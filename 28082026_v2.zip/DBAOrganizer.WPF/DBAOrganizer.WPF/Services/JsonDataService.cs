using System.IO;
using System.Text.Json;
using System.Collections.ObjectModel;
using DBAOrganizer.WPF.Models;

namespace DBAOrganizer.WPF.Services
{
    public class JsonDataService
    {
        private readonly string _filePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "tasks.json");

        public ObservableCollection<TaskItem> LoadTasks()
        {
            if (!File.Exists(_filePath))
                return new ObservableCollection<TaskItem>();

            try
            {
                var json = File.ReadAllText(_filePath);
                var tasks = JsonSerializer.Deserialize<ObservableCollection<TaskItem>>(json);
                return tasks ?? new ObservableCollection<TaskItem>();
            }
            catch
            {
                return new ObservableCollection<TaskItem>();
            }
        }

        public void SaveTasks(IEnumerable<TaskItem> tasks)
        {
            var options = new JsonSerializerOptions { WriteIndented = true };
            var json = JsonSerializer.Serialize(tasks, options);
            File.WriteAllText(_filePath, json);
        }
    }
}