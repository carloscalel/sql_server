using System.Windows;

namespace DBAOrganizer.WPF
{
    public partial class App : Application
    {
    }
}