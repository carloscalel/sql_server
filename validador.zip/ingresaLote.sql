USE [OrchestratorDB];
GO

-- Limpia solo si quieres empezar de cero (opcional)
-- DELETE FROM dbo.ExecutionQueue;
-- DELETE FROM dbo.ExecutionLog;
-- DELETE FROM dbo.ScriptsCatalog;

INSERT INTO dbo.ScriptsCatalog (ScriptName, TargetDatabase, CommandText, CommandTimeoutSec, Priority, IsActive)
VALUES
(N'Test 01 - Version SQL', N'AdventureWorks2022',
 N'SELECT @@VERSION AS SqlVersion;', 30, 10, 1),

(N'Test 02 - Contar empleados', N'AdventureWorks2022',
 N'SELECT COUNT(*) AS EmployeeCount FROM HumanResources.Employee;', 30, 20, 1),

(N'Test 03 - Top 5 productos', N'AdventureWorks2022',
 N'SELECT TOP (5) ProductID, Name, ListPrice FROM Production.Product ORDER BY ListPrice DESC;', 30, 30, 1),

(N'Test 04 - Fecha/DB actual', N'AdventureWorks2022',
 N'SELECT DB_NAME() AS CurrentDB, SYSDATETIME() AS Now;', 30, 40, 1);
GO


USE [OrchestratorDB];
GO

DECLARE @RunDate date = CAST(GETDATE() AS date);
EXEC dbo.usp_Queue_GenerateForDate @RunDate;
GO
