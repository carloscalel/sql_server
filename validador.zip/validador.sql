SELECT TOP 50 *
FROM dbo.ExecutionQueue
WHERE RunDate = CAST(GETDATE() AS date)
ORDER BY QueueId DESC;



SELECT * FROM dbo.ScriptsCatalog

--SELECT * FROM dbo.ExecutionQueue;
--SELECT * FROM dbo.ExecutionLog;
--SELECT * FROM dbo.ScriptsCatalog;


USE [OrchestratorDB];
GO

SELECT q.QueueId, q.RunDate, q.ScriptId, q.Status, q.Attempts, q.LockedBy, q.LockedAt, q.LastError
FROM dbo.ExecutionQueue q
WHERE q.RunDate = CAST(GETDATE() AS date)
ORDER BY q.QueueId DESC;


SELECT TOP 100
    l.LogId, l.QueueId, l.ScriptId, l.RunDate,
    l.StartedAt, l.FinishedAt, l.Succeeded,
    l.RowsAffected, l.ErrorNumber, l.ErrorMessage,
    l.HostName, l.AppInstance
FROM dbo.ExecutionLog l
WHERE l.RunDate = CAST(GETDATE() AS date)
ORDER BY l.LogId DESC;


