--------------------FASE 1 � Tablas de control y logging (SQL)--------------------
-- 1) Cat�logo de scripts
CREATE TABLE dbo.ScriptsCatalog
(
    ScriptId        INT IDENTITY(1,1) PRIMARY KEY,
    ScriptName      NVARCHAR(200) NOT NULL,
    TargetDatabase  SYSNAME NULL,              -- opcional (si ejecutas contra una DB espec�fica)
    CommandText     NVARCHAR(MAX) NOT NULL,    -- el SQL
    CommandTimeoutSec INT NOT NULL CONSTRAINT DF_ScriptsCatalog_Timeout DEFAULT(60),
    IsActive        BIT NOT NULL CONSTRAINT DF_ScriptsCatalog_IsActive DEFAULT(1),
    Priority        INT NOT NULL CONSTRAINT DF_ScriptsCatalog_Priority DEFAULT(100), -- menor = primero
    CreatedAt       DATETIME2 NOT NULL CONSTRAINT DF_ScriptsCatalog_CreatedAt DEFAULT(SYSDATETIME())
);
GO

-- 2) Cola diaria (qu� se va a ejecutar hoy)
CREATE TABLE dbo.ExecutionQueue
(
    QueueId         BIGINT IDENTITY(1,1) PRIMARY KEY,
    RunDate         DATE NOT NULL,
    ScriptId        INT NOT NULL,
    Status          VARCHAR(20) NOT NULL CONSTRAINT DF_ExecutionQueue_Status DEFAULT('PENDING'),
    -- PENDING | RUNNING | OK | ERROR | SKIPPED

    LockedBy        NVARCHAR(128) NULL,        -- nombre del worker/host
    LockedAt        DATETIME2 NULL,

    Attempts        INT NOT NULL CONSTRAINT DF_ExecutionQueue_Attempts DEFAULT(0),
    MaxAttempts     INT NOT NULL CONSTRAINT DF_ExecutionQueue_MaxAttempts DEFAULT(3),

    LastError       NVARCHAR(2000) NULL,
    CONSTRAINT FK_ExecutionQueue_ScriptId FOREIGN KEY (ScriptId) REFERENCES dbo.ScriptsCatalog(ScriptId),
    CONSTRAINT UQ_ExecutionQueue UNIQUE (RunDate, ScriptId)
);
GO

-- 3) Log detallado por ejecuci�n
CREATE TABLE dbo.ExecutionLog
(
    LogId           BIGINT IDENTITY(1,1) PRIMARY KEY,
    QueueId         BIGINT NOT NULL,
    ScriptId        INT NOT NULL,
    RunDate         DATE NOT NULL,

    StartedAt       DATETIME2 NOT NULL,
    FinishedAt      DATETIME2 NULL,
    DurationMs      BIGINT NULL,

    HostName        NVARCHAR(128) NULL,
    AppInstance     NVARCHAR(128) NULL,        -- por si luego tienes varios workers
    Succeeded       BIT NULL,

    RowsAffected    BIGINT NULL,
    ErrorNumber     INT NULL,
    ErrorMessage    NVARCHAR(2000) NULL,

    CONSTRAINT FK_ExecutionLog_QueueId FOREIGN KEY (QueueId) REFERENCES dbo.ExecutionQueue(QueueId)
);
GO

-- �ndices m�nimos para rendimiento
CREATE INDEX IX_ExecutionQueue_StatusRunDate ON dbo.ExecutionQueue (RunDate, Status) 
    INCLUDE (ScriptId, LockedBy, LockedAt, Attempts, MaxAttempts);

-- Nota: "Priority" est� en ScriptsCatalog, as� que lo resolveremos en el SP de picking.
GO


--------------------FASE 2 � Stored Procedures (para que C# no haga �l�gica de concurrencia� a mano)--------------------
CREATE OR ALTER PROCEDURE dbo.usp_Queue_GenerateForDate
    @RunDate DATE
AS
BEGIN
    SET NOCOUNT ON;

    INSERT INTO dbo.ExecutionQueue (RunDate, ScriptId)
    SELECT @RunDate, c.ScriptId
    FROM dbo.ScriptsCatalog c
    WHERE c.IsActive = 1
      AND NOT EXISTS (
          SELECT 1 FROM dbo.ExecutionQueue q 
          WHERE q.RunDate = @RunDate AND q.ScriptId = c.ScriptId
      );
END
GO


CREATE OR ALTER PROCEDURE dbo.usp_Queue_TakeNext
    @RunDate DATE,
    @WorkerName NVARCHAR(128)
AS
BEGIN
    SET NOCOUNT ON;

    ;WITH nextItem AS
    (
        SELECT TOP (1)
               q.QueueId
        FROM dbo.ExecutionQueue q
        INNER JOIN dbo.ScriptsCatalog c ON c.ScriptId = q.ScriptId
        WHERE q.RunDate = @RunDate
          AND q.Status IN ('PENDING', 'ERROR')
          AND q.Attempts < q.MaxAttempts
          AND c.IsActive = 1
        ORDER BY c.Priority ASC, q.QueueId ASC
    )
    UPDATE q
        SET q.Status   = 'RUNNING',
            q.LockedBy = @WorkerName,
            q.LockedAt = SYSDATETIME(),
            q.Attempts = q.Attempts + 1
    OUTPUT
        inserted.QueueId,
        inserted.ScriptId,
        c.ScriptName,
        c.TargetDatabase,
        c.CommandText,
        c.CommandTimeoutSec
    FROM dbo.ExecutionQueue q
    INNER JOIN nextItem n ON n.QueueId = q.QueueId
    INNER JOIN dbo.ScriptsCatalog c ON c.ScriptId = q.ScriptId;
END
GO


CREATE OR ALTER PROCEDURE dbo.usp_Queue_Complete
    @QueueId BIGINT,
    @Succeeded BIT,
    @RowsAffected BIGINT = NULL,
    @ErrorNumber INT = NULL,
    @ErrorMessage NVARCHAR(2000) = NULL,
    @HostName NVARCHAR(128) = NULL,
    @AppInstance NVARCHAR(128) = NULL
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @runDate DATE, @scriptId INT;

    SELECT @runDate = RunDate, @scriptId = ScriptId
    FROM dbo.ExecutionQueue
    WHERE QueueId = @QueueId;

    DECLARE @start DATETIME2 = SYSDATETIME();

    -- Log (tomamos StartedAt del momento de completar si no tienes otro punto de inicio)
    INSERT INTO dbo.ExecutionLog
    (
        QueueId, ScriptId, RunDate,
        StartedAt, FinishedAt, DurationMs,
        HostName, AppInstance,
        Succeeded, RowsAffected, ErrorNumber, ErrorMessage
    )
    VALUES
    (
        @QueueId, @scriptId, @runDate,
        @start, SYSDATETIME(), 0,
        @HostName, @AppInstance,
        @Succeeded, @RowsAffected, @ErrorNumber, @ErrorMessage
    );

    UPDATE dbo.ExecutionQueue
    SET Status = CASE WHEN @Succeeded = 1 THEN 'OK' ELSE 'ERROR' END,
        LastError = @ErrorMessage
    WHERE QueueId = @QueueId;
END
GO


--------------------FASE 3 � Usuario y permisos m�nimos (SQL Server)--------------------
USE [master]
GO
CREATE LOGIN [OrchestratorWorker] WITH PASSWORD=N'OrchestratorWorker', DEFAULT_DATABASE=[master], CHECK_EXPIRATION=OFF, CHECK_POLICY=ON
GO
USE [OrchestratorDB]
GO
CREATE USER [OrchestratorWorker] FOR LOGIN [OrchestratorWorker]
GO

-- Permisos m�nimos: leer cat�logo, tomar trabajo, completar, y generar cola
GRANT SELECT ON dbo.ScriptsCatalog TO OrchestratorWorker;
GRANT SELECT ON dbo.ExecutionQueue TO OrchestratorWorker;

GRANT EXECUTE ON dbo.usp_Queue_GenerateForDate TO OrchestratorWorker;
GRANT EXECUTE ON dbo.usp_Queue_TakeNext TO OrchestratorWorker;
GRANT EXECUTE ON dbo.usp_Queue_Complete TO OrchestratorWorker;

-- Para que pueda actualizar cola (porque el SP actualiza). Con EXECUTE alcanza si el due�o es dbo.
-- Aseg�rate que los SP est�n bajo dbo (ya lo hicimos) y que el OWNER sea dbo.
GO


