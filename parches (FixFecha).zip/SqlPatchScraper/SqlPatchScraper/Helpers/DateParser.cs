﻿using System;
using System.Globalization;
using System.Text.RegularExpressions;

namespace SqlPatchScraper.Helpers;

public static class DateParser
{
    private static readonly CultureInfo Es = new("es-ES");

    public static DateTime? Parse(string raw)
    {
        if (string.IsNullOrWhiteSpace(raw))
            return null;

        raw = raw.Trim();

        // 1️ martes, 13 de enero de 2026
        raw = Regex.Replace(raw, @"^[a-záéíóúñ]+,\s*", "", RegexOptions.IgnoreCase);

        // 2️ Normal
        if (DateTime.TryParse(raw, Es, DateTimeStyles.None, out var d))
            return d.Date;

        // 3 Abril de 2009 (mes + año)
        var m = Regex.Match(raw, @"^(?<mes>[a-záéíóúñ]+)\s+de\s+(?<anio>\d{4})$", RegexOptions.IgnoreCase);
        if (m.Success)
        {
            var text = $"1 de {m.Groups["mes"].Value} de {m.Groups["anio"].Value}";
            if (DateTime.TryParse(text, Es, DateTimeStyles.None, out d))
                return d.Date;
        }

        return null;
    }
}

//namespace SqlPatchScraper.Helpers
//{
//    public static class DateParser
//    {
//        private static readonly CultureInfo EsCulture =
//            new CultureInfo("es-ES");

//        public static bool TryParseSpanishDate(string input, out DateTime date)
//        {
//            date = default;

//            if (string.IsNullOrWhiteSpace(input))
//                return false;

//            // Quitar día de la semana si existe
//            var clean = input.Contains(",")
//                ? input.Split(',')[1].Trim()
//                : input.Trim();

//            return DateTime.TryParseExact(
//                clean,
//                "d 'de' MMMM 'de' yyyy",
//                EsCulture,
//                DateTimeStyles.None,
//                out date
//            );
//        }
//    }
//}
