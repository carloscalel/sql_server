﻿using HtmlAgilityPack;
using SqlPatchScraper.Helpers;
using SqlPatchScraper.Models;
using System.Globalization;
using System.Text.RegularExpressions;

namespace SqlPatchScraper.Scraping;

public class MicrosoftLearnScraper
{
    private readonly HttpClient _http;

    public MicrosoftLearnScraper()
    {
        _http = new HttpClient();
        _http.DefaultRequestHeaders.UserAgent.ParseAdd("Mozilla/5.0");
    }

    public async Task<(string html, List<SqlPatch> patches)> ScrapeAsync(string url)
    {
        var html = await _http.GetStringAsync(url);

        var doc = new HtmlDocument();
        doc.LoadHtml(html);

        var tables = doc.DocumentNode.SelectNodes("//table")?.ToList() ?? new List<HtmlNode>();
        if (tables.Count == 0)
            throw new Exception("No se encontraron tablas en la página");

        var allPatches = new List<SqlPatch>();

        foreach (var table in tables)
        {
            var productName = GetNearestHeading(table);

            var headerNodes = table.SelectNodes(".//tr[1]//th");
            if (headerNodes == null || headerNodes.Count == 0)
                continue;

            var headers = headerNodes.Select(h => Normalize(h.InnerText)).ToList();

            // En vez de requerir KB, detectamos tablas "tipo SQL updates" por headers
            bool looksLikeSqlTable =
                headers.Any(h => h.Contains("compilación") || h.Contains("build") || h.Contains("version") || h.Contains("versión")) &&
                headers.Any(h => h.Contains("knowledge base") || h.Contains("kb") || h.Contains("base de conocimientos")) &&
                headers.Any(h => h.Contains("fecha"));

            if (!looksLikeSqlTable)
                continue;

            int idxVersion = FindHeaderIndex(headers, new[]
            {
                "número de compilación", "numero de compilacion", "compilación", "compilacion",
                "número de compilación o versión", "numero de compilacion o version",
                "build", "build number", "version", "versión"
            });

            int idxUpdate = FindHeaderIndex(headers, new[]
            {
                "actualización", "actualizacion", "update", "cumulative update"
            });

            int idxKB = FindHeaderIndex(headers, new[]
            {
                "número de knowledge base", "numero de knowledge base",
                "knowledge base", "kb", "artículo kb", "articulo kb", "base de conocimientos"
            });

            int idxDate = FindHeaderIndex(headers, new[]
            {
                "fecha de lanzamiento", "fecha lanzamiento",
                "release date", "date", "fecha", "publicación", "publicacion"
            });

            // KB puede no existir (SQL 2025 muestra ND), pero la columna sí suele existir
            if (idxKB < 0)
                continue;

            // leer filas del tbody, si existe (evita perder la primera fila)
            var rows = table.SelectNodes(".//tbody/tr")?.ToList()
                       ?? table.SelectNodes(".//tr")?.ToList()
                       ?? new List<HtmlNode>();

            foreach (var row in rows)
            {
                // Saltar headers (normalmente sin td)
                var tds = row.SelectNodes("./td");
                if (tds == null || tds.Count == 0)
                    continue;

                // soportar th|td
                var cols = row.SelectNodes("./th|./td");
                if (cols == null || cols.Count == 0) continue;

                string version = idxVersion >= 0 && cols.Count > idxVersion
                    ? Clean(cols[idxVersion].InnerText)
                    : "";

                // Tomar "Actualización" directamente (CUxx, CUxx+GDR, RDA, RTM/GA)
                string cu = "";
                if (idxUpdate >= 0 && cols.Count > idxUpdate)
                {
                    cu = Clean(cols[idxUpdate].InnerText);
                    cu = NormalizeUpdateValue(cu);
                }
                else
                {
                    // fallback por si no detectó columna
                    cu = ExtractUpdateToken(Normalize(row.InnerText)) ?? "";
                }

                string kbText = "";
                string kbUrl = "";

                if (cols.Count > idxKB)
                {
                    var kbLink = cols[idxKB].SelectSingleNode(".//a");
                    kbText = kbLink != null ? Clean(kbLink.InnerText) : Clean(cols[idxKB].InnerText);
                    kbUrl = kbLink?.GetAttributeValue("href", "") ?? "";
                }

                // Fallback: buscar link KB en la fila
                if (string.IsNullOrWhiteSpace(kbText) || !ContainsKB(kbText))
                {
                    var anyKbLink = row.SelectSingleNode(
                        ".//a[contains(translate(@href,'kb','KB'),'KB') or contains(translate(text(),'kb','KB'),'KB')]"
                    );

                    if (anyKbLink != null)
                    {
                        kbText = Clean(anyKbLink.InnerText);
                        kbUrl = anyKbLink.GetAttributeValue("href", "");

                        if (string.IsNullOrWhiteSpace(kbText))
                        {
                            var m = Regex.Match(kbUrl ?? "", @"\b\d{6,8}\b");
                            if (m.Success) kbText = "KB" + m.Value;
                        }
                    }
                }

                // Normalizar KB
                kbText = NormalizeKB(kbText);

                // Si viene ND/N-D, permitimos la fila y dejamos KB vacío
                if (IsND(kbText))
                    kbText = "";

                // Solo descartamos si NO hay KB y además NO es ND (caso raro)
                // Para SQL 2025, KB puede venir vacío por ND y debe entrar.
                if (!string.IsNullOrWhiteSpace(kbText) && !ContainsKB(kbText))
                    continue;

                if (!string.IsNullOrWhiteSpace(kbUrl) && kbUrl.StartsWith("/"))
                    kbUrl = "https://learn.microsoft.com" + kbUrl;

                // FECHA
                //DateTime? releaseDate = null;
                //if (idxDate >= 0 && cols.Count > idxDate)
                //{
                //    var dateStr = Clean(cols[idxDate].InnerText);
                //    if (TryParseSpanishDate(dateStr, out var parsed))
                //        releaseDate = parsed.Date;
                //}
                DateTime? releaseDate = null;
                if (idxDate >= 0 && cols.Count > idxDate)
                {
                    var dateStr = Clean(cols[idxDate].InnerText);

                    //if (DateParser.TryParseSpanishDate(dateStr, out var d))
                    //    releaseDate = d.Date;
                    releaseDate = DateParser.Parse(dateStr);
                }

                // Si version quedó vacío, intentar extraerlo del texto
                if (string.IsNullOrWhiteSpace(version))
                {
                    var rowText = Normalize(row.InnerText);
                    version = ExtractVersionLike(rowText) ?? "";
                }

                allPatches.Add(new SqlPatch
                {
                    Product = productName,
                    Version = version,
                    CU = string.IsNullOrWhiteSpace(cu) ? null : cu,
                    KB = string.IsNullOrWhiteSpace(kbText) ? null : kbText,
                    ReleaseDate = releaseDate,
                    UrlKB = kbUrl
                });
            }
        }

        if (allPatches.Count == 0)
            throw new Exception("No se extrajo ningún parche.");

        return (html, allPatches
            .GroupBy(p => $"{p.Product}|{p.Version}|{p.KB}")
            .Select(g => g.First())
            .ToList());
    }

    private static int FindHeaderIndex(List<string> headers, string[] keywords)
    {
        for (int i = 0; i < headers.Count; i++)
            foreach (var k in keywords)
                if (headers[i].Contains(Normalize(k)))
                    return i;

        return -1;
    }

    private static string Normalize(string s)
        => Regex.Replace((s ?? "").Trim().ToLowerInvariant(), @"\s+", " ");

    private static string Clean(string s)
        => HtmlEntity.DeEntitize((s ?? "").Trim());

    private static bool ContainsKB(string s)
        => Regex.IsMatch(s ?? "", @"\b(KB\s*)?\d{6,8}\b", RegexOptions.IgnoreCase);

    private static string NormalizeKB(string kbRaw)
    {
        if (string.IsNullOrWhiteSpace(kbRaw)) return "";
        var txt = Clean(kbRaw);
        txt = Regex.Replace(txt, @"\s+", " ").Trim();

        // Si viene ND, se mantiene para que IsND lo detecte
        if (txt.Equals("ND", StringComparison.OrdinalIgnoreCase) ||
            txt.Equals("N/D", StringComparison.OrdinalIgnoreCase))
            return txt;

        var m = Regex.Match(txt, @"\b\d{6,8}\b");
        if (!m.Success) return txt;

        return "KB" + m.Value;
    }

    // Normaliza valores de "Actualización": CU21 + GDR => CU21+GDR, RDA, RTM/GA
    private static string NormalizeUpdateValue(string s)
    {
        if (string.IsNullOrWhiteSpace(s)) return "";
        s = Clean(s);
        s = Regex.Replace(s, @"\s+", " ").Trim();
        s = Regex.Replace(s, @"\s*\+\s*", "+");
        return s.ToUpperInvariant();
    }

    // Fallback: detecta CUxx, CUxx+GDR, RDA, RTM/GA
    private static string? ExtractUpdateToken(string text)
    {
        if (string.IsNullOrWhiteSpace(text)) return null;

        var m = Regex.Match(text, @"\b(CU\s*\d+(\s*\+\s*GDR)?|RDA|RTM\/GA)\b", RegexOptions.IgnoreCase);
        return m.Success ? NormalizeUpdateValue(m.Value) : null;
    }

    private static bool IsND(string s)
    {
        if (string.IsNullOrWhiteSpace(s)) return false;
        s = Clean(s).Trim();

        return s.Equals("ND", StringComparison.OrdinalIgnoreCase) ||
               s.Equals("N/D", StringComparison.OrdinalIgnoreCase) ||
               s.Equals("NA", StringComparison.OrdinalIgnoreCase) ||
               s.Equals("N.A.", StringComparison.OrdinalIgnoreCase);
    }

    private static string? ExtractVersionLike(string text)
    {
        var m = Regex.Match(text ?? "", @"\b\d{2}\.\d+\.\d+\.\d+\b");
        return m.Success ? m.Value : null;
    }

    private static string GetNearestHeading(HtmlNode table)
    {
        var candidates = table.SelectNodes("preceding::h2 | preceding::h3 | preceding::h4");
        if (candidates == null || candidates.Count == 0)
            return "SQL Server";

        for (int i = candidates.Count - 1; i >= 0; i--)
        {
            var text = Clean(candidates[i].InnerText);
            text = Regex.Replace(text, @"\s+", " ").Trim();

            if (text.Contains("SQL Server", StringComparison.OrdinalIgnoreCase))
                return text;
        }

        return "SQL Server";
    }

    private static bool TryParseSpanishDate(string input, out DateTime date)
    {
        date = default;

        if (string.IsNullOrWhiteSpace(input))
            return false;

        input = input.Trim();

        var es = new CultureInfo("es-ES");

        var formats = new[]
        {
            "d 'de' MMMM 'de' yyyy",
            "dd 'de' MMMM 'de' yyyy",
            "d 'de' MMMM yyyy",
            "dd 'de' MMMM yyyy"
        };

        return DateTime.TryParseExact(
            input,
            formats,
            es,
            DateTimeStyles.None,
            out date
        );
    }
}
