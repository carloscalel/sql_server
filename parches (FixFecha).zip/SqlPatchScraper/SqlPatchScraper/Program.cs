﻿using SqlPatchScraper.Data;
using SqlPatchScraper.Scraping;
using SqlPatchScraper.Utils;

internal class Program
{
    private const string Url =
        "https://learn.microsoft.com/es-es/troubleshoot/sql/releases/download-and-install-latest-updates";

    private const string ConnString =
        "Server=CALEL;Database=adminDB;Integrated Security=true;TrustServerCertificate=true;";

    private static readonly string LogPath =
        Path.Combine(AppContext.BaseDirectory, "logs", $"run_{DateTime.Now:yyyyMMdd}.log");

    static async Task Main()
    {
        Directory.CreateDirectory(Path.GetDirectoryName(LogPath)!);

        try
        {
            Log("Inicio ejecución.");

            var scraper = new MicrosoftLearnScraper();
            var (html, patches) = await scraper.ScrapeAsync(Url);

            var hash = HashHelper.ComputeSha256(html);

            Log($"Scrape OK. Parches encontrados: {patches.Count}. Hash: {hash}");

            var repo = new SqlRepository(ConnString);
            var (inserted, found, skipped, alreadyProcessed) =
                await repo.SaveLearnPatchesAsync(Url, hash, html, patches);

            Log($"SQL OK => Found={found}, Inserted={inserted}, Skipped={skipped}, AlreadyProcessed={alreadyProcessed}");
            Log("Fin ejecución.");

            Environment.ExitCode = 0;
        }
        catch (Exception ex)
        {
            Log("ERROR:");
            Log(ex.ToString());
            Environment.ExitCode = 1;
        }
    }

    private static void Log(string msg)
    {
        File.AppendAllText(LogPath, $"[{DateTime.Now:yyyy-MM-dd HH:mm:ss}] {msg}{Environment.NewLine}");
    }
}
