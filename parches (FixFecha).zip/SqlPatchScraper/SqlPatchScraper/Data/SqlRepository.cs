﻿using System.Data;
using Dapper;
using Microsoft.Data.SqlClient;
using SqlPatchScraper.Models;

namespace SqlPatchScraper.Data;

public class SqlRepository
{
    private readonly string _conn;

    public SqlRepository(string connectionString)
    {
        _conn = connectionString;
    }

    public async Task<(int Inserted, int Found, int Skipped, bool AlreadyProcessed)>
        SaveLearnPatchesAsync(string sourceUrl, string pageHash, string htmlContent, IEnumerable<SqlPatch> patches)
    {
        using var cn = new SqlConnection(_conn);
        await cn.OpenAsync();

        var tvp = new DataTable();
        tvp.Columns.Add("Product", typeof(string));
        tvp.Columns.Add("Version", typeof(string));
        tvp.Columns.Add("CU", typeof(string));
        tvp.Columns.Add("KB", typeof(string));
        tvp.Columns.Add("ReleaseDate", typeof(DateTime));
        tvp.Columns.Add("UrlKB", typeof(string));

        foreach (var p in patches)
        {
            object releaseDate = p.ReleaseDate.HasValue ? p.ReleaseDate.Value.Date : DBNull.Value;

            tvp.Rows.Add(
                p.Product ?? "SQL Server",
                p.Version ?? "",
                string.IsNullOrWhiteSpace(p.CU) ? DBNull.Value : p.CU,
                p.KB ?? "",
                releaseDate,
                string.IsNullOrWhiteSpace(p.UrlKB) ? DBNull.Value : p.UrlKB
            );
        }

        var dp = new DynamicParameters();
        dp.Add("@SourceUrl", sourceUrl, DbType.String, size: 600);
        dp.Add("@PageHash", pageHash, DbType.AnsiStringFixedLength, size: 64);
        dp.Add("@HtmlContent", htmlContent, DbType.String);
        dp.Add("@Patches", tvp.AsTableValuedParameter("Patch.SqlPatchTvp"));

        var result = await cn.QuerySingleAsync<SaveResult>(
            "Patch.SaveLearnPatches",
            dp,
            commandType: CommandType.StoredProcedure
        );

        return (result.InsertedCount, result.PatchesFound, result.SkippedAsDup, result.AlreadyProcessed);
    }

    private sealed class SaveResult
    {
        public int InsertedCount { get; set; }
        public int PatchesFound { get; set; }
        public int SkippedAsDup { get; set; }
        public bool AlreadyProcessed { get; set; }
    }
}
