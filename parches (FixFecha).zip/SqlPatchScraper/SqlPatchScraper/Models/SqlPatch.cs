﻿namespace SqlPatchScraper.Models;

public class SqlPatch
{
    public string Product { get; set; } = "";
    public string Version { get; set; } = "";
    public string CU { get; set; } = "";
    public string KB { get; set; } = "";
    public DateTime? ReleaseDate { get; set; }
    public string UrlKB { get; set; } = "";
}
