using System.Windows;

namespace OfuscadorTool;

public partial class ProgressDialog : Window
{
    public ProgressDialog(string stage)
    {
        InitializeComponent(); StageText.Text = stage;
    }

    public void UpdateProgress(int current, int total, string detail)
    {
        var percent = total <= 0 ? 0 : Math.Clamp((int)Math.Round(current * 100d / total), 0, 100);
        Progress.Value = percent; PercentText.Text = $"{percent}%"; DetailText.Text = detail;
    }
}
