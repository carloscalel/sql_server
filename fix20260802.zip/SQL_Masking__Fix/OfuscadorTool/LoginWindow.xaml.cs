using Microsoft.Data.SqlClient;
using System.Windows;

namespace OfuscadorTool;

public partial class LoginWindow : Window
{
    public LoginWindow() => InitializeComponent();

    private void AuthChanged(object sender, RoutedEventArgs e)
    {
        if (UserBox is null) return;
        var sql = WindowsBox.IsChecked != true;
        UserBox.IsEnabled = sql; PasswordBox.IsEnabled = sql;
    }

    private async void LoginClick(object sender, RoutedEventArgs e)
    {
        LoginButton.IsEnabled = false;
        StatusText.Text = "";
        StatusBorder.Visibility = Visibility.Collapsed;
        try
        {
            var source = string.IsNullOrWhiteSpace(InstanceBox.Text) ? HostBox.Text.Trim() : $@"{HostBox.Text.Trim()}\{InstanceBox.Text.Trim()}";
            var master = DatabaseService.BuildConnection(source, "master", WindowsBox.IsChecked == true, UserBox.Text.Trim(), PasswordBox.Password, EncryptBox.IsChecked == true, TrustBox.IsChecked == true);
            await using (var cn = new SqlConnection(master)) { await cn.OpenAsync(); }
            var admin = DatabaseBox.Text.Trim();
            var adminCs = DatabaseService.BuildConnection(source, admin, WindowsBox.IsChecked == true, UserBox.Text.Trim(), PasswordBox.Password, EncryptBox.IsChecked == true, TrustBox.IsChecked == true);
            var principal = WindowsBox.IsChecked == true ? Environment.UserDomainName + "\\" + Environment.UserName : UserBox.Text.Trim();
            var contextBase = new LoginContext(adminCs, principal, admin, "");
            var db = new DatabaseService(contextBase);
            await db.ValidateInstallationAsync();
            var role = await db.GetUserRoleAsync();
            if (role is null) throw new UnauthorizedAccessException("La identidad no está activa en Usuarios autorizados.");
            var context = contextBase with { Role = role };
            await db.AuditAsync("Login", "Ingresar", true, $"Rol={role}");
            new MainWindow(context).Show(); Close();
        }
        catch (Exception ex)
        {
            StatusText.Text = ex.Message; StatusText.Foreground = System.Windows.Media.Brushes.Firebrick;
            StatusBorder.Visibility = Visibility.Visible;
        }
        finally { LoginButton.IsEnabled = true; }
    }

    private void ExitClick(object sender, RoutedEventArgs e) => Close();
}
