using Microsoft.Data.SqlClient;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Data;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;

namespace OfuscadorTool;

public partial class MainWindow : Window
{
    private readonly DatabaseService _db;
    private readonly DeploymentService _deployment;
    private readonly bool _isAdministrator;
    private readonly bool _isOperator;
    private readonly bool _isAuditor;
    private ICollectionView? _serversView;
    private ICollectionView? _patternsView;
    private ICollectionView? _authorizedUsersView;
    private ICollectionView? _exceptionsView;
    private ICollectionView? _auditView;
    private ICollectionView? _inventoryView;
    private MaskingInventoryTreeNode? _inventoryScope;
    private bool _rebuildingInventoryTree;
    private DataTable? _auditTable;
    private bool _rollbackInProgress;
    public ObservableCollection<ServerProfile> Servers { get; set; } = [];
    public ObservableCollection<DatabaseTarget> Targets { get; } = [];
    public ObservableCollection<DeploymentTreeNode> ServerNodes { get; } = [];
    public ObservableCollection<DeploymentTreeNode> ExcludedNodes { get; } = [];
    public ObservableCollection<DeploymentTreeNode> FilteredServerNodes { get; } = [];
    public ObservableCollection<DeploymentTreeNode> FilteredExcludedNodes { get; } = [];
    public ObservableCollection<MaskPattern> Patterns { get; set; } = [];
    public ObservableCollection<MaskException> Exceptions { get; set; } = [];
    public ObservableCollection<AuthorizedUser> Users { get; set; } = [];
    public ObservableCollection<ExecutionRow> ExecutionRows { get; } = [];
    public ObservableCollection<MaskingInventoryRow> InventoryRows { get; } = [];
    public ObservableCollection<MaskingInventoryTreeNode> InventoryNodes { get; } = [];

    public MainWindow(LoginContext context)
    {
        InitializeComponent();
        _db = new(context); _deployment = new(_db);
        _isAdministrator = string.Equals(context.Role, "Administrator", StringComparison.OrdinalIgnoreCase);
        _isOperator = string.Equals(context.Role, "Operator", StringComparison.OrdinalIgnoreCase);
        _isAuditor = string.Equals(context.Role, "Auditor", StringComparison.OrdinalIgnoreCase);
        ConfigureRoleAccess();
        _deployment.Log += text => Dispatcher.Invoke(() =>
        {
            LogBox.AppendText(text + Environment.NewLine); LogBox.ScrollToEnd();
        });
        PrincipalText.Text = context.Principal;
        DashboardPrincipalText.Text = context.Principal;
        DashboardRoleText.Text = context.Role;
        var productVersion = typeof(MainWindow).Assembly.GetName().Version;
        AboutVersionText.Text = productVersion is null
            ? "No disponible"
            : $"{productVersion.Major}.{productVersion.Minor}.{productVersion.Build}";
        RoleColumn.ItemsSource = new[] { "Administrator", "Operator", "Auditor" };
        PatternPriorityColumn.ItemsSource = new[] { "Bajo", "Medio", "Alto" };
        DataContext = this;
        Loaded += async (_, _) => await LoadInitialAsync();
    }

    private bool CanExecuteOperations => _isAdministrator || _isOperator;
    private bool CanReviewConfiguration => _isAdministrator || _isAuditor;
    private bool CanViewAudit => _isAdministrator || _isAuditor;
    private bool CanViewInventory => _isAdministrator || _isAuditor;

    private void ConfigureRoleAccess()
    {
        MaskingNavButton.Visibility = CanExecuteOperations ? Visibility.Visible : Visibility.Collapsed;
        RollbackNavButton.Visibility = CanExecuteOperations ? Visibility.Visible : Visibility.Collapsed;
        ServersNavButton.Visibility = CanReviewConfiguration ? Visibility.Visible : Visibility.Collapsed;
        RulesNavButton.Visibility = CanReviewConfiguration ? Visibility.Visible : Visibility.Collapsed;
        ExceptionsNavButton.Visibility = CanReviewConfiguration ? Visibility.Visible : Visibility.Collapsed;
        ProfilesNavButton.Visibility = _isAdministrator ? Visibility.Visible : Visibility.Collapsed;
        AuthorizedUsersButton.Visibility = _isAdministrator ? Visibility.Visible : Visibility.Collapsed;
        AuditNavButton.Visibility = CanViewAudit ? Visibility.Visible : Visibility.Collapsed;
        InventoryNavButton.Visibility = CanViewInventory ? Visibility.Visible : Visibility.Collapsed;

        ServerActionsPanel.Visibility = _isAdministrator ? Visibility.Visible : Visibility.Collapsed;
        PatternActionsPanel.Visibility = _isAdministrator ? Visibility.Visible : Visibility.Collapsed;
        ExceptionActionsPanel.Visibility = _isAdministrator ? Visibility.Visible : Visibility.Collapsed;
        ServersGrid.IsReadOnly = !_isAdministrator;
        PatternsGrid.IsReadOnly = !_isAdministrator;

        DashboardMaskingCard.Visibility = CanExecuteOperations ? Visibility.Visible : Visibility.Collapsed;
        DashboardRollbackCard.Visibility = CanExecuteOperations ? Visibility.Visible : Visibility.Collapsed;
        DashboardFlowCard.Visibility = CanExecuteOperations ? Visibility.Visible : Visibility.Collapsed;
        DashboardServersCard.Visibility = CanReviewConfiguration ? Visibility.Visible : Visibility.Collapsed;
        DashboardRulesCard.Visibility = CanReviewConfiguration ? Visibility.Visible : Visibility.Collapsed;
        DashboardProfilesCard.Visibility = _isAdministrator ? Visibility.Visible : Visibility.Collapsed;
        DashboardEnvironmentUsersCard.Visibility = _isAdministrator ? Visibility.Visible : Visibility.Collapsed;

        SidebarRoleText.Text = _isAdministrator ? "Administrador · acceso total"
            : _isOperator ? "Operador · ejecución"
            : _isAuditor ? "Auditor · solo lectura"
            : "Rol sin permisos asignados";
    }

    private bool CanAccessPage(int index) => index switch
    {
        0 => true,
        1 or 2 => CanExecuteOperations,
        3 or 4 or 5 => CanReviewConfiguration,
        6 => _isAdministrator,
        7 => CanViewAudit,
        8 => CanViewInventory,
        9 => true,
        _ => false
    };

    private bool RequireAdministrator()
    {
        if (_isAdministrator) return true;
        MessageBox.Show("Esta acción requiere el rol Administrador.", "Acceso restringido",
            MessageBoxButton.OK, MessageBoxImage.Warning);
        return false;
    }

    private bool RequireExecutionRole()
    {
        if (CanExecuteOperations) return true;
        MessageBox.Show("Esta acción requiere el rol Administrador u Operador.", "Acceso restringido",
            MessageBoxButton.OK, MessageBoxImage.Warning);
        return false;
    }

    private async Task LoadInitialAsync()
    {
        Servers = await _db.LoadServersAsync(); Patterns = await _db.LoadPatternsAsync();
        Exceptions = await _db.LoadMaskExceptionsAsync();
        Users = _isAdministrator ? await _db.LoadUsersAsync() : [];
        ConfigureServersView(); ConfigurePatternsView(); ConfigureExceptionsView(); ConfigureAuthorizedUsersView();
        await _db.AuditAsync("Resumen", "Abrir", true);
    }

    private async void Navigate(object sender, RoutedEventArgs e)
    {
        var index = int.Parse((string)((Button)sender).Tag);
        if (!CanAccessPage(index))
        {
            MessageBox.Show("Tu rol no tiene acceso a este módulo.", "Acceso restringido",
                MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }
        Pages.SelectedIndex = index;
        var names = new[] { "Resumen", "Ofuscamiento", "Rollback", "Excepciones", "Servidores", "Reglas", "Usuarios autorizados", "Auditoría", "Estado de ofuscamiento", "Acerca de" };
        try
        {
            await _db.AuditAsync(names[index], "Abrir", true);
            if (index == 2) await LoadRollbackAsync();
            if (index == 7) await LoadAuditAsync();
            if (index == 8 && InventoryRows.Count == 0) await LoadInventoryAsync();
        }
        catch (Exception ex) { MessageBox.Show(ex.Message, "Error", MessageBoxButton.OK, MessageBoxImage.Error); }
    }

    private void OpenProfilesClick(object sender, RoutedEventArgs e)
    {
        if (!RequireAdministrator()) return;
        new ProfileWindow(_db, _deployment, Servers, Patterns) { Owner = this }.ShowDialog();
    }

    private async void LoadTargetsClick(object sender, RoutedEventArgs e)
    {
        if (!await TryLoadTargetsAsync()) return;
    }

    private async Task<bool> TryLoadTargetsAsync()
    {
        var progress = new ProgressDialog("Cargar servidores y bases") { Owner = this };
        IsEnabled = false; progress.Show();
        Targets.Clear(); ServerNodes.Clear(); ExcludedNodes.Clear();
        FilteredServerNodes.Clear(); FilteredExcludedNodes.Clear();
        try
        {
            var activeServers = Servers.Where(s => s.IsActive).ToList();
            var serverIndex = 0;
            foreach (var server in activeServers)
            {
                serverIndex++;
                progress.UpdateProgress(serverIndex - 1, activeServers.Count, $"Cargando bases de {server.Name}...");
                var serverNode = new DeploymentTreeNode { DisplayName = $"{server.Name}  ({server.DataSource})", Kind = "server", Server = server };
                foreach (var database in await _db.LoadDatabasesAsync(server))
                {
                    var target = new DatabaseTarget { Server = server, Database = database };
                    Targets.Add(target);
                    serverNode.Children.Add(new DeploymentTreeNode { DisplayName = database, Kind = "database", Server = server, Target = target });
                }
                ServerNodes.Add(serverNode);
            }
            ApplyTargetFilter();
            await _db.AuditAsync("Ofuscamiento", "Cargar bases", true, $"{Targets.Count} bases");
            progress.UpdateProgress(activeServers.Count, activeServers.Count, $"Completado: {Targets.Count} bases disponibles");
            await Task.Delay(250);
            return true;
        }
        catch (Exception ex) { await _db.AuditAsync("Ofuscamiento", "Cargar bases", false, ex.Message); ShowError(ex); return false; }
        finally { progress.Close(); IsEnabled = true; }
    }

    private async void LoadPrincipalsClick(object sender, RoutedEventArgs e)
    {
        var progress = new ProgressDialog("Cargar usuarios de las bases seleccionadas") { Owner = this };
        IsEnabled = false; progress.Show();
        try
        {
            var targets = Targets.Where(t => t.IsSelected).ToList();
            if (targets.Count == 0) { MessageBox.Show("Selecciona una o varias bases antes de cargar sus usuarios."); return; }
            ExcludedNodes.Clear();
            foreach (var server in Servers.Where(s => s.IsActive))
                ExcludedNodes.Add(new DeploymentTreeNode { DisplayName = $"{server.Name}  ({server.DataSource})", Kind = "excluded-server", Server = server });
            if (targets.Count == 0) { MessageBox.Show("Selecciona una o varias bases en la sección 1 antes de cargar sus usuarios."); return; }
            var targetIndex = 0;
            foreach (var target in targets)
            {
                targetIndex++;
                progress.UpdateProgress(targetIndex - 1, targets.Count, $"Consultando usuarios: {target.Server.Name}/{target.Database}");
                var serverNode = ExcludedNodes.FirstOrDefault(n => ReferenceEquals(n.Server, target.Server));
                if (serverNode is null) continue;
                var node = new DeploymentTreeNode { DisplayName = target.Database, Kind = "excluded-database", Server = target.Server, Target = target };
                serverNode.Children.Add(node);
                var users = await _db.LoadPrincipalsAsync(target.Server, target.Database);
                target.Principals.Clear();
                node.Children.Clear();
                foreach (var user in users)
                {
                    target.Principals.Add(user);
                    node.Children.Add(new DeploymentTreeNode { DisplayName = $"{user.Name}  [{user.Type}]" + (user.IsProtected ? "  · protegido" : ""), Kind = "user", Server = target.Server, Target = target, Principal = user, IsChecked = user.IsExcluded });
                }
            }
            ApplyTargetFilter();
            ApplyExcludedUserFilter();
            await _db.AuditAsync("Ofuscamiento", "Cargar usuarios", true, null);
            progress.UpdateProgress(targets.Count, targets.Count, $"Completado: {targets.Count} base(s)");
            await Task.Delay(250);
        }
        catch (Exception ex) { ShowError(ex); }
        finally { progress.Close(); IsEnabled = true; }
    }

    private void TreeCheckChanged(object sender, RoutedEventArgs e)
    {
        if (sender is not CheckBox check || check.DataContext is not DeploymentTreeNode node) return;
        var value = check.IsChecked == true;
        if (node.Kind == "server")
        {
            foreach (var target in Targets.Where(x => ReferenceEquals(x.Server, node.Server)))
                target.IsSelected = value;
            foreach (var database in node.Children) database.IsChecked = value;
        }
        else if (node.Kind == "database" && node.Target is not null) node.Target.IsSelected = value;
        else if (node.Kind == "excluded-server")
        {
            foreach (var target in Targets.Where(x => ReferenceEquals(x.Server, node.Server)))
                foreach (var principal in target.Principals)
                    principal.IsExcluded = principal.IsProtected || value;
            foreach (var database in node.Children)
                foreach (var user in database.Children)
                    user.IsChecked = user.Principal?.IsProtected == true || value;
        }
        else if (node.Kind == "excluded-database" && node.Target is not null)
        {
            foreach (var principal in node.Target.Principals)
                principal.IsExcluded = principal.IsProtected || value;
            foreach (var user in node.Children)
                user.IsChecked = user.Principal?.IsProtected == true || value;
        }
        else if (node.Kind == "user" && node.Principal is not null)
        {
            node.Principal.IsExcluded = node.Principal.IsProtected || value;
            node.IsChecked = node.Principal.IsExcluded;
        }
    }

    private void TargetFilterChanged(object sender, TextChangedEventArgs e) => ApplyTargetFilter();

    private void ExcludedUserFilterChanged(object sender, TextChangedEventArgs e) => ApplyExcludedUserFilter();

    private void ApplyTargetFilter()
    {
        if (FilteredServerNodes is null) return;
        var filter = TargetFilterBox?.Text?.Trim() ?? "";
        FilteredServerNodes.Clear();
        foreach (var sourceServer in ServerNodes)
        {
            var serverMatches = Matches(sourceServer.DisplayName, filter);
            var databases = sourceServer.Children
                .Where(x => serverMatches || Matches(x.DisplayName, filter))
                .ToList();
            if (!serverMatches && databases.Count == 0) continue;

            var serverNode = new DeploymentTreeNode
            {
                DisplayName = sourceServer.DisplayName,
                Kind = sourceServer.Kind,
                Server = sourceServer.Server,
                IsChecked = Targets.Where(x => ReferenceEquals(x.Server, sourceServer.Server)).Any()
                    && Targets.Where(x => ReferenceEquals(x.Server, sourceServer.Server)).All(x => x.IsSelected)
            };
            foreach (var database in databases)
                serverNode.Children.Add(new DeploymentTreeNode
                {
                    DisplayName = database.DisplayName,
                    Kind = database.Kind,
                    Server = database.Server,
                    Target = database.Target,
                    IsChecked = database.Target?.IsSelected == true
                });
            FilteredServerNodes.Add(serverNode);
        }
    }

    private void ApplyExcludedUserFilter()
    {
        if (FilteredExcludedNodes is null) return;
        var filter = ExcludedUserFilterBox?.Text?.Trim() ?? "";
        FilteredExcludedNodes.Clear();
        foreach (var sourceServer in ExcludedNodes)
        {
            var serverNode = new DeploymentTreeNode
            {
                DisplayName = sourceServer.DisplayName,
                Kind = sourceServer.Kind,
                Server = sourceServer.Server
            };
            foreach (var sourceDatabase in sourceServer.Children)
            {
                var users = sourceDatabase.Children
                    .Where(x => Matches(x.DisplayName, filter))
                    .ToList();
                if (users.Count == 0 && !string.IsNullOrWhiteSpace(filter)) continue;
                var databaseNode = new DeploymentTreeNode
                {
                    DisplayName = sourceDatabase.DisplayName,
                    Kind = sourceDatabase.Kind,
                    Server = sourceDatabase.Server,
                    Target = sourceDatabase.Target,
                    IsChecked = sourceDatabase.Target?.Principals.Count > 0
                        && sourceDatabase.Target.Principals.All(x => x.IsExcluded)
                };
                foreach (var user in users)
                    databaseNode.Children.Add(new DeploymentTreeNode
                    {
                        DisplayName = user.DisplayName,
                        Kind = user.Kind,
                        Server = user.Server,
                        Target = user.Target,
                        Principal = user.Principal,
                        IsChecked = user.Principal?.IsExcluded == true
                    });
                serverNode.Children.Add(databaseNode);
            }
            if (serverNode.Children.Count > 0)
            {
                serverNode.IsChecked = serverNode.Children.All(x => x.IsChecked);
                FilteredExcludedNodes.Add(serverNode);
            }
        }
    }

    private static bool Matches(string value, string filter) =>
        string.IsNullOrWhiteSpace(filter) || value.Contains(filter, StringComparison.OrdinalIgnoreCase);

    private void ReviewClick(object sender, RoutedEventArgs e)
    {
        var selected = Targets.Where(t => t.IsSelected).ToList();
        var text = $"MODO: {(DryRunBox.IsChecked == true ? "SIMULACIÓN (sin cambios)" : "DESPLIEGUE REAL")}\n\n" +
                   $"DESTINOS ({selected.Count}):\n" + string.Join("\n", selected.Select(t => $" • {t.Server.Name} / {t.Database} — excluidos: {t.Principals.Count(p => p.IsExcluded)}")) +
                   $"\n\nPATRONES ACTIVOS: {Patterns.Count(p => p.IsActive)}\n" +
                   "PROTECCIÓN AUTOMÁTICA: sysadmin, db_owner y owner siempre quedan excluidos.";
        MessageBox.Show(text, "Revisión previa", MessageBoxButton.OK, MessageBoxImage.Information);
    }

    private async void ExecuteClick(object sender, RoutedEventArgs e)
    {
        if (!RequireExecutionRole()) return;
        var selected = Targets.Where(t => t.IsSelected).ToList();
        if (selected.Count == 0) { MessageBox.Show("Selecciona al menos una base."); return; }
        var dry = DryRunBox.IsChecked == true;
        if (MessageBox.Show($"Se ejecutará {(dry ? "una simulación" : "el despliegue REAL")} en {selected.Count} base(s). ¿Continuar?",
            "Confirmar ejecución", MessageBoxButton.YesNo, dry ? MessageBoxImage.Question : MessageBoxImage.Warning) != MessageBoxResult.Yes) return;
        ExecuteButton.IsEnabled = false; ExecutionRows.Clear(); LogBox.Clear();
        foreach (var t in selected) ExecutionRows.Add(new() { Server = t.Server.Name, Database = t.Database });
        var executionId = await _db.BeginExecutionAsync(dry ? "Simulation" : "Deploy", selected);
        var failures = 0;
        await Parallel.ForEachAsync(selected, new ParallelOptions { MaxDegreeOfParallelism = 4 }, async (target, _) =>
        {
            var row = ExecutionRows.First(r => r.Server == target.Server.Name && r.Database == target.Database);
            try
            {
                var detail = dry ? await _deployment.SimulateAsync(target, Patterns.Where(p => p.IsActive).ToList(), Exceptions.ToList())
                                 : await DeployAndReturnAsync(executionId, target);
                await Dispatcher.InvokeAsync(() => { row.Status = "OK"; row.Detail = detail; ExecutionGrid.Items.Refresh(); });
                await _db.UpdateTargetAsync(executionId, target, "OK", detail);
                if (!dry)
                    await _db.AuditAsync("Ofuscamiento", "Destino desplegado", true,
                        $"ExecutionId={executionId}", target.Server.Name, target.Database);
            }
            catch (Exception ex)
            {
                Interlocked.Increment(ref failures);
                await Dispatcher.InvokeAsync(() => { row.Status = "Error"; row.Detail = ex.Message; ExecutionGrid.Items.Refresh(); LogBox.AppendText(ex.Message + "\n"); });
                await _db.UpdateTargetAsync(executionId, target, "Error", ex.ToString());
            }
        });
        var status = failures == 0 ? "Completed" : failures == selected.Count ? "Failed" : "Partial";
        await _db.FinishExecutionAsync(executionId, status, $"{selected.Count - failures} OK; {failures} error(es)");
        await _db.AuditAsync("Ofuscamiento", dry ? "Simular" : "Desplegar", failures == 0, $"ExecutionId={executionId}; {failures} errores");
        ExecuteButton.IsEnabled = true;
        MessageBox.Show($"Ejecución finalizada. {selected.Count - failures} correctas, {failures} con error.", "Finalizado");
        if (!dry && failures == 0) ClearLoadedMaskingConfiguration();
    }

    private void ClearLoadedMaskingConfiguration()
    {
        Targets.Clear();
        ServerNodes.Clear();
        ExcludedNodes.Clear();
        FilteredServerNodes.Clear();
        FilteredExcludedNodes.Clear();
        TargetFilterBox.Clear();
        ExcludedUserFilterBox.Clear();
    }

    private async Task<string> DeployAndReturnAsync(Guid id, DatabaseTarget target)
    {
        await _deployment.DeployAsync(id, target, Patterns.Where(p => p.IsActive).ToList(), Exceptions.ToList());
        return "Despliegue completado";
    }

    private async void AddServerClick(object sender, RoutedEventArgs e)
    {
        if (!RequireAdministrator()) return;
        var dialog = new ServerDialog(new ServerProfile { Name = "Nuevo servidor", Host = "localhost", Encrypt = true }) { Owner = this };
        if (dialog.ShowDialog() != true) return;
        try
        {
            var item = dialog.Server;
            if (!item.UseWindowsAuth && !string.IsNullOrEmpty(item.PlainPassword)) item.EncryptedPassword = SecurityService.Protect(item.PlainPassword);
            await _db.SaveServerAsync(item);
            Servers = await _db.LoadServersAsync(); ConfigureServersView();
            await _db.AuditAsync("Servidores", "Agregar", true, item.Name);
        }
        catch (Exception ex) { ShowError(ex); }
    }

    private async void EditServerClick(object sender, RoutedEventArgs e)
    {
        if (!RequireAdministrator()) return;
        if (ServersGrid.SelectedItem is not ServerProfile server) { MessageBox.Show("Selecciona un servidor."); return; }
        var dialog = new ServerDialog(server) { Owner = this };
        if (dialog.ShowDialog() != true) return;
        try { await SaveServerProfileAsync(dialog.Server, "Editar"); }
        catch (Exception ex) { ShowError(ex); }
    }

    private async void SaveServerClick(object sender, RoutedEventArgs e)
    {
        if (!RequireAdministrator()) return;
        if (ServersGrid.SelectedItem is not ServerProfile server) return;
        try
        {
            if (!server.UseWindowsAuth)
            {
                var dialog = new PasswordDialog { Owner = this };
                if (dialog.ShowDialog() == true && !string.IsNullOrEmpty(dialog.Password)) server.EncryptedPassword = SecurityService.Protect(dialog.Password);
            }
            await SaveServerProfileAsync(server, "Guardar");
        }
        catch (Exception ex) { ShowError(ex); }
    }

    private async Task SaveServerProfileAsync(ServerProfile server, string action)
    {
        if (!server.UseWindowsAuth && !string.IsNullOrEmpty(server.PlainPassword)) server.EncryptedPassword = SecurityService.Protect(server.PlainPassword);
        await _db.SaveServerAsync(server); Servers = await _db.LoadServersAsync(); ConfigureServersView();
        await _db.AuditAsync("Servidores", action, true, server.Name);
    }

    private async void TestServerClick(object sender, RoutedEventArgs e)
    {
        if (!RequireAdministrator()) return;
        if (ServersGrid.SelectedItem is not ServerProfile server) return;
        try { await using var cn = new SqlConnection(_db.TargetConnection(server)); await cn.OpenAsync(); MessageBox.Show("Conexión exitosa."); }
        catch (Exception ex) { ShowError(ex); }
    }

    private async void DeleteServerClick(object sender, RoutedEventArgs e)
    {
        if (!RequireAdministrator()) return;
        if (ServersGrid.SelectedItem is not ServerProfile server) return;
        if (server.Id > 0) await _db.DeleteServerAsync(server.Id);
        Servers.Remove(server);
        _serversView?.Refresh();
        UpdateServersCount();
    }

    private void ConfigureServersView()
    {
        _serversView = CollectionViewSource.GetDefaultView(Servers);
        _serversView.Filter = FilterServer;
        ServersGrid.ItemsSource = _serversView;
        UpdateServersCount();
    }

    private bool FilterServer(object item)
    {
        if (item is not ServerProfile server) return false;
        var filter = ServerFilterBox?.Text?.Trim();
        return string.IsNullOrWhiteSpace(filter)
            || server.Name.Contains(filter, StringComparison.OrdinalIgnoreCase)
            || server.Host.Contains(filter, StringComparison.OrdinalIgnoreCase)
            || server.Instance.Contains(filter, StringComparison.OrdinalIgnoreCase)
            || server.SqlUser.Contains(filter, StringComparison.OrdinalIgnoreCase);
    }

    private void ServerFilterChanged(object sender, TextChangedEventArgs e)
    {
        _serversView?.Refresh();
        UpdateServersCount();
    }

    private void UpdateServersCount()
    {
        if (ServersCountText is null) return;
        var visible = _serversView?.Cast<object>().Count() ?? Servers.Count;
        ServersCountText.Text = $"{visible} de {Servers.Count} servidores";
        UpdateDashboardSummary();
    }

    private void AddPatternClick(object sender, RoutedEventArgs e)
    {
        if (!RequireAdministrator()) return;
        PatternFilterBox.Text = "";
        Patterns.Add(new() { Pattern = "%NUEVO%", Priority = "Medio" });
        _patternsView?.Refresh();
        UpdatePatternsCount();
        PatternsGrid.SelectedItem = Patterns.Last();
        PatternsGrid.ScrollIntoView(Patterns.Last());
    }
    private void DeletePatternClick(object sender, RoutedEventArgs e)
    {
        if (!RequireAdministrator()) return;
        if (PatternsGrid.SelectedItem is MaskPattern pattern)
        {
            Patterns.Remove(pattern);
            _patternsView?.Refresh();
            UpdatePatternsCount();
        }
        else MessageBox.Show("Selecciona una regla para eliminar.");
    }
    private async void SavePatternsClick(object sender, RoutedEventArgs e)
    {
        if (!RequireAdministrator()) return;
        await _db.SavePatternsAsync(Patterns); await _db.AuditAsync("Reglas", "Guardar", true, $"{Patterns.Count} reglas"); UpdatePatternsCount(); MessageBox.Show("Reglas guardadas.");
    }

    private void ConfigurePatternsView()
    {
        _patternsView = CollectionViewSource.GetDefaultView(Patterns);
        _patternsView.Filter = FilterPattern;
        PatternsGrid.ItemsSource = _patternsView;
        UpdatePatternsCount();
    }

    private bool FilterPattern(object item)
    {
        if (item is not MaskPattern pattern) return false;
        var filter = PatternFilterBox?.Text?.Trim();
        return string.IsNullOrWhiteSpace(filter)
            || pattern.Pattern.Contains(filter, StringComparison.OrdinalIgnoreCase)
            || pattern.DdmFunction.Contains(filter, StringComparison.OrdinalIgnoreCase)
            || (pattern.ViewMaskExpr?.Contains(filter, StringComparison.OrdinalIgnoreCase) ?? false)
            || pattern.Priority.Contains(filter, StringComparison.OrdinalIgnoreCase);
    }

    private void PatternFilterChanged(object sender, TextChangedEventArgs e)
    {
        _patternsView?.Refresh();
        UpdatePatternsCount();
    }

    private void UpdatePatternsCount()
    {
        if (PatternsCountText is null) return;
        var visible = _patternsView?.Cast<object>().Count() ?? Patterns.Count;
        var active = Patterns.Count(x => x.IsActive);
        PatternsCountText.Text = $"{visible} de {Patterns.Count} · {active} activas";
        UpdateDashboardSummary();
    }

    private void ConfigureExceptionsView()
    {
        _exceptionsView = CollectionViewSource.GetDefaultView(Exceptions);
        _exceptionsView.Filter = FilterException;
        ExceptionsGrid.ItemsSource = _exceptionsView;
        UpdateExceptionsCount();
    }

    private bool FilterException(object item)
    {
        if (item is not MaskException exception) return false;
        var filter = ExceptionFilterBox?.Text?.Trim();
        return string.IsNullOrWhiteSpace(filter)
            || exception.ServerName.Contains(filter, StringComparison.OrdinalIgnoreCase)
            || exception.DatabaseName.Contains(filter, StringComparison.OrdinalIgnoreCase)
            || exception.ObjectDisplay.Contains(filter, StringComparison.OrdinalIgnoreCase)
            || exception.ActionDisplay.Contains(filter, StringComparison.OrdinalIgnoreCase)
            || exception.Notes.Contains(filter, StringComparison.OrdinalIgnoreCase);
    }

    private void ExceptionFilterChanged(object sender, TextChangedEventArgs e)
    {
        _exceptionsView?.Refresh();
        UpdateExceptionsCount();
    }

    private void UpdateExceptionsCount()
    {
        if (ExceptionsCountText is null) return;
        var visible = _exceptionsView?.Cast<object>().Count() ?? Exceptions.Count;
        ExceptionsCountText.Text = $"{visible} de {Exceptions.Count} excepciones";
    }

    private void AddExceptionClick(object sender, RoutedEventArgs e)
    {
        if (!RequireAdministrator()) return;
        var dialog = new MaskExceptionDialog(_db, Servers) { Owner = this };
        if (dialog.ShowDialog() != true || dialog.Results.Count == 0) return;
        var added = 0;
        foreach (var item in dialog.Results)
        {
            var duplicate = Exceptions.Any(x => x.ServerName.Equals(item.ServerName, StringComparison.OrdinalIgnoreCase)
                && x.DatabaseName.Equals(item.DatabaseName, StringComparison.OrdinalIgnoreCase)
                && x.SchemaName.Equals(item.SchemaName, StringComparison.OrdinalIgnoreCase)
                && x.TableName.Equals(item.TableName, StringComparison.OrdinalIgnoreCase)
                && string.Equals(x.ColumnName, item.ColumnName, StringComparison.OrdinalIgnoreCase)
                && x.ActionName.Equals(item.ActionName, StringComparison.OrdinalIgnoreCase));
            if (duplicate) continue;
            Exceptions.Add(item);
            added++;
        }
        _exceptionsView?.Refresh();
        UpdateExceptionsCount();
        if (added == 0) MessageBox.Show("Todas las excepciones seleccionadas ya estaban registradas.");
        else if (added < dialog.Results.Count)
            MessageBox.Show($"Se agregaron {added} excepciones; {dialog.Results.Count - added} ya existían.");
    }

    private void DeleteExceptionClick(object sender, RoutedEventArgs e)
    {
        if (!RequireAdministrator()) return;
        if (ExceptionsGrid.SelectedItem is not MaskException item)
        { MessageBox.Show("Selecciona una excepción para eliminar."); return; }
        Exceptions.Remove(item);
        _exceptionsView?.Refresh();
        UpdateExceptionsCount();
    }

    private async void SaveExceptionsClick(object sender, RoutedEventArgs e)
    {
        if (!RequireAdministrator()) return;
        try
        {
            await _db.SaveMaskExceptionsAsync(Exceptions);
            Exceptions = await _db.LoadMaskExceptionsAsync();
            ConfigureExceptionsView();
            await _db.AuditAsync("Excepciones", "Guardar", true, $"{Exceptions.Count} decisiones explícitas");
            MessageBox.Show("Excepciones guardadas. Se aplicarán en los próximos despliegues.");
        }
        catch (Exception ex)
        {
            await _db.AuditAsync("Excepciones", "Guardar", false, ex.Message);
            ShowError(ex);
        }
    }

    private async void LoadUsersClick(object sender, RoutedEventArgs e)
    {
        if (!RequireAdministrator()) return;
        try { Users = await _db.LoadUsersAsync(); ConfigureAuthorizedUsersView(); }
        catch (Exception ex) { ShowError(ex); }
    }

    private async void AddUserClick(object sender, RoutedEventArgs e)
    {
        if (!RequireAdministrator()) return;
        try
        {
            var existing = Users.Select(u => u.Principal).ToHashSet(StringComparer.OrdinalIgnoreCase);
            var dialog = new AddAuthorizedUsersDialog(_db, existing) { Owner = this };
            if (dialog.ShowDialog() != true) return;
            foreach (var option in dialog.SelectedUsers)
                Users.Add(new() { Principal = option.Login, PrincipalType = option.LoginType, Role = option.Role, IsActive = !option.IsDisabled, Notes = option.Notes });
            _authorizedUsersView?.Refresh();
            UpdateAuthorizedUsersCount();
            await _db.AuditAsync("Usuarios autorizados", "Agregar", true, $"{dialog.SelectedUsers.Count} usuarios");
        }
        catch (Exception ex) { ShowError(ex); }
    }
    private async void SaveUsersClick(object sender, RoutedEventArgs e)
    {
        if (!RequireAdministrator()) return;
        if (!Users.Any(u => u.Principal.Equals(_db.Context.Principal, StringComparison.OrdinalIgnoreCase) && u.IsActive))
        { MessageBox.Show("No puedes desactivar o eliminar tu propia identidad."); return; }
        await _db.SaveUsersAsync(Users); await _db.AuditAsync("Usuarios autorizados", "Guardar", true, $"{Users.Count} usuarios"); UpdateAuthorizedUsersCount();
        MessageBox.Show("Usuarios guardados. Los cambios de rol se aplicarán en el próximo inicio de sesión.");
    }

    private void ConfigureAuthorizedUsersView()
    {
        _authorizedUsersView = CollectionViewSource.GetDefaultView(Users);
        _authorizedUsersView.Filter = FilterAuthorizedUser;
        UsersGrid.ItemsSource = _authorizedUsersView;
        UpdateAuthorizedUsersCount();
    }

    private bool FilterAuthorizedUser(object item)
    {
        if (item is not AuthorizedUser user) return false;
        var filter = AuthorizedUserFilterBox?.Text?.Trim();
        return string.IsNullOrWhiteSpace(filter)
            || user.Principal.Contains(filter, StringComparison.OrdinalIgnoreCase)
            || user.PrincipalType.Contains(filter, StringComparison.OrdinalIgnoreCase)
            || user.Role.Contains(filter, StringComparison.OrdinalIgnoreCase);
    }

    private void AuthorizedUserFilterChanged(object sender, TextChangedEventArgs e)
    {
        _authorizedUsersView?.Refresh();
        UpdateAuthorizedUsersCount();
    }

    private void UpdateAuthorizedUsersCount()
    {
        if (AuthorizedUsersCountText is null) return;
        var visible = _authorizedUsersView?.Cast<object>().Count() ?? Users.Count;
        AuthorizedUsersCountText.Text = $"{visible} de {Users.Count} usuarios";
        UpdateDashboardSummary();
    }

    private void UpdateDashboardSummary()
    {
        if (DashboardServersCount is null) return;
        DashboardServersCount.Text = Servers.Count.ToString();
        DashboardPatternsCount.Text = Patterns.Count(x => x.IsActive).ToString();
        DashboardUsersCount.Text = Users.Count(x => x.IsActive).ToString();
    }

    private async Task LoadRollbackAsync()
    {
        RollbackGrid.ItemsSource = (await _db.LoadDeploymentsAsync()).DefaultView;
        RollbackTargetsGrid.ItemsSource = null;
        RollbackStatusText.Text = "Selecciona un despliegue para ver sus destinos.";
    }
    private async void LoadRollbackClick(object sender, RoutedEventArgs e) => await LoadRollbackAsync();
    private async void RollbackSelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (_rollbackInProgress) return;
        if (RollbackGrid.SelectedItem is not DataRowView row)
        {
            RollbackTargetsGrid.ItemsSource = null;
            RollbackStatusText.Text = "Selecciona un despliegue para ver sus destinos.";
            return;
        }

        try
        {
            RollbackStatusText.Text = "Cargando destinos...";
            var id = (Guid)row["ExecutionId"];
            var rows = await _db.LoadExecutionTargetsAsync(id);
            RollbackTargetsGrid.ItemsSource = rows
                .Select(x => new RollbackTargetRow { Server = x.Server, Database = x.Database })
                .ToList();
            RollbackStatusText.Text = $"{rows.Count} destino(s) disponibles.";
        }
        catch (Exception ex)
        {
            RollbackTargetsGrid.ItemsSource = null;
            RollbackStatusText.Text = "No fue posible cargar los destinos.";
            ShowError(ex);
        }
    }

    private void ClearRollbackSelectionClick(object sender, RoutedEventArgs e)
    {
        if (_rollbackInProgress) return;
        var targets = (RollbackTargetsGrid.ItemsSource as IEnumerable<RollbackTargetRow>)?.ToList() ?? [];
        foreach (var target in targets) target.IsSelected = false;
        RollbackTargetsGrid.Items.Refresh();
        RollbackStatusText.Text = targets.Count == 0
            ? "Selecciona un despliegue para ver sus destinos."
            : $"0 de {targets.Count} destinos seleccionados.";
    }

    private async void RollbackClick(object sender, RoutedEventArgs e)
    {
        if (!RequireExecutionRole()) return;
        if (_rollbackInProgress) return;
        _rollbackInProgress = true;
        RollbackExecuteButton.IsEnabled = false;
        RollbackRefreshButton.IsEnabled = false;
        RollbackGrid.IsEnabled = false;
        RollbackTargetsGrid.IsEnabled = false;
        try
        {
            if (RollbackGrid.SelectedItem is not DataRowView row)
            {
                MessageBox.Show("Selecciona un despliegue.", "Rollback", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            var targets = (RollbackTargetsGrid.ItemsSource as IEnumerable<RollbackTargetRow>)?
                .Where(x => x.IsSelected).ToList() ?? [];
            if (targets.Count == 0)
            {
                MessageBox.Show("Selecciona al menos una base para revertir.", "Rollback", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            if (MessageBox.Show(
                    $"Se revertirán {targets.Count} base(s) del despliegue seleccionado. Esta operación modificará permisos y objetos. ¿Continuar?",
                    "Confirmar rollback", MessageBoxButton.YesNo, MessageBoxImage.Warning) != MessageBoxResult.Yes)
            {
                RollbackStatusText.Text = "Rollback cancelado por el usuario.";
                return;
            }

            var id = (Guid)row["ExecutionId"];
            var serverList = await _db.LoadServersAsync();
            var failures = 0;
            foreach (var target in targets)
            {
                target.Status = "Procesando...";
                RollbackStatusText.Text = $"Revirtiendo {target.Server}/{target.Database}...";
                RollbackTargetsGrid.Items.Refresh();
                var server = serverList.FirstOrDefault(s => s.Name.Equals(target.Server, StringComparison.OrdinalIgnoreCase));
                if (server is null)
                {
                    failures++;
                    target.Status = "Servidor no registrado";
                    RollbackTargetsGrid.Items.Refresh();
                    continue;
                }

                try
                {
                    await _deployment.RollbackAsync(id, new() { Server = server, Database = target.Database });
                    target.Status = "Completado";
                    await _db.AuditAsync("Rollback", "Destino revertido", true,
                        $"SourceExecutionId={id}", target.Server, target.Database);
                }
                catch (Exception ex)
                {
                    failures++;
                    target.Status = "Error";
                    await _db.AuditAsync("Rollback", "Destino revertido", false,
                        $"SourceExecutionId={id}; {ex.Message}", target.Server, target.Database);
                    ShowError(ex);
                }
                RollbackTargetsGrid.Items.Refresh();
            }

            var success = targets.Count - failures;
            RollbackStatusText.Text = $"Finalizado: {success} correcto(s), {failures} con error.";
            await _db.AuditAsync("Rollback", "Ejecutar", failures == 0,
                $"SourceExecutionId={id}; {success} correctos; {failures} errores");
            MessageBox.Show(
                $"Rollback finalizado. {success} correcto(s), {failures} con error. Revisa auditoría y resultados.",
                "Rollback finalizado", MessageBoxButton.OK,
                failures == 0 ? MessageBoxImage.Information : MessageBoxImage.Warning);
        }
        finally
        {
            RollbackTargetsGrid.IsEnabled = true;
            RollbackGrid.IsEnabled = true;
            RollbackRefreshButton.IsEnabled = true;
            RollbackExecuteButton.IsEnabled = true;
            _rollbackInProgress = false;
        }
    }

    private async Task LoadAuditAsync()
    {
        _auditTable = await _db.LoadAuditAsync();
        _auditView = new ListCollectionView(_auditTable.DefaultView.Cast<object>().ToList());
        _auditView.Filter = FilterAudit;
        AuditGrid.ItemsSource = _auditView;
        UpdateAuditCount();
    }

    private bool FilterAudit(object item)
    {
        if (item is not DataRowView row) return false;
        var filter = AuditFilterBox?.Text?.Trim();
        if (string.IsNullOrWhiteSpace(filter)) return true;
        var table = row.DataView?.Table;
        if (table is null) return false;

        foreach (var columnName in new[]
                 {
                     "EventAt", "Principal", "FormName", "ActionName", "ServerName", "DatabaseName", "Detail"
                 })
        {
            if (!table.Columns.Contains(columnName) || row[columnName] == DBNull.Value) continue;
            if ((Convert.ToString(row[columnName]) ?? "").Contains(filter, StringComparison.OrdinalIgnoreCase))
                return true;
        }

        if (table.Columns.Contains("Success") && row["Success"] != DBNull.Value)
        {
            var successText = Convert.ToBoolean(row["Success"])
                ? "correcto exitoso éxito si"
                : "error fallido fallo no";
            if (successText.Contains(filter, StringComparison.OrdinalIgnoreCase)) return true;
        }

        return false;
    }

    private void AuditFilterChanged(object sender, TextChangedEventArgs e)
    {
        _auditView?.Refresh();
        UpdateAuditCount();
    }

    private void ClearAuditFilterClick(object sender, RoutedEventArgs e) => AuditFilterBox.Clear();

    private void UpdateAuditCount()
    {
        if (AuditCountText is null) return;
        var total = _auditTable?.Rows.Count ?? 0;
        var visible = _auditView?.Cast<object>().Count() ?? total;
        AuditCountText.Text = $"{visible} de {total} eventos";
    }

    private async void LoadAuditClick(object sender, RoutedEventArgs e)
    {
        try { await LoadAuditAsync(); }
        catch (Exception ex) { ShowError(ex); }
    }

    private async Task LoadInventoryAsync()
    {
        if (!CanViewInventory) return;
        var progress = new ProgressDialog("Actualizar inventario de ofuscamiento") { Owner = this };
        IsEnabled = false;
        progress.Show();
        InventoryRows.Clear();
        InventoryNodes.Clear();
        try
        {
            var rolledBack = await _db.LoadRolledBackTargetsAsync();
            var destinations = new List<(ServerProfile Server, string Database)>();
            var active = Servers.Where(x => x.IsActive).ToList();
            for (var i = 0; i < active.Count; i++)
            {
                progress.UpdateProgress(i, Math.Max(1, active.Count), $"Consultando bases de {active[i].Name}...");
                try
                {
                    foreach (var database in await _db.LoadDatabasesAsync(active[i]))
                        destinations.Add((active[i], database));
                }
                catch (Exception ex)
                {
                    InventoryRows.Add(new MaskingInventoryRow
                    {
                        Server = active[i].Name, State = "Error de conexión", MaskingRule = ex.Message
                    });
                }
            }

            for (var i = 0; i < destinations.Count; i++)
            {
                var destination = destinations[i];
                progress.UpdateProgress(i, Math.Max(1, destinations.Count),
                    $"Inspeccionando {destination.Server.Name}/{destination.Database}...");
                try
                {
                    var rows = await _db.LoadMaskingInventoryAsync(destination.Server, destination.Database);
                    if (rows.Count == 0)
                        InventoryRows.Add(new MaskingInventoryRow
                        {
                            Server = destination.Server.Name,
                            Database = destination.Database,
                            State = rolledBack.Contains($"{destination.Server.Name}|{destination.Database}")
                                ? "Rollback aplicado" : "Sin ofuscamiento",
                            ProtectionType = "Sin objetos activos"
                        });
                    else
                        foreach (var row in rows) InventoryRows.Add(row);
                }
                catch (Exception ex)
                {
                    InventoryRows.Add(new MaskingInventoryRow
                    {
                        Server = destination.Server.Name, Database = destination.Database,
                        State = "Error", MaskingRule = ex.Message
                    });
                }
            }

            ConfigureInventoryView();
            progress.UpdateProgress(1, 1, "Inventario actualizado.");
            await _db.AuditAsync("Estado de ofuscamiento", "Actualizar", true,
                $"{destinations.Count} bases inspeccionadas");
        }
        catch (Exception ex)
        {
            await _db.AuditAsync("Estado de ofuscamiento", "Actualizar", false, ex.Message);
            throw;
        }
        finally
        {
            progress.Close();
            IsEnabled = true;
        }
    }

    private void ConfigureInventoryView()
    {
        _inventoryScope = null;
        _inventoryView = CollectionViewSource.GetDefaultView(InventoryRows);
        _inventoryView.Filter = FilterInventory;
        InventoryGrid.ItemsSource = _inventoryView;
        UpdateInventoryScopeText();
        RebuildInventoryTree();
        UpdateInventoryCount();
    }

    private bool FilterInventory(object item)
    {
        if (item is not MaskingInventoryRow row) return false;
        return MatchesInventoryText(row) && MatchesInventoryScope(row);
    }

    private bool MatchesInventoryText(MaskingInventoryRow row)
    {
        var filter = InventoryFilterBox?.Text?.Trim();
        if (string.IsNullOrWhiteSpace(filter)) return true;
        return new[] { row.Server, row.Database, row.Schema, row.Table, row.Column,
                row.ProtectionType, row.MaskingRule, row.State }
            .Any(x => x.Contains(filter, StringComparison.OrdinalIgnoreCase));
    }

    private bool MatchesInventoryScope(MaskingInventoryRow row)
    {
        if (_inventoryScope is null) return true;
        if (!EqualsIgnoreCase(row.Server, _inventoryScope.Server)) return false;
        if (!string.IsNullOrWhiteSpace(_inventoryScope.Database)
            && !EqualsIgnoreCase(row.Database, _inventoryScope.Database)) return false;
        if (!string.IsNullOrWhiteSpace(_inventoryScope.Schema)
            && !EqualsIgnoreCase(row.Schema, _inventoryScope.Schema)) return false;
        if (!string.IsNullOrWhiteSpace(_inventoryScope.Table)
            && !EqualsIgnoreCase(row.Table, _inventoryScope.Table)) return false;
        return string.IsNullOrWhiteSpace(_inventoryScope.Column)
               || EqualsIgnoreCase(row.Column, _inventoryScope.Column);
    }

    private static bool EqualsIgnoreCase(string left, string right) =>
        string.Equals(left, right, StringComparison.OrdinalIgnoreCase);

    private void InventoryFilterChanged(object sender, TextChangedEventArgs e)
    {
        _inventoryScope = null;
        UpdateInventoryScopeText();
        RebuildInventoryTree();
        _inventoryView?.Refresh();
        UpdateInventoryCount();
    }

    private void ClearInventoryFilterClick(object sender, RoutedEventArgs e) => InventoryFilterBox.Clear();

    private void RebuildInventoryTree()
    {
        _rebuildingInventoryTree = true;
        try
        {
            InventoryNodes.Clear();
            var visible = InventoryRows.Where(MatchesInventoryText).ToList();
            foreach (var serverGroup in visible.GroupBy(x => x.Server).OrderBy(x => x.Key))
            {
                var serverNode = new MaskingInventoryTreeNode
                {
                    DisplayName = serverGroup.Key, Kind = "Servidor",
                    Server = serverGroup.Key, State = AggregateInventoryState(serverGroup)
                };
                foreach (var databaseGroup in serverGroup.GroupBy(x => x.Database).OrderBy(x => x.Key))
                {
                    var databaseNode = new MaskingInventoryTreeNode
                    {
                        DisplayName = string.IsNullOrWhiteSpace(databaseGroup.Key) ? "No disponible" : databaseGroup.Key,
                        Kind = "Base", Server = serverGroup.Key, Database = databaseGroup.Key,
                        State = AggregateInventoryState(databaseGroup)
                    };
                    foreach (var tableGroup in databaseGroup.Where(x => !string.IsNullOrWhiteSpace(x.Table))
                                 .GroupBy(x => new { x.Schema, x.Table }).OrderBy(x => $"{x.Key.Schema}.{x.Key.Table}"))
                    {
                        var tableNode = new MaskingInventoryTreeNode
                        {
                            DisplayName = $"{tableGroup.Key.Schema}.{tableGroup.Key.Table}", Kind = "Tabla",
                            Server = serverGroup.Key, Database = databaseGroup.Key,
                            Schema = tableGroup.Key.Schema, Table = tableGroup.Key.Table,
                            State = AggregateInventoryState(tableGroup)
                        };
                        foreach (var row in tableGroup.OrderBy(x => x.Column))
                            tableNode.Children.Add(new MaskingInventoryTreeNode
                            {
                                DisplayName = $"{row.Column}  ·  {row.ProtectionType}", Kind = "Columna",
                                Server = row.Server, Database = row.Database, Schema = row.Schema,
                                Table = row.Table, Column = row.Column, State = row.State
                            });
                        databaseNode.Children.Add(tableNode);
                    }
                    serverNode.Children.Add(databaseNode);
                }
                InventoryNodes.Add(serverNode);
            }
        }
        finally { _rebuildingInventoryTree = false; }
    }

    private void InventoryTreeSelectionChanged(object sender, RoutedPropertyChangedEventArgs<object> e)
    {
        if (_rebuildingInventoryTree || e.NewValue is not MaskingInventoryTreeNode node) return;
        _inventoryScope = node;
        _inventoryView?.Refresh();
        UpdateInventoryScopeText();
        UpdateInventoryCount();
    }

    private void ClearInventoryScopeClick(object sender, RoutedEventArgs e)
    {
        _inventoryScope = null;
        RebuildInventoryTree();
        _inventoryView?.Refresh();
        UpdateInventoryScopeText();
        UpdateInventoryCount();
    }

    private void UpdateInventoryScopeText()
    {
        if (InventoryScopeText is null || ClearInventoryScopeButton is null) return;
        InventoryScopeText.Text = _inventoryScope is null
            ? "Mostrando todos los registros que coinciden con la búsqueda."
            : $"Filtrado por {_inventoryScope.Kind.ToLowerInvariant()}: {_inventoryScope.DisplayName}";
        ClearInventoryScopeButton.Visibility = _inventoryScope is null
            ? Visibility.Collapsed : Visibility.Visible;
    }

    private static string AggregateInventoryState(IEnumerable<MaskingInventoryRow> rows)
    {
        var states = rows.Select(x => x.State).Distinct(StringComparer.OrdinalIgnoreCase).ToList();
        if (states.Any(x => x == "Error" || x == "Error de conexión")) return "Con errores";
        if (states.Any(x => x == "Ofuscada")) return "Ofuscado";
        if (states.Any(x => x == "Rollback aplicado")) return "Rollback aplicado";
        return "Sin ofuscamiento";
    }

    private void UpdateInventoryCount()
    {
        if (InventoryCountText is null) return;
        var total = InventoryRows.Count;
        var visibleRows = _inventoryView?.Cast<MaskingInventoryRow>().ToList() ?? InventoryRows.ToList();
        var maskedDatabases = visibleRows.Where(x => x.State == "Ofuscada")
            .Select(x => $"{x.Server}|{x.Database}").Distinct(StringComparer.OrdinalIgnoreCase).Count();
        InventoryCountText.Text = $"{visibleRows.Count} de {total} registros · {maskedDatabases} base(s) ofuscada(s)";
    }

    private async void LoadInventoryClick(object sender, RoutedEventArgs e)
    {
        try { await LoadInventoryAsync(); }
        catch (Exception ex) { ShowError(ex); }
    }

    private List<MaskingInventoryRow> VisibleInventoryRows() =>
        _inventoryView?.Cast<MaskingInventoryRow>().ToList() ?? InventoryRows.ToList();

    private async void ExportInventoryClick(object sender, RoutedEventArgs e)
    {
        if (!CanViewInventory) return;
        var rows = VisibleInventoryRows();
        if (rows.Count == 0)
        {
            MessageBox.Show("No hay datos visibles para exportar.", "Exportar inventario",
                MessageBoxButton.OK, MessageBoxImage.Information);
            return;
        }

        var format = (sender as Button)?.Tag?.ToString() ?? "CSV";
        var (extension, filter) = format switch
        {
            "XLSX" => ("xlsx", "Libro de Excel (*.xlsx)|*.xlsx"),
            "PDF" => ("pdf", "Documento PDF (*.pdf)|*.pdf"),
            _ => ("csv", "Archivo CSV (*.csv)|*.csv")
        };
        var dialog = new Microsoft.Win32.SaveFileDialog
        {
            Title = $"Exportar inventario a {format}", Filter = filter,
            DefaultExt = extension, AddExtension = true,
            FileName = $"Inventario_Ofuscamiento_{DateTime.Now:yyyyMMdd_HHmmss}.{extension}"
        };
        if (dialog.ShowDialog(this) != true) return;
        try
        {
            if (format == "XLSX") InventoryExportService.ExportXlsx(dialog.FileName, rows);
            else if (format == "PDF") InventoryExportService.ExportPdf(dialog.FileName, rows);
            else InventoryExportService.ExportCsv(dialog.FileName, rows);
            await _db.AuditAsync("Estado de ofuscamiento", $"Exportar {format}", true,
                $"{rows.Count} registros; {dialog.SafeFileName}");
            MessageBox.Show($"Inventario exportado correctamente a {format}.", "Exportación finalizada",
                MessageBoxButton.OK, MessageBoxImage.Information);
        }
        catch (Exception ex)
        {
            await _db.AuditAsync("Estado de ofuscamiento", $"Exportar {format}", false, ex.Message);
            ShowError(ex);
        }
    }
    private static void ShowError(Exception ex) => MessageBox.Show(ex.Message, "Error", MessageBoxButton.OK, MessageBoxImage.Error);
}
