# Suministros de produccion de OfuscadorTool

Estos scripts son ejecutados manualmente por un DBA. La aplicacion no crea ni actualiza los objetos administrativos de `adminDB`.

## Instalacion nueva

1. Cree o respalde la base pivote `adminDB`.
2. Edite el primer administrador en `00_instalacion_adminDB.sql` y ejecutelo.
3. Ejecute `02_permisos_roles.sql`.
4. Asigne cada usuario de base al rol SQL correspondiente y registre el mismo rol logico en `ofuscador.AuthorizedUsers`:
   - `Administrator` / `OfuscadorTool_Administrator`
   - `Operator` / `OfuscadorTool_Operator`
   - `Auditor` / `OfuscadorTool_Auditor`
5. Para administradores que cargaran logins desde la interfaz, edite y ejecute `04_permisos_servidor_pivote.sql`.
6. Ejecute `03_verificacion_instalacion.sql` y corrija cualquier resultado `FALTA`.

## Actualizacion de una instalacion existente

1. Respalde `adminDB`.
2. Ejecute `01_actualizacion_adminDB.sql`.
3. Ejecute `06_catalogo_patrones_base.sql` para completar reglas base faltantes sin sobrescribir personalizaciones.
4. Ejecute nuevamente `02_permisos_roles.sql`.
5. Ejecute `03_verificacion_instalacion.sql`.

La actualizacion no elimina configuracion, servidores, patrones, perfiles, auditoria ni historiales.
El script de permisos retira el acceso amplio del rol heredado `OfuscadorTool_AppRole`; el DBA debe migrar sus miembros a uno de los tres roles actuales.

## Servidores objetivo

Edite y ejecute `05_credencial_servidores_objetivo.sql` en cada servidor registrado. Declare solo las bases que administrara OfuscadorTool. La credencial necesita `db_owner` en esas bases porque el proceso administra DDM, vistas, triggers, sinonimos, esquemas, roles y permisos. No debe ser `sysadmin`.

Las contrasenas de servidores registradas por la aplicacion se almacenan cifradas con DPAPI para el usuario Windows que ejecuta OfuscadorTool.

## Catalogos centrales

- `ofuscador.AuthorizedUsers`: lista blanca y rol logico.
- `ofuscador.Servers`: conexiones registradas y credenciales cifradas.
- `ofuscador.MaskPatterns`: reglas centrales DDM y expresiones para vistas.
- `ofuscador.MaskExceptions`: columnas omitidas y tablas que requieren vista.
- `ofuscador.MaskProfiles`, `MaskProfileColumns`, `MaskProfileUsers`: perfiles especiales.
- `ofuscador.Executions`, `ExecutionTargets`, `PermissionBackup`: despliegues y rollback.
- `ofuscador.Audit`: auditoria funcional del aplicativo.

Las reglas activas se sincronizan durante cada despliegue hacia `dbo.Masked_Patterns` de la base objetivo. Las excepciones se sincronizan hacia `dbo.Masked_Exceptions`.

## Esquemas procesados y excluidos

El ofuscamiento procesa tablas de todos los esquemas funcionales. Siempre se excluyen `sys`, `INFORMATION_SCHEMA`, `ofuscador`, `masked`, `app`, `log`, `logs`, `audit`, `auditoria`, y los objetos internos `Masked_Audit`, `Masked_Patterns` y `Masked_Exceptions`.

Cuando una excepcion exige una vista, `dbo.Tabla` genera `masked.Tabla`; una tabla de otro esquema, por ejemplo `Ventas.Clientes`, genera `masked.Ventas__Clientes`. Esto evita colisiones entre tablas con el mismo nombre.

## Laboratorio

`10_base_ejemplo_ofuscamiento.sql` crea `OfuscadorDemo` con tablas en `dbo` y `Ventas`, columnas calculadas y datos ficticios. Consulte `README_LABORATORIO.md`. No ejecute este archivo en produccion.

`adminDB.sql` es una captura historica y no forma parte de la secuencia de instalacion actual.
