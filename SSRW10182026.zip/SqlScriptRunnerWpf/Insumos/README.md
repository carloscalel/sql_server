# Guía de Operación y Mantenimiento - SqlScriptRunner (Suite DBA v3)

SqlScriptRunner es una plataforma integral en C# (.NET 8) y WPF orientada a la automatización, monitoreo concurrente y persistencia centralizada de scripts T-SQL sobre múltiples servidores de bases de datos SQL Server sin requerir recompilar código.

---

## Resumen de Funcionalidades Enterprise Integradas

### 1. 🤖 Modo CLI / Desatendido (SQL Server Agent y Task Scheduler)
Permite invocar la herramienta directamente desde la línea de comandos o desde un **Job del SQL Server Agent** sin interfaz gráfica:
```cmd
"C:\SqlScriptRunner\SqlScriptRunner.exe" --task HEALTH --silent
```
* **En el SQL Server Agent:** Crear un paso de tipo `Operating system (CmdExec)`.
* **Exit Codes:** Devuelve `0` si todos los servidores se procesaron con éxito, o `1` si ocurrió algún error, permitiendo al SQL Agent alertar o reintentar el paso automáticamente.

---

### 2. ⚡ Test de Conectividad Masivo ("Ping SQL")
* Ubicado en la barra lateral con el botón **`⚡ Probar Conectividad (Ping SQL)`**.
* Realiza una consulta ultrarrápida (`SELECT 1`) en paralelo a todos los servidores del grupo en evaluación (timeout 5s).
* Muestra en el Monitor qué servidores están **ONLINE** (con su latencia exacta en milisegundos) y cuáles están **OFFLINE**.

---

### 3. 📈 Visor Central de adminDB en la UI
* Nueva pestaña **`📈 Visor adminDB`** integrada en la aplicación.
* Permite explorar y consultar en vivo cualquier tabla o vista de `adminDB` (como `dbo.HealthStatus` o `dbo.LogEjecuciones`) seleccionando el límite (`TOP 50`, `TOP 100`, `TOP 500`, `TOP 1000`).
* Evita tener que abrir SSMS solo para verificar los datos recién recolectados.

---

### 4. 🔔 Sistema de Alertas Automáticas (Microsoft Teams y Email SMTP)
* **Microsoft Teams (Incoming Webhook):** Solo necesitas pegar la URL del webhook de tu canal de Teams. No requiere usuarios, cuentas ni contraseñas. El sistema formatea tarjetas adaptativas con distintivos verdes (éxito) o rojos (alerta) con el detalle exacto de cada servidor fallido.
* **Correo Electrónico (SMTP):** Envío de resúmenes en HTML a listas de distribución.
* **Configurable por Proceso:** Cada tarea define en el Gestor Gráfico si envía alertas y si lo hace siempre o **únicamente ante fallas** (`NotificarSoloSiHayError`).

---

### 5. 📥 Exportación de Resúmenes (CSV / Excel)
* Botón **`📥 Exportar CSV`** en el Monitor de Servidores en Vivo.
* Exporta la corrida completa (Servidores, Estado, Duración en ms, Filas recolectadas, Detalle del error o persistencia y Fecha) con codificación UTF-8 con BOM para apertura nativa e instantánea en Microsoft Excel.

---

### 6. 🏷 Variables Dinámicas en Scripts T-SQL
Soporte de tokens automáticos sustituidos en tiempo de ejecución para cada servidor sin modificar el archivo físico `.sql`:
* `$(Servidor)`: Instancia de SQL Server actual.
* `$(FechaActual)`: Fecha en formato `YYYY-MM-DD`.
* `$(HoraActual)`: Hora en formato `HH:mm:ss`.
* `$(FechaHora)`: Marca temporal completa `YYYY-MM-DD HH:mm:ss`.
* `$(MesActual)`, `$(AnioActual)` y variables personalizadas por tarea.
* Botón **`🏷 Variables de Script`** en la cabecera del editor para auditar los tokens detectados en el código activo.

---

### 7. ⚙ Gestor Gráfico de Configuración
Ventana dedicada (**`⚙ Gestor de Tareas y Configuración`**) con 4 pestañas para administrar tareas, grupos de servidores, credenciales SQL con cifrado nativo DPAPI y opciones globales, recargando en caliente en la pantalla principal.
