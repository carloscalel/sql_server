-- ============================================================================
-- SCRIPT DE CONFIGURACIÓN DE LA BASE DE DATOS CENTRAL adminDB
-- Proyecto: SqlScriptRunner (Panel de Control y Motor DBA)
-- ============================================================================

-- 1. Crear la base de datos central adminDB si no existe
IF NOT EXISTS (SELECT name FROM sys.databases WHERE name = N'adminDB')
BEGIN
    CREATE DATABASE [adminDB];
    PRINT 'Base de datos adminDB creada exitosamente.';
END
GO

USE [adminDB];
GO

-- 2. Tabla para recolección de estado de salud (Tarea HEALTH)
IF OBJECT_ID('dbo.HealthStatus', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.HealthStatus (
        Id INT IDENTITY(1,1) PRIMARY KEY,
        Instancia NVARCHAR(128) NOT NULL,
        FechaRevision DATETIME NOT NULL,
        ConexionesActivas INT NULL,
        ServidorOrigen NVARCHAR(128) NULL,
        FechaRegistro DATETIME NOT NULL DEFAULT GETDATE()
    );
    CREATE NONCLUSTERED INDEX IX_HealthStatus_Instancia_Fecha ON dbo.HealthStatus(Instancia, FechaRevision DESC);
    PRINT 'Tabla dbo.HealthStatus creada.';
END
GO

-- 3. Procedimiento Almacenado de Destino para HEALTH (usp_GuardarHealth)
IF OBJECT_ID('dbo.usp_GuardarHealth', 'P') IS NOT NULL
    DROP PROCEDURE dbo.usp_GuardarHealth;
GO

CREATE PROCEDURE dbo.usp_GuardarHealth
    @Instancia NVARCHAR(128),
    @FechaRevision DATETIME,
    @ConexionesActivas INT = NULL,
    @ServidorOrigen NVARCHAR(128) = NULL,
    @FechaEjecucion DATETIME = NULL
AS
BEGIN
    SET NOCOUNT ON;

    INSERT INTO dbo.HealthStatus (
        Instancia,
        FechaRevision,
        ConexionesActivas,
        ServidorOrigen,
        FechaRegistro
    )
    VALUES (
        @Instancia,
        @FechaRevision,
        @ConexionesActivas,
        ISNULL(@ServidorOrigen, @Instancia),
        ISNULL(@FechaEjecucion, GETDATE())
    );
END
GO
PRINT 'Procedimiento dbo.usp_GuardarHealth creado.';
GO

-- 4. Tabla de Auditoría y Logs Centralizados de Ejecución
IF OBJECT_ID('dbo.LogEjecuciones', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.LogEjecuciones (
        Id INT IDENTITY(1,1) PRIMARY KEY,
        Tarea NVARCHAR(100) NOT NULL,
        Servidor NVARCHAR(128) NOT NULL,
        Fecha DATETIME NOT NULL DEFAULT GETDATE(),
        Exitoso BIT NOT NULL,
        DuracionMs BIGINT NOT NULL,
        Detalle NVARCHAR(MAX) NULL
    );
    CREATE NONCLUSTERED INDEX IX_LogEjecuciones_Tarea_Fecha ON dbo.LogEjecuciones(Tarea, Fecha DESC);
    PRINT 'Tabla dbo.LogEjecuciones creada.';
END
GO
