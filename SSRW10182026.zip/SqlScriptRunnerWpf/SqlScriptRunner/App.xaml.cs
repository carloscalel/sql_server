using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using SqlScriptRunner.Models;
using SqlScriptRunner.Services;

namespace SqlScriptRunner
{
    public partial class App : Application
    {
        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern bool AttachConsole(int dwProcessId);
        private const int ATTACH_PARENT_PROCESS = -1;

        protected override async void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);

            string? taskName = ObtenerArgumento(e.Args, "--task", "-t");

            if (!string.IsNullOrWhiteSpace(taskName))
            {
                // Adjuntar salida a la consola llamante (SQL Server Agent CmdExec, CMD o Task Scheduler)
                AttachConsole(ATTACH_PARENT_PROCESS);

                bool silent = e.Args.Any(a => a.Equals("--silent", StringComparison.OrdinalIgnoreCase) || a.Equals("-s", StringComparison.OrdinalIgnoreCase));

                int exitCode = await EjecutarModoCliAsync(taskName, silent);
                Shutdown(exitCode);
                return;
            }

            // Iniciar modo Interfaz Gráfica (WPF) normal
            var mainWindow = new MainWindow();
            mainWindow.Show();
        }

        private static string? ObtenerArgumento(string[] args, params string[] prefijos)
        {
            for (int i = 0; i < args.Length; i++)
            {
                foreach (var pref in prefijos)
                {
                    if (args[i].Equals(pref, StringComparison.OrdinalIgnoreCase) && i + 1 < args.Length)
                    {
                        return args[i + 1].Trim('\"', '\'');
                    }
                    if (args[i].StartsWith(pref + "=", StringComparison.OrdinalIgnoreCase))
                    {
                        return args[i].Substring(pref.Length + 1).Trim('\"', '\'');
                    }
                }
            }
            return null;
        }

        private static async Task<int> EjecutarModoCliAsync(string nombreTarea, bool silent)
        {
            string baseDir = AppDomain.CurrentDomain.BaseDirectory;
            string configPath = Path.Combine(baseDir, "appsettings.json");

            var logger = new LogService(baseDir);
            if (!silent)
            {
                logger.OnLogMessage += msg => Console.WriteLine(msg);
            }

            logger.Registrar($"[CLI] Iniciando ejecución desatendida para la tarea '{nombreTarea}'.");

            if (!File.Exists(configPath))
            {
                logger.Registrar($"[CLI ERROR] Archivo de configuración no encontrado en: {configPath}");
                return 1;
            }

            try
            {
                string json = File.ReadAllText(configPath);
                var opciones = new JsonSerializerOptions
                {
                    PropertyNameCaseInsensitive = true,
                    ReadCommentHandling = JsonCommentHandling.Skip,
                    AllowTrailingCommas = true
                };

                var config = JsonSerializer.Deserialize<AppConfig>(json, opciones) ?? new AppConfig();

                if (!config.Scripts.TryGetValue(nombreTarea, out var scriptConfig))
                {
                    logger.Registrar($"[CLI ERROR] La tarea '{nombreTarea}' no está definida en appsettings.json.");
                    return 1;
                }

                if (!scriptConfig.Habilitado)
                {
                    logger.Registrar($"[CLI AVISO] La tarea '{nombreTarea}' está configurada como deshabilitada (Habilitado=false).");
                    return 0;
                }

                string rutaScript = Path.Combine(baseDir, scriptConfig.Archivo);
                if (!File.Exists(rutaScript))
                {
                    logger.Registrar($"[CLI ERROR] Archivo SQL no encontrado: {rutaScript}");
                    return 1;
                }

                string scriptSql = File.ReadAllText(rutaScript);

                if (!config.GruposServidores.TryGetValue(scriptConfig.GrupoServidores, out var servidores) || servidores.Count == 0)
                {
                    logger.Registrar($"[CLI ERROR] El grupo '{scriptConfig.GrupoServidores}' no existe o no tiene servidores asignados.");
                    return 1;
                }

                var centralDb = new CentralDatabaseService(config, logger);
                var notifService = new NotificationService(config, logger);
                var engine = new ScriptExecutionEngine(config, logger, centralDb, notifService);

                var items = servidores.Select(s => new ServidorProgresoItem
                {
                    Servidor = s,
                    Estado = EstadoServidor.Pendiente,
                    Detalle = "En cola CLI"
                }).ToList();

                logger.IniciarSesion(nombreTarea);
                using var cts = new CancellationTokenSource();

                await engine.EjecutarTareaAsync(
                    nombreTarea,
                    scriptConfig,
                    scriptSql,
                    items,
                    (proc, total) =>
                    {
                        if (!silent)
                        {
                            Console.WriteLine($"[CLI Progreso] {proc}/{total} servidores procesados.");
                        }
                    },
                    cts.Token
                );

                bool huboErrores = items.Any(i => i.Estado == EstadoServidor.Error);
                if (huboErrores)
                {
                    logger.Registrar($"[CLI ALERTA] La tarea '{nombreTarea}' finalizó con errores en uno o más servidores.");
                    return 1; // Exit code 1 para que el SQL Agent marque el paso como Failed si hubo fallas
                }

                logger.Registrar($"[CLI ÉXITO] La tarea '{nombreTarea}' finalizó exitosamente en todos los servidores.");
                return 0; // Exit code 0
            }
            catch (Exception ex)
            {
                logger.Registrar($"[CLI FATAL] Excepción no controlada: {ex.Message}");
                return 1;
            }
        }
    }
}
