using System;
using System.Security.Cryptography;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using SqlScriptRunner.Services;

namespace SqlScriptRunner
{
    public partial class PasswordEncryptorWindow : Window
    {
        public PasswordEncryptorWindow()
        {
            InitializeComponent();
        }

        private void CboMetodoCifrado_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (PanelClaveAes == null)
                return;

            // Índice 2 corresponde a AES-256 (Portátil)
            PanelClaveAes.Visibility = (CboMetodoCifrado.SelectedIndex == 2) 
                ? Visibility.Visible 
                : Visibility.Collapsed;
        }

        private void BtnCargarEnvKey_Click(object sender, RoutedEventArgs e)
        {
            string? envKey = Environment.GetEnvironmentVariable("SQLSCRIPTRUNNER_MASTER_KEY");
            if (!string.IsNullOrWhiteSpace(envKey))
            {
                TxtGenPassphraseAes.Text = envKey;
                ModernMessageBox.Show("Clave maestra cargada exitosamente desde la variable de entorno SQLSCRIPTRUNNER_MASTER_KEY.", "Clave Cargada", MessageBoxButton.OK, MessageBoxImage.Information, this);
            }
            else
            {
                ModernMessageBox.Show("No se encontró definida la variable de entorno SQLSCRIPTRUNNER_MASTER_KEY en este equipo.", "Variable No Encontrada", MessageBoxButton.OK, MessageBoxImage.Warning, this);
            }
        }

        private void BtnGenerarHash_Click(object sender, RoutedEventArgs e)
        {
            string passwordPlano = TxtGenPasswordPlano.Password;
            if (string.IsNullOrEmpty(passwordPlano))
            {
                ModernMessageBox.Show("Por favor ingrese una contraseña en texto plano.", "Campo Requerido", MessageBoxButton.OK, MessageBoxImage.Warning, this);
                return;
            }

            try
            {
                string hashResultado;
                int metodo = CboMetodoCifrado.SelectedIndex;

                if (metodo == 2) // AES-256 Portátil
                {
                    string passClave = TxtGenPassphraseAes.Text.Trim();
                    if (string.IsNullOrWhiteSpace(passClave))
                    {
                        ModernMessageBox.Show("Para el cifrado portátil AES-256 debe especificar una Clave Maestra / Passphrase.", "Clave Requerida", MessageBoxButton.OK, MessageBoxImage.Warning, this);
                        TxtGenPassphraseAes.Focus();
                        return;
                    }

                    hashResultado = SecurityService.EncriptarPasswordAes(passwordPlano, passClave);
                    LblInfoResultado.Text = "Token AES generado. Portable a cualquier servidor configurado con la misma Clave Maestra.";
                }
                else if (metodo == 1) // DPAPI CurrentUser
                {
                    hashResultado = SecurityService.EncriptarPasswordDpapi(passwordPlano, DataProtectionScope.CurrentUser);
                    LblInfoResultado.Text = "Token DPAPI (CurrentUser) generado. Válido exclusivamente para la cuenta de Windows actual.";
                }
                else // DPAPI LocalMachine
                {
                    hashResultado = SecurityService.EncriptarPasswordDpapi(passwordPlano, DataProtectionScope.LocalMachine);
                    LblInfoResultado.Text = "Token DPAPI (LocalMachine) generado. Válido para cualquier servicio o usuario en este servidor físico/virtual.";
                }

                TxtGenHashResultado.Text = hashResultado;
                Clipboard.SetText(hashResultado);
                ModernMessageBox.Show("Hash cifrado generado con éxito y copiado al portapapeles.", "Éxito al Cifrar", MessageBoxButton.OK, MessageBoxImage.Information, this);
            }
            catch (Exception ex)
            {
                ModernMessageBox.Show($"Error al generar cifrado: {ex.Message}", "Error Criptográfico", MessageBoxButton.OK, MessageBoxImage.Error, this);
            }
        }

        private void BtnCopiarResultado_Click(object sender, RoutedEventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(TxtGenHashResultado.Text))
            {
                Clipboard.SetText(TxtGenHashResultado.Text);
                ModernMessageBox.Show("Hash copiado al portapapeles.", "Copiado", MessageBoxButton.OK, MessageBoxImage.Information, this);
            }
        }

        private void BtnProbarDescifrado_Click(object sender, RoutedEventArgs e)
        {
            string hashEntrada = TxtDiagHashEntrada.Text.Trim();
            if (string.IsNullOrWhiteSpace(hashEntrada))
            {
                ModernMessageBox.Show("Por favor pegue el hash cifrado que desea diagnosticar.", "Aviso", MessageBoxButton.OK, MessageBoxImage.Warning, this);
                return;
            }

            string? passManual = string.IsNullOrWhiteSpace(TxtDiagPassphraseAes.Text) ? null : TxtDiagPassphraseAes.Text.Trim();
            var resultado = SecurityService.ProbarDescifrado(hashEntrada, null, passManual);

            BorderResultadoDiag.Visibility = Visibility.Visible;
            LblDiagTipoCifrado.Text = resultado.TipoCifrado;

            if (resultado.Exito)
            {
                LblDiagIcono.Text = "🟢";
                LblDiagTitulo.Text = "Descifrado Exitoso en este Sistema";
                LblDiagTitulo.Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#FF5AF78E"));
                BorderResultadoDiag.BorderBrush = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#FF5AF78E"));
                TxtDiagPasswordDescifrado.Text = resultado.PasswordPlano;
                TxtDiagDetalleError.Visibility = Visibility.Collapsed;
            }
            else
            {
                LblDiagIcono.Text = "🔴";
                LblDiagTitulo.Text = "Incompatible / No Descifrable";
                LblDiagTitulo.Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#FFFF6B68"));
                BorderResultadoDiag.BorderBrush = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#FFFF6B68"));
                TxtDiagPasswordDescifrado.Text = "******** (Inaccesible)";
                TxtDiagDetalleError.Text = $"Causa: {resultado.Error}";
                TxtDiagDetalleError.Visibility = Visibility.Visible;
            }
        }

        private void BtnCopiarDescifrado_Click(object sender, RoutedEventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(TxtDiagPasswordDescifrado.Text) && !TxtDiagPasswordDescifrado.Text.Contains("Inaccesible"))
            {
                Clipboard.SetText(TxtDiagPasswordDescifrado.Text);
                ModernMessageBox.Show("Contraseña descifrada copiada al portapapeles.", "Copiado", MessageBoxButton.OK, MessageBoxImage.Information, this);
            }
        }
    }
}
