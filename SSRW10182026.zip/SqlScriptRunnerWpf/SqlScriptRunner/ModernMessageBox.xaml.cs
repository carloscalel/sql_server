using System.Windows;
using System.Windows.Input;
using System.Windows.Media;

namespace SqlScriptRunner
{
    public partial class ModernMessageBox : Window
    {
        public MessageBoxResult Resultado { get; private set; } = MessageBoxResult.None;

        public ModernMessageBox()
        {
            InitializeComponent();
            KeyDown += ModernMessageBox_KeyDown;
        }

        private void ModernMessageBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Escape)
            {
                Resultado = BtnCancelar.Visibility == Visibility.Visible ? MessageBoxResult.Cancel :
                            (BtnNo.Visibility == Visibility.Visible ? MessageBoxResult.No : MessageBoxResult.OK);
                Close();
            }
            else if (e.Key == Key.Enter)
            {
                Resultado = BtnAceptar.Content.ToString() == "Sí" ? MessageBoxResult.Yes : MessageBoxResult.OK;
                Close();
            }
        }

        public static MessageBoxResult Show(
            string mensaje, 
            string titulo = "Aviso", 
            MessageBoxButton botones = MessageBoxButton.OK, 
            MessageBoxImage icono = MessageBoxImage.Information,
            Window? owner = null)
        {
            var dlg = new ModernMessageBox();
            if (owner != null && owner.IsVisible)
            {
                dlg.Owner = owner;
            }
            else if (Application.Current?.MainWindow != null && Application.Current.MainWindow.IsVisible)
            {
                dlg.Owner = Application.Current.MainWindow;
            }

            dlg.TxtTitulo.Text = titulo;
            dlg.TxtMensaje.Text = mensaje;

            // Configurar Icono y Colores
            switch (icono)
            {
                case MessageBoxImage.Error:
                    dlg.TxtIcono.Text = "❌";
                    dlg.TxtIcono.Foreground = new SolidColorBrush(Color.FromRgb(216, 59, 1));
                    break;
                case MessageBoxImage.Warning:
                    dlg.TxtIcono.Text = "⚠️";
                    dlg.TxtIcono.Foreground = new SolidColorBrush(Color.FromRgb(241, 196, 15));
                    break;
                case MessageBoxImage.Question:
                    dlg.TxtIcono.Text = "❓";
                    dlg.TxtIcono.Foreground = new SolidColorBrush(Color.FromRgb(79, 193, 255));
                    break;
                default:
                    dlg.TxtIcono.Text = "ℹ";
                    dlg.TxtIcono.Foreground = new SolidColorBrush(Color.FromRgb(0, 122, 204));
                    break;
            }

            // Configurar Botones
            switch (botones)
            {
                case MessageBoxButton.OKCancel:
                    dlg.BtnAceptar.Content = "Aceptar";
                    dlg.BtnAceptar.Visibility = Visibility.Visible;
                    dlg.BtnCancelar.Visibility = Visibility.Visible;
                    dlg.BtnNo.Visibility = Visibility.Collapsed;
                    break;
                case MessageBoxButton.YesNo:
                    dlg.BtnAceptar.Content = "Sí";
                    dlg.BtnAceptar.Visibility = Visibility.Visible;
                    dlg.BtnNo.Visibility = Visibility.Visible;
                    dlg.BtnCancelar.Visibility = Visibility.Collapsed;
                    break;
                case MessageBoxButton.YesNoCancel:
                    dlg.BtnAceptar.Content = "Sí";
                    dlg.BtnAceptar.Visibility = Visibility.Visible;
                    dlg.BtnNo.Visibility = Visibility.Visible;
                    dlg.BtnCancelar.Visibility = Visibility.Visible;
                    break;
                default: // OK
                    dlg.BtnAceptar.Content = "Aceptar";
                    dlg.BtnAceptar.Visibility = Visibility.Visible;
                    dlg.BtnNo.Visibility = Visibility.Collapsed;
                    dlg.BtnCancelar.Visibility = Visibility.Collapsed;
                    break;
            }

            dlg.ShowDialog();
            return dlg.Resultado;
        }

        private void Header_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ButtonState == MouseButtonState.Pressed)
            {
                this.DragMove();
            }
        }

        private void BtnAceptar_Click(object sender, RoutedEventArgs e)
        {
            Resultado = BtnAceptar.Content.ToString() == "Sí" ? MessageBoxResult.Yes : MessageBoxResult.OK;
            this.Close();
        }

        private void BtnNo_Click(object sender, RoutedEventArgs e)
        {
            Resultado = MessageBoxResult.No;
            this.Close();
        }

        private void BtnCancelar_Click(object sender, RoutedEventArgs e)
        {
            Resultado = MessageBoxResult.Cancel;
            this.Close();
        }

        private void BtnCerrarX_Click(object sender, RoutedEventArgs e)
        {
            Resultado = MessageBoxResult.Cancel;
            this.Close();
        }
    }
}
