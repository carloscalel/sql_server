using System;
using System.IO;
using System.Windows;
using Microsoft.Win32;
using SqlScriptRunner.Models;
using SqlScriptRunner.Services;

namespace SqlScriptRunner
{
    public enum ModoTransferencia
    {
        Exportar,
        Importar
    }

    public partial class CredentialTransferWindow : Window
    {
        private readonly AppConfig _config;
        private readonly ModoTransferencia _modo;

        public int CredencialesProcesadas { get; private set; }

        public CredentialTransferWindow(AppConfig config, ModoTransferencia modo)
        {
            InitializeComponent();
            _config = config;
            _modo = modo;

            ConfigurarVistaSegunModo();
        }

        private void ConfigurarVistaSegunModo()
        {
            if (_modo == ModoTransferencia.Exportar)
            {
                Title = "Exportar Paquete Seguro de Credenciales";
                LblIconoModal.Text = "📤";
                LblTituloModal.Text = "Exportar Credenciales Portátiles";
                LblSubtituloModal.Text = "Genera un archivo cifrado con AES-256 para transferir credenciales a otro servidor.";
                PanelExportar.Visibility = Visibility.Visible;
                PanelImportar.Visibility = Visibility.Collapsed;
                BtnAccionPrincipal.Content = "Exportar Paquete";

                // Analizar credenciales exportables
                int exportables = 0;
                int incompatibles = 0;
                foreach (var kvp in _config.CredencialesServidores)
                {
                    var (exito, _, _, _) = SecurityService.ProbarDescifrado(kvp.Value.PasswordCifrado, _config);
                    if (exito) exportables++;
                    else incompatibles++;
                }

                LblResumenExportar.Text = $"Se exportarán {exportables} credencial(es) legibles en este equipo.";
                if (incompatibles > 0)
                {
                    LblOmitidosExportar.Text = $"⚠️ Se omitirán {incompatibles} credencial(es) porque actualmente no pueden ser descifradas en este equipo.";
                    LblOmitidosExportar.Visibility = Visibility.Visible;
                }

                TxtExportRutaArchivo.Text = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Desktop), "Credenciales_SqlScriptRunner.credpack");
            }
            else
            {
                Title = "Importar Paquete y Re-cifrar Credenciales";
                LblIconoModal.Text = "📥";
                LblTituloModal.Text = "Importar y Re-cifrar en este Equipo";
                LblSubtituloModal.Text = "Lee un archivo .credpack y re-cifra las contraseñas con el DPAPI de este servidor automáticamente.";
                PanelExportar.Visibility = Visibility.Collapsed;
                PanelImportar.Visibility = Visibility.Visible;
                BtnAccionPrincipal.Content = "Importar Credenciales";
            }
        }

        private void BtnExaminarExportar_Click(object sender, RoutedEventArgs e)
        {
            var sfd = new SaveFileDialog
            {
                Filter = "Paquete de Credenciales (*.credpack)|*.credpack|Todos los archivos (*.*)|*.*",
                FileName = "Credenciales_SqlScriptRunner.credpack",
                Title = "Guardar Paquete de Credenciales"
            };

            if (sfd.ShowDialog(this) == true)
            {
                TxtExportRutaArchivo.Text = sfd.FileName;
            }
        }

        private void BtnExaminarImportar_Click(object sender, RoutedEventArgs e)
        {
            var ofd = new OpenFileDialog
            {
                Filter = "Paquete de Credenciales (*.credpack)|*.credpack|Todos los archivos (*.*)|*.*",
                Title = "Seleccionar Paquete de Credenciales a Importar"
            };

            if (ofd.ShowDialog(this) == true)
            {
                TxtImportRutaArchivo.Text = ofd.FileName;
            }
        }

        private void BtnAccionPrincipal_Click(object sender, RoutedEventArgs e)
        {
            if (_modo == ModoTransferencia.Exportar)
            {
                string pass = TxtExportPassphrase.Password;
                if (string.IsNullOrWhiteSpace(pass) || pass.Length < 4)
                {
                    ModernMessageBox.Show("Por favor defina una contraseña de transferencia temporal de al menos 4 caracteres.", "Contraseña Requerida", MessageBoxButton.OK, MessageBoxImage.Warning, this);
                    TxtExportPassphrase.Focus();
                    return;
                }

                string ruta = TxtExportRutaArchivo.Text.Trim();
                if (string.IsNullOrWhiteSpace(ruta))
                {
                    ModernMessageBox.Show("Por favor seleccione la ruta del archivo de destino.", "Ruta Requerida", MessageBoxButton.OK, MessageBoxImage.Warning, this);
                    return;
                }

                try
                {
                    string paqueteCifrado = SecurityService.ExportarPaqueteCredenciales(_config, pass, out int exportadas, out var omitidos);
                    File.WriteAllText(ruta, paqueteCifrado);

                    CredencialesProcesadas = exportadas;
                    string msg = $"¡Paquete generado con éxito!\n\nCredenciales exportadas: {exportadas}\nArchivo: {ruta}";
                    if (omitidos.Count > 0)
                    {
                        msg += $"\n\nServidores omitidos por no ser descifrables: {string.Join(", ", omitidos)}";
                    }

                    ModernMessageBox.Show(msg, "Exportación Completada", MessageBoxButton.OK, MessageBoxImage.Information, this);
                    DialogResult = true;
                    Close();
                }
                catch (Exception ex)
                {
                    ModernMessageBox.Show($"Error al exportar credenciales: {ex.Message}", "Error al Exportar", MessageBoxButton.OK, MessageBoxImage.Error, this);
                }
            }
            else // Modo Importar
            {
                string ruta = TxtImportRutaArchivo.Text.Trim();
                if (string.IsNullOrWhiteSpace(ruta) || !File.Exists(ruta))
                {
                    ModernMessageBox.Show("Por favor seleccione un archivo .credpack válido que exista en el disco.", "Archivo no encontrado", MessageBoxButton.OK, MessageBoxImage.Warning, this);
                    return;
                }

                string pass = TxtImportPassphrase.Password;
                if (string.IsNullOrWhiteSpace(pass))
                {
                    ModernMessageBox.Show("Por favor ingrese la contraseña de transferencia temporal que se usó al exportar el archivo.", "Contraseña Requerida", MessageBoxButton.OK, MessageBoxImage.Warning, this);
                    TxtImportPassphrase.Focus();
                    return;
                }

                bool cifrarConDpapi = CboImportModoAlmacenamiento.SelectedIndex == 0;

                try
                {
                    string paquete = File.ReadAllText(ruta);
                    int importadas = SecurityService.ImportarPaqueteCredenciales(paquete, pass, _config, cifrarConDpapi);

                    CredencialesProcesadas = importadas;
                    string metodoGuardado = cifrarConDpapi ? "DPAPI del servidor actual" : "AES-256 Portátil";
                    ModernMessageBox.Show($"¡Importación completada con éxito!\n\nSe importaron y protegieron {importadas} credencial(es) usando {metodoGuardado}.\n\nRecuerde hacer clic en 'Guardar Cambios en appsettings.json' para persistirlas.", "Importación Exitosa", MessageBoxButton.OK, MessageBoxImage.Information, this);

                    DialogResult = true;
                    Close();
                }
                catch (Exception ex)
                {
                    ModernMessageBox.Show($"Error al importar el paquete: {ex.Message}\n\nVerifique que la contraseña de transferencia sea la correcta y que el archivo no esté dañado.", "Fallo en la Importación", MessageBoxButton.OK, MessageBoxImage.Error, this);
                }
            }
        }

        private void BtnCancelar_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }
    }
}
