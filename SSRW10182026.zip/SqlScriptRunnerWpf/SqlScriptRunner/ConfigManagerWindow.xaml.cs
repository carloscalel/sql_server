using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using Microsoft.Win32;
using SqlScriptRunner.Models;
using SqlScriptRunner.Services;

namespace SqlScriptRunner
{
    public partial class ConfigManagerWindow : Window
    {
        private readonly string _baseDirectory = AppDomain.CurrentDomain.BaseDirectory;
        private AppConfig _config = new();
        private string? _tareaActualKey;
        private string? _grupoActualKey;
        private string? _credencialActualKey;

        public ConfigManagerWindow()
        {
            InitializeComponent();
            CargarArchivoConfiguracion();
        }

        private void CargarArchivoConfiguracion()
        {
            string configPath = Path.Combine(_baseDirectory, "appsettings.json");
            if (File.Exists(configPath))
            {
                try
                {
                    string json = File.ReadAllText(configPath);
                    var opciones = new JsonSerializerOptions
                    {
                        PropertyNameCaseInsensitive = true,
                        ReadCommentHandling = JsonCommentHandling.Skip,
                        AllowTrailingCommas = true
                    };
                    _config = JsonSerializer.Deserialize<AppConfig>(json, opciones) ?? new AppConfig();
                }
                catch (Exception ex)
                {
                    ModernMessageBox.Show($"Error al leer appsettings.json: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error, this);
                    _config = new AppConfig();
                }
            }

            RefrescarGruposCombo();
            CargarTareasUI();
            CargarGruposUI();
            CargarCredencialesUI();
            CargarOpcionesGlobalesUI();
        }

        private void RefrescarGruposCombo()
        {
            CboGrupoServidores.Items.Clear();
            foreach (var grp in _config.GruposServidores.Keys)
            {
                CboGrupoServidores.Items.Add(grp);
            }
        }

        #region TAREAS (SCRIPTS)
        private void CargarTareasUI()
        {
            LbTareas.Items.Clear();
            foreach (var key in _config.Scripts.Keys)
            {
                LbTareas.Items.Add(key);
            }

            if (LbTareas.Items.Count > 0)
            {
                LbTareas.SelectedIndex = 0;
            }
            else
            {
                PanelDetalleTarea.IsEnabled = false;
                LimpiarFormularioTarea();
            }
        }

        private void GuardarTareaActualEnMemoria()
        {
            if (string.IsNullOrWhiteSpace(_tareaActualKey) || !_config.Scripts.ContainsKey(_tareaActualKey))
                return;

            string nuevoNombre = TxtNombreTarea.Text.Trim();
            if (string.IsNullOrWhiteSpace(nuevoNombre))
                return;

            var script = _config.Scripts[_tareaActualKey];
            script.Habilitado = ChkHabilitado.IsChecked ?? true;
            script.Archivo = TxtArchivoSql.Text.Trim();
            script.GrupoServidores = CboGrupoServidores.SelectedItem?.ToString() ?? "Todos";
            script.Paralelismo = int.TryParse(TxtParalelismo.Text, out int p) ? Math.Max(1, p) : 4;
            script.TimeoutSegundos = int.TryParse(TxtTimeout.Text, out int t) ? Math.Max(1, t) : 60;
            script.ContinuarSiHayError = ChkContinuarSiHayError.IsChecked ?? true;
            script.GuardarResultado = ChkGuardarResultado.IsChecked ?? true;
            script.GuardarErrores = ChkGuardarErrores.IsChecked ?? true;
            script.ProcedimientoDestino = string.IsNullOrWhiteSpace(TxtProcedimientoDestino.Text) ? null : TxtProcedimientoDestino.Text.Trim();
            script.TablaDestino = string.IsNullOrWhiteSpace(TxtTablaDestino.Text) ? null : TxtTablaDestino.Text.Trim();

            script.Notificaciones ??= new NotificacionesConfig();
            script.Notificaciones.Habilitado = ChkNotifHabilitada.IsChecked ?? false;
            script.Notificaciones.NotificarSoloSiHayError = ChkNotifSoloError.IsChecked ?? true;
            script.Notificaciones.WebhookTeams = string.IsNullOrWhiteSpace(TxtNotifTeamsWebhook.Text) ? null : TxtNotifTeamsWebhook.Text.Trim();
            script.Notificaciones.EmailDestinatarios = string.IsNullOrWhiteSpace(TxtNotifEmailDestinatarios.Text) ? null : TxtNotifEmailDestinatarios.Text.Trim();

            // Si cambió de nombre, actualizar llave en el diccionario
            if (!_isRenamingTask && !string.Equals(_tareaActualKey, nuevoNombre, StringComparison.OrdinalIgnoreCase))
            {
                if (!_config.Scripts.ContainsKey(nuevoNombre))
                {
                    _config.Scripts.Remove(_tareaActualKey);
                    _config.Scripts[nuevoNombre] = script;

                    string viejo = _tareaActualKey;
                    _tareaActualKey = nuevoNombre;

                    int idx = LbTareas.Items.IndexOf(viejo);
                    if (idx >= 0)
                    {
                        LbTareas.Items[idx] = nuevoNombre;
                    }
                }
            }
        }

        private bool _isRenamingTask = false;

        private void BtnRenombrarTarea_Click(object sender, RoutedEventArgs e)
        {
            AplicarRenombradoTarea();
        }

        private void TxtNombreTarea_LostFocus(object sender, RoutedEventArgs e)
        {
            AplicarRenombradoTarea();
        }

        private void TxtNombreTarea_KeyDown(object sender, System.Windows.Input.KeyEventArgs e)
        {
            if (e.Key == System.Windows.Input.Key.Enter)
            {
                AplicarRenombradoTarea();
            }
        }

        private void AplicarRenombradoTarea()
        {
            if (_isRenamingTask) return;
            if (string.IsNullOrWhiteSpace(_tareaActualKey) || !_config.Scripts.ContainsKey(_tareaActualKey))
                return;

            string nuevoNombre = TxtNombreTarea.Text.Trim();
            if (string.IsNullOrWhiteSpace(nuevoNombre))
            {
                TxtNombreTarea.Text = _tareaActualKey;
                return;
            }

            if (string.Equals(_tareaActualKey, nuevoNombre, StringComparison.OrdinalIgnoreCase))
                return;

            if (_config.Scripts.ContainsKey(nuevoNombre))
            {
                ModernMessageBox.Show($"Ya existe otra tarea llamada '{nuevoNombre}'.", "Nombre Duplicado", MessageBoxButton.OK, MessageBoxImage.Warning, this);
                TxtNombreTarea.Text = _tareaActualKey;
                return;
            }

            try
            {
                _isRenamingTask = true;
                var script = _config.Scripts[_tareaActualKey];
                _config.Scripts.Remove(_tareaActualKey);
                _config.Scripts[nuevoNombre] = script;

                string viejoNombre = _tareaActualKey;
                _tareaActualKey = nuevoNombre;

                int idx = LbTareas.Items.IndexOf(viejoNombre);
                if (idx >= 0)
                {
                    LbTareas.Items[idx] = nuevoNombre;
                    LbTareas.SelectedIndex = idx;
                }
                else
                {
                    CargarTareasUI();
                    LbTareas.SelectedItem = nuevoNombre;
                }
            }
            finally
            {
                _isRenamingTask = false;
            }
        }

        private void LbTareas_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            GuardarTareaActualEnMemoria();

            if (LbTareas.SelectedItem == null)
            {
                PanelDetalleTarea.IsEnabled = false;
                LimpiarFormularioTarea();
                _tareaActualKey = null;
                return;
            }

            _tareaActualKey = LbTareas.SelectedItem.ToString();
            if (_tareaActualKey != null && _config.Scripts.TryGetValue(_tareaActualKey, out var script))
            {
                PanelDetalleTarea.IsEnabled = true;
                TxtNombreTarea.Text = _tareaActualKey;
                ChkHabilitado.IsChecked = script.Habilitado;
                TxtArchivoSql.Text = script.Archivo;
                CboGrupoServidores.SelectedItem = script.GrupoServidores;
                TxtParalelismo.Text = script.Paralelismo.ToString();
                TxtTimeout.Text = script.TimeoutSegundos.ToString();
                ChkContinuarSiHayError.IsChecked = script.ContinuarSiHayError;
                ChkGuardarResultado.IsChecked = script.GuardarResultado;
                ChkGuardarErrores.IsChecked = script.GuardarErrores;
                TxtProcedimientoDestino.Text = script.ProcedimientoDestino ?? string.Empty;
                TxtTablaDestino.Text = script.TablaDestino ?? string.Empty;

                ChkNotifHabilitada.IsChecked = script.Notificaciones?.Habilitado ?? false;
                ChkNotifSoloError.IsChecked = script.Notificaciones?.NotificarSoloSiHayError ?? true;
                TxtNotifTeamsWebhook.Text = script.Notificaciones?.WebhookTeams ?? string.Empty;
                TxtNotifEmailDestinatarios.Text = script.Notificaciones?.EmailDestinatarios ?? string.Empty;
            }
        }

        private void LimpiarFormularioTarea()
        {
            TxtNombreTarea.Text = string.Empty;
            ChkHabilitado.IsChecked = true;
            TxtArchivoSql.Text = string.Empty;
            CboGrupoServidores.SelectedIndex = -1;
            TxtParalelismo.Text = "4";
            TxtTimeout.Text = "60";
            ChkContinuarSiHayError.IsChecked = true;
            ChkGuardarResultado.IsChecked = true;
            ChkGuardarErrores.IsChecked = true;
            TxtProcedimientoDestino.Text = string.Empty;
            TxtTablaDestino.Text = string.Empty;

            ChkNotifHabilitada.IsChecked = false;
            ChkNotifSoloError.IsChecked = true;
            TxtNotifTeamsWebhook.Text = string.Empty;
            TxtNotifEmailDestinatarios.Text = string.Empty;
        }

        private void BtnNuevaTarea_Click(object sender, RoutedEventArgs e)
        {
            GuardarTareaActualEnMemoria();

            string nombreBase = "NUEVA_TAREA";
            string nombreFinal = nombreBase;
            int counter = 1;
            while (_config.Scripts.ContainsKey(nombreFinal))
            {
                nombreFinal = $"{nombreBase}_{counter++}";
            }

            var nueva = new ScriptConfig
            {
                Habilitado = true,
                Archivo = "Scripts\\MiScript.sql",
                GrupoServidores = _config.GruposServidores.Keys.FirstOrDefault() ?? "Todos",
                Paralelismo = 4,
                TimeoutSegundos = 60,
                ContinuarSiHayError = true,
                GuardarResultado = true,
                GuardarErrores = true
            };

            _config.Scripts[nombreFinal] = nueva;
            CargarTareasUI();
            LbTareas.SelectedItem = nombreFinal;
            TxtNombreTarea.Focus();
        }

        private void BtnEliminarTarea_Click(object sender, RoutedEventArgs e)
        {
            if (LbTareas.SelectedItem == null)
                return;

            string tarea = LbTareas.SelectedItem.ToString()!;
            var res = ModernMessageBox.Show($"¿Desea eliminar la tarea '{tarea}' de la configuración?", "Confirmar Eliminación", MessageBoxButton.YesNo, MessageBoxImage.Question, this);
            if (res == MessageBoxResult.Yes)
            {
                _config.Scripts.Remove(tarea);
                _tareaActualKey = null;
                CargarTareasUI();
            }
        }

        private void BtnExaminarSql_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new OpenFileDialog
            {
                Title = "Seleccionar script T-SQL",
                Filter = "Archivos SQL (*.sql)|*.sql|Todos los archivos (*.*)|*.*",
                InitialDirectory = Path.Combine(_baseDirectory, "Scripts")
            };

            if (dialog.ShowDialog() == true)
            {
                string path = dialog.FileName;
                if (path.StartsWith(_baseDirectory, StringComparison.OrdinalIgnoreCase))
                {
                    path = Path.GetRelativePath(_baseDirectory, path);
                }
                TxtArchivoSql.Text = path;
            }
        }
        #endregion

        #region GRUPOS DE SERVIDORES
        private void CargarGruposUI()
        {
            LbGrupos.Items.Clear();
            foreach (var key in _config.GruposServidores.Keys)
            {
                LbGrupos.Items.Add(key);
            }

            if (LbGrupos.Items.Count > 0)
            {
                LbGrupos.SelectedIndex = 0;
            }
            else
            {
                PanelDetalleGrupo.IsEnabled = false;
                TxtNombreGrupo.Text = string.Empty;
                TxtServidoresGrupo.Text = string.Empty;
            }
        }

        private bool _isRenamingGroup = false;

        private void BtnRenombrarGrupo_Click(object sender, RoutedEventArgs e)
        {
            AplicarRenombradoGrupo();
        }

        private void TxtNombreGrupo_LostFocus(object sender, RoutedEventArgs e)
        {
            AplicarRenombradoGrupo();
        }

        private void TxtNombreGrupo_KeyDown(object sender, System.Windows.Input.KeyEventArgs e)
        {
            if (e.Key == System.Windows.Input.Key.Enter)
            {
                AplicarRenombradoGrupo();
            }
        }

        private void AplicarRenombradoGrupo()
        {
            if (_isRenamingGroup) return;
            if (string.IsNullOrWhiteSpace(_grupoActualKey) || !_config.GruposServidores.ContainsKey(_grupoActualKey))
                return;

            string nuevoNombre = TxtNombreGrupo.Text.Trim();
            if (string.IsNullOrWhiteSpace(nuevoNombre))
            {
                TxtNombreGrupo.Text = _grupoActualKey;
                return;
            }

            if (string.Equals(_grupoActualKey, nuevoNombre, StringComparison.OrdinalIgnoreCase))
                return;

            if (_config.GruposServidores.ContainsKey(nuevoNombre))
            {
                ModernMessageBox.Show($"Ya existe otro grupo de servidores llamado '{nuevoNombre}'.", "Nombre Duplicado", MessageBoxButton.OK, MessageBoxImage.Warning, this);
                TxtNombreGrupo.Text = _grupoActualKey;
                return;
            }

            try
            {
                _isRenamingGroup = true;
                var servidores = _config.GruposServidores[_grupoActualKey];
                _config.GruposServidores.Remove(_grupoActualKey);
                _config.GruposServidores[nuevoNombre] = servidores;

                // Actualizar tareas asociadas
                foreach (var script in _config.Scripts.Values)
                {
                    if (string.Equals(script.GrupoServidores, _grupoActualKey, StringComparison.OrdinalIgnoreCase))
                    {
                        script.GrupoServidores = nuevoNombre;
                    }
                }

                string viejoNombre = _grupoActualKey;
                _grupoActualKey = nuevoNombre;

                int idx = LbGrupos.Items.IndexOf(viejoNombre);
                if (idx >= 0)
                {
                    LbGrupos.Items[idx] = nuevoNombre;
                    LbGrupos.SelectedIndex = idx;
                }
                else
                {
                    CargarGruposUI();
                    LbGrupos.SelectedItem = nuevoNombre;
                }

                RefrescarGruposCombo();
            }
            finally
            {
                _isRenamingGroup = false;
            }
        }

        private void GuardarGrupoActualEnMemoria()
        {
            if (_isRenamingGroup) return;
            if (string.IsNullOrWhiteSpace(_grupoActualKey) || !_config.GruposServidores.ContainsKey(_grupoActualKey))
                return;

            string nuevoNombre = TxtNombreGrupo.Text.Trim();
            if (!string.IsNullOrWhiteSpace(nuevoNombre) && !string.Equals(_grupoActualKey, nuevoNombre, StringComparison.OrdinalIgnoreCase))
            {
                if (!_config.GruposServidores.ContainsKey(nuevoNombre))
                {
                    var serv = _config.GruposServidores[_grupoActualKey];
                    _config.GruposServidores.Remove(_grupoActualKey);
                    _config.GruposServidores[nuevoNombre] = serv;

                    foreach (var script in _config.Scripts.Values)
                    {
                        if (string.Equals(script.GrupoServidores, _grupoActualKey, StringComparison.OrdinalIgnoreCase))
                        {
                            script.GrupoServidores = nuevoNombre;
                        }
                    }

                    string viejo = _grupoActualKey;
                    _grupoActualKey = nuevoNombre;

                    int idx = LbGrupos.Items.IndexOf(viejo);
                    if (idx >= 0)
                    {
                        LbGrupos.Items[idx] = nuevoNombre;
                    }

                    RefrescarGruposCombo();
                }
            }

            var lineas = TxtServidoresGrupo.Text
                .Split(new[] { '\r', '\n', ',' }, StringSplitOptions.RemoveEmptyEntries)
                .Select(s => s.Trim())
                .Where(s => !string.IsNullOrEmpty(s))
                .Distinct()
                .ToList();

            if (_config.GruposServidores.ContainsKey(_grupoActualKey))
            {
                _config.GruposServidores[_grupoActualKey] = lineas;
            }
        }

        private void LbGrupos_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            GuardarGrupoActualEnMemoria();

            if (LbGrupos.SelectedItem == null)
            {
                PanelDetalleGrupo.IsEnabled = false;
                TxtNombreGrupo.Text = string.Empty;
                TxtServidoresGrupo.Text = string.Empty;
                _grupoActualKey = null;
                return;
            }

            _grupoActualKey = LbGrupos.SelectedItem.ToString();
            if (_grupoActualKey != null && _config.GruposServidores.TryGetValue(_grupoActualKey, out var lista))
            {
                PanelDetalleGrupo.IsEnabled = true;
                TxtNombreGrupo.Text = _grupoActualKey;
                TxtServidoresGrupo.Text = string.Join(Environment.NewLine, lista);
            }
        }

        private void BtnNuevoGrupo_Click(object sender, RoutedEventArgs e)
        {
            GuardarGrupoActualEnMemoria();

            string nombreBase = "NuevoGrupo";
            string nombreFinal = nombreBase;
            int counter = 1;
            while (_config.GruposServidores.ContainsKey(nombreFinal))
            {
                nombreFinal = $"{nombreBase}_{counter++}";
            }

            _config.GruposServidores[nombreFinal] = new List<string> { "SQL01" };
            RefrescarGruposCombo();
            CargarGruposUI();
            LbGrupos.SelectedItem = nombreFinal;
            TxtNombreGrupo.Focus();
            TxtNombreGrupo.SelectAll();
        }

        private void BtnEliminarGrupo_Click(object sender, RoutedEventArgs e)
        {
            if (LbGrupos.SelectedItem == null)
                return;

            string grupo = LbGrupos.SelectedItem.ToString()!;
            var res = ModernMessageBox.Show($"¿Desea eliminar el grupo '{grupo}'?", "Confirmar Eliminación", MessageBoxButton.YesNo, MessageBoxImage.Question, this);
            if (res == MessageBoxResult.Yes)
            {
                _config.GruposServidores.Remove(grupo);
                _grupoActualKey = null;
                RefrescarGruposCombo();
                CargarGruposUI();
            }
        }
        #endregion

        #region CREDENCIALES
        private void CargarCredencialesUI()
        {
            LbCredenciales.Items.Clear();
            foreach (var key in _config.CredencialesServidores.Keys)
            {
                LbCredenciales.Items.Add(key);
            }

            if (LbCredenciales.Items.Count > 0)
            {
                LbCredenciales.SelectedIndex = 0;
            }
            else
            {
                PanelDetalleCredencial.IsEnabled = false;
                TxtCredServidor.Text = string.Empty;
                TxtCredUsuario.Text = string.Empty;
                TxtCredPasswordPlano.Password = string.Empty;
                TxtCredPasswordCifrado.Text = string.Empty;
                ActualizarDiagnosticoCredencialUI(null);
            }
        }

        private bool _isRenamingCred = false;

        private void BtnRenombrarCredencial_Click(object sender, RoutedEventArgs e)
        {
            AplicarRenombradoCredencial();
        }

        private void TxtCredServidor_LostFocus(object sender, RoutedEventArgs e)
        {
            AplicarRenombradoCredencial();
        }

        private void TxtCredServidor_KeyDown(object sender, System.Windows.Input.KeyEventArgs e)
        {
            if (e.Key == System.Windows.Input.Key.Enter)
            {
                AplicarRenombradoCredencial();
            }
        }

        private void AplicarRenombradoCredencial()
        {
            if (_isRenamingCred) return;
            if (string.IsNullOrWhiteSpace(_credencialActualKey) || !_config.CredencialesServidores.ContainsKey(_credencialActualKey))
                return;

            string nuevoServidor = TxtCredServidor.Text.Trim();
            if (string.IsNullOrWhiteSpace(nuevoServidor))
            {
                TxtCredServidor.Text = _credencialActualKey;
                return;
            }

            if (string.Equals(_credencialActualKey, nuevoServidor, StringComparison.OrdinalIgnoreCase))
                return;

            if (_config.CredencialesServidores.ContainsKey(nuevoServidor))
            {
                ModernMessageBox.Show($"Ya existe una credencial configurada para el servidor '{nuevoServidor}'.", "Nombre Duplicado", MessageBoxButton.OK, MessageBoxImage.Warning, this);
                TxtCredServidor.Text = _credencialActualKey;
                return;
            }

            try
            {
                _isRenamingCred = true;
                var cred = _config.CredencialesServidores[_credencialActualKey];
                _config.CredencialesServidores.Remove(_credencialActualKey);
                _config.CredencialesServidores[nuevoServidor] = cred;

                string viejoServidor = _credencialActualKey;
                _credencialActualKey = nuevoServidor;

                int idx = LbCredenciales.Items.IndexOf(viejoServidor);
                if (idx >= 0)
                {
                    LbCredenciales.Items[idx] = nuevoServidor;
                    LbCredenciales.SelectedIndex = idx;
                }
                else
                {
                    CargarCredencialesUI();
                    LbCredenciales.SelectedItem = nuevoServidor;
                }
            }
            finally
            {
                _isRenamingCred = false;
            }
        }

        private void GuardarCredencialActualEnMemoria()
        {
            if (_isRenamingCred) return;
            if (string.IsNullOrWhiteSpace(_credencialActualKey) || !_config.CredencialesServidores.ContainsKey(_credencialActualKey))
                return;

            string nuevoServidor = TxtCredServidor.Text.Trim();
            if (!string.IsNullOrWhiteSpace(nuevoServidor) && !string.Equals(_credencialActualKey, nuevoServidor, StringComparison.OrdinalIgnoreCase))
            {
                if (!_config.CredencialesServidores.ContainsKey(nuevoServidor))
                {
                    var cred = _config.CredencialesServidores[_credencialActualKey];
                    _config.CredencialesServidores.Remove(_credencialActualKey);
                    _config.CredencialesServidores[nuevoServidor] = cred;

                    string viejo = _credencialActualKey;
                    _credencialActualKey = nuevoServidor;

                    int idx = LbCredenciales.Items.IndexOf(viejo);
                    if (idx >= 0)
                    {
                        LbCredenciales.Items[idx] = nuevoServidor;
                    }
                }
            }

            if (_config.CredencialesServidores.ContainsKey(_credencialActualKey))
            {
                var cred = _config.CredencialesServidores[_credencialActualKey];
                cred.Usuario = TxtCredUsuario.Text.Trim();
                cred.PasswordCifrado = TxtCredPasswordCifrado.Text.Trim();
            }
        }

        private void LbCredenciales_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            GuardarCredencialActualEnMemoria();

            if (LbCredenciales.SelectedItem == null)
            {
                PanelDetalleCredencial.IsEnabled = false;
                TxtCredServidor.Text = string.Empty;
                TxtCredUsuario.Text = string.Empty;
                TxtCredPasswordPlano.Password = string.Empty;
                TxtCredPasswordCifrado.Text = string.Empty;
                _credencialActualKey = null;
                ActualizarDiagnosticoCredencialUI(null);
                return;
            }

            _credencialActualKey = LbCredenciales.SelectedItem.ToString();
            if (_credencialActualKey != null && _config.CredencialesServidores.TryGetValue(_credencialActualKey, out var cred))
            {
                PanelDetalleCredencial.IsEnabled = true;
                TxtCredServidor.Text = _credencialActualKey;
                TxtCredUsuario.Text = cred.Usuario ?? string.Empty;
                TxtCredPasswordPlano.Password = string.Empty;
                TxtCredPasswordCifrado.Text = cred.PasswordCifrado ?? string.Empty;

                ActualizarDiagnosticoCredencialUI(cred.PasswordCifrado);
            }
        }

        private void ActualizarDiagnosticoCredencialUI(string? hash)
        {
            if (string.IsNullOrWhiteSpace(hash))
            {
                LblCredEstadoIcono.Text = "⚪";
                LblCredEstadoTexto.Text = "Sin contraseña almacenada";
                LblCredEstadoTexto.Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#FFAAAAAA"));
                LblCredAlgoritmo.Text = "Ninguno";
                BorderCredEstado.BorderBrush = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#FF3F3F46"));
                TxtCredDetalleIncompatible.Visibility = Visibility.Collapsed;
                BtnRevelarPasswordCred.IsEnabled = false;
                BtnProbarConexionCred.IsEnabled = true; // Permite probar con Windows Auth si aplica
                return;
            }

            var resultado = SecurityService.ProbarDescifrado(hash, _config);
            LblCredAlgoritmo.Text = resultado.TipoCifrado;

            if (resultado.Exito)
            {
                LblCredEstadoIcono.Text = "🟢";
                LblCredEstadoTexto.Text = "Credencial válida en este equipo";
                LblCredEstadoTexto.Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#FF5AF78E"));
                BorderCredEstado.BorderBrush = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#FF5AF78E"));
                TxtCredDetalleIncompatible.Visibility = Visibility.Collapsed;
                BtnRevelarPasswordCred.IsEnabled = true;
                BtnProbarConexionCred.IsEnabled = true;
            }
            else
            {
                LblCredEstadoIcono.Text = "⚠️";
                LblCredEstadoTexto.Text = "Incompatible / Cifrada en otra máquina";
                LblCredEstadoTexto.Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#FFFFBE3B"));
                BorderCredEstado.BorderBrush = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#FFFF6B68"));
                TxtCredDetalleIncompatible.Text = $"Causa: {resultado.Error}\n\nPara solucionarlo: Ingrese la nueva contraseña en 'Asignar Nueva Contraseña' y presione 'Cifrar y Actualizar Hash'.";
                TxtCredDetalleIncompatible.Visibility = Visibility.Visible;
                BtnRevelarPasswordCred.IsEnabled = false;
                BtnProbarConexionCred.IsEnabled = false;
            }
        }

        private void CboCredMetodoCifrado_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (PanelCredClaveAes == null) return;
            PanelCredClaveAes.Visibility = (CboCredMetodoCifrado.SelectedIndex == 1) 
                ? Visibility.Visible 
                : Visibility.Collapsed;
        }

        private void BtnAgregarCredencial_Click(object sender, RoutedEventArgs e)
        {
            GuardarCredencialActualEnMemoria();

            string srvBase = "SQL_NUEVO";
            string srvFinal = srvBase;
            int counter = 1;
            while (_config.CredencialesServidores.ContainsKey(srvFinal))
            {
                srvFinal = $"{srvBase}_{counter++}";
            }

            _config.CredencialesServidores[srvFinal] = new CredencialServidor
            {
                Usuario = "sa",
                PasswordCifrado = string.Empty
            };

            CargarCredencialesUI();
            LbCredenciales.SelectedItem = srvFinal;
            TxtCredServidor.Focus();
        }

        private void BtnEliminarCredencial_Click(object sender, RoutedEventArgs e)
        {
            if (LbCredenciales.SelectedItem == null)
                return;

            string srv = LbCredenciales.SelectedItem.ToString()!;
            var res = ModernMessageBox.Show($"¿Desea eliminar la credencial del servidor '{srv}'?", "Confirmar Eliminación", MessageBoxButton.YesNo, MessageBoxImage.Question, this);
            if (res == MessageBoxResult.Yes)
            {
                _config.CredencialesServidores.Remove(srv);
                _credencialActualKey = null;
                CargarCredencialesUI();
            }
        }

        private void BtnCifrarPasswordCred_Click(object sender, RoutedEventArgs e)
        {
            string passPlano = TxtCredPasswordPlano.Password;
            if (string.IsNullOrEmpty(passPlano))
            {
                ModernMessageBox.Show("Por favor ingresa una contraseña en el campo de texto antes de cifrar.", "Aviso", MessageBoxButton.OK, MessageBoxImage.Warning, this);
                return;
            }

            try
            {
                string hash;
                bool esAes = (CboCredMetodoCifrado.SelectedIndex == 1);

                if (esAes)
                {
                    string? passphrase = !string.IsNullOrWhiteSpace(TxtCredPassphraseAes.Text)
                        ? TxtCredPassphraseAes.Text.Trim()
                        : SecurityService.ObtenerClaveMaestra(_config);

                    if (string.IsNullOrWhiteSpace(passphrase))
                    {
                        ModernMessageBox.Show("Para el cifrado portátil AES-256 debe especificar una Clave Maestra en la caja de texto o haberla configurado en Opciones Globales.", "Clave Requerida", MessageBoxButton.OK, MessageBoxImage.Warning, this);
                        TxtCredPassphraseAes.Focus();
                        return;
                    }

                    hash = SecurityService.EncriptarPasswordAes(passPlano, passphrase);
                }
                else
                {
                    hash = SecurityService.EncriptarPasswordDpapi(passPlano, DataProtectionScope.LocalMachine);
                }

                TxtCredPasswordCifrado.Text = hash;

                if (!string.IsNullOrWhiteSpace(_credencialActualKey) && _config.CredencialesServidores.ContainsKey(_credencialActualKey))
                {
                    _config.CredencialesServidores[_credencialActualKey].PasswordCifrado = hash;
                }

                ActualizarDiagnosticoCredencialUI(hash);
                TxtCredPasswordPlano.Password = string.Empty;

                string modoTexto = esAes ? "AES-256 (Portátil)" : "DPAPI (LocalMachine)";
                ModernMessageBox.Show($"¡Contraseña cifrada con éxito mediante {modoTexto}!", "Éxito Criptográfico", MessageBoxButton.OK, MessageBoxImage.Information, this);
            }
            catch (Exception ex)
            {
                ModernMessageBox.Show($"Error al cifrar contraseña: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error, this);
            }
        }

        private void BtnRevelarPasswordCred_Click(object sender, RoutedEventArgs e)
        {
            string hash = TxtCredPasswordCifrado.Text.Trim();
            if (string.IsNullOrWhiteSpace(hash))
            {
                ModernMessageBox.Show("No hay una contraseña configurada para este servidor.", "Aviso", MessageBoxButton.OK, MessageBoxImage.Information, this);
                return;
            }

            try
            {
                string plano = SecurityService.DesencriptarPassword(hash, _config);
                Clipboard.SetText(plano);
                ModernMessageBox.Show($"Contraseña para el servidor '{TxtCredServidor.Text}':\n\n{plano}\n\n(Se ha copiado automáticamente al portapapeles)", "Contraseña Descifrada", MessageBoxButton.OK, MessageBoxImage.Information, this);
            }
            catch (Exception ex)
            {
                ModernMessageBox.Show($"Error al descifrar la credencial: {ex.Message}", "Fallo de Descifrado", MessageBoxButton.OK, MessageBoxImage.Error, this);
            }
        }

        private async void BtnProbarConexionCred_Click(object sender, RoutedEventArgs e)
        {
            string servidor = TxtCredServidor.Text.Trim();
            if (string.IsNullOrWhiteSpace(servidor))
            {
                ModernMessageBox.Show("Por favor especifique un nombre de servidor válido.", "Campo Requerido", MessageBoxButton.OK, MessageBoxImage.Warning, this);
                return;
            }

            string usuario = TxtCredUsuario.Text.Trim();
            string? passPlano = null;

            if (!string.IsNullOrWhiteSpace(TxtCredPasswordCifrado.Text))
            {
                try
                {
                    passPlano = SecurityService.DesencriptarPassword(TxtCredPasswordCifrado.Text.Trim(), _config);
                }
                catch (Exception ex)
                {
                    ModernMessageBox.Show($"No se puede probar la conexión porque la contraseña no pudo ser descifrada en este equipo:\n\n{ex.Message}", "Credencial Incompatible", MessageBoxButton.OK, MessageBoxImage.Warning, this);
                    return;
                }
            }

            var cursorAnterior = this.Cursor;
            this.Cursor = System.Windows.Input.Cursors.Wait;

            try
            {
                var (exito, mensaje, latencia) = await SecurityService.ProbarConexionSqlAsync(servidor, usuario, passPlano, timeoutSegundos: 5);
                this.Cursor = cursorAnterior;

                if (exito)
                {
                    ModernMessageBox.Show($"¡Conexión Exitosa!\n\nServidor: {servidor}\nLatencia: {latencia.TotalMilliseconds:F0} ms\nDetalle: {mensaje}", "Prueba de Conexión SQL", MessageBoxButton.OK, MessageBoxImage.Information, this);
                }
                else
                {
                    ModernMessageBox.Show($"No se pudo conectar a '{servidor}':\n\n{mensaje}", "Fallo en Conexión SQL", MessageBoxButton.OK, MessageBoxImage.Warning, this);
                }
            }
            catch (Exception ex)
            {
                this.Cursor = cursorAnterior;
                ModernMessageBox.Show($"Excepción al probar conexión: {ex.Message}", "Error Inesperado", MessageBoxButton.OK, MessageBoxImage.Error, this);
            }
        }

        private void BtnCopiarHashCred_Click(object sender, RoutedEventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(TxtCredPasswordCifrado.Text))
            {
                Clipboard.SetText(TxtCredPasswordCifrado.Text);
                ModernMessageBox.Show("Hash copiado al portapapeles.", "Copiado", MessageBoxButton.OK, MessageBoxImage.Information, this);
            }
        }

        private void BtnExportarCredenciales_Click(object sender, RoutedEventArgs e)
        {
            GuardarCredencialActualEnMemoria();
            var dlg = new CredentialTransferWindow(_config, ModoTransferencia.Exportar) { Owner = this };
            dlg.ShowDialog();
        }

        private void BtnImportarCredenciales_Click(object sender, RoutedEventArgs e)
        {
            var dlg = new CredentialTransferWindow(_config, ModoTransferencia.Importar) { Owner = this };
            if (dlg.ShowDialog() == true)
            {
                CargarCredencialesUI();
            }
        }
        #endregion

        #region OPCIONES GLOBALES
        private void CargarOpcionesGlobalesUI()
        {
            TxtGlobalServidorCentral.Text = _config.Configuracion.ServidorCentral;
            TxtGlobalBaseDatosCentral.Text = _config.Configuracion.BaseDatosCentral;
            TxtGlobalParalelismo.Text = _config.Configuracion.ParalelismoPredeterminado.ToString();
            TxtGlobalTimeout.Text = _config.Configuracion.TimeoutPredeterminadoSegundos.ToString();
            TxtGlobalRetencionLogs.Text = _config.Configuracion.DiasRetencionLogs.ToString();

            TxtGlobalTeamsWebhook.Text = _config.Configuracion.DefaultTeamsWebhook ?? string.Empty;
            TxtGlobalSmtpHost.Text = _config.Configuracion.SmtpHost ?? string.Empty;
            TxtGlobalSmtpPort.Text = _config.Configuracion.SmtpPort.ToString();
            TxtGlobalSmtpRemitente.Text = _config.Configuracion.SmtpRemitente ?? string.Empty;
            ChkGlobalSmtpSsl.IsChecked = _config.Configuracion.SmtpSsl;

            TxtGlobalSmtpUsuario.Text = _config.Configuracion.SmtpUsuario ?? string.Empty;
            TxtGlobalSmtpPasswordCifrado.Text = _config.Configuracion.SmtpPasswordCifrado ?? string.Empty;
            TxtGlobalClaveMaestra.Text = _config.Configuracion.ClaveMaestraPortabilidad ?? string.Empty;
        }

        private void BtnCifrarSmtpPassword_Click(object sender, RoutedEventArgs e)
        {
            string pass = TxtGlobalSmtpPasswordPlano.Password;
            if (string.IsNullOrEmpty(pass))
            {
                ModernMessageBox.Show("Por favor ingrese la contraseña SMTP antes de cifrar.", "Campo Requerido", MessageBoxButton.OK, MessageBoxImage.Warning, this);
                return;
            }

            try
            {
                string hash = SecurityService.EncriptarPasswordDpapi(pass, DataProtectionScope.LocalMachine);
                TxtGlobalSmtpPasswordCifrado.Text = hash;
                _config.Configuracion.SmtpPasswordCifrado = hash;
                TxtGlobalSmtpPasswordPlano.Password = string.Empty;
                ModernMessageBox.Show("¡Contraseña SMTP cifrada exitosamente con DPAPI!", "Cifrado Exitoso", MessageBoxButton.OK, MessageBoxImage.Information, this);
            }
            catch (Exception ex)
            {
                ModernMessageBox.Show($"Error al cifrar contraseña SMTP: {ex.Message}", "Error Criptográfico", MessageBoxButton.OK, MessageBoxImage.Error, this);
            }
        }

        private void GuardarOpcionesGlobalesEnMemoria()
        {
            _config.Configuracion.ServidorCentral = TxtGlobalServidorCentral.Text.Trim();
            _config.Configuracion.BaseDatosCentral = TxtGlobalBaseDatosCentral.Text.Trim();
            _config.Configuracion.ParalelismoPredeterminado = int.TryParse(TxtGlobalParalelismo.Text, out int p) ? Math.Max(1, p) : 4;
            _config.Configuracion.TimeoutPredeterminadoSegundos = int.TryParse(TxtGlobalTimeout.Text, out int t) ? Math.Max(1, t) : 300;
            _config.Configuracion.DiasRetencionLogs = int.TryParse(TxtGlobalRetencionLogs.Text, out int d) ? Math.Max(1, d) : 15;

            _config.Configuracion.DefaultTeamsWebhook = string.IsNullOrWhiteSpace(TxtGlobalTeamsWebhook.Text) ? null : TxtGlobalTeamsWebhook.Text.Trim();
            _config.Configuracion.SmtpHost = string.IsNullOrWhiteSpace(TxtGlobalSmtpHost.Text) ? null : TxtGlobalSmtpHost.Text.Trim();
            _config.Configuracion.SmtpPort = int.TryParse(TxtGlobalSmtpPort.Text, out int sp) ? sp : 587;
            _config.Configuracion.SmtpRemitente = string.IsNullOrWhiteSpace(TxtGlobalSmtpRemitente.Text) ? null : TxtGlobalSmtpRemitente.Text.Trim();
            _config.Configuracion.SmtpSsl = ChkGlobalSmtpSsl.IsChecked ?? true;

            _config.Configuracion.SmtpUsuario = string.IsNullOrWhiteSpace(TxtGlobalSmtpUsuario.Text) ? null : TxtGlobalSmtpUsuario.Text.Trim();
            _config.Configuracion.SmtpPasswordCifrado = string.IsNullOrWhiteSpace(TxtGlobalSmtpPasswordCifrado.Text) ? null : TxtGlobalSmtpPasswordCifrado.Text.Trim();
            _config.Configuracion.ClaveMaestraPortabilidad = string.IsNullOrWhiteSpace(TxtGlobalClaveMaestra.Text) ? null : TxtGlobalClaveMaestra.Text.Trim();
        }
        #endregion

        private void BtnGuardarTodo_Click(object sender, RoutedEventArgs e)
        {
            // Sincronizar pestañas activas
            GuardarTareaActualEnMemoria();
            GuardarGrupoActualEnMemoria();
            GuardarCredencialActualEnMemoria();
            GuardarOpcionesGlobalesEnMemoria();

            string configPath = Path.Combine(_baseDirectory, "appsettings.json");

            try
            {
                var opciones = new JsonSerializerOptions
                {
                    WriteIndented = true
                };

                string json = JsonSerializer.Serialize(_config, opciones);
                File.WriteAllText(configPath, json);

                ModernMessageBox.Show("Configuración guardada correctamente en appsettings.json.", "Configuración Actualizada", MessageBoxButton.OK, MessageBoxImage.Information, this);
                this.DialogResult = true;
                this.Close();
            }
            catch (Exception ex)
            {
                ModernMessageBox.Show($"Error al guardar appsettings.json: {ex.Message}", "Error de Guardado", MessageBoxButton.OK, MessageBoxImage.Error, this);
            }
        }

        private void BtnCerrar_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = false;
            this.Close();
        }
    }
}
