using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace SqlScriptRunner.Models
{
    public enum EstadoServidor
    {
        Pendiente,
        EnEjecucion,
        Completado,
        Error,
        Cancelado
    }

    public class ServidorProgresoItem : INotifyPropertyChanged
    {
        private string _servidor = string.Empty;
        private EstadoServidor _estado = EstadoServidor.Pendiente;
        private string _estadoTexto = "⏳ Pendiente";
        private long _duracionMs = 0;
        private int _registrosObtenidos = 0;
        private string _detalle = "En espera de inicio";
        private string _colorEstado = "#888888";

        public string Servidor
        {
            get => _servidor;
            set { _servidor = value; OnPropertyChanged(); }
        }

        public EstadoServidor Estado
        {
            get => _estado;
            set
            {
                _estado = value;
                OnPropertyChanged();
                ActualizarVisuales();
            }
        }

        public string EstadoTexto
        {
            get => _estadoTexto;
            set { _estadoTexto = value; OnPropertyChanged(); }
        }

        public long DuracionMs
        {
            get => _duracionMs;
            set { _duracionMs = value; OnPropertyChanged(); }
        }

        public int RegistrosObtenidos
        {
            get => _registrosObtenidos;
            set { _registrosObtenidos = value; OnPropertyChanged(); }
        }

        public string Detalle
        {
            get => _detalle;
            set { _detalle = value; OnPropertyChanged(); }
        }

        public string ColorEstado
        {
            get => _colorEstado;
            set { _colorEstado = value; OnPropertyChanged(); }
        }

        private void ActualizarVisuales()
        {
            switch (_estado)
            {
                case EstadoServidor.Pendiente:
                    EstadoTexto = "⏳ Pendiente";
                    ColorEstado = "#AAAAAA";
                    break;
                case EstadoServidor.EnEjecucion:
                    EstadoTexto = "🔄 Ejecutando";
                    ColorEstado = "#00A2ED";
                    break;
                case EstadoServidor.Completado:
                    EstadoTexto = "✅ Completado";
                    ColorEstado = "#2ECC71";
                    break;
                case EstadoServidor.Error:
                    EstadoTexto = "❌ Error";
                    ColorEstado = "#E74C3C";
                    break;
                case EstadoServidor.Cancelado:
                    EstadoTexto = "⏹ Cancelado";
                    ColorEstado = "#E67E22";
                    break;
            }
        }

        public event PropertyChangedEventHandler? PropertyChanged;
        protected void OnPropertyChanged([CallerMemberName] string? propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
