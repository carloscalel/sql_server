using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace SqlScriptRunner.Models
{
    public class ConfiguracionGlobal
    {
        [JsonPropertyName("ServidorCentral")]
        public string ServidorCentral { get; set; } = ".";

        [JsonPropertyName("BaseDatosCentral")]
        public string BaseDatosCentral { get; set; } = "adminDB";

        [JsonPropertyName("ParalelismoPredeterminado")]
        public int ParalelismoPredeterminado { get; set; } = 4;

        [JsonPropertyName("TimeoutPredeterminadoSegundos")]
        public int TimeoutPredeterminadoSegundos { get; set; } = 300;

        [JsonPropertyName("DiasRetencionLogs")]
        public int DiasRetencionLogs { get; set; } = 15;

        // Configuración Global de Alertas (Fallback)
        [JsonPropertyName("DefaultTeamsWebhook")]
        public string? DefaultTeamsWebhook { get; set; }

        [JsonPropertyName("SmtpHost")]
        public string? SmtpHost { get; set; }

        [JsonPropertyName("SmtpPort")]
        public int SmtpPort { get; set; } = 587;

        [JsonPropertyName("SmtpUsuario")]
        public string? SmtpUsuario { get; set; }

        [JsonPropertyName("SmtpPasswordCifrado")]
        public string? SmtpPasswordCifrado { get; set; }

        [JsonPropertyName("SmtpSsl")]
        public bool SmtpSsl { get; set; } = true;

        [JsonPropertyName("SmtpRemitente")]
        public string? SmtpRemitente { get; set; }

        // Clave Maestra de Portabilidad (Opcional, para descifrar credenciales AES-256 entre servidores)
        [JsonPropertyName("ClaveMaestraPortabilidad")]
        public string? ClaveMaestraPortabilidad { get; set; }
    }

    public class CredencialServidor
    {
        [JsonPropertyName("Usuario")]
        public string? Usuario { get; set; }

        [JsonPropertyName("PasswordCifrado")]
        public string? PasswordCifrado { get; set; }
    }

    public class NotificacionesConfig
    {
        [JsonPropertyName("Habilitado")]
        public bool Habilitado { get; set; } = false;

        [JsonPropertyName("NotificarSoloSiHayError")]
        public bool NotificarSoloSiHayError { get; set; } = true;

        [JsonPropertyName("WebhookTeams")]
        public string? WebhookTeams { get; set; }

        [JsonPropertyName("EmailDestinatarios")]
        public string? EmailDestinatarios { get; set; }
    }

    public class ScriptConfig
    {
        [JsonPropertyName("Habilitado")]
        public bool Habilitado { get; set; } = true;

        [JsonPropertyName("Archivo")]
        public string Archivo { get; set; } = string.Empty;

        [JsonPropertyName("GrupoServidores")]
        public string GrupoServidores { get; set; } = "Todos";

        [JsonPropertyName("Paralelismo")]
        public int Paralelismo { get; set; } = 4;

        [JsonPropertyName("TimeoutSegundos")]
        public int TimeoutSegundos { get; set; } = 60;

        [JsonPropertyName("ContinuarSiHayError")]
        public bool ContinuarSiHayError { get; set; } = true;

        [JsonPropertyName("GuardarResultado")]
        public bool GuardarResultado { get; set; } = true;

        [JsonPropertyName("GuardarErrores")]
        public bool GuardarErrores { get; set; } = true;

        [JsonPropertyName("ProcedimientoDestino")]
        public string? ProcedimientoDestino { get; set; }

        [JsonPropertyName("TablaDestino")]
        public string? TablaDestino { get; set; }

        [JsonPropertyName("Notificaciones")]
        public NotificacionesConfig Notificaciones { get; set; } = new();

        [JsonPropertyName("Variables")]
        public Dictionary<string, string> Variables { get; set; } = new();
    }

    public class AppConfig
    {
        [JsonPropertyName("Configuracion")]
        public ConfiguracionGlobal Configuracion { get; set; } = new();

        [JsonPropertyName("GruposServidores")]
        public Dictionary<string, List<string>> GruposServidores { get; set; } = new();

        [JsonPropertyName("CredencialesServidores")]
        public Dictionary<string, CredencialServidor> CredencialesServidores { get; set; } = new();

        [JsonPropertyName("Scripts")]
        public Dictionary<string, ScriptConfig> Scripts { get; set; } = new();
    }
}
