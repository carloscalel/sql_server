using System;
using System.Data;
using System.Threading.Tasks;
using Microsoft.Data.SqlClient;
using SqlScriptRunner.Models;

namespace SqlScriptRunner.Services
{
    public class CentralDatabaseService
    {
        private readonly AppConfig _config;
        private readonly LogService _logger;

        public CentralDatabaseService(AppConfig config, LogService logger)
        {
            _config = config;
            _logger = logger;
        }

        /// <summary>
        /// Guarda el conjunto de datos obtenido de un servidor remoto en la base central adminDB.
        /// Soporta ejecución de ProcedimientoDestino (ej. dbo.usp_GuardarHealth) o inserción en TablaDestino.
        /// </summary>
        public async Task<int> GuardarResultadosAsync(
            string nombreTarea,
            string servidorOrigen,
            ScriptConfig scriptConfig,
            DataTable datos)
        {
            if (datos == null || datos.Rows.Count == 0)
            {
                _logger.Registrar($"[{servidorOrigen}] No hubo registros que persistir en { _config.Configuracion.BaseDatosCentral }.");
                return 0;
            }

            string connStringCentral = SecurityService.ConstruirConnectionStringCentral(_config);
            int registrosInsertados = 0;

            try
            {
                await using var connection = new SqlConnection(connStringCentral);
                await connection.OpenAsync();

                // Opción A: Guardar mediante Procedimiento Almacenado Destino
                if (!string.IsNullOrWhiteSpace(scriptConfig.ProcedimientoDestino))
                {
                    registrosInsertados = await EjecutarProcedimientoDestinoAsync(connection, scriptConfig.ProcedimientoDestino, servidorOrigen, datos);
                    _logger.Registrar($"[{servidorOrigen}] Se guardaron {registrosInsertados} registros en {_config.Configuracion.BaseDatosCentral} mediante SP '{scriptConfig.ProcedimientoDestino}'.");
                }
                // Opción B: Guardar directamente en TablaDestino si no se configuró SP
                else if (!string.IsNullOrWhiteSpace(scriptConfig.TablaDestino))
                {
                    registrosInsertados = await GuardarEnTablaDestinoAsync(connection, scriptConfig.TablaDestino, servidorOrigen, datos);
                    _logger.Registrar($"[{servidorOrigen}] Se insertaron {registrosInsertados} registros en {_config.Configuracion.BaseDatosCentral}.{scriptConfig.TablaDestino}.");
                }
                else
                {
                    _logger.Registrar($"[{servidorOrigen}] La tarea no define 'ProcedimientoDestino' ni 'TablaDestino'. Se omitió la persistencia central.");
                }
            }
            catch (Exception ex)
            {
                _logger.Registrar($"[{servidorOrigen}] ERROR al guardar en base central {_config.Configuracion.BaseDatosCentral}: {ex.Message}");
                throw;
            }

            return registrosInsertados;
        }

        private async Task<int> EjecutarProcedimientoDestinoAsync(
            SqlConnection connection,
            string nombreProcedimiento,
            string servidorOrigen,
            DataTable datos)
        {
            int total = 0;

            foreach (DataRow row in datos.Rows)
            {
                await using var cmd = new SqlCommand(nombreProcedimiento, connection);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandTimeout = _config.Configuracion.TimeoutPredeterminadoSegundos;

                // Añadir cada columna del DataTable como parámetro al procedimiento
                foreach (DataColumn col in datos.Columns)
                {
                    string paramName = "@" + col.ColumnName;
                    object val = row[col] ?? DBNull.Value;
                    cmd.Parameters.AddWithValue(paramName, val);
                }

                // Parámetros adicionales de contexto si el SP los requiere o acepta
                if (!cmd.Parameters.Contains("@ServidorOrigen"))
                {
                    cmd.Parameters.AddWithValue("@ServidorOrigen", servidorOrigen);
                }
                if (!cmd.Parameters.Contains("@FechaEjecucion"))
                {
                    cmd.Parameters.AddWithValue("@FechaEjecucion", DateTime.Now);
                }

                try
                {
                    await cmd.ExecuteNonQueryAsync();
                    total++;
                }
                catch (SqlException ex) when (ex.Number == 8145) // Procedimiento tiene demasiados argumentos no esperados
                {
                    // Reintentar sin los parámetros adicionales de contexto si el SP no los acepta
                    cmd.Parameters.Remove(cmd.Parameters["@ServidorOrigen"]);
                    cmd.Parameters.Remove(cmd.Parameters["@FechaEjecucion"]);
                    await cmd.ExecuteNonQueryAsync();
                    total++;
                }
            }

            return total;
        }

        private async Task<int> GuardarEnTablaDestinoAsync(
            SqlConnection connection,
            string tablaDestino,
            string servidorOrigen,
            DataTable datos)
        {
            using var bulkCopy = new SqlBulkCopy(connection)
            {
                DestinationTableName = tablaDestino,
                BulkCopyTimeout = _config.Configuracion.TimeoutPredeterminadoSegundos
            };

            foreach (DataColumn col in datos.Columns)
            {
                bulkCopy.ColumnMappings.Add(col.ColumnName, col.ColumnName);
            }

            await bulkCopy.WriteToServerAsync(datos);
            return datos.Rows.Count;
        }

        /// <summary>
        /// Guarda un registro de auditoría o error en la tabla central dbo.LogEjecuciones si está disponible.
        /// </summary>
        public async Task RegistrarAuditoriaCentralAsync(
            string nombreTarea,
            string servidor,
            bool exitoso,
            long duracionMs,
            string mensaje)
        {
            try
            {
                string connStringCentral = SecurityService.ConstruirConnectionStringCentral(_config);
                await using var connection = new SqlConnection(connStringCentral);
                await connection.OpenAsync();

                const string sql = @"
IF OBJECT_ID('dbo.LogEjecuciones', 'U') IS NOT NULL
BEGIN
    INSERT INTO dbo.LogEjecuciones (Tarea, Servidor, Fecha, Exitoso, DuracionMs, Detalle)
    VALUES (@Tarea, @Servidor, GETDATE(), @Exitoso, @DuracionMs, @Detalle);
END";

                await using var cmd = new SqlCommand(sql, connection);
                cmd.Parameters.AddWithValue("@Tarea", nombreTarea);
                cmd.Parameters.AddWithValue("@Servidor", servidor);
                cmd.Parameters.AddWithValue("@Exitoso", exitoso);
                cmd.Parameters.AddWithValue("@DuracionMs", duracionMs);
                cmd.Parameters.AddWithValue("@Detalle", mensaje ?? (object)DBNull.Value);

                await cmd.ExecuteNonQueryAsync();
            }
            catch
            {
                // No interrumpir si la auditoría central no está creada o no responde
            }
        }

        /// <summary>
        /// Lista las tablas y vistas disponibles en la base de datos central adminDB para el Visor.
        /// </summary>
        public async Task<List<string>> ListarObjetosCentralesAsync()
        {
            var lista = new List<string>();
            try
            {
                string connString = SecurityService.ConstruirConnectionStringCentral(_config);
                await using var connection = new SqlConnection(connString);
                await connection.OpenAsync();

                const string sql = @"
SELECT TABLE_SCHEMA + '.' + TABLE_NAME AS Objeto 
FROM INFORMATION_SCHEMA.TABLES 
WHERE TABLE_TYPE IN ('BASE TABLE', 'VIEW') 
ORDER BY TABLE_NAME;";

                await using var cmd = new SqlCommand(sql, connection);
                await using var reader = await cmd.ExecuteReaderAsync();
                while (await reader.ReadAsync())
                {
                    lista.Add(reader.GetString(0));
                }
            }
            catch (Exception ex)
            {
                _logger.Registrar($"[Visor adminDB] Error al listar tablas/vistas: {ex.Message}");
            }
            return lista;
        }

        /// <summary>
        /// Obtiene los registros más recientes de una tabla o vista en adminDB.
        /// </summary>
        public async Task<DataTable> ConsultarDatosObjetoAsync(string objeto, int top = 100)
        {
            var dt = new DataTable();
            string connString = SecurityService.ConstruirConnectionStringCentral(_config);
            await using var connection = new SqlConnection(connString);
            await connection.OpenAsync();

            // Consulta protegida y parametrizada con TOP
            string sql = $"SELECT TOP ({Math.Clamp(top, 1, 10000)}) * FROM {objeto};";
            await using var cmd = new SqlCommand(sql, connection);
            await using var reader = await cmd.ExecuteReaderAsync();
            dt.Load(reader);
            return dt;
        }

        /// <summary>
        /// Ejecuta una consulta de solo lectura personalizada sobre adminDB.
        /// </summary>
        public async Task<DataTable> EjecutarConsultaAsync(string sql)
        {
            var dt = new DataTable();
            string connString = SecurityService.ConstruirConnectionStringCentral(_config);
            await using var connection = new SqlConnection(connString);
            await connection.OpenAsync();

            await using var cmd = new SqlCommand(sql, connection)
            {
                CommandTimeout = _config.Configuracion.TimeoutPredeterminadoSegundos
            };
            await using var reader = await cmd.ExecuteReaderAsync();
            dt.Load(reader);
            return dt;
        }

        /// <summary>
        /// Obtiene la lista de columnas de una tabla o vista en adminDB para armar consultas interactivas.
        /// </summary>
        public async Task<List<string>> ListarColumnasObjetoAsync(string objeto)
        {
            var columnas = new List<string>();
            try
            {
                string connString = SecurityService.ConstruirConnectionStringCentral(_config);
                await using var connection = new SqlConnection(connString);
                await connection.OpenAsync();

                string schema = "dbo";
                string tabla = objeto;
                if (objeto.Contains('.'))
                {
                    var partes = objeto.Split('.');
                    schema = partes[0].Trim('[', ']');
                    tabla = partes[1].Trim('[', ']');
                }

                const string sql = @"
SELECT COLUMN_NAME 
FROM INFORMATION_SCHEMA.COLUMNS 
WHERE TABLE_SCHEMA = @Schema AND TABLE_NAME = @Tabla 
ORDER BY ORDINAL_POSITION;";

                await using var cmd = new SqlCommand(sql, connection);
                cmd.Parameters.AddWithValue("@Schema", schema);
                cmd.Parameters.AddWithValue("@Tabla", tabla);

                await using var reader = await cmd.ExecuteReaderAsync();
                while (await reader.ReadAsync())
                {
                    columnas.Add(reader.GetString(0));
                }
            }
            catch (Exception ex)
            {
                _logger.Registrar($"[Visor adminDB] Error al listar columnas de {objeto}: {ex.Message}");
            }
            return columnas;
        }
    }
}
