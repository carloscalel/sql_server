using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Data.SqlClient;
using SqlScriptRunner.Models;

namespace SqlScriptRunner.Services
{
    public class ScriptExecutionEngine
    {
        private readonly AppConfig _config;
        private readonly LogService _logger;
        private readonly CentralDatabaseService _centralDb;
        private readonly NotificationService _notifications;

        public ScriptExecutionEngine(
            AppConfig config, 
            LogService logger, 
            CentralDatabaseService centralDb,
            NotificationService? notifications = null)
        {
            _config = config;
            _logger = logger;
            _centralDb = centralDb;
            _notifications = notifications ?? new NotificationService(config, logger);
        }

        /// <summary>
        /// Ejecuta concurrentemente el script sobre la lista de servidores usando Parallel.ForEachAsync.
        /// </summary>
        public async Task EjecutarTareaAsync(
            string nombreTarea,
            ScriptConfig scriptConfig,
            string scriptSql,
            List<ServidorProgresoItem> itemsProgreso,
            Action<int, int> onProgresoGlobal,
            CancellationToken cancellationToken)
        {
            var swTotal = Stopwatch.StartNew();
            int totalServidores = itemsProgreso.Count;
            int servidoresProcesados = 0;

            int nivelParalelismo = scriptConfig.Paralelismo > 0
                ? scriptConfig.Paralelismo
                : _config.Configuracion.ParalelismoPredeterminado;

            int timeoutSegundos = scriptConfig.TimeoutSegundos > 0
                ? scriptConfig.TimeoutSegundos
                : _config.Configuracion.TimeoutPredeterminadoSegundos;

            _logger.Registrar($"Iniciando ejecución de '{nombreTarea}' en {totalServidores} servidores. Grado de paralelismo: {nivelParalelismo}, Timeout: {timeoutSegundos}s.");

            using var internalCts = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);

            var parallelOptions = new ParallelOptions
            {
                MaxDegreeOfParallelism = Math.Max(1, nivelParalelismo),
                CancellationToken = internalCts.Token
            };

            try
            {
                await Parallel.ForEachAsync(itemsProgreso, parallelOptions, async (item, token) =>
                {
                    if (token.IsCancellationRequested)
                    {
                        item.Estado = EstadoServidor.Cancelado;
                        item.Detalle = "Cancelado antes de iniciar.";
                        return;
                    }

                    await EjecutarEnServidorAsync(
                        nombreTarea,
                        scriptConfig,
                        scriptSql,
                        item,
                        timeoutSegundos,
                        internalCts,
                        token);

                    int procesados = Interlocked.Increment(ref servidoresProcesados);
                    onProgresoGlobal?.Invoke(procesados, totalServidores);
                });
            }
            catch (OperationCanceledException)
            {
                _logger.Registrar($"[AVISO] La ejecución de la tarea '{nombreTarea}' fue cancelada o detenida por error.");
                foreach (var item in itemsProgreso)
                {
                    if (item.Estado == EstadoServidor.Pendiente || item.Estado == EstadoServidor.EnEjecucion)
                    {
                        item.Estado = EstadoServidor.Cancelado;
                        item.Detalle = "Ejecución cancelada.";
                    }
                }
            }

            swTotal.Stop();
            _logger.Registrar($"Finalizada la ejecución de '{nombreTarea}'. Total procesados: {servidoresProcesados}/{totalServidores} en {swTotal.ElapsedMilliseconds / 1000.0:F2}s.");

            // Envío automático de notificaciones (Teams / Email) si aplica
            try
            {
                await _notifications.EnviarResumenEjecucionAsync(nombreTarea, scriptConfig, itemsProgreso, swTotal.ElapsedMilliseconds);
            }
            catch (Exception ex)
            {
                _logger.Registrar($"[Alertas] Error no crítico al procesar notificaciones: {ex.Message}");
            }
        }

        private async Task EjecutarEnServidorAsync(
            string nombreTarea,
            ScriptConfig scriptConfig,
            string scriptSql,
            ServidorProgresoItem item,
            int timeoutSegundos,
            CancellationTokenSource errorCts,
            CancellationToken token)
        {
            var sw = Stopwatch.StartNew();
            item.Estado = EstadoServidor.EnEjecucion;
            item.Detalle = "Conectando y ejecutando script...";
            _logger.Registrar($"[{item.Servidor}] Conectando...");

            try
            {
                // Reemplazo dinámico de variables/tokens para este servidor
                string sqlFinal = VariableReplacerService.ReemplazarTokens(scriptSql, item.Servidor, scriptConfig.Variables);

                string connString = SecurityService.ConstruirConnectionString(item.Servidor, "master", _config, timeoutSegundos);
                var dataTable = new DataTable();

                await using (var connection = new SqlConnection(connString))
                {
                    await connection.OpenAsync(token);
                    _logger.Registrar($"[{item.Servidor}] Conexión establecida. Ejecutando script...");

                    await using var command = new SqlCommand(sqlFinal, connection)
                    {
                        CommandTimeout = timeoutSegundos
                    };

                    await using var reader = await command.ExecuteReaderAsync(token);
                    dataTable.Load(reader);
                }

                sw.Stop();
                item.DuracionMs = sw.ElapsedMilliseconds;
                item.RegistrosObtenidos = dataTable.Rows.Count;
                _logger.Registrar($"[{item.Servidor}] Consulta completada en {sw.ElapsedMilliseconds} ms. Filas obtenidas: {dataTable.Rows.Count}.");

                // Persistir resultados en adminDB central si está habilitado
                if (scriptConfig.GuardarResultado && dataTable.Rows.Count > 0)
                {
                    item.Detalle = "Guardando en adminDB central...";
                    int insertados = await _centralDb.GuardarResultadosAsync(nombreTarea, item.Servidor, scriptConfig, dataTable);
                    item.Detalle = $"Éxito ({dataTable.Rows.Count} filas recolectadas, {insertados} guardadas en adminDB).";
                }
                else
                {
                    item.Detalle = $"Éxito ({dataTable.Rows.Count} filas obtenidas).";
                }

                item.Estado = EstadoServidor.Completado;

                // Registro de auditoría central
                if (scriptConfig.GuardarErrores)
                {
                    await _centralDb.RegistrarAuditoriaCentralAsync(nombreTarea, item.Servidor, true, sw.ElapsedMilliseconds, item.Detalle);
                }
            }
            catch (Exception ex)
            {
                sw.Stop();
                item.DuracionMs = sw.ElapsedMilliseconds;
                item.Estado = EstadoServidor.Error;
                item.Detalle = ex.Message;

                _logger.Registrar($"[{item.Servidor}] ERROR ({sw.ElapsedMilliseconds} ms): {ex.Message}");

                if (scriptConfig.GuardarErrores)
                {
                    await _centralDb.RegistrarAuditoriaCentralAsync(nombreTarea, item.Servidor, false, sw.ElapsedMilliseconds, ex.Message);
                }

                if (!scriptConfig.ContinuarSiHayError)
                {
                    _logger.Registrar($"[{item.Servidor}] 'ContinuarSiHayError' es FALSE. Cancelando ejecución en los demás servidores...");
                    errorCts.Cancel();
                }
            }
        }

        /// <summary>
        /// Realiza una prueba de conectividad masiva concurrente (Ping SQL) a los servidores seleccionados.
        /// </summary>
        public async Task ProbarConectividadAsync(
            List<ServidorProgresoItem> items,
            int timeoutSegundos,
            Action<int, int> onProgreso,
            CancellationToken token)
        {
            int total = items.Count;
            int procesados = 0;
            _logger.Registrar($"[Ping SQL] Iniciando prueba de conectividad masiva a {total} servidores (Timeout: {timeoutSegundos}s)...");

            var parallelOptions = new ParallelOptions
            {
                MaxDegreeOfParallelism = Math.Max(2, _config.Configuracion.ParalelismoPredeterminado),
                CancellationToken = token
            };

            await Parallel.ForEachAsync(items, parallelOptions, async (item, cancelToken) =>
            {
                var sw = Stopwatch.StartNew();
                item.Estado = EstadoServidor.EnEjecucion;
                item.Detalle = "Probando conexión (Ping SQL)...";

                try
                {
                    string connString = SecurityService.ConstruirConnectionString(item.Servidor, "master", _config, timeoutSegundos);
                    await using var connection = new SqlConnection(connString);
                    await connection.OpenAsync(cancelToken);

                    await using var cmd = new SqlCommand("SELECT 1;", connection)
                    {
                        CommandTimeout = timeoutSegundos
                    };
                    await cmd.ExecuteScalarAsync(cancelToken);

                    sw.Stop();
                    item.DuracionMs = sw.ElapsedMilliseconds;
                    item.RegistrosObtenidos = 0;
                    item.Estado = EstadoServidor.Completado;
                    item.Detalle = $"ONLINE ({sw.ElapsedMilliseconds} ms de latencia)";
                    _logger.Registrar($"[{item.Servidor}] ONLINE ({sw.ElapsedMilliseconds} ms).");
                }
                catch (Exception ex)
                {
                    sw.Stop();
                    item.DuracionMs = sw.ElapsedMilliseconds;
                    item.Estado = EstadoServidor.Error;
                    item.Detalle = $"OFFLINE: {ex.Message}";
                    _logger.Registrar($"[{item.Servidor}] OFFLINE: {ex.Message}");
                }

                int act = Interlocked.Increment(ref procesados);
                onProgreso?.Invoke(act, total);
            });

            _logger.Registrar($"[Ping SQL] Finalizada la prueba de conectividad para {total} servidores.");
        }
    }
}
