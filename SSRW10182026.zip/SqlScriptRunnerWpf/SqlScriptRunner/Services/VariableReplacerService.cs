using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;

namespace SqlScriptRunner.Services
{
    public static class VariableReplacerService
    {
        private static readonly Regex TokenRegex = new(@"\$\(([a-zA-Z0-9_]+)\)", RegexOptions.Compiled);

        /// <summary>
        /// Detecta todos los tokens con formato $(NombreVariable) en el script SQL.
        /// </summary>
        public static HashSet<string> DetectarTokens(string scriptSql)
        {
            var tokens = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            if (string.IsNullOrEmpty(scriptSql))
                return tokens;

            var matches = TokenRegex.Matches(scriptSql);
            foreach (Match match in matches)
            {
                if (match.Groups.Count > 1)
                {
                    tokens.Add(match.Groups[1].Value);
                }
            }

            return tokens;
        }

        /// <summary>
        /// Reemplaza tokens predeterminados y variables personalizadas en el código SQL.
        /// </summary>
        public static string ReemplazarTokens(
            string scriptSql, 
            string nombreServidor, 
            IDictionary<string, string>? variablesPersonalizadas = null)
        {
            if (string.IsNullOrEmpty(scriptSql))
                return scriptSql;

            string resultado = scriptSql;

            // 1. Tokens Nativos del Sistema
            var ahora = DateTime.Now;
            resultado = resultado.Replace("$(Servidor)", nombreServidor, StringComparison.OrdinalIgnoreCase);
            resultado = resultado.Replace("$(FechaActual)", ahora.ToString("yyyy-MM-dd"), StringComparison.OrdinalIgnoreCase);
            resultado = resultado.Replace("$(HoraActual)", ahora.ToString("HH:mm:ss"), StringComparison.OrdinalIgnoreCase);
            resultado = resultado.Replace("$(FechaHora)", ahora.ToString("yyyy-MM-dd HH:mm:ss"), StringComparison.OrdinalIgnoreCase);
            resultado = resultado.Replace("$(MesActual)", ahora.ToString("MM"), StringComparison.OrdinalIgnoreCase);
            resultado = resultado.Replace("$(AnioActual)", ahora.ToString("yyyy"), StringComparison.OrdinalIgnoreCase);

            // 2. Tokens Personalizados del Proceso o Usuario
            if (variablesPersonalizadas != null)
            {
                foreach (var kvp in variablesPersonalizadas)
                {
                    string placeholder = $"$({kvp.Key})";
                    resultado = resultado.Replace(placeholder, kvp.Value ?? string.Empty, StringComparison.OrdinalIgnoreCase);
                }
            }

            return resultado;
        }
    }
}
