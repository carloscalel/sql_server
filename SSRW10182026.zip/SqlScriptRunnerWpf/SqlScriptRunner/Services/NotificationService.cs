using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Mail;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using SqlScriptRunner.Models;

namespace SqlScriptRunner.Services
{
    public class NotificationService
    {
        private static readonly HttpClient _httpClient = new();
        private readonly AppConfig _config;
        private readonly LogService _logger;

        public NotificationService(AppConfig config, LogService logger)
        {
            _config = config;
            _logger = logger;
        }

        /// <summary>
        /// Evalúa y envía las alertas configuradas para una tarea específica tras su ejecución.
        /// </summary>
        public async Task EnviarResumenEjecucionAsync(
            string nombreTarea,
            ScriptConfig scriptConfig,
            List<ServidorProgresoItem> resultados,
            long duracionTotalMs)
        {
            var notif = scriptConfig.Notificaciones;
            if (notif == null || !notif.Habilitado)
                return;

            int total = resultados.Count;
            int exitosos = resultados.Count(r => r.Estado == EstadoServidor.Completado);
            var fallidos = resultados.Where(r => r.Estado == EstadoServidor.Error || r.Estado == EstadoServidor.Cancelado).ToList();
            bool huboErrores = fallidos.Count > 0;

            // Si está configurado para alertar únicamente en fallas y no hubo errores, salir
            if (notif.NotificarSoloSiHayError && !huboErrores)
            {
                return;
            }

            _logger.Registrar($"[Alertas] Procesando notificaciones para '{nombreTarea}' (Errores: {fallidos.Count})...");

            // 1. Envío a Microsoft Teams Webhook
            string? webhookTeams = !string.IsNullOrWhiteSpace(notif.WebhookTeams) 
                ? notif.WebhookTeams 
                : _config.Configuracion.DefaultTeamsWebhook;

            if (!string.IsNullOrWhiteSpace(webhookTeams))
            {
                await EnviarTeamsWebhookAsync(webhookTeams, nombreTarea, total, exitosos, fallidos, duracionTotalMs);
            }

            // 2. Envío por Correo Electrónico (SMTP)
            if (!string.IsNullOrWhiteSpace(notif.EmailDestinatarios) && !string.IsNullOrWhiteSpace(_config.Configuracion.SmtpHost))
            {
                await EnviarEmailAsync(notif.EmailDestinatarios, nombreTarea, total, exitosos, fallidos, duracionTotalMs);
            }
        }

        private async Task EnviarTeamsWebhookAsync(
            string webhookUrl,
            string nombreTarea,
            int total,
            int exitosos,
            List<ServidorProgresoItem> fallidos,
            long duracionTotalMs)
        {
            try
            {
                bool exitoso = fallidos.Count == 0;
                string themeColor = exitoso ? "2ECC71" : "D83B01";
                string tituloEstado = exitoso 
                    ? $"✅ [ÉXITO] Ejecución de {nombreTarea}" 
                    : $"🚨 [ALERTA] Fallas en {nombreTarea}";

                var facts = new List<object>
                {
                    new { name = "Tarea:", value = nombreTarea },
                    new { name = "Servidores Procesados:", value = $"{total}" },
                    new { name = "Completados con Éxito:", value = $"{exitosos}" },
                    new { name = "Servidores con Error:", value = $"{fallidos.Count}" },
                    new { name = "Duración Total:", value = $"{duracionTotalMs / 1000.0:F2} seg" },
                    new { name = "Fecha y Hora:", value = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") }
                };

                string detalleTexto = string.Empty;
                if (fallidos.Count > 0)
                {
                    var erroresDetalle = fallidos.Select(f => $"**{f.Servidor}**: {f.Detalle}");
                    detalleTexto = "### Errores Detectados:\n\n" + string.Join("\n\n", erroresDetalle);
                }
                else
                {
                    detalleTexto = "Todos los servidores del grupo respondieron y guardaron datos correctamente.";
                }

                var cardPayload = new
                {
                    summary = tituloEstado,
                    themeColor = themeColor,
                    title = tituloEstado,
                    sections = new[]
                    {
                        new
                        {
                            activityTitle = "SqlScriptRunner - Panel DBA",
                            activitySubtitle = "Notificación Automática de Ejecución",
                            facts = facts,
                            text = detalleTexto
                        }
                    }
                };

                string jsonContent = JsonSerializer.Serialize(cardPayload);
                using var request = new HttpRequestMessage(HttpMethod.Post, webhookUrl)
                {
                    Content = new StringContent(jsonContent, Encoding.UTF8, "application/json")
                };

                var response = await _httpClient.SendAsync(request);
                if (response.IsSuccessStatusCode)
                {
                    _logger.Registrar($"[Alertas Teams] Notificación enviada con éxito al canal de Teams.");
                }
                else
                {
                    string errResp = await response.Content.ReadAsStringAsync();
                    _logger.Registrar($"[Alertas Teams] Error al enviar a Teams (HTTP {response.StatusCode}): {errResp}");
                }
            }
            catch (Exception ex)
            {
                _logger.Registrar($"[Alertas Teams] Excepción al enviar webhook: {ex.Message}");
            }
        }

        private async Task EnviarEmailAsync(
            string destinatarios,
            string nombreTarea,
            int total,
            int exitosos,
            List<ServidorProgresoItem> fallidos,
            long duracionTotalMs)
        {
            try
            {
                var global = _config.Configuracion;
                bool exitoso = fallidos.Count == 0;
                string asunto = exitoso 
                    ? $"[SqlScriptRunner - ÉXITO] Tarea '{nombreTarea}' completada"
                    : $"[SqlScriptRunner - ALERTA] Fallas en tarea '{nombreTarea}' ({fallidos.Count} errores)";

                var htmlBuilder = new StringBuilder();
                htmlBuilder.Append($"<h2>Resumen de Ejecución: {nombreTarea}</h2>");
                htmlBuilder.Append($"<p><b>Fecha:</b> {DateTime.Now:yyyy-MM-dd HH:mm:ss}<br>");
                htmlBuilder.Append($"<b>Total Servidores:</b> {total}<br>");
                htmlBuilder.Append($"<b>Exitosos:</b> {exitosos}<br>");
                htmlBuilder.Append($"<b>Fallidos:</b> {fallidos.Count}<br>");
                htmlBuilder.Append($"<b>Tiempo Total:</b> {duracionTotalMs / 1000.0:F2}s</p>");

                if (fallidos.Count > 0)
                {
                    htmlBuilder.Append("<h3 style='color:red;'>Detalle de Errores:</h3><ul>");
                    foreach (var f in fallidos)
                    {
                        htmlBuilder.Append($"<li><b>{f.Servidor}:</b> {WebUtility.HtmlEncode(f.Detalle)}</li>");
                    }
                    htmlBuilder.Append("</ul>");
                }

                using var mail = new MailMessage();
                mail.From = new MailAddress(string.IsNullOrWhiteSpace(global.SmtpRemitente) ? "sqlscriptrunner@dba.local" : global.SmtpRemitente);
                
                foreach (var dest in destinatarios.Split(new[] { ';', ',' }, StringSplitOptions.RemoveEmptyEntries))
                {
                    mail.To.Add(dest.Trim());
                }

                mail.Subject = asunto;
                mail.Body = htmlBuilder.ToString();
                mail.IsBodyHtml = true;

                using var client = new SmtpClient(global.SmtpHost, global.SmtpPort)
                {
                    EnableSsl = global.SmtpSsl
                };

                if (!string.IsNullOrWhiteSpace(global.SmtpUsuario))
                {
                    string pass = SecurityService.DesencriptarPassword(global.SmtpPasswordCifrado, _config);
                    client.Credentials = new NetworkCredential(global.SmtpUsuario, pass);
                }

                await client.SendMailAsync(mail);
                _logger.Registrar($"[Alertas Email] Correo enviado exitosamente a: {destinatarios}");
            }
            catch (Exception ex)
            {
                _logger.Registrar($"[Alertas Email] Error al enviar correo SMTP: {ex.Message}");
            }
        }
    }
}
