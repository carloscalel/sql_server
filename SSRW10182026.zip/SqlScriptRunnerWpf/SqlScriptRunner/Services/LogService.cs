using System;
using System.IO;

namespace SqlScriptRunner.Services
{
    public class LogService
    {
        private readonly string _baseLogsDir;
        private string? _currentLogFile;
        private readonly object _lock = new();

        public event Action<string>? OnLogMessage;

        public LogService(string? baseDirectory = null)
        {
            string root = baseDirectory ?? AppDomain.CurrentDomain.BaseDirectory;
            _baseLogsDir = Path.Combine(root, "Logs");
            Directory.CreateDirectory(_baseLogsDir);
        }

        public string BaseLogsDirectory => _baseLogsDir;

        /// <summary>
        /// Inicia una nueva sesión de log para la tarea dada en una subcarpeta dedicada.
        /// </summary>
        public void IniciarSesion(string nombreTarea)
        {
            lock (_lock)
            {
                string safeName = string.Join("_", nombreTarea.Split(Path.GetInvalidFileNameChars()));
                string taskDir = Path.Combine(_baseLogsDir, safeName);
                Directory.CreateDirectory(taskDir);

                string timestamp = DateTime.Now.ToString("yyyyMMdd_HHmmss");
                _currentLogFile = Path.Combine(taskDir, $"ejecucion_{timestamp}.log");

                Registrar($"=== SESIÓN INICIADA: Tarea [{nombreTarea}] - {DateTime.Now:yyyy-MM-dd HH:mm:ss} ===");
            }
        }

        /// <summary>
        /// Registra un mensaje en el archivo de log activo y dispara el evento en vivo para la UI.
        /// </summary>
        public void Registrar(string mensaje)
        {
            string linea = $"[{DateTime.Now:yyyy-MM-dd HH:mm:ss}] {mensaje}";

            lock (_lock)
            {
                if (!string.IsNullOrEmpty(_currentLogFile))
                {
                    try
                    {
                        File.AppendAllText(_currentLogFile, linea + Environment.NewLine);
                    }
                    catch
                    {
                        // Fallback silencioso para no detener la ejecución si el archivo está momentáneamente bloqueado
                    }
                }
            }

            OnLogMessage?.Invoke(linea);
        }

        /// <summary>
        /// Rutina de auto-limpieza inteligente que purga archivos .log con más de N días de antigüedad.
        /// </summary>
        public int LimpiarLogsAntiguos(int diasRetencion = 15)
        {
            int eliminados = 0;
            try
            {
                if (!Directory.Exists(_baseLogsDir))
                    return 0;

                DateTime limiteFecha = DateTime.Now.AddDays(-diasRetencion);
                var archivos = Directory.GetFiles(_baseLogsDir, "*.log", SearchOption.AllDirectories);

                foreach (var archivo in archivos)
                {
                    try
                    {
                        var info = new FileInfo(archivo);
                        if (info.LastWriteTime < limiteFecha)
                        {
                            info.Delete();
                            eliminados++;
                        }
                    }
                    catch
                    {
                        // Archivo en uso o sin permisos, se omitirá hasta la siguiente corrida
                    }
                }
            }
            catch
            {
                // Manejo tolerante a fallos
            }

            return eliminados;
        }
    }
}
