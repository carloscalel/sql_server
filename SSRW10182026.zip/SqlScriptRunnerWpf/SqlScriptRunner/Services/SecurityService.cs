using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Threading.Tasks;
using Microsoft.Data.SqlClient;
using SqlScriptRunner.Models;

namespace SqlScriptRunner.Services
{
    /// <summary>
    /// Modelo auxiliar para la exportación/importación segura de paquetes de credenciales entre servidores.
    /// </summary>
    public class CredencialTransferenciaItem
    {
        [JsonPropertyName("Servidor")]
        public string Servidor { get; set; } = string.Empty;

        [JsonPropertyName("Usuario")]
        public string? Usuario { get; set; }

        [JsonPropertyName("PasswordPlano")]
        public string? PasswordPlano { get; set; }
    }

    /// <summary>
    /// Servicio de seguridad y criptografía para SqlScriptRunner.
    /// Soporta modo local de alta seguridad (Windows DPAPI) y modo portátil para múltiples servidores (AES-256).
    /// Provee herramientas de diagnóstico, re-cifrado, prueba de conexión y migración entre equipos.
    /// </summary>
    public static class SecurityService
    {
        public const string PrefijoAes = "AES:";
        public const string PrefijoDpapi = "DPAPI:";
        private const int Pbkdf2Iteraciones = 100_000;
        private const int SaltBytesLength = 16;
        private const int IvBytesLength = 16;
        private const int KeyBytesLength = 32; // AES-256

        #region CIFRADO Y DESCIFRADO CENTRALIZADO

        /// <summary>
        /// Cifra una contraseña en texto plano utilizando DPAPI de Windows.
        /// </summary>
        public static string EncriptarPasswordDpapi(string passwordPlano, DataProtectionScope scope = DataProtectionScope.LocalMachine)
        {
            if (string.IsNullOrEmpty(passwordPlano))
                return string.Empty;

            byte[] bytesPlanos = Encoding.UTF8.GetBytes(passwordPlano);
            byte[] bytesCifrados = ProtectedData.Protect(bytesPlanos, null, scope);
            return $"{PrefijoDpapi}{Convert.ToBase64String(bytesCifrados)}";
        }

        /// <summary>
        /// Cifra una contraseña en texto plano utilizando AES-256 con PBKDF2 (SHA-256) y un Salt/IV criptográficamente aleatorios.
        /// Formato: AES:[Salt(16)][IV(16)][CipherBytes]
        /// </summary>
        public static string EncriptarPasswordAes(string passwordPlano, string passphrase)
        {
            if (string.IsNullOrEmpty(passwordPlano))
                return string.Empty;

            if (string.IsNullOrWhiteSpace(passphrase))
                throw new ArgumentException("La clave maestra o contraseña de cifrado AES no puede estar vacía.", nameof(passphrase));

            byte[] salt = RandomNumberGenerator.GetBytes(SaltBytesLength);
            byte[] iv = RandomNumberGenerator.GetBytes(IvBytesLength);

            using var kdf = new Rfc2898DeriveBytes(passphrase, salt, Pbkdf2Iteraciones, HashAlgorithmName.SHA256);
            byte[] key = kdf.GetBytes(KeyBytesLength);

            using var aes = Aes.Create();
            aes.Key = key;
            aes.IV = iv;
            aes.Mode = CipherMode.CBC;
            aes.Padding = PaddingMode.PKCS7;

            byte[] plainBytes = Encoding.UTF8.GetBytes(passwordPlano);
            using var encryptor = aes.CreateEncryptor();
            byte[] cipherBytes = encryptor.TransformFinalBlock(plainBytes, 0, plainBytes.Length);

            // Empaquetar: Salt (16) + IV (16) + CipherBytes
            byte[] payload = new byte[salt.Length + iv.Length + cipherBytes.Length];
            Buffer.BlockCopy(salt, 0, payload, 0, salt.Length);
            Buffer.BlockCopy(iv, 0, payload, salt.Length, iv.Length);
            Buffer.BlockCopy(cipherBytes, 0, payload, salt.Length + iv.Length, cipherBytes.Length);

            return $"{PrefijoAes}{Convert.ToBase64String(payload)}";
        }

        /// <summary>
        /// Intenta obtener la clave maestra para descifrar tokens AES siguiendo un orden de prioridad:
        /// 1) Clave manual suministrada en la llamada
        /// 2) Variable de entorno SQLSCRIPTRUNNER_MASTER_KEY
        /// 3) Clave configurada en appsettings.json (Configuracion.ClaveMaestraPortabilidad)
        /// 4) Archivo sqlscriptrunner.key en la raíz de la aplicación
        /// </summary>
        public static string? ObtenerClaveMaestra(AppConfig? config = null, string? passphraseManual = null)
        {
            if (!string.IsNullOrWhiteSpace(passphraseManual))
                return passphraseManual.Trim();

            string? envKey = Environment.GetEnvironmentVariable("SQLSCRIPTRUNNER_MASTER_KEY");
            if (!string.IsNullOrWhiteSpace(envKey))
                return envKey.Trim();

            if (config != null && !string.IsNullOrWhiteSpace(config.Configuracion.ClaveMaestraPortabilidad))
                return config.Configuracion.ClaveMaestraPortabilidad.Trim();

            try
            {
                string keyFilePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "sqlscriptrunner.key");
                if (File.Exists(keyFilePath))
                {
                    string fileKey = File.ReadAllText(keyFilePath).Trim();
                    if (!string.IsNullOrWhiteSpace(fileKey))
                        return fileKey;
                }
            }
            catch
            {
                // Ignorar error al leer archivo de llave
            }

            return null;
        }

        /// <summary>
        /// Descifra una contraseña cifrada (soporta DPAPI LocalMachine, DPAPI CurrentUser y AES-256).
        /// Mantiene compatibilidad total hacia atrás con hashes Base64 legacy de DPAPI sin prefijo.
        /// </summary>
        public static string DesencriptarPassword(string? passwordCifrado, AppConfig? config = null, string? passphraseManual = null)
        {
            if (string.IsNullOrWhiteSpace(passwordCifrado))
                return string.Empty;

            string raw = passwordCifrado.Trim();

            // CASO 1: Token Cifrado con AES-256 (Portátil)
            if (raw.StartsWith(PrefijoAes, StringComparison.OrdinalIgnoreCase))
            {
                string b64 = raw.Substring(PrefijoAes.Length).Trim();
                string? masterKey = ObtenerClaveMaestra(config, passphraseManual);

                if (string.IsNullOrWhiteSpace(masterKey))
                {
                    throw new InvalidOperationException(
                        "La credencial está cifrada con AES-256 (Modo Portátil), pero no se encontró la Clave Maestra. " +
                        "Configure la variable de entorno 'SQLSCRIPTRUNNER_MASTER_KEY' o la Clave Maestra en la Configuración Global.");
                }

                try
                {
                    byte[] payload = Convert.FromBase64String(b64);
                    if (payload.Length < SaltBytesLength + IvBytesLength + 1)
                        throw new FormatException("El tamaño del hash AES es insuficiente o está corrupto.");

                    byte[] salt = new byte[SaltBytesLength];
                    byte[] iv = new byte[IvBytesLength];
                    int cipherLength = payload.Length - SaltBytesLength - IvBytesLength;
                    byte[] cipherBytes = new byte[cipherLength];

                    Buffer.BlockCopy(payload, 0, salt, 0, SaltBytesLength);
                    Buffer.BlockCopy(payload, SaltBytesLength, iv, 0, IvBytesLength);
                    Buffer.BlockCopy(payload, SaltBytesLength + IvBytesLength, cipherBytes, 0, cipherLength);

                    using var kdf = new Rfc2898DeriveBytes(masterKey, salt, Pbkdf2Iteraciones, HashAlgorithmName.SHA256);
                    byte[] key = kdf.GetBytes(KeyBytesLength);

                    using var aes = Aes.Create();
                    aes.Key = key;
                    aes.IV = iv;
                    aes.Mode = CipherMode.CBC;
                    aes.Padding = PaddingMode.PKCS7;

                    using var decryptor = aes.CreateDecryptor();
                    byte[] plainBytes = decryptor.TransformFinalBlock(cipherBytes, 0, cipherBytes.Length);
                    return Encoding.UTF8.GetString(plainBytes);
                }
                catch (CryptographicException ex)
                {
                    throw new InvalidOperationException(
                        "No se pudo descifrar la credencial AES-256: la Clave Maestra proporcionada no coincide o los datos están corruptos.", ex);
                }
                catch (Exception ex)
                {
                    throw new InvalidOperationException($"Error al procesar credencial AES-256: {ex.Message}", ex);
                }
            }

            // CASO 2: Token DPAPI (Con prefijo DPAPI: o formato Base64 nativo directo)
            string dpapiB64 = raw;
            if (raw.StartsWith(PrefijoDpapi, StringComparison.OrdinalIgnoreCase))
            {
                dpapiB64 = raw.Substring(PrefijoDpapi.Length).Trim();
            }

            try
            {
                byte[] bytesCifrados = Convert.FromBase64String(dpapiB64);
                try
                {
                    byte[] bytesPlanos = ProtectedData.Unprotect(bytesCifrados, null, DataProtectionScope.LocalMachine);
                    return Encoding.UTF8.GetString(bytesPlanos);
                }
                catch
                {
                    // Fallback a CurrentUser por si fue generado bajo ese contexto
                    byte[] bytesPlanos = ProtectedData.Unprotect(bytesCifrados, null, DataProtectionScope.CurrentUser);
                    return Encoding.UTF8.GetString(bytesPlanos);
                }
            }
            catch (CryptographicException ex)
            {
                throw new InvalidOperationException(
                    "Esta credencial fue cifrada con DPAPI en otro equipo o bajo otra cuenta de Windows y no puede ser descifrada aquí. " +
                    "Por favor vuelva a cifrarla en este servidor desde el Gestor de Configuración o use el formato AES portátil.", ex);
            }
            catch (Exception ex)
            {
                throw new InvalidOperationException($"Error al descifrar contraseña DPAPI: {ex.Message}", ex);
            }
        }

        /// <summary>
        /// Sobrecarga para mantener retrocompatibilidad directa con llamadas que solo pasan el string cifrado.
        /// </summary>
        public static string DesencriptarPassword(string? passwordCifrado)
        {
            return DesencriptarPassword(passwordCifrado, null, null);
        }

        #endregion

        #region DIAGNÓSTICO Y VALIDACIÓN DE HASH

        /// <summary>
        /// Prueba si una credencial cifrada puede ser descifrada en este equipo sin arrojar excepciones.
        /// Provee información sobre el algoritmo utilizado y el error si falló.
        /// </summary>
        public static (bool Exito, string? PasswordPlano, string? Error, string TipoCifrado) ProbarDescifrado(
            string? hashCifrado,
            AppConfig? config = null,
            string? passphraseManual = null)
        {
            if (string.IsNullOrWhiteSpace(hashCifrado))
            {
                return (true, string.Empty, null, "Sin Contraseña");
            }

            string raw = hashCifrado.Trim();
            string tipoCifrado = raw.StartsWith(PrefijoAes, StringComparison.OrdinalIgnoreCase)
                ? "AES-256 (Portátil)"
                : "DPAPI (Local)";

            try
            {
                string plano = DesencriptarPassword(raw, config, passphraseManual);
                return (true, plano, null, tipoCifrado);
            }
            catch (Exception ex)
            {
                return (false, null, ex.Message, tipoCifrado);
            }
        }

        #endregion

        #region EXPORTACIÓN E IMPORTACIÓN PORTÁTIL ENTRE EQUIPOS

        /// <summary>
        /// Empaqueta todas las credenciales registradas en la configuración y las cifra con AES-256 usando una contraseña temporal de transferencia.
        /// Permite mover de forma segura todas las credenciales a otro servidor sin exponer texto plano.
        /// </summary>
        public static string ExportarPaqueteCredenciales(AppConfig config, string passwordTransferencia, out int totalExportadas, out List<string> servidoresOmitidos)
        {
            if (string.IsNullOrWhiteSpace(passwordTransferencia))
                throw new ArgumentException("Debe ingresar una contraseña de transferencia para proteger el paquete.", nameof(passwordTransferencia));

            var items = new List<CredencialTransferenciaItem>();
            servidoresOmitidos = new List<string>();

            foreach (var kvp in config.CredencialesServidores)
            {
                string servidor = kvp.Key;
                var cred = kvp.Value;

                var (exito, passPlano, _, _) = ProbarDescifrado(cred.PasswordCifrado, config);
                if (exito)
                {
                    items.Add(new CredencialTransferenciaItem
                    {
                        Servidor = servidor,
                        Usuario = cred.Usuario,
                        PasswordPlano = passPlano
                    });
                }
                else
                {
                    servidoresOmitidos.Add(servidor);
                }
            }

            totalExportadas = items.Count;
            string json = JsonSerializer.Serialize(items, new JsonSerializerOptions { WriteIndented = false });
            return EncriptarPasswordAes(json, passwordTransferencia);
        }

        /// <summary>
        /// Importa un paquete exportado desde otro servidor, descifra sus credenciales con la clave de transferencia y
        /// las re-cifra localmente usando DPAPI del equipo actual (o AES-256 si se desea portabilidad persistente).
        /// </summary>
        public static int ImportarPaqueteCredenciales(
            string paqueteCifrado,
            string passwordTransferencia,
            AppConfig config,
            bool cifrarConDpapi = true,
            string? passphraseAes = null)
        {
            if (string.IsNullOrWhiteSpace(paqueteCifrado))
                throw new ArgumentException("El paquete de credenciales está vacío.", nameof(paqueteCifrado));

            if (string.IsNullOrWhiteSpace(passwordTransferencia))
                throw new ArgumentException("Debe especificar la contraseña de transferencia usada al exportar.", nameof(passwordTransferencia));

            // Descifrar el contenedor
            string json = DesencriptarPassword(paqueteCifrado, null, passwordTransferencia);
            var items = JsonSerializer.Deserialize<List<CredencialTransferenciaItem>>(json);

            if (items == null || items.Count == 0)
                return 0;

            int procesadas = 0;
            foreach (var item in items)
            {
                if (string.IsNullOrWhiteSpace(item.Servidor))
                    continue;

                string passPlano = item.PasswordPlano ?? string.Empty;
                string nuevoHashCifrado;

                if (cifrarConDpapi)
                {
                    nuevoHashCifrado = EncriptarPasswordDpapi(passPlano, DataProtectionScope.LocalMachine);
                }
                else
                {
                    string passClave = !string.IsNullOrWhiteSpace(passphraseAes) ? passphraseAes : passwordTransferencia;
                    nuevoHashCifrado = EncriptarPasswordAes(passPlano, passClave);
                }

                config.CredencialesServidores[item.Servidor] = new CredencialServidor
                {
                    Usuario = item.Usuario,
                    PasswordCifrado = nuevoHashCifrado
                };

                procesadas++;
            }

            return procesadas;
        }

        #endregion

        #region PRUEBA DE CONEXIÓN SQL SERVER

        /// <summary>
        /// Realiza una prueba de conexión rápida con el servidor SQL indicado, midiendo la latencia de respuesta
        /// y verificando la validez del usuario y contraseña configurados.
        /// </summary>
        public static async Task<(bool Exito, string Mensaje, TimeSpan Latencia)> ProbarConexionSqlAsync(
            string servidor,
            string? usuario,
            string? passwordPlano,
            int timeoutSegundos = 6)
        {
            if (string.IsNullOrWhiteSpace(servidor))
                return (false, "El nombre del servidor no puede estar vacío.", TimeSpan.Zero);

            var sw = Stopwatch.StartNew();

            var builder = new SqlConnectionStringBuilder
            {
                DataSource = servidor,
                InitialCatalog = "master",
                ConnectTimeout = timeoutSegundos,
                CommandTimeout = timeoutSegundos,
                TrustServerCertificate = true,
                ApplicationName = "SqlScriptRunner-CredTester"
            };

            if (!string.IsNullOrWhiteSpace(usuario))
            {
                builder.IntegratedSecurity = false;
                builder.UserID = usuario;
                builder.Password = passwordPlano ?? string.Empty;
            }
            else
            {
                builder.IntegratedSecurity = true;
            }

            try
            {
                await using var connection = new SqlConnection(builder.ConnectionString);
                await connection.OpenAsync();

                await using var cmd = new SqlCommand("SELECT @@SERVERNAME, SERVERPROPERTY('ProductVersion'), SERVERPROPERTY('ProductLevel')", connection);
                await using var reader = await cmd.ExecuteReaderAsync();

                string versionInfo = string.Empty;
                if (await reader.ReadAsync())
                {
                    string srvName = reader.GetString(0);
                    string prodVer = reader.GetValue(1)?.ToString() ?? string.Empty;
                    string prodLvl = reader.GetValue(2)?.ToString() ?? string.Empty;
                    versionInfo = $"Instancia: {srvName} (v{prodVer} {prodLvl})";
                }

                sw.Stop();
                return (true, $"¡Conexión exitosa! {versionInfo}", sw.Elapsed);
            }
            catch (SqlException ex)
            {
                sw.Stop();
                string causa = ex.Number switch
                {
                    18456 => $"Error de inicio de sesión (Login Failed para usuario '{usuario}'). Verifique usuario y contraseña.",
                    53 or 2 => "No se pudo encontrar o alcanzar el servidor/instancia. Verifique el nombre del host o el servicio SQL Browser.",
                    -2 => "Tiempo de espera agotado (Timeout al conectar). El servidor no respondió dentro del plazo establecido.",
                    _ => $"Error SQL ({ex.Number}): {ex.Message}"
                };
                return (false, causa, sw.Elapsed);
            }
            catch (Exception ex)
            {
                sw.Stop();
                return (false, $"Error de conexión: {ex.Message}", sw.Elapsed);
            }
        }

        #endregion

        #region CONEXIONES DE APLICACIÓN

        /// <summary>
        /// Construye el connection string para un servidor determinado según appsettings.json.
        /// Si existen credenciales explícitas en CredencialesServidores se usa autenticación SQL,
        /// de lo contrario se utiliza autenticación integrada de Windows.
        /// </summary>
        public static string ConstruirConnectionString(string servidor, string baseDatos, AppConfig config, int timeoutSegundos = 30)
        {
            var builder = new SqlConnectionStringBuilder
            {
                DataSource = servidor,
                InitialCatalog = string.IsNullOrWhiteSpace(baseDatos) ? "master" : baseDatos,
                ConnectTimeout = timeoutSegundos,
                CommandTimeout = timeoutSegundos,
                TrustServerCertificate = true,
                ApplicationName = "SqlScriptRunner"
            };

            if (config.CredencialesServidores.TryGetValue(servidor, out var cred) && !string.IsNullOrWhiteSpace(cred.Usuario))
            {
                builder.IntegratedSecurity = false;
                builder.UserID = cred.Usuario;
                builder.Password = DesencriptarPassword(cred.PasswordCifrado, config);
            }
            else
            {
                builder.IntegratedSecurity = true;
            }

            return builder.ConnectionString;
        }

        /// <summary>
        /// Construye la cadena de conexión hacia el servidor central (adminDB).
        /// </summary>
        public static string ConstruirConnectionStringCentral(AppConfig config)
        {
            return ConstruirConnectionString(
                config.Configuracion.ServidorCentral,
                config.Configuracion.BaseDatosCentral,
                config,
                config.Configuracion.TimeoutPredeterminadoSegundos
            );
        }

        #endregion
    }
}
