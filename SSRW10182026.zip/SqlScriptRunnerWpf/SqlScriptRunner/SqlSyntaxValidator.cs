using System.IO;
using System.Collections.Generic;
using Microsoft.SqlServer.TransactSql.ScriptDom;

public static class SqlSyntaxValidator
{
    public static (bool EsValido, List<string> Errores) ValidarScript(string codigoSql)
    {
        var parser = new TSql160Parser(true);
        using var reader = new StringReader(codigoSql);
        
        parser.Parse(reader, out var errores);
        
        var listaErrores = new List<string>();
        if (errores != null && errores.Count > 0)
        {
            foreach (var err in errores)
            {
                listaErrores.Add($"Línea {err.Line}, Col {err.Column}: {err.Message}");
            }
        }

        return (listaErrores.Count == 0, listaErrores);
    }
}
