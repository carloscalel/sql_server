using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.IO;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Threading;
using ICSharpCode.AvalonEdit.Highlighting;
using SqlScriptRunner.Models;
using SqlScriptRunner.Services;

namespace SqlScriptRunner
{
    public partial class MainWindow : Window
    {
        private readonly string _baseDirectory = AppDomain.CurrentDomain.BaseDirectory;
        private AppConfig _config = new();
        private LogService _logger = null!;
        private CentralDatabaseService _centralDb = null!;
        private ScriptExecutionEngine _engine = null!;

        private ObservableCollection<ServidorProgresoItem> _servidoresProgreso = new();
        private CancellationTokenSource? _cts;
        private DispatcherTimer? _ejecucionTimer;
        private Stopwatch _stopwatch = new();
        private string? _archivoSqlRelativoActual;

        // Variables del Visor interactivo adminDB
        private List<string> _todasLasTablasCentrales = new();
        private bool _actualizandoConsulta = false;
        private bool _isViewLoaded = false;

        public MainWindow()
        {
            InitializeComponent();
            _isViewLoaded = true;
            InicializarServicios();
            ConfigurarEditorSql();
            CargarConfiguracion();
        }

        private void InicializarServicios()
        {
            _logger = new LogService(_baseDirectory);
            _logger.OnLogMessage += MensajeLogRecibido;

            // Vincular colección observable al DataGrid
            DgServidores.ItemsSource = _servidoresProgreso;

            // Configurar timer para medir tiempo en pantalla
            _ejecucionTimer = new DispatcherTimer
            {
                Interval = TimeSpan.FromMilliseconds(500)
            };
            _ejecucionTimer.Tick += (s, e) =>
            {
                LblTiempoTranscurrido.Text = $"Tiempo: {_stopwatch.Elapsed.TotalSeconds:F1}s";
            };
        }

        private void MensajeLogRecibido(string mensaje)
        {
            Dispatcher.Invoke(() =>
            {
                TxtLogConsola.AppendText(mensaje + Environment.NewLine);
                TxtLogConsola.ScrollToEnd();
            });
        }

        private void ConfigurarEditorSql()
        {
            try
            {
                SqlEditor.SyntaxHighlighting = HighlightingManager.Instance.GetDefinition("SQL");
            }
            catch
            {
                // Fallback por si la definición de syntax highlighting no está disponible
            }
        }

        private void CargarConfiguracion()
        {
            LbTareas.Items.Clear();
            string configPath = Path.Combine(_baseDirectory, "appsettings.json");

            if (File.Exists(configPath))
            {
                try
                {
                    string jsonContent = File.ReadAllText(configPath);
                    var opciones = new JsonSerializerOptions
                    {
                        PropertyNameCaseInsensitive = true,
                        ReadCommentHandling = JsonCommentHandling.Skip,
                        AllowTrailingCommas = true
                    };

                    _config = JsonSerializer.Deserialize<AppConfig>(jsonContent, opciones) ?? new AppConfig();

                    // Instanciar servicios dependientes de la configuración
                    _centralDb = new CentralDatabaseService(_config, _logger);
                    _engine = new ScriptExecutionEngine(_config, _logger, _centralDb);

                    // Ejecutar auto-limpieza inteligente de logs (> 15 días o según configuración)
                    int diasRetencion = _config.Configuracion.DiasRetencionLogs > 0 ? _config.Configuracion.DiasRetencionLogs : 15;
                    Task.Run(() =>
                    {
                        int eliminados = _logger.LimpiarLogsAntiguos(diasRetencion);
                        if (eliminados > 0)
                        {
                            _logger.Registrar($"[Mantenimiento de Logs] Se purgaron {eliminados} archivos de log con más de {diasRetencion} días de antigüedad.");
                        }
                    });

                    // Cargar lista de tareas
                    foreach (var key in _config.Scripts.Keys)
                    {
                        LbTareas.Items.Add(key);
                    }

                    if (LbTareas.Items.Count > 0)
                    {
                        LbTareas.SelectedIndex = 0;
                    }

                    _logger.Registrar($"Configuración cargada. Servidor Central: '{_config.Configuracion.ServidorCentral}', Base Central: '{_config.Configuracion.BaseDatosCentral}'. Tareas: {_config.Scripts.Count}.");

                    // Verificación preventiva de compatibilidad de credenciales en este equipo (portabilidad)
                    var incompatibles = new List<string>();
                    foreach (var kvp in _config.CredencialesServidores)
                    {
                        var (exito, _, _, _) = SecurityService.ProbarDescifrado(kvp.Value.PasswordCifrado, _config);
                        if (!exito) incompatibles.Add(kvp.Key);
                    }
                    if (incompatibles.Count > 0)
                    {
                        _logger.Registrar($"[Seguridad] ⚠️ Advertencia: {incompatibles.Count} credencial(es) no pueden ser descifradas en este equipo ({string.Join(", ", incompatibles)}). Cifradas en otro servidor o sin clave AES. Actualícelas en el Gestor de Configuración.");
                    }

                    // Precargar lista de tablas para el Visor adminDB
                    CargarTablasAdminDbAsync();
                }
                catch (Exception ex)
                {
                    ModernMessageBox.Show($"Error al cargar appsettings.json: {ex.Message}", "Error de Configuración", MessageBoxButton.OK, MessageBoxImage.Error, this);
                }
            }
            else
            {
                ModernMessageBox.Show($"No se encontró el archivo de configuración en:\n{configPath}", "Archivo no encontrado", MessageBoxButton.OK, MessageBoxImage.Warning, this);
            }
        }

        private void LbTareas_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            if (LbTareas.SelectedItem == null)
                return;

            string tarea = LbTareas.SelectedItem.ToString()!;
            if (!_config.Scripts.TryGetValue(tarea, out var scriptConfig))
                return;

            _archivoSqlRelativoActual = scriptConfig.Archivo;
            string rutaScript = Path.Combine(_baseDirectory, scriptConfig.Archivo);

            if (File.Exists(rutaScript))
            {
                try
                {
                    SqlEditor.Text = File.ReadAllText(rutaScript);
                    LblArchivoActual.Text = $"Editando: {scriptConfig.Archivo}";
                    LblEstadoGuardado.Text = string.Empty;
                }
                catch (Exception ex)
                {
                    SqlEditor.Text = $"-- Error al leer archivo: {ex.Message}";
                }
            }
            else
            {
                SqlEditor.Text = $"-- No se encontró el archivo físico en:\n-- {rutaScript}";
                LblArchivoActual.Text = $"Editando: {scriptConfig.Archivo} (No encontrado)";
            }

            // Precargar los servidores en la pestaña de monitoreo
            _servidoresProgreso.Clear();
            if (_config.GruposServidores.TryGetValue(scriptConfig.GrupoServidores, out var listaServidores))
            {
                foreach (var srv in listaServidores)
                {
                    _servidoresProgreso.Add(new ServidorProgresoItem
                    {
                        Servidor = srv,
                        Estado = EstadoServidor.Pendiente,
                        Detalle = "En espera de ejecución"
                    });
                }
            }

            PbProgresoGlobal.Value = 0;
            LblProgresoTexto.Text = $"Grupo: '{scriptConfig.GrupoServidores}' ({_servidoresProgreso.Count} servidores configurados)";
        }

        private async void BtnEjecutar_Click(object sender, RoutedEventArgs e)
        {
            if (LbTareas.SelectedItem == null)
            {
                ModernMessageBox.Show("Por favor seleccione una tarea para ejecutar.", "Aviso", MessageBoxButton.OK, MessageBoxImage.Warning, this);
                return;
            }

            string nombreTarea = LbTareas.SelectedItem.ToString()!;
            if (!_config.Scripts.TryGetValue(nombreTarea, out var scriptConfig))
            {
                ModernMessageBox.Show($"No se encontró la configuración para la tarea '{nombreTarea}'.", "Error", MessageBoxButton.OK, MessageBoxImage.Error, this);
                return;
            }

            if (!scriptConfig.Habilitado)
            {
                ModernMessageBox.Show($"La tarea '{nombreTarea}' está marcada como deshabilitada en la configuración.", "Tarea Deshabilitada", MessageBoxButton.OK, MessageBoxImage.Information, this);
                return;
            }

            string codigoSql = SqlEditor.Text;
            if (string.IsNullOrWhiteSpace(codigoSql))
            {
                ModernMessageBox.Show("El script T-SQL a ejecutar está vacío.", "Aviso", MessageBoxButton.OK, MessageBoxImage.Warning, this);
                return;
            }

            // Preparar lista de servidores
            if (!_config.GruposServidores.TryGetValue(scriptConfig.GrupoServidores, out var servidores) || servidores.Count == 0)
            {
                ModernMessageBox.Show($"El grupo de servidores '{scriptConfig.GrupoServidores}' no existe o no tiene servidores configurados.", "Aviso", MessageBoxButton.OK, MessageBoxImage.Warning, this);
                return;
            }

            // Cambiar a la pestaña de monitoreo para visibilidad inmediata
            TabMonitor.IsSelected = true;

            // Reinicializar visuales
            _servidoresProgreso.Clear();
            foreach (var srv in servidores)
            {
                _servidoresProgreso.Add(new ServidorProgresoItem
                {
                    Servidor = srv,
                    Estado = EstadoServidor.Pendiente,
                    Detalle = "En cola para ejecución"
                });
            }

            BtnEjecutar.IsEnabled = false;
            BtnCancelar.IsEnabled = true;
            PbProgresoGlobal.Value = 0;
            PbProgresoGlobal.Maximum = servidores.Count;
            LblProgresoTexto.Text = $"Ejecutando '{nombreTarea}' en {servidores.Count} servidores...";

            _logger.IniciarSesion(nombreTarea);
            _cts = new CancellationTokenSource();
            _stopwatch.Restart();
            _ejecucionTimer?.Start();

            try
            {
                var listaItems = new List<ServidorProgresoItem>(_servidoresProgreso);

                await _engine.EjecutarTareaAsync(
                    nombreTarea,
                    scriptConfig,
                    codigoSql,
                    listaItems,
                    (procesados, total) =>
                    {
                        Dispatcher.Invoke(() =>
                        {
                            PbProgresoGlobal.Value = procesados;
                            double pct = total > 0 ? (procesados * 100.0 / total) : 0;
                            LblProgresoTexto.Text = $"Progreso: {procesados}/{total} servidores ({pct:F0}%)";
                        });
                    },
                    _cts.Token
                );

                LblProgresoTexto.Text = $"Ejecución de '{nombreTarea}' concluida con éxito.";
            }
            catch (OperationCanceledException)
            {
                LblProgresoTexto.Text = $"Ejecución de '{nombreTarea}' cancelada por el usuario.";
            }
            catch (Exception ex)
            {
                LblProgresoTexto.Text = $"Error general: {ex.Message}";
                _logger.Registrar($"[EXCEPCIÓN NO CONTROLADA]: {ex.Message}");
            }
            finally
            {
                _stopwatch.Stop();
                _ejecucionTimer?.Stop();
                LblTiempoTranscurrido.Text = $"Tiempo total: {_stopwatch.Elapsed.TotalSeconds:F1}s";
                BtnEjecutar.IsEnabled = true;
                BtnCancelar.IsEnabled = false;
                _cts?.Dispose();
                _cts = null;
            }
        }

        private void BtnCancelar_Click(object sender, RoutedEventArgs e)
        {
            if (_cts != null && !_cts.IsCancellationRequested)
            {
                _cts.Cancel();
                _logger.Registrar("Solicitud de cancelación recibida del usuario. Deteniendo tareas...");
                BtnCancelar.IsEnabled = false;
            }
        }

        private void BtnGuardarScript_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(_archivoSqlRelativoActual))
            {
                ModernMessageBox.Show("No hay ningún archivo seleccionado para guardar.", "Aviso", MessageBoxButton.OK, MessageBoxImage.Warning, this);
                return;
            }

            try
            {
                string rutaFisica = Path.Combine(_baseDirectory, _archivoSqlRelativoActual);
                string? directorio = Path.GetDirectoryName(rutaFisica);
                if (!string.IsNullOrEmpty(directorio))
                {
                    Directory.CreateDirectory(directorio);
                }

                File.WriteAllText(rutaFisica, SqlEditor.Text);
                LblEstadoGuardado.Text = $"✔ Guardado en disco a las {DateTime.Now:HH:mm:ss}";
                _logger.Registrar($"Archivo guardado correctamente en: {rutaFisica}");
            }
            catch (Exception ex)
            {
                ModernMessageBox.Show($"Error al guardar el archivo: {ex.Message}", "Error al Guardar", MessageBoxButton.OK, MessageBoxImage.Error, this);
            }
        }

        private void BtnValidar_Click(object sender, RoutedEventArgs e)
        {
            string codigoSql = SqlEditor.Text;
            var resultado = SqlSyntaxValidator.ValidarScript(codigoSql);

            if (resultado.EsValido)
            {
                ModernMessageBox.Show("¡Sintaxis T-SQL Correcta! No se encontraron errores estructurales.", "Validación Exitosa", MessageBoxButton.OK, MessageBoxImage.Information, this);
            }
            else
            {
                string erroresStr = string.Join(Environment.NewLine, resultado.Errores);
                ModernMessageBox.Show($"Se encontraron errores de sintaxis:\n\n{erroresStr}", "Error de Sintaxis", MessageBoxButton.OK, MessageBoxImage.Warning, this);
            }
        }

        private void BtnAbrirConfigManager_Click(object sender, RoutedEventArgs e)
        {
            var configWindow = new ConfigManagerWindow
            {
                Owner = this
            };

            if (configWindow.ShowDialog() == true)
            {
                // Recargar automáticamente la configuración y reflejar los cambios en pantalla sin reiniciar
                CargarConfiguracion();
                _logger.Registrar("[Configuración] Configuración actualizada y recargada exitosamente desde el Gestor.");
            }
        }

        private void BtnAbrirEncriptador_Click(object sender, RoutedEventArgs e)
        {
            var encryptorWindow = new PasswordEncryptorWindow
            {
                Owner = this
            };
            encryptorWindow.ShowDialog();
        }

        private void BtnAbrirLogs_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string rutaLogs = _logger.BaseLogsDirectory;
                if (!Directory.Exists(rutaLogs))
                {
                    Directory.CreateDirectory(rutaLogs);
                }

                Process.Start(new ProcessStartInfo
                {
                    FileName = rutaLogs,
                    UseShellExecute = true,
                    Verb = "open"
                });
            }
            catch (Exception ex)
            {
                ModernMessageBox.Show($"No se pudo abrir la carpeta de logs: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error, this);
            }
        }

        private void BtnLimpiarLogs_Click(object sender, RoutedEventArgs e)
        {
            TxtLogConsola.Clear();
        }

        #region PING CONEXIONES (FEATURE 2)
        private async void BtnPingConexiones_Click(object sender, RoutedEventArgs e)
        {
            if (LbTareas.SelectedItem == null)
            {
                ModernMessageBox.Show("Selecciona una tarea para verificar su grupo de servidores.", "Aviso", MessageBoxButton.OK, MessageBoxImage.Warning, this);
                return;
            }

            string nombreTarea = LbTareas.SelectedItem.ToString()!;
            if (!_config.Scripts.TryGetValue(nombreTarea, out var scriptConfig))
                return;

            if (!_config.GruposServidores.TryGetValue(scriptConfig.GrupoServidores, out var servidores) || servidores.Count == 0)
            {
                ModernMessageBox.Show($"El grupo '{scriptConfig.GrupoServidores}' no tiene servidores.", "Aviso", MessageBoxButton.OK, MessageBoxImage.Warning, this);
                return;
            }

            TabMonitor.IsSelected = true;
            _servidoresProgreso.Clear();
            foreach (var srv in servidores)
            {
                _servidoresProgreso.Add(new ServidorProgresoItem
                {
                    Servidor = srv,
                    Estado = EstadoServidor.Pendiente,
                    Detalle = "En espera de prueba de ping..."
                });
            }

            BtnEjecutar.IsEnabled = false;
            BtnPingConexiones.IsEnabled = false;
            BtnCancelar.IsEnabled = true;
            PbProgresoGlobal.Value = 0;
            PbProgresoGlobal.Maximum = servidores.Count;
            LblProgresoTexto.Text = $"Probando conexión (Ping SQL) en {servidores.Count} servidores...";

            _cts = new CancellationTokenSource();
            _stopwatch.Restart();
            _ejecucionTimer?.Start();

            try
            {
                var listaItems = new List<ServidorProgresoItem>(_servidoresProgreso);
                await _engine.ProbarConectividadAsync(
                    listaItems,
                    timeoutSegundos: 5,
                    (proc, total) =>
                    {
                        Dispatcher.Invoke(() =>
                        {
                            PbProgresoGlobal.Value = proc;
                            double pct = total > 0 ? (proc * 100.0 / total) : 0;
                            LblProgresoTexto.Text = $"Ping SQL: {proc}/{total} servidores evaluados ({pct:F0}%)";
                        });
                    },
                    _cts.Token
                );

                int online = listaItems.Count(i => i.Estado == EstadoServidor.Completado);
                int offline = listaItems.Count(i => i.Estado == EstadoServidor.Error);
                LblProgresoTexto.Text = $"Ping finalizado: {online} ONLINE, {offline} OFFLINE.";
            }
            catch (OperationCanceledException)
            {
                LblProgresoTexto.Text = "Prueba de conectividad cancelada por el usuario.";
            }
            catch (Exception ex)
            {
                LblProgresoTexto.Text = $"Error en Ping: {ex.Message}";
            }
            finally
            {
                _stopwatch.Stop();
                _ejecucionTimer?.Stop();
                LblTiempoTranscurrido.Text = $"Tiempo: {_stopwatch.Elapsed.TotalSeconds:F1}s";
                BtnEjecutar.IsEnabled = true;
                BtnPingConexiones.IsEnabled = true;
                BtnCancelar.IsEnabled = false;
                _cts?.Dispose();
                _cts = null;
            }
        }
        #endregion

        #region EXPORTACIÓN CSV (FEATURE 5)
        private void BtnExportarCsv_Click(object sender, RoutedEventArgs e)
        {
            if (_servidoresProgreso.Count == 0)
            {
                ModernMessageBox.Show("No hay registros en el monitor de servidores para exportar.", "Aviso", MessageBoxButton.OK, MessageBoxImage.Information, this);
                return;
            }

            var dialog = new Microsoft.Win32.SaveFileDialog
            {
                Title = "Guardar Resumen de Ejecución",
                Filter = "Archivos CSV (*.csv)|*.csv|Todos los archivos (*.*)|*.*",
                FileName = $"Resumen_Ejecucion_{DateTime.Now:yyyyMMdd_HHmmss}.csv"
            };

            if (dialog.ShowDialog() == true)
            {
                try
                {
                    var sb = new System.Text.StringBuilder();
                    // Encabezados CSV
                    sb.AppendLine("Servidor,Estado,DuracionMs,FilasRecolectadas,Detalle,FechaExportacion");

                    foreach (var item in _servidoresProgreso)
                    {
                        string detalleLimpio = (item.Detalle ?? string.Empty).Replace("\"", "\"\"").Replace("\r", " ").Replace("\n", " ");
                        sb.AppendLine($"\"{item.Servidor}\",\"{item.EstadoTexto}\",{item.DuracionMs},{item.RegistrosObtenidos},\"{detalleLimpio}\",\"{DateTime.Now:yyyy-MM-dd HH:mm:ss}\"");
                    }

                    // Escribir con codificación UTF-8 con BOM para perfecta apertura en Excel
                    File.WriteAllText(dialog.FileName, sb.ToString(), System.Text.Encoding.UTF8);

                    var res = ModernMessageBox.Show($"Reporte exportado exitosamente a:\n{dialog.FileName}\n\n¿Deseas abrir el archivo ahora en Excel?", "Exportación Exitosa", MessageBoxButton.YesNo, MessageBoxImage.Information, this);
                    if (res == MessageBoxResult.Yes)
                    {
                        Process.Start(new ProcessStartInfo
                        {
                            FileName = dialog.FileName,
                            UseShellExecute = true
                        });
                    }
                }
                catch (Exception ex)
                {
                    ModernMessageBox.Show($"Error al exportar archivo CSV: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error, this);
                }
            }
        }
        #endregion

        #region VARIABLES DINÁMICAS (FEATURE 6)
        private void BtnVariables_Click(object sender, RoutedEventArgs e)
        {
            string codigoSql = SqlEditor.Text;
            var tokens = VariableReplacerService.DetectarTokens(codigoSql);

            var sb = new System.Text.StringBuilder();
            sb.AppendLine("=== TOKENS Y VARIABLES DINÁMICAS DETECTADAS ===");
            sb.AppendLine();

            if (tokens.Count == 0)
            {
                sb.AppendLine("No se detectaron variables en el script actual.");
                sb.AppendLine();
                sb.AppendLine("Puedes usar tokens con formato $(NombreVariable) en tu código SQL:");
                sb.AppendLine(" • $(Servidor)       -> Se reemplaza por el nombre del servidor actual.");
                sb.AppendLine(" • $(FechaActual)   -> Formato YYYY-MM-DD (ej: " + DateTime.Now.ToString("yyyy-MM-dd") + ")");
                sb.AppendLine(" • $(HoraActual)    -> Formato HH:mm:ss (ej: " + DateTime.Now.ToString("HH:mm:ss") + ")");
                sb.AppendLine(" • $(FechaHora)     -> Formato YYYY-MM-DD HH:mm:ss");
                sb.AppendLine(" • $(MesActual)     -> Mes en 2 dígitos (ej: " + DateTime.Now.ToString("MM") + ")");
                sb.AppendLine(" • $(AnioActual)    -> Año en 4 dígitos (ej: " + DateTime.Now.ToString("yyyy") + ")");
            }
            else
            {
                sb.AppendLine($"Se detectaron {tokens.Count} token(s) en este script:");
                foreach (var t in tokens)
                {
                    string tipo = t.Equals("Servidor", StringComparison.OrdinalIgnoreCase) ||
                                  t.Equals("FechaActual", StringComparison.OrdinalIgnoreCase) ||
                                  t.Equals("HoraActual", StringComparison.OrdinalIgnoreCase) ||
                                  t.Equals("FechaHora", StringComparison.OrdinalIgnoreCase)
                                  ? "[Nativo del Sistema]" : "[Variable Personalizada]";
                    sb.AppendLine($" • $({t})  {tipo}");
                }
                sb.AppendLine();
                sb.AppendLine("Estos tokens serán sustituidos automáticamente en tiempo de ejecución para cada servidor sin alterar el archivo original.");
            }

            ModernMessageBox.Show(sb.ToString(), "Variables Dinámicas del Script", MessageBoxButton.OK, MessageBoxImage.Information, this);
        }
        #endregion

        #region VISOR adminDB (CONSTRUCTOR ASISTIDO + BUSCADOR + SQL LIBRE)
        private async void CargarTablasAdminDbAsync()
        {
            try
            {
                if (_centralDb == null) return;
                _todasLasTablasCentrales = await _centralDb.ListarObjetosCentralesAsync();
                FiltrarTablasCentrales();
            }
            catch
            {
                // Manejo tolerante
            }
        }

        private void TxtBuscarTabla_TextChanged(object sender, System.Windows.Controls.TextChangedEventArgs e)
        {
            if (!_isViewLoaded) return;
            FiltrarTablasCentrales();
        }

        private void FiltrarTablasCentrales()
        {
            if (!_isViewLoaded || CboTablasCentrales == null || TxtBuscarTabla == null)
                return;

            string filtro = TxtBuscarTabla.Text.Trim();
            string? seleccionActual = CboTablasCentrales.SelectedItem?.ToString();

            CboTablasCentrales.Items.Clear();
            var filtradas = string.IsNullOrEmpty(filtro)
                ? _todasLasTablasCentrales
                : _todasLasTablasCentrales.Where(t => t.Contains(filtro, StringComparison.OrdinalIgnoreCase)).ToList();

            foreach (var t in filtradas)
            {
                CboTablasCentrales.Items.Add(t);
            }

            if (CboTablasCentrales.Items.Count > 0)
            {
                if (!string.IsNullOrEmpty(seleccionActual) && CboTablasCentrales.Items.Contains(seleccionActual))
                {
                    CboTablasCentrales.SelectedItem = seleccionActual;
                }
                else
                {
                    // Preferir dbo.HealthStatus si está presente
                    int idx = -1;
                    for (int i = 0; i < CboTablasCentrales.Items.Count; i++)
                    {
                        if (CboTablasCentrales.Items[i]?.ToString()?.Contains("HealthStatus", StringComparison.OrdinalIgnoreCase) == true)
                        {
                            idx = i;
                            break;
                        }
                    }
                    CboTablasCentrales.SelectedIndex = idx >= 0 ? idx : 0;
                }
            }
        }

        private async void CboTablasCentrales_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            if (!_isViewLoaded || CboTablasCentrales == null)
                return;

            if (CboTablasCentrales.SelectedItem == null)
            {
                CboColumnaOrden?.Items.Clear();
                return;
            }

            string objeto = CboTablasCentrales.SelectedItem.ToString()!;
            await CargarColumnasTablaCentralAsync(objeto);
            ActualizarConsultaGenerada();
        }

        private async Task CargarColumnasTablaCentralAsync(string objeto)
        {
            try
            {
                _actualizandoConsulta = true;
                CboColumnaOrden.Items.Clear();
                CboColumnaOrden.Items.Add("(Sin ordenación específica)");

                var columnas = await _centralDb.ListarColumnasObjetoAsync(objeto);
                int idxRecomendado = 0;
                int currentIdx = 1;

                foreach (var col in columnas)
                {
                    CboColumnaOrden.Items.Add(col);

                    // Recomendar columna de ordenación por fecha o Id
                    if (idxRecomendado == 0 && (
                        col.Contains("Fecha", StringComparison.OrdinalIgnoreCase) ||
                        col.Contains("Date", StringComparison.OrdinalIgnoreCase) ||
                        col.Contains("Time", StringComparison.OrdinalIgnoreCase) ||
                        col.Equals("Id", StringComparison.OrdinalIgnoreCase)))
                    {
                        idxRecomendado = currentIdx;
                    }
                    currentIdx++;
                }

                CboColumnaOrden.SelectedIndex = idxRecomendado;
            }
            catch
            {
                CboColumnaOrden.SelectedIndex = 0;
            }
            finally
            {
                _actualizandoConsulta = false;
            }
        }

        private void CboColumnaOrden_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            if (!_isViewLoaded) return;
            ActualizarConsultaGenerada();
        }

        private void CboDireccionOrden_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            if (!_isViewLoaded) return;
            ActualizarConsultaGenerada();
        }

        private void CboTopRegistros_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            if (!_isViewLoaded) return;
            ActualizarConsultaGenerada();
        }

        private void ActualizarConsultaGenerada()
        {
            if (!_isViewLoaded || _actualizandoConsulta)
                return;

            if (TxtConsultaSqlLibre == null || CboTablasCentrales == null)
                return;

            if (CboTablasCentrales.SelectedItem == null)
            {
                TxtConsultaSqlLibre.Text = "-- Selecciona una tabla para armar la consulta.";
                return;
            }

            string objeto = CboTablasCentrales.SelectedItem.ToString()!;
            string topClause = "TOP (100)";

            if (CboTopRegistros?.SelectedItem is System.Windows.Controls.ComboBoxItem itemCbo)
            {
                string txt = itemCbo.Content.ToString()!;
                if (txt.Equals("TODOS", StringComparison.OrdinalIgnoreCase))
                {
                    topClause = "";
                }
                else
                {
                    string num = txt.Replace("TOP", "").Trim();
                    topClause = $"TOP ({num})";
                }
            }

            string orderClause = "";
            if (CboColumnaOrden?.SelectedItem != null)
            {
                string col = CboColumnaOrden.SelectedItem.ToString()!;
                if (!col.StartsWith("("))
                {
                    string dir = "DESC";
                    if (CboDireccionOrden?.SelectedItem is System.Windows.Controls.ComboBoxItem dirCbo)
                    {
                        if (dirCbo.Content.ToString()?.Contains("ASC") == true)
                        {
                            dir = "ASC";
                        }
                    }
                    orderClause = $" ORDER BY [{col}] {dir}";
                }
            }

            string topSpace = string.IsNullOrEmpty(topClause) ? "" : topClause + " ";
            TxtConsultaSqlLibre.Text = $"SELECT {topSpace}* FROM {objeto}{orderClause};";
        }

        private void ChkModoSqlLibre_CheckedChanged(object sender, RoutedEventArgs e)
        {
            if (!_isViewLoaded || PanelSqlLibre == null || ChkModoSqlLibre == null) return;
            PanelSqlLibre.Visibility = ChkModoSqlLibre.IsChecked == true ? Visibility.Visible : Visibility.Collapsed;
        }

        private void BtnResetearSqlLibre_Click(object sender, RoutedEventArgs e)
        {
            ActualizarConsultaGenerada();
        }

        private async void BtnConsultarAdminDb_Click(object sender, RoutedEventArgs e)
        {
            if (CboTablasCentrales.SelectedItem == null && string.IsNullOrWhiteSpace(TxtConsultaSqlLibre.Text))
            {
                ModernMessageBox.Show("Por favor selecciona una tabla o ingresa una consulta SQL para ejecutar.", "Aviso", MessageBoxButton.OK, MessageBoxImage.Warning, this);
                return;
            }

            string sqlAEjecutar;
            if (ChkModoSqlLibre.IsChecked == true && !string.IsNullOrWhiteSpace(TxtConsultaSqlLibre.Text))
            {
                sqlAEjecutar = TxtConsultaSqlLibre.Text.Trim();
            }
            else
            {
                ActualizarConsultaGenerada();
                sqlAEjecutar = TxtConsultaSqlLibre.Text.Trim();
            }

            LblEstadoVisor.Text = $"Ejecutando consulta en { _config.Configuracion.BaseDatosCentral }...";

            try
            {
                var dt = await _centralDb.EjecutarConsultaAsync(sqlAEjecutar);
                DgVisorCentral.ItemsSource = dt.DefaultView;
                LblEstadoVisor.Text = $"✔ Se obtuvieron {dt.Rows.Count} registros a las {DateTime.Now:HH:mm:ss}.";
            }
            catch (Exception ex)
            {
                LblEstadoVisor.Text = $"❌ Error al ejecutar consulta: {ex.Message}";
                ModernMessageBox.Show($"Error al ejecutar consulta en adminDB:\n\n{ex.Message}", "Error adminDB", MessageBoxButton.OK, MessageBoxImage.Error, this);
            }
        }

        private void BtnRefrescarTablasAdminDb_Click(object sender, RoutedEventArgs e)
        {
            CargarTablasAdminDbAsync();
        }

        private void BtnExportarResultadosAdminDb_Click(object sender, RoutedEventArgs e)
        {
            if (DgVisorCentral.ItemsSource is not System.Data.DataView dv || dv.Count == 0)
            {
                ModernMessageBox.Show("No hay registros en la vista previa para exportar.", "Aviso", MessageBoxButton.OK, MessageBoxImage.Information, this);
                return;
            }

            var dialog = new Microsoft.Win32.SaveFileDialog
            {
                Title = "Guardar Resultados de adminDB",
                Filter = "Archivos CSV (*.csv)|*.csv|Todos los archivos (*.*)|*.*",
                FileName = $"adminDB_Resultados_{DateTime.Now:yyyyMMdd_HHmmss}.csv"
            };

            if (dialog.ShowDialog() == true)
            {
                try
                {
                    var table = dv.Table;
                    if (table == null) return;
                    var sb = new System.Text.StringBuilder();

                    // Encabezados
                    var headers = table.Columns.Cast<System.Data.DataColumn>().Select(c => $"\"{c.ColumnName}\"");
                    sb.AppendLine(string.Join(",", headers));

                    // Filas
                    foreach (System.Data.DataRowView rowView in dv)
                    {
                        var row = rowView.Row;
                        var fields = row.ItemArray.Select(field =>
                        {
                            string str = field?.ToString() ?? "";
                            return $"\"{str.Replace("\"", "\"\"").Replace("\r", " ").Replace("\n", " ")}\"";
                        });
                        sb.AppendLine(string.Join(",", fields));
                    }

                    File.WriteAllText(dialog.FileName, sb.ToString(), System.Text.Encoding.UTF8);

                    var res = ModernMessageBox.Show($"Resultados exportados exitosamente a:\n{dialog.FileName}\n\n¿Deseas abrir el archivo ahora en Excel?", "Exportación Exitosa", MessageBoxButton.YesNo, MessageBoxImage.Information, this);
                    if (res == MessageBoxResult.Yes)
                    {
                        Process.Start(new ProcessStartInfo
                        {
                            FileName = dialog.FileName,
                            UseShellExecute = true
                        });
                    }
                }
                catch (Exception ex)
                {
                    ModernMessageBox.Show($"Error al exportar resultados: {ex.Message}", "Error al Exportar", MessageBoxButton.OK, MessageBoxImage.Error, this);
                }
            }
        }
        #endregion
    }
}
