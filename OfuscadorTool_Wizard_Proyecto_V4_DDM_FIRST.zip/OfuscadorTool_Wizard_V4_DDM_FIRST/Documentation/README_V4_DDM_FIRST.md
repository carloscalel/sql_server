# OfuscadorTool V4 - Estrategia DDM primero, vistas solo por necesidad

Esta versión cambia la estrategia para evitar generar cientos o miles de vistas innecesarias.

## Principio principal

```text
1. DDM primero sobre las tablas reales dbo.Tabla.
2. Vistas masked.Tabla solo cuando sean realmente necesarias.
3. DEFAULT_SCHEMA = masked solo para usuarios controlados.
4. Si existe masked.Tabla, SQL Server la usa primero para consultas sin esquema.
5. Si no existe masked.Tabla, la consulta cae a dbo.Tabla, donde las columnas sensibles quedan protegidas con DDM.
```

## Nueva opción: ViewGenerationStrategy

Valores:

| Valor | Comportamiento |
|---|---|
| `WHEN_NEEDED` | Recomendado. Crea vistas solo si DDM no alcanza, hay columnas calculadas sensibles, columnas no soportadas por DDM o reglas `RequiresView = 1`. |
| `ALL_CANDIDATE_TABLES` | Crea vista para toda tabla con columnas candidatas. Similar a la estrategia anterior. |
| `MANUAL_ONLY` | Solo crea vistas cuando una regla o selección manual tiene `RequiresView = 1`. |
| `DISABLED` | No crea vistas. Solo se usa DDM si está activado. |

## Cambio importante en columnas calculadas

Antes, una tabla con columna calculada podía omitirse completa para evitar errores.

En V4, DDM ya no omite una tabla completa solo por tener columnas calculadas. DDM se aplica a las columnas normales compatibles y se omiten únicamente las columnas calculadas.

Las vistas se crean solo si una columna calculada es candidata sensible o si existe una razón real para vista.

## Nuevas columnas de control

Se agregan en `setup.sql`:

```sql
ALTER TABLE dbo.Masked_ColumnRules ADD RequiresView BIT NOT NULL DEFAULT(0);
ALTER TABLE dbo.Masked_ManualSelection ADD RequiresView BIT NOT NULL DEFAULT(0);
```

Estas columnas permiten forzar vista por tabla/columna cuando DDM no es suficiente o se necesita una expresión personalizada.

## Configuración recomendada

```text
ApplyDDM = true
CreateViews = true
ViewGenerationStrategy = WHEN_NEEDED
DryRun = true para primera ejecución
ApplySafePolicy = true solo después de validar DDM y vistas
BaseAccessAction = REPORT_ONLY inicialmente
```

## Resultado esperado

Si hay 1,000 tablas y solo 25 requieren vista, V4 debería generar cerca de 25 vistas, no 1,000.

Las demás tablas quedan protegidas con DDM directamente en `dbo.Tabla`.
