/* ===========================================================
   02_deploy_all.sql - V4 DDM FIRST / VISTAS SOLO POR NECESIDAD
   Compatible SQL Server 2016+

   Estrategia V4:
   - DDM es la capa principal sobre dbo.Tabla.
   - Las vistas masked.Tabla se crean solo si realmente hacen falta.
   - Con DEFAULT_SCHEMA=masked: si existe masked.Tabla se usa; si no existe,
     la consulta cae a dbo.Tabla y queda protegida por DDM.

   Configuracion dbo.Masked_Config:
   - CreateMaskedViews: 1/0
   - ViewGenerationStrategy:
       WHEN_NEEDED          = solo cuando DDM no alcanza, hay calculada sensible o RequiresView=1.
       ALL_CANDIDATE_TABLES = crea vista para toda tabla con candidato sensible.
       MANUAL_ONLY          = solo si regla/seleccion manual tiene RequiresView=1.
       DISABLED             = no crea vistas.
   - ApplyDDM: si es 0 y CreateMaskedViews=1, WHEN_NEEDED crea vistas para candidatos
     porque no hay capa DDM directa.
   - MaskDryRun: si es 1, solo audita/print; no crea vista ni sinonimo.
   ===========================================================*/
SET NOCOUNT ON;
SET XACT_ABORT ON;

DECLARE @BaseSchema SYSNAME = N'dbo';
DECLARE @MaskedSchema SYSNAME = N'masked';
DECLARE @AppSchema SYSNAME = N'app';
DECLARE @MaskingMode NVARCHAR(20) = N'both';
DECLARE @ApplyDDM BIT = 1;
DECLARE @CreateViews BIT = 1;
DECLARE @CreateSynonyms BIT = 1;
DECLARE @DryRun BIT = 0;
DECLARE @ViewGenerationStrategy NVARCHAR(40) = N'WHEN_NEEDED';
DECLARE @SkipTablesWithComputed BIT = 1; -- V4: solo evita vistas innecesarias; no bloquea DDM.

SELECT @MaskingMode = COALESCE(ConfigValue, @MaskingMode) FROM dbo.Masked_Config WHERE ConfigKey = N'MaskingMode';
SELECT @ApplyDDM = CASE WHEN ConfigValue IN (N'1',N'true',N'TRUE',N'yes',N'YES') THEN 1 ELSE 0 END FROM dbo.Masked_Config WHERE ConfigKey = N'ApplyDDM';
SELECT @CreateViews = CASE WHEN ConfigValue IN (N'1',N'true',N'TRUE',N'yes',N'YES') THEN 1 ELSE 0 END FROM dbo.Masked_Config WHERE ConfigKey = N'CreateMaskedViews';
SELECT @CreateSynonyms = CASE WHEN ConfigValue IN (N'1',N'true',N'TRUE',N'yes',N'YES') THEN 1 ELSE 0 END FROM dbo.Masked_Config WHERE ConfigKey = N'CreateSynonyms';
SELECT @DryRun = CASE WHEN ConfigValue IN (N'1',N'true',N'TRUE',N'yes',N'YES') THEN 1 ELSE 0 END FROM dbo.Masked_Config WHERE ConfigKey = N'MaskDryRun';
SELECT @ViewGenerationStrategy = COALESCE(ConfigValue, @ViewGenerationStrategy) FROM dbo.Masked_Config WHERE ConfigKey = N'ViewGenerationStrategy';
SELECT @SkipTablesWithComputed = CASE WHEN ConfigValue IN (N'1',N'true',N'TRUE',N'yes',N'YES') THEN 1 ELSE 0 END FROM dbo.Masked_Config WHERE ConfigKey = N'SkipTablesWithComputed';

IF @MaskingMode NOT IN (N'patterns', N'manual', N'both') SET @MaskingMode = N'both';
IF @ViewGenerationStrategy NOT IN (N'WHEN_NEEDED', N'ALL_CANDIDATE_TABLES', N'MANUAL_ONLY', N'DISABLED') SET @ViewGenerationStrategy = N'WHEN_NEEDED';
IF @CreateViews = 0 SET @ViewGenerationStrategy = N'DISABLED';

PRINT N'V4 View deploy. ApplyDDM=' + CONVERT(NVARCHAR(1),@ApplyDDM) +
      N' CreateViews=' + CONVERT(NVARCHAR(1),@CreateViews) +
      N' Strategy=' + @ViewGenerationStrategy +
      N' DryRun=' + CONVERT(NVARCHAR(1),@DryRun);

IF OBJECT_ID(N'tempdb..#ColumnCandidates') IS NOT NULL DROP TABLE #ColumnCandidates;
CREATE TABLE #ColumnCandidates
(
    SchemaName SYSNAME NOT NULL,
    TableName SYSNAME NOT NULL,
    ColumnName SYSNAME NOT NULL,
    IsComputed BIT NOT NULL,
    IsIdentity BIT NOT NULL,
    IsRowGuid BIT NOT NULL,
    TypeName SYSNAME NOT NULL,
    DdmFunction NVARCHAR(200) NULL,
    ViewMaskExpr NVARCHAR(1000) NULL,
    RequiresView BIT NOT NULL DEFAULT 0,
    Source NVARCHAR(30) NOT NULL,
    DdmSupported BIT NOT NULL DEFAULT 0
);

;WITH Raw AS
(
    SELECT DISTINCT
        s.name AS SchemaName,
        t.name AS TableName,
        c.name AS ColumnName,
        c.is_computed AS IsComputed,
        c.is_identity AS IsIdentity,
        c.is_rowguidcol AS IsRowGuid,
        TYPE_NAME(c.user_type_id) AS TypeName,
        COALESCE(
            r.DdmFunction,
            CASE
                WHEN @MaskingMode IN (N'manual', N'both') AND ms.IsSelected = 1
                    THEN COALESCE(ms.MaskOverride, p.DdmFunction, N'default()')
                WHEN @MaskingMode = N'patterns'
                    THEN p.DdmFunction
                ELSE NULL
            END
        ) AS DdmFunction,
        COALESCE(
            r.ViewMaskExpr,
            CASE
                WHEN @MaskingMode IN (N'manual', N'both') AND ms.IsSelected = 1 THEN
                    CASE
                        WHEN ms.MaskOverride = N'default()' THEN N'NULL'
                        WHEN ms.MaskOverride = N'email()' THEN N'CASE WHEN {col} IS NULL THEN NULL ELSE CASE WHEN CHARINDEX(''@'',{col})>1 THEN LEFT({col},1)+''*****''+SUBSTRING({col},CHARINDEX(''@'',{col}),LEN({col})-CHARINDEX(''@'',{col})+1) ELSE ''*****'' END END'
                        ELSE p.ViewMaskExpr
                    END
                WHEN @MaskingMode IN (N'patterns', N'both') THEN p.ViewMaskExpr
                ELSE NULL
            END
        ) AS ViewMaskExpr,
        CONVERT(BIT, CASE WHEN ISNULL(r.RequiresView,0)=1 OR ISNULL(ms.RequiresView,0)=1 THEN 1 ELSE 0 END) AS RequiresView,
        CASE
            WHEN r.RuleId IS NOT NULL THEN N'rule'
            WHEN ms.SelectionId IS NOT NULL AND ms.IsSelected = 1 THEN N'manual'
            WHEN p.DdmFunction IS NOT NULL OR p.ViewMaskExpr IS NOT NULL THEN N'pattern'
            ELSE N'none'
        END AS Source
    FROM sys.columns c
    JOIN sys.tables t ON t.object_id = c.object_id
    JOIN sys.schemas s ON s.schema_id = t.schema_id
    LEFT JOIN dbo.Masked_ColumnRules r
      ON r.SchemaName = s.name
     AND r.TableName = t.name
     AND r.ColumnName = c.name
     AND r.IsEnabled = 1
    LEFT JOIN dbo.Masked_ManualSelection ms
      ON ms.SchemaName = s.name
     AND ms.TableName = t.name
     AND ms.ColumnName = c.name
     AND ms.IsSelected = 1
    LEFT JOIN dbo.Masked_Exceptions ex
      ON ex.SchemaName = s.name
     AND ex.TableName = t.name
     AND (ex.ColumnName = c.name OR ex.ColumnName IS NULL)
     AND ex.IsEnabled = 1
    OUTER APPLY
    (
        SELECT TOP 1 p.DdmFunction, p.ViewMaskExpr
        FROM dbo.Masked_Patterns p
        WHERE p.IsEnabled = 1
          AND c.name LIKE p.Pattern
        ORDER BY p.Priority DESC, LEN(p.Pattern) DESC, p.Pattern
    ) p
    WHERE t.is_ms_shipped = 0
      AND s.name = @BaseSchema
      AND t.name NOT IN
      (
        N'Masked_Audit', N'Masked_Patterns', N'Masked_Config', N'Masked_ColumnRules',
        N'Masked_Exceptions', N'Masked_ManualSelection', N'Masked_PrincipalPolicy', N'Masked_PrincipalExclusions'
      )
      AND ex.ExceptionId IS NULL
      AND (
            (@MaskingMode = N'patterns' AND (p.DdmFunction IS NOT NULL OR p.ViewMaskExpr IS NOT NULL))
         OR (@MaskingMode = N'manual' AND (ms.IsSelected = 1 OR r.RuleId IS NOT NULL))
         OR (@MaskingMode = N'both' AND (r.RuleId IS NOT NULL OR ms.IsSelected = 1 OR p.DdmFunction IS NOT NULL OR p.ViewMaskExpr IS NOT NULL))
      )
)
INSERT INTO #ColumnCandidates
(SchemaName, TableName, ColumnName, IsComputed, IsIdentity, IsRowGuid, TypeName, DdmFunction, ViewMaskExpr, RequiresView, Source, DdmSupported)
SELECT
    SchemaName,
    TableName,
    ColumnName,
    IsComputed,
    IsIdentity,
    IsRowGuid,
    TypeName,
    DdmFunction,
    ViewMaskExpr,
    RequiresView,
    Source,
    CONVERT(BIT, CASE
        WHEN IsComputed = 1 OR IsIdentity = 1 OR IsRowGuid = 1 THEN 0
        WHEN DdmFunction IS NULL THEN 0
        WHEN (DdmFunction LIKE N'partial(%' OR DdmFunction = N'email()')
             AND TypeName IN (N'char', N'nchar', N'varchar', N'nvarchar') THEN 1
        WHEN DdmFunction LIKE N'random(%'
             AND TypeName IN (N'tinyint', N'smallint', N'int', N'bigint', N'decimal', N'numeric', N'money', N'smallmoney', N'float', N'real') THEN 1
        WHEN DdmFunction = N'default()'
             AND TypeName IN (N'char', N'nchar', N'varchar', N'nvarchar', N'binary', N'varbinary',
                              N'tinyint', N'smallint', N'int', N'bigint', N'decimal', N'numeric', N'money', N'smallmoney', N'float', N'real', N'bit',
                              N'date', N'datetime', N'datetime2', N'smalldatetime', N'time', N'datetimeoffset') THEN 1
        ELSE 0
    END) AS DdmSupported
FROM Raw;

IF OBJECT_ID(N'tempdb..#TablesForViews') IS NOT NULL DROP TABLE #TablesForViews;
CREATE TABLE #TablesForViews
(
    Id INT IDENTITY(1,1) PRIMARY KEY,
    SchemaName SYSNAME NOT NULL,
    TableName SYSNAME NOT NULL,
    HasAnyCandidate BIT NOT NULL,
    HasComputedCandidate BIT NOT NULL,
    HasUnsupportedCandidate BIT NOT NULL,
    HasRequiresView BIT NOT NULL,
    HasViewMask BIT NOT NULL,
    Reason NVARCHAR(1000) NULL,
    ShouldCreateView BIT NOT NULL
);

;WITH T AS
(
    SELECT
        SchemaName,
        TableName,
        CAST(1 AS BIT) AS HasAnyCandidate,
        CONVERT(BIT, MAX(CASE WHEN IsComputed = 1 THEN 1 ELSE 0 END)) AS HasComputedCandidate,
        CONVERT(BIT, MAX(CASE WHEN DdmSupported = 0 THEN 1 ELSE 0 END)) AS HasUnsupportedCandidate,
        CONVERT(BIT, MAX(CASE WHEN RequiresView = 1 THEN 1 ELSE 0 END)) AS HasRequiresView,
        CONVERT(BIT, MAX(CASE WHEN ViewMaskExpr IS NOT NULL THEN 1 ELSE 0 END)) AS HasViewMask
    FROM #ColumnCandidates
    GROUP BY SchemaName, TableName
)
INSERT INTO #TablesForViews
(SchemaName, TableName, HasAnyCandidate, HasComputedCandidate, HasUnsupportedCandidate, HasRequiresView, HasViewMask, Reason, ShouldCreateView)
SELECT
    SchemaName,
    TableName,
    HasAnyCandidate,
    HasComputedCandidate,
    HasUnsupportedCandidate,
    HasRequiresView,
    HasViewMask,
    CONCAT(
        N'ApplyDDM=', @ApplyDDM,
        N'; Strategy=', @ViewGenerationStrategy,
        N'; ComputedCandidate=', HasComputedCandidate,
        N'; UnsupportedCandidate=', HasUnsupportedCandidate,
        N'; RequiresView=', HasRequiresView,
        N'; HasViewMask=', HasViewMask
    ) AS Reason,
    CONVERT(BIT, CASE
        WHEN @CreateViews = 0 OR @ViewGenerationStrategy = N'DISABLED' THEN 0
        WHEN HasViewMask = 0 THEN 0
        WHEN @ViewGenerationStrategy = N'ALL_CANDIDATE_TABLES' THEN 1
        WHEN @ViewGenerationStrategy = N'MANUAL_ONLY' AND HasRequiresView = 1 THEN 1
        WHEN @ViewGenerationStrategy = N'WHEN_NEEDED'
             AND (
                    @ApplyDDM = 0
                 OR HasComputedCandidate = 1
                 OR HasUnsupportedCandidate = 1
                 OR HasRequiresView = 1
             ) THEN 1
        ELSE 0
    END) AS ShouldCreateView
FROM T;

DECLARE @i INT = 1, @imax INT = (SELECT ISNULL(MAX(Id),0) FROM #TablesForViews);
DECLARE @sch SYSNAME, @tbl SYSNAME, @reason NVARCHAR(1000), @should BIT, @sql NVARCHAR(MAX);

WHILE @i <= @imax
BEGIN
    SELECT @sch = SchemaName, @tbl = TableName, @should = ShouldCreateView, @reason = Reason
    FROM #TablesForViews WHERE Id = @i;

    IF @should = 1
    BEGIN
        IF @DryRun = 1
        BEGIN
            PRINT N'DRYRUN VIEW: ' + QUOTENAME(@MaskedSchema) + N'.' + QUOTENAME(@tbl) + N' | ' + @reason;
            INSERT INTO dbo.Masked_Audit(EventType, SchemaName, ObjectName, ColumnName, Action, Detail)
            VALUES(N'DRYRUN', @MaskedSchema, @tbl, NULL, N'CREATE VIEW WHEN NEEDED', @reason);
        END
        ELSE
        BEGIN
            BEGIN TRY
                EXEC dbo.sp_Masked_CreateViewWithDml @BaseSchema = @sch, @TableName = @tbl, @MaskedSchema = @MaskedSchema;
            END TRY
            BEGIN CATCH
                INSERT INTO dbo.Masked_Audit(EventType, SchemaName, ObjectName, ColumnName, Action, Detail)
                VALUES(N'ERROR', @sch, @tbl, NULL, N'VIEW/TRIGGERS', ERROR_MESSAGE());
            END CATCH;

            IF @CreateSynonyms = 1
            BEGIN
                IF EXISTS (SELECT 1 FROM sys.views v JOIN sys.schemas s ON s.schema_id = v.schema_id WHERE s.name = @MaskedSchema AND v.name = @tbl)
                BEGIN
                    BEGIN TRY
                        IF EXISTS (SELECT 1 FROM sys.synonyms syn WHERE syn.name = @tbl AND SCHEMA_NAME(syn.schema_id) = @AppSchema)
                        BEGIN
                            SET @sql = N'DROP SYNONYM ' + QUOTENAME(@AppSchema) + N'.' + QUOTENAME(@tbl) + N';';
                            EXEC sp_executesql @sql;
                        END;

                        SET @sql = N'CREATE SYNONYM ' + QUOTENAME(@AppSchema) + N'.' + QUOTENAME(@tbl) +
                                   N' FOR ' + QUOTENAME(@MaskedSchema) + N'.' + QUOTENAME(@tbl) + N';';
                        EXEC sp_executesql @sql;

                        INSERT INTO dbo.Masked_Audit(EventType, SchemaName, ObjectName, ColumnName, Action, Detail)
                        VALUES(N'SYNONYM', @AppSchema, @tbl, NULL, N'CREATE', @AppSchema + N'.' + @tbl + N' -> ' + @MaskedSchema + N'.' + @tbl);
                    END TRY
                    BEGIN CATCH
                        INSERT INTO dbo.Masked_Audit(EventType, SchemaName, ObjectName, ColumnName, Action, Detail)
                        VALUES(N'ERROR', @AppSchema, @tbl, NULL, N'SYNONYM', ERROR_MESSAGE());
                    END CATCH;
                END;
            END;
        END;
    END
    ELSE
    BEGIN
        INSERT INTO dbo.Masked_Audit(EventType, SchemaName, ObjectName, ColumnName, Action, Detail)
        VALUES(N'SKIP', @sch, @tbl, NULL, N'VIEW NOT REQUIRED', @reason + N'. Se espera protección por DDM si ApplyDDM=1.');
    END;

    SET @i += 1;
END;

PRINT N'Deploy V4 de vistas/sinonimos finalizado. Revise dbo.Masked_Audit.';
