/* ===========================================================
   apply_ddm.sql - corregido / endurecido
   Compatible SQL Server 2016+

   Cambios clave:
   - Usa SchemaName en reglas, seleccion manual y excepciones.
   - No intenta enmascarar columnas ya enmascaradas, salvo ForceReapply.
   - Soporta default() para tipos numericos/fecha/texto soportados.
   - partial()/email() solo se aplican a tipos texto compatibles.
   - random() solo se aplica a numericos.
   - Tiene modo DryRun por configuracion dbo.Masked_Config.
   - V4: DDM se aplica primero aun si la tabla tiene columnas calculadas; solo se omiten columnas calculadas.
   ===========================================================*/
SET NOCOUNT ON;
SET XACT_ABORT ON;

DECLARE @MaskingMode NVARCHAR(20);
DECLARE @ForceReapply BIT = 0;
DECLARE @DryRun BIT = 0;
DECLARE @SkipTablesWithComputed BIT = 1; -- V4: solo informativo; no bloquea DDM por tabla completa

SELECT @MaskingMode = ConfigValue FROM dbo.Masked_Config WHERE ConfigKey = N'MaskingMode';
IF @MaskingMode IS NULL SET @MaskingMode = N'both';

SELECT @ForceReapply = CASE WHEN ConfigValue IN (N'1', N'true', N'TRUE', N'yes', N'YES') THEN 1 ELSE 0 END
FROM dbo.Masked_Config WHERE ConfigKey = N'MaskForceReapply';

SELECT @DryRun = CASE WHEN ConfigValue IN (N'1', N'true', N'TRUE', N'yes', N'YES') THEN 1 ELSE 0 END
FROM dbo.Masked_Config WHERE ConfigKey = N'MaskDryRun';

SELECT @SkipTablesWithComputed = CASE WHEN ConfigValue IN (N'1', N'true', N'TRUE', N'yes', N'YES') THEN 1 ELSE 0 END
FROM dbo.Masked_Config WHERE ConfigKey = N'SkipTablesWithComputed';

IF @MaskingMode NOT IN (N'patterns', N'manual', N'both')
BEGIN
    INSERT INTO dbo.Masked_Audit(EventType, SchemaName, ObjectName, ColumnName, Action, Detail)
    VALUES(N'ERROR', N'dbo', N'apply_ddm', NULL, N'CONFIG', N'MaskingMode invalido: ' + ISNULL(@MaskingMode, N'<NULL>'));
    THROW 51000, N'MaskingMode invalido. Use patterns, manual o both.', 1;
END;

PRINT N'Modo de enmascaramiento: ' + @MaskingMode;
PRINT N'ForceReapply: ' + CONVERT(NVARCHAR(1), @ForceReapply) + N' | DryRun: ' + CONVERT(NVARCHAR(1), @DryRun) + N' | V4 DDM-first: tablas con columnas calculadas NO se omiten; se omiten solo columnas calculadas.';

DECLARE @sql NVARCHAR(MAX);
DECLARE @sch SYSNAME, @tbl SYSNAME, @col SYSNAME, @mf NVARCHAR(200);
DECLARE @ObjFull NVARCHAR(517);

IF OBJECT_ID(N'tempdb..#Candidates') IS NOT NULL DROP TABLE #Candidates;
CREATE TABLE #Candidates
(
    Id INT IDENTITY(1,1) PRIMARY KEY,
    SchemaName SYSNAME,
    TableName SYSNAME,
    ColumnName SYSNAME,
    DdmFunction NVARCHAR(200),
    TypeName SYSNAME,
    Source NVARCHAR(30)
);

;WITH RawCandidates AS
(
    SELECT DISTINCT
        s.name AS SchemaName,
        t.name AS TableName,
        c.name AS ColumnName,
        TYPE_NAME(c.user_type_id) AS TypeName,
        COALESCE(
            r.DdmFunction,
            CASE
                WHEN @MaskingMode IN (N'manual', N'both') AND ms.IsSelected = 1
                    THEN COALESCE(ms.MaskOverride, p.DdmFunction, N'default()')
                WHEN @MaskingMode = N'patterns'
                    THEN p.DdmFunction
                ELSE NULL
            END
        ) AS DdmFunction,
        CASE
            WHEN r.RuleId IS NOT NULL THEN N'rule'
            WHEN ms.SelectionId IS NOT NULL AND ms.IsSelected = 1 THEN N'manual'
            WHEN p.DdmFunction IS NOT NULL THEN N'pattern'
            ELSE N'none'
        END AS Source
    FROM sys.columns c
    JOIN sys.tables t ON t.object_id = c.object_id
    JOIN sys.schemas s ON s.schema_id = t.schema_id
    LEFT JOIN dbo.Masked_ColumnRules r
        ON r.SchemaName = s.name
       AND r.TableName = t.name
       AND r.ColumnName = c.name
       AND r.IsEnabled = 1
    LEFT JOIN dbo.Masked_ManualSelection ms
        ON ms.SchemaName = s.name
       AND ms.TableName = t.name
       AND ms.ColumnName = c.name
       AND ms.IsSelected = 1
    LEFT JOIN dbo.Masked_Exceptions ex
        ON ex.SchemaName = s.name
       AND ex.TableName = t.name
       AND (ex.ColumnName = c.name OR ex.ColumnName IS NULL)
       AND ex.IsEnabled = 1
    OUTER APPLY
    (
        SELECT TOP 1 p.DdmFunction
        FROM dbo.Masked_Patterns p
        WHERE p.IsEnabled = 1
          AND c.name LIKE p.Pattern
        ORDER BY p.Priority DESC, LEN(p.Pattern) DESC, p.Pattern
    ) p
    WHERE t.is_ms_shipped = 0
      AND s.name = N'dbo'
      AND t.name NOT IN (N'Masked_Audit', N'Masked_Patterns', N'Masked_Config', N'Masked_ColumnRules', N'Masked_Exceptions', N'Masked_ManualSelection', N'Masked_PrincipalPolicy', N'Masked_PrincipalExclusions')
      AND c.is_computed = 0
      AND c.is_identity = 0
      AND c.is_rowguidcol = 0
      AND c.name NOT LIKE N'Id\_%' ESCAPE N'\'
      AND ex.ExceptionId IS NULL
      -- V4: No se omite la tabla completa por tener columnas calculadas; solo se excluyen columnas calculadas con c.is_computed = 0.
      AND (
            (@MaskingMode = N'patterns' AND p.DdmFunction IS NOT NULL)
         OR (@MaskingMode = N'manual' AND ms.IsSelected = 1)
         OR (@MaskingMode = N'both' AND (r.RuleId IS NOT NULL OR p.DdmFunction IS NOT NULL OR ms.IsSelected = 1))
      )
)
INSERT INTO #Candidates(SchemaName, TableName, ColumnName, DdmFunction, TypeName, Source)
SELECT SchemaName, TableName, ColumnName, DdmFunction, TypeName, Source
FROM RawCandidates
WHERE DdmFunction IS NOT NULL
  AND (
        -- partial/email solamente para tipos texto editables. Se excluye text/ntext por estar deprecados y dar problemas en ALTER COLUMN.
        ((DdmFunction LIKE N'partial(%' OR DdmFunction = N'email()')
            AND TypeName IN (N'char', N'nchar', N'varchar', N'nvarchar'))
        -- random solamente numericos.
     OR (DdmFunction LIKE N'random(%'
            AND TypeName IN (N'tinyint', N'smallint', N'int', N'bigint', N'decimal', N'numeric', N'money', N'smallmoney', N'float', N'real'))
        -- default para texto, numericos, fechas y binarios comunes.
     OR (DdmFunction = N'default()'
            AND TypeName IN (N'char', N'nchar', N'varchar', N'nvarchar', N'binary', N'varbinary',
                             N'tinyint', N'smallint', N'int', N'bigint', N'decimal', N'numeric', N'money', N'smallmoney', N'float', N'real', N'bit',
                             N'date', N'datetime', N'datetime2', N'smalldatetime', N'time', N'datetimeoffset'))
      );

INSERT INTO dbo.Masked_Audit(EventType, SchemaName, ObjectName, ColumnName, Action, Detail)
SELECT N'SKIP', rc.SchemaName, rc.TableName, rc.ColumnName, N'UNSUPPORTED TYPE', rc.TypeName + N' / ' + ISNULL(rc.DdmFunction, N'<NULL>')
FROM
(
    SELECT DISTINCT
        s.name AS SchemaName, t.name AS TableName, c.name AS ColumnName,
        TYPE_NAME(c.user_type_id) AS TypeName,
        COALESCE(r.DdmFunction,
            CASE
                WHEN @MaskingMode IN (N'manual', N'both') AND ms.IsSelected = 1 THEN COALESCE(ms.MaskOverride, p.DdmFunction, N'default()')
                WHEN @MaskingMode = N'patterns' THEN p.DdmFunction
                ELSE NULL
            END) AS DdmFunction
    FROM sys.columns c
    JOIN sys.tables t ON t.object_id = c.object_id
    JOIN sys.schemas s ON s.schema_id = t.schema_id
    LEFT JOIN dbo.Masked_ColumnRules r ON r.SchemaName=s.name AND r.TableName=t.name AND r.ColumnName=c.name AND r.IsEnabled=1
    LEFT JOIN dbo.Masked_ManualSelection ms ON ms.SchemaName=s.name AND ms.TableName=t.name AND ms.ColumnName=c.name AND ms.IsSelected=1
    LEFT JOIN dbo.Masked_Exceptions ex ON ex.SchemaName=s.name AND ex.TableName=t.name AND (ex.ColumnName=c.name OR ex.ColumnName IS NULL) AND ex.IsEnabled=1
    OUTER APPLY (SELECT TOP 1 p.DdmFunction FROM dbo.Masked_Patterns p WHERE p.IsEnabled=1 AND c.name LIKE p.Pattern ORDER BY p.Priority DESC, LEN(p.Pattern) DESC, p.Pattern) p
    WHERE t.is_ms_shipped=0 AND s.name=N'dbo' AND c.is_computed=0 AND c.is_identity=0 AND c.is_rowguidcol=0
      AND ex.ExceptionId IS NULL
      AND COALESCE(r.DdmFunction, CASE WHEN @MaskingMode IN (N'manual', N'both') AND ms.IsSelected=1 THEN COALESCE(ms.MaskOverride, p.DdmFunction, N'default()') WHEN @MaskingMode=N'patterns' THEN p.DdmFunction ELSE NULL END) IS NOT NULL
) rc
LEFT JOIN #Candidates ok
  ON ok.SchemaName=rc.SchemaName AND ok.TableName=rc.TableName AND ok.ColumnName=rc.ColumnName
WHERE ok.Id IS NULL;

DECLARE cur CURSOR LOCAL FAST_FORWARD FOR
    SELECT SchemaName, TableName, ColumnName, DdmFunction
    FROM #Candidates
    ORDER BY SchemaName, TableName, ColumnName;

OPEN cur;
FETCH NEXT FROM cur INTO @sch, @tbl, @col, @mf;
WHILE @@FETCH_STATUS = 0
BEGIN
    SET @ObjFull = QUOTENAME(@sch) + N'.' + QUOTENAME(@tbl);

    BEGIN TRY
        IF @mf NOT IN (N'default()', N'email()') AND @mf NOT LIKE N'partial(%' AND @mf NOT LIKE N'random(%'
        BEGIN
            INSERT INTO dbo.Masked_Audit(EventType, SchemaName, ObjectName, ColumnName, Action, Detail)
            VALUES(N'ERROR', @sch, @tbl, @col, N'INVALID DDM FUNCTION', @mf);
        END
        ELSE IF EXISTS
        (
            SELECT 1
            FROM sys.masked_columns mc
            WHERE mc.object_id = OBJECT_ID(@ObjFull)
              AND mc.name = @col
        )
        BEGIN
            IF @ForceReapply = 1
            BEGIN
                SET @sql = N'ALTER TABLE ' + @ObjFull + N' ALTER COLUMN ' + QUOTENAME(@col) + N' DROP MASKED;';
                IF @DryRun = 1
                BEGIN
                    PRINT N'DRYRUN: ' + @sql;
                    INSERT INTO dbo.Masked_Audit(EventType, SchemaName, ObjectName, ColumnName, Action, Detail)
                    VALUES(N'DRYRUN', @sch, @tbl, @col, N'DROP MASKED', @sql);
                END
                ELSE
                BEGIN
                    EXEC sp_executesql @sql;
                    INSERT INTO dbo.Masked_Audit(EventType, SchemaName, ObjectName, ColumnName, Action, Detail)
                    VALUES(N'DDM', @sch, @tbl, @col, N'DROP MASKED', N'ForceReapply=1');
                END

                SET @sql = N'ALTER TABLE ' + @ObjFull + N' ALTER COLUMN ' + QUOTENAME(@col) + N' ADD MASKED WITH (FUNCTION = ' + QUOTENAME(@mf, '''') + N');';
                IF @DryRun = 1
                BEGIN
                    PRINT N'DRYRUN: ' + @sql;
                    INSERT INTO dbo.Masked_Audit(EventType, SchemaName, ObjectName, ColumnName, Action, Detail)
                    VALUES(N'DRYRUN', @sch, @tbl, @col, N'ADD MASKED', @sql);
                END
                ELSE
                BEGIN
                    EXEC sp_executesql @sql;
                    INSERT INTO dbo.Masked_Audit(EventType, SchemaName, ObjectName, ColumnName, Action, Detail)
                    VALUES(N'DDM', @sch, @tbl, @col, N'REAPPLY MASKED', @mf);
                END
            END
            ELSE
            BEGIN
                INSERT INTO dbo.Masked_Audit(EventType, SchemaName, ObjectName, ColumnName, Action, Detail)
                VALUES(N'SKIP', @sch, @tbl, @col, N'ALREADY MASKED', N'Use MaskForceReapply=1 para reaplicar.');
            END
        END
        ELSE
        BEGIN
            SET @sql = N'ALTER TABLE ' + @ObjFull + N' ALTER COLUMN ' + QUOTENAME(@col) + N' ADD MASKED WITH (FUNCTION = ' + QUOTENAME(@mf, '''') + N');';
            IF @DryRun = 1
            BEGIN
                PRINT N'DRYRUN: ' + @sql;
                INSERT INTO dbo.Masked_Audit(EventType, SchemaName, ObjectName, ColumnName, Action, Detail)
                VALUES(N'DRYRUN', @sch, @tbl, @col, N'ADD MASKED', @sql);
            END
            ELSE
            BEGIN
                EXEC sp_executesql @sql;
                INSERT INTO dbo.Masked_Audit(EventType, SchemaName, ObjectName, ColumnName, Action, Detail)
                VALUES(N'DDM', @sch, @tbl, @col, N'ADD MASKED', @mf);
            END
        END
    END TRY
    BEGIN CATCH
        INSERT INTO dbo.Masked_Audit(EventType, SchemaName, ObjectName, ColumnName, Action, Detail)
        VALUES(N'ERROR', @sch, @tbl, @col, N'DDM', ERROR_MESSAGE());
    END CATCH;

    FETCH NEXT FROM cur INTO @sch, @tbl, @col, @mf;
END;
CLOSE cur;
DEALLOCATE cur;

PRINT N'DDM finalizado. Revise dbo.Masked_Audit para SKIP/ERROR/DRYRUN.';
