/* ===========================================================
   04_policy_by_table_SAFE.sql - politica segura con DEFAULT_SCHEMA opcional
   Compatible SQL Server 2016+

   Objetivo:
   - Permite DEFAULT_SCHEMA = masked, pero solo para usuarios/principales controlados.
   - Copia permisos puntuales desde dbo.Tabla hacia masked.Tabla sin tocar los permisos originales.
   - No regala permisos generales por defecto.
   - No quita db_datareader/db_datawriter.
   - No cambia DEFAULT_SCHEMA de forma masiva.
   - No bloquea acceso a dbo automáticamente.
   - Por defecto corre en DRY RUN.

   Flujo recomendado:
   1) Poblar dbo.Masked_PrincipalPolicy con los usuarios/principales a migrar.
   2) Ejecutar este script con @DryRun = 1.
   3) Revisar comandos y reportes.
   4) Cambiar @DryRun = 0 si todo es correcto.
   5) Si se desea bloquear acceso directo a dbo, hacerlo en una segunda corrida
      usando @BaseAccessAction = 'REVOKE_EXPLICIT_OBJECT_PERMISSIONS'
      o 'DENY_BASE_FOR_POLICY_PRINCIPALS'.

   Modos de permisos:
   - @MirrorScope = 'POLICY_TABLE':
       Solo copia permisos para usuarios/roles listados en dbo.Masked_PrincipalPolicy
       con IsEnabled = 1 y MirrorObjectPermissions = 1.
   - @MirrorScope = 'ALL_EXISTING_GRANTEES':
       Copia permisos puntuales existentes de todos los usuarios/roles no fijos
       que ya tienen permisos explícitos sobre tablas base con vista masked.
       Útil para migración general, pero revisar con DryRun primero.

   BaseAccessAction:
   - REPORT_ONLY:
       No toca permisos de dbo. Solo reporta quién aún tiene acceso directo.
   - REVOKE_EXPLICIT_OBJECT_PERMISSIONS:
       Quita permisos explícitos directos sobre dbo.Tabla para los principales migrados.
       No afecta permisos heredados por roles.
   - DENY_BASE_FOR_POLICY_PRINCIPALS:
       Aplica DENY sobre dbo.Tabla solo a principales en Masked_PrincipalPolicy
       con BlockBaseAccess = 1. Usar con extremo cuidado.
   ===========================================================*/
SET NOCOUNT ON;
SET XACT_ABORT ON;

DECLARE @DryRun BIT = 1;

DECLARE @BaseSchema SYSNAME = N'dbo';
DECLARE @MaskedSchema SYSNAME = N'masked';

DECLARE @ApplyDefaultSchemaFromPolicy BIT = 1;
DECLARE @MirrorPermissions BIT = 1;
DECLARE @MirrorScope NVARCHAR(30) = N'POLICY_TABLE'; -- POLICY_TABLE | ALL_EXISTING_GRANTEES

DECLARE @CopyDml BIT = 0; -- copia INSERT/UPDATE/DELETE si el permiso existe y si el principal lo permite
DECLARE @IncludeColumnPermissions BIT = 1;

DECLARE @AddRoleMembershipsFromPolicy BIT = 0; -- opcional: agregar a rol_app_lectura / rol_app_dml segun tabla policy
DECLARE @BaseAccessAction NVARCHAR(50) = N'REPORT_ONLY';
-- REPORT_ONLY | REVOKE_EXPLICIT_OBJECT_PERMISSIONS | DENY_BASE_FOR_POLICY_PRINCIPALS

DECLARE @sql NVARCHAR(MAX);

IF @MirrorScope NOT IN (N'POLICY_TABLE', N'ALL_EXISTING_GRANTEES')
    THROW 51010, N'@MirrorScope invalido. Use POLICY_TABLE o ALL_EXISTING_GRANTEES.', 1;

IF @BaseAccessAction NOT IN (N'REPORT_ONLY', N'REVOKE_EXPLICIT_OBJECT_PERMISSIONS', N'DENY_BASE_FOR_POLICY_PRINCIPALS')
    THROW 51011, N'@BaseAccessAction invalido.', 1;

IF OBJECT_ID(N'dbo.Masked_Audit', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.Masked_Audit (
        AuditId     INT IDENTITY(1,1) PRIMARY KEY,
        EventType   NVARCHAR(30) NULL,
        SchemaName  SYSNAME NULL,
        ObjectName  SYSNAME NULL,
        ColumnName  SYSNAME NULL,
        Action      NVARCHAR(80) NULL,
        Detail      NVARCHAR(4000) NULL,
        CreatedAt   DATETIME2(0) NOT NULL DEFAULT SYSUTCDATETIME()
    );
END;

IF OBJECT_ID(N'dbo.Masked_PrincipalPolicy', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.Masked_PrincipalPolicy (
        PolicyId                INT IDENTITY(1,1) PRIMARY KEY,
        PrincipalName           SYSNAME NOT NULL UNIQUE,
        IsEnabled               BIT NOT NULL DEFAULT 1,
        ApplyDefaultSchema      BIT NOT NULL DEFAULT 1,
        MirrorObjectPermissions BIT NOT NULL DEFAULT 1,
        IncludeDml              BIT NOT NULL DEFAULT 0,
        AddToReadRole           BIT NOT NULL DEFAULT 0,
        AddToDmlRole            BIT NOT NULL DEFAULT 0,
        BlockBaseAccess         BIT NOT NULL DEFAULT 0,
        Notes                   NVARCHAR(500) NULL,
        CreatedAt               DATETIME2(0) NOT NULL DEFAULT SYSUTCDATETIME(),
        ModifiedAt              DATETIME2(0) NOT NULL DEFAULT SYSUTCDATETIME()
    );
END;



IF OBJECT_ID(N'dbo.Masked_PrincipalExclusions', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.Masked_PrincipalExclusions
    (
        ExclusionId INT IDENTITY(1,1) PRIMARY KEY,
        PrincipalName SYSNAME NOT NULL UNIQUE,
        IsEnabled BIT NOT NULL DEFAULT 1,
        Reason NVARCHAR(500) NULL,
        CreatedAt DATETIME2(0) NOT NULL DEFAULT SYSUTCDATETIME(),
        ModifiedAt DATETIME2(0) NOT NULL DEFAULT SYSUTCDATETIME()
    );
END;
/* Crear roles de apoyo, sin asignar usuarios automáticamente salvo que @AddRoleMembershipsFromPolicy = 1. */
IF NOT EXISTS (SELECT 1 FROM sys.database_principals WHERE name=N'rol_app_lectura' AND type='R')
BEGIN
    IF @DryRun = 1 PRINT N'DRYRUN: CREATE ROLE [rol_app_lectura]';
    ELSE CREATE ROLE [rol_app_lectura];
END;

IF NOT EXISTS (SELECT 1 FROM sys.database_principals WHERE name=N'rol_app_dml' AND type='R')
BEGIN
    IF @DryRun = 1 PRINT N'DRYRUN: CREATE ROLE [rol_app_dml]';
    ELSE CREATE ROLE [rol_app_dml];
END;

IF NOT EXISTS (SELECT 1 FROM sys.database_principals WHERE name=N'rol_app_bloqueo_dbo' AND type='R')
BEGIN
    IF @DryRun = 1 PRINT N'DRYRUN: CREATE ROLE [rol_app_bloqueo_dbo]';
    ELSE CREATE ROLE [rol_app_bloqueo_dbo];
END;

IF OBJECT_ID(N'tempdb..#Commands') IS NOT NULL DROP TABLE #Commands;
CREATE TABLE #Commands
(
    Id INT IDENTITY(1,1) PRIMARY KEY,
    CommandText NVARCHAR(MAX) NOT NULL,
    Reason NVARCHAR(4000) NULL
);

/* Tablas base que tienen vista equivalente masked.<Tabla>. */
IF OBJECT_ID(N'tempdb..#MappedObjects') IS NOT NULL DROP TABLE #MappedObjects;
SELECT
    bt.object_id AS BaseObjectId,
    mv.object_id AS ViewObjectId,
    bs.name AS BaseSchema,
    bt.name AS TableName,
    ms.name AS MaskedSchema
INTO #MappedObjects
FROM sys.tables bt
JOIN sys.schemas bs ON bs.schema_id = bt.schema_id
JOIN sys.views mv ON mv.name = bt.name
JOIN sys.schemas ms ON ms.schema_id = mv.schema_id
WHERE bs.name = @BaseSchema
  AND ms.name = @MaskedSchema
  AND bt.is_ms_shipped = 0;

IF NOT EXISTS (SELECT 1 FROM #MappedObjects)
BEGIN
    PRINT N'AVISO: No se encontraron vistas masked equivalentes a tablas dbo.';
END;


/* Principales protegidos que nunca deben modificarse automáticamente. */
IF OBJECT_ID(N'tempdb..#ProtectedPrincipals') IS NOT NULL DROP TABLE #ProtectedPrincipals;
CREATE TABLE #ProtectedPrincipals
(
    PrincipalId INT NULL,
    PrincipalName SYSNAME NOT NULL,
    Reason NVARCHAR(200) NOT NULL
);

INSERT INTO #ProtectedPrincipals(PrincipalId, PrincipalName, Reason)
SELECT principal_id, name, N'Principal del sistema o rol fijo'
FROM sys.database_principals
WHERE name IN
(
    N'dbo', N'guest', N'INFORMATION_SCHEMA', N'sys', N'public',
    N'db_owner', N'db_accessadmin', N'db_securityadmin', N'db_ddladmin',
    N'db_backupoperator', N'db_datareader', N'db_datawriter',
    N'db_denydatareader', N'db_denydatawriter'
)
OR ISNULL(is_fixed_role, 0) = 1;

INSERT INTO #ProtectedPrincipals(PrincipalId, PrincipalName, Reason)
SELECT DISTINCT dp.principal_id, dp.name, N'Miembro de db_owner'
FROM sys.database_role_members drm
JOIN sys.database_principals r ON r.principal_id = drm.role_principal_id
JOIN sys.database_principals dp ON dp.principal_id = drm.member_principal_id
WHERE r.name = N'db_owner'
  AND NOT EXISTS (SELECT 1 FROM #ProtectedPrincipals pp WHERE pp.PrincipalId = dp.principal_id);

BEGIN TRY
    INSERT INTO #ProtectedPrincipals(PrincipalId, PrincipalName, Reason)
    SELECT DISTINCT dp.principal_id, dp.name, N'Login miembro de sysadmin'
    FROM sys.server_role_members srm
    JOIN sys.server_principals sr ON sr.principal_id = srm.role_principal_id
    JOIN sys.server_principals sp ON sp.principal_id = srm.member_principal_id
    JOIN sys.database_principals dp ON dp.sid = sp.sid
    WHERE sr.name = N'sysadmin'
      AND NOT EXISTS (SELECT 1 FROM #ProtectedPrincipals pp WHERE pp.PrincipalId = dp.principal_id);
END TRY
BEGIN CATCH
    PRINT N'AVISO: No se pudo validar membresía sysadmin para todos los principales. Se continuará excluyendo db_owner y roles fijos.';
END CATCH;

INSERT INTO #ProtectedPrincipals(PrincipalId, PrincipalName, Reason)
SELECT dp.principal_id, dp.name, N'Excluido en dbo.Masked_PrincipalExclusions'
FROM dbo.Masked_PrincipalExclusions e
JOIN sys.database_principals dp ON dp.name = e.PrincipalName
WHERE e.IsEnabled = 1
  AND NOT EXISTS (SELECT 1 FROM #ProtectedPrincipals pp WHERE pp.PrincipalId = dp.principal_id);

/* Principales candidatos para copiar permisos. */
IF OBJECT_ID(N'tempdb..#Principals') IS NOT NULL DROP TABLE #Principals;
CREATE TABLE #Principals
(
    PrincipalId INT NOT NULL PRIMARY KEY,
    PrincipalName SYSNAME NOT NULL,
    PrincipalType CHAR(1) NOT NULL,
    ApplyDefaultSchema BIT NOT NULL DEFAULT 0,
    MirrorObjectPermissions BIT NOT NULL DEFAULT 1,
    IncludeDml BIT NOT NULL DEFAULT 0,
    AddToReadRole BIT NOT NULL DEFAULT 0,
    AddToDmlRole BIT NOT NULL DEFAULT 0,
    BlockBaseAccess BIT NOT NULL DEFAULT 0
);

IF @MirrorScope = N'POLICY_TABLE'
BEGIN
    INSERT INTO #Principals(PrincipalId, PrincipalName, PrincipalType, ApplyDefaultSchema, MirrorObjectPermissions, IncludeDml, AddToReadRole, AddToDmlRole, BlockBaseAccess)
    SELECT dp.principal_id,
           dp.name,
           dp.[type],
           p.ApplyDefaultSchema,
           p.MirrorObjectPermissions,
           p.IncludeDml,
           p.AddToReadRole,
           p.AddToDmlRole,
           p.BlockBaseAccess
    FROM dbo.Masked_PrincipalPolicy p
    JOIN sys.database_principals dp
      ON dp.name = p.PrincipalName
    WHERE p.IsEnabled = 1
      AND NOT EXISTS (SELECT 1 FROM #ProtectedPrincipals pp WHERE pp.PrincipalId = dp.principal_id)
      AND NOT EXISTS (SELECT 1 FROM dbo.Masked_PrincipalExclusions e WHERE e.IsEnabled = 1 AND e.PrincipalName = dp.name);
END
ELSE
BEGIN
    INSERT INTO #Principals(PrincipalId, PrincipalName, PrincipalType, ApplyDefaultSchema, MirrorObjectPermissions, IncludeDml, AddToReadRole, AddToDmlRole, BlockBaseAccess)
    SELECT DISTINCT dp.principal_id,
           dp.name,
           dp.[type],
           0 AS ApplyDefaultSchema,
           1 AS MirrorObjectPermissions,
           @CopyDml AS IncludeDml,
           0 AS AddToReadRole,
           0 AS AddToDmlRole,
           0 AS BlockBaseAccess
    FROM sys.database_permissions perm
    JOIN #MappedObjects mo
      ON mo.BaseObjectId = perm.major_id
    JOIN sys.database_principals dp
      ON dp.principal_id = perm.grantee_principal_id
    WHERE perm.class = 1
      AND NOT EXISTS (SELECT 1 FROM #ProtectedPrincipals pp WHERE pp.PrincipalId = dp.principal_id)
      AND NOT EXISTS (SELECT 1 FROM dbo.Masked_PrincipalExclusions e WHERE e.IsEnabled = 1 AND e.PrincipalName = dp.name);
END;

PRINT N'--- Principales protegidos/excluidos que no se modificarán ---';
SELECT PrincipalName, Reason FROM #ProtectedPrincipals ORDER BY PrincipalName;

/* Avisar si hay registros en policy sin usuario/principal existente. */
PRINT N'--- Registros de dbo.Masked_PrincipalPolicy sin principal en la base ---';
SELECT p.PrincipalName, p.Notes
FROM dbo.Masked_PrincipalPolicy p
LEFT JOIN sys.database_principals dp ON dp.name = p.PrincipalName
WHERE p.IsEnabled = 1
  AND dp.principal_id IS NULL
  AND NOT EXISTS (SELECT 1 FROM dbo.Masked_PrincipalExclusions e WHERE e.IsEnabled = 1 AND e.PrincipalName = p.PrincipalName);

PRINT N'--- Exclusiones configuradas en dbo.Masked_PrincipalExclusions ---';
SELECT PrincipalName, Reason
FROM dbo.Masked_PrincipalExclusions
WHERE IsEnabled = 1
ORDER BY PrincipalName;

/* DEFAULT_SCHEMA = masked solo para usuarios controlados, no roles. */
IF @ApplyDefaultSchemaFromPolicy = 1
BEGIN
    INSERT INTO #Commands(CommandText, Reason)
    SELECT N'ALTER USER ' + QUOTENAME(PrincipalName) + N' WITH DEFAULT_SCHEMA = ' + QUOTENAME(@MaskedSchema) + N';',
           N'Aplicar DEFAULT_SCHEMA=masked solo a principal listado en dbo.Masked_PrincipalPolicy.'
    FROM #Principals
    WHERE ApplyDefaultSchema = 1
      AND PrincipalType <> 'R';
END;

/* Membresia opcional a roles de apoyo, si el usuario lo pide. */
IF @AddRoleMembershipsFromPolicy = 1
BEGIN
    INSERT INTO #Commands(CommandText, Reason)
    SELECT N'ALTER ROLE [rol_app_lectura] ADD MEMBER ' + QUOTENAME(p.PrincipalName) + N';',
           N'Agregar a rol_app_lectura segun Masked_PrincipalPolicy.'
    FROM #Principals p
    WHERE p.AddToReadRole = 1
      AND p.PrincipalType <> 'R'
      AND NOT EXISTS
      (
          SELECT 1
          FROM sys.database_role_members drm
          JOIN sys.database_principals r ON r.principal_id = drm.role_principal_id
          WHERE r.name = N'rol_app_lectura'
            AND drm.member_principal_id = p.PrincipalId
      );

    INSERT INTO #Commands(CommandText, Reason)
    SELECT N'ALTER ROLE [rol_app_dml] ADD MEMBER ' + QUOTENAME(p.PrincipalName) + N';',
           N'Agregar a rol_app_dml segun Masked_PrincipalPolicy.'
    FROM #Principals p
    WHERE p.AddToDmlRole = 1
      AND p.PrincipalType <> 'R'
      AND NOT EXISTS
      (
          SELECT 1
          FROM sys.database_role_members drm
          JOIN sys.database_principals r ON r.principal_id = drm.role_principal_id
          WHERE r.name = N'rol_app_dml'
            AND drm.member_principal_id = p.PrincipalId
      );
END;

/* Copia permisos puntuales objeto/columna desde dbo.Tabla hacia masked.Tabla. */
IF @MirrorPermissions = 1
BEGIN
    ;WITH Perms AS
    (
        SELECT
            perm.state,
            perm.state_desc,
            perm.permission_name,
            perm.grantee_principal_id,
            pr.PrincipalName,
            mo.BaseSchema,
            mo.MaskedSchema,
            mo.TableName,
            mo.BaseObjectId,
            mo.ViewObjectId,
            perm.minor_id,
            bc.name AS BaseColumnName,
            vc.name AS ViewColumnName,
            pr.IncludeDml
        FROM sys.database_permissions perm
        JOIN #MappedObjects mo
          ON mo.BaseObjectId = perm.major_id
        JOIN #Principals pr
          ON pr.PrincipalId = perm.grantee_principal_id
        LEFT JOIN sys.columns bc
          ON bc.object_id = mo.BaseObjectId
         AND bc.column_id = perm.minor_id
        LEFT JOIN sys.columns vc
          ON vc.object_id = mo.ViewObjectId
         AND vc.name = bc.name
        WHERE perm.class = 1
          AND pr.MirrorObjectPermissions = 1
          AND perm.state IN ('G','W','D')
          AND (
                perm.permission_name = N'SELECT'
             OR (pr.IncludeDml = 1 AND @CopyDml = 1 AND perm.permission_name IN (N'INSERT', N'UPDATE', N'DELETE'))
          )
          AND (
                perm.minor_id = 0
             OR (@IncludeColumnPermissions = 1 AND vc.column_id IS NOT NULL)
          )
    )
    INSERT INTO #Commands(CommandText, Reason)
    SELECT
        CASE
            WHEN state = 'D' THEN
                N'DENY ' + permission_name + N' ON OBJECT::' + QUOTENAME(MaskedSchema) + N'.' + QUOTENAME(TableName) +
                CASE WHEN minor_id > 0 THEN N'(' + QUOTENAME(ViewColumnName) + N')' ELSE N'' END +
                N' TO ' + QUOTENAME(PrincipalName) + N';'
            WHEN state = 'W' THEN
                N'GRANT ' + permission_name + N' ON OBJECT::' + QUOTENAME(MaskedSchema) + N'.' + QUOTENAME(TableName) +
                CASE WHEN minor_id > 0 THEN N'(' + QUOTENAME(ViewColumnName) + N')' ELSE N'' END +
                N' TO ' + QUOTENAME(PrincipalName) + N' WITH GRANT OPTION;'
            ELSE
                N'GRANT ' + permission_name + N' ON OBJECT::' + QUOTENAME(MaskedSchema) + N'.' + QUOTENAME(TableName) +
                CASE WHEN minor_id > 0 THEN N'(' + QUOTENAME(ViewColumnName) + N')' ELSE N'' END +
                N' TO ' + QUOTENAME(PrincipalName) + N';'
        END AS CommandText,
        N'Permiso puntual copiado desde ' + QUOTENAME(BaseSchema) + N'.' + QUOTENAME(TableName) +
        N' hacia ' + QUOTENAME(MaskedSchema) + N'.' + QUOTENAME(TableName) +
        CASE WHEN minor_id > 0 THEN N' columna ' + QUOTENAME(ViewColumnName) ELSE N'' END AS Reason
    FROM Perms p
    WHERE NOT EXISTS
    (
        SELECT 1
        FROM sys.database_permissions existing
        WHERE existing.class = 1
          AND existing.major_id = p.ViewObjectId
          AND existing.minor_id = CASE WHEN p.minor_id > 0 THEN COLUMNPROPERTY(p.ViewObjectId, p.ViewColumnName, 'ColumnId') ELSE 0 END
          AND existing.grantee_principal_id = p.grantee_principal_id
          AND existing.permission_name = p.permission_name
          AND existing.state = p.state
    );
END;

/* Acciones opcionales sobre permisos base. Por defecto solo reporte. */
IF @BaseAccessAction = N'REVOKE_EXPLICIT_OBJECT_PERMISSIONS'
BEGIN
    ;WITH PermsToRevoke AS
    (
        SELECT DISTINCT
            perm.permission_name,
            perm.grantee_principal_id,
            pr.PrincipalName,
            mo.BaseSchema,
            mo.TableName,
            mo.BaseObjectId,
            perm.minor_id,
            bc.name AS BaseColumnName,
            pr.BlockBaseAccess,
            pr.IncludeDml
        FROM sys.database_permissions perm
        JOIN #MappedObjects mo ON mo.BaseObjectId = perm.major_id
        JOIN #Principals pr ON pr.PrincipalId = perm.grantee_principal_id
        LEFT JOIN sys.columns bc ON bc.object_id = mo.BaseObjectId AND bc.column_id = perm.minor_id
        WHERE perm.class = 1
          AND pr.BlockBaseAccess = 1
          AND perm.permission_name IN (N'SELECT', N'INSERT', N'UPDATE', N'DELETE')
          AND (perm.permission_name = N'SELECT' OR pr.IncludeDml = 1)
    )
    INSERT INTO #Commands(CommandText, Reason)
    SELECT N'REVOKE ' + permission_name + N' ON OBJECT::' + QUOTENAME(BaseSchema) + N'.' + QUOTENAME(TableName) +
           CASE WHEN minor_id > 0 THEN N'(' + QUOTENAME(BaseColumnName) + N')' ELSE N'' END +
           N' FROM ' + QUOTENAME(PrincipalName) + N';',
           N'Quitar permiso explicito directo sobre tabla base solo para principal con BlockBaseAccess=1.'
    FROM PermsToRevoke;
END
ELSE IF @BaseAccessAction = N'DENY_BASE_FOR_POLICY_PRINCIPALS'
BEGIN
    INSERT INTO #Commands(CommandText, Reason)
    SELECT DISTINCT
           N'DENY SELECT' +
           CASE WHEN p.IncludeDml = 1 AND @CopyDml = 1 THEN N', INSERT, UPDATE, DELETE' ELSE N'' END +
           N' ON OBJECT::' + QUOTENAME(mo.BaseSchema) + N'.' + QUOTENAME(mo.TableName) +
           N' TO ' + QUOTENAME(p.PrincipalName) + N';',
           N'DENY directo a tabla base. Usar solo tras validar que la vista masked funciona.'
    FROM #MappedObjects mo
    CROSS JOIN #Principals p
    WHERE p.BlockBaseAccess = 1;
END
ELSE
BEGIN
    PRINT N'AVISO: @BaseAccessAction = REPORT_ONLY. No se revocaran ni denegaran permisos en dbo.';
END;

/* Ejecutar o mostrar comandos. */
DECLARE @Id INT = 1, @MaxId INT = (SELECT ISNULL(MAX(Id),0) FROM #Commands);
DECLARE @cmd NVARCHAR(MAX), @reason NVARCHAR(4000);

WHILE @Id <= @MaxId
BEGIN
    SELECT @cmd = CommandText, @reason = Reason FROM #Commands WHERE Id = @Id;

    IF @DryRun = 1
    BEGIN
        PRINT N'DRYRUN: ' + @cmd + N' -- ' + ISNULL(@reason, N'');
    END
    ELSE
    BEGIN
        BEGIN TRY
            EXEC sp_executesql @cmd;
            INSERT INTO dbo.Masked_Audit(EventType, SchemaName, ObjectName, ColumnName, Action, Detail)
            VALUES(N'POLICY', NULL, NULL, NULL, N'APPLY', @cmd);
        END TRY
        BEGIN CATCH
            INSERT INTO dbo.Masked_Audit(EventType, SchemaName, ObjectName, ColumnName, Action, Detail)
            VALUES(N'ERROR', NULL, NULL, NULL, N'POLICY', ERROR_MESSAGE() + N' | ' + @cmd);
            PRINT N'ERROR: ' + ERROR_MESSAGE() + N' | ' + @cmd;
        END CATCH;
    END;

    SET @Id += 1;
END;

/* Reportes finales. */
PRINT N'--- Resumen de objetos mapeados dbo -> masked ---';
SELECT BaseSchema, TableName, MaskedSchema
FROM #MappedObjects
ORDER BY BaseSchema, TableName;

PRINT N'--- Principales considerados por la politica ---';
SELECT PrincipalName, PrincipalType, ApplyDefaultSchema, MirrorObjectPermissions, IncludeDml, AddToReadRole, AddToDmlRole, BlockBaseAccess
FROM #Principals
ORDER BY PrincipalName;

PRINT N'--- Permisos explicitos sobre tablas base que siguen existiendo. No se tocaron si BaseAccessAction=REPORT_ONLY. ---';
SELECT
    USER_NAME(perm.grantee_principal_id) AS GranteeName,
    perm.state_desc,
    perm.permission_name,
    mo.BaseSchema,
    mo.TableName,
    CASE WHEN perm.minor_id > 0 THEN COL_NAME(perm.major_id, perm.minor_id) ELSE NULL END AS ColumnName
FROM sys.database_permissions perm
JOIN #MappedObjects mo ON mo.BaseObjectId = perm.major_id
WHERE perm.class = 1
ORDER BY GranteeName, mo.BaseSchema, mo.TableName, permission_name, ColumnName;

PRINT N'--- Usuarios en roles amplios que pueden saltarse la capa masked si consultan dbo.Tabla ---';
SELECT dp.name AS UserName,
       rp.name AS RoleName
FROM sys.database_role_members drm
JOIN sys.database_principals rp ON rp.principal_id = drm.role_principal_id
JOIN sys.database_principals dp ON dp.principal_id = drm.member_principal_id
WHERE rp.name IN (N'db_datareader', N'db_datawriter', N'db_owner')
ORDER BY rp.name, dp.name;

PRINT N'Politica finalizada. Revisa los reportes antes de quitar o denegar permisos sobre dbo.';
