/* ===========================================================
   sp_ManageColumnRule.sql - corregido
   Compatible SQL Server 2016+

   Corrige la generación de ViewMaskExpr para partial().
   V4: @RequiresView permite forzar la creación de vista masked para una columna.
   Acciones: ADD, UPDATE, DELETE, GET, ENABLE, DISABLE.
   ===========================================================*/
IF OBJECT_ID(N'dbo.sp_Masked_ManageColumnRule', N'P') IS NOT NULL
    DROP PROCEDURE dbo.sp_Masked_ManageColumnRule;
GO
CREATE PROCEDURE dbo.sp_Masked_ManageColumnRule
    @Action         NVARCHAR(20),
    @SchemaName     SYSNAME = N'dbo',
    @TableName      SYSNAME,
    @ColumnName     SYSNAME = NULL,
    @MaskType       NVARCHAR(50) = NULL,
    @MaskParams     NVARCHAR(200) = NULL,
    @CustomFunction NVARCHAR(1000) = NULL,
    @Priority       INT = 10,
    @RequiresView   BIT = 0
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    SET @Action = UPPER(LTRIM(RTRIM(@Action)));

    IF @Action IN (N'ADD', N'UPDATE')
    BEGIN
        IF @ColumnName IS NULL
            THROW 50000, N'ColumnName es obligatorio para ADD/UPDATE.', 1;

        IF @MaskType NOT IN (N'partial', N'email', N'default', N'random', N'custom', N'none')
            THROW 50001, N'MaskType invalido. Use partial, email, default, random, custom o none.', 1;

        DECLARE @DdmFunction NVARCHAR(200) = NULL;
        DECLARE @ViewMaskExpr NVARCHAR(1000) = NULL;
        DECLARE @IsEnabled BIT = 1;

        IF @MaskType = N'none'
        BEGIN
            SET @IsEnabled = 0;
            SET @DdmFunction = NULL;
            SET @ViewMaskExpr = NULL;
        END
        ELSE IF @MaskType = N'default'
        BEGIN
            SET @DdmFunction = N'default()';
            SET @ViewMaskExpr = N'NULL';
        END
        ELSE IF @MaskType = N'email'
        BEGIN
            SET @DdmFunction = N'email()';
            SET @ViewMaskExpr = N'CASE WHEN {col} IS NULL THEN NULL ELSE CASE WHEN CHARINDEX(''@'',{col})>1 THEN LEFT({col},1)+''*****''+SUBSTRING({col},CHARINDEX(''@'',{col}),LEN({col})-CHARINDEX(''@'',{col})+1) ELSE ''*****'' END END';
        END
        ELSE IF @MaskType = N'random'
        BEGIN
            -- @MaskParams esperado: inicio,fin  ejemplo: 1,9999
            IF @MaskParams IS NULL OR CHARINDEX(N',', @MaskParams) = 0
                THROW 50002, N'MaskParams para random debe ser inicio,fin. Ejemplo: 1,9999.', 1;

            SET @DdmFunction = N'random(' + @MaskParams + N')';
            -- En vista no devolvemos numeros aleatorios; se oculta de forma estable.
            SET @ViewMaskExpr = N'NULL';
        END
        ELSE IF @MaskType = N'partial'
        BEGIN
            -- @MaskParams esperado: prefijo,"relleno",sufijo  ejemplo: 0,"XXXX",4
            DECLARE @FirstComma INT = CHARINDEX(N',', @MaskParams);
            DECLARE @LastComma  INT = LEN(@MaskParams) - CHARINDEX(N',', REVERSE(@MaskParams)) + 1;
            DECLARE @PrefixLen INT;
            DECLARE @SuffixLen INT;

            IF @MaskParams IS NULL OR @FirstComma = 0 OR @LastComma <= @FirstComma
                THROW 50003, N'MaskParams para partial debe ser prefijo,"relleno",sufijo. Ejemplo: 0,"XXXX",4.', 1;

            SET @PrefixLen = TRY_CONVERT(INT, LTRIM(RTRIM(SUBSTRING(@MaskParams, 1, @FirstComma - 1))));
            SET @SuffixLen = TRY_CONVERT(INT, LTRIM(RTRIM(SUBSTRING(@MaskParams, @LastComma + 1, LEN(@MaskParams)))));

            IF @PrefixLen IS NULL OR @SuffixLen IS NULL OR @PrefixLen < 0 OR @SuffixLen < 0
                THROW 50004, N'Prefijo y sufijo de partial deben ser numeros enteros >= 0.', 1;

            SET @DdmFunction = N'partial(' + @MaskParams + N')';
            SET @ViewMaskExpr =
                N'CASE WHEN {col} IS NULL THEN NULL ELSE ' +
                N'LEFT({col}, CASE WHEN LEN({col})>' + CONVERT(NVARCHAR(10), @PrefixLen) + N' THEN ' + CONVERT(NVARCHAR(10), @PrefixLen) + N' ELSE LEN({col}) END)' +
                N' + REPLICATE(''X'', CASE WHEN LEN({col})>' + CONVERT(NVARCHAR(10), @PrefixLen + @SuffixLen) + N' THEN LEN({col})-' + CONVERT(NVARCHAR(10), @PrefixLen + @SuffixLen) + N' ELSE 0 END)' +
                N' + RIGHT({col}, CASE WHEN LEN({col})>' + CONVERT(NVARCHAR(10), @PrefixLen + @SuffixLen) + N' THEN ' + CONVERT(NVARCHAR(10), @SuffixLen) + N' ELSE 0 END)' +
                N' END';
        END
        ELSE IF @MaskType = N'custom'
        BEGIN
            IF @CustomFunction IS NULL OR CHARINDEX(N'{col}', @CustomFunction) = 0
                THROW 50005, N'CustomFunction debe incluir el marcador {col}.', 1;

            -- Para custom no se genera DDM automaticamente, solo expresion de vista.
            SET @DdmFunction = NULL;
            SET @ViewMaskExpr = @CustomFunction;
        END

        MERGE dbo.Masked_ColumnRules AS target
        USING (SELECT @SchemaName AS SchemaName, @TableName AS TableName, @ColumnName AS ColumnName) AS source
        ON target.SchemaName = source.SchemaName
           AND target.TableName = source.TableName
           AND target.ColumnName = source.ColumnName
        WHEN MATCHED THEN
            UPDATE SET IsEnabled = @IsEnabled,
                       MaskType = @MaskType,
                       MaskParams = @MaskParams,
                       CustomFunction = @CustomFunction,
                       DdmFunction = @DdmFunction,
                       ViewMaskExpr = @ViewMaskExpr,
                       Priority = @Priority,
                       RequiresView = @RequiresView,
                       ModifiedAt = SYSUTCDATETIME()
        WHEN NOT MATCHED THEN
            INSERT (SchemaName, TableName, ColumnName, IsEnabled, MaskType, MaskParams, CustomFunction, DdmFunction, ViewMaskExpr, Priority, RequiresView)
            VALUES (@SchemaName, @TableName, @ColumnName, @IsEnabled, @MaskType, @MaskParams, @CustomFunction, @DdmFunction, @ViewMaskExpr, @Priority, @RequiresView);
    END
    ELSE IF @Action = N'DELETE'
    BEGIN
        DELETE FROM dbo.Masked_ColumnRules
        WHERE SchemaName = @SchemaName
          AND TableName = @TableName
          AND (@ColumnName IS NULL OR ColumnName = @ColumnName);
    END
    ELSE IF @Action = N'DISABLE'
    BEGIN
        UPDATE dbo.Masked_ColumnRules
        SET IsEnabled = 0, ModifiedAt = SYSUTCDATETIME()
        WHERE SchemaName = @SchemaName
          AND TableName = @TableName
          AND (@ColumnName IS NULL OR ColumnName = @ColumnName);
    END
    ELSE IF @Action = N'ENABLE'
    BEGIN
        UPDATE dbo.Masked_ColumnRules
        SET IsEnabled = 1, ModifiedAt = SYSUTCDATETIME()
        WHERE SchemaName = @SchemaName
          AND TableName = @TableName
          AND (@ColumnName IS NULL OR ColumnName = @ColumnName);
    END
    ELSE IF @Action = N'GET'
    BEGIN
        SELECT RuleId, SchemaName, TableName, ColumnName, IsEnabled,
               MaskType, MaskParams, CustomFunction, DdmFunction, ViewMaskExpr, Priority, RequiresView,
               CreatedAt, ModifiedAt
        FROM dbo.Masked_ColumnRules
        WHERE SchemaName = @SchemaName
          AND TableName = @TableName
          AND (@ColumnName IS NULL OR ColumnName = @ColumnName)
        ORDER BY Priority DESC, ColumnName;
    END
    ELSE
    BEGIN
        THROW 50006, N'Action invalida. Use ADD, UPDATE, DELETE, GET, ENABLE o DISABLE.', 1;
    END
END;
GO
