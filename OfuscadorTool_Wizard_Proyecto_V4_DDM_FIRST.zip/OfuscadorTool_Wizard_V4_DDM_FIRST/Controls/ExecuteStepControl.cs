using OfuscadorTool.Models;
using OfuscadorTool.Services;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OfuscadorTool
{
    public class ExecuteStepControl : WizardStepBase
    {
        public override string StepTitle => "Ejecución";
        private readonly GlobalConfig _config;
        private readonly DeploymentService _deployment = new DeploymentService();
        private readonly ProgressBar _progress = new ProgressBar();
        private readonly TextBox _log = new TextBox();
        private readonly DataGridView _resultsGrid = new DataGridView();
        private readonly Button _btnExecute = new Button();
        private BindingList<DeploymentResult> _results = new BindingList<DeploymentResult>();

        public ExecuteStepControl(GlobalConfig config)
        {
            _config = config;
            BuildUi();
        }

        private void BuildUi()
        {
            var layout = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                ColumnCount = 1,
                RowCount = 4,
                BackColor = System.Drawing.Color.White
            };
            layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 46));
            layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 26));
            layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 170));
            layout.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
            Controls.Add(layout);

            var top = new FlowLayoutPanel
            {
                Dock = DockStyle.Fill,
                FlowDirection = FlowDirection.LeftToRight,
                WrapContents = false,
                Padding = new Padding(0, 5, 0, 4),
                BackColor = System.Drawing.Color.White
            };
            _btnExecute.Text = "Ejecutar despliegue";
            _btnExecute.Width = 160;
            _btnExecute.Height = 30;
            _btnExecute.Click += async (_, __) => await ExecuteAsync();
            top.Controls.Add(_btnExecute);
            layout.Controls.Add(top, 0, 0);

            _progress.Dock = DockStyle.Fill;
            layout.Controls.Add(_progress, 0, 1);

            _resultsGrid.Dock = DockStyle.Fill;
            _resultsGrid.AutoGenerateColumns = false;
            _resultsGrid.ReadOnly = true;
            _resultsGrid.AllowUserToAddRows = false;
            _resultsGrid.BackgroundColor = System.Drawing.Color.White;
            _resultsGrid.BorderStyle = BorderStyle.FixedSingle;
            _resultsGrid.RowHeadersVisible = false;
            _resultsGrid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Servidor", DataPropertyName = "ServerName", Width = 180 });
            _resultsGrid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Base", DataPropertyName = "DatabaseName", Width = 180 });
            _resultsGrid.Columns.Add(new DataGridViewCheckBoxColumn { HeaderText = "OK", DataPropertyName = "Success", Width = 50 });
            _resultsGrid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Error", DataPropertyName = "ErrorMessage", AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill });
            _resultsGrid.DataSource = _results;
            layout.Controls.Add(_resultsGrid, 0, 2);

            _log.Dock = DockStyle.Fill;
            _log.Multiline = true;
            _log.ScrollBars = ScrollBars.Both;
            _log.ReadOnly = true;
            _log.Font = new System.Drawing.Font("Consolas", 9F);
            _log.BorderStyle = BorderStyle.FixedSingle;
            layout.Controls.Add(_log, 0, 3);
        }

        private async Task ExecuteAsync()
        {
            var confirmMessage = _config.DefaultOptions.DryRun
                ? "Se ejecutará en modo DryRun/simulación. ¿Continuar?"
                : "DryRun está desactivado. Se ejecutarán cambios reales en SQL Server. ¿Continuar?";

            if (MessageBox.Show(confirmMessage, "Confirmar ejecución", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes)
                return;

            _btnExecute.Enabled = false;
            _results = new BindingList<DeploymentResult>();
            _resultsGrid.DataSource = _results;
            _log.Clear();

            try
            {
                var jobs = await BuildDeploymentJobsAsync();
                if (jobs.Count == 0)
                {
                    MessageBox.Show("No hay bases seleccionadas para desplegar.", "Sin trabajo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }

                _progress.Minimum = 0;
                _progress.Maximum = jobs.Count;
                _progress.Value = 0;

                foreach (var job in jobs)
                {
                    var result = await _deployment.DeployDatabaseAsync(
                        job.Server,
                        job.DatabaseName,
                        _config.DefaultOptions,
                        _config.PrincipalPolicies,
                        AppendLog);

                    _results.Add(result);
                    _progress.Value = Math.Min(_progress.Maximum, _progress.Value + 1);
                }

                SaveLogToFile();
                MessageBox.Show("Ejecución finalizada. Revisa la tabla de resultados y el log.", "Finalizado", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                AppendLog("ERROR GENERAL: " + ex.Message);
                MessageBox.Show(ex.Message, "Error general", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                _btnExecute.Enabled = true;
            }
        }

        private async Task<List<DeploymentJob>> BuildDeploymentJobsAsync()
        {
            var jobs = new List<DeploymentJob>();

            foreach (var server in _config.Servers.Where(s => s.IsEnabled))
            {
                AppendLog($"Cargando bases disponibles de {server.DisplayName}...");
                var available = await _deployment.GetDatabasesAsync(server);
                var selected = _deployment.ResolveSelectedDatabases(server, _config, available);

                foreach (var db in selected)
                {
                    jobs.Add(new DeploymentJob { Server = server, DatabaseName = db });
                }
            }

            return jobs;
        }

        private void AppendLog(string message)
        {
            if (InvokeRequired)
            {
                BeginInvoke(new Action<string>(AppendLog), message);
                return;
            }

            _log.AppendText($"[{DateTime.Now:HH:mm:ss}] {message}{Environment.NewLine}");
        }

        private void SaveLogToFile()
        {
            try
            {
                string folder = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, _config.LogPath ?? "Logs");
                Directory.CreateDirectory(folder);
                string path = Path.Combine(folder, $"OfuscadorTool_{DateTime.Now:yyyyMMdd_HHmmss}.log");
                File.WriteAllText(path, _log.Text);
                AppendLog("Log guardado en: " + path);
            }
            catch (Exception ex)
            {
                AppendLog("No se pudo guardar el log: " + ex.Message);
            }
        }

        private class DeploymentJob
        {
            public ServerConnection Server { get; set; }
            public string DatabaseName { get; set; }
        }
    }
}
