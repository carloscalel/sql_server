using OfuscadorTool.Models;
using OfuscadorTool.Services;
using System;
using System.ComponentModel;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OfuscadorTool
{
    public class PrincipalPolicyStepControl : WizardStepBase
    {
        public override string StepTitle => "Usuarios / políticas";

        private readonly GlobalConfig _config;
        private readonly DeploymentService _deployment = new DeploymentService();
        private BindingList<PrincipalPolicy> _binding;

        private readonly ComboBox _cmbServers = new ComboBox();
        private readonly ComboBox _cmbDatabases = new ComboBox();
        private readonly DataGridView _grid = new DataGridView();
        private readonly Label _status = new Label();

        private readonly CheckBox _bulkDefaultSchema = new CheckBox { Text = "DefaultSchema=masked a cargados", Checked = true, AutoSize = true };
        private readonly CheckBox _bulkMirror = new CheckBox { Text = "Copiar permisos a cargados", Checked = true, AutoSize = true };
        private readonly CheckBox _bulkDml = new CheckBox { Text = "Incluir DML a cargados", Checked = false, AutoSize = true };

        public PrincipalPolicyStepControl(GlobalConfig config)
        {
            _config = config;
            BuildUi();
            LoadGrid();
        }

        private void BuildUi()
        {
            var layout = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                ColumnCount = 1,
                RowCount = 4,
                BackColor = System.Drawing.Color.White
            };
            layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 82));
            layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 44));
            layout.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
            layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 60));
            Controls.Add(layout);

            var sourceBar = new FlowLayoutPanel
            {
                Dock = DockStyle.Fill,
                FlowDirection = FlowDirection.LeftToRight,
                WrapContents = true,
                Padding = new Padding(0, 3, 0, 0),
                BackColor = System.Drawing.Color.White
            };

            _cmbServers.DropDownStyle = ComboBoxStyle.DropDownList;
            _cmbServers.Width = 240;
            _cmbDatabases.DropDownStyle = ComboBoxStyle.DropDownList;
            _cmbDatabases.Width = 260;

            var btnLoadDatabases = new Button { Text = "Cargar bases", Width = 110, Height = 28 };
            var btnLoadAll = new Button { Text = "Agregar usuarios/roles", Width = 150, Height = 28 };
            var btnLoadWithPerms = new Button { Text = "Agregar con permisos", Width = 150, Height = 28 };

            btnLoadDatabases.Click += async (_, __) => await LoadDatabasesAsync();
            btnLoadAll.Click += async (_, __) => await AddCandidatesAsync(false);
            btnLoadWithPerms.Click += async (_, __) => await AddCandidatesAsync(true);

            sourceBar.Controls.Add(new Label { Text = "Servidor:", AutoSize = true, Padding = new Padding(0, 7, 4, 0) });
            sourceBar.Controls.Add(_cmbServers);
            sourceBar.Controls.Add(btnLoadDatabases);
            sourceBar.Controls.Add(new Label { Text = "Base:", AutoSize = true, Padding = new Padding(12, 7, 4, 0) });
            sourceBar.Controls.Add(_cmbDatabases);
            sourceBar.Controls.Add(btnLoadAll);
            sourceBar.Controls.Add(btnLoadWithPerms);
            sourceBar.Controls.Add(_bulkDefaultSchema);
            sourceBar.Controls.Add(_bulkMirror);
            sourceBar.Controls.Add(_bulkDml);
            layout.Controls.Add(sourceBar, 0, 0);

            var toolbar = new FlowLayoutPanel
            {
                Dock = DockStyle.Fill,
                FlowDirection = FlowDirection.LeftToRight,
                WrapContents = false,
                Padding = new Padding(0, 5, 0, 4),
                BackColor = System.Drawing.Color.White
            };

            var btnAdd = new Button { Text = "Agregar manual", Width = 110, Height = 30 };
            var btnRemove = new Button { Text = "Quitar", Width = 90, Height = 30 };
            var btnExclude = new Button { Text = "Excluir seleccionado", Width = 140, Height = 30 };
            var btnReactivate = new Button { Text = "Reactivar seleccionado", Width = 150, Height = 30 };

            btnAdd.Click += (_, __) => AddPolicy();
            btnRemove.Click += (_, __) => RemovePolicy();
            btnExclude.Click += (_, __) => MarkSelectedExcluded();
            btnReactivate.Click += (_, __) => MarkSelectedActive();

            toolbar.Controls.AddRange(new Control[] { btnAdd, btnRemove, btnExclude, btnReactivate });
            layout.Controls.Add(toolbar, 0, 1);

            _grid.Dock = DockStyle.Fill;
            _grid.AutoGenerateColumns = false;
            _grid.AllowUserToAddRows = true;
            _grid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            _grid.BackgroundColor = System.Drawing.Color.White;
            _grid.BorderStyle = BorderStyle.FixedSingle;
            _grid.RowHeadersVisible = false;
            _grid.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.None;

            _grid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "PrincipalName", DataPropertyName = "PrincipalName", Width = 190 });
            _grid.Columns.Add(new DataGridViewCheckBoxColumn { HeaderText = "Activo", DataPropertyName = "IsEnabled", Width = 60 });
            _grid.Columns.Add(new DataGridViewCheckBoxColumn { HeaderText = "Excluir", DataPropertyName = "IsExcluded", Width = 65 });
            _grid.Columns.Add(new DataGridViewCheckBoxColumn { HeaderText = "DefaultSchema", DataPropertyName = "ApplyDefaultSchema", Width = 105 });
            _grid.Columns.Add(new DataGridViewCheckBoxColumn { HeaderText = "Copiar permisos", DataPropertyName = "MirrorObjectPermissions", Width = 115 });
            _grid.Columns.Add(new DataGridViewCheckBoxColumn { HeaderText = "Incluir DML", DataPropertyName = "IncludeDml", Width = 90 });
            _grid.Columns.Add(new DataGridViewCheckBoxColumn { HeaderText = "Rol lectura", DataPropertyName = "AddToReadRole", Width = 85 });
            _grid.Columns.Add(new DataGridViewCheckBoxColumn { HeaderText = "Rol DML", DataPropertyName = "AddToDmlRole", Width = 75 });
            _grid.Columns.Add(new DataGridViewCheckBoxColumn { HeaderText = "Bloquear dbo", DataPropertyName = "BlockBaseAccess", Width = 95 });
            _grid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Notas", DataPropertyName = "Notes", AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill });
            layout.Controls.Add(_grid, 0, 2);

            _status.Dock = DockStyle.Fill;
            _status.Text = "Puedes agregar usuarios manualmente o cargarlos desde una base. Se omiten db_owner, roles fijos y sysadmin cuando sea posible detectarlo. Los marcados como Excluir no se modifican.";
            _status.Padding = new Padding(5);
            _status.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            layout.Controls.Add(_status, 0, 3);
        }

        public override void OnStepVisible()
        {
            var selectedId = (_cmbServers.SelectedItem as ServerConnection)?.Id;
            var servers = _config.Servers.Where(s => s.IsEnabled).ToList();
            _cmbServers.DataSource = null;
            _cmbServers.DataSource = servers;
            _cmbServers.DisplayMember = "DisplayName";
            _cmbServers.ValueMember = "Id";

            if (!string.IsNullOrWhiteSpace(selectedId))
            {
                var server = servers.FirstOrDefault(s => s.Id == selectedId);
                if (server != null) _cmbServers.SelectedItem = server;
            }
        }

        private ServerConnection SelectedServer => _cmbServers.SelectedItem as ServerConnection;
        private string SelectedDatabase => _cmbDatabases.SelectedItem?.ToString();

        private async Task LoadDatabasesAsync()
        {
            if (SelectedServer == null)
            {
                MessageBox.Show("Selecciona un servidor primero.", "Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                Cursor.Current = Cursors.WaitCursor;
                _status.Text = "Cargando bases para políticas...";
                var databases = await _deployment.GetDatabasesAsync(SelectedServer);
                _cmbDatabases.DataSource = databases;
                _status.Text = $"Bases cargadas para políticas: {databases.Count}";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error al cargar bases", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                Cursor.Current = Cursors.Default;
            }
        }

        private async Task AddCandidatesAsync(bool onlyWithObjectPermissions)
        {
            if (SelectedServer == null || string.IsNullOrWhiteSpace(SelectedDatabase))
            {
                MessageBox.Show("Selecciona servidor y base. Primero usa Cargar bases.", "Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                _grid.EndEdit();
                Cursor.Current = Cursors.WaitCursor;
                _status.Text = onlyWithObjectPermissions ? "Buscando usuarios/roles con permisos..." : "Buscando usuarios/roles elegibles...";

                var candidates = await _deployment.GetPrincipalCandidatesAsync(SelectedServer, SelectedDatabase, onlyWithObjectPermissions);
                int added = 0;
                int skipped = 0;

                foreach (var c in candidates)
                {
                    if (string.IsNullOrWhiteSpace(c.PrincipalName))
                        continue;

                    var existing = _config.PrincipalPolicies.FirstOrDefault(p =>
                        string.Equals(p.PrincipalName?.Trim(), c.PrincipalName.Trim(), StringComparison.OrdinalIgnoreCase));

                    if (existing != null)
                    {
                        skipped++;
                        continue;
                    }

                    _config.PrincipalPolicies.Add(new PrincipalPolicy
                    {
                        PrincipalName = c.PrincipalName,
                        IsEnabled = true,
                        IsExcluded = false,
                        ApplyDefaultSchema = _bulkDefaultSchema.Checked,
                        MirrorObjectPermissions = _bulkMirror.Checked,
                        IncludeDml = _bulkDml.Checked,
                        AddToReadRole = false,
                        AddToDmlRole = false,
                        BlockBaseAccess = false,
                        Notes = $"Agregado desde {SelectedDatabase}. Fuente={c.Source}; Tipo={c.PrincipalType}; TienePermisos={c.HasObjectPermissions}."
                    });
                    added++;
                }

                LoadGrid();
                _status.Text = $"Candidatos encontrados: {candidates.Count}. Agregados: {added}. Ya existían: {skipped}.";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error al cargar usuarios/roles", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                Cursor.Current = Cursors.Default;
            }
        }

        private void LoadGrid()
        {
            _binding = new BindingList<PrincipalPolicy>(_config.PrincipalPolicies);
            _grid.DataSource = _binding;
        }

        private void AddPolicy()
        {
            _config.PrincipalPolicies.Add(new PrincipalPolicy { PrincipalName = "Usuario_o_Rol", IsEnabled = true, ApplyDefaultSchema = true, MirrorObjectPermissions = true });
            LoadGrid();
        }

        private void RemovePolicy()
        {
            if (_grid.CurrentRow?.DataBoundItem is PrincipalPolicy policy)
            {
                _config.PrincipalPolicies.Remove(policy);
                LoadGrid();
            }
        }

        private void MarkSelectedExcluded()
        {
            _grid.EndEdit();
            foreach (DataGridViewRow row in _grid.SelectedRows)
            {
                if (row.DataBoundItem is PrincipalPolicy p)
                {
                    p.IsExcluded = true;
                    p.IsEnabled = false;
                    p.ApplyDefaultSchema = false;
                    p.MirrorObjectPermissions = false;
                    p.IncludeDml = false;
                    p.BlockBaseAccess = false;
                    p.Notes = string.IsNullOrWhiteSpace(p.Notes) ? "Excluido desde OfuscadorTool. No modificar." : p.Notes + " | Excluido: no modificar.";
                }
            }
            _grid.Refresh();
            _status.Text = "Principales seleccionados marcados como excluidos. La política los omitirá aunque existan permisos.";
        }

        private void MarkSelectedActive()
        {
            _grid.EndEdit();
            foreach (DataGridViewRow row in _grid.SelectedRows)
            {
                if (row.DataBoundItem is PrincipalPolicy p)
                {
                    p.IsExcluded = false;
                    p.IsEnabled = true;
                    p.ApplyDefaultSchema = true;
                    p.MirrorObjectPermissions = true;
                }
            }
            _grid.Refresh();
            _status.Text = "Principales seleccionados reactivados.";
        }

        public override bool ValidateStep(out string message)
        {
            _grid.EndEdit();

            var duplicates = _config.PrincipalPolicies
                .Where(p => !string.IsNullOrWhiteSpace(p.PrincipalName))
                .GroupBy(p => p.PrincipalName.Trim().ToLowerInvariant())
                .Where(g => g.Count() > 1)
                .Select(g => g.Key)
                .ToList();

            if (duplicates.Any())
            {
                message = "Hay usuarios/roles duplicados en la política.";
                return false;
            }

            var dangerous = _config.PrincipalPolicies
                .Where(p => !p.IsExcluded && !string.IsNullOrWhiteSpace(p.PrincipalName))
                .Where(p => new[] { "dbo", "guest", "sys", "public", "db_owner", "db_datareader", "db_datawriter" }
                    .Contains(p.PrincipalName.Trim(), StringComparer.OrdinalIgnoreCase))
                .Select(p => p.PrincipalName)
                .ToList();

            if (dangerous.Any())
            {
                message = "Hay principales administrativos o roles amplios en la política activa: " + string.Join(", ", dangerous) + ". Márcalos como Excluir o elimínalos.";
                return false;
            }

            message = null;
            return true;
        }
    }
}
