using OfuscadorTool.Models;
using System;
using System.Windows.Forms;

namespace OfuscadorTool
{
    public class OptionsStepControl : WizardStepBase
    {
        public override string StepTitle => "Opciones";
        private readonly GlobalConfig _config;

        private readonly CheckBox _applyDdm = new CheckBox { Text = "Aplicar Dynamic Data Masking sobre tablas dbo", AutoSize = true };
        private readonly CheckBox _createViews = new CheckBox { Text = "Crear vistas masked cuando sean necesarias", AutoSize = true };
        private readonly CheckBox _createSynonyms = new CheckBox { Text = "Crear sinónimos app solo para vistas creadas", AutoSize = true };
        private readonly CheckBox _forceReapply = new CheckBox { Text = "Forzar reaplicación de DDM", AutoSize = true };
        private readonly CheckBox _dryRun = new CheckBox { Text = "DryRun / solo simular", AutoSize = true };
        private readonly CheckBox _skipComputed = new CheckBox { Text = "Evitar vistas/triggers en tablas con columnas calculadas salvo necesidad", AutoSize = true };
        private readonly CheckBox _applyPolicy = new CheckBox { Text = "Aplicar política segura de permisos", AutoSize = true };
        private readonly CheckBox _defaultSchema = new CheckBox { Text = "Aplicar DEFAULT_SCHEMA = masked desde política", AutoSize = true };
        private readonly CheckBox _mirrorPermissions = new CheckBox { Text = "Copiar permisos puntuales a vistas existentes", AutoSize = true };
        private readonly CheckBox _copyDml = new CheckBox { Text = "Copiar permisos INSERT/UPDATE/DELETE", AutoSize = true };
        private readonly CheckBox _runReprocess = new CheckBox { Text = "Ejecutar reproceso controlado antes de aplicar", AutoSize = true };
        private readonly ComboBox _maskingMode = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList, Width = 180 };
        private readonly ComboBox _viewStrategy = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList, Width = 260 };
        private readonly ComboBox _mirrorScope = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList, Width = 220 };
        private readonly ComboBox _baseAccess = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList, Width = 300 };
        private readonly ComboBox _reprocessMode = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList, Width = 180 };
        private readonly NumericUpDown _timeout = new NumericUpDown { Minimum = 30, Maximum = 3600, Value = 300, Width = 100 };

        public OptionsStepControl(GlobalConfig config)
        {
            _config = config;
            BuildUi();
            LoadValues();
        }

        private void BuildUi()
        {
            var panel = new TableLayoutPanel { Dock = DockStyle.Top, AutoSize = true, ColumnCount = 2, Padding = new Padding(10) };
            panel.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 270));
            panel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
            Controls.Add(panel);

            _maskingMode.Items.AddRange(new object[] { "patterns", "manual", "both" });
            _viewStrategy.Items.AddRange(new object[] { "WHEN_NEEDED", "ALL_CANDIDATE_TABLES", "MANUAL_ONLY", "DISABLED" });
            _mirrorScope.Items.AddRange(new object[] { "POLICY_TABLE", "ALL_EXISTING_GRANTEES" });
            _baseAccess.Items.AddRange(new object[] { "REPORT_ONLY", "REVOKE_EXPLICIT_OBJECT_PERMISSIONS", "DENY_BASE_FOR_POLICY_PRINCIPALS" });
            _reprocessMode.Items.AddRange(new object[] { "SOFT", "FORCE_DDM", "FULL_REBUILD" });

            AddCheck(panel, _applyDdm);
            AddCheck(panel, _createViews);
            AddCombo(panel, "Estrategia de vistas", _viewStrategy);
            AddCheck(panel, _createSynonyms);
            AddCheck(panel, _forceReapply);
            AddCheck(panel, _dryRun);
            AddCheck(panel, _skipComputed);
            AddCombo(panel, "Modo de selección", _maskingMode);
            AddCheck(panel, _applyPolicy);
            AddCheck(panel, _defaultSchema);
            AddCheck(panel, _mirrorPermissions);
            AddCheck(panel, _copyDml);
            AddCombo(panel, "Alcance copia permisos", _mirrorScope);
            AddCombo(panel, "Acción sobre tabla base", _baseAccess);
            AddCheck(panel, _runReprocess);
            AddCombo(panel, "Modo reproceso", _reprocessMode);
            AddCombo(panel, "Timeout comandos", _timeout);

            var info = new TextBox
            {
                Dock = DockStyle.Fill,
                Multiline = true,
                ReadOnly = true,
                BorderStyle = BorderStyle.None,
                Text = "Estrategia recomendada V4: DDM primero sobre dbo.Tabla. Crear vistas masked solo cuando sean necesarias. " +
                       "Con DEFAULT_SCHEMA=masked, si existe masked.Tabla se usa; si no existe, la consulta cae a dbo.Tabla con DDM aplicado. " +
                       "Primera ejecución siempre con DryRun y BaseAccessAction=REPORT_ONLY."
            };
            Controls.Add(info);
        }

        private static void AddCheck(TableLayoutPanel panel, CheckBox chk)
        {
            int row = panel.RowCount++;
            panel.RowStyles.Add(new RowStyle(SizeType.Absolute, 30));
            panel.Controls.Add(new Label(), 0, row);
            panel.Controls.Add(chk, 1, row);
        }

        private static void AddCombo(TableLayoutPanel panel, string label, Control control)
        {
            int row = panel.RowCount++;
            panel.RowStyles.Add(new RowStyle(SizeType.Absolute, 34));
            panel.Controls.Add(new Label { Text = label, Dock = DockStyle.Fill, TextAlign = System.Drawing.ContentAlignment.MiddleLeft }, 0, row);
            panel.Controls.Add(control, 1, row);
        }

        private void LoadValues()
        {
            var o = _config.DefaultOptions;
            _applyDdm.Checked = o.ApplyDDM;
            _createViews.Checked = o.CreateViews;
            _createSynonyms.Checked = o.CreateSynonyms;
            _forceReapply.Checked = o.ForceReapply;
            _dryRun.Checked = o.DryRun;
            _skipComputed.Checked = o.SkipTablesWithComputed;
            _applyPolicy.Checked = o.ApplySafePolicy;
            _defaultSchema.Checked = o.ApplyDefaultSchemaPolicy;
            _mirrorPermissions.Checked = o.MirrorObjectPermissions;
            _copyDml.Checked = o.CopyDmlPermissions;
            _runReprocess.Checked = o.RunReprocess;
            _maskingMode.SelectedItem = o.MaskingMode ?? "both";
            _viewStrategy.SelectedItem = o.ViewGenerationStrategy ?? "WHEN_NEEDED";
            _mirrorScope.SelectedItem = o.PermissionMirrorScope ?? "POLICY_TABLE";
            _baseAccess.SelectedItem = o.BaseAccessAction ?? "REPORT_ONLY";
            _reprocessMode.SelectedItem = o.ReprocessMode ?? "SOFT";
            _timeout.Value = Math.Max(_timeout.Minimum, Math.Min(_timeout.Maximum, o.CommandTimeout <= 0 ? 300 : o.CommandTimeout));
        }

        private void SaveValues()
        {
            var o = _config.DefaultOptions;
            o.ApplyDDM = _applyDdm.Checked;
            o.CreateViews = _createViews.Checked;
            o.CreateSynonyms = _createSynonyms.Checked;
            o.ForceReapply = _forceReapply.Checked;
            o.DryRun = _dryRun.Checked;
            o.SkipTablesWithComputed = _skipComputed.Checked;
            o.ApplySafePolicy = _applyPolicy.Checked;
            o.ApplyDefaultSchemaPolicy = _defaultSchema.Checked;
            o.MirrorObjectPermissions = _mirrorPermissions.Checked;
            o.CopyDmlPermissions = _copyDml.Checked;
            o.RunReprocess = _runReprocess.Checked;
            o.MaskingMode = _maskingMode.SelectedItem?.ToString() ?? "both";
            o.ViewGenerationStrategy = _viewStrategy.SelectedItem?.ToString() ?? "WHEN_NEEDED";
            o.PermissionMirrorScope = _mirrorScope.SelectedItem?.ToString() ?? "POLICY_TABLE";
            o.BaseAccessAction = _baseAccess.SelectedItem?.ToString() ?? "REPORT_ONLY";
            o.ReprocessMode = _reprocessMode.SelectedItem?.ToString() ?? "SOFT";
            o.CommandTimeout = (int)_timeout.Value;
        }

        public override bool ValidateStep(out string message)
        {
            SaveValues();
            if (_baseAccess.SelectedItem?.ToString() == "DENY_BASE_FOR_POLICY_PRINCIPALS" && !_dryRun.Checked)
            {
                var confirm = MessageBox.Show("Vas a ejecutar DENY sin DryRun. ¿Seguro que deseas continuar?", "Confirmación peligrosa", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                if (confirm != DialogResult.Yes)
                {
                    message = "Activa DryRun o cambia BaseAccessAction a REPORT_ONLY.";
                    return false;
                }
            }
            message = null;
            return true;
        }
    }
}
