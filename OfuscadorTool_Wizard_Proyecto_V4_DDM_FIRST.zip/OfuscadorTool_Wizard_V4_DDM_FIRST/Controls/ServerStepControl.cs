using OfuscadorTool.Models;
using OfuscadorTool.Services;
using System;
using System.ComponentModel;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OfuscadorTool
{
    public class ServerStepControl : WizardStepBase
    {
        public override string StepTitle => "Servidores";
        private readonly GlobalConfig _config;
        private BindingList<ServerConnection> _binding;
        private readonly DataGridView _grid = new DataGridView();
        private readonly DeploymentService _deployment = new DeploymentService();

        public ServerStepControl(GlobalConfig config)
        {
            _config = config;
            BuildUi();
            LoadGrid();
        }

        private void BuildUi()
        {
            var layout = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                ColumnCount = 1,
                RowCount = 2,
                Padding = new Padding(0),
                BackColor = System.Drawing.Color.White
            };
            layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 46));
            layout.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
            Controls.Add(layout);

            var toolbar = new FlowLayoutPanel
            {
                Dock = DockStyle.Fill,
                Height = 42,
                FlowDirection = FlowDirection.LeftToRight,
                WrapContents = false,
                Padding = new Padding(0, 4, 0, 4),
                BackColor = System.Drawing.Color.White
            };
            var btnAdd = new Button { Text = "Agregar", Width = 100, Height = 30 };
            var btnEdit = new Button { Text = "Editar", Width = 100, Height = 30 };
            var btnRemove = new Button { Text = "Quitar", Width = 100, Height = 30 };
            var btnTest = new Button { Text = "Probar conexión", Width = 140, Height = 30 };

            btnAdd.Click += (_, __) => AddServer();
            btnEdit.Click += (_, __) => EditServer();
            btnRemove.Click += (_, __) => RemoveServer();
            btnTest.Click += async (_, __) => await TestServerAsync();

            toolbar.Controls.AddRange(new Control[] { btnAdd, btnEdit, btnRemove, btnTest });
            layout.Controls.Add(toolbar, 0, 0);

            _grid.Dock = DockStyle.Fill;
            _grid.AutoGenerateColumns = false;
            _grid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            _grid.MultiSelect = false;
            _grid.AllowUserToAddRows = false;
            _grid.ReadOnly = true;
            _grid.BackgroundColor = System.Drawing.Color.White;
            _grid.BorderStyle = BorderStyle.FixedSingle;
            _grid.RowHeadersVisible = false;
            _grid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.None;

            _grid.Columns.Add(new DataGridViewCheckBoxColumn { HeaderText = "Activo", DataPropertyName = "IsEnabled", Width = 60 });
            _grid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Nombre", DataPropertyName = "Name", Width = 160 });
            _grid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Host", DataPropertyName = "Host", Width = 180 });
            _grid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Instancia", DataPropertyName = "InstanceName", Width = 120 });
            _grid.Columns.Add(new DataGridViewCheckBoxColumn { HeaderText = "Windows", DataPropertyName = "UseWindowsAuth", Width = 75 });
            _grid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Usuario", DataPropertyName = "Username", Width = 140 });
            _grid.Columns.Add(new DataGridViewCheckBoxColumn { HeaderText = "Encrypt", DataPropertyName = "EncryptConnection", Width = 70 });
            _grid.Columns.Add(new DataGridViewCheckBoxColumn { HeaderText = "Trust Cert", DataPropertyName = "TrustServerCertificate", Width = 85 });

            layout.Controls.Add(_grid, 0, 1);
        }

        private void LoadGrid()
        {
            _binding = new BindingList<ServerConnection>(_config.Servers);
            _grid.DataSource = _binding;
        }

        private ServerConnection Selected => _grid.CurrentRow?.DataBoundItem as ServerConnection;

        private void AddServer()
        {
            var server = new ServerConnection { Name = "Servidor SQL", Host = "." };
            using var dialog = new ServerDialog(server);
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                _config.Servers.Add(server);
                LoadGrid();
            }
        }

        private void EditServer()
        {
            if (Selected == null) return;
            using var dialog = new ServerDialog(Selected);
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                Selected.LastModified = DateTime.Now;
                _grid.Refresh();
            }
        }

        private void RemoveServer()
        {
            if (Selected == null) return;
            if (MessageBox.Show("¿Quitar este servidor de la configuración local?", "Confirmar", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                _config.Servers.Remove(Selected);
                LoadGrid();
            }
        }

        private async Task TestServerAsync()
        {
            if (Selected == null) return;
            try
            {
                Cursor.Current = Cursors.WaitCursor;
                await _deployment.TestConnectionAsync(Selected);
                MessageBox.Show("Conexión correcta.", "SQL Server", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error de conexión", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                Cursor.Current = Cursors.Default;
            }
        }

        public override bool ValidateStep(out string message)
        {
            if (!_config.Servers.Any(s => s.IsEnabled))
            {
                message = "Agrega y habilita al menos un servidor SQL Server.";
                return false;
            }

            message = null;
            return true;
        }
    }
}
