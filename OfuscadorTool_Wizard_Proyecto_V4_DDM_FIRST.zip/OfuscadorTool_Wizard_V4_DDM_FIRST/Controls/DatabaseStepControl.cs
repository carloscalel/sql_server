using OfuscadorTool.Models;
using OfuscadorTool.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OfuscadorTool
{
    public class DatabaseStepControl : WizardStepBase
    {
        public override string StepTitle => "Bases de datos";
        private readonly GlobalConfig _config;
        private readonly DeploymentService _deployment = new DeploymentService();
        private readonly ComboBox _cmbServers = new ComboBox();
        private readonly CheckedListBox _chkDatabases = new CheckedListBox();
        private readonly RadioButton _rbAll = new RadioButton { Text = "Todas las bases", AutoSize = true };
        private readonly RadioButton _rbAllExcept = new RadioButton { Text = "Todas excepto las marcadas", AutoSize = true, Checked = true };
        private readonly RadioButton _rbOnly = new RadioButton { Text = "Solo las marcadas", AutoSize = true };
        private readonly Label _status = new Label();
        private bool _loading;

        public DatabaseStepControl(GlobalConfig config)
        {
            _config = config;
            BuildUi();
        }

        private void BuildUi()
        {
            var layout = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                ColumnCount = 1,
                RowCount = 4,
                BackColor = System.Drawing.Color.White
            };
            layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 48));
            layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 42));
            layout.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
            layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 32));
            Controls.Add(layout);

            var top = new FlowLayoutPanel
            {
                Dock = DockStyle.Fill,
                FlowDirection = FlowDirection.LeftToRight,
                WrapContents = false,
                Padding = new Padding(0, 6, 0, 4),
                BackColor = System.Drawing.Color.White
            };
            _cmbServers.DropDownStyle = ComboBoxStyle.DropDownList;
            _cmbServers.Width = 280;
            _cmbServers.Height = 28;
            var btnLoad = new Button { Text = "Cargar bases", Width = 120, Height = 30 };
            btnLoad.Click += async (_, __) => await LoadDatabasesAsync();
            top.Controls.Add(new Label { Text = "Servidor:", AutoSize = true, Padding = new Padding(0, 8, 6, 0) });
            top.Controls.Add(_cmbServers);
            top.Controls.Add(btnLoad);
            layout.Controls.Add(top, 0, 0);

            var modes = new FlowLayoutPanel
            {
                Dock = DockStyle.Fill,
                FlowDirection = FlowDirection.LeftToRight,
                WrapContents = false,
                Padding = new Padding(0, 6, 0, 4),
                BackColor = System.Drawing.Color.White
            };
            _rbAll.CheckedChanged += (_, __) => SaveSelection();
            _rbAllExcept.CheckedChanged += (_, __) => SaveSelection();
            _rbOnly.CheckedChanged += (_, __) => SaveSelection();
            modes.Controls.AddRange(new Control[] { _rbAll, _rbAllExcept, _rbOnly });
            layout.Controls.Add(modes, 0, 1);

            _chkDatabases.Dock = DockStyle.Fill;
            _chkDatabases.CheckOnClick = true;
            _chkDatabases.BorderStyle = BorderStyle.FixedSingle;
            _chkDatabases.ItemCheck += (_, __) => { if (!_loading) BeginInvoke(new Action(SaveSelection)); };
            layout.Controls.Add(_chkDatabases, 0, 2);

            _status.Dock = DockStyle.Fill;
            _status.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            _status.Text = "Carga las bases del servidor seleccionado.";
            layout.Controls.Add(_status, 0, 3);
        }

        public override void OnStepVisible()
        {
            var servers = _config.Servers.Where(s => s.IsEnabled).ToList();
            _cmbServers.DataSource = null;
            _cmbServers.DataSource = servers;
            _cmbServers.DisplayMember = "DisplayName";
            _cmbServers.ValueMember = "Id";
        }

        private ServerConnection SelectedServer => _cmbServers.SelectedItem as ServerConnection;

        private async Task LoadDatabasesAsync()
        {
            if (SelectedServer == null) return;
            try
            {
                Cursor.Current = Cursors.WaitCursor;
                _status.Text = "Cargando bases...";
                var databases = await _deployment.GetDatabasesAsync(SelectedServer);
                LoadDatabaseList(databases);
                _status.Text = $"Bases cargadas: {databases.Count}";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error al cargar bases", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                Cursor.Current = Cursors.Default;
            }
        }

        private void LoadDatabaseList(List<string> databases)
        {
            _loading = true;
            _chkDatabases.Items.Clear();

            var selection = GetSelection();
            foreach (var db in databases)
            {
                bool check = selection.Mode == DatabaseSelectionMode.OnlyThese
                    ? selection.SelectedDatabases.Contains(db, StringComparer.OrdinalIgnoreCase)
                    : selection.ExcludedDatabases.Contains(db, StringComparer.OrdinalIgnoreCase);

                _chkDatabases.Items.Add(db, check);
            }

            _rbAll.Checked = selection.Mode == DatabaseSelectionMode.AllDatabases;
            _rbAllExcept.Checked = selection.Mode == DatabaseSelectionMode.AllExcept;
            _rbOnly.Checked = selection.Mode == DatabaseSelectionMode.OnlyThese;
            _loading = false;
        }

        private DatabaseSelection GetSelection()
        {
            var server = SelectedServer;
            if (server == null) return new DatabaseSelection();

            if (!_config.DatabaseSelections.TryGetValue(server.Id, out var selection))
            {
                selection = new DatabaseSelection { ServerId = server.Id };
                _config.DatabaseSelections[server.Id] = selection;
            }
            return selection;
        }

        private void SaveSelection()
        {
            if (_loading || SelectedServer == null) return;
            var selection = GetSelection();

            selection.Mode = _rbAll.Checked ? DatabaseSelectionMode.AllDatabases : _rbOnly.Checked ? DatabaseSelectionMode.OnlyThese : DatabaseSelectionMode.AllExcept;
            selection.SelectedDatabases.Clear();
            selection.ExcludedDatabases.Clear();

            if (selection.Mode == DatabaseSelectionMode.OnlyThese)
            {
                foreach (var item in _chkDatabases.CheckedItems)
                    selection.SelectedDatabases.Add(item.ToString());
            }
            else
            {
                foreach (var item in _chkDatabases.CheckedItems)
                    selection.ExcludedDatabases.Add(item.ToString());
            }
        }

        public override bool ValidateStep(out string message)
        {
            foreach (var server in _config.Servers.Where(s => s.IsEnabled))
            {
                if (!_config.DatabaseSelections.ContainsKey(server.Id))
                {
                    message = $"Carga y confirma la selección de bases para el servidor: {server.DisplayName}";
                    return false;
                }
            }

            message = null;
            return true;
        }
    }
}
