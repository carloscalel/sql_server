using System;

namespace OfuscadorTool.Models
{
    public class PrincipalPolicy
    {
        public string PrincipalName { get; set; }
        public bool IsEnabled { get; set; } = true;
        public bool IsExcluded { get; set; } = false;
        public bool ApplyDefaultSchema { get; set; } = true;
        public bool MirrorObjectPermissions { get; set; } = true;
        public bool IncludeDml { get; set; } = false;
        public bool AddToReadRole { get; set; } = false;
        public bool AddToDmlRole { get; set; } = false;
        public bool BlockBaseAccess { get; set; } = false;
        public string Notes { get; set; }
        public DateTime ModifiedAt { get; set; } = DateTime.Now;
    }
}
