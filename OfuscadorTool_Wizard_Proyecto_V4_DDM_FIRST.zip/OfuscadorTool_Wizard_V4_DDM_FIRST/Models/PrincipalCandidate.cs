namespace OfuscadorTool.Models
{
    public class PrincipalCandidate
    {
        public string PrincipalName { get; set; }
        public string PrincipalType { get; set; }
        public bool HasObjectPermissions { get; set; }
        public bool IsDbOwnerMember { get; set; }
        public bool IsSysAdminLogin { get; set; }
        public string Source { get; set; }
    }
}
