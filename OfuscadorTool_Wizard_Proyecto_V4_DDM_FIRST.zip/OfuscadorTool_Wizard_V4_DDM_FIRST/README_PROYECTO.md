# OfuscadorTool Wizard

Proyecto base Windows Forms para probar el sistema de enmascaramiento/ofuscamiento en SQL Server.

## Requisitos

- Visual Studio 2022/2026 con carga de trabajo **.NET desktop development**.
- .NET 8 SDK o superior.
- Acceso a una instancia SQL Server de prueba.
- Usuario con permisos suficientes para crear esquemas, vistas, procedimientos y aplicar DDM.

## Cómo probar

1. Abrir `OfuscadorTool.csproj` en Visual Studio.
2. Restaurar paquetes NuGet.
3. Compilar el proyecto.
4. Ejecutar.
5. Agregar servidor SQL Server.
6. Cargar bases de datos.
7. Seleccionar una base de pruebas.
8. Mantener `DryRun = true` en la primera ejecución.
9. Ejecutar.
10. Revisar el log y `dbo.Masked_Audit`.

## Orden interno de ejecución

El wizard ejecuta:

1. `setup.sql`
2. Sincroniza `dbo.Masked_Config`
3. Sincroniza `dbo.Masked_PrincipalPolicy`
4. `sp_ManageColumnRule.sql`
5. `sp_CreateViewWithDml.sql`
6. Opcional: `06_reprocess_all_CONTROLADO.sql`
7. Opcional: `apply_ddm.sql`
8. Opcional: `02_deploy_all.sql`
9. Opcional: `04_policy_by_table_SAFE.sql`

## Recomendación de seguridad

Primera prueba:

- `DryRun = true`
- `BaseAccessAction = REPORT_ONLY`
- `ApplySafePolicy = false`

Segunda prueba:

- `DryRun = false`
- `BaseAccessAction = REPORT_ONLY`
- `ApplySafePolicy = true` solo si agregaste usuarios/roles en la política.

No uses `DENY_BASE_FOR_POLICY_PRINCIPALS` hasta validar permisos y resultados.

## Cambios V3 - Usuarios, DEFAULT_SCHEMA y exclusiones

Esta versión agrega mejoras en la pantalla **Usuarios / políticas**:

- Botón **Cargar bases** para seleccionar una base origen desde donde se leerán los usuarios/roles.
- Botón **Agregar usuarios/roles** para cargar usuarios y roles elegibles no administrativos.
- Botón **Agregar con permisos** para cargar únicamente usuarios/roles que ya tienen permisos explícitos sobre objetos.
- Columna **Excluir** para marcar usuarios/roles que no deben ser modificados por la política.
- Botón **Excluir seleccionado** para desactivar y proteger rápidamente usuarios seleccionados.
- Botón **Reactivar seleccionado** para volver a habilitar un usuario/rol.
- Validación para evitar agregar como política activa `dbo`, `db_owner`, `db_datareader`, `db_datawriter`, `sys`, `public`, etc.

La política SQL también se reforzó:

- Se crea `dbo.Masked_PrincipalExclusions`.
- Los usuarios/roles en `dbo.Masked_PrincipalExclusions` con `IsEnabled = 1` no se tocan.
- Se omiten miembros de `db_owner`.
- Se intenta detectar y omitir logins miembros de `sysadmin`.
- Cuando `DEFAULT_SCHEMA = masked` se aplica a un usuario, SQL Server buscará primero en `masked`; si el objeto no existe ahí, puede resolver hacia `dbo` según las reglas normales de resolución de nombres.

Recomendación de uso:

1. Cargar usuarios/roles desde una base de prueba.
2. Revisar y marcar como **Excluir** cuentas técnicas, ETL, aplicaciones críticas o administradores.
3. Ejecutar primero con `DryRun = true` y `BaseAccessAction = REPORT_ONLY`.
4. Validar reportes antes de ejecutar sin DryRun.

---

# Nota V4 - DDM primero

Esta versión prioriza DDM sobre las tablas reales y crea vistas `masked` solo cuando sean necesarias. La opción `ViewGenerationStrategy = WHEN_NEEDED` es la recomendada para bases grandes porque evita generar una vista por cada tabla.

