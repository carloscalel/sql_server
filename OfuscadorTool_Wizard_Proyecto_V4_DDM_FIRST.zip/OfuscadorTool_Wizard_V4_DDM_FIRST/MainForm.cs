using OfuscadorTool.Models;
using OfuscadorTool.Services;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace OfuscadorTool
{
    public class MainForm : Form
    {
        private readonly ConfigService _configService = new ConfigService();
        private readonly GlobalConfig _config;
        private readonly List<WizardStepBase> _steps = new List<WizardStepBase>();
        private readonly Panel _leftPanel = new Panel();
        private readonly Panel _contentPanel = new Panel();
        private readonly Label _title = new Label();
        private readonly Button _btnBack = new Button();
        private readonly Button _btnNext = new Button();
        private readonly Button _btnCancel = new Button();
        private int _currentStep = 0;

        public MainForm()
        {
            _config = _configService.Load();
            InitializeLayout();
            BuildSteps();
            ShowStep(0);
        }

        private void InitializeLayout()
        {
            Text = "OfuscadorTool - Wizard de Enmascaramiento SQL Server";
            StartPosition = FormStartPosition.CenterScreen;
            Width = 1100;
            Height = 720;
            MinimumSize = new Size(980, 620);
            Font = new Font("Segoe UI", 9F);

            var root = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                ColumnCount = 2,
                RowCount = 3,
                BackColor = Color.White
            };
            root.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 230));
            root.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
            root.RowStyles.Add(new RowStyle(SizeType.Absolute, 60));
            root.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
            root.RowStyles.Add(new RowStyle(SizeType.Absolute, 58));
            Controls.Add(root);

            _leftPanel.Dock = DockStyle.Fill;
            _leftPanel.Padding = new Padding(10);
            _leftPanel.BackColor = Color.FromArgb(245, 245, 245);
            root.Controls.Add(_leftPanel, 0, 0);
            root.SetRowSpan(_leftPanel, 3);

            _title.Dock = DockStyle.Fill;
            _title.Font = new Font("Segoe UI", 16F, FontStyle.Bold);
            _title.Padding = new Padding(15, 12, 15, 5);
            _title.TextAlign = ContentAlignment.MiddleLeft;
            root.Controls.Add(_title, 1, 0);

            _contentPanel.Dock = DockStyle.Fill;
            _contentPanel.Padding = new Padding(12);
            _contentPanel.BackColor = Color.White;
            root.Controls.Add(_contentPanel, 1, 1);

            var bottomPanel = new Panel
            {
                Dock = DockStyle.Fill,
                Padding = new Padding(10),
                BackColor = Color.WhiteSmoke
            };
            root.Controls.Add(bottomPanel, 1, 2);

            var buttonPanel = new FlowLayoutPanel
            {
                Dock = DockStyle.Fill,
                FlowDirection = FlowDirection.RightToLeft,
                WrapContents = false
            };
            bottomPanel.Controls.Add(buttonPanel);

            _btnCancel.Text = "Cancelar";
            _btnCancel.Width = 110;
            _btnCancel.Height = 32;
            _btnCancel.Click += (_, __) => Close();

            _btnNext.Text = "Siguiente";
            _btnNext.Width = 120;
            _btnNext.Height = 32;
            _btnNext.Click += BtnNext_Click;

            _btnBack.Text = "Atrás";
            _btnBack.Width = 110;
            _btnBack.Height = 32;
            _btnBack.Click += (_, __) => { if (_currentStep > 0) ShowStep(_currentStep - 1); };

            buttonPanel.Controls.Add(_btnCancel);
            buttonPanel.Controls.Add(_btnNext);
            buttonPanel.Controls.Add(_btnBack);
        }

        private void BuildSteps()
        {
            _steps.Add(new WelcomeStepControl());
            _steps.Add(new ServerStepControl(_config));
            _steps.Add(new DatabaseStepControl(_config));
            _steps.Add(new OptionsStepControl(_config));
            _steps.Add(new PrincipalPolicyStepControl(_config));
            _steps.Add(new ReviewStepControl(_config));
            _steps.Add(new ExecuteStepControl(_config));
        }

        private void RefreshStepList()
        {
            _leftPanel.SuspendLayout();
            _leftPanel.Controls.Clear();

            for (int i = _steps.Count - 1; i >= 0; i--)
            {
                var lbl = new Label
                {
                    Text = $"{i + 1}. {_steps[i].StepTitle}",
                    Height = 38,
                    Dock = DockStyle.Top,
                    Padding = new Padding(8, 9, 8, 4),
                    Font = new Font("Segoe UI", 9F, i == _currentStep ? FontStyle.Bold : FontStyle.Regular),
                    ForeColor = i == _currentStep ? Color.FromArgb(20, 80, 150) : Color.Black
                };
                _leftPanel.Controls.Add(lbl);
            }

            _leftPanel.ResumeLayout();
        }

        private void ShowStep(int index)
        {
            _configService.Save(_config);
            _currentStep = index;

            _contentPanel.SuspendLayout();
            _contentPanel.Controls.Clear();

            var step = _steps[index];
            step.Dock = DockStyle.Fill;
            step.OnStepVisible();

            _title.Text = step.StepTitle;
            _contentPanel.Controls.Add(step);
            _contentPanel.ResumeLayout();

            _btnBack.Enabled = index > 0;
            _btnNext.Text = index == _steps.Count - 1 ? "Finalizar" : index == _steps.Count - 2 ? "Ejecutar" : "Siguiente";
            RefreshStepList();
        }

        private void BtnNext_Click(object sender, EventArgs e)
        {
            var step = _steps[_currentStep];
            if (!step.ValidateStep(out string message))
            {
                MessageBox.Show(message, "Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            _configService.Save(_config);

            if (_currentStep < _steps.Count - 1)
                ShowStep(_currentStep + 1);
            else
                Close();
        }
    }
}
