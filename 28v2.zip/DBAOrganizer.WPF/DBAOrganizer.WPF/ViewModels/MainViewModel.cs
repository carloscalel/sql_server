using System.Collections.ObjectModel;
using System.Windows.Input;
using DBAOrganizer.WPF.Models;
using DBAOrganizer.WPF.Services;

namespace DBAOrganizer.WPF.ViewModels
{
    public class RelayCommand : ICommand
    {
        private readonly Action<object?> _execute;
        private readonly Func<object?, bool>? _canExecute;

        public RelayCommand(Action<object?> execute, Func<object?, bool>? canExecute = null)
        {
            _execute = execute;
            _canExecute = canExecute;
        }

        public event EventHandler? CanExecuteChanged
        {
            add => CommandManager.RequerySuggested += value;
            remove => CommandManager.RequerySuggested -= value;
        }

        public bool CanExecute(object? parameter) => _canExecute == null || _canExecute(parameter);
        public void Execute(object? parameter) => _execute(parameter);
    }

    public class MainViewModel : TaskItem
    {
        private readonly JsonDataService _dataService;
        public ObservableCollection<TaskItem> Tasks { get; set; }

        public ObservableCollection<TaskItem> PorHacerTasks { get; } = new();
        public ObservableCollection<TaskItem> EnProcesoTasks { get; } = new();
        public ObservableCollection<TaskItem> ValidacionTasks { get; } = new();
        public ObservableCollection<TaskItem> BloqueadoTasks { get; } = new();
        public ObservableCollection<TaskItem> EnRevisionTasks { get; } = new();
        public ObservableCollection<TaskItem> FinalizadoTasks { get; } = new();

        private TaskItem? _selectedTask;
        public TaskItem? SelectedTask
        {
            get => _selectedTask;
            set { _selectedTask = value; OnPropertyChanged(); }
        }

        private bool _isDarkMode = false;
        public bool IsDarkMode
        {
            get => _isDarkMode;
            set
            {
                _isDarkMode = value;
                OnPropertyChanged();
                OnPropertyChanged(nameof(CurrentThemeBackground));
                OnPropertyChanged(nameof(HeaderBackground));
                OnPropertyChanged(nameof(ColumnBackground));
                OnPropertyChanged(nameof(CardBackground));
                OnPropertyChanged(nameof(BorderColor));
                OnPropertyChanged(nameof(TextPrimary));
                OnPropertyChanged(nameof(TextSecondary));
                OnPropertyChanged(nameof(TagBackground));
                OnPropertyChanged(nameof(ThemeButtonText));
            }
        }

        // Temas de colores dinámicos (Claro / Oscuro Pro)
        public string CurrentThemeBackground => _IsDark("#1E1E1E", "#F3F2F1");
        public string HeaderBackground => _IsDark("#2D2D30", "White");
        public string ColumnBackground => _IsDark("#252526", "White");
        public string CardBackground => _IsDark("#2D2D30", "#FAFAFA");
        public string BorderColor => _IsDark("#3F3F46", "#C8C6C4");
        public string TextPrimary => _IsDark("#FFFFFF", "#201F1E");
        public string TextSecondary => _IsDark("#D4D4D4", "#605E5C");
        public string TagBackground => _IsDark("#3E3E42", "#EDEBE9");
        public string ThemeButtonText => _IsDark("☀️ Modo Claro", "🌙 Modo Oscuro");

        private string _IsDark(string dark, string light) => _isDarkMode ? dark : light;

        private string _totalTasksSummary = "Total: 0 tareas";
        public string TotalTasksSummary
        {
            get => _totalTasksSummary;
            set { _totalTasksSummary = value; OnPropertyChanged(); }
        }

        public ICommand AddCommand { get; }
        public ICommand DeleteCommand { get; }
        public ICommand SaveCommand { get; }
        public ICommand AdvanceCommand { get; }
        public ICommand RegressCommand { get; }
        public ICommand ToggleThemeCommand { get; }

        public MainViewModel()
        {
            _dataService = new JsonDataService();
            Tasks = _dataService.LoadTasks();

            if (Tasks.Count == 0)
            {
                Tasks.Add(new TaskItem
                {
                    Ticket = "INC-725037",
                    Title = "Error Replica SQL01",
                    Description = "Falla de sincronización en nodo secundario",
                    Priority = "High",
                    Tag = "SQL Server",
                    Status = "Por Hacer",
                    Notes = "EXEC sp_help_replica;"
                });
            }

            UpdateColumnCollections();
            Tasks.CollectionChanged += (s, e) => UpdateColumnCollections();

            AddCommand = new RelayCommand(_ => AddTask());
            DeleteCommand = new RelayCommand(_ => DeleteTask(), _ => SelectedTask != null);
            SaveCommand = new RelayCommand(_ => SaveData());
            AdvanceCommand = new RelayCommand(_ => MoveStatus(1), _ => SelectedTask != null);
            RegressCommand = new RelayCommand(_ => MoveStatus(-1), _ => SelectedTask != null);
            ToggleThemeCommand = new RelayCommand(_ => IsDarkMode = !IsDarkMode);
        }

        private void UpdateColumnCollections()
        {
            PorHacerTasks.Clear();
            EnProcesoTasks.Clear();
            ValidacionTasks.Clear();
            BloqueadoTasks.Clear();
            EnRevisionTasks.Clear();
            FinalizadoTasks.Clear();

            foreach (var task in Tasks)
            {
                switch (task.Status)
                {
                    case "Por Hacer": PorHacerTasks.Add(task); break;
                    case "En Proceso": EnProcesoTasks.Add(task); break;
                    case "Validación": ValidacionTasks.Add(task); break;
                    case "Bloqueado": BloqueadoTasks.Add(task); break;
                    case "En Revisión": EnRevisionTasks.Add(task); break;
                    case "Finalizado": FinalizadoTasks.Add(task); break;
                    default: PorHacerTasks.Add(task); break;
                }
            }

            TotalTasksSummary = $"Total Activas: {Tasks.Count} tickets";
        }

        private void AddTask()
        {
            var newTask = new TaskItem
            {
                Ticket = $"INC-{new Random().Next(100000, 999999)}",
                Title = "Nueva Actividad DBA",
                Description = "Descripción del mantenimiento o ticket",
                Priority = "Normal",
                Tag = "SQL Server",
                Status = "Por Hacer"
            };
            Tasks.Add(newTask);
            UpdateColumnCollections();
            SelectedTask = newTask;
            SaveData();
        }

        private void DeleteTask()
        {
            if (SelectedTask != null)
            {
                Tasks.Remove(SelectedTask);
                UpdateColumnCollections();
                SelectedTask = null;
                SaveData();
            }
        }

        private void SaveData()
        {
            UpdateColumnCollections();
            _dataService.SaveTasks(Tasks);
        }

        private void MoveStatus(int direction)
        {
            if (SelectedTask == null) return;

            string[] states = { "Por Hacer", "En Proceso", "Validación", "Bloqueado", "En Revisión", "Finalizado" };
            int currentIndex = Array.IndexOf(states, SelectedTask.Status);
            if (currentIndex == -1) currentIndex = 0;

            int newIndex = currentIndex + direction;
            if (newIndex >= 0 && newIndex < states.Length)
            {
                SelectedTask.Status = states[newIndex];
                SaveData();

                var current = SelectedTask;
                SelectedTask = null;
                SelectedTask = current;
            }
        }
    }
}