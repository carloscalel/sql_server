using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace DBAOrganizer.WPF.Models
{
    public class TaskItem : INotifyPropertyChanged
    {
        private string _id = Guid.NewGuid().ToString();
        private string _ticket = string.Empty;
        private string _title = string.Empty;
        private string _description = string.Empty;
        private string _priority = "Normal"; // Low, Normal, High, Critical
        private string _tag = "SQL Server"; // SQL Server, Backup, Migración, Seguridad, General
        private string _creationDate = DateTime.Now.ToString("dd/MM/yyyy");
        private string _dueDate = DateTime.Now.AddDays(3).ToString("dd/MM/yyyy");
        private string _status = "Por Hacer"; // Por Hacer, En Proceso, Validación, Bloqueado, En Revisión, Finalizado
        private double _investedHours = 1.0;
        private string _notes = string.Empty;

        public string Id
        {
            get => _id;
            set { _id = value; OnPropertyChanged(); }
        }

        public string Ticket
        {
            get => _ticket;
            set { _ticket = value; OnPropertyChanged(); }
        }

        public string Title
        {
            get => _title;
            set { _title = value; OnPropertyChanged(); }
        }

        public string Description
        {
            get => _description;
            set { _description = value; OnPropertyChanged(); }
        }

        public string Priority
        {
            get => _priority;
            set { _priority = value; OnPropertyChanged(); }
        }

        public string Tag
        {
            get => _tag;
            set { _tag = value; OnPropertyChanged(); }
        }

        public string CreationDate
        {
            get => _creationDate;
            set { _creationDate = value; OnPropertyChanged(); }
        }

        public string DueDate
        {
            get => _dueDate;
            set { _dueDate = value; OnPropertyChanged(); }
        }

        public string Status
        {
            get => _status;
            set { _status = value; OnPropertyChanged(); }
        }

        public double InvestedHours
        {
            get => _investedHours;
            set { _investedHours = value; OnPropertyChanged(); }
        }

        public string Notes
        {
            get => _notes;
            set { _notes = value; OnPropertyChanged(); }
        }

        public event PropertyChangedEventHandler? PropertyChanged;
        protected void OnPropertyChanged([CallerMemberName] string? propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}