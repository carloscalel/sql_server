# SQL Access Admin

Cliente WPF moderno en C# / .NET 8 para administrar accesos en múltiples instancias SQL Server desde un servidor pivote `adminDB`.

## Ejecutar

```powershell
dotnet restore
dotnet run --project src/SqlAccessAdmin/SqlAccessAdmin.csproj
```

La aplicación requiere que un DBA prepare previamente `adminDB` con los scripts de [InsumosProduccion](InsumosProduccion/README.md). El cliente no crea bases, tablas, tipos, roles ni procedimientos y no aplica migraciones automáticas. La UI implementa autenticación con el pivote, roles Administrator/Operator/Auditor, alta y edición de servidores, prueba de conexión, selección simultánea de servidores y bases, asignación de login/rol, resultados por destino y auditoría.

## Conexiones directas

`adminDB` funciona como catálogo y registro de auditoría. El cliente recupera únicamente los servidores autorizados y abre conexiones TLS directas a cada destino; no requiere linked servers. Para migrar una instalación anterior, el DBA debe ejecutar `08_ConfigurarConexionDirectaYCifrado.sql` y después volver a ejecutar los scripts `02`, `03`, `04` y `99`.

El flujo de administración de accesos requiere además [10_PoliticaSolicitudesEIntegridad.sql](InsumosProduccion/10_PoliticaSolicitudesEIntegridad.sql). Este insumo instala la allowlist, la denylist permanente, solicitudes y aprobaciones, y la cadena hash append-only de auditoría. Ninguno de estos objetos se crea automáticamente desde el cliente.

## Seguridad

La pantalla **Política de seguridad** permite habilitar o bloquear permisos y roles directamente en sus tablas, con búsqueda y filtros por estado. Los cambios de ambas pestañas se guardan juntos después de revisar una confirmación; **Descartar** restaura lo guardado. Los cambios pendientes también se advierten al actualizar, navegar o cerrar la ventana. Bloquear una opción impide usarla en solicitudes nuevas y pendientes; no retira los accesos existentes en SQL Server.

**Detalles avanzados** muestra las acciones **Asignar** y **Retirar**, el último cambio, la edición de descripciones de roles y opciones para registrar roles personalizados o consultar y agregar bloqueos obligatorios. Ambas pestañas utilizan el mismo botón **Habilitar…** y el mismo formulario: el Administrator indica un motivo, reconoce el riesgo y escribe el nombre exacto. **Autorizar y habilitar** registra la excepción inmediatamente, con identidad, fecha y auditoría. Es una doble confirmación, no un segundo factor de autenticación. Volver a bloquear y guardar retira la excepción; habilitar después exige autorizar nuevamente. Los roles de servidor, `public` y las combinaciones SQL no admitidas siguen fuera del contrato.

Se admiten SELECT, INSERT, UPDATE, DELETE, EXECUTE y REFERENCES en DATABASE/OBJECT/SCHEMA; en COLUMN únicamente SELECT, UPDATE y REFERENCES. SCHEMA, COLUMN y REFERENCES requieren autorización especial por combinación exacta de permiso y alcance. La edición de accesos mantiene la matriz por objeto y añade una sección plegable para permisos de base, esquema o columna. La copia conserva esos alcances y nunca agrega delegación. Un permiso de columna puede prevalecer sobre una denegación de objeto: el formulario advierte este riesgo ([documentación de SQL Server](https://learn.microsoft.com/en-us/sql/t-sql/statements/grant-object-permissions-transact-sql)).

Las excepciones se revalidan en las solicitudes, copia y ejecución. Si el guardado falla parcialmente, conserva los cambios pendientes e informa cuántos se guardaron. Aplique manualmente `25` después de `24` y después [26_ValidacionCompartidaPermisosRoles.sql](InsumosProduccion/26_ValidacionCompartidaPermisosRoles.sql), ejecute `99` y reinicie. La migración registra las combinaciones nuevas deshabilitadas: no habilita accesos ni excepciones automáticamente. La aplicación no instala estos scripts por sí sola.

El formulario **2. Crear usuario** se organiza en un asistente: **General y cuenta**, **Mapeo de bases** y **Permisos a objetos**. Ticket y justificación permanecen obligatorios en el primer paso. Mapeo y permisos a objetos son opciones independientes: puede elegir cualquiera, ambas o ninguna. Al elegir solo objetos, pasa directamente al paso 2 de objetos y selecciona la base allí; el usuario de esa base se crea automáticamente, sin asignar roles o permisos generales. Anterior vuelve al paso anterior habilitado y conserva el borrador; Cancelar lo descarta. El envío genera una sola solicitud y mantiene la confirmación y ejecución separadas.

Los roles y permisos generales se aplican a todas las bases marcadas. Los permisos por objeto requieren exactamente una base, como exige el contrato actual de solicitudes en `adminDB`. Si combina ambas opciones, la única base mapeada se usa también para objetos. Cambiar la base de objetos descarta sus selecciones anteriores; desactivar el mapeo conserva la opción de objetos y permite elegir su base de forma independiente. Este asistente reutiliza los scripts existentes y no requiere una migración nueva.

El selector incluye funciones definidas por el usuario SQL/CLR y un filtro por tipo de objeto. Las funciones escalares permiten elegir `EXECUTE` y las tabulares `SELECT`, sujetos a la política central, tanto en Crear usuario como en Modificar accesos. El [análisis de viabilidad multibase](docs/ViabilidadPermisosMultibase.md) detalla los cambios necesarios para combinar roles y objetos de bases diferentes; esa ampliación todavía no está habilitada.

Los formularios **2. Crear usuario** y **3. Copiar permisos** permiten elegir **SQL authentication** o **Windows authentication**, un solo tipo por solicitud. SQL requiere contraseña temporal cifrada; Windows usa una identidad existente como `DOMINIO\usuario` o `EQUIPO\usuario` y no solicita contraseña SQL. Windows exige pulsar **Comprobar nombres**, que consulta `xp_logininfo` en el servidor seleccionado: muestra ✓ verde o ✕ roja y bloquea el envío si no hay una comprobación válida. Cambiar la identidad o el servidor invalida el resultado. La identidad se comprueba nuevamente al enviar y ejecutar. Aplique `24_AutenticacionSqlWindows.sql` después de `23`, ejecute `99` y reinicie. La conexión técnica requiere permiso de ejecución de `xp_logininfo` en `master`; consulte las instrucciones de infraestructura. El aplicativo registra el login en SQL Server; la cuenta Windows debe existir previamente.

- `Encrypt=True` por defecto en la conexión.
- No se requieren linked servers. El cliente abre conexiones TLS directas y las credenciales SQL se almacenan como sobres AES-256-GCM en `adminDB`.
- La clave AES-GCM aleatoria se guarda envuelta mediante una clave AES-256 protegida por certificado y Database Master Key de SQL Server.
- La contraseña del servidor nunca aparece en el listado y, al editar, puede dejarse vacía para conservar el sobre existente.
- Comandos parametrizados y `CommandType.StoredProcedure` exclusivamente.
- Si se habilita almacenamiento de credenciales, la clave de producción debe proceder de DPAPI/HSM/gestor de secretos; nunca debe almacenarse en el repositorio.
