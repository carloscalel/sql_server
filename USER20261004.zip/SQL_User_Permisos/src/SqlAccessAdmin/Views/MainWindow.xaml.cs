using System.ComponentModel;
using System.Windows;
using SqlAccessAdmin.ViewModels;

namespace SqlAccessAdmin.Views;

public partial class MainWindow : Window
{
    public MainWindow() => InitializeComponent();
    protected override void OnClosing(CancelEventArgs e)
    {
        if (DataContext is MainViewModel { Current: PolicyViewModel policy } && !policy.ConfirmLeave()) e.Cancel = true;
        base.OnClosing(e);
    }
}
