using System.Windows.Controls;

namespace SqlAccessAdmin.Views;

public partial class WindowsNameValidation : UserControl
{
    public WindowsNameValidation()=>InitializeComponent();
}
