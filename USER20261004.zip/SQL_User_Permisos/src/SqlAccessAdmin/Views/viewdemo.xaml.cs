﻿using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;

namespace SqlAccessAdmin.Views
{
    public partial class viewdemo : Page
    {
        public viewdemo()
        {
            InitializeComponent();
            CargarDatosEjemplo();
        }

        private void CargarDatosEjemplo()
        {
            var listaPermisos = new List<PermisoItem>
            {
                new PermisoItem { NombrePermiso = "SELECT", Ambito = "DATABASE", PermiteConceder = true,  PermiteRetirar = true,  EsActivo = true,  UltimaModificacion = @"MicrosoftAccount\josepablo... 2026-08-30 22:04" },
                new PermisoItem { NombrePermiso = "SELECT", Ambito = "OBJECT",   PermiteConceder = true,  PermiteRetirar = true,  EsActivo = true,  UltimaModificacion = @"MicrosoftAccount\josepablo... 2026-08-30 22:04" },
                new PermisoItem { NombrePermiso = "INSERT", Ambito = "DATABASE", PermiteConceder = true,  PermiteRetirar = true,  EsActivo = true,  UltimaModificacion = @"MicrosoftAccount\josepablo... 2026-08-30 22:04" },
                new PermisoItem { NombrePermiso = "UPDATE", Ambito = "COLUMN",   PermiteConceder = false, PermiteRetirar = true,  EsActivo = false, UltimaModificacion = @"MicrosoftAccount\josepablo... 2026-08-16 01:11" },
                new PermisoItem { NombrePermiso = "DELETE", Ambito = "DATABASE", PermiteConceder = true,  PermiteRetirar = true,  EsActivo = true,  UltimaModificacion = @"MicrosoftAccount\josepablo... 2026-08-30 22:04" }
            };
            dgPermisos.ItemsSource = listaPermisos;

            var listaRoles = new List<RolItem>
            {
                new RolItem { NombreRol = "db_accessadmin", Tipo = "FIXED", Activo = false, Descripcion = "Administración de acceso" },
                new RolItem { NombreRol = "db_backupoperator", Tipo = "FIXED", Activo = false, Descripcion = "Operación de respaldos" },
                new RolItem { NombreRol = "db_datareader", Tipo = "FIXED", Activo = true,  Descripcion = "Lectura de todas las tablas y vistas" },
                new RolItem { NombreRol = "db_datawriter", Tipo = "FIXED", Activo = true,  Descripcion = "Escritura en todas las tablas" },
                new RolItem { NombreRol = "db_ddladmin", Tipo = "FIXED", Activo = false, Descripcion = "Administración DDL" },
                new RolItem { NombreRol = "db_owner", Tipo = "FIXED", Activo = false, Descripcion = "Control total de la base" },
                new RolItem { NombreRol = "SqlAccessAdmin_Operator", Tipo = "CUSTOM", Activo = true, Descripcion = "Operador personalizado de la herramienta" }
            };
            dgRoles.ItemsSource = listaRoles;
        }

        private void BtnGuardar_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Cambios guardados correctamente.", "Información", MessageBoxButton.OK, MessageBoxImage.Information);
        }
    }

    public class PermisoItem
    {
        public string NombrePermiso { get; set; } = string.Empty;
        public string Ambito { get; set; } = string.Empty;
        public bool PermiteConceder { get; set; }
        public bool PermiteRetirar { get; set; }
        public bool EsActivo { get; set; }
        public string UltimaModificacion { get; set; } = string.Empty;
    }

    public class RolItem
    {
        public string NombreRol { get; set; } = string.Empty;
        public string Tipo { get; set; } = string.Empty;
        public bool Activo { get; set; }
        public string Descripcion { get; set; } = string.Empty;
        public bool EsActivo
        {
            get => Activo;
            set => Activo = value;
        }
    }
}