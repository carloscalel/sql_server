using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Threading;
using SqlAccessAdmin.ViewModels;

namespace SqlAccessAdmin.Views;

public partial class PolicyView : UserControl
{
    public PolicyView() => InitializeComponent();
    private void OnActivationPanelVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
    {
        if (e.NewValue is true) Dispatcher.BeginInvoke(DispatcherPriority.Input, new Action(() => ActivationReason.Focus()));
    }
    private void OnActivationPanelKeyDown(object sender, KeyEventArgs e)
    {
        if (e.Key != Key.Escape || DataContext is not PolicyViewModel vm || !vm.CancelActivationCommand.CanExecute(null)) return;
        vm.CancelActivationCommand.Execute(null); e.Handled = true;
    }
}
