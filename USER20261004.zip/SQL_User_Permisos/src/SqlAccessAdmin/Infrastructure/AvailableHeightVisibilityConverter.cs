using System.Globalization;
using System.Windows;
using System.Windows.Data;

namespace SqlAccessAdmin.Infrastructure;

/// <summary>Leaves space for editable rows when the policy panel is short.</summary>
public sealed class AvailableHeightVisibilityConverter : IValueConverter
{
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
    {
        var minimum = double.TryParse(parameter?.ToString(), NumberStyles.Float,
            CultureInfo.InvariantCulture, out var parsed) ? parsed : 600;
        return value is double height && height >= minimum ? Visibility.Visible : Visibility.Collapsed;
    }

    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        => Binding.DoNothing;
}
