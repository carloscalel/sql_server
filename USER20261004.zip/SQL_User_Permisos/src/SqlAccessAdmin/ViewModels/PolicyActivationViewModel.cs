using SqlAccessAdmin.Infrastructure;
using SqlAccessAdmin.Models;

namespace SqlAccessAdmin.ViewModels;

public sealed class PolicyActivationViewModel : BindableBase
{
    private string _reason = "", _confirmedName = "";
    private bool _acknowledged;
    public PolicyEditorItem Item { get; }
    public string Name => Item is RolePolicyItem role ? role.Name : ((PermissionPolicyItem)Item).Permission;
    public string Title => $"Habilitar {Name}";
    public string ScopeDisplay => Item is PermissionPolicyItem permission ? permission.ScopeDisplay : ((RolePolicyItem)Item).RoleScope == "SERVER" ? "Rol de servidor" : "Rol de base de datos";
    public string Destination { get; }
    public string RiskDescription => Item.ProtectionReason;
    public string Reason { get => _reason; set { if (Set(ref _reason, value)) Raise(nameof(CanActivate)); } }
    public string ConfirmedName { get => _confirmedName; set { if (Set(ref _confirmedName, value)) Raise(nameof(CanActivate)); } }
    public bool RiskAcknowledged { get => _acknowledged; set { if (Set(ref _acknowledged, value)) Raise(nameof(CanActivate)); } }
    public bool CanActivate => RiskAcknowledged && Name.Equals(ConfirmedName, StringComparison.Ordinal) && Reason.Trim().Length is >= 20 and <= 1000;
    public PolicyActivationViewModel(PolicyEditorItem item, string destination = "Plantilla general") { Item = item; Destination = destination; }
    public PolicySpecialActivation ToRequest() => new(Item is RolePolicyItem role ? role.RoleScope == "SERVER" ? "SERVER_ROLE" : "DATABASE_ROLE" : "PERMISSION", Name,
        Item is PermissionPolicyItem permission ? permission.Scope : "", Reason.Trim(), ConfirmedName, RiskAcknowledged);
}
