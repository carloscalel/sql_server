using System.Collections.ObjectModel;
using System.Windows.Data;
using System.ComponentModel;
using SqlAccessAdmin.Models;
using SqlAccessAdmin.Infrastructure;

namespace SqlAccessAdmin.ViewModels;

public sealed partial class AccessViewModel
{
    private CancellationTokenSource? _copyCatalogCancellation,_copyLoadCancellation,_copyTargetCancellation;
    private readonly Dictionary<string,List<DatabaseItem>> _copySourceDatabases=new(StringComparer.OrdinalIgnoreCase);
    private string? _selectedCopySource;
    private string _copySourceSearch="",_copySourcesMessage="Seleccione el usuario cuyos accesos desea copiar.",_copyAccessMessage="Seleccione el usuario cuyos accesos desea copiar.",_copyTargetValidationMessage="Escriba el nombre de la nueva cuenta SQL.";
    private bool _isLoadingCopySources,_copyCatalogComplete,_isLoadingCopyAccess,_copyAccessLoaded,_copyTargetAvailable;
    public bool IsClonePermissionsOperation=>SelectedOperation?.Code=="CLONE_PERMISSIONS";
    public bool IsBasicIdentityOperation=>RequiresBasicAccessData&&!IsClonePermissionsOperation;
    public bool HasTopRequestDetails=>SelectedOperation is not null;
    public bool HasBottomRequestDetails=>false;
    public ObservableCollection<string> CopySources {get;}=[];
    public ObservableCollection<PermissionCopyAccessItem> CopySourceAccesses {get;}=[];
    private ICollectionView? _copySourcesView;
    public ICollectionView CopySourcesView=>_copySourcesView??=CollectionViewSource.GetDefaultView(CopySources);
    public string CopySourceSearch
    {
        get=>_copySourceSearch;
        set
        {
            if(!Set(ref _copySourceSearch,value))return;
            CopySourcesView.Filter=item=>item is string name&&(string.IsNullOrWhiteSpace(value)||name.Contains(value.Trim(),StringComparison.CurrentCultureIgnoreCase));
        }
    }
    public string? SelectedCopySource
    {
        get=>_selectedCopySource;
        set{if(Set(ref _selectedCopySource,value)){SourcePrincipal=value??"";_=LoadCopySourceAccessAsync();}}
    }
    public bool IsLoadingCopyAccess {get=>_isLoadingCopyAccess;private set{if(Set(ref _isLoadingCopyAccess,value))RefreshPermissionCopyState();}}
    public bool IsLoadingCopySources {get=>_isLoadingCopySources;private set{if(Set(ref _isLoadingCopySources,value)){_refreshCopySourcesCommand?.Refresh();RefreshPermissionCopyState();}}}
    public string CopySourcesMessage {get=>_copySourcesMessage;private set=>Set(ref _copySourcesMessage,value);}
    public string CopyAccessMessage {get=>_copyAccessMessage;private set=>Set(ref _copyAccessMessage,value);}
    public string CopyTargetValidationMessage {get=>_copyTargetValidationMessage;private set=>Set(ref _copyTargetValidationMessage,value);}
    public PermissionCopyPlan? CurrentCopyPlan=>SelectedCopySource is not null&&_copySourceDatabases.TryGetValue(SelectedCopySource,out var databases)
        ?new(2,databases.Select(x=>new PermissionCopyDatabasePlan(x.Name,x.CopySourceUser,CopySourceAccesses.Where(a=>a.Database==x.Name).ToList())).ToList()):null;
    public string CopyAccessFingerprint=>CurrentCopyPlan?.Fingerprint??"";
    public bool CanSubmitPermissionCopy=>CanUseValidatedWindowsName&&!IsLoadingCopySources&&_copyCatalogComplete&&!IsLoadingCopyAccess&&_copyAccessLoaded&&_copyTargetAvailable&&CopySourceAccesses.Any(x=>x.CanCopy)
        &&!CopySourceAccesses.Any(x=>x.State is "DENY" or "REVOKE");
    public AsyncCommand RefreshCopySourcesCommand=>_refreshCopySourcesCommand??=new(LoadCopySourcesAsync,()=>!IsLoadingCopySources);
    private AsyncCommand? _refreshCopySourcesCommand;

    private void RefreshPermissionCopyState()
    {
        Decision=null;Raise(nameof(CanSubmitPermissionCopy));PreviewCommand?.Refresh();SubmitCommand?.Refresh();
    }

    private void ResetPermissionCopy()
    {
        _copyCatalogCancellation?.Cancel();_copyLoadCancellation?.Cancel();_copyTargetCancellation?.Cancel();
        _copyCatalogCancellation=null;_copyLoadCancellation=null;_copyTargetCancellation=null;
        _selectedCopySource=null;Raise(nameof(SelectedCopySource));SourcePrincipal="";
        CopySources.Clear();_copySourceDatabases.Clear();CopySourceAccesses.Clear();CopySourceSearch="";
        _copyCatalogComplete=false;_copyAccessLoaded=false;_copyTargetAvailable=false;IsLoadingCopySources=false;IsLoadingCopyAccess=false;
        CopySourcesMessage="Seleccione el usuario cuyos accesos desea copiar.";
        CopyAccessMessage="Seleccione el usuario cuyos accesos desea copiar.";CopyTargetValidationMessage="Escriba el nombre de la nueva cuenta SQL.";
        RefreshPermissionCopyState();
    }

    private async Task LoadCopySourcesAsync()
    {
        ResetPermissionCopy();
        var server=SelectedWorkingServer;
        if(server is null||!IsClonePermissionsOperation)return;
        using var cancellation=new CancellationTokenSource();_copyCatalogCancellation=cancellation;
        var ct=cancellation.Token;
        IsLoadingCopySources=true;CopySourcesMessage="Buscando usuarios disponibles…";
        try
        {
            var databases=await _direct.GetCopyDatabasesAsync(server,ct);
            var (sources,errors)=await _direct.GetCopySourceCatalogAsync(databases,
                name=>CopySourcesMessage=$"Buscando usuarios en {name}…",ct);
            ct.ThrowIfCancellationRequested();
            if(!ReferenceEquals(_copyCatalogCancellation,cancellation)||!ReferenceEquals(server,SelectedWorkingServer))return;
            Databases.Clear();foreach(var database in databases)Databases.Add(database);
            foreach(var pair in sources.OrderBy(x=>x.Key,StringComparer.CurrentCultureIgnoreCase))
            { _copySourceDatabases.Add(pair.Key,pair.Value);CopySources.Add(pair.Key); }
            _copyCatalogComplete=errors.Count==0;
            CopySourcesMessage=errors.Count>0
                ?$"Encontramos {CopySources.Count} usuarios, pero no fue posible revisar todas las bases de datos. Seleccione Actualizar lista para intentarlo nuevamente."
                :CopySources.Count==0
                    ?"No encontramos usuarios disponibles para copiar en este servidor."
                    :$"Usuarios disponibles: {CopySources.Count}. Seleccione el usuario cuyos accesos desea copiar.";
        }
        catch(OperationCanceledException)when(ct.IsCancellationRequested){}
        catch(Exception){if(!ct.IsCancellationRequested)CopySourcesMessage="No pudimos cargar los usuarios. Seleccione Actualizar lista para intentarlo nuevamente.";}
        finally{if(ReferenceEquals(_copyCatalogCancellation,cancellation)){_copyCatalogCancellation=null;IsLoadingCopySources=false;}}
    }

    private async Task LoadCopySourceAccessAsync()
    {
        _copyLoadCancellation?.Cancel();_copyTargetCancellation?.Cancel();
        _copyAccessLoaded=false;_copyTargetAvailable=false;CopySourceAccesses.Clear();
        foreach(var database in Databases)database.IsSelected=false;
        RefreshPermissionCopyState();
        var source=SelectedCopySource;
        if(!IsClonePermissionsOperation||source is null||!_copySourceDatabases.TryGetValue(source,out var databases))
        {IsLoadingCopyAccess=false;CopyAccessMessage="Seleccione un usuario de la lista para ver qué accesos se copiarán.";return;}
        using var cancellation=new CancellationTokenSource();_copyLoadCancellation=cancellation;
        var ct=cancellation.Token;IsLoadingCopyAccess=true;
        try
        {
            var accesses=new List<PermissionCopyAccessItem>();
            foreach(var database in databases)
            {
                CopyAccessMessage=$"Revisando los accesos de {source} en {database.Name}…";
                accesses.AddRange(await _direct.GetPermissionCopyAccessAsync(database,database.CopySourceUser,ct));
            }
            ct.ThrowIfCancellationRequested();
            if(!ReferenceEquals(_copyLoadCancellation,cancellation))return;
            foreach(var item in accesses)CopySourceAccesses.Add(item);
            foreach(var database in Databases)database.IsSelected=databases.Any(x=>x.Name==database.Name);
            _copyAccessLoaded=true;
            CopyAccessMessage=$"Se copiarán {accesses.Count(x=>x.CanCopy)} de {accesses.Count} accesos encontrados para {source}. Revise el detalle antes de continuar.";
            if(accesses.Any(x=>x.State is "DENY" or "REVOKE"))
                CopyAccessMessage="No se puede continuar porque algunos accesos del usuario requieren revisión. Comuníquese con el administrador de la aplicación.";
        }
        catch(OperationCanceledException)when(ct.IsCancellationRequested){}
        catch(Exception){if(!ct.IsCancellationRequested)CopyAccessMessage="No pudimos cargar los accesos de este usuario. Actualice la lista e inténtelo nuevamente.";}
        finally
        {
            if(ReferenceEquals(_copyLoadCancellation,cancellation))
            {_copyLoadCancellation=null;IsLoadingCopyAccess=false;_=ValidateCopyTargetAsync();}
        }
    }

    private async Task ValidateCopyTargetAsync()
    {
        _copyTargetCancellation?.Cancel();_copyTargetAvailable=false;RefreshPermissionCopyState();
        if(!IsClonePermissionsOperation)return;
        var server=SelectedWorkingServer;var target=TargetPrincipal.Trim();
        if(server is null||target.Length==0){CopyTargetValidationMessage=IsWindowsAuthentication?"Escriba la cuenta de Windows que recibirá los accesos.":"Escriba el nombre de la nueva cuenta SQL.";return;}
        using var cancellation=new CancellationTokenSource();_copyTargetCancellation=cancellation;var ct=cancellation.Token;
        CopyTargetValidationMessage="Comprobando si el nombre está disponible…";
        try
        {
            LoginAuthentication.Validate("CLONE_PERMISSIONS",target,AuthenticationType);
            await Task.Delay(400,ct);
            await _direct.EnsureCopyTargetAvailableAsync(server.Id,target,Databases.Where(x=>x.IsSelected).ToList(),ct);
            ct.ThrowIfCancellationRequested();
            _copyTargetAvailable=true;CopyTargetValidationMessage=IsWindowsAuthentication
                ?"✓ El nombre está disponible para crear la cuenta."
                :"✓ El nombre está disponible. La cuenta se creará al ejecutar la solicitud.";
        }
        catch(OperationCanceledException)when(ct.IsCancellationRequested){}
        catch(Exception error){if(!ct.IsCancellationRequested)CopyTargetValidationMessage=error.Message;}
        finally{if(ReferenceEquals(_copyTargetCancellation,cancellation)){_copyTargetCancellation=null;RefreshPermissionCopyState();}}
    }

    private async Task ValidatePermissionCopyAsync(IReadOnlyList<DatabaseItem> targets)
    {
        var original=Draft();
        await _direct.ValidatePermissionCopyPlanAsync(original,targets);
        if((await _db.GetRequestsAsync(serverId:targets[0].ServerId)).Any(x=>(x.Status is "PENDING" or "APPROVED")
            &&(x.Operation is "CREATE_SQL_LOGIN" or "CREATE_WINDOWS_LOGIN" or "CLONE_PERMISSIONS")&&Same(x.TargetPrincipal,original.TargetPrincipal)))
            throw new InvalidOperationException("Ya existe una solicitud activa para crear esta cuenta. Revísela en Confirmar y ejecutar.");
        foreach(var code in new[]{LoginAuthentication.CreationOperation(original.AuthenticationType!),"CREATE_DB_USER"})
        {
            var decision=await _db.PreviewRequestTargetsAsync(original with{Operation=code,SourcePrincipal=null,Securable=null},targets);
            if(!decision.Allowed)throw new InvalidOperationException(decision.Reason);
        }
        if(!IsClonePermissionsOperation||original.AuthenticationType!=AuthenticationType||!Same(original.TargetPrincipal,TargetPrincipal)||!Same(original.SourcePrincipal,SourcePrincipal)||original.Securable!=CopyAccessFingerprint)
            throw new InvalidOperationException("Los datos cambiaron mientras se revisaba la solicitud. Verifique la información e inténtelo nuevamente.");
    }
}
