using SqlAccessAdmin.Infrastructure;
using SqlAccessAdmin.Models;

namespace SqlAccessAdmin.ViewModels;

public sealed partial class AccessViewModel
{
    private CancellationTokenSource? _windowsNameCancellation;
    private AsyncCommand? _checkWindowsNameCommand;
    private bool _isCheckingWindowsName,_windowsNameValidated,_windowsNameFailed;
    private int? _validatedWindowsServerId;
    private string _validatedWindowsName="",_windowsNameValidationMessage="Escriba la cuenta y seleccione Comprobar cuenta antes de continuar.";

    public bool RequiresWindowsNameValidation=>RequiresAuthenticationType&&IsWindowsAuthentication;
    public bool IsCheckingWindowsName=>_isCheckingWindowsName;
    public bool IsWindowsNameValidated=>RequiresWindowsNameValidation&&!IsCheckingWindowsName&&_windowsNameValidated
        &&SelectedWorkingServer?.Id==_validatedWindowsServerId
        &&string.Equals(TargetPrincipal.Trim(),_validatedWindowsName,StringComparison.Ordinal);
    public bool CanUseValidatedWindowsName=>!RequiresWindowsNameValidation||IsWindowsNameValidated;
    public string WindowsNameValidationMessage=>_windowsNameValidationMessage;
    public string WindowsNameValidationIcon=>IsCheckingWindowsName?"…":IsWindowsNameValidated?"✓":_windowsNameFailed?"✕":"ℹ";
    public string WindowsNameValidationForeground=>IsWindowsNameValidated?"#15803D":_windowsNameFailed?"#B42318":"#60789F";
    public AsyncCommand CheckWindowsNameCommand=>_checkWindowsNameCommand??=new(
        ()=>CheckWindowsNameAsync(_direct.CheckWindowsAccountAsync),
        ()=>RequiresWindowsNameValidation&&SelectedWorkingServer is not null&&!string.IsNullOrWhiteSpace(TargetPrincipal)&&!IsCheckingWindowsName);

    private void ResetWindowsNameValidation()
    {
        _windowsNameCancellation?.Cancel();_windowsNameCancellation=null;
        _isCheckingWindowsName=false;_windowsNameValidated=false;_windowsNameFailed=false;
        _validatedWindowsServerId=null;_validatedWindowsName="";
        _windowsNameValidationMessage="Escriba la cuenta y seleccione Comprobar cuenta antes de continuar.";
        RefreshWindowsNameValidationState();
    }

    private void RefreshWindowsNameValidationState()
    {
        Decision=null;
        Raise(nameof(RequiresWindowsNameValidation));Raise(nameof(IsCheckingWindowsName));Raise(nameof(IsWindowsNameValidated));
        Raise(nameof(CanUseValidatedWindowsName));Raise(nameof(WindowsNameValidationMessage));
        Raise(nameof(WindowsNameValidationIcon));Raise(nameof(WindowsNameValidationForeground));
        Raise(nameof(CanSubmitPermissionCopy));
        _checkWindowsNameCommand?.Refresh();PreviewCommand?.Refresh();SubmitCommand?.Refresh();
    }

    private async Task CheckWindowsNameAsync(Func<int,string,CancellationToken,Task> checkAccount)
    {
        ResetWindowsNameValidation();
        var server=SelectedWorkingServer;var account=TargetPrincipal.Trim();
        if(!RequiresWindowsNameValidation||server is null)return;
        var operation=SelectedOperation?.Code;
        using var cancellation=new CancellationTokenSource();_windowsNameCancellation=cancellation;
        var ct=cancellation.Token;
        _isCheckingWindowsName=true;_windowsNameValidationMessage=$"Comprobando la cuenta {account}…";
        RefreshWindowsNameValidationState();
        try
        {
            LoginAuthentication.Validate(operation!,account,"WINDOWS");
            await checkAccount(server.Id,account,ct);
            ct.ThrowIfCancellationRequested();
            if(!ReferenceEquals(_windowsNameCancellation,cancellation)||SelectedWorkingServer?.Id!=server.Id
                ||!RequiresWindowsNameValidation||SelectedOperation?.Code!=operation
                ||!string.Equals(TargetPrincipal.Trim(),account,StringComparison.Ordinal))return;
            _validatedWindowsServerId=server.Id;_validatedWindowsName=account;_windowsNameValidated=true;
            _windowsNameValidationMessage=$"✓ Cuenta confirmada: {account}.";
        }
        catch(OperationCanceledException)when(ct.IsCancellationRequested){}
        catch(Exception error)
        {
            if(!ct.IsCancellationRequested&&ReferenceEquals(_windowsNameCancellation,cancellation))
            {_windowsNameFailed=true;_windowsNameValidationMessage=error.Message;}
        }
        finally
        {
            if(ReferenceEquals(_windowsNameCancellation,cancellation))
            {_windowsNameCancellation=null;_isCheckingWindowsName=false;RefreshWindowsNameValidationState();}
        }
    }

    private async Task RecheckWindowsNameBeforeSubmissionAsync(AccessRequestDraft draft,int serverId)
    {
        if(draft.AuthenticationType!="WINDOWS")return;
        if(!IsWindowsNameValidated||SelectedWorkingServer?.Id!=serverId||_validatedWindowsName!=draft.TargetPrincipal||SelectedOperation?.Code!=draft.Operation)
            throw new InvalidOperationException("Compruebe la cuenta de Windows antes de enviar la solicitud.");
        try{await _direct.CheckWindowsAccountAsync(serverId,draft.TargetPrincipal);}
        catch(Exception error)
        {
            if(SelectedWorkingServer?.Id==serverId&&TargetPrincipal.Trim()==draft.TargetPrincipal&&IsWindowsAuthentication)
            {
                ResetWindowsNameValidation();_windowsNameFailed=true;_windowsNameValidationMessage=error.Message;
                RefreshWindowsNameValidationState();
            }
            throw;
        }
        if(!IsWindowsNameValidated||SelectedWorkingServer?.Id!=serverId||_validatedWindowsName!=draft.TargetPrincipal||SelectedOperation?.Code!=draft.Operation)
            throw new InvalidOperationException("La cuenta o el servidor cambió. Compruebe nuevamente la cuenta.");
    }
}
