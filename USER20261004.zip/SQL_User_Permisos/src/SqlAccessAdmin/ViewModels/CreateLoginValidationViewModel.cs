namespace SqlAccessAdmin.ViewModels;

public sealed partial class AccessViewModel
{
    private CancellationTokenSource? _createLoginTargetCancellation;
    private bool _isCreateLoginTargetAvailable;
    private string _createLoginTargetValidationMessage="Indique el nombre del nuevo login SQL.";

    public bool IsCreateLoginTargetAvailable=>_isCreateLoginTargetAvailable;
    public string CreateLoginTargetValidationMessage
    {
        get=>_createLoginTargetValidationMessage;
        private set=>Set(ref _createLoginTargetValidationMessage,value);
    }

    private void ResetCreateLoginTargetValidation()
    {
        _createLoginTargetCancellation?.Cancel();
        _createLoginTargetCancellation=null;
        _isCreateLoginTargetAvailable=false;
        CreateLoginTargetValidationMessage="Indique el nombre del nuevo login SQL.";
        Raise(nameof(IsCreateLoginTargetAvailable));
    }

    private async Task ValidateCreateLoginTargetAsync()
    {
        _createLoginTargetCancellation?.Cancel();
        _isCreateLoginTargetAvailable=false;
        Raise(nameof(IsCreateLoginTargetAvailable));
        PreviewCommand?.Refresh();SubmitCommand?.Refresh();
        if(!IsCreateLoginOperation)return;

        var server=SelectedWorkingServer;
        var target=TargetPrincipal.Trim();
        if(server is null||target.Length==0)
        {
            CreateLoginTargetValidationMessage=IsWindowsAuthentication?"Indique la cuenta Windows existente (DOMINIO\\usuario o EQUIPO\\usuario).":"Indique el nombre del nuevo login SQL.";
            return;
        }

        using var cancellation=new CancellationTokenSource();
        _createLoginTargetCancellation=cancellation;
        var ct=cancellation.Token;
        CreateLoginTargetValidationMessage="Comprobando si el nombre está disponible…";
        try
        {
            SqlAccessAdmin.Models.LoginAuthentication.Validate(SelectedOperation!.Code,target,AuthenticationType);
            await Task.Delay(400,ct);
            // La creación puede incluir usuarios de base más adelante en el mismo
            // formulario; compruebe desde el inicio tanto el login como las bases accesibles.
            var databases=await _direct.GetCopyDatabasesAsync(server,ct);
            await _direct.EnsureCopyTargetAvailableAsync(server.Id,target,databases,ct);
            ct.ThrowIfCancellationRequested();
            _isCreateLoginTargetAvailable=true;
            Raise(nameof(IsCreateLoginTargetAvailable));
            CreateLoginTargetValidationMessage=IsWindowsAuthentication
                ?"✓ El nombre está disponible para crear la cuenta."
                :"✓ El nombre está disponible.";
        }
        catch(OperationCanceledException)when(ct.IsCancellationRequested){}
        catch(Exception error)
        {
            if(!ct.IsCancellationRequested)CreateLoginTargetValidationMessage=error.Message;
        }
        finally
        {
            if(ReferenceEquals(_createLoginTargetCancellation,cancellation))
            {
                _createLoginTargetCancellation=null;
                PreviewCommand?.Refresh();SubmitCommand?.Refresh();
            }
        }
    }
}
