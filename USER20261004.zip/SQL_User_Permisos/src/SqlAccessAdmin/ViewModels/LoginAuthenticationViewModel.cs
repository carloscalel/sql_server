using SqlAccessAdmin.Models;

namespace SqlAccessAdmin.ViewModels;

public sealed partial class AccessViewModel
{
    public bool IsSqlAuthentication
    {
        get=>AuthenticationType=="SQL";
        set{if(value)AuthenticationType="SQL";}
    }
    public bool IsWindowsAuthentication
    {
        get=>AuthenticationType=="WINDOWS";
        set{if(value)AuthenticationType="WINDOWS";}
    }
    public string AuthenticationHelp=>IsWindowsAuthentication
        ?"Use una cuenta de Windows existente con el formato DOMINIO\\usuario o EQUIPO\\usuario. Después seleccione Comprobar cuenta. La contraseña habitual del usuario no se solicita aquí."
        :"Se creará una cuenta SQL con la contraseña temporal que indique a continuación.";

    private void ChangeAuthenticationType(string value)
    {
        if(RequiresAuthenticationType&&value is not ("SQL" or "WINDOWS"))
            throw new InvalidOperationException("Seleccione un único tipo de autenticación.");
        if(!Set(ref _authenticationType,value,nameof(AuthenticationType)))return;
        ResetWindowsNameValidation();
        if(IsCreateLoginOperation)
        {
            var code=LoginAuthentication.CreationOperation(value);
            // Cambiar solo la operación conserva ticket, justificación y accesos iniciales.
            var operation=Operations.FirstOrDefault(x=>x.Code==code)
                ??new PolicyOperation(code,value=="SQL"?"Crear login SQL":"Crear login Windows",false,true,"HIGH","Configuración pendiente en la política central.");
            Set(ref _operation,operation,nameof(SelectedOperation));
        }
        ClearTemporaryPassword();
        Decision=null;
        RaiseAuthenticationState();
        if(IsClonePermissionsOperation)_=ValidateCopyTargetAsync();
        else if(IsCreateLoginOperation)_=ValidateCreateLoginTargetAsync();
    }

    private void RaiseAuthenticationState()
    {
        Raise(nameof(IsSqlAuthentication));Raise(nameof(IsWindowsAuthentication));Raise(nameof(AuthenticationHelp));
        Raise(nameof(RequiresAuthenticationType));Raise(nameof(RequiresTemporaryPassword));Raise(nameof(IsCreateSqlLoginOperation));
        Raise(nameof(TargetPrincipalLabel));Raise(nameof(TargetPrincipalHelp));Raise(nameof(OperationGuidance));
        Raise(nameof(NeedsPolicyConfiguration));Raise(nameof(PolicyConfigurationWarning));Raise(nameof(OperationBadge));
        RaisePasswordValidationState();
        PreviewCommand?.Refresh();SubmitCommand?.Refresh();
    }
}
