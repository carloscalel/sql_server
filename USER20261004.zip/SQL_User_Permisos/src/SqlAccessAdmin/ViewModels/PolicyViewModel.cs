using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Windows;
using System.Windows.Data;
using SqlAccessAdmin.Data;
using SqlAccessAdmin.Infrastructure;
using SqlAccessAdmin.Models;

namespace SqlAccessAdmin.ViewModels;

public sealed class PolicyViewModel : BindableBase
{
    private readonly IPolicyStore _db;
    private readonly SessionContext _session;
    private readonly Func<string, bool> _confirm;
    private readonly IPolicyDiscovery? _discovery;
    private bool _initialized;
    private PolicyServerChoice _selectedInstance = new(0, "Plantilla general");
    private PolicyDatabaseChoice _selectedDatabase = new("", "Todas las bases · política de instancia");
    public ObservableCollection<PolicyServerChoice> Instances { get; } = [new(0, "Plantilla general")];
    public ObservableCollection<PolicyDatabaseChoice> Databases { get; } = [new("", "Todas las bases · política de instancia")];
    public PolicyServerChoice SelectedInstance { get => _selectedInstance; set { if (value is not null && value != _selectedInstance) _ = ChangeContextAsync(value, Databases[0]); } }
    public PolicyDatabaseChoice SelectedDatabase { get => _selectedDatabase; set { if (value is not null && value != _selectedDatabase) _ = ChangeContextAsync(_selectedInstance, value); } }
    public PolicyContext Context => new(SelectedInstance.Id, SelectedDatabase.Name);
    public bool HasInstance => SelectedInstance.Id > 0;
    public bool CanChangeContext => IsAdministrator && !IsBusy && !HasActivation;
    public string ContextDisplay => Context.Level == "GENERAL" ? "Plantilla general · valores predeterminados"
        : SelectedInstance.Name + (Context.Database.Length == 0 ? " · Todas las bases" : " / " + Context.Database);
    public string InheritanceHelp => Context.Level == "GENERAL" ? "Define los valores que heredan las instancias y bases sin una configuración propia."
        : "Cambie solo lo necesario. General → Instancia → Base de datos. Los roles personalizados nuevos esperan autorización en su destino.";
    private bool _busy, _loaded, _showAdvanced;
    private string _status = "Cargando política…", _search = "", _stateFilter = "Todos";
    private string _newRoleName = "", _newRoleNotes = "", _denyCategory = "PERMISSION", _denyValue = "", _denyReason = "";
    private IReadOnlyList<DenyRule> _denyRules = [];
    private PolicyActivationViewModel? _activation;
    private string _activationStatus = "";
    public string ActivationStatus { get => _activationStatus; private set => Set(ref _activationStatus, value); }
    public PolicyActivationViewModel? Activation { get => _activation; private set { if (Set(ref _activation, value)) { Raise(nameof(HasActivation)); UpdateState(); } } }
    public bool HasActivation => Activation is not null;
    public ObservableCollection<PermissionPolicyItem> Permissions { get; } = [];
    public ObservableCollection<RolePolicyItem> Roles { get; } = [];
    public ObservableCollection<PolicyBlockItem> Blocks { get; } = [];
    public ICollectionView PermissionView { get; }
    public ICollectionView RoleView { get; }
    public string[] StateFilters { get; } = ["Todos", "Permitidos", "Bloqueados", "Protegidos"];
    public KeyValuePair<string, string>[] DenyCategories { get; } =
    [new("PERMISSION", "Permiso"), new("DATABASE_ROLE", "Rol de base"), new("SERVER_ROLE", "Rol de servidor"), new("OPERATION", "Operación"), new("CLAUSE", "Opción SQL")];
    public bool IsAdministrator => _session.Role == AppRole.Administrator;
    public bool IsBusy { get => _busy; private set { if (Set(ref _busy, value)) UpdateState(); } }
    public bool CanEdit => IsAdministrator && _loaded && !IsBusy && !HasActivation;
    public bool CanFillActivation => IsAdministrator && _loaded && !IsBusy;
    public bool ShowAdvanced { get => _showAdvanced; set => Set(ref _showAdvanced, value); }
    public string Status { get => _status; private set => Set(ref _status, value); }
    public string Search { get => _search; set { if (Set(ref _search, value)) RefreshFilters(); } }
    public string StateFilter { get => _stateFilter; set { if (Set(ref _stateFilter, value)) RefreshFilters(); } }
    public string NewRoleName { get => _newRoleName; set { if (Set(ref _newRoleName, value)) AddRoleCommand.Refresh(); } }
    public string NewRoleNotes { get => _newRoleNotes; set => Set(ref _newRoleNotes, value); }
    public string DenyCategory { get => _denyCategory; set => Set(ref _denyCategory, value); }
    public string DenyValue { get => _denyValue; set { if (Set(ref _denyValue, value)) AddDenyCommand.Refresh(); } }
    public string DenyReason { get => _denyReason; set { if (Set(ref _denyReason, value)) AddDenyCommand.Refresh(); } }
    public int PendingCount => Permissions.Count(x => x.IsDirty) + Roles.Count(x => x.IsDirty);
    public bool HasChanges => PendingCount > 0;
    public string PendingSummary => PendingCount switch { 0 => "Sin cambios pendientes", 1 => "1 cambio sin guardar", _ => $"{PendingCount} cambios sin guardar" };
    public string CatalogSummary => $"{Permissions.Count(x => x.IsAllowed)} permisos y {Roles.Count(x => x.IsAllowed)} roles permitidos";
    public bool HasVisiblePermissions => PermissionView.Cast<object>().Any();
    public bool HasVisibleRoles => RoleView.Cast<object>().Any();
    public string PermissionResultSummary => $"{PermissionView.Cast<object>().Count()} de {Permissions.Count} permisos";
    public string RoleResultSummary => $"{RoleView.Cast<object>().Count()} de {Roles.Count} roles";
    public AsyncCommand RefreshCommand { get; }
    public AsyncCommand SaveCommand { get; }
    public RelayCommand DiscardCommand { get; }
    public RelayCommand AddRoleCommand { get; }
    public AsyncCommand AddDenyCommand { get; }
    public AsyncCommand ActivateSpecialCommand { get; }
    public RelayCommand CancelActivationCommand { get; }
    private List<PolicyPermission> _savedPermissions = [];
    private List<PolicyRole> _savedRoles = [];

    public PolicyViewModel(IPolicyStore db, SessionContext session, Func<string, bool>? confirm = null, bool loadOnStart = true, IPolicyDiscovery? discovery = null)
    {
        _db = db; _session = session; _discovery = discovery;
        _confirm = confirm ?? (message => MessageBox.Show(message, "Política de acceso",
            MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes);
        PermissionView = CollectionViewSource.GetDefaultView(Permissions);
        RoleView = CollectionViewSource.GetDefaultView(Roles);
        PermissionView.Filter = item => Matches((PermissionPolicyItem)item);
        RoleView.Filter = item => Matches((RolePolicyItem)item);
        RefreshCommand = new(RefreshAsync, () => IsAdministrator && !IsBusy && !HasActivation);
        SaveCommand = new(SaveAsync, () => CanEdit && HasChanges);
        DiscardCommand = new(Discard, () => CanEdit && HasChanges);
        AddRoleCommand = new(AddRole, () => CanEdit && !string.IsNullOrWhiteSpace(NewRoleName));
        AddDenyCommand = new(AddDenyAsync, () => CanEdit && !HasChanges && !string.IsNullOrWhiteSpace(DenyValue) && !string.IsNullOrWhiteSpace(DenyReason));
        ActivateSpecialCommand = new(ActivateSpecialAsync, () => CanFillActivation && Activation?.CanActivate == true);
        CancelActivationCommand = new(CancelActivation, () => !IsBusy && HasActivation);
        if (loadOnStart && IsAdministrator) RefreshCommand.Execute(null);
        else if (!IsAdministrator) Status = "Solo un administrador puede administrar la política.";
    }

    private bool Matches(PolicyEditorItem item)
    {
        var text = item switch
        {
            PermissionPolicyItem p => $"{p.Permission} {p.Description} {p.HelpDescription} {p.ScopeDisplay}",
            RolePolicyItem r => $"{r.Name} {r.Description} {r.Notes} {r.KindDisplay}", _ => ""
        };
        return text.Contains(Search.Trim(), StringComparison.OrdinalIgnoreCase) && StateFilter switch
        {
            "Permitidos" => item.IsAllowed, "Bloqueados" => !item.IsAllowed && !item.IsProtected,
            "Protegidos" => item.IsProtected, _ => true
        };
    }
    private void RefreshFilters()
    {
        PermissionView.Refresh(); RoleView.Refresh();
        Raise(nameof(HasVisiblePermissions)); Raise(nameof(HasVisibleRoles));
        Raise(nameof(PermissionResultSummary)); Raise(nameof(RoleResultSummary));
    }
    private void ItemChanged(object? sender, PropertyChangedEventArgs e)
    {
        if (e.PropertyName != nameof(PolicyEditorItem.IsDirty)) return;
        UpdateState(); RefreshFilters();
    }
    private void UpdateState()
    {
        Raise(nameof(CanEdit)); Raise(nameof(PendingCount)); Raise(nameof(HasChanges));
        Raise(nameof(CanFillActivation));
        Raise(nameof(CanChangeContext)); Raise(nameof(HasInstance)); Raise(nameof(ContextDisplay)); Raise(nameof(InheritanceHelp));
        Raise(nameof(PendingSummary)); Raise(nameof(CatalogSummary));
        RefreshCommand.Refresh(); SaveCommand.Refresh(); DiscardCommand.Refresh(); AddRoleCommand.Refresh(); AddDenyCommand.Refresh();
        ActivateSpecialCommand.Refresh(); CancelActivationCommand.Refresh();
        foreach (var item in Permissions.Cast<PolicyEditorItem>().Concat(Roles)) item.ActivateCommand?.Refresh();
        foreach (var item in Permissions.Cast<PolicyEditorItem>().Concat(Roles)) item.RestoreCommand?.Refresh();
    }
    private void BuildItems()
    {
        foreach (var item in Permissions.Cast<PolicyEditorItem>().Concat(Roles)) item.PropertyChanged -= ItemChanged;
        Permissions.Clear(); Roles.Clear(); Blocks.Clear();
        // El catálogo completo permite habilitar combinaciones aún no registradas.
        foreach (var name in PolicyEditorCatalog.Permissions)
        foreach (var scope in PolicyEditorCatalog.Scopes)
        {
            var rule = _savedPermissions.FirstOrDefault(x => x.Permission == name && x.Scope == scope)
                ?? new(name, scope, true, false, true, false, "", default);
            Permissions.Add(new(rule, rule.Supported ? PolicyEditorCatalog.PermissionProtection(name, scope, _denyRules) : "Esta combinación no es válida en SQL Server."));
        }
        foreach (var rule in _savedPermissions.Where(x => !PolicyEditorCatalog.Permissions.Contains(x.Permission) || !PolicyEditorCatalog.Scopes.Contains(x.Scope)))
            Permissions.Add(new(rule, rule.Supported ? PolicyEditorCatalog.PermissionProtection(rule.Permission, rule.Scope, _denyRules) : "Esta combinación no es válida en SQL Server."));
        foreach (var role in _savedRoles.Where(x => !SqlSystemNames.IsReserved(x.Name))) Roles.Add(new(role, role.RoleScope == "SERVER" && !PolicyEditorCatalog.IsPermanentlyBlockedRole(role.Name)
            ? "Este rol controla privilegios de la instancia. Requiere autorización especial." : PolicyEditorCatalog.RoleProtection(role.Name, _denyRules)));
        foreach (var rule in _denyRules.Where(x => x.Active && !SqlSystemNames.IsReserved(x.Value))) Blocks.Add(new(rule));
        foreach (var item in Permissions.Cast<PolicyEditorItem>().Concat(Roles))
        {
            item.PropertyChanged += ItemChanged;
            item.ActivateCommand = new(() => BeginSpecialActivation(item), () => CanEdit && !HasChanges && item.CanRequestSpecialActivation);
            item.CanRestoreInheritance = Context != PolicyContext.General && item.Origin == Context.Level;
            item.RestoreCommand = new(() => _ = RestoreInheritanceAsync(item), () => CanEdit && !HasChanges && item.CanRestoreInheritance);
        }
        RefreshFilters(); UpdateState();
    }
    private async Task ReadAsync()
    {
        // Publicar solo después de obtener el catálogo completo, incluidos sus bloqueos.
        var permissions = await _db.GetPolicyPermissionsAsync(Context);
        var roles = await _db.GetPolicyRolesAsync(Context);
        var blocks = await _db.GetDenyRulesAsync();
        _savedPermissions = permissions.ToList(); _savedRoles = roles.ToList(); _denyRules = blocks;
        _loaded = true; BuildItems();
    }
    private void InvalidateCatalog()
    {
        _loaded = false;
        foreach (var item in Permissions.Cast<PolicyEditorItem>().Concat(Roles)) item.PropertyChanged -= ItemChanged;
        Permissions.Clear(); Roles.Clear(); Blocks.Clear();
        _savedPermissions = []; _savedRoles = []; _denyRules = [];
        RefreshFilters(); UpdateState();
    }
    private async Task RefreshAsync()
    {
        if (!IsAdministrator || IsBusy || HasActivation) return;
        if (HasChanges && !_confirm("Hay cambios sin guardar. ¿Desea descartarlos y actualizar el catálogo?")) return;
        IsBusy = true;
        try
        {
            if (!_initialized)
            {
                foreach (var server in await _db.GetServersAsync()) if (server.Active) Instances.Add(new(server.Id, server.Name));
                _selectedInstance = Instances[0]; _initialized = true; Raise(nameof(SelectedInstance));
            }
            await DiscoverAsync(); await ReadAsync();
            Status = "Política actualizada. Marque o desmarque una opción y guarde los cambios.";
        }
        catch (InvalidOperationException error) { InvalidateCatalog(); Status = error.Message + " Pulse Actualizar para reintentar; puede cambiar de pestaña o destino."; }
        catch { InvalidateCatalog(); Status = "No se pudo cargar la política completa. Revise la conexión y las migraciones; pulse Actualizar para reintentar."; }
        finally { IsBusy = false; }
    }
    private void Discard()
    {
        if (!CanEdit || !HasChanges) return;
        if (!_confirm("¿Desea descartar todos los cambios sin guardar?")) return;
        BuildItems(); Status = "Cambios descartados.";
    }
    private async Task DiscoverAsync()
    {
        if (_discovery is null || !HasInstance) return;
        var discovered = await _discovery.DiscoverPolicyAsync(Context);
        await _db.RegisterPolicyDiscoveryAsync(Context, discovered);
    }
    private async Task ChangeContextAsync(PolicyServerChoice instance, PolicyDatabaseChoice database)
    {
        if (!CanChangeContext) { Raise(nameof(SelectedInstance)); Raise(nameof(SelectedDatabase)); return; }
        if (HasChanges && !_confirm("Hay cambios sin guardar. ¿Desea descartarlos y cambiar el destino de la política?"))
        { Raise(nameof(SelectedInstance)); Raise(nameof(SelectedDatabase)); return; }
        var instanceChanged = instance.Id != _selectedInstance.Id;
        IsBusy = true; _loaded = false;
        _selectedInstance = instance; _selectedDatabase = database;
        InvalidateCatalog();
        Status = "Cargando política para " + ContextDisplay + "…";
        Raise(nameof(SelectedInstance)); Raise(nameof(SelectedDatabase));
        try
        {
            if (instanceChanged)
            {
                Databases.Clear(); Databases.Add(new("", "Todas las bases · política de instancia"));
                _selectedDatabase = Databases[0]; Raise(nameof(SelectedDatabase));
                if (HasInstance && _discovery is not null)
                {
                    var server = (await _db.GetServersAsync()).Single(x => x.Id == instance.Id);
                    foreach (var db in await _discovery.GetPolicyDatabasesAsync(server)) Databases.Add(new(db.Name, db.Name));
                }
            }
            await DiscoverAsync(); await ReadAsync(); Status = "Política cargada para " + ContextDisplay + ".";
        }
        catch (InvalidOperationException error) { InvalidateCatalog(); Status = error.Message + " Pulse Actualizar para reintentar; puede cambiar de pestaña o destino."; }
        catch { InvalidateCatalog(); Status = "No se pudo cargar este destino. Revise la conexión y las migraciones; pulse Actualizar para reintentar."; }
        finally { IsBusy = false; }
    }
    private async Task RestoreInheritanceAsync(PolicyEditorItem item)
    {
        if (!CanEdit || HasChanges || !item.CanRestoreInheritance) return;
        if (!_confirm("¿Restaurar el valor heredado para este elemento en " + ContextDisplay + "?\nSe eliminará solo la configuración de este nivel.")) return;
        IsBusy = true;
        try
        {
            await _db.RestorePolicyInheritanceAsync(Context,
                item is RolePolicyItem role ? role.RoleScope == "SERVER" ? "SERVER_ROLE" : "DATABASE_ROLE" : "PERMISSION",
                item is RolePolicyItem r ? r.Name : ((PermissionPolicyItem)item).Permission,
                item is PermissionPolicyItem p ? p.Scope : "");
            await ReadAsync(); Status = "Valor heredado restaurado.";
        }
        catch { Status = "No se pudo restaurar el valor heredado. Actualice y reintente."; }
        finally { IsBusy = false; }
    }
    public bool ConfirmLeave()
    {
        if (IsBusy) { Status = "Espere a que termine la operación antes de salir de la política."; return false; }
        return (!HasChanges && !HasActivation) || _confirm("Hay cambios de política sin guardar. ¿Desea salir y descartarlos?");
    }
    private async Task SaveAsync()
    {
        if (!CanEdit || !HasChanges) return;
        var permissions = Permissions.Where(x => x.IsDirty).ToList();
        var roles = Roles.Where(x => x.IsDirty).ToList();
        var invalid = permissions.FirstOrDefault(x => x.IsAllowed && !x.AllowGrant && !x.AllowDeny && !x.AllowRevoke);
        if (invalid is not null)
        { Status = $"{invalid.Description} ({invalid.ScopeDisplay}): permita asignar, denegar o retirar, o bloquee el permiso."; return; }
        if (roles.Any(x => x.Notes.Length > 500)) { Status = "La descripción de un rol admite hasta 500 caracteres."; return; }
        var changes = permissions.Select(x => $"• {x.Description} ({x.Permission}) · {x.ScopeDisplay}: {x.StateDisplay}{(x.IsAllowed ? " · " + x.ActionSummary : "")}")
            .Concat(roles.Select(x => $"• {x.Name}: {x.StateDisplay}{(x.NotesChanged ? " · Descripción: " + x.Description : "")}"));
        if (!_confirm("¿Guardar estos cambios en " + ContextDisplay + "?\n\n" + string.Join("\n", changes)
            + "\n\nControlan las nuevas solicitudes y las pendientes al ejecutarlas. No cambian los accesos ya asignados en SQL Server.")) return;
        IsBusy = true;
        var saved = 0;
        string current = "";
        try
        {
            // Releer los bloqueos antes de guardar; el servidor sigue siendo la autoridad final.
            var blocks = await _db.GetDenyRulesAsync();
            var livePermissions = await _db.GetPolicyPermissionsAsync(Context);
            var liveRoles = await _db.GetPolicyRolesAsync(Context);
            foreach (var item in permissions)
                if (item.IsAllowed && PolicyEditorCatalog.PermissionProtection(item.Permission, item.Scope, blocks,
                    livePermissions.Any(x => x.Permission == item.Permission && x.Scope == item.Scope && x.SpecialActivationApproved)).Length > 0)
                { Status = "Un permiso ahora está protegido. Actualice el catálogo antes de guardar."; return; }
            foreach (var item in roles)
                if (item.IsAllowed && PolicyEditorCatalog.RoleProtection(item.Name, blocks,
                    liveRoles.Any(x => x.Name.Equals(item.Name,StringComparison.OrdinalIgnoreCase) && x.SpecialActivationApproved)).Length > 0)
                { Status = "Un rol ahora está protegido. Actualice el catálogo antes de guardar."; return; }
            foreach (var item in permissions)
            {
                current = $"{item.Description} · {item.ScopeDisplay}";
                var rule = item.ToPolicy(_session.Principal, DateTime.UtcNow) with { Origin = Context.Level };
                await _db.UpsertPermissionAsync(Context, rule);
                _savedPermissions.RemoveAll(x => x.Permission == rule.Permission && x.Scope == rule.Scope);
                _savedPermissions.Add(rule); item.AcceptSaved(rule); saved++;
            }
            foreach (var item in roles)
            {
                current = item.Name;
                var rule = item.ToPolicy(_session.Principal, DateTime.UtcNow) with { Origin = Context.Level };
                await _db.UpsertRoleAsync(Context, rule);
                _savedRoles.RemoveAll(x => x.Name.Equals(rule.Name, StringComparison.OrdinalIgnoreCase) && x.RoleScope == rule.RoleScope);
                _savedRoles.Add(rule); item.AcceptSaved(rule); saved++;
            }
            try { await ReadAsync(); Status = $"Cambios guardados: {saved}."; }
            catch { _loaded = false; Status = $"Cambios guardados: {saved}. No se pudo actualizar el catálogo; pulse Actualizar."; }
        }
        catch
        {
            Status = $"No se pudo guardar{(current.Length > 0 ? " «" + current + "»" : " la política")}. Guardados: {saved}; pendientes: {PendingCount}. Revise los cambios y reintente; si el problema continúa, contacte al administrador.";
        }
        finally { IsBusy = false; }
    }
    private void AddRole()
    {
        if (!CanEdit) return;
        var name = NewRoleName.Trim();
        if (name.Length is 0 or > 128) { Status = "Indique un nombre de rol de hasta 128 caracteres."; return; }
        if (NewRoleNotes.Length > 500) { Status = "La descripción admite hasta 500 caracteres."; return; }
        if (Roles.Any(x => x.Name.Equals(name, StringComparison.OrdinalIgnoreCase))) { Status = "Este rol ya está en el catálogo. Búsquelo para cambiar su estado."; return; }
        if (PolicyEditorCatalog.RoleProtection(name, _denyRules).Length > 0 || PolicyEditorCatalog.IsFixedRole(name))
        { Status = "Use el catálogo existente para los roles integrados. Aquí puede agregar un rol personalizado."; return; }
        var item = new RolePolicyItem(new(name, "CUSTOM", true, _session.Principal, default, NewRoleNotes.Trim()), isNew: true);
        item.PropertyChanged += ItemChanged; Roles.Add(item);
        NewRoleName = ""; NewRoleNotes = ""; Search = ""; StateFilter = "Todos";
        RefreshFilters(); UpdateState(); Status = $"Rol «{name}» agregado al borrador. Pulse Guardar cambios para registrarlo.";
    }
    private async Task AddDenyAsync()
    {
        if (!CanEdit || HasChanges) return;
        var value = DenyValue.Trim(); var reason = DenyReason.Trim();
        if (!DenyCategories.Any(x => x.Key == DenyCategory) || value.Length is 0 or > 256 || reason.Length is 0 or > 1000)
        { Status = "Seleccione una categoría, indique el valor (hasta 256 caracteres) y el motivo (hasta 1000)."; return; }
        if (_denyRules.Any(x => x.Active && x.Category == DenyCategory && x.Value.Equals(value, StringComparison.OrdinalIgnoreCase)))
        { Status = "Este bloqueo ya existe. Puede consultar su motivo en la lista."; return; }
        if (!_confirm($"¿Agregar un bloqueo obligatorio para «{value}»?\n\nMotivo: {reason}\n\nSe guardará inmediatamente y tendrá prioridad sobre las opciones permitidas. Esta pantalla no permite eliminarlo.")) return;
        IsBusy = true;
        try
        {
            await _db.UpsertDenyRuleAsync(DenyCategory, value, reason);
            DenyValue = ""; DenyReason = "";
            try { await ReadAsync(); Status = "Bloqueo obligatorio guardado."; }
            catch { _loaded = false; Status = "Bloqueo guardado. No se pudo actualizar el catálogo; pulse Actualizar."; }
        }
        catch { Status = "No se pudo guardar el bloqueo. Reintente o contacte al administrador."; }
        finally { IsBusy = false; }
    }
    public void BeginSpecialActivation(PolicyEditorItem item)
    {
        if (!CanEdit || HasChanges || !item.CanRequestSpecialActivation
            || !Permissions.Cast<PolicyEditorItem>().Concat(Roles).Contains(item)) return;
        Activation = new(item, ContextDisplay);
        ActivationStatus = "";
        Activation.PropertyChanged += ActivationChanged;
    }
    private void ActivationChanged(object? sender, PropertyChangedEventArgs e) => ActivateSpecialCommand.Refresh();
    private void CancelActivation()
    {
        if (IsBusy) return;
        if (Activation is not null) Activation.PropertyChanged -= ActivationChanged;
        Activation = null;
    }
    private async Task ActivateSpecialAsync()
    {
        if (!CanFillActivation || Activation?.CanActivate != true || HasChanges) return;
        var request = Activation.ToRequest();
        request.Validate();
        IsBusy = true;
        try
        {
            await _db.ActivateSpecialPolicyAsync(Context, request);
            Activation.PropertyChanged -= ActivationChanged;
            Activation = null;
            try { await ReadAsync(); Status = $"{request.Value} habilitado con autorización especial. El cambio quedó registrado."; }
            catch { _loaded = false; Status = "Activación guardada. No se pudo actualizar el catálogo; pulse Actualizar."; }
        }
        catch (Microsoft.Data.SqlClient.SqlException ex) when (ex.Number == 2812)
        { Status = ActivationStatus = "Falta actualizar la infraestructura. Solicite al administrador aplicar el script 27 de política por destino."; }
        catch (Microsoft.Data.SqlClient.SqlException ex) when (ex.Number == 51371 && request.Category == "PERMISSION"
            && PolicyEditorCatalog.RequiresPermissionActivation(request.Value, request.Scope))
        { Status = ActivationStatus = "Este permiso requiere la infraestructura actualizada. Aplique el script 27, actualice la política y reintente."; }
        catch { Status = ActivationStatus = "No se pudo autorizar la activación. Revise los datos o actualice la política antes de reintentar."; }
        finally { IsBusy = false; }
    }
}
