using System.Collections.ObjectModel;
using System.ComponentModel;
using SqlAccessAdmin.Infrastructure;
using SqlAccessAdmin.Models;

namespace SqlAccessAdmin.ViewModels;

public sealed partial class AccessViewModel
{
    private int _createUserStep=1,_createUserDatabaseVersion,_createUserObjectVersion;
    private bool _includeInitialObjectPermissions,_isLoadingCreateUserDatabases,_isLoadingCreateUserObjects,_createUserDatabasesLoaded;
    private string _createUserDatabaseError="";
    private Dictionary<string,(IReadOnlyList<PolicyPermission> Permissions,IReadOnlyList<PolicyRole> Roles)>? _createUserPolicies;
    private RelayCommand? _createUserNextCommand,_createUserPreviousCommand,_removeCreateUserObjectCommand;
    private ObservableCollection<ObjectPermissionRow>? _createUserObjectRows;
    private ObjectPermissionRow? _selectedCreateUserObjectRow;
    private DatabaseItem? _selectedCreateUserObjectDatabase;
    private ObservableCollection<DatabaseItem>? _createUserObjectDatabaseChoices;

    public ObservableCollection<ObjectPermissionRow> CreateUserObjectRows=>_createUserObjectRows??=[];
    public ObjectPermissionRow? SelectedCreateUserObjectRow
    {
        get=>_selectedCreateUserObjectRow;
        set{if(Set(ref _selectedCreateUserObjectRow,value))RemoveCreateUserObjectCommand.Refresh();}
    }
    public int CreateUserStep=>Math.Max(1,_createUserStep);
    public bool IsCreateUserAccountStep=>IsCreateLoginOperation&&CreateUserStep==1;
    public bool IsCreateUserMappingStep=>IsCreateLoginOperation&&CreateUserStep==2;
    public bool IsCreateUserObjectsStep=>IsCreateLoginOperation&&CreateUserStep==3;
    public bool ShowCreateUserContext=>IsCreateLoginOperation&&CreateUserStep>1;
    public bool IsLegacyStandardAccessOperation=>IsStandardAccessOperation&&!IsCreateLoginOperation;
    public bool ShowAuthenticationCard=>RequiresAuthenticationType&&(!IsCreateLoginOperation||IsCreateUserAccountStep);
    public bool ShowIdentityCard=>IsBasicIdentityOperation&&(!IsCreateLoginOperation||IsCreateUserAccountStep);
    public bool ShowPasswordCard=>RequiresTemporaryPassword&&(!IsCreateLoginOperation||IsCreateUserAccountStep);
    public bool ShowTicketCard=>HasTopRequestDetails&&(!IsCreateLoginOperation||IsCreateUserAccountStep);
    public bool ShowRequestAccessCard=>!IsCreateLoginOperation;
    public bool IsLoadingCreateUserDatabases=>_isLoadingCreateUserDatabases;
    public bool IsLoadingCreateUserObjects=>_isLoadingCreateUserObjects;
    public bool HasCreateUserDatabaseError=>_createUserDatabaseError.Length>0;
    public string CreateUserDatabaseMessage=>IsLoadingCreateUserDatabases?"Cargando las bases de datos…"
        :HasCreateUserDatabaseError?_createUserDatabaseError
        :$"Bases disponibles: {Databases.Count}. Seleccionadas: {Databases.Count(x=>x.IsSelected)}.";
    public bool HasCreateUserDatabaseAccess=>IncludeInitialAccess||IncludeInitialObjectPermissions;
    public ObservableCollection<DatabaseItem> CreateUserObjectDatabaseChoices=>_createUserObjectDatabaseChoices??=[];
    public DatabaseItem? SelectedCreateUserObjectDatabase
    {
        get=>_selectedCreateUserObjectDatabase;
        set
        {
            if(!Set(ref _selectedCreateUserObjectDatabase,value))return;
            ClearCreateUserObjects();RefreshCreateUserScopedChoices();Decision=null;RefreshCreateUserWizard();
        }
    }
    public string CreateUserObjectDatabase=>SelectedCreateUserObjectDatabase?.Name??"";
    public int CreateUserObjectsStepNumber=>IncludeInitialAccess?3:2;
    public string CreateUserObjectsStepLabel=>$"{CreateUserObjectsStepNumber}. Permisos a objetos";
    public string CreateUserTitle=>$"Asistente de creación de usuario · {SelectedWorkingServer?.Name??"SQL Server"}";
    public string CreateUserStepTitle=>CreateUserStep switch
    {
        2=>"Paso 2: Acceso a bases de datos",
        3=>$"Paso {CreateUserObjectsStepNumber}: Acceso a objetos específicos",
        _=>"Paso 1: Datos de la cuenta"
    };
    public string CreateUserContextSummary=>$"Usuario: {TargetPrincipal} · Tipo de cuenta: {(IsWindowsAuthentication?"Windows":"SQL")} · Ticket: {ExternalTicketNumber}";
    public string CreateUserMappingStepHint=>IncludeInitialAccess?"Bases de datos, roles y permisos generales":"Este paso no se incluirá";
    public string CreateUserObjectsStepHint=>IncludeInitialObjectPermissions?"Tablas, vistas, funciones y procedimientos":"Este paso no se incluirá";
    public string CreateUserObjectSummary=>$"Objetos agregados: {CreateUserObjectRows.Count}. Permisos seleccionados: {CreateUserObjectRows.Sum(x=>x.SelectedPermissions.Count())}.";
    public bool IncludeInitialObjectPermissions
    {
        get=>_includeInitialObjectPermissions;
        set
        {
            if(!Set(ref _includeInitialObjectPermissions,value))return;
            if(!value){SelectedCreateUserObjectDatabase=null;ClearCreateUserObjects();}
            SynchronizeCreateUserObjectDatabase();
            Decision=null;CreateUserAccessOptionsChanged();
        }
    }
    public bool IsCreateUserFinalStep=>IsCreateLoginOperation&&(!HasCreateUserDatabaseAccess||CreateUserStep==(IncludeInitialObjectPermissions?3:2));
    public bool ShowCreateUserNextButton=>IsCreateLoginOperation&&!IsCreateUserFinalStep;
    public RelayCommand CreateUserNextCommand=>_createUserNextCommand??=new(()=>
    {
        if(!IsCreateLoginOperation||IsCreateUserFinalStep||CreateUserStepValidationMessage.Length>0)return;
        _createUserStep=CreateUserStep==1&&IncludeInitialAccess?2:3;
        SynchronizeCreateUserObjectDatabase();RefreshCreateUserWizard();
    },()=>IsCreateLoginOperation&&!IsCreateUserFinalStep&&CreateUserStepValidationMessage.Length==0);
    public RelayCommand CreateUserPreviousCommand=>_createUserPreviousCommand??=new(()=>
    {
        _createUserStep=CreateUserStep==3&&IncludeInitialAccess?2:1;RefreshCreateUserWizard();
    },()=>IsCreateLoginOperation&&CreateUserStep>1);
    public RelayCommand RemoveCreateUserObjectCommand=>_removeCreateUserObjectCommand??=new(()=>
    {
        if(SelectedCreateUserObjectRow is not { } row)return;
        row.PropertyChanged-=CreateUserObjectChanged;CreateUserObjectRows.Remove(row);
        SelectedCreateUserObjectRow=null;Decision=null;RefreshCreateUserWizard();
    },()=>SelectedCreateUserObjectRow is not null&&!IsLoadingCreateUserObjects);

    private string CreateUserAccountValidationMessage
    {
        get
        {
            if(!HasWorkingServer)return "Seleccione un servidor de trabajo.";
            if(NeedsPolicyConfiguration)return PolicyConfigurationWarning;
            if(!IsExternalTicketValid)return "Valide un ticket activo en adminDB para continuar.";
            if(Justification.Trim().Length<10)return "Escriba una justificación de al menos 10 caracteres.";
            if(string.IsNullOrWhiteSpace(TargetPrincipal))return IsWindowsAuthentication
                ?"Escriba la cuenta de Windows."
                :"Escriba el nombre de la cuenta SQL.";
            if(!IsCreateLoginTargetAvailable)return CreateLoginTargetValidationMessage;
            if(!CanUseValidatedWindowsName)return "Seleccione Comprobar cuenta para confirmar la cuenta de Windows.";
            if(!IsTemporaryPasswordValid)return TemporaryPasswordValidationMessage;
            return "";
        }
    }
    private string CreateUserMappingValidationMessage
    {
        get
        {
            if(!IncludeInitialAccess)return "";
            if(IsLoadingCreateUserDatabases)return "Espere mientras se cargan las bases de datos.";
            if(HasCreateUserDatabaseError)return _createUserDatabaseError;
            var selected=Databases.Where(x=>x.IsSelected).ToList();
            if(selected.Count==0)return "Seleccione al menos una base de datos. Asignar roles o permisos generales es opcional.";
            if(selected.Any(x=>x.ServerId!=SelectedWorkingServer?.Id))return "Seleccione únicamente bases de datos del servidor actual.";
            if(IncludeInitialObjectPermissions&&selected.Count!=1)return "Como también asignará permisos a objetos, seleccione solo una base de datos.";
            return "";
        }
    }
    private string CreateUserObjectDatabaseValidationMessage
    {
        get
        {
            if(!IncludeInitialObjectPermissions)return "";
            if(IsLoadingCreateUserDatabases)return "Espere mientras se cargan las bases de datos.";
            if(HasCreateUserDatabaseError)return _createUserDatabaseError;
            var database=SelectedCreateUserObjectDatabase;
            if(database is null)return "Seleccione la base de datos donde desea asignar los permisos.";
            if(!CreateUserObjectDatabaseChoices.Contains(database))return "Seleccione una base de datos de la lista.";
            if(IncludeInitialAccess&&Databases.Count(x=>x.IsSelected)!=1)return "Los permisos a objetos deben aplicarse en la misma base de datos seleccionada en el paso anterior.";
            return "";
        }
    }
    public bool CanAddCreateUserObjects=>IsCreateLoginOperation&&IncludeInitialObjectPermissions
        &&CreateUserObjectDatabaseValidationMessage.Length==0&&!IsLoadingCreateUserObjects;
    private string CreateUserObjectsValidationMessage
    {
        get
        {
            if(!IncludeInitialObjectPermissions)return "";
            if(CreateUserObjectDatabaseValidationMessage.Length>0)return CreateUserObjectDatabaseValidationMessage;
            if(IsLoadingCreateUserObjects)return "Espere mientras se cargan los objetos.";
            var database=SelectedCreateUserObjectDatabase!;
            if(CreateUserObjectRows.Any(x=>x.Item.ServerId!=database.ServerId||!x.Item.Database.Equals(database.Name,StringComparison.OrdinalIgnoreCase)))
                return "La base de datos cambió. Agregue nuevamente los objetos que necesita.";
            if(!CreateUserObjectRows.Any(x=>x.SelectedPermissions.Any()))return "Agregue al menos un objeto y seleccione uno de sus permisos. Si no necesita este acceso, vuelva al primer paso y desmarque la opción.";
            var allowed=AllowedCreateUserObjectPermissions();
            if(CreateUserObjectRows.Any(x=>x.SelectedPermissions.Any(p=>!allowed.Contains(p)||!x.Item.SupportsPermission(p))))
                return "Uno de los permisos seleccionados ya no está disponible. Revise las opciones marcadas.";
            return "";
        }
    }
    public string CreateUserStepValidationMessage=>!IsCreateLoginOperation?"":CreateUserStep switch
    {
        2=>CreateUserMappingValidationMessage,
        3=>CreateUserObjectsValidationMessage,
        _=>CreateUserAccountValidationMessage
    };
    public bool CanSubmitCreateUserWizard=>!IsCreateLoginOperation||IsCreateUserFinalStep
        &&CreateUserAccountValidationMessage.Length==0&&CreateUserMappingValidationMessage.Length==0&&CreateUserObjectsValidationMessage.Length==0;

    private void InitializeCreateUserWizard()
    {
        PropertyChanged+=(_,args)=>
        {
            if(args.PropertyName is nameof(TargetPrincipal) or nameof(Justification) or nameof(ExternalTicketDigits)
                or nameof(TemporaryPassword) or nameof(TemporaryPasswordConfirmation) or nameof(IsCreateLoginTargetAvailable)
                or nameof(CanUseValidatedWindowsName) or nameof(AuthenticationType) or nameof(SelectedOperation))RefreshCreateUserWizard();
        };
        Databases.CollectionChanged+=(_,args)=>
        {
            if(args.OldItems is not null)foreach(DatabaseItem item in args.OldItems)item.PropertyChanged-=CreateUserDatabaseChanged;
            if(args.NewItems is not null)foreach(DatabaseItem item in args.NewItems)item.PropertyChanged+=CreateUserDatabaseChanged;
            if(IsCreateLoginOperation){SynchronizeCreateUserObjectDatabase();RefreshCreateUserWizard();}
        };
    }
    private void CreateUserDatabaseChanged(object? sender,PropertyChangedEventArgs args)
    {
        if(!IsCreateLoginOperation||args.PropertyName!=nameof(DatabaseItem.IsSelected))return;
        SynchronizeCreateUserObjectDatabase();RefreshCreateUserScopedChoices();Decision=null;RefreshCreateUserWizard();
    }
    private void SynchronizeCreateUserObjectDatabase()
    {
        var choices=Databases.Where(x=>x.ServerId==SelectedWorkingServer?.Id&&(!IncludeInitialAccess||x.IsSelected)).ToList();
        foreach(var stale in CreateUserObjectDatabaseChoices.Except(choices).ToList())CreateUserObjectDatabaseChoices.Remove(stale);
        foreach(var database in choices.Except(CreateUserObjectDatabaseChoices))CreateUserObjectDatabaseChoices.Add(database);
        if(!IncludeInitialObjectPermissions)return;
        if(IncludeInitialAccess&&choices.Count==1)SelectedCreateUserObjectDatabase=choices[0];
        else if(SelectedCreateUserObjectDatabase is not null&&!choices.Contains(SelectedCreateUserObjectDatabase))SelectedCreateUserObjectDatabase=null;
        Raise(nameof(CreateUserObjectDatabaseChoices));
    }
    private void CreateUserAccessOptionsChanged()
    {
        if(HasCreateUserDatabaseAccess)
        {
            if(!_createUserDatabasesLoaded&&!IsLoadingCreateUserDatabases)_=LoadCreateUserDatabasesAsync();
        }
        else
        {
            _createUserDatabaseVersion++;_isLoadingCreateUserDatabases=false;_createUserDatabaseError="";_createUserDatabasesLoaded=false;
        }
        RefreshCreateUserWizard();
    }
    private void CreateUserObjectChanged(object? sender,PropertyChangedEventArgs args)
    {Decision=null;RefreshCreateUserWizard();}
    private void ClearCreateUserObjects()
    {
        _createUserObjectVersion++;
        foreach(var row in CreateUserObjectRows)row.PropertyChanged-=CreateUserObjectChanged;
        CreateUserObjectRows.Clear();SelectedCreateUserObjectRow=null;
        _isLoadingCreateUserObjects=false;
    }
    private void ResetCreateUserWizard()
    {
        _createUserStep=1;_includeInitialObjectPermissions=false;_createUserDatabaseVersion++;_createUserPolicies=null;
        _selectedCreateUserObjectDatabase=null;_createUserDatabasesLoaded=false;
        _isLoadingCreateUserDatabases=false;_createUserDatabaseError="";ClearCreateUserObjects();
        Raise(nameof(IncludeInitialObjectPermissions));Raise(nameof(SelectedCreateUserObjectDatabase));RefreshCreateUserWizard();
    }
    private void RefreshCreateUserWizard()
    {
        foreach(var name in new[]{nameof(CreateUserStep),nameof(IsCreateUserAccountStep),nameof(IsCreateUserMappingStep),nameof(IsCreateUserObjectsStep),nameof(ShowCreateUserContext),
            nameof(IsLegacyStandardAccessOperation),nameof(ShowAuthenticationCard),nameof(ShowIdentityCard),nameof(ShowPasswordCard),nameof(ShowTicketCard),nameof(ShowRequestAccessCard),
            nameof(CreateUserTitle),nameof(CreateUserStepTitle),nameof(CreateUserContextSummary),nameof(CreateUserMappingStepHint),nameof(CreateUserObjectsStepHint),
            nameof(IsCreateUserFinalStep),nameof(ShowCreateUserNextButton),nameof(CreateUserStepValidationMessage),nameof(CanSubmitCreateUserWizard),
            nameof(IsLoadingCreateUserDatabases),nameof(IsLoadingCreateUserObjects),nameof(HasCreateUserDatabaseError),nameof(CreateUserDatabaseMessage),
            nameof(CreateUserObjectDatabase),nameof(CreateUserObjectSummary),nameof(CreateUserObjectDatabaseChoices),nameof(CanAddCreateUserObjects),
            nameof(HasCreateUserDatabaseAccess),nameof(CreateUserObjectsStepNumber),nameof(CreateUserObjectsStepLabel)})Raise(name);
        _createUserNextCommand?.Refresh();_createUserPreviousCommand?.Refresh();_removeCreateUserObjectCommand?.Refresh();SubmitCommand?.Refresh();
    }
    private async Task LoadCreateUserDatabasesAsync()
    {
        var server=SelectedWorkingServer;
        if(server is null)return;
        var version=++_createUserDatabaseVersion;
        _createUserDatabasesLoaded=false;
        _isLoadingCreateUserDatabases=true;_createUserDatabaseError="";RefreshCreateUserWizard();
        try
        {
            var databases=await _direct.GetDatabasesAsync([server]);
            if(version!=_createUserDatabaseVersion||SelectedWorkingServer?.Id!=server.Id||!IsCreateLoginOperation||!HasCreateUserDatabaseAccess)return;
            var policies=new Dictionary<string,(IReadOnlyList<PolicyPermission>,IReadOnlyList<PolicyRole>)>(StringComparer.Ordinal);
            var blocks=await _db.GetDenyRulesAsync();
            foreach(var database in databases)
            {
                var context=new PolicyContext(database.ServerId,database.Name);
                var permissions=await _db.GetPolicyPermissionsAsync(context);
                var roles=await _db.GetPolicyRolesAsync(context);
                policies.Add(database.Name,(permissions.Where(x=>PolicyEditorCatalog.CanUsePermission(x,blocks)).ToList(),
                    roles.Where(x=>x.RoleScope=="DATABASE"&&PolicyEditorCatalog.CanUseRole(x,blocks)).ToList()));
                if(version!=_createUserDatabaseVersion)return;
            }
            if(version!=_createUserDatabaseVersion||SelectedWorkingServer?.Id!=server.Id)return;
            _createUserPolicies=policies;
            Databases.Clear();foreach(var database in databases)Databases.Add(database);
            RefreshCreateUserScopedChoices();
            _createUserDatabasesLoaded=true;
            Status=$"{Databases.Count} bases disponibles en {server.Name}.";
        }
        catch(Exception error)
        {
            if(version==_createUserDatabaseVersion){_createUserDatabaseError=error.Message;Status=error.Message;}
        }
        finally
        {
            if(version==_createUserDatabaseVersion){_isLoadingCreateUserDatabases=false;RefreshCreateUserWizard();}
        }
    }
    private void RefreshCreateUserScopedChoices()
    {
        if(_createUserPolicies is null)return;
        var selectedRoles=InitialAccessRoleChoices.Where(x=>x.IsSelected).Select(x=>x.Name).ToHashSet(StringComparer.Ordinal);
        var selectedPermissions=InitialAccessPermissionChoices.Where(x=>x.IsSelected).Select(x=>x.Name).ToHashSet(StringComparer.Ordinal);
        var targets=IncludeInitialAccess?Databases.Where(x=>x.IsSelected).ToList()
            :SelectedCreateUserObjectDatabase is { } database?new List<DatabaseItem>{database}:[];
        var policies=targets.Select(x=>_createUserPolicies[x.Name]).ToList();
        Permissions.Clear();Roles.Clear();
        if(policies.Count>0)
        {
            foreach(var permission in policies[0].Permissions.Where(x=>policies.All(p=>p.Permissions.Any(r=>r.Permission==x.Permission&&r.Scope==x.Scope))))
                Permissions.Add(permission with{AllowGrant=policies.All(p=>p.Permissions.Any(r=>r.Permission==permission.Permission&&r.Scope==permission.Scope&&r.AllowGrant))});
            foreach(var role in policies[0].Roles.Where(x=>policies.All(p=>p.Roles.Any(r=>r.Name==x.Name))))Roles.Add(role);
        }
        RefreshInitialAccessPermissions();RefreshInitialAccessRoles();
        foreach(var role in InitialAccessRoleChoices)role.IsSelected=selectedRoles.Contains(role.Name);
        foreach(var permission in InitialAccessPermissionChoices)permission.IsSelected=selectedPermissions.Contains(permission.Name);
    }
    private HashSet<string> AllowedCreateUserObjectPermissions()=>(_createUserPolicies is not null && SelectedCreateUserObjectDatabase is { } database && _createUserPolicies.TryGetValue(database.Name,out var policy)?policy.Permissions:Permissions)
        .Where(x=>x.Enabled&&x.Scope=="OBJECT"&&x.AllowGrant&&ManagedDataPermissions.Contains(x.Permission))
        .Select(x=>x.Permission).ToHashSet(StringComparer.OrdinalIgnoreCase);

    public async Task<IReadOnlyList<DatabaseObjectItem>> LoadCreateUserObjectsAsync()
    {
        if(!CanAddCreateUserObjects){Status=CreateUserObjectDatabaseValidationMessage;return [];}
        var database=SelectedCreateUserObjectDatabase!;
        var version=++_createUserObjectVersion;
        _isLoadingCreateUserObjects=true;RefreshCreateUserWizard();
        try
        {
            var objects=await _direct.GetDatabaseObjectsAsync(database);
            if(version!=_createUserObjectVersion||!IsCreateLoginOperation||!IncludeInitialObjectPermissions
                ||SelectedWorkingServer?.Id!=database.ServerId||!ReferenceEquals(SelectedCreateUserObjectDatabase,database))return [];
            Status=$"{objects.Count} objetos disponibles en {database.Name}.";
            return objects;
        }
        catch(Exception error){if(version==_createUserObjectVersion)Status=error.Message;return [];}
        finally{if(version==_createUserObjectVersion){_isLoadingCreateUserObjects=false;RefreshCreateUserWizard();}}
    }
    public void ApplyCreateUserObjects(IEnumerable<DatabaseObjectItem> selected)
    {
        if(!IsCreateLoginOperation||!IncludeInitialObjectPermissions||CreateUserObjectDatabaseValidationMessage.Length>0)return;
        var database=SelectedCreateUserObjectDatabase!;
        var objects=selected.ToList();
        if(objects.Any(x=>x.ServerId!=database.ServerId||!x.Database.Equals(database.Name,StringComparison.OrdinalIgnoreCase)))
        {Status="La base de datos cambió. Seleccione nuevamente los objetos.";return;}
        var retained=CreateUserObjectRows.ToDictionary(x=>x.Item);
        ClearCreateUserObjects();
        foreach(var item in objects.Distinct().OrderBy(x=>x.Schema).ThenBy(x=>x.Name))
        {
            var row=retained.GetValueOrDefault(item)??new ObjectPermissionRow(item,AllowedCreateUserObjectPermissions());
            row.PropertyChanged+=CreateUserObjectChanged;CreateUserObjectRows.Add(row);
        }
        Decision=null;RefreshCreateUserWizard();
    }
}
