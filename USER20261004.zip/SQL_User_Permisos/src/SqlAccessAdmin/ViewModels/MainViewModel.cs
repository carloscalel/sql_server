using System.Collections.ObjectModel;
using System.Data;
using System.Security.Cryptography;
using System.Windows;
using System.Windows.Threading;
using SqlAccessAdmin.Data;
using SqlAccessAdmin.Infrastructure;
using SqlAccessAdmin.Models;
using SqlAccessAdmin.Security;
using SqlAccessAdmin.Views;

namespace SqlAccessAdmin.ViewModels;

public sealed class MainViewModel : BindableBase
{
    private readonly AdminDbGateway _db;
    private readonly DirectSqlServerService _direct;
    private object? _current;
    private string _title="Resumen";
    public SessionContext Session {get;}
    public object? Current {get=>_current;private set=>Set(ref _current,value);}
    public string Title {get=>_title;private set=>Set(ref _title,value);}
    public RelayCommand DashboardCommand {get;}
    public RelayCommand ServersCommand {get;}
    public RelayCommand AccessCommand {get;}
    public RelayCommand RequestHistoryCommand {get;}
    public RelayCommand UsersCommand {get;}
    public RelayCommand AuditCommand {get;}
    public RelayCommand PolicyCommand {get;}
    public bool CanAdmin=>Session.Role==AppRole.Administrator;
    public bool CanOperate=>Session.Role!=AppRole.Auditor;

    public MainViewModel(AdminDbGateway db,SessionContext session)
    {
        _db=db;_direct=new(db);Session=session;
        DashboardCommand=new(()=>Navigate("Resumen",()=>new DashboardViewModel(db,session)));
        ServersCommand=new(()=>Navigate("Servidores",()=>new ServersViewModel(db,_direct)),()=>CanAdmin);
        AccessCommand=new(()=>Navigate("Administrar accesos",()=>new AccessViewModel(db,_direct)),()=>CanOperate);
        RequestHistoryCommand=new(()=>Navigate("Historial de solicitudes",()=>new RequestHistoryViewModel(db)),()=>CanOperate);
        UsersCommand=new(()=>Navigate("Usuarios autorizados",()=>new UsersViewModel(db)),()=>CanAdmin);
        AuditCommand=new(()=>Navigate("Auditoría",()=>new AuditViewModel(db)));
        PolicyCommand=new(()=>Navigate("Política de acceso",()=>new PolicyViewModel(db,session,discovery:_direct)),()=>CanAdmin);
        DashboardCommand.Execute(null);
    }
    private void Navigate(string title,Func<object> createViewModel)
    {
        if(Current is PolicyViewModel policy&&!policy.ConfirmLeave())return;
        Title=title;Current=createViewModel();
    }
}

public sealed class RequestHistoryViewModel : BindableBase
{
    private readonly AdminDbGateway _db;
    private readonly List<AccessRequestItem> _allRequests=[];
    private ServerItem? _selectedServer;
    private string _status="Seleccione un servidor para consultar sus solicitudes finalizadas.";
    private string _requestFilter="";
    public ObservableCollection<ServerItem> Servers {get;}=[];
    public ObservableCollection<AccessRequestItem> Requests {get;}=[];
    public ServerItem? SelectedServer
    {
        get=>_selectedServer;
        set
        {
            if(!Set(ref _selectedServer,value))return;
            Raise(nameof(ServerSummary));
            RefreshCommand.Execute(null);
        }
    }
    public string ServerSummary=>SelectedServer is null
        ? "Ningún servidor seleccionado"
        : $"{SelectedServer.Name} · {SelectedServer.Host}{(string.IsNullOrWhiteSpace(SelectedServer.Instance)?"":$"\\{SelectedServer.Instance}")}";
    public string Status {get=>_status;private set=>Set(ref _status,value);}
    public string RequestFilter {get=>_requestFilter;set{if(Set(ref _requestFilter,value))ApplyRequestFilter();}}
    public AsyncCommand RefreshCommand {get;}

    public RequestHistoryViewModel(AdminDbGateway db)
    {
        _db=db;
        RefreshCommand=new(LoadAsync);
        _=InitializeAsync();
    }

    private async Task InitializeAsync()
    {
        try
        {
            foreach(var server in await _db.GetServersAsync())if(server.Active)Servers.Add(server);
            SelectedServer=Servers.FirstOrDefault();
            if(SelectedServer is null)Status="No hay servidores activos disponibles.";
        }
        catch(Exception ex){Status=ex.Message;}
    }

    private async Task LoadAsync()
    {
        Requests.Clear();_allRequests.Clear();
        if(SelectedServer is null)return;
        try
        {
            foreach(var request in (await _db.GetRequestsAsync(serverId:SelectedServer.Id)).OrderByDescending(x=>x.Id))
            {
                if(request.Status is "PENDING" or "APPROVED")continue;
                var targets=await _db.GetRequestTargetsAsync(request.Id);
                if(targets.Select(x=>x.ServerId).Distinct().Any(id=>id!=SelectedServer.Id))continue;
                _allRequests.Add(request with{DestinationSummary=string.Join(", ",targets.Select(x=>$"{x.Server} / {x.Name}"))});
            }
            ApplyRequestFilter();
        }
        catch(Exception ex){Status=ex.Message;}
    }
    private void ApplyRequestFilter()
    {
        Requests.Clear();
        var filter=RequestFilter.Trim();
        foreach(var request in _allRequests.Where(x=>string.IsNullOrWhiteSpace(filter)
            ||x.ExternalTicketNumber.Contains(filter,StringComparison.OrdinalIgnoreCase)
            ||x.TargetPrincipal.Contains(filter,StringComparison.OrdinalIgnoreCase)
            ||x.Operation.Contains(filter,StringComparison.OrdinalIgnoreCase)))Requests.Add(request);
        Status=SelectedServer is null?"Seleccione un servidor.":$"{Requests.Count} de {_allRequests.Count} solicitud(es) finalizada(s) en {SelectedServer.Name}.";
    }
}

public sealed class DashboardViewModel : BindableBase
{
    private int _servers,_users;
    public int Servers {get=>_servers;private set=>Set(ref _servers,value);}
    public int Users {get=>_users;private set=>Set(ref _users,value);}
    public SessionContext Session {get;}
    public AsyncCommand RefreshCommand {get;}
    public DashboardViewModel(AdminDbGateway db,SessionContext session){Session=session;RefreshCommand=new(async()=>{Servers=(await db.GetServersAsync()).Count;Users=(await db.GetUsersAsync()).Count;});RefreshCommand.Execute(null);}
}

public sealed class ServersViewModel : BindableBase
{
    private readonly AdminDbGateway _db;
    private readonly DirectSqlServerService _direct;
    private string _filter="",_status="";
    private ServerItem? _selected;
    public ObservableCollection<ServerItem> Servers {get;}=[];
    public string Filter {get=>_filter;set{if(Set(ref _filter,value))Raise(nameof(Filtered));}}
    public string Status {get=>_status;set=>Set(ref _status,value);}
    public ServerItem? Selected
    {
        get=>_selected;
        set
        {
            if(!Set(ref _selected,value))return;
            EditCommand.Refresh();TestCommand.Refresh();RemoveCommand.Refresh();
        }
    }
    public IEnumerable<ServerItem> Filtered=>Servers.Where(x=>string.IsNullOrWhiteSpace(Filter)||x.Name.Contains(Filter,StringComparison.OrdinalIgnoreCase)||x.Host.Contains(Filter,StringComparison.OrdinalIgnoreCase)||x.Instance.Contains(Filter,StringComparison.OrdinalIgnoreCase)||x.SqlUser.Contains(Filter,StringComparison.OrdinalIgnoreCase));
    public AsyncCommand RefreshCommand {get;}
    public RelayCommand AddCommand {get;}
    public RelayCommand EditCommand {get;}
    public AsyncCommand TestCommand {get;}
    public AsyncCommand RemoveCommand {get;}

    public ServersViewModel(AdminDbGateway db,DirectSqlServerService direct)
    {
        _db=db;_direct=direct;
        RefreshCommand=new(LoadAsync);
        AddCommand=new(()=>OpenEditor(null));
        EditCommand=new(()=>OpenEditor(Selected),()=>Selected is not null);
        TestCommand=new(TestAsync,()=>Selected is not null);
        RemoveCommand=new(RemoveAsync,()=>Selected is not null);
        RefreshCommand.Execute(null);
    }
    private async Task LoadAsync()
    {
        try{var items=await _db.GetServersAsync();Servers.Clear();foreach(var x in items)Servers.Add(x);Raise(nameof(Filtered));Status=$"{Servers.Count} servidor(es) registrado(s).";}
        catch(Exception ex){Status=$"No fue posible actualizar el listado: {ex.Message}";}
    }
    private void OpenEditor(ServerItem? item){var window=new ServerEditorWindow(_db,_direct,item){Owner=Application.Current.Windows.OfType<MainWindow>().FirstOrDefault()};if(window.ShowDialog()==true)RefreshCommand.Execute(null);}
    private async Task TestAsync(){try{Status="Probando conexión directa…";await _direct.TestAsync(Selected!.Id);Status=$"Conexión correcta con {Selected.Name}.";}catch(Exception ex){Status=$"Error de conexión: {ex.Message}";}}
    private async Task RemoveAsync(){if(MessageBox.Show($"¿Deshabilitar el servidor {Selected!.Name}?","Confirmar",MessageBoxButton.YesNo,MessageBoxImage.Question)!=MessageBoxResult.Yes)return;await _db.SetServerActiveAsync(Selected.Id,false);await LoadAsync();}
    public async Task ChangeActiveAsync(ServerItem server)
    {
        var requested=server.Active;
        try{Status=$"{(requested?"Habilitando":"Deshabilitando")} {server.Name}…";await _db.SetServerActiveAsync(server.Id,requested);Status=$"Servidor {server.Name} {(requested?"habilitado":"deshabilitado")}.";}
        catch(Exception ex){server.Active=!requested;Status=$"No fue posible cambiar el estado: {ex.Message}";}
    }
}

public sealed class UsersViewModel : BindableBase
{
    private readonly AdminDbGateway _db;public ObservableCollection<AuthorizedUser> Users {get;}=[];public AsyncCommand RefreshCommand {get;}
    public UsersViewModel(AdminDbGateway db){_db=db;RefreshCommand=new(LoadAsync);RefreshCommand.Execute(null);}
    private async Task LoadAsync(){Users.Clear();foreach(var x in await _db.GetUsersAsync())Users.Add(x);}
}

public sealed class AuditViewModel : BindableBase
{
    private readonly AdminDbGateway _db;private string _filter="",_integrityStatus="Integridad no validada.";public ObservableCollection<AuditEvent> Events {get;}=[];public string Filter {get=>_filter;set=>Set(ref _filter,value);}public string IntegrityStatus{get=>_integrityStatus;set=>Set(ref _integrityStatus,value);}public AsyncCommand RefreshCommand {get;}public AsyncCommand ValidateIntegrityCommand{get;}
    public AuditViewModel(AdminDbGateway db){_db=db;RefreshCommand=new(LoadAsync);ValidateIntegrityCommand=new(ValidateAsync);RefreshCommand.Execute(null);}
    private async Task LoadAsync(){Events.Clear();foreach(var x in await _db.GetAuditAsync(Filter))Events.Add(x);}
    private async Task ValidateAsync(){try{var x=await _db.ValidateAuditIntegrityAsync();IntegrityStatus=x.IsValid?$"Cadena íntegra: {x.HashedEvents} eventos verificados.":$"ALERTA: {x.BrokenLinks} enlaces rotos y {x.AlteredEvents} eventos alterados.";}catch(Exception ex){IntegrityStatus=ex.Message;}}
}

public sealed partial class AccessViewModel : BindableBase
{
    private static readonly HashSet<string> SupportedRequestOperations=new(StringComparer.OrdinalIgnoreCase)
    {
        "CREATE_SQL_LOGIN","CREATE_WINDOWS_LOGIN","MODIFY_LOGIN","ENABLE_LOGIN","DISABLE_LOGIN",
        "CREATE_DB_USER","PERMISSION_CHANGE","ADD_ROLE_MEMBER","REMOVE_ROLE_MEMBER","CLONE_PERMISSIONS",
        "SERVER_PERMISSION_CHANGE","ADD_SERVER_ROLE_MEMBER","REMOVE_SERVER_ROLE_MEMBER"
    };
    private static readonly HashSet<string> ManagedDataPermissions=new(StringComparer.OrdinalIgnoreCase)
    {"SELECT","INSERT","UPDATE","DELETE","EXECUTE","REFERENCES"};
    private readonly AdminDbGateway _db;
    private readonly DirectSqlServerService _direct;
    private readonly List<AccessRequestItem> _allActiveRequests=[];
    private string _status="Seleccione servidores y cargue sus bases.",_targetPrincipal="",_sourcePrincipal="",_authenticationType="WINDOWS",_permissionAction="GRANT",_scope="OBJECT",_securable="",_justification="",_externalTicketDigits="",_requestFilter="",_approvalComment="",_executionPassword="",_temporaryPassword="",_temporaryPasswordConfirmation="",_suggestedPasswordLengthText="20",_loginSearchText="",_selectedLoginTypeFilter="Todos los tipos",_objectPermissionSearch="",_selectedObjectSchemaFilter="Todos",_selectedObjectTypeFilter="Todos";
    private ServerItem? _inventoryServer;
    private ServerItem? _selectedWorkingServer;
    private string? _inventoryDatabase,_inventoryType="LOGINS";
    private DataView? _inventory;
    private PolicyOperation? _operation;
    private PolicyPermission? _permission;
    private PolicyRole? _role;
    private DatabaseItem? _selectedMappingDatabase;
    private CancellationTokenSource? _databaseContextCancellation;
    private bool _isSwitchingExistingAccessOperation,_databaseRolesLoaded,_objectPermissionsLoaded,_isLoadingDatabaseAccess,_hasDatabaseAccessError,_isVerifyingExternalTicket;
    private ExternalTicketDetails? _verifiedExternalTicket;
    private string _externalTicketValidationMessage="Ingrese el identificador completo y pulse Validar ticket.";
    private string _databaseAccessMessage="Seleccione una base de datos para comenzar.";
    private DatabaseObjectItem? _selectedDatabaseObject;
    private PolicyDecision? _decision;
    private AccessRequestItem? _selectedRequest;
    private SecurityTreeNode? _selectedSecurityNode;
    private ServerLoginItem? _selectedServerLogin;
    private bool _isManagingAccess;
    private bool _isStartingAccessManagement;
    private bool? _selectedLoginEnabled;
    private bool _selectedUserLoginCheckCompleted;
    private MappedLoginState? _selectedUserMappedLogin;
    private bool _requestSubmitted;
    private bool _includeInitialAccess;
    private int _selectedAccessStep;
    private bool _passwordPolicyEnabled=true;
    private bool _passwordExpirationEnabled=true;
    private bool _mustChangePassword=true;
    private string _securitySelectionTitle="Seleccione un login o usuario";
    private string _securitySelectionSubtitle="Expanda un servidor para consultar su seguridad.";
    private string _securitySelectionType="SIN SELECCIÓN";
    private string _securitySummary="Los permisos y las membresías aparecerán en este panel.";
    private string _securityFilter="";
    private string _securityFilterHint="Sin filtro · la consulta es de solo lectura.";
    private string _roleChoicesHint="Seleccione una base de datos para consultar sus roles permitidos.";
    public ObservableCollection<ServerItem> Servers {get;}=[];
    public ObservableCollection<DatabaseItem> Databases {get;}=[];
    public ObservableCollection<string> InventoryDatabases {get;}=[];
    public ObservableCollection<PolicyOperation> Operations {get;}=[];
    public ObservableCollection<PolicyPermission> Permissions {get;}=[];
    public ObservableCollection<PolicyPermission> AvailablePermissions {get;}=[];
    public ObservableCollection<DatabaseObjectItem> DatabaseObjects {get;}=[];
    public ObservableCollection<DatabaseObjectItem> SelectedDatabaseObjects {get;}=[];
    public ObservableCollection<PolicyRole> Roles {get;}=[];
    public ObservableCollection<RoleSelectionItem> RoleChoices {get;}=[];
    public ObservableCollection<DatabaseRoleSelectionItem> DatabaseRoleChoices {get;}=[];
    public ObservableCollection<RoleSelectionItem> InitialAccessRoleChoices {get;}=[];
    public ObservableCollection<PermissionSelectionItem> PermissionChoices {get;}=[];
    public ObservableCollection<PermissionSelectionItem> InitialAccessPermissionChoices {get;}=[];
    public ObservableCollection<AccessRequestItem> Requests {get;}=[];
    public ObservableCollection<OperationResult> Results {get;}=[];
    public ObservableCollection<SecurityTreeNode> SecurityRoots {get;}=[];
    public ObservableCollection<SecurityPermissionItem> SecurityPermissions {get;}=[];
    public ObservableCollection<SecurityMembershipItem> SecurityMemberships {get;}=[];
    public ObservableCollection<ServerLoginItem> ServerLogins {get;}=[];
    public ObservableCollection<ServerLoginItem> FilteredServerLogins {get;}=[];
    public ObservableCollection<ObjectPermissionRow> ObjectPermissionRows {get;}=[];
    public ObservableCollection<ObjectPermissionRow> FilteredObjectPermissionRows {get;}=[];
    public ObservableCollection<string> ObjectSchemaFilters {get;}=["Todos"];
    public ObservableCollection<string> ObjectTypeFilters {get;}=["Todos"];
    public string[] InventoryTypes {get;}=["LOGINS","USERS","PERMISSIONS"];
    public string[] LoginTypeFilters {get;}=["Todos los tipos","SQL_LOGIN","WINDOWS_LOGIN","WINDOWS_GROUP"];
    public string[] AuthenticationTypes {get;}=["WINDOWS","SQL"];
    public string[] PermissionActions {get;}=["GRANT","DENY","REVOKE"];
    private static readonly string[] DatabasePermissionScopes=SqlPermissionSafety.Scopes.Where(x=>!x.IsServer).Select(x=>x.Code).ToArray();
    private static readonly string[] ServerPermissionScopes=SqlPermissionSafety.Scopes.Where(x=>x.IsServer).Select(x=>x.Code).ToArray();
    public string[] Scopes=>IsServerAccessOperation?ServerPermissionScopes:DatabasePermissionScopes;
    public bool IsAdditionalPermissionScope=>SqlPermissionSafety.Scope(Scope)?.IsServer==false;
    public bool IsAdditionalPermissionTarget=>SqlPermissionSafety.Scope(Scope)?.Parts>0;
    public string Status {get=>_status;set=>Set(ref _status,value);}
    public ServerItem? SelectedWorkingServer
    {
        get=>_selectedWorkingServer;
        set{if(Set(ref _selectedWorkingServer,value))OnWorkingServerChanged();}
    }
    public bool HasWorkingServer=>SelectedWorkingServer is not null;
    public string LoginSearchText {get=>_loginSearchText;set{if(Set(ref _loginSearchText,value))ApplyServerLoginFilter();}}
    public string SelectedLoginTypeFilter {get=>_selectedLoginTypeFilter;set{if(Set(ref _selectedLoginTypeFilter,value))ApplyServerLoginFilter();}}
    public ServerLoginItem? SelectedServerLogin
    {
        get=>_selectedServerLogin;
        set
        {
            if(!Set(ref _selectedServerLogin,value))return;
            Raise(nameof(SelectedServerLoginSummary));Raise(nameof(SelectedServerLoginActionHint));
            LoadSelectedLoginCommand?.Refresh();
            _serverPermissionsCommand?.Refresh();_assignServerRoleCommand?.Refresh();_removeServerRoleCommand?.Refresh();
        }
    }
    public string SelectedServerLoginSummary=>SelectedServerLogin?.Name??"Ninguno (haga clic en la lista)";
    public string SelectedServerLoginActionHint=>SelectedServerLogin is null
        ? "Seleccione primero un login."
        : SelectedServerLogin.Enabled?"Cargar el acceso actual para editarlo.":"Este login está deshabilitado; no se permite gestionar sus accesos de base de datos.";
    public string ObjectPermissionSearch {get=>_objectPermissionSearch;set{if(Set(ref _objectPermissionSearch,value))ApplyObjectPermissionFilter();}}
    public string SelectedObjectSchemaFilter {get=>_selectedObjectSchemaFilter;set{if(Set(ref _selectedObjectSchemaFilter,value))ApplyObjectPermissionFilter();}}
    public string SelectedObjectTypeFilter {get=>_selectedObjectTypeFilter;set{if(Set(ref _selectedObjectTypeFilter,value))ApplyObjectPermissionFilter();}}
    public int ObjectPermissionGrantCount=>ObjectPermissionRows.Sum(x=>x.PermissionChanges.Count());
    public string ObjectPermissionSummary=>ObjectPermissionGrantCount==0?"Los permisos marcados reflejan el estado actual. Modifique una casilla para solicitar un cambio.":$"{ObjectPermissionGrantCount} cambio(s) de permiso directo pendiente(s) en la matriz.";
    public int SelectedAccessStep
    {
        get=>_selectedAccessStep;
        set
        {
            var previousStep=_selectedAccessStep;
            if(!Set(ref _selectedAccessStep,value))return;
            if(previousStep!=value&&IsManagingAccess)
            {
                ResetManagementForm();
                IsManagingAccess=false;
            }
            Raise(nameof(IsModifyAccessStep));Raise(nameof(IsCreateUserStep));
            Raise(nameof(IsCopyPermissionsStep));Raise(nameof(IsConfirmationStep));
            _=PrepareSelectedAccessStepAsync(value);
        }
    }
    public bool IsModifyAccessStep {get=>SelectedAccessStep==0;set{if(value)SelectedAccessStep=0;}}
    public bool IsCreateUserStep {get=>SelectedAccessStep==1;set{if(value)SelectedAccessStep=1;}}
    public bool IsCopyPermissionsStep {get=>SelectedAccessStep==2;set{if(value)SelectedAccessStep=2;}}
    public bool IsConfirmationStep {get=>SelectedAccessStep==3;set{if(value)SelectedAccessStep=3;}}
    public int PendingRequestCount=>_allActiveRequests.Count;
    public string PendingRequestBadge=>PendingRequestCount==1?"1 pendiente":$"{PendingRequestCount} pendientes";
    public string WorkingServerSummary=>SelectedWorkingServer is null
        ? "Ningún servidor seleccionado"
        : $"{SelectedWorkingServer.Name} · {SelectedWorkingServer.Host}{(string.IsNullOrWhiteSpace(SelectedWorkingServer.Instance)?"":$"\\{SelectedWorkingServer.Instance}")}";
    public ServerItem? InventoryServer {get=>_inventoryServer;set{if(Set(ref _inventoryServer,value))_=LoadInventoryDatabasesAsync();}}
    public string? InventoryDatabase {get=>_inventoryDatabase;set=>Set(ref _inventoryDatabase,value);}
    public string? InventoryType {get=>_inventoryType;set=>Set(ref _inventoryType,value);}
    public DataView? Inventory {get=>_inventory;set=>Set(ref _inventory,value);}
    public PolicyOperation? SelectedOperation {get=>_operation;set{if(Set(ref _operation,value))OnOperationChanged();}}
    public PolicyPermission? SelectedPermission {get=>_permission;set{if(Set(ref _permission,value))Decision=null;}}
    public PolicyRole? SelectedRole {get=>_role;set{if(Set(ref _role,value))Decision=null;}}
    public DatabaseItem? SelectedMappingDatabase
    {
        get=>_selectedMappingDatabase;
        set
        {
            if(!Set(ref _selectedMappingDatabase,value))return;
            CancelDatabaseContextLoad();
            _databaseRolesLoaded=false;_objectPermissionsLoaded=false;
            foreach(var database in Databases)database.IsSelected=ReferenceEquals(database,value);
            RoleChoices.Clear();
            DatabaseRoleChoices.Clear();
            ObjectPermissionRows.Clear();FilteredObjectPermissionRows.Clear();
            SelectedDatabaseObjects.Clear();DatabaseObjects.Clear();SelectedDatabaseObject=null;
            Securable="";
            Decision=null;
            Raise(nameof(HasSelectedMappingDatabase));
            Raise(nameof(ActiveDatabaseText));Raise(nameof(DatabaseRoleChangeCount));Raise(nameof(DatabaseRolesSummary));
            Raise(nameof(ObjectPermissionGrantCount));Raise(nameof(ObjectPermissionSummary));Raise(nameof(PlannedChangesSummary));
            Raise(nameof(SelectedObjectsSummary));
            _=LoadSelectedDatabaseContextAsync();
        }
    }
    public bool HasSelectedMappingDatabase=>SelectedMappingDatabase is not null;
    public string ActiveDatabaseText=>SelectedMappingDatabase?.Name??"Sin seleccionar";
    public bool HasDatabaseAccessEditor=>IsLoginMappingOperation||IsPermissionMatrixOperation;
    public bool IsLoadingDatabaseAccess
    {
        get=>_isLoadingDatabaseAccess;
        private set{if(Set(ref _isLoadingDatabaseAccess,value))RefreshDatabaseAccessState();}
    }
    public bool HasDatabaseAccessError
    {
        get=>_hasDatabaseAccessError;
        private set{if(Set(ref _hasDatabaseAccessError,value))RefreshDatabaseAccessState();}
    }
    public string DatabaseAccessMessage {get=>_databaseAccessMessage;private set=>Set(ref _databaseAccessMessage,value);}
    public bool CanEditDatabaseAccess=>HasSelectedMappingDatabase&&!IsLoadingDatabaseAccess&&!HasDatabaseAccessError
        &&(IsPermissionMatrixOperation?_objectPermissionsLoaded:_databaseRolesLoaded);
    private void RefreshDatabaseAccessState()
    {
        Raise(nameof(CanEditDatabaseAccess));
        PreviewCommand?.Refresh();SubmitCommand?.Refresh();
    }
    public string RoleChoicesHint {get=>_roleChoicesHint;private set=>Set(ref _roleChoicesHint,value);}
    public DatabaseObjectItem? SelectedDatabaseObject {get=>_selectedDatabaseObject;set{if(Set(ref _selectedDatabaseObject,value)){Securable=value?.QualifiedName??"";RefreshAvailablePermissions();}}}
    public string SelectedObjectsSummary=>SelectedDatabaseObjects.Count==0
        ? "Ningún objeto seleccionado"
        : SelectedDatabaseObjects.Count==1?SelectedDatabaseObjects[0].DisplayName:$"{SelectedDatabaseObjects.Count} objetos seleccionados";
    public bool IsDatabaseAccessLevel
    {
        get=>IsPermissionMatrixOperation&&Scope.Equals("DATABASE",StringComparison.OrdinalIgnoreCase);
        set{if(value)Scope="DATABASE";}
    }
    public bool IsObjectScope
    {
        get=>IsPermissionMatrixOperation&&Scope.Equals("OBJECT",StringComparison.OrdinalIgnoreCase);
        set{if(value)Scope="OBJECT";}
    }
    public string PermissionStepTitle=>IsObjectScope?"3. Elija qué acciones se permitirán":"2. Elija qué acciones se permitirán en toda la base";
    public int DatabaseRoleChangeCount=>DatabaseRoleChoices.Count(x=>x.HasChange);
    public string DatabaseRolesSummary
    {
        get
        {
            if(DatabaseRoleChoices.Count==0)return "No se encontraron roles en la base de datos.";
            var allowed=DatabaseRoleChoices.Count(x=>x.IsAllowed);
            var assigned=DatabaseRoleChoices.Count(x=>x.InitiallyAssigned);
            return $"{DatabaseRoleChoices.Count} rol(es) existente(s) · {allowed} autorizado(s) para gestionar · {assigned} asignado(s) actualmente.";
        }
    }
    public string PlannedChangesSummary
    {
        get
        {
            if(HasDatabaseAccessEditor&&ObjectPermissionRows.Count>0)
                return $"Una sola solicitud con {DatabaseRoleChangeCount} cambio(s) de rol, {ObjectPermissionGrantCount} cambio(s) por objeto y {PermissionChoices.Count(x=>x.IsSelected)} permiso(s) adicional(es) en {Scope}.";
            var permissionCount=PermissionChoices.Count(x=>x.IsSelected);
            var roleCount=DatabaseRoleChangeCount;
            if(IsObjectScope&&permissionCount>0)
                return SelectedDatabaseObjects.Count==0
                    ? "Elija uno o varios objetos antes de seleccionar las acciones."
                    : $"{roleCount} cambio(s) de rol y {SelectedDatabaseObjects.Count*permissionCount} permiso(s) directo(s) sobre {SelectedDatabaseObjects.Count} objeto(s).";
            if(roleCount==0&&permissionCount==0)return "Seleccione al menos un cambio de rol o un permiso directo.";
            if(roleCount>0&&permissionCount==0)return $"Una sola solicitud con {roleCount} cambio(s) de membresía de rol.";
            return $"Una sola solicitud con {roleCount} cambio(s) de rol y {permissionCount} permiso(s) directo(s) sobre toda la base {SelectedMappingDatabase?.Name}.";
        }
    }
    public string TargetPrincipal
    {
        get=>_targetPrincipal;
        set
        {
            if(!Set(ref _targetPrincipal,value))return;
            ResetWindowsNameValidation();
            Decision=null;
            if(IsClonePermissionsOperation)_=ValidateCopyTargetAsync();
            else if(IsCreateLoginOperation)_=ValidateCreateLoginTargetAsync();
        }
    }
    public string SourcePrincipal {get=>_sourcePrincipal;set{if(Set(ref _sourcePrincipal,value))Decision=null;}}
    public string AuthenticationType {get=>_authenticationType;set=>ChangeAuthenticationType(value);}
    [System.Diagnostics.CodeAnalysis.AllowNull]
    public string PermissionAction
    {
        get=>_permissionAction;
        set
        {
            // A ComboBox can temporarily clear SelectedItem when it loads or changes ItemsSource.
            // Keep the draft intact until the operator selects an actual action.
            if(string.IsNullOrWhiteSpace(value))return;
            if(Set(ref _permissionAction,value)){RefreshAvailablePermissions();Decision=null;}
        }
    }
    [System.Diagnostics.CodeAnalysis.AllowNull]
    public string Scope
    {
        get=>_scope;
        set
        {
            // Ignore transient empty selections from WPF; Scope must always be non-null.
            if(string.IsNullOrWhiteSpace(value)||!Set(ref _scope,value))return;
            Securable="";
            if(!value.Equals("OBJECT",StringComparison.OrdinalIgnoreCase))
            {
                SelectedDatabaseObject=null;
                SelectedDatabaseObjects.Clear();DatabaseObjects.Clear();
                Raise(nameof(SelectedObjectsSummary));
            }
            RefreshAvailablePermissions();
            Raise(nameof(IsAdditionalPermissionScope));Raise(nameof(IsAdditionalPermissionTarget));
            Raise(nameof(IsDatabaseAccessLevel));Raise(nameof(IsObjectScope));Raise(nameof(PermissionStepTitle));
            Raise(nameof(PlannedChangesSummary));Raise(nameof(RequiresSecurable));Raise(nameof(SecurableLabel));
            Raise(nameof(SecurableHelp));Raise(nameof(OperationBadge));
            Decision=null;
        }
    }
    public string Securable {get=>_securable;set{if(Set(ref _securable,value)){Decision=null;Raise(nameof(PlannedChangesSummary));}}}
    public string Justification {get=>_justification;set{if(Set(ref _justification,value))Decision=null;}}
    public string ExternalTicketDigits
    {
        get=>_externalTicketDigits;
        set
        {
            var ticket=(value??"").TrimStart().ToUpperInvariant();
            if(ticket.Length>50)ticket=ticket[..50];
            if(!Set(ref _externalTicketDigits,ticket))return;
            _verifiedExternalTicket=null;
            ExternalTicketValidationMessage=string.IsNullOrWhiteSpace(ticket)
                ?"Ingrese el identificador completo y pulse Validar ticket."
                :"El ticket todavía no ha sido validado.";
            Raise(nameof(ExternalTicketNumber));Raise(nameof(IsExternalTicketValid));Raise(nameof(VerifiedTicketSummary));Raise(nameof(HasVerifiedTicketDetails));
            VerifyExternalTicketCommand?.Refresh();
            Decision=null;SubmitCommand.Refresh();
        }
    }
    public string ExternalTicketNumber=>_verifiedExternalTicket?.Number??ExternalTicketDigits.Trim();
    public bool IsExternalTicketValid=>_verifiedExternalTicket is not null&&ExternalTicketNumber.Equals(ExternalTicketDigits.Trim(),StringComparison.OrdinalIgnoreCase);
    public bool IsVerifyingExternalTicket{get=>_isVerifyingExternalTicket;private set{if(Set(ref _isVerifyingExternalTicket,value)){VerifyExternalTicketCommand.Refresh();Raise(nameof(CanVerifyExternalTicket));}}}
    public bool CanVerifyExternalTicket=>!IsVerifyingExternalTicket&&!string.IsNullOrWhiteSpace(ExternalTicketDigits);
    public string ExternalTicketValidationMessage{get=>_externalTicketValidationMessage;private set=>Set(ref _externalTicketValidationMessage,value);}
    public bool HasVerifiedTicketDetails=>_verifiedExternalTicket is not null;
    public string VerifiedTicketSummary=>_verifiedExternalTicket?.Summary??"";
    public string RequestFilter {get=>_requestFilter;set{if(Set(ref _requestFilter,value))ApplyActiveRequestFilter();}}
    public PolicyDecision? Decision {get=>_decision;set=>Set(ref _decision,value);}
    public AccessRequestItem? SelectedRequest
    {
        get=>_selectedRequest;
        set
        {
            if(!Set(ref _selectedRequest,value))return;
            ApproveCommand.Refresh();RejectCommand.Refresh();ExecuteApprovedCommand.Refresh();
        }
    }
    public string ApprovalComment {get=>_approvalComment;set=>Set(ref _approvalComment,value);}
    public string ExecutionPassword {get=>_executionPassword;set=>Set(ref _executionPassword,value);}
    public string TemporaryPassword
    {
        get=>_temporaryPassword;
        set{if(Set(ref _temporaryPassword,value)){RaisePasswordValidationState();SubmitCommand.Refresh();}}
    }
    public string TemporaryPasswordConfirmation
    {
        get=>_temporaryPasswordConfirmation;
        set{if(Set(ref _temporaryPasswordConfirmation,value)){RaisePasswordValidationState();SubmitCommand.Refresh();}}
    }
    public string SuggestedPasswordLengthText
    {
        get=>_suggestedPasswordLengthText;
        set
        {
            if(!Set(ref _suggestedPasswordLengthText,value?.Trim()??""))return;
            Raise(nameof(IsSuggestedPasswordLengthValid));
            Raise(nameof(SuggestedPasswordLengthValidationMessage));
        }
    }
    public bool IsSuggestedPasswordLengthValid=>int.TryParse(SuggestedPasswordLengthText,out var length)&&length is >=16 and <=128;
    public string SuggestedPasswordLengthValidationMessage=>IsSuggestedPasswordLengthValid
        ? $"Se generará una contraseña de {SuggestedPasswordLengthText} caracteres."
        : "Indique una longitud entre 16 y 128 caracteres.";
    public bool IsCreateSqlLoginOperation=>SelectedOperation?.Code=="CREATE_SQL_LOGIN";
    public bool RequiresTemporaryPassword=>(IsCreateLoginOperation||IsClonePermissionsOperation)&&IsSqlAuthentication;
    public bool PasswordPolicyEnabled
    {
        get=>_passwordPolicyEnabled;
        set
        {
            if(!Set(ref _passwordPolicyEnabled,value))return;
            if(!value){PasswordExpirationEnabled=false;MustChangePassword=false;}
            Raise(nameof(CanEnablePasswordExpiration));Raise(nameof(CanRequirePasswordChange));Raise(nameof(HasReducedPasswordSecurity));Raise(nameof(PasswordConfigurationWarning));Raise(nameof(TemporaryPasswordValidationMessage));Decision=null;
        }
    }
    public bool PasswordExpirationEnabled
    {
        get=>_passwordExpirationEnabled;
        set
        {
            if(value&&!PasswordPolicyEnabled)return;
            if(!Set(ref _passwordExpirationEnabled,value))return;
            if(!value)MustChangePassword=false;
            Raise(nameof(CanRequirePasswordChange));Raise(nameof(HasReducedPasswordSecurity));Raise(nameof(PasswordConfigurationWarning));Raise(nameof(TemporaryPasswordValidationMessage));Decision=null;
        }
    }
    public bool MustChangePassword
    {
        get=>_mustChangePassword;
        set{if(value&&!CanRequirePasswordChange)return;if(Set(ref _mustChangePassword,value)){Raise(nameof(HasReducedPasswordSecurity));Raise(nameof(PasswordConfigurationWarning));Raise(nameof(TemporaryPasswordValidationMessage));Decision=null;}}
    }
    public bool CanEnablePasswordExpiration=>PasswordPolicyEnabled;
    public bool CanRequirePasswordChange=>PasswordPolicyEnabled&&PasswordExpirationEnabled;
    public bool HasReducedPasswordSecurity=>!PasswordPolicyEnabled||!PasswordExpirationEnabled||!MustChangePassword;
    public string PasswordConfigurationWarning
    {
        get
        {
            var disabled=new List<string>();
            if(!PasswordPolicyEnabled)disabled.Add("política de contraseñas");
            if(!PasswordExpirationEnabled)disabled.Add("expiración");
            if(!MustChangePassword)disabled.Add("cambio obligatorio en el próximo login");
            return disabled.Count==0?"":$"Opciones desactivadas: {string.Join(", ",disabled)}. Puede continuar, pero se guardará esta configuración en el historial.";
        }
    }
    public event Action? TemporaryPasswordCleared;
    public bool PasswordMeetsComplexity=>TemporaryPassword.Length>=16
        &&TemporaryPassword.Any(char.IsUpper)&&TemporaryPassword.Any(char.IsLower)&&TemporaryPassword.Any(char.IsDigit)
        &&TemporaryPassword.Any(character=>!char.IsLetterOrDigit(character));
    public bool HasPasswordMismatch=>TemporaryPasswordConfirmation.Length>0&&!string.Equals(TemporaryPassword,TemporaryPasswordConfirmation,StringComparison.Ordinal);
    public bool IsPasswordConfirmationMissing=>TemporaryPassword.Length>0&&TemporaryPasswordConfirmation.Length==0;
    public bool IsTemporaryPasswordValid=>!RequiresTemporaryPassword||PasswordMeetsComplexity
        &&string.Equals(TemporaryPassword,TemporaryPasswordConfirmation,StringComparison.Ordinal);
    public string TemporaryPasswordValidationMessage=>IsTemporaryPasswordValid
        ? "✓ La contraseña cumple los requisitos y ambas entradas coinciden."
        : HasPasswordMismatch
            ? "Las contraseñas no coinciden. Corrija la confirmación para que sea exactamente igual a la contraseña temporal."
            : IsPasswordConfirmationMissing
                ? "Confirme la contraseña temporal escribiéndola nuevamente en el segundo campo."
                : !PasswordMeetsComplexity&&TemporaryPassword.Length>0
                    ? "La contraseña debe tener al menos 16 caracteres, mayúscula, minúscula, número y símbolo."
                    : "Ingrese y confirme una contraseña temporal segura.";
    public string TemporaryPasswordValidationIcon=>IsTemporaryPasswordValid?"✓":HasPasswordMismatch?"!":"ℹ";
    private void RaisePasswordValidationState()
    {
        Raise(nameof(PasswordMeetsComplexity));Raise(nameof(HasPasswordMismatch));Raise(nameof(IsPasswordConfirmationMissing));
        Raise(nameof(IsTemporaryPasswordValid));Raise(nameof(TemporaryPasswordValidationMessage));Raise(nameof(TemporaryPasswordValidationIcon));
    }
    public string GenerateTemporaryPassword()
    {
        if(!int.TryParse(SuggestedPasswordLengthText,out var requestedLength)||requestedLength is <16 or >128)
            throw new InvalidOperationException("La longitud de la contraseña sugerida debe estar entre 16 y 128 caracteres.");
        const string upper="ABCDEFGHJKLMNPQRSTUVWXYZ",lower="abcdefghijkmnopqrstuvwxyz",digits="23456789",symbols="!@#$%*-_+=?";
        const string all=upper+lower+digits+symbols;
        var chars=new List<char>{upper[RandomNumberGenerator.GetInt32(upper.Length)],lower[RandomNumberGenerator.GetInt32(lower.Length)],digits[RandomNumberGenerator.GetInt32(digits.Length)],symbols[RandomNumberGenerator.GetInt32(symbols.Length)]};
        while(chars.Count<requestedLength)chars.Add(all[RandomNumberGenerator.GetInt32(all.Length)]);
        for(var index=chars.Count-1;index>0;index--){var swap=RandomNumberGenerator.GetInt32(index+1);(chars[index],chars[swap])=(chars[swap],chars[index]);}
        TemporaryPassword=new(chars.ToArray());TemporaryPasswordConfirmation=TemporaryPassword;return TemporaryPassword;
    }
    private void ClearTemporaryPassword()
    {
        TemporaryPassword="";TemporaryPasswordConfirmation="";
        TemporaryPasswordCleared?.Invoke();
    }
    public SecurityTreeNode? SelectedSecurityNode
    {
        get=>_selectedSecurityNode;
        private set
        {
            if(!Set(ref _selectedSecurityNode,value))return;
            _selectedLoginEnabled=null;
            _selectedUserLoginCheckCompleted=false;
            _selectedUserMappedLogin=null;
            Raise(nameof(HasContextualActions));
            Raise(nameof(IsSelectedLogin));
            Raise(nameof(IsSelectedUser));
            Raise(nameof(CanCreateDatabaseUser));
            Raise(nameof(ContextActionTitle));
            Raise(nameof(CanManageSelectedUser));
            Raise(nameof(IsSelectedUserManagementBlocked));
            Raise(nameof(SelectedUserAccessStateText));
            Raise(nameof(CanEnableSelectedLogin));
            Raise(nameof(CanDisableSelectedLogin));
            Raise(nameof(SelectedLoginStateText));
            RefreshContextCommands();
        }
    }
    public bool HasContextualActions=>SelectedSecurityNode?.Kind is SecurityNodeKind.Login or SecurityNodeKind.User or SecurityNodeKind.Database or SecurityNodeKind.UserGroup;
    public bool IsSelectedLogin=>SelectedSecurityNode?.Kind==SecurityNodeKind.Login;
    public bool IsSelectedUser=>SelectedSecurityNode?.Kind==SecurityNodeKind.User;
    public bool CanCreateDatabaseUser=>SelectedSecurityNode?.Kind is SecurityNodeKind.Login or SecurityNodeKind.Database or SecurityNodeKind.UserGroup;
    public bool CanManageSelectedUser=>IsSelectedUser&&_selectedUserLoginCheckCompleted&&_selectedUserMappedLogin?.Enabled!=false;
    public bool IsSelectedUserManagementBlocked=>IsSelectedUser&&_selectedUserLoginCheckCompleted&&_selectedUserMappedLogin?.Enabled==false;
    public string SelectedUserAccessStateText=>!IsSelectedUser?"":!_selectedUserLoginCheckCompleted
        ? "Verificando el login asociado…"
        : _selectedUserMappedLogin switch
        {
            {Enabled:false} state=>$"Gestión bloqueada: el login {state.Login} está deshabilitado",
            {Enabled:true} state=>$"Login asociado habilitado: {state.Login}",
            _=>"Usuario sin login de servidor asociado"
        };
    public string ContextActionTitle=>SelectedSecurityNode is null?"Seleccione un objeto":$"Acciones para {SelectedSecurityNode.Name}";
    public bool CanEnableSelectedLogin=>IsSelectedLogin&&_selectedLoginEnabled==false;
    public bool CanDisableSelectedLogin=>IsSelectedLogin&&_selectedLoginEnabled==true;
    public string SelectedLoginStateText=>!IsSelectedLogin?"":_selectedLoginEnabled switch
    {
        true=>"Estado actual: habilitado",
        false=>"Estado actual: deshabilitado",
        _=>"Consultando estado del login…"
    };
    public bool IsManagingAccess
    {
        get=>_isManagingAccess;
        private set
        {
            if(!Set(ref _isManagingAccess,value))return;
            Raise(nameof(IsBrowsingAccess));Raise(nameof(IsExistingAccessOperation));Raise(nameof(IsStandardAccessOperation));Raise(nameof(EditorBackActionText));
            Raise(nameof(HasTopRequestDetails));Raise(nameof(HasBottomRequestDetails));
            EditMappingModeCommand?.Refresh();EditObjectPermissionsModeCommand?.Refresh();
        }
    }
    public bool IsBrowsingAccess=>!IsManagingAccess;
    public string SecuritySelectionTitle {get=>_securitySelectionTitle;private set=>Set(ref _securitySelectionTitle,value);}
    public string SecuritySelectionSubtitle {get=>_securitySelectionSubtitle;private set=>Set(ref _securitySelectionSubtitle,value);}
    public string SecuritySelectionType {get=>_securitySelectionType;private set=>Set(ref _securitySelectionType,value);}
    public string SecuritySummary {get=>_securitySummary;private set=>Set(ref _securitySummary,value);}
    public string SecurityFilter {get=>_securityFilter;set{if(Set(ref _securityFilter,value))ApplySecurityFilter();}}
    public string SecurityFilterHint {get=>_securityFilterHint;private set=>Set(ref _securityFilterHint,value);}
    public bool IsLoginMappingOperation=>SelectedOperation?.Code=="MODIFY_LOGIN";
    public bool IsPermissionMatrixOperation=>SelectedOperation?.Code=="PERMISSION_CHANGE";
    public bool IsExistingAccessOperation=>IsManagingAccess&&(IsLoginMappingOperation||IsPermissionMatrixOperation)&&SelectedServerLogin is not null;
    public bool IsStandardAccessOperation=>!IsExistingAccessOperation;
    public string EditorBackActionText=>IsExistingAccessOperation?"↻  Cambiar usuario":"← Volver a consulta";
    public bool IsCreateLoginOperation=>SelectedOperation?.Code is "CREATE_SQL_LOGIN" or "CREATE_WINDOWS_LOGIN";
    public bool IncludeInitialAccess
    {
        get=>_includeInitialAccess;
        set
        {
            if(!Set(ref _includeInitialAccess,value))return;
            if(!value)
            {
                foreach(var database in Databases)database.IsSelected=false;
                foreach(var permission in InitialAccessPermissionChoices)permission.IsSelected=false;
                foreach(var role in InitialAccessRoleChoices)role.IsSelected=false;
            }
            Decision=null;
            SynchronizeCreateUserObjectDatabase();CreateUserAccessOptionsChanged();
        }
    }
    public bool RequiresBasicAccessData=>!IsLoginMappingOperation&&!IsPermissionMatrixOperation;
    public bool NeedsPolicyConfiguration=>SelectedOperation is not null&&!SelectedOperation.Enabled;
    public string PolicyConfigurationWarning=>NeedsPolicyConfiguration
        ? SelectedOperation?.Code=="CLONE_PERMISSIONS"
            ? "Esta opción todavía no está disponible. Comuníquese con el administrador de la aplicación si necesita utilizarla."
            : "Esta opción todavía no está disponible. Comuníquese con el administrador de la aplicación."
        : "";
    public bool IsServerAccessOperation=>SelectedOperation?.Code is "SERVER_PERMISSION_CHANGE" or "ADD_SERVER_ROLE_MEMBER" or "REMOVE_SERVER_ROLE_MEMBER";
    public bool IsServerOperation=>IsServerAccessOperation||SelectedOperation?.Code is "CREATE_SQL_LOGIN" or "CREATE_WINDOWS_LOGIN" or "ENABLE_LOGIN" or "DISABLE_LOGIN";
    public bool IsDatabaseOperation=>SelectedOperation is not null&&!IsServerOperation;
    public bool IsStandardDatabaseOperation=>IsDatabaseOperation&&!IsLoginMappingOperation&&!IsPermissionMatrixOperation&&!IsClonePermissionsOperation;
    public bool RequiresSourcePrincipal=>SelectedOperation?.Code=="CLONE_PERMISSIONS";
    public bool RequiresRole=>SelectedOperation?.Code is "MODIFY_LOGIN" or "ADD_ROLE_MEMBER" or "REMOVE_ROLE_MEMBER" or "ADD_SERVER_ROLE_MEMBER" or "REMOVE_SERVER_ROLE_MEMBER";
    public bool RequiresRoleInDetails=>RequiresRole&&!IsLoginMappingOperation;
    public bool RequiresPermission=>SelectedOperation?.Code is "PERMISSION_CHANGE" or "SERVER_PERMISSION_CHANGE";
    public bool RequiresSecurable=>RequiresPermission&&SqlPermissionSafety.Scope(Scope)?.Parts>0;
    public bool RequiresAuthenticationType=>IsCreateLoginOperation||IsClonePermissionsOperation;
    public bool RequiresDefaultDatabase=>false;
    public string OperationBadge=>$"{(IsServerOperation?"INSTANCIA":RequiresPermission&&Scope=="OBJECT"?"OBJETO":"BASE DE DATOS")} · RIESGO {SelectedOperation?.Risk??"-"}";
    public string TargetPrincipalLabel=>SelectedOperation?.Code switch
    {
        "CREATE_SQL_LOGIN"=>"Nombre de la nueva cuenta SQL",
        "CREATE_WINDOWS_LOGIN"=>"Cuenta de Windows (DOMINIO\\usuario o EQUIPO\\usuario)",
        "MODIFY_LOGIN"=>"Login que se modificará",
        "CREATE_DB_USER"=>"Login existente que se convertirá en usuario",
        "ENABLE_LOGIN" or "DISABLE_LOGIN"=>"Login que se modificará",
        "PERMISSION_CHANGE"=>"Usuario destino (los roles no están permitidos)",
        "CLONE_PERMISSIONS"=>IsWindowsAuthentication?"Nueva cuenta de Windows (DOMINIO\\usuario o EQUIPO\\usuario)":"Nombre de la nueva cuenta SQL",
        _=>"Usuario o principal destino"
    };
    public string TargetPrincipalHelp=>SelectedOperation?.Code switch
    {
        "CREATE_SQL_LOGIN"=>"Escriba un nombre para la cuenta. A continuación podrá definir una contraseña temporal.",
        "CREATE_WINDOWS_LOGIN"=>AuthenticationHelp,
        "MODIFY_LOGIN"=>"Seleccione una base de datos y uno de los roles aprobados para mapear el login como usuario.",
        "CREATE_DB_USER"=>"El login debe existir previamente en cada servidor seleccionado.",
        "ENABLE_LOGIN"=>"No se cambiarán roles ni permisos del login.",
        "DISABLE_LOGIN"=>"El login no se elimina y sus permisos se conservan.",
        "PERMISSION_CHANGE"=>"Solo puede ser un usuario de base de datos; nunca un rol fijo o personalizado.",
        "CLONE_PERMISSIONS"=>IsWindowsAuthentication?AuthenticationHelp:"El nombre nuevo debe estar disponible. Se creará un login SQL y sus usuarios de base al ejecutar.",
        _=>"Principal que recibirá la operación solicitada."
    };
    public string OperationGuidance=>SelectedOperation?.Code switch
    {
        "CREATE_SQL_LOGIN"=>"Cree una cuenta SQL nueva y, si lo necesita, asígnele acceso inicial a una base de datos.",
        "CREATE_WINDOWS_LOGIN"=>"Use una cuenta de Windows existente y, si lo necesita, asígnele acceso inicial a una base de datos.",
        "MODIFY_LOGIN"=>"Muestra todas las bases del servidor. Al seleccionar una se habilitan únicamente los roles aprobados por la política central.",
        "CREATE_DB_USER"=>"Seleccione las bases donde se creará el usuario asociado al login existente.",
        "ADD_ROLE_MEMBER"=>"Seleccione el usuario, el rol aprobado y las bases donde se agregará la membresía.",
        "REMOVE_ROLE_MEMBER"=>"Seleccione el usuario, el rol y las bases de las que se retirará la membresía.",
        "PERMISSION_CHANGE"=>"Elija dónde se aplicará el acceso y después marque las acciones que necesita realizar el usuario.",
        "CLONE_PERMISSIONS"=>IsWindowsAuthentication
            ?"Elija un usuario como referencia y escriba la cuenta de Windows que recibirá los mismos accesos permitidos."
            :"Elija un usuario como referencia y escriba el nombre de la nueva cuenta SQL que recibirá los mismos accesos permitidos.",
        "ENABLE_LOGIN"=>"Seleccione los servidores donde se habilitará el login.",
        "DISABLE_LOGIN"=>"Seleccione los servidores donde se deshabilitará el login.",
        _=>"Seleccione una operación para ver los datos necesarios."
    };
    public string DestinationInstruction=>IsLoginMappingOperation
        ? "Seleccione una base de datos. Después podrá elegir el rol permitido que se asignará al usuario mapeado."
        : IsPermissionMatrixOperation
            ? "Siga los pasos: elija el alcance, seleccione objetos si corresponde y marque las acciones permitidas."
        : SelectedOperation?.Code=="CLONE_PERMISSIONS"
            ? "Revise qué accesos recibirá la nueva cuenta. La tabla es informativa y no puede editarse."
        : IsServerOperation
            ? "Operación de instancia: se ejecutará únicamente en el servidor de trabajo seleccionado."
            : "Operación de base de datos: cargue las bases del servidor de trabajo y marque una o varias bases de ese mismo servidor.";
    public string SecurableLabel=>Scope switch
    {
        "SCHEMA"=>"Esquema",
        "OBJECT"=>"Objeto",
        "COLUMN"=>"Columna",
        _=>SqlPermissionSafety.Scope(Scope)?.SqlClass??"Destino"
    };
    public string SecurableHelp=>Scope switch
    {
        "SCHEMA"=>"Ejemplo: ventas",
        "OBJECT"=>"Ejemplo: ventas.Factura",
        "COLUMN"=>"Ejemplo: ventas.Factura.Total",
        _=>SqlPermissionSafety.Scope(Scope)?.Parts==0?"No requiere un objeto destino."
            :SqlPermissionSafety.Scope(Scope)?.Parts==2?"Escriba esquema.nombre, sin corchetes.":"Escriba el nombre del destino, sin corchetes."
    };
    public AsyncCommand LoadDatabasesCommand {get;}
    public AsyncCommand LoadDatabaseObjectsCommand {get;}
    public AsyncCommand LoadInventoryCommand {get;}
    public AsyncCommand PreviewCommand {get;}
    public AsyncCommand SubmitCommand {get;}
    public AsyncCommand RefreshRequestsCommand {get;}
    public AsyncCommand ApproveCommand {get;}
    public AsyncCommand RejectCommand {get;}
    public AsyncCommand ExecuteApprovedCommand {get;}
    public RelayCommand ClearSecurityFilterCommand {get;}
    public RelayCommand BeginAccessManagementCommand {get;}
    public RelayCommand CancelAccessManagementCommand {get;}
    public AsyncCommand NewLoginCommand {get;}
    public AsyncCommand RefreshSecurityTreeCommand {get;}
    public AsyncCommand ModifyLoginCommand {get;}
    public AsyncCommand EnableLoginCommand {get;}
    public AsyncCommand DisableLoginCommand {get;}
    public AsyncCommand CreateDatabaseUserCommand {get;}
    public AsyncCommand ChangePermissionsCommand {get;}
    public AsyncCommand AddRoleCommand {get;}
    public AsyncCommand RemoveRoleCommand {get;}
    public AsyncCommand LoadSelectedLoginCommand {get;}
    public AsyncCommand EditMappingModeCommand {get;}
    public AsyncCommand EditObjectPermissionsModeCommand {get;}
    public RelayCommand ResetObjectPermissionFiltersCommand {get;}
    public AsyncCommand RetryDatabaseAccessCommand {get;}
    public AsyncCommand VerifyExternalTicketCommand {get;}

    public AccessViewModel(AdminDbGateway db,DirectSqlServerService direct)
    {
        RetryDatabaseAccessCommand=new(LoadSelectedDatabaseContextAsync);
        VerifyExternalTicketCommand=new(VerifyExternalTicketAsync,()=>CanVerifyExternalTicket);
        _db=db;_direct=direct;LoadDatabasesCommand=new(LoadDatabasesAsync);LoadDatabaseObjectsCommand=new(LoadDatabaseObjectsAsync);LoadInventoryCommand=new(LoadInventoryAsync);
        PreviewCommand=new(PreviewAsync,()=>(!HasDatabaseAccessEditor||CanEditDatabaseAccess)
            &&(!IsClonePermissionsOperation||CanSubmitPermissionCopy)
            &&(!IsCreateLoginOperation||IsCreateLoginTargetAvailable)&&CanUseValidatedWindowsName);
        SubmitCommand=new(SubmitAsync,()=>!_requestSubmitted&&IsExternalTicketValid&&IsTemporaryPasswordValid&&CanSubmitCreateUserWizard
            &&(!HasDatabaseAccessEditor||CanEditDatabaseAccess)
            &&(!IsClonePermissionsOperation||CanSubmitPermissionCopy)
            &&(!IsCreateLoginOperation||IsCreateLoginTargetAvailable)&&CanUseValidatedWindowsName);
        RefreshRequestsCommand=new(LoadRequestsAsync);ApproveCommand=new(()=>ApproveAsync(true),()=>SelectedRequest?.Status=="PENDING");RejectCommand=new(()=>ApproveAsync(false),()=>SelectedRequest?.Status=="PENDING");ExecuteApprovedCommand=new(ExecuteApprovedAsync,()=>SelectedRequest?.Status=="APPROVED");ClearSecurityFilterCommand=new(()=>SecurityFilter="");BeginAccessManagementCommand=new(()=>BeginAccessManagement());CancelAccessManagementCommand=new(()=>{ClearAccessDraft();SelectedAccessStep=0;});
        NewLoginCommand=new(()=>BeginAccessManagementAsync("CREATE_SQL_LOGIN"),()=>!_isStartingAccessManagement);
        RefreshSecurityTreeCommand=new(RefreshSecurityTreeAsync,()=>!_isStartingAccessManagement);
        ModifyLoginCommand=new(()=>BeginAccessManagementAsync("MODIFY_LOGIN"),()=>IsSelectedLogin&&!_isStartingAccessManagement);
        EnableLoginCommand=new(()=>ConfirmLoginStateChangeAsync(true),()=>CanEnableSelectedLogin&&!_isStartingAccessManagement);
        DisableLoginCommand=new(()=>ConfirmLoginStateChangeAsync(false),()=>CanDisableSelectedLogin&&!_isStartingAccessManagement);
        CreateDatabaseUserCommand=new(()=>BeginAccessManagementAsync("CREATE_DB_USER"),()=>CanCreateDatabaseUser&&!_isStartingAccessManagement);
        ChangePermissionsCommand=new(()=>BeginAccessManagementAsync("PERMISSION_CHANGE"),()=>CanManageSelectedUser&&!_isStartingAccessManagement);
        AddRoleCommand=new(()=>BeginAccessManagementAsync("ADD_ROLE_MEMBER"),()=>CanManageSelectedUser&&!_isStartingAccessManagement);
        RemoveRoleCommand=new(()=>BeginAccessManagementAsync("REMOVE_ROLE_MEMBER"),()=>CanManageSelectedUser&&!_isStartingAccessManagement);
        LoadSelectedLoginCommand=new(LoadSelectedServerLoginAsync,()=>SelectedServerLogin?.Enabled==true&&!_isStartingAccessManagement);
        EditMappingModeCommand=new(()=>SwitchExistingAccessOperationAsync("MODIFY_LOGIN"),()=>IsExistingAccessOperation);
        EditObjectPermissionsModeCommand=new(()=>SwitchExistingAccessOperationAsync("PERMISSION_CHANGE"),()=>IsExistingAccessOperation);
        ResetObjectPermissionFiltersCommand=new(()=>{ObjectPermissionSearch="";SelectedObjectSchemaFilter="Todos";SelectedObjectTypeFilter="Todos";});
        InitializeCreateUserWizard();
        _=InitializeAsync();
    }

    private void RefreshContextCommands()
    {
        NewLoginCommand?.Refresh();
        RefreshSecurityTreeCommand?.Refresh();
        ModifyLoginCommand?.Refresh();
        EnableLoginCommand?.Refresh();
        DisableLoginCommand?.Refresh();
        CreateDatabaseUserCommand?.Refresh();
        ChangePermissionsCommand?.Refresh();
        AddRoleCommand?.Refresh();
        RemoveRoleCommand?.Refresh();
        LoadSelectedLoginCommand?.Refresh();
        EditMappingModeCommand?.Refresh();
        EditObjectPermissionsModeCommand?.Refresh();
    }

    private async Task PrepareSelectedAccessStepAsync(int step)
    {
        if(!HasWorkingServer||_isStartingAccessManagement)return;
        switch(step)
        {
            case 0:
                IsManagingAccess=false;
                break;
            case 1:
                await BeginAccessManagementAsync("CREATE_SQL_LOGIN");
                break;
            case 2:
                await BeginAccessManagementAsync("CLONE_PERMISSIONS");
                break;
            case 3:
                IsManagingAccess=false;
                await LoadRequestsAsync();
                break;
        }
    }

    private void SetSelectedLoginEnabled(bool? value)
    {
        if(_selectedLoginEnabled==value)return;
        _selectedLoginEnabled=value;
        Raise(nameof(CanEnableSelectedLogin));
        Raise(nameof(CanDisableSelectedLogin));
        Raise(nameof(SelectedLoginStateText));
        RefreshContextCommands();
    }

    private void SetSelectedUserMappedLogin(MappedLoginState? value,bool completed)
    {
        _selectedUserMappedLogin=value;
        _selectedUserLoginCheckCompleted=completed;
        Raise(nameof(CanManageSelectedUser));
        Raise(nameof(IsSelectedUserManagementBlocked));
        Raise(nameof(SelectedUserAccessStateText));
        RefreshContextCommands();
    }

    private async Task<bool> VerifyUserLoginAllowsManagementAsync(SecurityTreeNode node)
    {
        try
        {
            var state=await _direct.GetMappedLoginStateAsync(node.ServerId,node.Database,node.Principal);
            if(ReferenceEquals(SelectedSecurityNode,node))SetSelectedUserMappedLogin(state,true);
            if(state?.Enabled!=false)return true;
            Status=$"Gestión bloqueada: el login {state.Login} asociado a {node.Principal} está deshabilitado.";
            MessageBox.Show(
                $"No se puede modificar el acceso de '{node.Principal}' en {node.Database} porque su login asociado '{state.Login}' está deshabilitado.\n\nHabilite primero el login y complete su confirmación y ejecución.",
                "Gestión de base de datos bloqueada",
                MessageBoxButton.OK,
                MessageBoxImage.Warning);
            return false;
        }
        catch(Exception ex)
        {
            if(ReferenceEquals(SelectedSecurityNode,node))SetSelectedUserMappedLogin(null,false);
            Status=$"No fue posible verificar el login asociado: {ex.Message}";
            return false;
        }
    }

    private async Task ConfirmLoginStateChangeAsync(bool enable)
    {
        var node=SelectedSecurityNode;
        if(node?.Kind!=SecurityNodeKind.Login)return;
        if(enable&&_selectedLoginEnabled!=false)return;
        if(!enable&&_selectedLoginEnabled!=true)return;
        var action=enable?"habilitar":"deshabilitar";
        var consequence=enable
            ? "El login podrá volver a autenticarse y acceder a los recursos que tenga asignados."
            : "El login dejará de poder autenticarse; esto puede interrumpir usuarios, servicios o procesos dependientes.";
        var result=MessageBox.Show(
            $"Está a punto de {action} el login '{node.Principal}'.\n\n{consequence}\n\nSe creará una solicitud auditable que todavía deberá confirmarse y ejecutarse. ¿Desea continuar?",
            $"Confirmar: {action} login",
            MessageBoxButton.YesNo,
            MessageBoxImage.Warning,
            MessageBoxResult.No);
        if(result!=MessageBoxResult.Yes)return;
        await BeginAccessManagementAsync(enable?"ENABLE_LOGIN":"DISABLE_LOGIN",node);
    }
    private async Task InitializeAsync()
    {
        try
        {
            foreach(var x in await _db.GetServersAsync())if(x.Active)Servers.Add(x);
            BuildSecurityTree();
            foreach(var source in await _db.GetPolicyOperationsAsync())
            {
                if(!source.Enabled||!SupportedRequestOperations.Contains(source.Code))continue;
                var operation=source.Code switch
                {
                    "MODIFY_LOGIN"=>source with{Name="Mapear login a base y roles",Description="Seleccione una base y los roles aprobados que recibirá el usuario mapeado."},
                    "PERMISSION_CHANGE"=>source with{Name="Conceder permisos de datos",Description="Elija si el acceso aplicará a toda la base o únicamente a objetos específicos."},
                    _=>source
                };
                Operations.Add(operation);
            }
            var policyBlocks=await _db.GetDenyRulesAsync();
            foreach(var x in await _db.GetPolicyPermissionsAsync())if(PolicyEditorCatalog.CanUsePermission(x,policyBlocks))Permissions.Add(x);
            RefreshInitialAccessPermissions();
            foreach(var x in await _db.GetPolicyRolesAsync())if(x.RoleScope=="DATABASE"&&PolicyEditorCatalog.CanUseRole(x,policyBlocks))Roles.Add(x);
            RefreshInitialAccessRoles();
            RefreshRoleChoices();
            SelectedOperation=Operations.FirstOrDefault();
            SelectedRole=Roles.FirstOrDefault();
            RefreshAvailablePermissions();
            await LoadRequestsAsync();
        }
        catch(Exception ex){Status=$"No se pudo cargar la política. Aplique 27_PoliticaAccesoPorInstanciaYBase.sql después de 26 y ejecute 99_ValidarInstalacion.sql: {ex.Message}";}
    }

    private void OnWorkingServerChanged()
    {
        ResetCreateUserWizard();
        ResetWindowsNameValidation();
        ResetCreateLoginTargetValidation();
        ResetPermissionCopy();
        CancelDatabaseContextLoad();
        SelectedMappingDatabase=null;
        _databaseRolesLoaded=false;_objectPermissionsLoaded=false;
        foreach(var server in Servers)server.IsSelected=ReferenceEquals(server,SelectedWorkingServer);
        ServerLogins.Clear();FilteredServerLogins.Clear();SelectedServerLogin=null;LoginSearchText="";SelectedLoginTypeFilter="Todos los tipos";
        Databases.Clear();DatabaseObjects.Clear();SelectedDatabaseObjects.Clear();SelectedDatabaseObject=null;Raise(nameof(SelectedObjectsSummary));
        InventoryDatabases.Clear();InventoryDatabase=null;_inventoryServer=SelectedWorkingServer;Raise(nameof(InventoryServer));
        SecurityFilter="";
        BuildSecurityTree();
        Requests.Clear();SelectedRequest=null;Results.Clear();
        _allActiveRequests.Clear();Raise(nameof(PendingRequestCount));Raise(nameof(PendingRequestBadge));
        IsManagingAccess=false;
        if(_selectedAccessStep!=0){_selectedAccessStep=0;Raise(nameof(SelectedAccessStep));Raise(nameof(IsModifyAccessStep));Raise(nameof(IsCreateUserStep));Raise(nameof(IsCopyPermissionsStep));Raise(nameof(IsConfirmationStep));}
        Raise(nameof(HasWorkingServer));Raise(nameof(WorkingServerSummary));
        Status=SelectedWorkingServer is null
            ? "Paso previo: seleccione un servidor de trabajo."
            : $"Servidor de trabajo fijado: {WorkingServerSummary}. Todas las acciones se limitarán a este servidor.";
        Permissions.Clear();Roles.Clear();RefreshAvailablePermissions();RefreshRoleChoices();
        if(SelectedWorkingServer is not null){_=LoadRequestsAsync();_=LoadServerLoginsAsync();_=LoadScopedAccessPolicyAsync(new(SelectedWorkingServer.Id));}
    }


    private int _policyLoadVersion;
    private async Task LoadScopedAccessPolicyAsync(PolicyContext context,CancellationToken ct=default)
    {
        var version=++_policyLoadVersion;
        try
        {
            var permissions=await _db.GetPolicyPermissionsAsync(context,ct);
            var roles=await _db.GetPolicyRolesAsync(context,ct);
            var blocks=await _db.GetDenyRulesAsync(ct);
            ct.ThrowIfCancellationRequested();
            if(version!=_policyLoadVersion||SelectedWorkingServer?.Id!=context.ServerId)return;
            Permissions.Clear();
            foreach(var rule in permissions.Where(x=>PolicyEditorCatalog.CanUsePermission(x,blocks)))Permissions.Add(rule);
            Roles.Clear();
            foreach(var rule in roles.Where(x=>x.RoleScope==(IsServerAccessOperation?"SERVER":"DATABASE")&&PolicyEditorCatalog.CanUseRole(x,blocks)))Roles.Add(rule);
            RefreshAvailablePermissions();RefreshRoleChoices();RefreshInitialAccessPermissions();RefreshInitialAccessRoles();
        }
        catch(OperationCanceledException) when(ct.IsCancellationRequested){throw;}
        catch(Exception error)
        {
            if(version!=_policyLoadVersion)return;
            Permissions.Clear();Roles.Clear();RefreshAvailablePermissions();RefreshRoleChoices();
            Status="No se pudo cargar la política del destino: "+error.Message;
            if(ct.CanBeCanceled)throw;
        }
    }

    public AsyncCommand ServerPermissionsCommand=>_serverPermissionsCommand??=new(()=>BeginSelectedServerAccessAsync("SERVER_PERMISSION_CHANGE"),()=>SelectedServerLogin is not null);
    public AsyncCommand AssignServerRoleCommand=>_assignServerRoleCommand??=new(()=>BeginSelectedServerAccessAsync("ADD_SERVER_ROLE_MEMBER"),()=>SelectedServerLogin is not null);
    public AsyncCommand RemoveServerRoleCommand=>_removeServerRoleCommand??=new(()=>BeginSelectedServerAccessAsync("REMOVE_SERVER_ROLE_MEMBER"),()=>SelectedServerLogin is not null);
    private AsyncCommand? _serverPermissionsCommand,_assignServerRoleCommand,_removeServerRoleCommand;
    private async Task BeginSelectedServerAccessAsync(string operation)
    {
        if(SelectedServerLogin is not { } login||SelectedWorkingServer is not { } server)return;
        await BeginAccessManagementAsync(operation,new(login.Name,SecurityNodeKind.Login,server.Id,server.Name,principal:login.Name,loginEnabled:login.Enabled));
    }
    public async Task RefreshSecurityTreeAsync()
    {
        BuildSecurityTree();
        await LoadServerLoginsAsync();
    }

    private async Task LoadServerLoginsAsync()
    {
        ServerLogins.Clear();FilteredServerLogins.Clear();SelectedServerLogin=null;
        if(SelectedWorkingServer is null)return;
        try
        {
            Status=$"Cargando logins administrables de {SelectedWorkingServer.Name}…";
            var table=await _direct.GetSecurityInventoryAsync(SelectedWorkingServer.Id,"master","LOGINS");
            foreach(var row in table.Rows.Cast<DataRow>())
            {
                var name=TableCell(row,"LoginName","Name");
                if(string.IsNullOrWhiteSpace(name)||IsInternalOrServicePrincipal(name))continue;
                var type=TableCell(row,"LoginType","Type");
                var enabled=!table.Columns.Contains("IsDisabled")||row.IsNull("IsDisabled")||!Convert.ToBoolean(row["IsDisabled"]);
                ServerLogins.Add(new(name,string.IsNullOrWhiteSpace(type)?"SQL_LOGIN":type,enabled));
            }
            ApplyServerLoginFilter();
            Status=$"{ServerLogins.Count} login(s) administrable(s) disponible(s) en {SelectedWorkingServer.Name}.";
        }
        catch(Exception ex){Status=$"No se pudieron cargar los logins: {ex.Message}";}
    }

    private void ApplyServerLoginFilter()
    {
        var selectedName=SelectedServerLogin?.Name;
        FilteredServerLogins.Clear();
        foreach(var login in ServerLogins
                    .Where(x=>string.IsNullOrWhiteSpace(LoginSearchText)||x.Name.Contains(LoginSearchText.Trim(),StringComparison.CurrentCultureIgnoreCase))
                    .Where(x=>SelectedLoginTypeFilter=="Todos los tipos"||x.Type.Equals(SelectedLoginTypeFilter,StringComparison.OrdinalIgnoreCase))
                    .OrderBy(x=>x.Name,StringComparer.CurrentCultureIgnoreCase))
            FilteredServerLogins.Add(login);
        SelectedServerLogin=FilteredServerLogins.FirstOrDefault(x=>x.Name.Equals(selectedName,StringComparison.OrdinalIgnoreCase));
    }

    private async Task LoadSelectedServerLoginAsync()
    {
        if(SelectedWorkingServer is null||SelectedServerLogin is null)return;
        if(!SelectedServerLogin.Enabled){Status=$"No se pueden modificar accesos de {SelectedServerLogin.Name} porque el login está deshabilitado.";return;}
        var node=new SecurityTreeNode(SelectedServerLogin.Name,SecurityNodeKind.Login,SelectedWorkingServer.Id,SelectedWorkingServer.Name,principal:SelectedServerLogin.Name,loginEnabled:SelectedServerLogin.Enabled);
        SelectedSecurityNode=node;
        SetSelectedLoginEnabled(SelectedServerLogin.Enabled);
        await BeginAccessManagementAsync("MODIFY_LOGIN",node);
    }

    private async Task SwitchExistingAccessOperationAsync(string operationCode)
    {
        if(SelectedWorkingServer is null||SelectedServerLogin is null)return;
        if(SelectedOperation?.Code.Equals(operationCode,StringComparison.OrdinalIgnoreCase)==true)return;
        var operation=Operations.FirstOrDefault(x=>x.Code.Equals(operationCode,StringComparison.OrdinalIgnoreCase));
        if(operation is null){Status=$"La operación {operationCode} no está habilitada por la política central.";return;}
        CancelDatabaseContextLoad();
        _isSwitchingExistingAccessOperation=true;
        try{SelectedOperation=operation;}
        finally{_isSwitchingExistingAccessOperation=false;}
        TargetPrincipal=SelectedServerLogin.Name;
        if(Databases.Count==0)await LoadDatabasesAsync();
        if(IsPermissionMatrixOperation){Scope="OBJECT";PermissionAction="GRANT";RefreshAvailablePermissions();}
        await LoadSelectedDatabaseContextAsync();
    }

    private void CancelDatabaseContextLoad()
    {
        _databaseContextCancellation?.Cancel();
        _databaseContextCancellation=null;
        IsLoadingDatabaseAccess=false;
    }

    private async Task LoadSelectedDatabaseContextAsync()
    {
        CancelDatabaseContextLoad();
        HasDatabaseAccessError=false;
        var database=SelectedMappingDatabase;
        if(database is null||!HasDatabaseAccessEditor)
        {
            RoleChoicesHint="Seleccione una base de datos para consultar sus roles.";
            DatabaseAccessMessage="Seleccione una base de datos. Después elija roles o permisos por objeto.";
            RefreshDatabaseAccessState();
            return;
        }
        if(SelectedWorkingServer is null||string.IsNullOrWhiteSpace(TargetPrincipal))return;
        var cancellation=new CancellationTokenSource();
        _databaseContextCancellation=cancellation;
        var ct=cancellation.Token;
        var node=new SecurityTreeNode(TargetPrincipal,SecurityNodeKind.User,database.ServerId,database.Server,database.Name,TargetPrincipal);
        IsLoadingDatabaseAccess=true;
        DatabaseAccessMessage=IsPermissionMatrixOperation?$"Cargando objetos y permisos de {database.Name}…":$"Consultando roles de {database.Name}…";
        Status=DatabaseAccessMessage;
        try
        {
            // Let WPF paint the loading state before starting the queries.
            await Dispatcher.Yield(DispatcherPriority.Background);
            ct.ThrowIfCancellationRequested();
            await LoadScopedAccessPolicyAsync(new(database.ServerId,database.Name),ct);
            if(!_databaseRolesLoaded)
            {
                RoleChoicesHint=$"Consultando membresías de {database.Name}…";
                await LoadDatabaseRoleMembershipsAsync(node,ct);
                ct.ThrowIfCancellationRequested();
                _databaseRolesLoaded=true;
                RoleChoicesHint=$"{DatabaseRoleChoices.Count(x=>x.InitiallyAssigned)} rol(es) asignado(s) actualmente. Marque o desmarque los cambios requeridos.";
            }
            if(IsPermissionMatrixOperation&&!_objectPermissionsLoaded)
            {
                var mapped=await _direct.GetMappedLoginStateAsync(database.ServerId,database.Name,node.Principal,ct);
                ct.ThrowIfCancellationRequested();
                if(mapped is null)throw new InvalidOperationException($"{node.Principal} todavía no está mapeado en {database.Name}. Abra 'Mapeo y roles' para asignarle acceso primero.");
                if(!mapped.Enabled)throw new InvalidOperationException($"El login {mapped.Login} está deshabilitado.");
                SelectedSecurityNode=node;
                SetSelectedUserMappedLogin(mapped,true);
                await LoadObjectPermissionMatrixAsync(database,node.Principal,ct);
                ct.ThrowIfCancellationRequested();
                _objectPermissionsLoaded=true;
            }
            ct.ThrowIfCancellationRequested();
            DatabaseAccessMessage=IsPermissionMatrixOperation
                ? ObjectPermissionRows.Count==0?$"No hay objetos administrables en {database.Name}.":$"{ObjectPermissionRows.Count} objetos en {database.Name}. Los permisos marcados son asignaciones explícitas actuales."
                : $"Trabajando en {database.Name}. Los roles marcados son membresías actuales.";
            Status=DatabaseAccessMessage;
        }
        catch(OperationCanceledException) when(ct.IsCancellationRequested) { }
        catch(Exception ex)
        {
            if(ct.IsCancellationRequested)return;
            HasDatabaseAccessError=true;
            DatabaseAccessMessage=$"No se pudo cargar el acceso de {database.Name}: {ex.Message}";
            Status=DatabaseAccessMessage;
        }
        finally
        {
            if(ReferenceEquals(_databaseContextCancellation,cancellation))
            {
                _databaseContextCancellation=null;
                IsLoadingDatabaseAccess=false;
            }
            cancellation.Dispose();
        }
    }

    private async Task LoadObjectPermissionMatrixAsync(DatabaseItem database,string principal,CancellationToken ct)
    {
        ObjectPermissionRows.Clear();FilteredObjectPermissionRows.Clear();
        ObjectSchemaFilters.Clear();ObjectSchemaFilters.Add("Todos");
        ObjectTypeFilters.Clear();ObjectTypeFilters.Add("Todos");
        var allowed=Permissions
            .Where(x=>x.Enabled&&x.Scope.Equals("OBJECT",StringComparison.OrdinalIgnoreCase)&&x.AllowGrant)
            .Select(x=>x.Permission)
            .ToHashSet(StringComparer.OrdinalIgnoreCase);
        var objectsTask=_direct.GetDatabaseObjectsAsync(database,ct);
        var detailsTask=_direct.GetSecurityPrincipalDetailsAsync(database.ServerId,database.Name,principal,SecurityNodeKind.User,ct);
        await Task.WhenAll(objectsTask,detailsTask);
        ct.ThrowIfCancellationRequested();
        var objects=await objectsTask;
        var assignedByObject=(await detailsTask).Permissions
            .Where(x=>x.Scope.Equals("OBJECT",StringComparison.OrdinalIgnoreCase))
            .Where(x=>x.State.StartsWith("Grant",StringComparison.OrdinalIgnoreCase))
            .Where(x=>ManagedDataPermissions.Contains(x.Permission))
            .GroupBy(x=>x.Securable,StringComparer.OrdinalIgnoreCase)
            .ToDictionary(x=>x.Key,x=>x.Select(p=>p.Permission).ToHashSet(StringComparer.OrdinalIgnoreCase),StringComparer.OrdinalIgnoreCase);
        if(!ReferenceEquals(SelectedMappingDatabase,database))return;
        var loadedCount=0;
        foreach(var item in objects)
        {
            ct.ThrowIfCancellationRequested();
            assignedByObject.TryGetValue(item.QualifiedName,out var assigned);
            var row=new ObjectPermissionRow(item,allowed,assigned);
            row.PropertyChanged+=(_,args)=>
            {
                if(args.PropertyName is not (nameof(ObjectPermissionRow.GrantSelect) or nameof(ObjectPermissionRow.GrantInsert) or nameof(ObjectPermissionRow.GrantUpdate) or nameof(ObjectPermissionRow.GrantDelete) or nameof(ObjectPermissionRow.GrantExecute) or nameof(ObjectPermissionRow.HasChange)))return;
                Decision=null;Raise(nameof(ObjectPermissionGrantCount));Raise(nameof(ObjectPermissionSummary));Raise(nameof(PlannedChangesSummary));
            };
            ObjectPermissionRows.Add(row);
            if(++loadedCount%100==0)
            {
                DatabaseAccessMessage=$"Preparando objetos de {database.Name}: {loadedCount} de {objects.Count}…";
                await Dispatcher.Yield(DispatcherPriority.Background);
                ct.ThrowIfCancellationRequested();
            }
        }
        foreach(var schema in ObjectPermissionRows.Select(x=>x.Schema).Distinct(StringComparer.OrdinalIgnoreCase).OrderBy(x=>x))ObjectSchemaFilters.Add(schema);
        foreach(var type in ObjectPermissionRows.Select(x=>x.Kind).Distinct(StringComparer.OrdinalIgnoreCase).OrderBy(x=>x))ObjectTypeFilters.Add(type);
        _selectedObjectSchemaFilter="Todos";_selectedObjectTypeFilter="Todos";_objectPermissionSearch="";
        Raise(nameof(SelectedObjectSchemaFilter));Raise(nameof(SelectedObjectTypeFilter));Raise(nameof(ObjectPermissionSearch));
        ApplyObjectPermissionFilter();
        Raise(nameof(ObjectPermissionGrantCount));Raise(nameof(ObjectPermissionSummary));Raise(nameof(PlannedChangesSummary));
    }

    private void ApplyObjectPermissionFilter()
    {
        FilteredObjectPermissionRows.Clear();
        foreach(var row in ObjectPermissionRows
                    .Where(x=>SelectedObjectSchemaFilter=="Todos"||x.Schema.Equals(SelectedObjectSchemaFilter,StringComparison.OrdinalIgnoreCase))
                    .Where(x=>SelectedObjectTypeFilter=="Todos"||x.Kind.Equals(SelectedObjectTypeFilter,StringComparison.OrdinalIgnoreCase))
                    .Where(x=>string.IsNullOrWhiteSpace(ObjectPermissionSearch)||x.Name.Contains(ObjectPermissionSearch.Trim(),StringComparison.CurrentCultureIgnoreCase)))
            FilteredObjectPermissionRows.Add(row);
    }

    public async Task BeginAccessManagementAsync(string? operationCode=null,SecurityTreeNode? node=null)
    {
        if(_isStartingAccessManagement)return;
        _isStartingAccessManagement=true;
        RefreshContextCommands();
        try
        {
            // Una operación elegida desde los pasos superiores es nueva y no debe
            // heredar el principal que quedó seleccionado en "Modificar accesos".
            if(operationCode is null)node??=SelectedSecurityNode;
            ResetManagementForm();
            var inferredCode=operationCode??(node?.Kind switch
            {
                SecurityNodeKind.Login=>"MODIFY_LOGIN",
                SecurityNodeKind.User=>"PERMISSION_CHANGE",
                _=>null
            });
            if(node?.Kind==SecurityNodeKind.User&&inferredCode is "PERMISSION_CHANGE" or "ADD_ROLE_MEMBER" or "REMOVE_ROLE_MEMBER")
                if(!await VerifyUserLoginAllowsManagementAsync(node))return;
            if(!string.IsNullOrWhiteSpace(inferredCode))
            {
                var operation=Operations.FirstOrDefault(x=>x.Code.Equals(inferredCode,StringComparison.OrdinalIgnoreCase));
                if(operation is null)
                {
                    operation=inferredCode switch
                    {
                        "MODIFY_LOGIN"=>new("MODIFY_LOGIN","Mapear login a base y roles",false,true,"HIGH","Configuración pendiente en la política central."),
                        "CLONE_PERMISSIONS"=>new("CLONE_PERMISSIONS","Copiar permisos de un usuario",false,true,"HIGH","La copia está visible, pero debe ser habilitada por la política central antes de enviarse."),
                        _=>null
                    };
                    if(operation is null)
                    {
                        IsManagingAccess=false;
                        Status=$"La operación {inferredCode} no está habilitada en la política central.";
                        return;
                    }
                }
                SelectedOperation=operation;
            }
            TargetPrincipal=node?.IsPrincipal==true?node.Principal:"";
            if(IsLoginMappingOperation)
            {
                SelectedRole=null;
                RoleChoices.Clear();
                RoleChoicesHint="Seleccione una base de datos para consultar sus roles permitidos.";
            }
            if(IsPermissionMatrixOperation){Scope="DATABASE";PermissionAction="GRANT";RefreshAvailablePermissions();}

            IsManagingAccess=true;
            if(IsServerAccessOperation)
            {
                Scope="SERVER";PermissionAction="GRANT";
                if(SelectedWorkingServer is not null)await LoadScopedAccessPolicyAsync(new(SelectedWorkingServer.Id));
                SelectedRole=Roles.FirstOrDefault();RefreshAvailablePermissions();
            }
            if(IsClonePermissionsOperation)
            {
                TargetPrincipal="";
                _=LoadCopySourcesAsync();
            }
            else if(IsLoginMappingOperation)
            {
                await LoadDatabasesAsync();
            }
            else if(!IsServerOperation&&!string.IsNullOrWhiteSpace(node?.Database))
            {
                await LoadDatabasesAsync();
                await LoadScopedAccessPolicyAsync(new(node.ServerId,node.Database));
                if(RequiresRole)SelectedRole=Roles.FirstOrDefault();
                foreach(var database in Databases)database.IsSelected=database.Name.Equals(node.Database,StringComparison.OrdinalIgnoreCase);
                if(IsPermissionMatrixOperation&&node.Kind==SecurityNodeKind.User)
                    SelectedMappingDatabase=Databases.FirstOrDefault(x=>x.Name.Equals(node.Database,StringComparison.OrdinalIgnoreCase));
            }
            Status=node?.IsPrincipal==true
                ? $"Gestionando acceso de {node.Principal}. Revise los datos y genere una solicitud."
                : "Nueva solicitud de acceso. Complete los pasos visibles.";
        }
        finally
        {
            _isStartingAccessManagement=false;
            RefreshContextCommands();
        }
    }

    private void ResetManagementForm()
    {
        ResetWindowsNameValidation();
        ResetPermissionCopy();
        ResetCreateLoginTargetValidation();
        CancelDatabaseContextLoad();
        _databaseRolesLoaded=false;_objectPermissionsLoaded=false;
        HasDatabaseAccessError=false;
        _requestSubmitted=false;
        TargetPrincipal="";SourcePrincipal="";Securable="";Justification="";ExternalTicketDigits="";
        Decision=null;SelectedPermission=null;SelectedRole=null;SelectedMappingDatabase=null;SelectedDatabaseObject=null;
        SelectedDatabaseObjects.Clear();DatabaseObjects.Clear();DatabaseRoleChoices.Clear();RoleChoices.Clear();
        ObjectPermissionRows.Clear();FilteredObjectPermissionRows.Clear();ObjectSchemaFilters.Clear();ObjectSchemaFilters.Add("Todos");ObjectTypeFilters.Clear();ObjectTypeFilters.Add("Todos");
        _objectPermissionSearch="";_selectedObjectSchemaFilter="Todos";_selectedObjectTypeFilter="Todos";
        Raise(nameof(ObjectPermissionSearch));Raise(nameof(SelectedObjectSchemaFilter));Raise(nameof(SelectedObjectTypeFilter));Raise(nameof(ObjectPermissionGrantCount));Raise(nameof(ObjectPermissionSummary));
        foreach(var database in Databases)database.IsSelected=false;
        foreach(var permission in PermissionChoices)permission.IsSelected=false;
        foreach(var permission in InitialAccessPermissionChoices)permission.IsSelected=false;
        foreach(var role in InitialAccessRoleChoices)role.IsSelected=false;
        _includeInitialAccess=false;Raise(nameof(IncludeInitialAccess));
        ResetCreateUserWizard();
        SuggestedPasswordLengthText="20";
        ClearTemporaryPassword();
        PasswordPolicyEnabled=true;PasswordExpirationEnabled=true;MustChangePassword=true;
        Raise(nameof(SelectedObjectsSummary));Raise(nameof(DatabaseRoleChangeCount));Raise(nameof(DatabaseRolesSummary));
        Raise(nameof(HasReducedPasswordSecurity));Raise(nameof(PasswordConfigurationWarning));Raise(nameof(TemporaryPasswordValidationMessage));
        SubmitCommand.Refresh();
    }

    public void ClearAccessDraft()
    {
        ResetManagementForm();
        IsManagingAccess=false;
    }

    private async Task VerifyExternalTicketAsync()
    {
        var requestedTicket=ExternalTicketDigits.Trim();
        if(string.IsNullOrWhiteSpace(requestedTicket))return;
        IsVerifyingExternalTicket=true;
        ExternalTicketValidationMessage="Consultando el ticket en adminDB...";
        try
        {
            var ticket=await _db.VerifyExternalTicketAsync(requestedTicket);
            if(ticket is null)
            {
                _verifiedExternalTicket=null;
                Justification="";
                ExternalTicketValidationMessage="No existe un ticket activo con ese identificador. Revise el dato o su estado.";
            }
            else if(!ticket.Number.Equals(requestedTicket,StringComparison.OrdinalIgnoreCase))
            {
                _verifiedExternalTicket=null;
                Justification="";
                ExternalTicketValidationMessage="adminDB devolvió un identificador distinto al consultado; el ticket no se habilitó.";
            }
            else
            {
                _verifiedExternalTicket=ticket;
                Justification=string.IsNullOrWhiteSpace(ticket.Description)?ticket.Subject:ticket.Description;
                ExternalTicketValidationMessage=$"✓ Ticket activo verificado: {ticket.Number}";
            }
        }
        catch(Exception ex)
        {
            _verifiedExternalTicket=null;
            Justification="";
            ExternalTicketValidationMessage=$"No fue posible validar el ticket en adminDB: {ex.Message}";
        }
        finally
        {
            IsVerifyingExternalTicket=false;
            Raise(nameof(ExternalTicketNumber));Raise(nameof(IsExternalTicketValid));Raise(nameof(HasVerifiedTicketDetails));Raise(nameof(VerifiedTicketSummary));
            RefreshCreateUserWizard();
            SubmitCommand.Refresh();
        }
    }

    public void BeginAccessManagement()=>_=BeginAccessManagementAsync();

    private void OnOperationChanged()
    {
        ResetWindowsNameValidation();
        Decision=null;
        if(_isSwitchingExistingAccessOperation)
        {
            Raise(nameof(IsLoginMappingOperation));Raise(nameof(IsPermissionMatrixOperation));
            Raise(nameof(RequiresRole));Raise(nameof(RequiresRoleInDetails));Raise(nameof(RequiresPermission));
            Raise(nameof(HasDatabaseAccessEditor));Raise(nameof(IsDatabaseAccessLevel));Raise(nameof(IsObjectScope));
            Raise(nameof(RequiresSecurable));Raise(nameof(PlannedChangesSummary));
            RefreshDatabaseAccessState();
            return;
        }
        CancelDatabaseContextLoad();
        _databaseRolesLoaded=false;_objectPermissionsLoaded=false;
        if(IsPermissionMatrixOperation)PermissionAction="GRANT";
        _includeInitialAccess=false;Raise(nameof(IncludeInitialAccess));
        ResetCreateUserWizard();
        SuggestedPasswordLengthText="20";
        ClearTemporaryPassword();
        PasswordPolicyEnabled=true;PasswordExpirationEnabled=true;MustChangePassword=true;
        SelectedDatabaseObject=null;
        SelectedDatabaseObjects.Clear();Raise(nameof(SelectedObjectsSummary));
        DatabaseRoleChoices.Clear();
        Raise(nameof(DatabaseRoleChangeCount));Raise(nameof(DatabaseRolesSummary));
        SelectedMappingDatabase=null;
        if(IsLoginMappingOperation)SelectedRole=null;
        DatabaseObjects.Clear();
        ObjectPermissionRows.Clear();FilteredObjectPermissionRows.Clear();
        Raise(nameof(ObjectPermissionGrantCount));Raise(nameof(ObjectPermissionSummary));
        Securable="";
        AuthenticationType=SelectedOperation?.Code switch
        {
            "CREATE_SQL_LOGIN" or "CLONE_PERMISSIONS"=>"SQL",
            "CREATE_WINDOWS_LOGIN"=>"WINDOWS",
            _=>""
        };
        RefreshRoleChoices();
        RaiseAuthenticationState();
        Raise(nameof(IsServerAccessOperation));Raise(nameof(Scopes));
        Raise(nameof(IsLoginMappingOperation));Raise(nameof(IsPermissionMatrixOperation));Raise(nameof(IsExistingAccessOperation));Raise(nameof(IsStandardAccessOperation));Raise(nameof(EditorBackActionText));Raise(nameof(IsCreateLoginOperation));Raise(nameof(IsCreateSqlLoginOperation));Raise(nameof(IsTemporaryPasswordValid));Raise(nameof(TemporaryPasswordValidationMessage));Raise(nameof(RequiresBasicAccessData));Raise(nameof(IsServerOperation));Raise(nameof(IsDatabaseOperation));Raise(nameof(IsStandardDatabaseOperation));Raise(nameof(RequiresSourcePrincipal));
        Raise(nameof(IsDatabaseAccessLevel));Raise(nameof(IsObjectScope));Raise(nameof(PermissionStepTitle));Raise(nameof(PlannedChangesSummary));
        Raise(nameof(NeedsPolicyConfiguration));Raise(nameof(PolicyConfigurationWarning));
        Raise(nameof(RequiresRole));Raise(nameof(RequiresRoleInDetails));Raise(nameof(RequiresPermission));Raise(nameof(RequiresSecurable));
        Raise(nameof(RequiresAuthenticationType));Raise(nameof(RequiresDefaultDatabase));
        Raise(nameof(OperationBadge));
        Raise(nameof(TargetPrincipalLabel));Raise(nameof(TargetPrincipalHelp));Raise(nameof(OperationGuidance));
        Raise(nameof(DestinationInstruction));Raise(nameof(SecurableLabel));Raise(nameof(SecurableHelp));
        EditMappingModeCommand?.Refresh();EditObjectPermissionsModeCommand?.Refresh();
        Raise(nameof(HasDatabaseAccessEditor));RefreshDatabaseAccessState();
        Raise(nameof(IsClonePermissionsOperation));Raise(nameof(IsBasicIdentityOperation));Raise(nameof(HasTopRequestDetails));Raise(nameof(HasBottomRequestDetails));Raise(nameof(RequiresTemporaryPassword));
        Status=SelectedOperation is null?"Seleccione una operación.":$"Operación seleccionada: {SelectedOperation.Name}. Complete únicamente los campos visibles.";
    }

    private void RefreshAvailablePermissions()
    {
        var previous=SelectedPermission?.Permission;
        AvailablePermissions.Clear();
        foreach(var permission in Permissions
                    .Where(x=>x.Scope.Equals(Scope,StringComparison.OrdinalIgnoreCase))
                    .Where(x=>PolicyEditorCatalog.CanManagePermission(x.Permission,x.Scope))
                    .Where(x=>!Scope.Equals("OBJECT",StringComparison.OrdinalIgnoreCase)
                        ||SelectedDatabaseObjects.Count==0
                        ||!ManagedDataPermissions.Contains(x.Permission)
                        ||SelectedDatabaseObjects.All(item=>item.SupportsPermission(x.Permission)))
                    .Where(x=>PermissionAction switch{"GRANT"=>x.AllowGrant,"DENY"=>x.AllowDeny,"REVOKE"=>x.AllowRevoke,_=>false})
                    .GroupBy(x=>x.Permission,StringComparer.OrdinalIgnoreCase)
                    .Select(x=>x.First())
                    .OrderBy(x=>x.Permission))
            AvailablePermissions.Add(permission);
        SelectedPermission=AvailablePermissions.FirstOrDefault(x=>x.Permission.Equals(previous,StringComparison.OrdinalIgnoreCase))
            ??AvailablePermissions.FirstOrDefault();
        PermissionChoices.Clear();
        foreach(var permission in AvailablePermissions)
        {
            var choice=new PermissionSelectionItem(permission);
            choice.PropertyChanged+=(_,args)=>
            {
                if(args.PropertyName!=nameof(PermissionSelectionItem.IsSelected))return;
                Decision=null;
                Raise(nameof(PlannedChangesSummary));
            };
            PermissionChoices.Add(choice);
        }
        Raise(nameof(PlannedChangesSummary));
    }

    private void RefreshInitialAccessPermissions()
    {
        InitialAccessPermissionChoices.Clear();
        foreach(var permission in Permissions
                    .Where(x=>x.Scope.Equals("DATABASE",StringComparison.OrdinalIgnoreCase)&&x.AllowGrant)
                    .Where(x=>ManagedDataPermissions.Contains(x.Permission))
                    .GroupBy(x=>x.Permission,StringComparer.OrdinalIgnoreCase)
                    .Select(x=>x.First())
                    .OrderBy(x=>x.Permission))
            InitialAccessPermissionChoices.Add(new(permission));
    }

    private void RefreshInitialAccessRoles()
    {
        InitialAccessRoleChoices.Clear();
        foreach(var role in Roles.OrderBy(x=>x.Name))InitialAccessRoleChoices.Add(new(role));
    }

    private void RefreshRoleChoices()
    {
        RoleChoices.Clear();
        if(!IsLoginMappingOperation)
            foreach(var role in Roles.OrderBy(x=>x.Name,StringComparer.CurrentCultureIgnoreCase))RoleChoices.Add(new(role));
    }

    private async Task LoadDatabaseRoleMembershipsAsync(SecurityTreeNode node,CancellationToken ct)
    {
        var rolesTask=_direct.GetSecurityInventoryAsync(node.ServerId,node.Database,"ROLES",ct);
        var membershipsTask=_direct.GetDatabaseRoleMembershipsAsync(node.ServerId,node.Database,node.Principal,ct);
        await Task.WhenAll(rolesTask,membershipsTask);
        ct.ThrowIfCancellationRequested();
        var roleTable=await rolesTask;
        var assigned=await membershipsTask;
        DatabaseRoleChoices.Clear();
        var allowed=Roles.Where(x=>x.Enabled).Select(x=>x.Name).ToHashSet(StringComparer.OrdinalIgnoreCase);
        var roles=roleTable.Rows.Cast<DataRow>()
            .Select(row=>new
            {
                Name=TableCell(row,"RoleName","Name"),
                Kind=TableCell(row,"RoleType","Type")
            })
            .Where(x=>!string.IsNullOrWhiteSpace(x.Name))
            .GroupBy(x=>x.Name,StringComparer.OrdinalIgnoreCase)
            .Select(x=>x.First())
            .OrderBy(x=>x.Name,StringComparer.CurrentCultureIgnoreCase);
        foreach(var role in roles)
        {
            var canChange=allowed.Contains(role.Name)
                &&!PolicyEditorCatalog.IsPermanentlyBlockedRole(role.Name)
                &&!role.Name.Equals("public",StringComparison.OrdinalIgnoreCase);
            var item=new DatabaseRoleSelectionItem(role.Name,role.Kind,canChange,assigned.Contains(role.Name));
            item.PropertyChanged+=(_,args)=>
            {
                if(args.PropertyName is not (nameof(DatabaseRoleSelectionItem.IsSelected) or nameof(DatabaseRoleSelectionItem.HasChange)))return;
                Decision=null;
                Raise(nameof(DatabaseRoleChangeCount));
                Raise(nameof(DatabaseRolesSummary));
                Raise(nameof(PlannedChangesSummary));
            };
            DatabaseRoleChoices.Add(item);
        }
        Raise(nameof(DatabaseRoleChangeCount));Raise(nameof(DatabaseRolesSummary));Raise(nameof(PlannedChangesSummary));
    }

    public async Task ExpandSecurityNodeAsync(SecurityTreeNode node)
    {
        if(!node.LoadOnExpand||node.IsLoaded)return;
        node.Children.Clear();
        try
        {
            Status=$"Cargando {node.Name.ToLowerInvariant()}…";
            switch(node.Kind)
            {
                case SecurityNodeKind.LoginGroup:
                    AddPrincipalNodes(node,await _direct.GetSecurityInventoryAsync(node.ServerId,"master","LOGINS"),SecurityNodeKind.Login,"LoginName","Name");
                    break;
                case SecurityNodeKind.DatabaseGroup:
                    var server=Servers.First(x=>x.Id==node.ServerId);
                    var selected=CopySelected(server);
                    foreach(var database in await _direct.GetDatabasesAsync([selected]))
                    {
                        var databaseNode=new SecurityTreeNode(database.Name,SecurityNodeKind.Database,node.ServerId,node.ServerName,database.Name);
                        databaseNode.Children.Add(new SecurityTreeNode("Usuarios",SecurityNodeKind.UserGroup,node.ServerId,node.ServerName,database.Name,loadOnExpand:true));
                        node.Children.Add(databaseNode);
                    }
                    break;
                case SecurityNodeKind.UserGroup:
                    AddPrincipalNodes(node,await _direct.GetSecurityInventoryAsync(node.ServerId,node.Database,"USERS"),SecurityNodeKind.User,"UserName","Name");
                    break;
            }
            if(node.Children.Count==0)
                node.Children.Add(new SecurityTreeNode("Sin elementos",SecurityNodeKind.Loading,node.ServerId,node.ServerName,node.Database));
            node.IsLoaded=true;
            ApplySecurityFilter();
            Status=$"{node.Name}: {node.Children.Count} elemento(s).";
        }
        catch(Exception ex)
        {
            node.Children.Add(new SecurityTreeNode($"No disponible: {ex.Message}",SecurityNodeKind.Error,node.ServerId,node.ServerName,node.Database));
            node.IsLoaded=true;
            Status=$"No se pudo cargar {node.Name}: {ex.Message}";
        }
    }

    public async Task SelectSecurityNodeAsync(SecurityTreeNode node)
    {
        SelectedSecurityNode=node;
        SetSelectedLoginEnabled(node.LoginEnabled);
        SecurityPermissions.Clear();
        SecurityMemberships.Clear();
        SecuritySelectionTitle=node.Name;
        SecuritySelectionSubtitle=string.IsNullOrWhiteSpace(node.Database)
            ? node.ServerName
            : $"{node.ServerName}  ·  {node.Database}";
        SecuritySelectionType=node.Kind switch
        {
            SecurityNodeKind.Login=>"LOGIN DE SERVIDOR",
            SecurityNodeKind.User=>"USUARIO DE BASE",
            SecurityNodeKind.Database=>"BASE DE DATOS",
            SecurityNodeKind.Server=>"SERVIDOR",
            _=>"CARPETA"
        };

        if(!node.IsPrincipal)
        {
            SecuritySummary="Expanda esta rama y seleccione un login o usuario para ver sus accesos.";
            return;
        }

        try
        {
            SecuritySummary="Consultando permisos y membresías…";
            Status=$"Consultando seguridad de {node.Principal}…";
            if(node.Kind==SecurityNodeKind.Login)
                SetSelectedLoginEnabled(await _direct.IsLoginEnabledAsync(node.ServerId,node.Principal));
            if(node.Kind==SecurityNodeKind.User)
            {
                try{SetSelectedUserMappedLogin(await _direct.GetMappedLoginStateAsync(node.ServerId,node.Database,node.Principal),true);}
                catch{SetSelectedUserMappedLogin(null,false);}
            }
            var details=await _direct.GetSecurityPrincipalDetailsAsync(node.ServerId,node.Database,node.Principal,node.Kind);
            if(!ReferenceEquals(SelectedSecurityNode,node))return;
            foreach(var item in details.Permissions)SecurityPermissions.Add(item);
            foreach(var item in details.Memberships.Distinct())SecurityMemberships.Add(item);
            SecuritySummary=$"{SecurityPermissions.Count} permiso(s) explícito(s) · {SecurityMemberships.Count} rol(es) asignado(s) o mapeo(s).";
            Status=IsSelectedUserManagementBlocked
                ? $"Consulta completada. La gestión está bloqueada porque el login {_selectedUserMappedLogin!.Login} está deshabilitado."
                : $"Seguridad de {node.Principal} consultada correctamente.";
        }
        catch(Exception ex)
        {
            if(!ReferenceEquals(SelectedSecurityNode,node))return;
            SecuritySummary=$"No se pudo consultar el principal: {ex.Message}";
            Status=SecuritySummary;
        }
    }

    private void BuildSecurityTree()
    {
        SecurityRoots.Clear();
        foreach(var server in Servers.Where(x=>ReferenceEquals(x,SelectedWorkingServer)).OrderBy(x=>x.Name))
        {
            var root=new SecurityTreeNode(server.Name,SecurityNodeKind.Server,server.Id,server.Name);
            root.Children.Add(new SecurityTreeNode("Logins",SecurityNodeKind.LoginGroup,server.Id,server.Name,loadOnExpand:true));
            root.Children.Add(new SecurityTreeNode("Bases de datos",SecurityNodeKind.DatabaseGroup,server.Id,server.Name,loadOnExpand:true));
            SecurityRoots.Add(root);
        }
        SelectedSecurityNode=null;
        SecurityPermissions.Clear();SecurityMemberships.Clear();
        SecuritySelectionTitle="Seleccione un login o usuario";
        SecuritySelectionSubtitle="Expanda un servidor para consultar su seguridad.";
        SecuritySelectionType="SIN SELECCIÓN";
        SecuritySummary="Los permisos y las membresías aparecerán en este panel.";
        ApplySecurityFilter();
    }

    private void ApplySecurityFilter()
    {
        var filter=SecurityFilter.Trim();
        if(string.IsNullOrWhiteSpace(filter))
        {
            foreach(var root in SecurityRoots)SetTreeVisibility(root,true);
            SecurityFilterHint="Sin filtro · la consulta es de solo lectura.";
            return;
        }

        var matches=0;
        foreach(var root in SecurityRoots)FilterTreeNode(root,filter,ref matches);
        SecurityFilterHint=$"{matches} coincidencia(s) en ramas cargadas · expanda otras carpetas para incluirlas.";
    }

    private static bool FilterTreeNode(SecurityTreeNode node,string filter,ref int matches)
    {
        var ownMatch=node.Kind is not (SecurityNodeKind.Loading or SecurityNodeKind.Error)
            &&node.Name.Contains(filter,StringComparison.CurrentCultureIgnoreCase);
        if(ownMatch)matches++;

        var descendantVisible=false;
        foreach(var child in node.Children)
            descendantVisible|=FilterTreeNode(child,filter,ref matches);

        var pendingBranch=node.LoadOnExpand&&!node.IsLoaded;
        node.IsVisible=ownMatch||descendantVisible||pendingBranch;
        if(descendantVisible)node.IsExpanded=true;
        return node.IsVisible;
    }

    private static void SetTreeVisibility(SecurityTreeNode node,bool visible)
    {
        node.IsVisible=visible;
        foreach(var child in node.Children)SetTreeVisibility(child,visible);
    }

    private static ServerItem CopySelected(ServerItem server)=>new()
    {
        Id=server.Id,Name=server.Name,Host=server.Host,Instance=server.Instance,
        WindowsAuth=server.WindowsAuth,SqlUser=server.SqlUser,Encrypt=server.Encrypt,
        TrustCertificate=server.TrustCertificate,TimeoutSeconds=server.TimeoutSeconds,
        Active=server.Active,IsSelected=true
    };

    private static void AddPrincipalNodes(SecurityTreeNode parent,DataTable table,SecurityNodeKind kind,params string[] candidateColumns)
    {
        var rows=table.Rows.Cast<DataRow>()
            .Select(row=>new{Name=TableCell(row,candidateColumns),Row=row})
            .Where(item=>!string.IsNullOrWhiteSpace(item.Name))
            .Where(item=>!IsInternalOrServicePrincipal(item.Name))
            .GroupBy(item=>item.Name,StringComparer.OrdinalIgnoreCase)
            .Select(group=>group.First())
            .OrderBy(item=>item.Name,StringComparer.CurrentCultureIgnoreCase);
        foreach(var item in rows)
        {
            bool? loginEnabled=null;
            if(kind==SecurityNodeKind.Login&&table.Columns.Contains("IsDisabled")&&!item.Row.IsNull("IsDisabled"))
                loginEnabled=!Convert.ToBoolean(item.Row["IsDisabled"]);
            parent.Children.Add(new SecurityTreeNode(item.Name,kind,parent.ServerId,parent.ServerName,parent.Database,item.Name,loginEnabled:loginEnabled));
        }
    }

    private static bool IsInternalOrServicePrincipal(string? principal)
    {
        var name=principal?.Trim()??"";
        if(string.IsNullOrWhiteSpace(name))return false;
        if(SqlSystemNames.IsReserved(name)
           ||name.StartsWith("NT AUTHORITY\\",StringComparison.OrdinalIgnoreCase)
           ||name.StartsWith("NT SERVICE\\",StringComparison.OrdinalIgnoreCase)
           ||name.StartsWith("BUILTIN\\",StringComparison.OrdinalIgnoreCase))return true;
        return name.Equals("dbo",StringComparison.OrdinalIgnoreCase)
            ||name.Equals("guest",StringComparison.OrdinalIgnoreCase)
            ||name.Equals("sys",StringComparison.OrdinalIgnoreCase)
            ||name.Equals("INFORMATION_SCHEMA",StringComparison.OrdinalIgnoreCase);
    }

    private static string TableCell(DataRow row,params string[] names)
    {
        var column=names.Select(name=>row.Table.Columns.Cast<DataColumn>().FirstOrDefault(x=>x.ColumnName.Equals(name,StringComparison.OrdinalIgnoreCase))).FirstOrDefault(x=>x is not null)
            ??row.Table.Columns.Cast<DataColumn>().FirstOrDefault();
        return column is null||row.IsNull(column)?"":Convert.ToString(row[column])?.Trim()??"";
    }
    private async Task LoadDatabasesAsync()
    {
        if(IsCreateLoginOperation){await LoadCreateUserDatabasesAsync();return;}
        try{if(SelectedWorkingServer is null)throw new InvalidOperationException("Seleccione primero un servidor de trabajo.");Status=$"Cargando bases de {SelectedWorkingServer.Name}…";SelectedMappingDatabase=null;Databases.Clear();foreach(var x in await _direct.GetDatabasesAsync([SelectedWorkingServer]))Databases.Add(x);Status=$"{Databases.Count} bases disponibles en {SelectedWorkingServer.Name}.";}catch(Exception ex){Status=ex.Message;}
    }
    private async Task LoadDatabaseObjectsAsync()
    {
        await LoadDatabaseObjectsForSelectionAsync();
        SelectedDatabaseObject=DatabaseObjects.FirstOrDefault();
    }
    public async Task LoadDatabaseObjectsForSelectionAsync()
    {
        DatabaseObjects.Clear();
        try
        {
            var selected=Databases.Where(x=>x.IsSelected).ToList();
            if(selected.Count!=1)throw new InvalidOperationException("Para seleccionar un objeto puntual, marque exactamente una base de datos.");
            Status=$"Cargando tablas, vistas, funciones y procedimientos de {selected[0].Name}…";
            foreach(var item in await _direct.GetDatabaseObjectsAsync(selected[0]))DatabaseObjects.Add(item);
            Status=$"{DatabaseObjects.Count} objeto(s) disponible(s) en {selected[0].Server} · {selected[0].Name}.";
        }
        catch(Exception ex){Status=ex.Message;}
    }
    public void ApplySelectedDatabaseObjects(IEnumerable<DatabaseObjectItem> selected)
    {
        SelectedDatabaseObjects.Clear();
        foreach(var item in selected.OrderBy(x=>x.Schema).ThenBy(x=>x.Name))SelectedDatabaseObjects.Add(item);
        SelectedDatabaseObject=SelectedDatabaseObjects.Count==1?SelectedDatabaseObjects[0]:null;
        Securable=SelectedDatabaseObjects.Count==1?SelectedDatabaseObjects[0].QualifiedName:"";
        Raise(nameof(SelectedObjectsSummary));
        RefreshAvailablePermissions();
        Raise(nameof(PlannedChangesSummary));
        Decision=null;
        Status=$"{SelectedDatabaseObjects.Count} objeto(s) seleccionado(s). Marque los permisos GRANT que se aplicarán a todos.";
    }
    private async Task LoadInventoryDatabasesAsync(){InventoryDatabases.Clear();if(InventoryServer is null)return;try{var item=new ServerItem{Id=InventoryServer.Id,Name=InventoryServer.Name,Host=InventoryServer.Host,Instance=InventoryServer.Instance,WindowsAuth=InventoryServer.WindowsAuth,SqlUser=InventoryServer.SqlUser,Encrypt=InventoryServer.Encrypt,TrustCertificate=InventoryServer.TrustCertificate,TimeoutSeconds=InventoryServer.TimeoutSeconds,Active=true,IsSelected=true};foreach(var x in await _direct.GetDatabasesAsync([item]))InventoryDatabases.Add(x.Name);InventoryDatabase=InventoryDatabases.FirstOrDefault()??"master";}catch(Exception ex){Status=ex.Message;}}
    private async Task LoadInventoryAsync(){try{if(InventoryServer is null)throw new InvalidOperationException("Seleccione un servidor.");Status="Consultando inventario de seguridad…";Inventory=(await _direct.GetSecurityInventoryAsync(InventoryServer.Id,InventoryDatabase??"master",InventoryType??"LOGINS")).DefaultView;Status=$"Consulta {InventoryType} finalizada: {Inventory.Count} registros.";}catch(Exception ex){Status=ex.Message;}}
    private AccessRequestDraft Draft(string? roleOverride=null,string? permissionOverride=null,string? securableOverride=null)
    {
        var code=SelectedOperation?.Code??"";
        return new AccessRequestDraft(
            code,
            TargetPrincipal.Trim(),
            RequiresSourcePrincipal?Null(SourcePrincipal):null,
            LoginAuthentication.CreatesLogin(code)?AuthenticationType:null,
            RequiresPermission?PermissionAction:null,
            RequiresPermission?(permissionOverride??SelectedPermission?.Permission):null,
            RequiresPermission?Scope:null,
            IsClonePermissionsOperation?CopyAccessFingerprint:RequiresSecurable?(securableOverride??Null(Securable)):null,
            RequiresRole?(roleOverride??SelectedRole?.Name):null,
            ExternalTicketNumber,
            Justification.Trim()){CopyPlan=IsClonePermissionsOperation?CurrentCopyPlan:null};
    }
    private IReadOnlyList<AccessRequestDraft> Drafts()
    {
        if(IsLoginMappingOperation||IsPermissionMatrixOperation)
        {
            var drafts=DatabaseRoleChoices
                .Where(x=>x.HasChange)
                .Select(x=>new AccessRequestDraft(
                    x.IsSelected?"ADD_ROLE_MEMBER":"REMOVE_ROLE_MEMBER",
                    TargetPrincipal.Trim(),null,null,null,null,null,null,x.Name,ExternalTicketNumber,Justification.Trim()))
                .ToList();
            if(ObjectPermissionRows.Count>0)
            {
                drafts.AddRange(ObjectPermissionRows.SelectMany(row=>row.PermissionChanges.Select(change=>new AccessRequestDraft(
                    "PERMISSION_CHANGE",TargetPrincipal.Trim(),null,null,change.Action,change.Permission,"OBJECT",row.QualifiedName,null,ExternalTicketNumber,Justification.Trim()))));
            }
            if(IsLoginMappingOperation)return drafts;
            var permissions=PermissionChoices.Where(x=>x.IsSelected).ToList();
            if(Scope.Equals("OBJECT",StringComparison.OrdinalIgnoreCase))
            {
                if(SelectedDatabaseObjects.Count>0)drafts.AddRange(SelectedDatabaseObjects.SelectMany(item=>permissions.Select(permission=>Draft(permissionOverride:permission.Name,securableOverride:item.QualifiedName))));
                else drafts.AddRange(permissions.Select(permission=>Draft(permissionOverride:permission.Name)));
            }
            else
                drafts.AddRange(permissions.Select(x=>Draft(permissionOverride:x.Name)));
            return drafts;
        }
        return [Draft()];
    }
    private sealed record SubmissionPlan(AccessRequestDraft Draft,IReadOnlyList<DatabaseItem> Targets,IReadOnlyList<AccessRequestStepDraft> Steps);
    private IReadOnlyList<SubmissionPlan> BuildSubmissionPlans(IReadOnlyList<DatabaseItem> defaultTargets)
    {
        if(IsClonePermissionsOperation)
            return [new SubmissionPlan(Draft(),defaultTargets.Select(x=>new DatabaseItem
                {ServerId=x.ServerId,Server=x.Server,Name=x.Name,IsSelected=true}).ToList(),[])];
        if(HasDatabaseAccessEditor)
        {
            var changes=Drafts();
            if(changes.Count==0)throw new InvalidOperationException("Modifique al menos un rol o permiso antes de enviar la solicitud.");
            var remaining=changes.Skip(1).Select((change,index)=>new AccessRequestStepDraft(
                index+1,change.Operation,change.PermissionAction,change.Permission,change.Scope,change.Securable,change.Role)).ToList();
            return [new SubmissionPlan(changes[0],defaultTargets,remaining)];
        }
        if(!IsCreateLoginOperation||!HasCreateUserDatabaseAccess)
            return Drafts().Select(x=>new SubmissionPlan(x,defaultTargets,[])).ToList();

        var databaseTargets=(IncludeInitialAccess?Databases.Where(x=>x.IsSelected&&x.ServerId==SelectedWorkingServer?.Id)
            :SelectedCreateUserObjectDatabase is { } objectDatabase?new[]{objectDatabase}:Enumerable.Empty<DatabaseItem>())
            .Select(x=>new DatabaseItem{ServerId=x.ServerId,Server=x.Server,Name=x.Name,IsSelected=true}).ToList();
        var steps=new List<AccessRequestStepDraft>();
        var order=1;
        steps.Add(new(order++,"CREATE_DB_USER",null,null,null,null,null));
        if(IncludeInitialAccess)
        {
            steps.AddRange(InitialAccessRoleChoices.Where(x=>x.IsSelected).Select(x=>new AccessRequestStepDraft(order++,"ADD_ROLE_MEMBER",null,null,null,null,x.Name)));
            steps.AddRange(InitialAccessPermissionChoices.Where(x=>x.IsSelected).Select(x=>new AccessRequestStepDraft(order++,"PERMISSION_CHANGE","GRANT",x.Name,"DATABASE",null,null)));
        }
        if(IncludeInitialObjectPermissions)
            steps.AddRange(CreateUserObjectRows.SelectMany(row=>row.SelectedPermissions.Select(permission=>new AccessRequestStepDraft(order++,"PERMISSION_CHANGE","GRANT",permission,"OBJECT",row.QualifiedName,null))));
        return [new SubmissionPlan(Draft(),databaseTargets,steps)];
    }
    private static string? Null(string value)=>string.IsNullOrWhiteSpace(value)?null:value.Trim();
    private async Task PreviewAsync()
    {
        try
        {
            var targets=ValidateRequest();
            if(IsClonePermissionsOperation)await ValidatePermissionCopyAsync(targets);
            var plans=BuildSubmissionPlans(targets);
            var decisions=new List<PolicyDecision>();
            foreach(var plan in plans)
            {
                decisions.Add(await _db.PreviewRequestTargetsAsync(plan.Draft,plan.Targets));
                foreach(var step in plan.Steps)decisions.Add(await _db.PreviewRequestTargetsAsync(StepAsDraft(plan.Draft,step),plan.Targets));
            }
            var denied=decisions.FirstOrDefault(x=>!x.Allowed);
            if(denied is not null)throw new InvalidOperationException(denied.Reason);
            var risk=decisions.Any(x=>x.Risk=="HIGH")?"HIGH":decisions.Any(x=>x.Risk=="MEDIUM")?"MEDIUM":decisions.First().Risk;
            var changeCount=plans.Sum(x=>x.Draft.CopyPlan?.ChangeCount??x.Steps.Count+1);
            Decision=decisions.First() with{Risk=risk,RequiresApproval=decisions.Any(x=>x.RequiresApproval),Reason=$"{plans.Count} solicitud(es) con {changeCount} cambio(s) validados por la política central."};
            if(IsClonePermissionsOperation){Status=$"1 solicitud de copia · {changeCount} cambios · {targets.Count} base(s) · Riesgo {Decision.Risk}.";return;}
            Status=plans.Count==1&&plans[0].Steps.Count>0
                ? $"1 solicitud permitida · {plans[0].Steps.Count+1} cambios incluidos · Riesgo {Decision.Risk}."
                : $"{plans.Count} cambio(s) permitido(s) · Riesgo {Decision.Risk} · requiere(n) confirmación.";
        }
        catch(Exception ex){Decision=null;Status=ex.Message;}
    }
    private async Task SubmitAsync()
    {
        try
        {
            if(SelectedSecurityNode?.Kind==SecurityNodeKind.User&&SelectedOperation?.Code is "PERMISSION_CHANGE" or "ADD_ROLE_MEMBER" or "REMOVE_ROLE_MEMBER")
                if(!await VerifyUserLoginAllowsManagementAsync(SelectedSecurityNode))return;
            var targets=ValidateRequest();
            if(IsClonePermissionsOperation)await ValidatePermissionCopyAsync(targets);
            var plans=BuildSubmissionPlans(targets);
            var creationDraft=plans.Select(x=>x.Draft).FirstOrDefault(x=>LoginAuthentication.CreatesLogin(x.Operation));
            RequestSecretData? secret=creationDraft?.AuthenticationType=="SQL"?await ProtectTemporaryPasswordAsync():null;
            foreach(var plan in plans)
            {
                var duplicateId=await FindActiveDuplicateAsync(plan.Draft,plan.Targets,plan.Steps);
                if(duplicateId is not null)
                    throw new InvalidOperationException($"Ya existe la solicitud activa #{duplicateId} con la misma operación, principal y destino. Revísela en 'Confirmar y ejecutar'.");
            }
            var ids=new List<long>();
            foreach(var plan in plans)
            {
                Decision=await _db.PreviewRequestTargetsAsync(plan.Draft,plan.Targets);
                if(!Decision.Allowed)throw new InvalidOperationException(Decision.Reason);
                foreach(var step in plan.Steps)
                {
                    var stepDecision=await _db.PreviewRequestTargetsAsync(StepAsDraft(plan.Draft,step),plan.Targets);
                    if(!stepDecision.Allowed)throw new InvalidOperationException(stepDecision.Reason);
                }
                if(creationDraft is not null&&(creationDraft.AuthenticationType!=AuthenticationType
                    ||creationDraft.Operation!=SelectedOperation?.Code||creationDraft.TargetPrincipal!=TargetPrincipal.Trim()))
                    throw new InvalidOperationException("La identidad o autenticación cambió durante la validación. Vuelva a enviar la solicitud.");
                if(creationDraft is not null)await RecheckWindowsNameBeforeSubmissionAsync(creationDraft,plan.Targets[0].ServerId);
                ids.Add(await _db.CreateRequestAsync(plan.Draft,plan.Targets,plan.Steps,secret));
            }
            _requestSubmitted=true;
            SubmitCommand.Refresh();
            ClearTemporaryPassword();
            IsManagingAccess=false;
            SelectedAccessStep=3;
            Status=$"{ids.Count} solicitud(es) enviada(s) una sola vez: {string.Join(", ",ids.Select(x=>$"#{x}"))}. Haga el doble check en 'Confirmar y ejecutar'.";
        }
        catch(Microsoft.Data.SqlClient.SqlException ex) when(ex.Number is 51332 or 51333)
        {
            Status="adminDB todavía no admite solicitudes con varios cambios de acceso. El DBA debe aplicar 21_SolicitudUnicaCambiosAcceso.sql; después vuelva a enviar esta gestión.";
        }
        catch(Microsoft.Data.SqlClient.SqlException ex) when(ex.Number==8144&&IsClonePermissionsOperation)
        {
            Status="adminDB todavía no guarda el detalle de copia por base. El DBA debe aplicar 23_DetalleCopiaPermisosPorBase.sql y volver a enviar la solicitud.";
        }
        catch(Microsoft.Data.SqlClient.SqlException ex) when(ex.Number==51342&&IsClonePermissionsOperation&&IsWindowsAuthentication)
        {
            Status="adminDB todavía requiere un destino SQL para copiar permisos. Aplique 24_AutenticacionSqlWindows.sql, ejecute 99 y reinicie la aplicación.";
        }
        catch(Exception ex){Status=ex.Message;}
    }

    private static AccessRequestDraft StepAsDraft(AccessRequestDraft parent,AccessRequestStepDraft step)=>new(
        step.Operation,parent.TargetPrincipal,null,null,step.PermissionAction,step.Permission,step.Scope,step.Securable,step.Role,parent.ExternalTicketNumber,parent.Justification);

    private async Task<RequestSecretData> ProtectTemporaryPasswordAsync()
    {
        if(!IsTemporaryPasswordValid)throw new InvalidOperationException(TemporaryPasswordValidationMessage);
        var password=TemporaryPassword;
        var policy=PasswordPolicyEnabled;var expiration=PasswordExpirationEnabled;var mustChange=MustChangePassword;
        var material=await _db.GetCryptoMaterialAsync();
        try
        {
            var envelope=new AesGcmCredentialProtector(material.MasterKey).ProtectEnvelope(password,material.KeyId);
            return new(envelope,policy,expiration,mustChange);
        }
        finally{CryptographicOperations.ZeroMemory(material.MasterKey);}
    }

    private async Task<long?> FindActiveDuplicateAsync(AccessRequestDraft draft,IReadOnlyList<DatabaseItem> targets,IReadOnlyList<AccessRequestStepDraft> steps)
    {
        if(SelectedWorkingServer is null)return null;
        var requestedTargets=targets
            .Select(x=>$"{x.ServerId}|{x.Name}")
            .ToHashSet(StringComparer.OrdinalIgnoreCase);
        var candidates=(await _db.GetRequestsAsync(serverId:SelectedWorkingServer.Id))
            .Where(x=>x.Status is "PENDING" or "APPROVED")
            .Where(x=>Same(x.Operation,draft.Operation)&&Same(x.TargetPrincipal,draft.TargetPrincipal))
            .Where(x=>Same(x.SourcePrincipal,draft.SourcePrincipal)&&Same(x.AuthenticationType,draft.AuthenticationType))
            .Where(x=>Same(x.PermissionAction,draft.PermissionAction)&&Same(x.Permission,draft.Permission))
            .Where(x=>Same(x.Scope,draft.Scope)&&Same(x.Securable,draft.Securable)&&Same(x.Role,draft.Role));
        foreach(var candidate in candidates)
        {
            var existingTargets=(await _db.GetRequestTargetsAsync(candidate.Id))
                .Select(x=>$"{x.ServerId}|{x.Name}")
                .ToHashSet(StringComparer.OrdinalIgnoreCase);
            if(!requestedTargets.SetEquals(existingTargets))continue;
            if(draft.Operation is "CREATE_SQL_LOGIN" or "CREATE_WINDOWS_LOGIN")return candidate.Id;
            if(SameSteps(candidate.Steps,steps))return candidate.Id;
        }
        return null;
    }

    private static bool Same(string? left,string? right)=>string.Equals(left?.Trim()??"",right?.Trim()??"",StringComparison.OrdinalIgnoreCase);

    private static bool SameSteps(IReadOnlyList<AccessRequestStepItem> existing,IReadOnlyList<AccessRequestStepDraft> planned)=>
        existing.Count==planned.Count&&existing.OrderBy(x=>x.Order).Zip(planned.OrderBy(x=>x.Order)).All(pair=>
            Same(pair.First.Operation,pair.Second.Operation)&&Same(pair.First.PermissionAction,pair.Second.PermissionAction)
            &&Same(pair.First.Permission,pair.Second.Permission)&&Same(pair.First.Scope,pair.Second.Scope)
            &&Same(pair.First.Securable,pair.Second.Securable)&&Same(pair.First.Role,pair.Second.Role));

    private IReadOnlyList<DatabaseItem> ValidateRequest()
    {
        if(SelectedWorkingServer is null)throw new InvalidOperationException("Seleccione primero un servidor de trabajo.");
        if(SelectedOperation is null)throw new InvalidOperationException("Seleccione una operación desde el árbol de seguridad.");
        if(NeedsPolicyConfiguration)throw new InvalidOperationException(PolicyConfigurationWarning);
        if(!CanUseValidatedWindowsName)throw new InvalidOperationException("Compruebe la cuenta de Windows antes de enviar la solicitud. "+WindowsNameValidationMessage);
        if(IsClonePermissionsOperation&&!CanSubmitPermissionCopy)throw new InvalidOperationException(CopyAccessMessage+" "+CopyTargetValidationMessage);
        if(RequiresAuthenticationType)LoginAuthentication.Validate(SelectedOperation!.Code,TargetPrincipal.Trim(),AuthenticationType);
        if(IsCreateLoginOperation&&!IsCreateLoginTargetAvailable)throw new InvalidOperationException(CreateLoginTargetValidationMessage);
        if(HasDatabaseAccessEditor&&!CanEditDatabaseAccess)
            throw new InvalidOperationException(IsLoadingDatabaseAccess?"Espere a que termine la consulta de la base seleccionada.":DatabaseAccessMessage);
        if(string.IsNullOrWhiteSpace(TargetPrincipal))throw new InvalidOperationException($"Complete '{TargetPrincipalLabel}'.");
        if(IsInternalOrServicePrincipal(TargetPrincipal))throw new InvalidOperationException("Las cuentas internas del sistema o de servicios no se pueden administrar desde esta aplicación.");
        if(RequiresSourcePrincipal&&string.IsNullOrWhiteSpace(SourcePrincipal))throw new InvalidOperationException("Indique el principal origen que se clonará.");
        if(RequiresSourcePrincipal&&IsInternalOrServicePrincipal(SourcePrincipal))throw new InvalidOperationException("Una cuenta interna del sistema o de servicios no puede utilizarse como usuario pivote.");
        var hasDirectPermissions=PermissionChoices.Any(x=>x.IsSelected)||ObjectPermissionRows.Any(x=>x.HasChange);
        var hasRoleChanges=DatabaseRoleChoices.Any(x=>x.HasChange);
        if(HasDatabaseAccessEditor&&!hasDirectPermissions&&!hasRoleChanges)throw new InvalidOperationException("Modifique al menos un rol o permiso directo para enviar la solicitud.");
        if(RequiresRole&&!IsLoginMappingOperation&&SelectedRole is null)throw new InvalidOperationException("Seleccione un rol aprobado.");
        if(RequiresPermission&&!IsPermissionMatrixOperation&&SelectedPermission is null)throw new InvalidOperationException("No existe un permiso permitido para la acción y el ámbito seleccionados.");
        if(RequiresSecurable&&IsPermissionMatrixOperation&&PermissionChoices.Any(x=>x.IsSelected))
        {
            if(Scope!="OBJECT"||SelectedDatabaseObjects.Count==0)DirectSqlServerService.ValidatePermissionTarget(Scope,Securable);
        }
        if(RequiresSecurable&&!IsPermissionMatrixOperation&&string.IsNullOrWhiteSpace(Securable))throw new InvalidOperationException($"Seleccione '{SecurableLabel}' ({SecurableHelp}).");
        if(RequiresSecurable&&!IsPermissionMatrixOperation)DirectSqlServerService.ValidatePermissionTarget(Scope,Securable);
        if(RequiresDefaultDatabase&&string.IsNullOrWhiteSpace(Securable))throw new InvalidOperationException("Indique la base de datos predeterminada del login.");
        if(!IsExternalTicketValid)throw new InvalidOperationException("Valide un ticket activo en adminDB antes de continuar.");
        if(Justification.Trim().Length<10)throw new InvalidOperationException("El ticket validado no contiene una descripción o asunto suficiente para usarlo como motivo.");
        if(RequiresTemporaryPassword&&!IsTemporaryPasswordValid)throw new InvalidOperationException(TemporaryPasswordValidationMessage);

        if(IsCreateLoginOperation&&HasCreateUserDatabaseAccess)
        {
            if(CreateUserMappingValidationMessage.Length>0)throw new InvalidOperationException(CreateUserMappingValidationMessage);
            if(CreateUserObjectsValidationMessage.Length>0)throw new InvalidOperationException(CreateUserObjectsValidationMessage);
        }

        if(IsServerOperation)
        {
            return [new DatabaseItem
            {
                ServerId=SelectedWorkingServer.Id,Server=SelectedWorkingServer.Name,Name="master",IsSelected=true
            }];
        }

        var databaseTargets=Databases.Where(x=>x.IsSelected&&x.ServerId==SelectedWorkingServer.Id).ToList();
        if(databaseTargets.Count==0)throw new InvalidOperationException("Seleccione al menos una base de datos destino.");
        if(IsLoginMappingOperation&&databaseTargets.Count!=1)throw new InvalidOperationException("Seleccione exactamente una base de datos para modificar el acceso del login.");
        if(RequiresPermission&&hasDirectPermissions&&Scope!="DATABASE"&&databaseTargets.Count!=1)throw new InvalidOperationException("Los permisos sobre esquemas, objetos o columnas requieren exactamente una base de datos destino.");
        if(RequiresPermission&&hasDirectPermissions&&Scope=="OBJECT"&&ObjectPermissionRows.Count==0&&SelectedDatabaseObjects.Any(x=>x.ServerId!=databaseTargets[0].ServerId||!x.Database.Equals(databaseTargets[0].Name,StringComparison.OrdinalIgnoreCase)))
            throw new InvalidOperationException("La base de datos destino cambió. Vuelva a seleccionar los objetos protegibles.");
        return databaseTargets;
    }
    private async Task LoadRequestsAsync()
    {
        try
        {
            Requests.Clear();_allActiveRequests.Clear();
            Raise(nameof(PendingRequestCount));Raise(nameof(PendingRequestBadge));
            if(SelectedWorkingServer is null)return;

            var serverId=SelectedWorkingServer.Id;
            var active=new List<AccessRequestItem>();
            foreach(var request in await _db.GetRequestsAsync(serverId:serverId))
            {
                // También verifica el filtro cuando adminDB conserva la firma anterior
                // del procedimiento y el gateway debe usar el modo de compatibilidad.
                var targets=await _db.GetRequestTargetsAsync(request.Id);
                var targetServers=targets.Select(x=>x.ServerId).Distinct().ToList();
                if(targetServers.Count!=1||targetServers[0]!=serverId)continue;
                if(request.Status is "PENDING" or "APPROVED")active.Add(request with{DestinationSummary=string.Join(", ",targets.Select(x=>$"{x.Server} / {x.Name}"))});
            }
            foreach(var request in active.OrderByDescending(x=>x.Id))_allActiveRequests.Add(request);
            Raise(nameof(PendingRequestCount));Raise(nameof(PendingRequestBadge));
            ApplyActiveRequestFilter();
        }
        catch(Exception ex){Status=ex.Message;}
    }
    private void ApplyActiveRequestFilter()
    {
        Requests.Clear();
        var filter=RequestFilter.Trim();
        foreach(var request in _allActiveRequests.Where(x=>string.IsNullOrWhiteSpace(filter)
            ||x.ExternalTicketNumber.Contains(filter,StringComparison.OrdinalIgnoreCase)
            ||x.TargetPrincipal.Contains(filter,StringComparison.OrdinalIgnoreCase)
            ||x.Operation.Contains(filter,StringComparison.OrdinalIgnoreCase)))Requests.Add(request);
    }
    private async Task ApproveAsync(bool approve)
    {
        try
        {
            if(SelectedRequest is null)throw new InvalidOperationException("Seleccione una solicitud.");
            if(approve&&SelectedRequest.Operation=="CLONE_PERMISSIONS"&&SelectedRequest.CopyPlan is null)
                throw new InvalidOperationException("Esta solicitud de copia anterior no guardó el detalle por base. Rechácela y genere una nueva después de aplicar el script 23.");
            var requestId=SelectedRequest.Id;
            await _db.ApproveRequestAsync(requestId,approve,ApprovalComment);
            await LoadRequestsAsync();
            SelectedRequest=Requests.FirstOrDefault(x=>x.Id==requestId);
            ApprovalComment="";
            Status=approve
                ? $"Solicitud #{requestId} confirmada. Revise la fila seleccionada y presione 'Ejecutar confirmada'."
                : $"Solicitud #{requestId} rechazada.";
        }
        catch(Exception ex){Status=ex.Message;}
    }
    private async Task ExecuteApprovedAsync()
    {
        try
        {
            var request=SelectedRequest??throw new InvalidOperationException("Seleccione una solicitud confirmada.");
            if(request.Status!="APPROVED")throw new InvalidOperationException("La solicitud no está confirmada.");
            if(request.Operation=="CLONE_PERMISSIONS"&&request.CopyPlan is null)
                throw new InvalidOperationException("Esta copia anterior no tiene un desglose guardado. Genere una solicitud nueva con los permisos por base.");
            var workingServerId=SelectedWorkingServer?.Id??throw new InvalidOperationException("Seleccione un servidor de trabajo.");
            var targets=await _db.GetRequestTargetsAsync(request.Id);
            var check=await _db.PreviewRequestTargetsAsync(new(request.Operation,request.TargetPrincipal,Null(request.SourcePrincipal),Null(request.AuthenticationType),Null(request.PermissionAction),Null(request.Permission),Null(request.Scope),Null(request.Securable),Null(request.Role),request.ExternalTicketNumber,request.Justification),targets);
            if(!check.Allowed)throw new InvalidOperationException($"La política cambió y ahora bloquea la solicitud: {check.Reason}");
            var steps=await _db.GetRequestStepsAsync(request.Id);
            if(steps.Count!=request.StepCount)throw new InvalidOperationException("El listado de cambios está incompleto. Vuelva a cargar la solicitud.");
            foreach(var step in steps)
            {
                var stepCheck=await _db.PreviewRequestTargetsAsync(new(step.Operation,request.TargetPrincipal,null,null,Null(step.PermissionAction),Null(step.Permission),Null(step.Scope),Null(step.Securable),Null(step.Role),request.ExternalTicketNumber,request.Justification),targets);
                if(!stepCheck.Allowed)throw new InvalidOperationException($"La política cambió y ahora bloquea el paso {step.Order}: {stepCheck.Reason}");
            }
            var password=request.AuthenticationType=="WINDOWS"?"":ExecutionPassword;
            var passwordPolicy=true;var passwordExpiration=true;var mustChangePassword=true;
            var secret=LoginAuthentication.CreatesLogin(request.Operation)&&request.AuthenticationType=="SQL"
                ?await _db.GetRequestSecretAsync(request.Id):null;
            if(secret is not null)
            {
                var material=await _db.GetCryptoMaterialAsync();
                try{password=new AesGcmCredentialProtector(material.MasterKey).Unprotect(secret.Envelope);}
                finally{CryptographicOperations.ZeroMemory(material.MasterKey);}
                passwordPolicy=secret.PasswordPolicy;passwordExpiration=secret.PasswordExpiration;mustChangePassword=secret.MustChangePassword;
            }
            if(SelectedWorkingServer?.Id!=workingServerId||targets.Any(x=>x.ServerId!=workingServerId))
                throw new InvalidOperationException("La solicitud no pertenece exclusivamente al servidor de trabajo seleccionado.");
            Results.Clear();
            foreach(var result in await _direct.ExecuteApprovedRequestAsync(request,targets,password,steps,passwordPolicy,passwordExpiration,mustChangePassword))Results.Add(result);
            var success=Results.Count>0&&Results.All(x=>x.Success);
            var policyDetail=LoginAuthentication.CreatesLogin(request.Operation)?$" Autenticación: {request.AuthenticationType}.":"";
            if(LoginAuthentication.CreatesLogin(request.Operation)&&request.AuthenticationType=="SQL")
                policyDetail+=$" Política: CHECK_POLICY={(passwordPolicy?"ON":"OFF")}, CHECK_EXPIRATION={(passwordExpiration?"ON":"OFF")}, MUST_CHANGE={(mustChangePassword?"ON":"OFF")}.";
            if(request.Operation=="CLONE_PERMISSIONS")policyDetail+=$" Origen: {request.SourcePrincipal}; destino nuevo: {request.TargetPrincipal}. "+string.Join(" | ",Results.Where(x=>x.Success).Select(x=>$"{x.Server}/{x.Database}: {x.Message}"));
            var errors=string.Join(" | ",Results.Where(x=>!x.Success).Select(x=>$"{x.Server}/{x.Database}: {x.Message}"));
            var detail=$"{Results.Count(x=>x.Success)} correctos; {Results.Count(x=>!x.Success)} fallidos.{policyDetail}{(errors.Length>0?$" {errors}":"")}";
            if(detail.Length>2000)detail=detail[..2000];
            await _db.MarkRequestExecutedAsync(request.Id,success,detail);
            await LoadRequestsAsync();
            Status=$"Solicitud #{request.Id}: {detail}";
        }
        catch(Exception ex){Status=ex.Message;}
        finally{ExecutionPassword="";}
    }
}

