namespace SqlAccessAdmin.Models;

/// <summary>Reserved names must never be offered as manageable SQL objects.</summary>
public static class SqlSystemNames
{
    public static bool IsReserved(string? name) => name?.Contains("##", StringComparison.Ordinal) == true;
}
