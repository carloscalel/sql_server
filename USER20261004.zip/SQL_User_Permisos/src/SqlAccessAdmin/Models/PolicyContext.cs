namespace SqlAccessAdmin.Models;

public sealed record PolicyContext(int ServerId = 0, string Database = "")
{
    public static PolicyContext General { get; } = new();
    public string Level => Database.Length > 0 ? "DATABASE" : ServerId > 0 ? "INSTANCE" : "GENERAL";
    public string LevelDisplay => Level switch { "DATABASE" => "Base de datos", "INSTANCE" => "Instancia", _ => "General" };
    public void Validate()
    {
        if (ServerId < 0 || Database.Length > 128 || (ServerId == 0 && Database.Length > 0))
            throw new InvalidOperationException("Seleccione una instancia válida antes de elegir una base de datos.");
    }
    public static string OriginDisplay(string origin) => origin switch
    { "DATABASE" => "Base de datos", "INSTANCE" => "Instancia", "DISCOVERED" => "Pendiente de autorización", _ => "General" };
}

public sealed record PolicyServerChoice(int Id, string Name);
public sealed record PolicyDatabaseChoice(string Name, string Display);
public sealed record DiscoveredPolicyRole(string Name, string Kind, string RoleScope, string Description);
public sealed record DiscoveredPolicyPermission(string Permission, string Scope);
public sealed record PolicyDiscoveryResult(IReadOnlyList<DiscoveredPolicyRole> Roles)
{ public IReadOnlyList<DiscoveredPolicyPermission> Permissions { get; init; } = []; }

public sealed record SqlPermissionScope(string Code, string SqlClass, int Parts, bool IsServer = false);
public static class SqlPermissionSafety
{
    public static IReadOnlyList<SqlPermissionScope> Scopes { get; } =
    [new("DATABASE", "DATABASE", 0), new("OBJECT", "OBJECT", 2), new("SCHEMA", "SCHEMA", 1),
     new("COLUMN", "OBJECT", 3), new("SERVER", "SERVER", 0, true),
     new("USER", "USER", 1), new("ROLE", "ROLE", 1), new("APPLICATION_ROLE", "APPLICATION ROLE", 1),
     new("TYPE", "TYPE", 2), new("XML_SCHEMA", "XML SCHEMA COLLECTION", 2),
     new("ASSEMBLY", "ASSEMBLY", 1), new("CERTIFICATE", "CERTIFICATE", 1),
     new("ASYMMETRIC_KEY", "ASYMMETRIC KEY", 1), new("SYMMETRIC_KEY", "SYMMETRIC KEY", 1),
     new("DB_CREDENTIAL", "DATABASE SCOPED CREDENTIAL", 1), new("CREDENTIAL", "CREDENTIAL", 1, true),
     new("FULLTEXT_CATALOG", "FULLTEXT CATALOG", 1), new("FULLTEXT_STOPLIST", "FULLTEXT STOPLIST", 1),
     new("SEARCH_PROPERTY_LIST", "SEARCH PROPERTY LIST", 1),
     new("SERVICE", "SERVICE", 1), new("CONTRACT", "CONTRACT", 1), new("MESSAGE_TYPE", "MESSAGE TYPE", 1),
     new("REMOTE_BINDING", "REMOTE SERVICE BINDING", 1), new("ROUTE", "ROUTE", 1),
     new("EXTERNAL_LANGUAGE", "EXTERNAL LANGUAGE", 1), new("EXTERNAL_LIBRARY", "EXTERNAL LIBRARY", 1),
     new("LOGIN", "LOGIN", 1, true), new("SERVER_ROLE", "SERVER ROLE", 1, true),
     new("ENDPOINT", "ENDPOINT", 1, true), new("AVAILABILITY_GROUP", "AVAILABILITY GROUP", 1, true)];
    public static SqlPermissionScope? Scope(string code) => Scopes.FirstOrDefault(x => x.Code == code);
    public static IReadOnlyList<DiscoveredPolicyPermission> DiscoverPermissions(string name, string classDescription)
    {
        var sqlClass = classDescription.Replace('_', ' ');
        var scopes = Scopes.Where(x => x.Code != "COLUMN" && (x.SqlClass == sqlClass
            || x.SqlClass == "OBJECT" && sqlClass == "OBJECT OR COLUMN")).ToList();
        if (!IsPermissionName(name) || scopes.Count == 0)
            throw new InvalidOperationException("La versión de SQL Server contiene un permiso o ámbito no reconocido: "
                + name + " / " + sqlClass + ". No se publicó un catálogo incompleto.");
        var result = scopes.Select(x => new DiscoveredPolicyPermission(name, x.Code)).ToList();
        if (sqlClass is "OBJECT" or "OBJECT OR COLUMN" && name is "SELECT" or "UPDATE" or "REFERENCES" or "UNMASK")
            result.Add(new(name, "COLUMN"));
        return result;
    }
    public static bool IsPermissionName(string name) => name.Length is > 0 and <= 128 && name[0] != ' ' && name[^1] != ' '
        && name.All(c => c is >= 'A' and <= 'Z' or ' ');
    public static bool Supports(string name, string scope) => IsPermissionName(name) && Scope(scope) is not null
        && (scope != "COLUMN" || name is "SELECT" or "UPDATE" or "REFERENCES" or "UNMASK");
}
