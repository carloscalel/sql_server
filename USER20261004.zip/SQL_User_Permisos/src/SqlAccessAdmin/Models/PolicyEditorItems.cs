using SqlAccessAdmin.Infrastructure;

namespace SqlAccessAdmin.Models;

public static class PolicyEditorCatalog
{
    public static IReadOnlyList<string> Permissions { get; } = ["SELECT", "INSERT", "UPDATE", "DELETE", "EXECUTE"];
    public static IReadOnlyList<string> Scopes { get; } = ["DATABASE", "OBJECT"];
    public static IReadOnlyList<string> SupportedPermissions { get; } = ["SELECT", "INSERT", "UPDATE", "DELETE", "EXECUTE", "REFERENCES"];
    public static IReadOnlyList<string> SupportedScopes { get; } = SqlPermissionSafety.Scopes.Select(x => x.Code).ToArray();
    public static bool CanManagePermission(string name, string scope) => SqlPermissionSafety.Supports(name, scope);
    public static bool RequiresPermissionActivation(string name, string scope) => CanManagePermission(name, scope)
        && (!Permissions.Contains(name) || !Scopes.Contains(scope));
    public static bool IsPermanentlyBlockedRole(string name) => SqlSystemNames.IsReserved(name) || name.Equals("public", StringComparison.OrdinalIgnoreCase);
    private static readonly HashSet<string> ProtectedRoles = new(StringComparer.OrdinalIgnoreCase)
    { "public", "sysadmin", "securityadmin", "serveradmin", "setupadmin", "processadmin", "diskadmin", "bulkadmin",
      "db_owner", "db_securityadmin", "db_accessadmin", "db_ddladmin", "db_backupoperator" };
    public static bool IsFixedRole(string name) => new[]
    { "db_datareader", "db_datawriter", "db_denydatareader", "db_denydatawriter", "db_owner", "db_securityadmin", "db_accessadmin", "db_ddladmin", "db_backupoperator" }
        .Contains(name, StringComparer.OrdinalIgnoreCase);

    public static string RoleProtection(string name, IEnumerable<DenyRule> rules, bool specialActivationApproved = false)
    {
        if (IsPermanentlyBlockedRole(name)) return "Este rol de servidor o de sistema no se administra desde la aplicación.";
        var block = rules.FirstOrDefault(x => x.Active && !specialActivationApproved && (x.Category == "SERVER_ROLE" || x.Category == "DATABASE_ROLE")
            && x.Value.Equals(name, StringComparison.OrdinalIgnoreCase));
        if (block is not null) return string.IsNullOrWhiteSpace(block.Reason) ? "Bloqueado por la política central." : block.Reason;
        return !specialActivationApproved && ProtectedRoles.Contains(name) ? "Bloqueado por seguridad de la aplicación." : "";
    }

    public static string PermissionProtection(string name, string scope, IEnumerable<DenyRule> rules, bool specialActivationApproved = false)
    {
        if (!CanManagePermission(name, scope)) return "Esta combinación no es compatible con las operaciones SQL admitidas por la aplicación.";
        if (specialActivationApproved) return "";
        var block = rules.FirstOrDefault(x => x.Active && x.Category == "PERMISSION" && x.Value.Equals(name, StringComparison.OrdinalIgnoreCase));
        if (block is not null) return string.IsNullOrWhiteSpace(block.Reason) ? "Bloqueado por la política central." : block.Reason;
        return RequiresPermissionActivation(name, scope) ? scope switch
        {
            "SCHEMA" => "Afecta a los objetos actuales y futuros del esquema. Requiere autorización especial.",
            "COLUMN" => "Afecta a una columna concreta. Un GRANT de columna puede prevalecer sobre un DENY de objeto.",
            _ => "Puede ampliar los privilegios del destinatario. Requiere autorización especial."
        } : "";
    }

    public static string CategoryDisplay(string category) => category switch
    {
        "PERMISSION" => "Permiso", "DATABASE_ROLE" => "Rol de base", "SERVER_ROLE" => "Rol de servidor",
        "OPERATION" => "Operación", "CLAUSE" => "Opción SQL", _ => category
    };
    public static bool CanUseRole(PolicyRole role, IEnumerable<DenyRule> rules) => role.Enabled
        && (role.RoleScope != "SERVER" || role.SpecialActivationApproved)
        && RoleProtection(role.Name, rules, role.SpecialActivationApproved).Length == 0;
    public static bool CanUsePermission(PolicyPermission permission, IEnumerable<DenyRule> rules) => permission.Enabled && permission.Supported
        && PermissionProtection(permission.Permission, permission.Scope, rules, permission.SpecialActivationApproved).Length == 0;
}

public abstract class PolicyEditorItem : BindableBase
{
    public abstract bool IsDirty { get; }
    private readonly string _protectionReason;
    protected bool SupportsSpecialActivation { get; }
    public string ProtectionReason => HasSpecialActivation && SupportsSpecialActivation ? "" : _protectionReason;
    public bool IsProtected => ProtectionReason.Length > 0;
    public bool CanEdit => !IsProtected;
    public abstract bool IsAllowed { get; set; }
    public abstract bool HasSpecialActivation { get; }
    public abstract string SpecialActivationReason { get; }
    public virtual bool CanRequestSpecialActivation => false;
    public RelayCommand? ActivateCommand { get; internal set; }
    public RelayCommand? RestoreCommand { get; internal set; }
    public abstract string Origin { get; }
    public string OriginDisplay => PolicyContext.OriginDisplay(Origin);
    public bool CanRestoreInheritance { get; internal set; }
    public string SpecialActivationDisplay => HasSpecialActivation ? "Autorización especial" : "";
    public string StateDisplay => IsProtected ? "Protegido" : IsAllowed ? "Permitido" : "Bloqueado";
    public string ChangeDisplay => IsDirty ? "Sin guardar" : "";
    protected PolicyEditorItem(string protectionReason, bool supportsSpecialActivation)
    { _protectionReason = protectionReason; SupportsSpecialActivation = supportsSpecialActivation; }
    protected virtual void Changed()
    {
        Raise(nameof(IsDirty)); Raise(nameof(IsAllowed)); Raise(nameof(StateDisplay)); Raise(nameof(ChangeDisplay));
        Raise(nameof(ProtectionReason)); Raise(nameof(IsProtected)); Raise(nameof(CanEdit)); Raise(nameof(CanRequestSpecialActivation));
        Raise(nameof(HasSpecialActivation)); Raise(nameof(SpecialActivationDisplay)); Raise(nameof(SpecialActivationReason));
    }
}

public sealed class PermissionPolicyItem : PolicyEditorItem
{
    private PolicyPermission _saved;
    private bool _enabled, _allowGrant, _allowDeny, _allowRevoke;
    public string Permission => _saved.Permission;
    public string Scope => _saved.Scope;
    public string HelpDescription => SqlAccessDescriptions.Permission(Permission, Scope);
    public override string Origin => _saved.Origin;
    public override bool HasSpecialActivation => _saved.SpecialActivationApproved;
    public override string SpecialActivationReason => _saved.SpecialActivationReason;
    public override bool CanRequestSpecialActivation => IsProtected && SupportsSpecialActivation;
    public string Description => Permission switch
    {
        "SELECT" => "Leer datos", "INSERT" => "Agregar datos", "UPDATE" => "Modificar datos",
        "DELETE" => "Eliminar datos", "EXECUTE" => "Ejecutar", "REFERENCES" => "Referenciar objetos",
        "CONTROL" => "Control completo del destino", "CONTROL SERVER" => "Control total de la instancia",
        "ALTER" => "Modificar el destino", "ALTER ANY USER" => "Administrar usuarios",
        "IMPERSONATE" => "Suplantar la identidad", "VIEW DEFINITION" => "Consultar definiciones",
        "UNMASK" => "Ver datos sin enmascarar", _ => Permission
    };
    public string ScopeDisplay => Scope switch
    {
        "DATABASE" => "Toda la base", "OBJECT" => "Objetos específicos", "COLUMN" => "Columnas",
        "SCHEMA" => "Esquema", "SERVER" => "Instancia", "USER" => "Usuario", "ROLE" => "Rol",
        "APPLICATION_ROLE" => "Rol de aplicación", "TYPE" => "Tipo de datos", "XML_SCHEMA" => "Colección XML",
        "ASSEMBLY" => "Ensamblado", "CERTIFICATE" => "Certificado", "ASYMMETRIC_KEY" => "Clave asimétrica",
        "SYMMETRIC_KEY" => "Clave simétrica", "DB_CREDENTIAL" => "Credencial de base", "CREDENTIAL" => "Credencial de instancia",
        "FULLTEXT_CATALOG" => "Catálogo de texto completo", "FULLTEXT_STOPLIST" => "Lista de exclusión",
        "SEARCH_PROPERTY_LIST" => "Lista de propiedades de búsqueda", "SERVICE" => "Servicio", "CONTRACT" => "Contrato",
        "MESSAGE_TYPE" => "Tipo de mensaje", "REMOTE_BINDING" => "Vínculo de servicio remoto", "ROUTE" => "Ruta",
        "EXTERNAL_LANGUAGE" => "Lenguaje externo", "EXTERNAL_LIBRARY" => "Biblioteca externa", "LOGIN" => "Login",
        "SERVER_ROLE" => "Rol de servidor", "ENDPOINT" => "Punto de conexión", "AVAILABILITY_GROUP" => "Grupo de disponibilidad", _ => Scope
    };
    public string ScopeHelp => Scope switch
    {
        "DATABASE" => "Aplica a toda la base de datos seleccionada.",
        "SCHEMA" => "Aplica a los objetos actuales y futuros del esquema seleccionado.",
        "COLUMN" => "Aplica solo a una columna de un objeto de la base seleccionada.",
        _ => "Aplica solo a los objetos seleccionados que admitan este permiso."
    };
    public override bool IsAllowed
    {
        get => _enabled && CanEdit;
        set
        {
            if (!CanEdit || !Set(ref _enabled, value)) return;
            // Habilitar una regla vacía debe producir una opción utilizable.
            if (value && !_allowGrant && !_allowDeny && !_allowRevoke) { AllowGrant = true; AllowRevoke = true; }
            Changed();
        }
    }
    public bool AllowGrant { get => _allowGrant; set { if (CanEdit && Set(ref _allowGrant, value)) Changed(); } }
    public bool AllowDeny { get => _allowDeny; set { if (CanEdit && Set(ref _allowDeny, value)) Changed(); } }
    public bool AllowRevoke { get => _allowRevoke; set { if (CanEdit && Set(ref _allowRevoke, value)) Changed(); } }
    public bool CanEditActions => CanEdit && IsAllowed;
    public override bool IsDirty => _enabled != _saved.Enabled || _allowGrant != _saved.AllowGrant || _allowDeny != _saved.AllowDeny || _allowRevoke != _saved.AllowRevoke;
    public string ActionSummary => !IsAllowed ? "" : AllowDeny
        ? string.Join(" · ", new[] { AllowGrant ? "Asignar" : "", "Denegar", AllowRevoke ? "Retirar" : "" }.Where(x => x.Length > 0))
        : (AllowGrant, AllowRevoke) switch { (true, true) => "Asignar y retirar", (true, false) => "Solo asignar", (false, true) => "Solo retirar", _ => "Elija una acción" };
    public string AuditDisplay => _saved.ApprovedAt == default ? "Sin cambios registrados"
        : $"{_saved.ApprovedBy} · {_saved.ApprovedAt:yyyy-MM-dd HH:mm} UTC";
    public PermissionPolicyItem(PolicyPermission rule, string protectionReason = "") : base(protectionReason,
        rule.Supported && PolicyEditorCatalog.CanManagePermission(rule.Permission, rule.Scope))
    { _saved = rule; _enabled = rule.Enabled; _allowGrant = rule.AllowGrant; _allowDeny = rule.AllowDeny; _allowRevoke = rule.AllowRevoke; }
    public PolicyPermission ToPolicy(string principal, DateTime time) =>
        new(Permission, Scope, AllowGrant, AllowDeny, AllowRevoke, _enabled, principal, time)
        { SpecialActivationApproved = _enabled && HasSpecialActivation, SpecialActivationReason = SpecialActivationReason, Origin = Origin, Supported = _saved.Supported };
    public void AcceptSaved(PolicyPermission saved) { _saved = saved; Changed(); Raise(nameof(AuditDisplay)); Raise(nameof(OriginDisplay)); }
    protected override void Changed()
    {
        base.Changed(); Raise(nameof(CanEditActions)); Raise(nameof(ActionSummary));
    }
}

public sealed class RolePolicyItem : PolicyEditorItem
{
    private PolicyRole _saved;
    private bool _enabled, _isNew;
    private string _notes;
    public string Name => _saved.Name;
    public override string Origin => _saved.Origin;
    public string RoleScope => _saved.RoleScope;
    public string Kind => _saved.Kind;
    public override bool HasSpecialActivation => _saved.SpecialActivationApproved;
    public override string SpecialActivationReason => _saved.SpecialActivationReason;
    public override bool CanRequestSpecialActivation => IsProtected && SupportsSpecialActivation;
    public string KindDisplay => (Kind == "FIXED" ? "Integrado" : "Personalizado") + (RoleScope == "SERVER" ? " · Servidor" : " · Base de datos");
    public bool HasCustomDescription => Kind != "FIXED";
    public bool CanEditDescription => HasCustomDescription && CanEdit;
    public string Notes { get => _notes; set { if (CanEditDescription && Set(ref _notes, value)) Changed(); } }
    public string Description => Kind == "FIXED" && SqlAccessDescriptions.FixedRole(Name, RoleScope) is {} builtIn
        ? builtIn : string.IsNullOrWhiteSpace(Notes) ? "Sin descripción" : Notes;
    public bool NotesChanged => _isNew || Notes != _saved.Notes;
    public override bool IsAllowed { get => _enabled && CanEdit; set { if (CanEdit && Set(ref _enabled, value)) Changed(); } }
    public override bool IsDirty => _isNew || _enabled != _saved.Enabled || Notes != _saved.Notes;
    public string AuditDisplay => _isNew ? "Rol nuevo · sin guardar" : $"{_saved.ApprovedBy} · {_saved.ApprovedAt:yyyy-MM-dd HH:mm} UTC";
    public RolePolicyItem(PolicyRole rule, string protectionReason = "", bool isNew = false, bool supportsSpecialActivation = true)
        : base(protectionReason, supportsSpecialActivation && !PolicyEditorCatalog.IsPermanentlyBlockedRole(rule.Name))
    { _saved = rule; _enabled = rule.Enabled; _notes = rule.Notes; _isNew = isNew; }
    public PolicyRole ToPolicy(string principal, DateTime time) => new(Name, Kind, _enabled, principal, time, Notes.Trim())
    { SpecialActivationApproved = _enabled && HasSpecialActivation, SpecialActivationReason = SpecialActivationReason, Origin = Origin, RoleScope = RoleScope };
    public void AcceptSaved(PolicyRole saved) { _saved = saved; _notes = saved.Notes; _isNew = false; Changed(); Raise(nameof(Notes)); Raise(nameof(AuditDisplay)); }
    protected override void Changed()
    {
        base.Changed(); Raise(nameof(Description)); Raise(nameof(CanEditDescription));
    }
}

public sealed record PolicyBlockItem(DenyRule Rule)
{
    public string CategoryDisplay => PolicyEditorCatalog.CategoryDisplay(Rule.Category);
    public string Value => Rule.Value;
    public string Reason => Rule.Reason;
    public string SourceDisplay => Rule.IsSystem ? "Sistema" : "Administrador";
}
