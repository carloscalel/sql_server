namespace SqlAccessAdmin.Models;

public static class LoginAuthentication
{
    public static bool CreatesLogin(string operation)=>operation is "CREATE_SQL_LOGIN" or "CREATE_WINDOWS_LOGIN" or "CLONE_PERMISSIONS";
    public static string CreationOperation(string authenticationType)=>authenticationType switch
    {
        "SQL"=>"CREATE_SQL_LOGIN",
        "WINDOWS"=>"CREATE_WINDOWS_LOGIN",
        _=>throw new InvalidOperationException("Seleccione cómo iniciará sesión el usuario: con una cuenta SQL o con una cuenta de Windows.")
    };

    public static void Validate(string operation,string target,string? authenticationType)
    {
        CreationOperation(authenticationType??"");
        if(!CreatesLogin(operation)||operation=="CREATE_SQL_LOGIN"&&authenticationType!="SQL"
            ||operation=="CREATE_WINDOWS_LOGIN"&&authenticationType!="WINDOWS")
            throw new InvalidOperationException("El tipo de cuenta cambió. Vuelva a seleccionarlo e inténtelo de nuevo.");
        if(string.IsNullOrWhiteSpace(target)||target.Length>128||target!=target.Trim()||target.Any(char.IsControl))
            throw new InvalidOperationException("Escriba un nombre de usuario válido, sin espacios al inicio o al final.");
        if(authenticationType=="SQL"&&target.Contains('\\'))
            throw new InvalidOperationException("Ese nombre parece ser una cuenta de Windows. Seleccione 'Cuenta de Windows' para continuar.");
        if(authenticationType=="WINDOWS")
        {
            var parts=target.Split('\\');
            if(parts.Length!=2||parts.Any(x=>string.IsNullOrWhiteSpace(x)||x!=x.Trim())||target.Contains('@'))
                throw new InvalidOperationException("Escriba la cuenta en el formato DOMINIO\\usuario o EQUIPO\\usuario.");
        }
    }

    public static void ValidateSecret(string operation,string target,string? authenticationType,bool hasPassword)
    {
        Validate(operation,target,authenticationType);
        if(authenticationType=="SQL"&&!hasPassword)
            throw new InvalidOperationException("La cuenta SQL necesita una contraseña temporal.");
        if(authenticationType=="WINDOWS"&&hasPassword)
            throw new InvalidOperationException("Las cuentas de Windows usan su contraseña habitual; no necesitan una contraseña SQL.");
    }
}
