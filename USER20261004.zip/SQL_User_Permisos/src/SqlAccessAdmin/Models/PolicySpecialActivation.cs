namespace SqlAccessAdmin.Models;

public sealed record PolicySpecialActivation(string Category, string Value, string Scope, string Reason, string ConfirmedName, bool RiskAcknowledged)
{
    public void Validate()
    {
        if (!RiskAcknowledged || !Value.Equals(ConfirmedName, StringComparison.Ordinal))
            throw new InvalidOperationException("Reconozca el riesgo y escriba el nombre exacto para confirmar.");
        if (Reason.Trim().Length is < 20 or > 1000)
            throw new InvalidOperationException("Explique el motivo con entre 20 y 1000 caracteres.");
        if (Category is "DATABASE_ROLE" or "SERVER_ROLE")
        {
            if (Value.Length is 0 or > 128 || Scope != "" || PolicyEditorCatalog.IsPermanentlyBlockedRole(Value))
                throw new InvalidOperationException("Este rol no admite activación especial.");
        }
        else if (Category != "PERMISSION" || !PolicyEditorCatalog.CanManagePermission(Value, Scope))
            throw new InvalidOperationException("Este permiso o alcance no admite activación especial.");
    }
}
