using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace SqlAccessAdmin.Models;

public sealed record PermissionCopyAccessItem(string Database,string Kind,string State,string Permission,
    string Scope,string Schema,string Object,string Column,string Role,bool CanCopy=false,string CopyStatus="")
{
    [JsonIgnore] public string Access=>Kind=="Rol"?Role:Permission;
    [JsonIgnore] public string Destination=>Kind=="Rol"?"Rol de la base de datos":Scope=="DATABASE"?"Toda la base de datos":
        string.Join('.',new[]{Schema,Object,Column}.Where(x=>x.Length>0));
    [JsonIgnore] public string ScopeDisplay=>Scope switch{"DATABASE"=>"Toda la base","OBJECT"=>"Objeto específico","SCHEMA"=>"Grupo de objetos","COLUMN"=>"Columna",_=>Scope};
    [JsonIgnore] public string StateDisplay=>State switch{"GRANT"=>"Permitido","GRANT_WITH_GRANT_OPTION"=>"Permitido","DENY"=>"Denegado","REVOKE"=>"Retirado",_=>State};
    [JsonIgnore] public string Identity=>string.Join('|',new[]{Database,Kind,State,Permission,Scope,Schema,Object,Column,Role,CanCopy.ToString()}
        .Select(x=>Convert.ToBase64String(Encoding.UTF8.GetBytes(x))));
    public static string Fingerprint(IEnumerable<PermissionCopyAccessItem> items)=>Convert.ToHexString(
        SHA256.HashData(Encoding.UTF8.GetBytes(string.Join('\n',items.Select(x=>x.Identity).OrderBy(x=>x,StringComparer.Ordinal)))));
}

public sealed record PermissionCopySourceUser(string Name,string SourceUser);
public sealed record PermissionCopyDatabasePlan(string Database,string SourceUser,IReadOnlyList<PermissionCopyAccessItem> Accesses);
public sealed record PermissionCopyPlan(int Version,IReadOnlyList<PermissionCopyDatabasePlan> Databases)
{
    [JsonIgnore] public int ChangeCount=>1+Databases.Count+Databases.Sum(x=>x.Accesses.Count(a=>a.CanCopy));
    public string ToJson()=>JsonSerializer.Serialize(this with{Databases=Databases.OrderBy(x=>x.Database,StringComparer.Ordinal)
        .Select(x=>x with{Accesses=x.Accesses.OrderBy(a=>a.Identity,StringComparer.Ordinal).ToList()}).ToList()});
    // SQL Server HASHBYTES recibe los mismos bytes UTF-16 de @CopyPlanJson.
    [JsonIgnore] public string Fingerprint=>Convert.ToHexString(SHA256.HashData(Encoding.Unicode.GetBytes(ToJson())));
    public static PermissionCopyPlan FromJson(string json)
    {
        var plan=JsonSerializer.Deserialize<PermissionCopyPlan>(json)??throw new InvalidOperationException("El detalle de copia está vacío.");
        if(plan.Version!=2||plan.Databases is null||plan.Databases.Count==0||plan.Databases.Any(x=>x is null||string.IsNullOrWhiteSpace(x.Database)
            ||x.Database.Length>128||string.IsNullOrWhiteSpace(x.SourceUser)||x.SourceUser.Length>128||x.Accesses is null
            ||x.Accesses.Any(a=>a is null||a.Database!=x.Database||a.Kind is not ("Rol" or "Permiso")||a.State is null||a.Permission is null
                ||a.Scope is null||a.Schema is null||a.Object is null||a.Column is null||a.Role is null||a.CopyStatus is null)))
            throw new InvalidOperationException("El detalle guardado de copia está incompleto o no es compatible.");
        if(plan.Databases.Select(x=>x.Database).Distinct(StringComparer.Ordinal).Count()!=plan.Databases.Count)
            throw new InvalidOperationException("El plan contiene una base duplicada.");
        return plan;
    }
    public IReadOnlyList<AccessRequestChangeItem> DescribeChanges(string target,string authenticationType="SQL")
    {
        var changes=new List<AccessRequestChangeItem>{new(1,$"Crear login {(authenticationType=="WINDOWS"?"Windows":"SQL")} {target}")};
        foreach(var database in Databases.OrderBy(x=>x.Database,StringComparer.CurrentCultureIgnoreCase))
        {
            changes.Add(new(changes.Count+1,$"[{database.Database}] Crear usuario {target} · origen: {database.SourceUser}"));
            foreach(var access in database.Accesses.Where(x=>x.CanCopy).OrderBy(x=>x.Kind).ThenBy(x=>x.Destination).ThenBy(x=>x.Access))
                changes.Add(new(changes.Count+1,$"[{database.Database}] "+(access.Kind=="Rol"?$"Asignar rol {access.Role}":
                    $"Conceder {access.Permission} · {(access.Scope=="DATABASE"?"Toda la base de datos":access.Destination)}")));
        }
        return changes;
    }
}
