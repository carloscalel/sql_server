using System.Collections.ObjectModel;
using SqlAccessAdmin.Infrastructure;

namespace SqlAccessAdmin.Models;

public enum AppRole { Administrator, Operator, Auditor }
public sealed record SessionContext(string Principal, AppRole Role);
public sealed record PivotOptions(string Server, string Instance, string Database, bool IntegratedSecurity, string? User, string? Password, bool Encrypt, bool TrustCertificate)
{ public string DataSource => string.IsNullOrWhiteSpace(Instance) ? Server : $"{Server}\\{Instance}"; }

public sealed class ServerItem : BindableBase
{
    private bool _selected,_active;
    public int Id { get; init; } public bool IsSelected { get => _selected; set => Set(ref _selected, value); }
    public bool Active { get=>_active; set=>Set(ref _active,value); } public string Name { get; init; } = ""; public string Host { get; init; } = ""; public string Instance { get; init; } = "";
    public bool WindowsAuth { get; init; } public string SqlUser { get; init; } = ""; public bool Encrypt { get; init; } public bool TrustCertificate { get; init; } public int TimeoutSeconds { get; init; } = 30;
}
public sealed class DatabaseItem : BindableBase { private bool _selected; public int ServerId { get; init; } public string Server { get; init; }=""; public string Name { get; init; }=""; public string CopySourceUser {get;init;}=""; public bool IsSelected { get=>_selected; set=>Set(ref _selected,value); } }
public sealed record DatabaseObjectItem(int ServerId,string Server,string Database,string Schema,string Name,string Kind)
{
    public string SqlObjectType {get;init;}="";
    public string TypeDisplay=>Kind switch
    {
        "TABLE"=>"Tabla",
        "VIEW"=>"Vista",
        "PROCEDURE"=>"Procedimiento",
        "FUNCTION"=>SqlObjectType switch
        {
            "FN"=>"Función escalar",
            "FS"=>"Función escalar CLR",
            "IF"=>"Función tabular en línea",
            "TF"=>"Función tabular",
            "FT"=>"Función tabular CLR",
            _=>"Función · tipo sin resolver"
        },
        _=>Kind
    };
    public bool SupportsPermission(string permission)=>Kind switch
    {
        "TABLE" or "VIEW"=>permission is "SELECT" or "INSERT" or "UPDATE" or "DELETE" or "REFERENCES",
        "PROCEDURE"=>permission=="EXECUTE",
        "FUNCTION"=>SqlObjectType switch
        {
            "FN" or "FS"=>permission is "EXECUTE" or "REFERENCES",
            "IF" or "TF" or "FT"=>permission is "SELECT" or "REFERENCES",
            _=>false
        },
        _=>false
    };
    public string QualifiedName=>$"{Schema}.{Name}";
    public string DisplayName=>$"{Schema}.{Name}  ·  {TypeDisplay}";
}
public sealed class DatabaseObjectSelectionItem(DatabaseObjectItem item,bool selected=false) : BindableBase
{
    private bool _selected=selected;
    public DatabaseObjectItem Item {get;}=item;
    public string Schema=>Item.Schema;
    public string Name=>Item.Name;
    public string Kind=>Item.Kind;
    public string TypeDisplay=>Item.TypeDisplay;
    public string QualifiedName=>Item.QualifiedName;
    public bool IsSelected {get=>_selected;set=>Set(ref _selected,value);}
}
public sealed record ServerLoginItem(string Name,string Type,bool Enabled)
{
    public string Status=>Enabled?"Habilitado":"Deshabilitado";
    public string StatusForeground=>Enabled?"#15803D":"#B42318";
    public string StatusBackground=>Enabled?"#DCFCE7":"#FEE2E2";
}
public sealed class ObjectPermissionRow(DatabaseObjectItem item,ISet<string> allowedPermissions,ISet<string>? assignedPermissions=null) : BindableBase
{
    private readonly HashSet<string> _initiallyAssigned=new(assignedPermissions??new HashSet<string>(),StringComparer.OrdinalIgnoreCase);
    private bool _select=assignedPermissions?.Contains("SELECT")==true;
    private bool _insert=assignedPermissions?.Contains("INSERT")==true;
    private bool _update=assignedPermissions?.Contains("UPDATE")==true;
    private bool _delete=assignedPermissions?.Contains("DELETE")==true;
    private bool _execute=assignedPermissions?.Contains("EXECUTE")==true;
    private bool _references=assignedPermissions?.Contains("REFERENCES")==true;
    public DatabaseObjectItem Item {get;}=item;
    public string Schema=>Item.Schema;
    public string Name=>Item.Name;
    public string Kind=>Item.Kind;
    public string TypeDisplay=>Item.TypeDisplay;
    public string QualifiedName=>Item.QualifiedName;
    public bool CanSelect=>allowedPermissions.Contains("SELECT")&&Item.SupportsPermission("SELECT");
    public bool CanInsert=>allowedPermissions.Contains("INSERT")&&Item.SupportsPermission("INSERT");
    public bool CanUpdate=>allowedPermissions.Contains("UPDATE")&&Item.SupportsPermission("UPDATE");
    public bool CanDelete=>allowedPermissions.Contains("DELETE")&&Item.SupportsPermission("DELETE");
    public bool CanExecute=>allowedPermissions.Contains("EXECUTE")&&Item.SupportsPermission("EXECUTE");
    public bool CanReferences=>allowedPermissions.Contains("REFERENCES")&&Item.SupportsPermission("REFERENCES");
    public bool GrantSelect {get=>_select;set{if(CanSelect&&Set(ref _select,value))Raise(nameof(HasChange));}}
    public bool GrantInsert {get=>_insert;set{if(CanInsert&&Set(ref _insert,value))Raise(nameof(HasChange));}}
    public bool GrantUpdate {get=>_update;set{if(CanUpdate&&Set(ref _update,value))Raise(nameof(HasChange));}}
    public bool GrantDelete {get=>_delete;set{if(CanDelete&&Set(ref _delete,value))Raise(nameof(HasChange));}}
    public bool GrantExecute {get=>_execute;set{if(CanExecute&&Set(ref _execute,value))Raise(nameof(HasChange));}}
    public bool GrantReferences {get=>_references;set{if(CanReferences&&Set(ref _references,value))Raise(nameof(HasChange));}}
    public IEnumerable<string> SelectedPermissions
    {
        get
        {
            if(GrantSelect)yield return "SELECT";
            if(GrantInsert)yield return "INSERT";
            if(GrantUpdate)yield return "UPDATE";
            if(GrantDelete)yield return "DELETE";
            if(GrantExecute)yield return "EXECUTE";
            if(GrantReferences)yield return "REFERENCES";
        }
    }
    public IEnumerable<(string Permission,string Action)> PermissionChanges
    {
        get
        {
            foreach(var permission in PolicyEditorCatalog.SupportedPermissions)
            {
                var selected=permission switch
                {
                    "SELECT"=>GrantSelect,"INSERT"=>GrantInsert,"UPDATE"=>GrantUpdate,
                    "DELETE"=>GrantDelete,"EXECUTE"=>GrantExecute,"REFERENCES"=>GrantReferences,_=>false
                };
                if(selected!=_initiallyAssigned.Contains(permission))yield return(permission,selected?"GRANT":"REVOKE");
            }
        }
    }
    public bool HasChange=>PermissionChanges.Any();
}
public sealed record AuthorizedUser(int Id, string Principal, string Type, AppRole Role, bool Active, string Notes);
public sealed record AuditEvent(DateTime Date, string User, string Form, string Action, string Server, string Database, bool Success, string Detail);
public sealed record OperationResult(string Server, string Database, bool Success, string Message);
public sealed record CryptoMaterial(Guid KeyId, byte[] MasterKey);
public sealed record CredentialEnvelope(byte[] Ciphertext, byte[] Nonce, byte[] Tag, Guid KeyId);
public sealed record ServerConnectionInfo(int Id,string Name,string Host,string Instance,bool WindowsAuth,string SqlUser,CredentialEnvelope? Credential,bool Encrypt,bool TrustCertificate,int TimeoutSeconds);
public sealed record ServerEditData(int? Id,string Name,string Host,string Instance,bool WindowsAuth,string SqlUser,string? Password,bool Encrypt,bool TrustCertificate,int TimeoutSeconds,bool Active);
public sealed record PolicyOperation(string Code,string Name,bool Enabled,bool RequiresApproval,string Risk,string Description);
public sealed record PolicyPermission(string Permission,string Scope,bool AllowGrant,bool AllowDeny,bool AllowRevoke,bool Enabled,string ApprovedBy,DateTime ApprovedAt)
{ public bool SpecialActivationApproved {get;init;} public string SpecialActivationReason {get;init;}="";
  public string Origin {get;init;}="GENERAL"; public bool Supported {get;init;}=true; }
public sealed record PolicyRole(string Name,string Kind,bool Enabled,string ApprovedBy,DateTime ApprovedAt,string Notes)
{ public bool SpecialActivationApproved {get;init;} public string SpecialActivationReason {get;init;}="";
  public string Origin {get;init;}="GENERAL"; public string RoleScope {get;init;}="DATABASE"; }
public sealed class RoleSelectionItem(PolicyRole role) : BindableBase
{
    private bool _selected;
    public PolicyRole Role { get; }=role;
    public string Name=>Role.Name;
    public string Kind=>Role.Kind;
    public bool IsSelected {get=>_selected;set=>Set(ref _selected,value);}
}
public sealed class DatabaseRoleSelectionItem : BindableBase
{
    private bool _isSelected;
    public DatabaseRoleSelectionItem(string name,string kind,bool isAllowed,bool isAssigned)
    {
        Name=name;
        Kind=kind;
        IsAllowed=isAllowed;
        InitiallyAssigned=isAssigned;
        _isSelected=isAssigned;
    }
    public string Name {get;}
    public string Kind {get;}
    public bool IsAllowed {get;}
    public bool InitiallyAssigned {get;}
    public bool IsSelected
    {
        get=>_isSelected;
        set
        {
            if(!IsAllowed)return;
            if(Set(ref _isSelected,value))Raise(nameof(HasChange));
        }
    }
    public bool HasChange=>IsAllowed&&IsSelected!=InitiallyAssigned;
    public string MembershipStatus=>InitiallyAssigned?"Asignado actualmente":"No asignado";
    public string PolicyStatus=>IsAllowed?"Autorizado por política":"Solo consulta · no autorizado";
    public string SecurityIcon=>IsAllowed?"✓":"🔒";
    public string SecurityHint=>IsAllowed
        ? "Este rol fue habilitado por la política central."
        : "Rol bloqueado: un administrador debe autorizarlo en Política de seguridad y no puede pertenecer a la denylist.";
}
public sealed class PermissionSelectionItem(PolicyPermission permission) : BindableBase
{
    private bool _selected;
    public PolicyPermission PermissionRule { get; }=permission;
    public string Name=>PermissionRule.Permission;
    public string Description=>Name.ToUpperInvariant() switch
    {
        "SELECT"=>"Consultar y leer datos",
        "INSERT"=>"Agregar nuevos registros",
        "UPDATE"=>"Modificar registros existentes",
        "DELETE"=>"Eliminar registros",
        "EXECUTE"=>"Ejecutar procedimientos y funciones",
        "REFERENCES"=>"Referenciar objetos en definiciones SQL",
        _=>"Aplicar esta acción autorizada"
    };
    public bool IsSelected {get=>_selected;set=>Set(ref _selected,value);}
}
public sealed record DenyRule(int Id,string Category,string Value,string Reason,bool IsSystem,bool Active,string CreatedBy,DateTime CreatedAt);
public sealed record PolicyDecision(bool Allowed,bool RequiresApproval,string Risk,string Reason);
public sealed record ExternalTicketDetails(string Responsible,string Client,string Number,string Subject,string Description,string Status)
{
    public string Summary=>string.Join(" · ",new[]{Subject,Status,$"Cliente: {Client}",$"Responsable: {Responsible}"}.Where(x=>!string.IsNullOrWhiteSpace(x)));
}
public sealed record AccessRequestItem(long Id,string Operation,string TargetPrincipal,string SourcePrincipal,string AuthenticationType,string PermissionAction,string Permission,string Scope,string Securable,string Role,string ExternalTicketNumber,string Justification,string Status,string RequestedBy,DateTime RequestedAt,string ApprovedBy,DateTime? ApprovedAt,int TargetCount,int StepCount)
{
    public IReadOnlyList<AccessRequestStepItem> Steps {get;init;}=[];
    public PermissionCopyPlan? CopyPlan {get;init;}
    public string DestinationSummary {get;init;}="";
    public string AuthenticationDisplay=>AuthenticationType switch{"SQL"=>"SQL authentication","WINDOWS"=>"Windows authentication",_=>""};
    public int ChangeCount=>Operation=="CLONE_PERMISSIONS"&&CopyPlan is not null?CopyPlan.ChangeCount:StepCount+1;
    public string TicketDisplay=>string.IsNullOrWhiteSpace(ExternalTicketNumber)?"Sin ticket histórico":ExternalTicketNumber;
    public string RequestTitle=>Operation=="CLONE_PERMISSIONS"?$"Solicitud #{Id} · Copiar permisos a usuario nuevo{(CopyPlan is null?"":$" · {ChangeCount} cambios en {CopyPlan.Databases.Count} base(s)")}":StepCount>0&&Operation is "MODIFY_LOGIN" or "ADD_ROLE_MEMBER" or "REMOVE_ROLE_MEMBER" or "PERMISSION_CHANGE"
        ? $"Solicitud #{Id} · Modificar accesos · {ChangeCount} cambios"
        : $"Solicitud #{Id} · {Operation}{(StepCount>0?$" · {ChangeCount} cambios":"")}";
    public string ChangesTitle=>$"Cambios incluidos ({ChangeCount})";
    public IReadOnlyList<AccessRequestChangeItem> Changes=>Operation=="CLONE_PERMISSIONS"
        ?CopyPlan?.DescribeChanges(TargetPrincipal,AuthenticationType)??[new(1,$"Copia de {SourcePrincipal} a {TargetPrincipal}: esta solicitud anterior no guardó el desglose. Genere una solicitud nueva para revisar los accesos por base.")]
        :new[]{new AccessRequestStepItem(0,0,Operation,PermissionAction,Permission,Scope,Securable,Role)}
        .Concat(Steps.OrderBy(x=>x.Order))
        .Select((step,index)=>new AccessRequestChangeItem(index+1,step.Description)).ToList();
}
public sealed record AccessRequestChangeItem(int Order,string Description)
{
    public string DisplayText=>$"{Order}. {Description}";
}
public sealed record AccessRequestDraft(string Operation,string TargetPrincipal,string? SourcePrincipal,string? AuthenticationType,string? PermissionAction,string? Permission,string? Scope,string? Securable,string? Role,string ExternalTicketNumber,string Justification)
{
    public PermissionCopyPlan? CopyPlan {get;init;}
}
public sealed record AccessRequestStepDraft(int Order,string Operation,string? PermissionAction,string? Permission,string? Scope,string? Securable,string? Role);
public sealed record AccessRequestStepItem(long Id,int Order,string Operation,string PermissionAction,string Permission,string Scope,string Securable,string Role)
{
    public string Description=>Operation switch
    {
        "MODIFY_LOGIN" or "ADD_ROLE_MEMBER"=>$"Asignar rol {Role}",
        "REMOVE_ROLE_MEMBER"=>$"Retirar rol {Role}",
        "PERMISSION_CHANGE" or "SERVER_PERMISSION_CHANGE"=>$"{(PermissionAction=="REVOKE"?"Retirar":PermissionAction=="DENY"?"Denegar":"Conceder")} {Permission} · {(Scope=="DATABASE"?"Toda la base de datos":Scope=="SERVER"?"Instancia":Securable)}",
        "ADD_SERVER_ROLE_MEMBER"=>$"Asignar rol de servidor {Role}",
        "REMOVE_SERVER_ROLE_MEMBER"=>$"Retirar rol de servidor {Role}",
        "CREATE_DB_USER"=>"Crear usuario en la base de datos",
        "CREATE_SQL_LOGIN"=>"Crear login SQL",
        "CREATE_WINDOWS_LOGIN"=>"Crear login Windows",
        "ENABLE_LOGIN"=>"Habilitar login",
        "DISABLE_LOGIN"=>"Deshabilitar login",
        "CLONE_PERMISSIONS"=>"Copiar permisos del usuario origen",
        _=>Operation
    };
}
public sealed record RequestSecretData(CredentialEnvelope Envelope,bool PasswordPolicy,bool PasswordExpiration,bool MustChangePassword);
public sealed record AuditIntegrity(long HashedEvents,int BrokenLinks,int AlteredEvents,bool IsValid);

public enum SecurityNodeKind
{
    Server,
    LoginGroup,
    Login,
    DatabaseGroup,
    Database,
    UserGroup,
    User,
    Loading,
    Error
}

public sealed class SecurityTreeNode : BindableBase
{
    private bool _isLoaded;
    private bool _isVisible=true;
    private bool _isExpanded;

    public SecurityTreeNode(
        string name,
        SecurityNodeKind kind,
        int serverId,
        string serverName,
        string database = "",
        string principal = "",
        bool loadOnExpand = false,
        bool? loginEnabled = null)
    {
        Name = name;
        Kind = kind;
        ServerId = serverId;
        ServerName = serverName;
        Database = database;
        Principal = principal;
        LoadOnExpand = loadOnExpand;
        LoginEnabled = loginEnabled;
        if (loadOnExpand)
            Children.Add(new SecurityTreeNode("Cargando…", SecurityNodeKind.Loading, serverId, serverName));
    }

    public string Name { get; }
    public SecurityNodeKind Kind { get; }
    public int ServerId { get; }
    public string ServerName { get; }
    public string Database { get; }
    public string Principal { get; }
    public bool LoadOnExpand { get; }
    public bool? LoginEnabled { get; }
    public bool HasLoginState => Kind == SecurityNodeKind.Login && LoginEnabled.HasValue;
    public string LoginStateLabel => LoginEnabled switch { true => "Habilitado", false => "Deshabilitado", _ => "" };
    public string LoginStateColor => LoginEnabled switch { true => "#15803D", false => "#B42318", _ => "#60789F" };
    public string LoginStateBackground => LoginEnabled switch { true => "#EAF8EF", false => "#FFF0EE", _ => "#F2F6FD" };
    public ObservableCollection<SecurityTreeNode> Children { get; } = [];
    public bool IsPrincipal => Kind is SecurityNodeKind.Login or SecurityNodeKind.User;
    public bool IsLoaded { get => _isLoaded; set => Set(ref _isLoaded, value); }
    public bool IsVisible { get => _isVisible; set => Set(ref _isVisible, value); }
    public bool IsExpanded { get => _isExpanded; set => Set(ref _isExpanded, value); }
    public string Icon => Kind switch
    {
        SecurityNodeKind.Server => "▣",
        SecurityNodeKind.LoginGroup => "♟",
        SecurityNodeKind.Login => LoginEnabled==false ? "⊘" : "●",
        SecurityNodeKind.DatabaseGroup => "▰",
        SecurityNodeKind.Database => "●",
        SecurityNodeKind.UserGroup => "♟",
        SecurityNodeKind.User => "●",
        SecurityNodeKind.Error => "!",
        _ => "·"
    };
}

public sealed record SecurityPermissionItem(string State, string Permission, string Scope, string Securable, string Grantor);
public sealed record SecurityMembershipItem(string Type, string Name, string Context);
public sealed record MappedLoginState(string Login, bool Enabled);

public sealed class SecurityPrincipalDetails
{
    public List<SecurityPermissionItem> Permissions { get; } = [];
    public List<SecurityMembershipItem> Memberships { get; } = [];
}
