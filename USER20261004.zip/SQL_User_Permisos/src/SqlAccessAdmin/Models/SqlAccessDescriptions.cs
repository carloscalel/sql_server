namespace SqlAccessAdmin.Models;

/// <summary>Plain-language help, independent from policy approvals and administrator notes.</summary>
public static class SqlAccessDescriptions
{
    private static readonly IReadOnlyDictionary<string,string> Objects = new Dictionary<string,string>(StringComparer.Ordinal)
    {
        ["AGGREGATE"]="funciones que resumen varios valores",
        ["APPLICATION ROLE"]="roles de seguridad usados por aplicaciones",
        ["ASSEMBLY"]="módulos de código que ejecuta la base",
        ["ASYMMETRIC KEY"]="claves de seguridad con parte pública y privada",
        ["AVAILABILITY GROUP"]="grupos de bases con réplicas para mantener el servicio",
        ["CERTIFICATE"]="certificados usados para proteger datos o código",
        ["COLUMN ENCRYPTION KEY"]="claves que cifran los datos de columnas",
        ["COLUMN MASTER KEY"]="claves maestras que protegen el cifrado de columnas",
        ["CONNECTION"]="conexiones de usuarios al servidor",
        ["CONTRACT"]="reglas sobre qué mensajes intercambian los servicios",
        ["CREDENTIAL"]="credenciales usadas para acceder a recursos externos",
        ["DATABASE SCOPED CREDENTIAL"]="credenciales de la base para recursos externos",
        ["DATABASE"]="bases de datos",
        ["DATABASE AUDIT"]="configuraciones que registran actividad y seguridad de la base",
        ["DATABASE DDL TRIGGER"]="acciones automáticas ante cambios de objetos de la base",
        ["DATABASE DDL EVENT NOTIFICATION"]="avisos de cambios en objetos de la base",
        ["DATABASE EVENT NOTIFICATION"]="avisos de eventos de la base",
        ["DATABASE EVENT SESSION"]="sesiones que registran actividad y errores de la base",
        ["DATABASE SCOPED CONFIGURATION"]="opciones de funcionamiento de la base",
        ["DATASPACE"]="espacios donde se almacenan los datos de la base",
        ["DEFAULT"]="valores predeterminados para los datos",
        ["DDL EVENT NOTIFICATION"]="avisos de cambios en objetos",
        ["ENDPOINT"]="puntos de conexión al servidor",
        ["EVENT NOTIFICATION"]="avisos automáticos de eventos",
        ["EVENT SESSION"]="sesiones que registran actividad y errores del servidor",
        ["EXTERNAL DATA SOURCE"]="conexiones a datos externos",
        ["EXTERNAL FILE FORMAT"]="formatos para leer archivos externos",
        ["EXTERNAL JOB"]="tareas que procesan datos externos",
        ["EXTERNAL LANGUAGE"]="lenguajes de programación ejecutados desde la base",
        ["EXTERNAL LIBRARY"]="bibliotecas de código para tareas externas",
        ["EXTERNAL STREAM"]="flujos de datos que llegan desde sistemas externos",
        ["EXTERNAL MODEL"]="modelos externos usados desde la base",
        ["FULLTEXT CATALOG"]="catálogos para buscar palabras dentro de textos",
        ["FULLTEXT STOPLIST"]="listas de palabras que se ignoran en búsquedas de texto",
        ["FUNCTION"]="funciones que calculan y devuelven resultados",
        ["LINKED SERVER"]="conexiones a otros servidores de datos",
        ["LOGIN"]="cuentas de inicio de sesión del servidor",
        ["MASK"]="reglas que ocultan parte de los datos al consultarlos",
        ["MESSAGE TYPE"]="formatos de mensajes intercambiados entre servicios",
        ["PROCEDURE"]="rutinas que ejecutan tareas en la base",
        ["QUEUE"]="bandejas que almacenan mensajes entre servicios",
        ["REMOTE SERVICE BINDING"]="vínculos seguros con servicios de otras bases",
        ["ROLE"]="roles personalizados que agrupan permisos",
        ["ROUTE"]="rutas para enviar mensajes entre servicios",
        ["RULE"]="reglas de validación de datos",
        ["SCHEMA"]="grupos de objetos de la base (esquemas)",
        ["SEARCH PROPERTY LIST"]="listas de propiedades para buscar en documentos",
        ["SECURITY POLICY"]="filtros que limitan las filas que un usuario puede ver o modificar",
        ["SENSITIVITY CLASSIFICATION"]="etiquetas que identifican datos sensibles",
        ["SEQUENCE"]="secuencias que generan números consecutivos",
        ["SERVER AUDIT"]="configuraciones que registran actividad y seguridad del servidor",
        ["SERVER ROLE"]="roles que agrupan permisos de la instancia",
        ["SERVICE"]="servicios que intercambian mensajes entre bases",
        ["SYMMETRIC KEY"]="claves para cifrar y descifrar datos",
        ["SYNONYM"]="nombres alternativos para acceder a objetos",
        ["TABLE"]="tablas que almacenan datos",
        ["TRACE EVENT NOTIFICATION"]="avisos de eventos de seguimiento",
        ["TYPE"]="tipos de datos personalizados",
        ["USER"]="usuarios de la base",
        ["VIEW"]="consultas guardadas que presentan datos",
        ["XML SCHEMA COLLECTION"]="reglas que validan la estructura de datos XML"
    };

    public static string Permission(string name,string scope)
    {
        var description = name switch
        {
            "SELECT"=>"Consultar datos sin modificarlos.",
            "INSERT"=>"Agregar nuevos registros.",
            "UPDATE"=>"Cambiar los valores de registros existentes.",
            "DELETE"=>"Eliminar registros; no elimina la tabla.",
            "EXECUTE"=>scope=="TYPE"?"Usar este tipo de datos al ejecutar código.":"Ejecutar rutinas o funciones del destino.",
            "CONTROL"=>"Administrar el destino y sus permisos; incluye un acceso muy amplio.",
            "CONTROL SERVER"=>"Administrar toda la instancia, sus bases y sus permisos.",
            "ALTER"=>"Cambiar la definición o configuración del destino; no equivale a editar sus datos.",
            "ALTER ANY CONNECTION"=>"Cerrar conexiones de otros usuarios al servidor.",
            "ALTER ANY DATABASE SCOPED CONFIGURATION"=>"Cambiar opciones de funcionamiento que afectan a esta base.",
            "REFERENCES"=>References(scope),
            "TAKE OWNERSHIP"=>"Convertirse en propietario del destino y controlar sus permisos.",
            "IMPERSONATE"=>"Actuar con la identidad y los permisos del usuario o cuenta indicada.",
            "IMPERSONATE ANY USER"=>"Actuar con la identidad de cualquier usuario de la base.",
            "IMPERSONATE ANY LOGIN"=>"Actuar con la identidad de cualquier cuenta del servidor.",
            "UNMASK"=>"Ver los datos originales que normalmente aparecen ocultos o enmascarados.",
            "VIEW DEFINITION"=>"Consultar cómo están definidos los objetos, sin modificar su definición.",
            "VIEW SECURITY DEFINITION" or "VIEW ANY SECURITY DEFINITION"=>"Consultar información sobre la configuración de seguridad y permisos.",
            "VIEW PERFORMANCE DEFINITION" or "VIEW ANY PERFORMANCE DEFINITION"=>"Consultar definiciones y metadatos relacionados con el rendimiento.",
            "VIEW CRYPTOGRAPHICALLY SECURED DEFINITION" or "VIEW ANY CRYPTOGRAPHICALLY SECURED DEFINITION"=>"Consultar metadatos protegidos sobre firmas y claves de seguridad.",
            "VIEW DATABASE STATE"=>"Consultar la actividad y el estado interno de la base.",
            "VIEW DATABASE PERFORMANCE STATE"=>"Consultar métricas y diagnósticos de rendimiento de la base.",
            "VIEW DATABASE SECURITY STATE"=>"Consultar el estado y los diagnósticos de seguridad de la base.",
            "VIEW DATABASE SECURITY AUDIT"=>"Consultar registros de eventos de seguridad de la base.",
            "VIEW SERVER STATE"=>"Consultar la actividad y el estado interno de la instancia.",
            "VIEW SERVER PERFORMANCE STATE"=>"Consultar métricas y diagnósticos de rendimiento de la instancia.",
            "VIEW SERVER SECURITY STATE"=>"Consultar el estado y los diagnósticos de seguridad de la instancia.",
            "VIEW SERVER SECURITY AUDIT"=>"Consultar registros de eventos de seguridad de la instancia.",
            "VIEW ANY DATABASE"=>"Ver los nombres y datos generales de las bases del servidor; no sus registros.",
            "VIEW ANY SENSITIVITY CLASSIFICATION"=>"Consultar las etiquetas que identifican datos sensibles.",
            "VIEW ANY DEFINITION"=>"Consultar las definiciones de objetos de la instancia y sus bases.",
            "VIEW ANY ERROR LOG"=>"Consultar los archivos de registro de errores del servidor.",
            "VIEW CHANGE TRACKING"=>"Consultar qué registros han cambiado mediante el seguimiento de cambios.",
            "BACKUP DATABASE"=>"Crear una copia de respaldo de la base.",
            "BACKUP LOG"=>"Respaldar el registro de cambios para apoyar la recuperación de la base.",
            "CHECKPOINT"=>"Solicitar que los cambios pendientes de la base se escriban en disco.",
            "CONNECT"=>"Conectarse al destino; por sí solo no permite consultar sus datos.",
            "CONNECT SQL"=>"Iniciar una conexión con la instancia de SQL Server.",
            "CONNECT ANY DATABASE"=>"Conectarse a cualquier base de la instancia; no concede acceso a sus datos.",
            "CONNECT REPLICATION"=>"Conectarse para realizar tareas de replicación de datos.",
            "AUTHENTICATE"=>"Permitir autenticación en la base para determinados contextos de ejecución.",
            "AUTHENTICATE SERVER"=>"Permitir autenticación en el servidor para determinados contextos de ejecución.",
            "ADMINISTER BULK OPERATIONS"=>"Importar grandes cantidades de datos desde archivos.",
            "ADMINISTER DATABASE BULK OPERATIONS"=>"Realizar importaciones masivas de datos dentro de la base.",
            "SHOWPLAN"=>"Consultar cómo SQL Server planea ejecutar una consulta.",
            "SUBSCRIBE QUERY NOTIFICATIONS"=>"Recibir avisos cuando cambian los resultados de una consulta.",
            "RECEIVE"=>"Leer y retirar mensajes de una bandeja de servicios.",
            "SEND"=>"Enviar mensajes a un servicio de la base.",
            "ENABLE LEDGER"=>"Habilitar un historial verificable de cambios mediante tablas de registro (ledger).",
            "ALTER LEDGER"=>"Modificar las funciones de historial verificable de cambios (ledger).",
            "ALTER LEDGER CONFIGURATION"=>"Cambiar la configuración del historial verificable de la base (ledger).",
            "VIEW LEDGER CONTENT"=>"Consultar el historial verificable de cambios de las tablas ledger.",
            "EXECUTE ANY EXTERNAL SCRIPT"=>"Ejecutar código externo, como Python o R, desde la base.",
            "EXECUTE ANY EXTERNAL ENDPOINT"=>"Llamar a servicios externos desde la base.",
            "SELECT ALL USER SECURABLES"=>"Consultar datos de tablas y vistas de usuario en todas las bases del servidor.",
            "KILL DATABASE CONNECTION"=>"Cerrar conexiones de usuarios a la base.",
            "KILL ANY CONNECTION"=>"Cerrar cualquier conexión de usuario al servidor.",
            "SHUTDOWN"=>"Apagar el servicio de SQL Server; afecta a todos los usuarios.",
            "ALTER RESOURCES"=>"Modificar límites y distribución de recursos del servidor.",
            "ALTER SERVER STATE"=>"Realizar tareas que cambian el estado operativo de la instancia.",
            "ALTER SETTINGS"=>"Cambiar opciones de funcionamiento del servidor.",
            "ALTER TRACE"=>"Configurar el seguimiento de actividad del servidor.",
            "EXTERNAL ACCESS ASSEMBLY"=>"Permitir que módulos de código accedan a recursos fuera del servidor.",
            "UNSAFE ASSEMBLY"=>"Permitir módulos de código con acceso sin las restricciones habituales de seguridad.",
            _=>DescribeOperation(name)
        };
        return description;
    }

    private static string References(string scope)=>scope switch
    {
        "CREDENTIAL" or "DB_CREDENTIAL"=>"Usar esta credencial para acceder a recursos externos.",
        "TYPE"=>"Usar este tipo de datos al definir otros objetos.",
        "CONTRACT"=>"Usar estas reglas de mensajes al configurar un servicio.",
        "CERTIFICATE" or "ASYMMETRIC_KEY" or "SYMMETRIC_KEY"=>"Usar este elemento de seguridad en otros objetos o procesos.",
        "OBJECT" or "COLUMN"=>"Crear relaciones o dependencias que hagan referencia a este objeto o columna.",
        _=>"Crear relaciones o dependencias que usen objetos del destino."
    };

    private static string DescribeOperation(string name)
    {
        foreach(var prefix in new[]{"ALTER ANY DATABASE EVENT SESSION ","ALTER ANY EVENT SESSION "})
            if(name.StartsWith(prefix,StringComparison.Ordinal))
                return name[prefix.Length..] switch
                {
                    "ADD EVENT"=>"Añadir eventos a registrar en sesiones de seguimiento.",
                    "DROP EVENT"=>"Quitar eventos de las sesiones de seguimiento.",
                    "ADD TARGET"=>"Añadir un destino donde se guardan los eventos registrados.",
                    "DROP TARGET"=>"Quitar un destino de almacenamiento de eventos registrados.",
                    "ENABLE"=>"Iniciar sesiones que registran actividad y errores.",
                    "DISABLE"=>"Detener sesiones que registran actividad y errores.",
                    "OPTION"=>"Cambiar opciones de las sesiones de seguimiento.",
                    _=>"Gestionar sesiones de registro de actividad; revise el alcance antes de autorizarlo."
                };
        foreach(var (prefix,verb) in new[]{("ALTER ANY ","Crear, modificar o eliminar "),("CREATE ANY ","Crear "),("CREATE ","Crear "),("DROP ANY ","Eliminar ")})
            if(name.StartsWith(prefix,StringComparison.Ordinal)&&Objects.TryGetValue(name[prefix.Length..],out var objects))
                return verb+objects+".";
        if(name.StartsWith("VIEW ANY ",StringComparison.Ordinal)&&name.EndsWith(" DEFINITION",StringComparison.Ordinal)
            &&Objects.TryGetValue(name[9..^11],out var definitions))
            return "Consultar las definiciones de "+definitions+"; no permite modificarlos.";
        return "Permiso avanzado de SQL Server. Revise su significado y alcance antes de autorizarlo.";
    }

    public static string? FixedRole(string name,string scope)=>(scope,name.ToLowerInvariant()) switch
    {
        ("DATABASE","db_owner")=>"Administrar toda la base, sus datos y permisos; incluso eliminarla.",
        ("DATABASE","db_accessadmin")=>"Agregar o quitar el acceso de usuarios a la base.",
        ("DATABASE","db_securityadmin")=>"Administrar permisos y miembros de roles personalizados; puede ampliar accesos.",
        ("DATABASE","db_backupoperator")=>"Crear respaldos de la base; no permite restaurarlos por sí solo.",
        ("DATABASE","db_ddladmin")=>"Crear, modificar o eliminar objetos de la base, como tablas y rutinas.",
        ("DATABASE","db_datareader")=>"Leer los datos de todas las tablas y vistas de usuario de la base.",
        ("DATABASE","db_datawriter")=>"Agregar, modificar y eliminar datos en todas las tablas de usuario de la base.",
        ("DATABASE","db_denydatareader")=>"Bloquear la lectura de datos en todas las tablas y vistas de usuario de la base.",
        ("DATABASE","db_denydatawriter")=>"Bloquear que se agreguen, modifiquen o eliminen datos en tablas de usuario.",
        ("SERVER","sysadmin")=>"Control total de la instancia y todas sus bases; sin restricciones de permisos.",
        ("SERVER","serveradmin")=>"Cambiar opciones del servidor y apagar el servicio de SQL Server.",
        ("SERVER","securityadmin")=>"Administrar cuentas y permisos; puede llegar a obtener control total del servidor.",
        ("SERVER","processadmin")=>"Finalizar procesos y conexiones que se ejecutan en la instancia.",
        ("SERVER","setupadmin")=>"Agregar o quitar conexiones a otros servidores de datos.",
        ("SERVER","bulkadmin")=>"Importar grandes cantidades de datos desde archivos.",
        ("SERVER","diskadmin")=>"Administrar archivos de disco usados por SQL Server.",
        ("SERVER","dbcreator")=>"Crear, modificar, eliminar y restaurar bases de datos.",
        _=>null
    };
}
