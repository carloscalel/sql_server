using System.Data;
using System.Security.Cryptography;
using Microsoft.Data.SqlClient;
using SqlAccessAdmin.Models;
using SqlAccessAdmin.Security;

namespace SqlAccessAdmin.Data;

public sealed partial class DirectSqlServerService(AdminDbGateway adminDb)
{
    private static bool IsPermissionSafe(string permission)=>SqlPermissionSafety.IsPermissionName(permission);
    private static bool IsBlockedRole(string role)=>PolicyEditorCatalog.IsPermanentlyBlockedRole(role);
    private async Task<(ServerConnectionInfo Server,string ConnectionString)> ResolveAsync(int serverId,string database="master",CancellationToken ct=default)
    {
        var server=await adminDb.GetServerConnectionAsync(serverId,ct);
        string? password=null;
        if(!server.WindowsAuth)
        {
            if(server.Credential is null)throw new InvalidOperationException("El servidor no tiene una credencial SQL cifrada.");
            var crypto=await adminDb.GetCryptoMaterialAsync(ct);
            if(crypto.KeyId!=server.Credential.KeyId)throw new InvalidOperationException("La credencial utiliza una versión de clave no disponible.");
            try{password=new AesGcmCredentialProtector(crypto.MasterKey).Unprotect(server.Credential);}
            finally{CryptographicOperations.ZeroMemory(crypto.MasterKey);}
        }
        var source=string.IsNullOrWhiteSpace(server.Instance)?server.Host:$"{server.Host}\\{server.Instance}";
        var builder=new SqlConnectionStringBuilder{DataSource=source,InitialCatalog=database,IntegratedSecurity=server.WindowsAuth,UserID=server.WindowsAuth?"":server.SqlUser,Password=password??"",Encrypt=server.Encrypt,TrustServerCertificate=server.TrustCertificate,ConnectTimeout=server.TimeoutSeconds,ApplicationName="SqlAccessAdmin-Direct"};
        return(server,builder.ConnectionString);
    }

    public async Task TestAsync(int serverId,CancellationToken ct=default)
    { var x=await ResolveAsync(serverId,ct:ct);await using var cn=new SqlConnection(x.ConnectionString);await cn.OpenAsync(ct); }

    public async Task TestAsync(ServerEditData data,CancellationToken ct=default)
    {
        string? password=data.Password;
        if(!data.WindowsAuth&&string.IsNullOrEmpty(password)&&data.Id.HasValue){var existing=await ResolveAsync(data.Id.Value,ct:ct);password=new SqlConnectionStringBuilder(existing.ConnectionString).Password;}
        var source=string.IsNullOrWhiteSpace(data.Instance)?data.Host:$"{data.Host}\\{data.Instance}";
        var builder=new SqlConnectionStringBuilder{DataSource=source,InitialCatalog="master",IntegratedSecurity=data.WindowsAuth,UserID=data.WindowsAuth?"":data.SqlUser,Password=password??"",Encrypt=data.Encrypt,TrustServerCertificate=data.TrustCertificate,ConnectTimeout=data.TimeoutSeconds,ApplicationName="SqlAccessAdmin-Direct-Test"};
        await using var cn=new SqlConnection(builder.ConnectionString);await cn.OpenAsync(ct);
    }

    public async Task<IReadOnlyList<DatabaseItem>> GetDatabasesAsync(IEnumerable<ServerItem> servers,CancellationToken ct=default)
    {
        var tasks=servers.Where(x=>x.IsSelected).Select(async item=>{var x=await ResolveAsync(item.Id,ct:ct);await using var cn=new SqlConnection(x.ConnectionString);await cn.OpenAsync(ct);var schema=cn.GetSchema("Databases");return schema.Rows.Cast<DataRow>().Select(r=>new DatabaseItem{ServerId=item.Id,Server=item.Name,Name=Convert.ToString(r["database_name"])??""}).Where(d=>!string.IsNullOrWhiteSpace(d.Name)).ToList();});
        return (await Task.WhenAll(tasks)).SelectMany(x=>x).OrderBy(x=>x.Server).ThenBy(x=>x.Name).ToList();
    }

    public async Task<IReadOnlyList<DatabaseObjectItem>> GetDatabaseObjectsAsync(DatabaseItem database,CancellationToken ct=default)
    {
        var resolved=await ResolveAsync(database.ServerId,database.Name,ct);
        await using var cn=new SqlConnection(resolved.ConnectionString);
        await cn.OpenAsync(ct);
        await using var cmd=new SqlCommand("""
            SELECT s.name AS SchemaName,o.name AS ObjectName,
                   CASE WHEN o.type='U' THEN 'TABLE' WHEN o.type='V' THEN 'VIEW'
                        WHEN o.type IN ('P','PC') THEN 'PROCEDURE' ELSE 'FUNCTION' END AS ObjectKind,
                   RTRIM(o.type) AS SqlObjectType
            FROM sys.objects o INNER JOIN sys.schemas s ON s.schema_id=o.schema_id
            WHERE o.is_ms_shipped=0 AND o.type IN ('U','V','P','PC','FN','IF','TF','FS','FT')
            ORDER BY ObjectKind,s.name,o.name
            """,cn)
        {
            CommandTimeout=resolved.Server.TimeoutSeconds
        };
        await using var reader=await cmd.ExecuteReaderAsync(ct);
        var result=new List<DatabaseObjectItem>();
        while(await reader.ReadAsync(ct))
        {
            var schema=reader.GetString(0);
            var name=reader.GetString(1);
            var kind=reader.GetString(2);
            if(!SqlSystemNames.IsReserved(name)&&!SqlSystemNames.IsReserved(schema)&&!string.IsNullOrWhiteSpace(name)&&!string.IsNullOrWhiteSpace(kind))
                result.Add(new(database.ServerId,database.Server,database.Name,schema,name,kind){SqlObjectType=reader.GetString(3)});
        }
        return result.OrderBy(x=>x.Kind).ThenBy(x=>x.Schema).ThenBy(x=>x.Name).ToList();
    }

    public async Task<IReadOnlySet<string>> GetDatabaseRoleMembershipsAsync(int serverId,string database,string principal,CancellationToken ct=default)
    {
        var resolved=await ResolveAsync(serverId,database,ct);
        await using var cn=new SqlConnection(resolved.ConnectionString);
        await cn.OpenAsync(ct);
        await using var cmd=new SqlCommand("""
            SELECT role.name FROM sys.database_role_members membership
            INNER JOIN sys.database_principals role ON role.principal_id=membership.role_principal_id
            INNER JOIN sys.database_principals member ON member.principal_id=membership.member_principal_id
            WHERE member.name=@principal AND role.name NOT LIKE N'%##%'
            """,cn){CommandTimeout=resolved.Server.TimeoutSeconds};
        cmd.Parameters.Add(new("@principal",SqlDbType.NVarChar,128){Value=principal});
        await using var reader=await cmd.ExecuteReaderAsync(ct);
        var result=new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        while(await reader.ReadAsync(ct))result.Add(reader.GetString(0));
        return result;
    }

    public async Task<DataTable> GetSecurityInventoryAsync(int serverId,string database,string inventoryType,CancellationToken ct=default)
    {
        var resolved=await ResolveAsync(serverId,string.IsNullOrWhiteSpace(database)?"master":database,ct);
        await using var cn=new SqlConnection(resolved.ConnectionString);await cn.OpenAsync(ct);
        await using var cmd=inventoryType=="LOGINS"
            ? new SqlCommand("""
                SELECT name AS LoginName,is_disabled AS IsDisabled,type_desc AS LoginType
                FROM sys.server_principals
                WHERE type IN ('S','U','G')
                  AND name NOT LIKE N'%##%'
                  AND name NOT LIKE N'NT AUTHORITY\%'
                  AND name NOT LIKE N'NT SERVICE\%'
                  AND name NOT LIKE N'BUILTIN\%'
                ORDER BY name
                """,cn)
            : new SqlCommand(inventoryType switch
            {
                "USERS"=>"sys.sp_helpuser",
                "ROLES"=>"sys.sp_helprole",
                "PERMISSIONS"=>"sys.sp_helprotect",
                _=>throw new InvalidOperationException("Tipo de inventario no permitido.")
            },cn){CommandType=CommandType.StoredProcedure};
        cmd.CommandTimeout=resolved.Server.TimeoutSeconds;
        await using var reader=await cmd.ExecuteReaderAsync(ct);
        var table=new DataTable();
        table.Load(reader);
        if(inventoryType=="USERS")RemoveInternalOrServicePrincipals(table,"UserName","Name");
        RemoveReservedInventoryRows(table);
        return table;
    }

    private static void RemoveReservedInventoryRows(DataTable table)
    {
        foreach(var row in table.Rows.Cast<DataRow>()
            .Where(row=>row.ItemArray.OfType<string>().Any(SqlSystemNames.IsReserved)).ToList())
            table.Rows.Remove(row);
    }

    private static void RemoveInternalOrServicePrincipals(DataTable table,params string[] candidateColumns)
    {
        var column=candidateColumns
            .Select(name=>table.Columns.Cast<DataColumn>().FirstOrDefault(x=>x.ColumnName.Equals(name,StringComparison.OrdinalIgnoreCase)))
            .FirstOrDefault(x=>x is not null);
        if(column is null)return;
        foreach(var row in table.Rows.Cast<DataRow>().Where(row=>IsInternalOrServicePrincipal(Convert.ToString(row[column]))).ToList())
            table.Rows.Remove(row);
    }

    private static bool IsInternalOrServicePrincipal(string? principal)
    {
        var name=principal?.Trim()??"";
        return SqlSystemNames.IsReserved(name)
            ||name.StartsWith("NT AUTHORITY\\",StringComparison.OrdinalIgnoreCase)
            ||name.StartsWith("NT SERVICE\\",StringComparison.OrdinalIgnoreCase)
            ||name.StartsWith("BUILTIN\\",StringComparison.OrdinalIgnoreCase)
            ||name.Equals("dbo",StringComparison.OrdinalIgnoreCase)
            ||name.Equals("guest",StringComparison.OrdinalIgnoreCase)
            ||name.Equals("sys",StringComparison.OrdinalIgnoreCase)
            ||name.Equals("INFORMATION_SCHEMA",StringComparison.OrdinalIgnoreCase);
    }

    public async Task<bool> IsLoginEnabledAsync(int serverId,string login,CancellationToken ct=default)
    {
        if(string.IsNullOrWhiteSpace(login))throw new InvalidOperationException("El login seleccionado no es válido.");
        var resolved=await ResolveAsync(serverId,"master",ct);
        await using var cn=new SqlConnection(resolved.ConnectionString);
        await cn.OpenAsync(ct);
        await using var cmd=new SqlCommand("SELECT is_disabled FROM sys.server_principals WHERE name=@login AND type IN ('S','U','G','C','K')",cn)
        {
            CommandTimeout=resolved.Server.TimeoutSeconds
        };
        cmd.Parameters.Add(new("@login",SqlDbType.NVarChar,128){Value=login});
        var value=await cmd.ExecuteScalarAsync(ct);
        if(value is null||value is DBNull)throw new InvalidOperationException($"El login {login} ya no existe en el servidor.");
        return !Convert.ToBoolean(value);
    }

    public async Task<MappedLoginState?> GetMappedLoginStateAsync(int serverId,string database,string user,CancellationToken ct=default)
    {
        if(string.IsNullOrWhiteSpace(database)||string.IsNullOrWhiteSpace(user))
            throw new InvalidOperationException("El usuario de base seleccionado no es válido.");
        var resolved=await ResolveAsync(serverId,database,ct);
        await using var cn=new SqlConnection(resolved.ConnectionString);
        await cn.OpenAsync(ct);
        await using var cmd=new SqlCommand(
            "SELECT TOP (1) sp.name AS LoginName,sp.is_disabled AS IsDisabled FROM sys.database_principals dp INNER JOIN sys.server_principals sp ON dp.sid=sp.sid WHERE dp.name=@user",
            cn){CommandTimeout=resolved.Server.TimeoutSeconds};
        cmd.Parameters.Add(new("@user",SqlDbType.NVarChar,128){Value=user});
        await using var reader=await cmd.ExecuteReaderAsync(ct);
        if(!await reader.ReadAsync(ct))return null;
        return new(reader.GetString(0),!reader.GetBoolean(1));
    }

    public async Task<SecurityPrincipalDetails> GetSecurityPrincipalDetailsAsync(
        int serverId,
        string database,
        string principal,
        SecurityNodeKind kind,
        CancellationToken ct=default)
    {
        if (string.IsNullOrWhiteSpace(principal))
            throw new InvalidOperationException("El principal seleccionado no es válido.");

        var details = new SecurityPrincipalDetails();
        if (kind == SecurityNodeKind.Login)
        {
            var loginData = await RunSystemProcedureAsync(
                serverId,
                "master",
                "sys.sp_helplogins",
                [new SqlParameter("@LoginNamePattern", SqlDbType.NVarChar, 128) { Value = principal }],
                ct);

            if (loginData.Tables.Count > 1)
            {
                foreach (DataRow row in loginData.Tables[1].Rows)
                {
                    var dbName = Cell(row, "DBName", "DatabaseName");
                    var userName = Cell(row, "UserName", "Name");
                    if (!string.IsNullOrWhiteSpace(userName))
                        details.Memberships.Add(new SecurityMembershipItem("Usuario de base", userName, dbName));
                }
            }

            var serverRoles = await RunSystemProcedureAsync(serverId, "master", "sys.sp_helpsrvrolemember", [], ct);
            foreach (DataTable table in serverRoles.Tables)
            foreach (DataRow row in table.Rows)
            {
                var member = Cell(row, "MemberName", "LoginName");
                if (!member.Equals(principal, StringComparison.OrdinalIgnoreCase)) continue;
                var role = Cell(row, "ServerRole", "RoleName");
                if (!string.IsNullOrWhiteSpace(role))
                    details.Memberships.Add(new SecurityMembershipItem("Rol de servidor", role, "Servidor"));
            }

            return details;
        }

        var helpUser = await RunSystemProcedureAsync(
            serverId,
            database,
            "sys.sp_helpuser",
            [new SqlParameter("@name_in_db", SqlDbType.NVarChar, 128) { Value = principal }],
            ct);
        foreach (DataTable table in helpUser.Tables)
        foreach (DataRow row in table.Rows)
        {
            var role = Cell(row, "RoleName");
            if (!string.IsNullOrWhiteSpace(role))
                details.Memberships.Add(new SecurityMembershipItem("Rol de base asignado", role, database));
        }

        var permissions = await RunOptionalReportProcedureAsync(
            serverId,
            database,
            "sys.sp_helprotect",
            [new SqlParameter("@username", SqlDbType.NVarChar, 128) { Value = principal }],
            ct);

        foreach (DataTable table in permissions.Tables)
        foreach (DataRow row in table.Rows)
        {
            var state = Cell(row, "ProtectType", "State");
            var permission = Cell(row, "Action", "Permission");
            var owner = Cell(row, "Owner", "Schema");
            var target = Cell(row, "Object", "ObjectName");
            var column = Cell(row, "Column", "ColumnName");
            var securableParts = new[] { owner, target, column }
                .Where(x => !string.IsNullOrWhiteSpace(x) && x != ".");
            var securable = string.Join('.', securableParts);
            var scope = !string.IsNullOrWhiteSpace(column) && column != "."
                ? "COLUMN"
                : !string.IsNullOrWhiteSpace(target) && target != "." ? "OBJECT" : "DATABASE";
            if (!string.IsNullOrWhiteSpace(permission))
                details.Permissions.Add(new SecurityPermissionItem(state, permission, scope, securable, Cell(row, "Grantor")));
        }

        return details;
    }

    private async Task<DataSet> RunOptionalReportProcedureAsync(
        int serverId,
        string database,
        string procedure,
        IReadOnlyCollection<SqlParameter> parameters,
        CancellationToken ct)
    {
        try
        {
            return await RunSystemProcedureAsync(serverId,database,procedure,parameters,ct);
        }
        catch(SqlException ex) when(IsEmptyReport(ex.Message))
        {
            return new DataSet();
        }
    }

    private static bool IsEmptyReport(string message)=>
        message.Contains("no matching rows",StringComparison.OrdinalIgnoreCase)||
        message.Contains("no hay filas que coincidan",StringComparison.OrdinalIgnoreCase)||
        message.Contains("aucune ligne correspondante",StringComparison.OrdinalIgnoreCase)||
        message.Contains("keine übereinstimmenden Zeilen",StringComparison.OrdinalIgnoreCase);

    private async Task<DataSet> RunSystemProcedureAsync(
        int serverId,
        string database,
        string procedure,
        IReadOnlyCollection<SqlParameter> parameters,
        CancellationToken ct)
    {
        var resolved = await ResolveAsync(serverId, database, ct);
        await using var cn = new SqlConnection(resolved.ConnectionString);
        await cn.OpenAsync(ct);
        await using var cmd = new SqlCommand(procedure, cn)
        {
            CommandType = CommandType.StoredProcedure,
            CommandTimeout = resolved.Server.TimeoutSeconds
        };
        foreach (var parameter in parameters) cmd.Parameters.Add(parameter);

        await using var reader = await cmd.ExecuteReaderAsync(ct);
        var result = new DataSet();
        var resultNumber = 1;
        do
        {
            if (reader.FieldCount <= 0) continue;
            var table = new DataTable($"Result{resultNumber++}");
            for (var index = 0; index < reader.FieldCount; index++)
            {
                var columnName = reader.GetName(index);
                if (string.IsNullOrWhiteSpace(columnName)) columnName = $"Column{index + 1}";
                var uniqueName = columnName;
                var suffix = 2;
                while (table.Columns.Contains(uniqueName)) uniqueName = $"{columnName}_{suffix++}";
                table.Columns.Add(uniqueName, typeof(object));
            }

            while (await reader.ReadAsync(ct))
            {
                var values = new object[reader.FieldCount];
                reader.GetValues(values);
                table.Rows.Add(values);
            }
            result.Tables.Add(table);
        }
        while (await reader.NextResultAsync(ct));

        return result;
    }

    private static string Cell(DataRow row, params string[] names)
    {
        var column = names.Select(name => row.Table.Columns.Cast<DataColumn>()
                .FirstOrDefault(x => x.ColumnName.Equals(name, StringComparison.OrdinalIgnoreCase)))
            .FirstOrDefault(x => x is not null);
        return column is null || row.IsNull(column) ? "" : Convert.ToString(row[column])?.Trim() ?? "";
    }

    public async Task<IReadOnlyList<OperationResult>> ExecuteApprovedRequestAsync(AccessRequestItem request,IEnumerable<DatabaseItem> targets,string? newLoginPassword,IReadOnlyList<AccessRequestStepItem>? steps=null,bool passwordPolicy=true,bool passwordExpiration=true,bool mustChangePassword=true,CancellationToken ct=default)
    {
        if(request.Status!="APPROVED")throw new InvalidOperationException("La solicitud debe estar aprobada.");
        if(LoginAuthentication.CreatesLogin(request.Operation))
            LoginAuthentication.ValidateSecret(request.Operation,request.TargetPrincipal,request.AuthenticationType,!string.IsNullOrEmpty(newLoginPassword));
        if(request.StepCount!=(steps?.Count??0))throw new InvalidOperationException("El listado de cambios está incompleto. Vuelva a cargar la solicitud antes de ejecutarla.");
        if(!string.IsNullOrWhiteSpace(request.Permission)&&!IsPermissionSafe(request.Permission))throw new InvalidOperationException("Permiso bloqueado por la política máxima.");
        if(!string.IsNullOrWhiteSpace(request.Role)&&IsBlockedRole(request.Role))throw new InvalidOperationException("Rol bloqueado permanentemente.");
        var targetList=targets.ToList();
        var draft=new AccessRequestDraft(request.Operation,request.TargetPrincipal,null,null,
            string.IsNullOrWhiteSpace(request.PermissionAction)?null:request.PermissionAction,
            string.IsNullOrWhiteSpace(request.Permission)?null:request.Permission,
            string.IsNullOrWhiteSpace(request.Scope)?null:request.Scope,null,
            string.IsNullOrWhiteSpace(request.Role)?null:request.Role,request.ExternalTicketNumber,request.Justification);
        var decision=await adminDb.PreviewRequestTargetsAsync(draft,targetList,ct);
        if(!decision.Allowed)throw new InvalidOperationException(decision.Reason);
        foreach(var step in steps??[])
        {
            var stepDecision=await adminDb.PreviewRequestTargetsAsync(new(step.Operation,request.TargetPrincipal,null,null,
                string.IsNullOrWhiteSpace(step.PermissionAction)?null:step.PermissionAction,
                string.IsNullOrWhiteSpace(step.Permission)?null:step.Permission,
                string.IsNullOrWhiteSpace(step.Scope)?null:step.Scope,null,
                string.IsNullOrWhiteSpace(step.Role)?null:step.Role,request.ExternalTicketNumber,request.Justification),targetList,ct);
            if(!stepDecision.Allowed)throw new InvalidOperationException(stepDecision.Reason);
        }
        foreach(var target in targetList)
        {
            var context=new PolicyContext(target.ServerId,request.Operation is "SERVER_PERMISSION_CHANGE" or "ADD_SERVER_ROLE_MEMBER" or "REMOVE_SERVER_ROLE_MEMBER"?"":target.Name);
            if(!string.IsNullOrWhiteSpace(request.Role))await ValidateRolePolicyAsync(request.Role,request.Operation,context,ct);
            if(request.Operation is "PERMISSION_CHANGE" or "SERVER_PERMISSION_CHANGE")
            {
                BuildPermissionSql(request.TargetPrincipal,request.PermissionAction,request.Permission,request.Scope,request.Securable);
                await ValidatePermissionPolicyAsync(request.Permission,request.Scope,request.PermissionAction,context,ct);
            }
            foreach(var step in steps??[])
            {
                if(!string.IsNullOrWhiteSpace(step.Role))await ValidateRolePolicyAsync(step.Role,step.Operation,context,ct);
                if(step.Operation=="PERMISSION_CHANGE")
                {
                    BuildPermissionSql(request.TargetPrincipal,step.PermissionAction,step.Permission,step.Scope,step.Securable);
                    await ValidatePermissionPolicyAsync(step.Permission,step.Scope,step.PermissionAction,context,ct);
                }
            }
        }
        if((request.Operation=="PERMISSION_CHANGE"&&request.Scope!="DATABASE"
            ||(steps??[]).Any(x=>x.Operation=="PERMISSION_CHANGE"&&x.Scope!="DATABASE"))&&targetList.Count!=1)
            throw new InvalidOperationException("Los permisos sobre esquemas, objetos o columnas requieren exactamente una base destino.");
        if(targetList.Select(x=>x.ServerId).Distinct().Count()!=1)throw new InvalidOperationException("La solicitud debe pertenecer a un único servidor. Divida cualquier solicitud histórica con varios servidores antes de ejecutarla.");
        if(request.Operation is "SERVER_PERMISSION_CHANGE" or "ADD_SERVER_ROLE_MEMBER" or "REMOVE_SERVER_ROLE_MEMBER")
        {
            if(targetList.Count!=1||targetList[0].Name!="master"||steps is {Count:>0})
                throw new InvalidOperationException("La operación de instancia requiere un único destino master y no admite pasos internos.");
            var resolved=await ResolveAsync(targetList[0].ServerId,ct:ct);
            try
            {
                await ExecuteServerAccessAsync(resolved.ConnectionString,request,new(targetList[0].ServerId),ct);
                return [new(resolved.Server.Name,"Instancia",true,"Cambio de acceso de instancia ejecutado.")];
            }
            catch(Exception error){return [new(resolved.Server.Name,"Instancia",false,error.Message)];}
        }
        if(request.Operation=="CLONE_PERMISSIONS")
        {
            if(request.StepCount!=0)throw new InvalidOperationException("El plan de copia no admite pasos internos heredados.");
            try{return await ExecutePermissionCopyAsync(request,targetList,newLoginPassword,passwordPolicy,passwordExpiration,mustChangePassword,ct);}
            catch(Exception error){return targetList.Select(x=>new OperationResult(x.Server,x.Name,false,error.Message)).ToList();}
        }
        var results=new List<OperationResult>();
        foreach(var group in targetList.GroupBy(x=>x.ServerId))
        {
            var master=await ResolveAsync(group.Key,ct:ct);
            if(request.Operation is "CREATE_SQL_LOGIN" or "CREATE_WINDOWS_LOGIN" or "CLONE_SQL_LOGIN" or "ENABLE_LOGIN" or "DISABLE_LOGIN")
            {
                try
                {
                    if(request.Operation=="CREATE_SQL_LOGIN")await EnsureLoginAsync(master.ConnectionString,request.TargetPrincipal,true,newLoginPassword,passwordPolicy,passwordExpiration,mustChangePassword,ct,failIfExists:true);
                    else if(request.Operation=="CREATE_WINDOWS_LOGIN")await EnsureLoginAsync(master.ConnectionString,request.TargetPrincipal,false,null,false,false,false,ct,failIfExists:true);
                    else if(request.Operation=="CLONE_SQL_LOGIN")await CloneLoginAsync(master.ConnectionString,request.SourcePrincipal,request.TargetPrincipal,newLoginPassword,ct);
                    else await SetLoginEnabledAsync(master.ConnectionString,request.TargetPrincipal,request.Operation=="ENABLE_LOGIN",ct);
                    if(steps is {Count:>0})
                    {
                        foreach(var target in group)
                        {
                            try
                            {
                                var db=await ResolveAsync(group.Key,target.Name,ct);
                                foreach(var step in steps.OrderBy(x=>x.Order))await ExecuteStepAsync(db.ConnectionString,request.TargetPrincipal,step,new(target.ServerId,target.Name),ct);
                                results.Add(new(master.Server.Name,target.Name,true,$"Login y {steps.Count} paso(s) de acceso ejecutados en orden."));
                            }
                            catch(Exception ex){results.Add(new(master.Server.Name,target.Name,false,$"El login fue creado, pero falló el acceso inicial: {ex.Message}"));}
                        }
                    }
                    else foreach(var db in group)results.Add(new(master.Server.Name,db.Name,true,"Operación de login completada."));
                }
                catch(Exception ex){foreach(var db in group)results.Add(new(master.Server.Name,db.Name,false,ex.Message));}
                continue;
            }
            foreach(var target in group)
            {
                try
                {
                    var db=await ResolveAsync(group.Key,target.Name,ct);
                    if(steps is {Count:>0})
                    {
                        await ExecuteDatabaseChangePlanAsync(db.ConnectionString,request,steps,new(target.ServerId,target.Name),ct);
                        results.Add(new(master.Server.Name,target.Name,true,$"{steps.Count+1} cambio(s) de acceso ejecutados en una sola transacción."));
                        continue;
                    }
                    switch(request.Operation)
                    {
                        case "CREATE_DB_USER":await EnsureUserAsync(db.ConnectionString,request.TargetPrincipal,ct);break;
                        case "MODIFY_LOGIN":await ChangeRoleAsync(db.ConnectionString,request.TargetPrincipal,request.Role,true,new(target.ServerId,target.Name),ct);break;
                        case "ADD_ROLE_MEMBER":await ChangeRoleAsync(db.ConnectionString,request.TargetPrincipal,request.Role,true,new(target.ServerId,target.Name),ct);break;
                        case "REMOVE_ROLE_MEMBER":await ChangeRoleAsync(db.ConnectionString,request.TargetPrincipal,request.Role,false,new(target.ServerId,target.Name),ct);break;
                        case "PERMISSION_CHANGE":await ChangePermissionAsync(db.ConnectionString,request.TargetPrincipal,request.PermissionAction,request.Permission,request.Scope,request.Securable,new(target.ServerId,target.Name),ct);break;
                        default:throw new InvalidOperationException("La operación aprobada no tiene un ejecutor registrado.");
                    }
                    results.Add(new(master.Server.Name,target.Name,true,"Operación aprobada ejecutada."));
                }
                catch(Exception ex){results.Add(new(master.Server.Name,target.Name,false,ex.Message));}
            }
        }
        return results;
    }

    private async Task ExecuteStepAsync(string connectionString,string principal,AccessRequestStepItem step,PolicyContext context,CancellationToken ct)
    {
        if(!string.IsNullOrWhiteSpace(step.Permission)&&!IsPermissionSafe(step.Permission))throw new InvalidOperationException("Permiso de paso bloqueado por la política máxima.");
        if(!string.IsNullOrWhiteSpace(step.Role)&&IsBlockedRole(step.Role))throw new InvalidOperationException("Rol de paso bloqueado permanentemente.");
        switch(step.Operation)
        {
            case "CREATE_DB_USER":await EnsureUserAsync(connectionString,principal,ct);break;
            case "ADD_ROLE_MEMBER":await ChangeRoleAsync(connectionString,principal,step.Role,true,context,ct);break;
            case "REMOVE_ROLE_MEMBER":await ChangeRoleAsync(connectionString,principal,step.Role,false,context,ct);break;
            case "PERMISSION_CHANGE":await ChangePermissionAsync(connectionString,principal,step.PermissionAction,step.Permission,step.Scope,step.Securable,context,ct);break;
            default:throw new InvalidOperationException($"El paso {step.Order} no tiene un ejecutor registrado.");
        }
    }

    private static async Task EnsureUserAsync(string connectionString,string login,CancellationToken ct)
    {
        await using var cn=new SqlConnection(connectionString);await cn.OpenAsync(ct);await using var cmd=new SqlCommand("sys.sp_grantdbaccess",cn){CommandType=CommandType.StoredProcedure};cmd.Parameters.Add(new("@loginame",SqlDbType.NVarChar,128){Value=login});try{await cmd.ExecuteNonQueryAsync(ct);}catch(SqlException ex)when(ex.Number==15023){}
    }
    private async Task ChangeRoleAsync(string connectionString,string principal,string role,bool add,PolicyContext context,CancellationToken ct)
    {
        if(string.IsNullOrWhiteSpace(role)||IsBlockedRole(role))throw new InvalidOperationException("Rol no permitido.");
        await ValidateRolePolicyAsync(role,add?"ADD_ROLE_MEMBER":"REMOVE_ROLE_MEMBER",context,ct);
        await EnsureUserAsync(connectionString,principal,ct);await using var cn=new SqlConnection(connectionString);await cn.OpenAsync(ct);await using var cmd=new SqlCommand(add?"sys.sp_addrolemember":"sys.sp_droprolemember",cn){CommandType=CommandType.StoredProcedure};cmd.Parameters.Add(new("@rolename",SqlDbType.NVarChar,128){Value=role});cmd.Parameters.Add(new("@membername",SqlDbType.NVarChar,128){Value=principal});await cmd.ExecuteNonQueryAsync(ct);
    }
    private static async Task SetLoginEnabledAsync(string connectionString,string login,bool enabled,CancellationToken ct)
    {var b=new SqlCommandBuilder();var sql=$"ALTER LOGIN {b.QuoteIdentifier(login)} {(enabled?"ENABLE":"DISABLE")}";await ExecuteControlledTextAsync(connectionString,sql,ct);}

    private async Task ChangePermissionAsync(string connectionString,string principal,string action,string permission,string scope,string securable,PolicyContext context,CancellationToken ct)
    {
        var sql=BuildPermissionSql(principal,action,permission,scope,securable);
        await ValidatePermissionPolicyAsync(permission,scope,action,context,ct);
        await EnsurePrincipalIsNotRoleAsync(connectionString,principal,ct);
        await using var cn=new SqlConnection(connectionString);await cn.OpenAsync(ct);
        await EnsureLivePermissionSupportedAsync(cn,null,permission,scope,ct);
        await using var command=new SqlCommand(sql,cn){CommandTimeout=60};await command.ExecuteNonQueryAsync(ct);
    }

    private static string BuildPermissionSql(string principal,string action,string permission,string scope,string securable)
    {
        if(!PolicyEditorCatalog.CanManagePermission(permission,scope))throw new InvalidOperationException("Permiso o alcance fuera de la allowlist máxima.");
        if(action is not ("GRANT" or "DENY" or "REVOKE"))throw new InvalidOperationException("Seleccione GRANT, DENY o REVOKE.");
        var b=new SqlCommandBuilder();var target=b.QuoteIdentifier(principal);string onClause="";
        var parts=ValidatePermissionTarget(scope,securable);
        var descriptor=SqlPermissionSafety.Scope(scope)!;
        if(scope=="COLUMN")onClause=$" ON OBJECT::{b.QuoteIdentifier(parts[0])}.{b.QuoteIdentifier(parts[1])} ({b.QuoteIdentifier(parts[2])})";
        else if(parts.Length>0)onClause=$" ON {descriptor.SqlClass}::{string.Join(".",parts.Select(b.QuoteIdentifier))}";
        var preposition=action=="REVOKE"?"FROM":"TO";
        return $"{action} {permission}{onClause} {preposition} {target}";
    }

    public static string[] ValidatePermissionTarget(string scope,string? securable)
    {
        if(SqlPermissionSafety.Scope(scope)?.Parts==0)
        {
            if(!string.IsNullOrWhiteSpace(securable))throw new InvalidOperationException("El ámbito DATABASE no admite un objeto destino.");
            return [];
        }
        var expected=SqlPermissionSafety.Scope(scope)?.Parts??0;
        var parts=(securable??"").Split('.',StringSplitOptions.TrimEntries);
        if(expected==0||parts.Length!=expected||parts.Any(x=>string.IsNullOrWhiteSpace(x)||x.Length>128))
            throw new InvalidOperationException("Indique un esquema, esquema.objeto o esquema.objeto.columna según el ámbito seleccionado, sin segmentos vacíos.");
        return parts;
    }

    private static void ValidatePermissionPolicySnapshot(string permission,string scope,string action,
        IReadOnlyList<PolicyPermission> permissions,IReadOnlyList<DenyRule> blocks)
    {
        if(action is not ("GRANT" or "DENY" or "REVOKE")||!permissions.Any(x=>x.Permission==permission&&x.Scope==scope
            &&PolicyEditorCatalog.CanUsePermission(x,blocks)&&(action=="GRANT"?x.AllowGrant:action=="DENY"?x.AllowDeny:x.AllowRevoke)))
            throw new InvalidOperationException("El permiso, alcance o acción ya no está autorizado por la política central.");
    }

    private async Task ValidatePermissionPolicyAsync(string permission,string scope,string action,PolicyContext context,CancellationToken ct)
    {
        if(SqlPermissionSafety.Scope(scope)?.IsServer==true&&context.Database.Length>0)
            throw new InvalidOperationException("Un permiso de instancia no puede ejecutarse como un cambio de base de datos.");
        ValidatePermissionPolicySnapshot(permission,scope,action,await adminDb.GetPolicyPermissionsAsync(context,ct),await adminDb.GetDenyRulesAsync(ct));
        var decision=await adminDb.PreviewRequestAsync(new(SqlPermissionSafety.Scope(scope)?.IsServer==true?"SERVER_PERMISSION_CHANGE":"PERMISSION_CHANGE","Validación",null,null,action,permission,scope,null,null,
            "TIC-RF-1","Revalidar permiso antes de ejecutar"),context,ct);
        if(!decision.Allowed)throw new InvalidOperationException(decision.Reason);
    }

    private static async Task EnsureLivePermissionSupportedAsync(SqlConnection cn,SqlTransaction? transaction,string permission,string scope,CancellationToken ct)
    {
        var descriptor=SqlPermissionSafety.Scope(scope)??throw new InvalidOperationException("Ámbito no compatible.");
        await using var query=new SqlCommand("""
            SELECT COUNT(*) FROM sys.fn_builtin_permissions(DEFAULT)
            WHERE permission_name=@permission AND (REPLACE(class_desc,'_',' ')=@class OR (@class='OBJECT' AND REPLACE(class_desc,'_',' ')='OBJECT OR COLUMN'))
            """,cn,transaction);
        query.Parameters.Add(new("@permission",SqlDbType.VarChar,128){Value=permission});
        query.Parameters.Add(new("@class",SqlDbType.VarChar,60){Value=descriptor.SqlClass});
        if(Convert.ToInt32(await query.ExecuteScalarAsync(ct))==0)
            throw new InvalidOperationException("SQL Server no reconoce este permiso y ámbito en la instancia seleccionada.");
    }
    private async Task ExecuteServerAccessAsync(string connectionString,AccessRequestItem request,PolicyContext context,CancellationToken ct)
    {
        await using var cn=new SqlConnection(connectionString);await cn.OpenAsync(ct);
        await using var principalCheck=new SqlCommand("SELECT type FROM sys.server_principals WHERE name=@principal",cn);
        principalCheck.Parameters.Add(new("@principal",SqlDbType.NVarChar,128){Value=request.TargetPrincipal});
        var type=await principalCheck.ExecuteScalarAsync(ct) as string;
        if(type is not ("S" or "U" or "G" or "E" or "X" or "C" or "K")||IsInternalOrServicePrincipal(request.TargetPrincipal))
            throw new InvalidOperationException("El destino debe ser un login administrable existente, no un rol.");
        string sql;
        if(request.Operation=="SERVER_PERMISSION_CHANGE")
        {
            if(SqlPermissionSafety.Scope(request.Scope)?.IsServer!=true)throw new InvalidOperationException("Seleccione un ámbito de instancia.");
            await ValidatePermissionPolicyAsync(request.Permission,request.Scope,request.PermissionAction,context,ct);
            await EnsureLivePermissionSupportedAsync(cn,null,request.Permission,request.Scope,ct);
            sql=BuildPermissionSql(request.TargetPrincipal,request.PermissionAction,request.Permission,request.Scope,request.Securable);
        }
        else
        {
            await ValidateRolePolicyAsync(request.Role,request.Operation,context,ct);
            sql=BuildServerRoleSql(request.TargetPrincipal,request.Role,request.Operation=="ADD_SERVER_ROLE_MEMBER");
        }
        await using var command=new SqlCommand(sql,cn){CommandTimeout=60};await command.ExecuteNonQueryAsync(ct);
    }
    private static string BuildServerRoleSql(string principal,string role,bool add)
    {
        if(string.IsNullOrWhiteSpace(role)||IsBlockedRole(role))throw new InvalidOperationException("Seleccione un rol de servidor válido.");
        var builder=new SqlCommandBuilder();
        return $"ALTER SERVER ROLE {builder.QuoteIdentifier(role)} {(add?"ADD":"DROP")} MEMBER {builder.QuoteIdentifier(principal)}";
    }

    private static async Task CloneLoginAsync(string connectionString,string source,string target,string? password,CancellationToken ct)
    {
        if(string.IsNullOrWhiteSpace(source)||string.IsNullOrWhiteSpace(password))throw new InvalidOperationException("Clonar un login requiere origen y una contraseña nueva.");
        await using var cn=new SqlConnection(connectionString);await cn.OpenAsync(ct);await using var query=new SqlCommand("SELECT default_database_name,default_language_name,is_disabled FROM sys.sql_logins WHERE name=@source",cn);query.Parameters.Add(new("@source",SqlDbType.NVarChar,128){Value=source});await using var reader=await query.ExecuteReaderAsync(ct);if(!await reader.ReadAsync(ct))throw new InvalidOperationException("El login origen no existe o no es un login SQL compatible.");var db=reader.GetString(0);var lang=reader.GetString(1);var disabled=reader.GetBoolean(2);await reader.CloseAsync();await using var create=new SqlCommand("sys.sp_addlogin",cn){CommandType=CommandType.StoredProcedure};create.Parameters.Add(new("@loginame",SqlDbType.NVarChar,128){Value=target});create.Parameters.Add(new("@passwd",SqlDbType.NVarChar,128){Value=password});create.Parameters.Add(new("@defdb",SqlDbType.NVarChar,128){Value=db});create.Parameters.Add(new("@deflanguage",SqlDbType.NVarChar,128){Value=lang});await create.ExecuteNonQueryAsync(ct);if(disabled)await SetLoginEnabledAsync(connectionString,target,false,ct);
    }

    private static async Task EnsurePrincipalIsNotRoleAsync(string connectionString,string principal,CancellationToken ct)
    {
        await using var cn=new SqlConnection(connectionString);
        await cn.OpenAsync(ct);
        await EnsureDatabaseUserAsync(cn,null,principal,ct);
    }

    private static async Task EnsureDatabaseUserAsync(SqlConnection cn,SqlTransaction? transaction,string principal,CancellationToken ct)
    {
        await using var cmd=new SqlCommand("SELECT type FROM sys.database_principals WHERE name=@principal",cn,transaction);
        cmd.Parameters.Add(new("@principal",SqlDbType.NVarChar,128){Value=principal});
        var type=await cmd.ExecuteScalarAsync(ct) as string;
        ValidateDatabaseUserType(principal,type);
    }

    private static void ValidateDatabaseUserType(string principal,string? type)
    {
        if(type is null)throw new InvalidOperationException($"El usuario '{principal}' no existe en la base de datos seleccionada.");
        if(type=="R")throw new InvalidOperationException($"'{principal}' es un rol. Los permisos solo pueden administrarse para usuarios; los roles son inmutables.");
        if(type is not ("S" or "U" or "G" or "E" or "X" or "C" or "K")||IsInternalOrServicePrincipal(principal))
            throw new InvalidOperationException($"'{principal}' no es un usuario de base de datos administrable.");
    }

    // The request header is the first change; internal steps hold the remaining changes.
    private static IReadOnlyList<AccessRequestStepItem> DatabaseChangePlan(AccessRequestItem request,IReadOnlyList<AccessRequestStepItem> steps)=>
        new[]{new AccessRequestStepItem(0,0,request.Operation,request.PermissionAction,request.Permission,request.Scope,request.Securable,request.Role)}
            .Concat(steps.OrderBy(x=>x.Order)).ToList();

    private async Task ExecuteDatabaseChangePlanAsync(string connectionString,AccessRequestItem request,IReadOnlyList<AccessRequestStepItem> steps,PolicyContext context,CancellationToken ct)
    {
        var plan=DatabaseChangePlan(request,steps);
        foreach(var step in plan)
        {
            if(step.Operation is not ("MODIFY_LOGIN" or "ADD_ROLE_MEMBER" or "REMOVE_ROLE_MEMBER" or "PERMISSION_CHANGE"))
                throw new InvalidOperationException("El plan de modificación contiene una operación no permitida.");
            if(!string.IsNullOrWhiteSpace(step.Permission)&&!IsPermissionSafe(step.Permission))
                throw new InvalidOperationException("Permiso de paso bloqueado por la política máxima.");
            if(!string.IsNullOrWhiteSpace(step.Role)&&IsBlockedRole(step.Role))
                throw new InvalidOperationException("Rol de paso bloqueado permanentemente.");
            if(!string.IsNullOrWhiteSpace(step.Role))await ValidateRolePolicyAsync(step.Role,step.Operation,context,ct);
        }
        await using var cn=new SqlConnection(connectionString);
        await cn.OpenAsync(ct);
        using var transaction=cn.BeginTransaction();
        var current=0;
        try
        {
            foreach(var step in plan)
            {
                current++;
                if(step.Operation=="PERMISSION_CHANGE")
                {
                    await ValidatePermissionPolicyAsync(step.Permission,step.Scope,step.PermissionAction,context,ct);
                    await EnsureDatabaseUserAsync(cn,transaction,request.TargetPrincipal,ct);
                    await EnsureLivePermissionSupportedAsync(cn,transaction,step.Permission,step.Scope,ct);
                    await using var command=new SqlCommand(BuildPermissionSql(request.TargetPrincipal,step.PermissionAction,step.Permission,step.Scope,step.Securable),cn,transaction){CommandTimeout=60};
                    await command.ExecuteNonQueryAsync(ct);
                }
                else
                {
                    if(string.IsNullOrWhiteSpace(step.Role))throw new InvalidOperationException("Seleccione un rol válido.");
                    await ValidateRolePolicyAsync(step.Role,step.Operation,context,ct);
                    await using var ensure=new SqlCommand("IF DATABASE_PRINCIPAL_ID(@principal) IS NULL EXEC sys.sp_grantdbaccess @loginame=@principal;",cn,transaction){CommandTimeout=60};
                    ensure.Parameters.Add(new("@principal",SqlDbType.NVarChar,128){Value=request.TargetPrincipal});
                    await ensure.ExecuteNonQueryAsync(ct);
                    await EnsureDatabaseUserAsync(cn,transaction,request.TargetPrincipal,ct);
                    await using var command=new SqlCommand(step.Operation=="REMOVE_ROLE_MEMBER"?"sys.sp_droprolemember":"sys.sp_addrolemember",cn,transaction){CommandType=CommandType.StoredProcedure,CommandTimeout=60};
                    command.Parameters.Add(new("@rolename",SqlDbType.NVarChar,128){Value=step.Role});
                    command.Parameters.Add(new("@membername",SqlDbType.NVarChar,128){Value=request.TargetPrincipal});
                    await command.ExecuteNonQueryAsync(ct);
                }
            }
            await transaction.CommitAsync(ct);
        }
        catch(Exception ex)
        {
            try{await transaction.RollbackAsync(CancellationToken.None);}
            catch(Exception rollbackError)
            {
                throw new InvalidOperationException($"Falló el cambio {current} de {plan.Count}: {ex.Message}. No se pudo confirmar la reversión: {rollbackError.Message}",ex);
            }
            throw new InvalidOperationException($"Falló el cambio {current} de {plan.Count}. Se revirtieron los cambios de esta base. {ex.Message}",ex);
        }
    }
    private static async Task ExecuteControlledTextAsync(string connectionString,string text,CancellationToken ct)
    {await using var cn=new SqlConnection(connectionString);await cn.OpenAsync(ct);await using var cmd=new SqlCommand(text,cn){CommandTimeout=60};await cmd.ExecuteNonQueryAsync(ct);}
    private static void ValidateRolePolicySnapshot(string role,IReadOnlyList<PolicyRole> roles,IReadOnlyList<DenyRule> blocks)
    {
        var policy=roles.FirstOrDefault(x=>x.Name.Equals(role,StringComparison.OrdinalIgnoreCase));
        if(policy is null||!PolicyEditorCatalog.CanUseRole(policy,blocks))
            throw new InvalidOperationException("El rol no está autorizado por la política vigente. Revise su activación especial si corresponde.");
    }
    private async Task ValidateRolePolicyAsync(string role,string operation,PolicyContext context,CancellationToken ct)
    {
        var serverRole=operation is "ADD_SERVER_ROLE_MEMBER" or "REMOVE_SERVER_ROLE_MEMBER";
        if(serverRole)context=new(context.ServerId);
        var policies=await adminDb.GetPolicyRolesAsync(context,ct);
        ValidateRolePolicySnapshot(role,policies.Where(x=>x.RoleScope==(serverRole?"SERVER":"DATABASE")).ToList(),await adminDb.GetDenyRulesAsync(ct));
        var decision=await adminDb.PreviewRequestAsync(new(operation,"Validación de política",null,null,null,null,null,null,role,"TIC-RF-1","Validar membresía autorizada"),context,ct);
        if(!decision.Allowed)throw new InvalidOperationException("La política actual bloquea este rol. Actualice la solicitud antes de ejecutarla.");
    }

    private static async Task EnsureLoginAsync(string connectionString,string login,bool sqlLogin,string? password,bool passwordPolicy,bool passwordExpiration,bool mustChangePassword,CancellationToken ct,bool failIfExists=false)
    {
        await using var cn=new SqlConnection(connectionString);await cn.OpenAsync(ct);
        SqlCommand cmd;
        if(sqlLogin)
        {
            if(string.IsNullOrWhiteSpace(password)||password.Length<16)throw new InvalidOperationException("La contraseña temporal debe contener al menos 16 caracteres.");
            var b=new SqlCommandBuilder();
            var mustChange=mustChangePassword?" MUST_CHANGE":"";
            var passwordLiteral=$"N'{password.Replace("'","''",StringComparison.Ordinal)}'";
            var sql=$"CREATE LOGIN {b.QuoteIdentifier(login)} WITH PASSWORD={passwordLiteral}{mustChange}, CHECK_POLICY={(passwordPolicy?"ON":"OFF")}, CHECK_EXPIRATION={(passwordExpiration?"ON":"OFF")}";
            cmd=new SqlCommand(sql,cn){CommandType=CommandType.Text};
        }
        else
        {
            await CheckWindowsAccountOnConnectionAsync(cn,login,60,ct);
            cmd=new SqlCommand(BuildWindowsLoginSql(login),cn){CommandType=CommandType.Text};
        }
        await using(cmd)try{await cmd.ExecuteNonQueryAsync(ct);}catch(SqlException ex)when(ex.Number==15025&&!failIfExists){ }
    }

    private static string BuildWindowsLoginSql(string login)
    {
        LoginAuthentication.Validate("CREATE_WINDOWS_LOGIN",login,"WINDOWS");
        return $"CREATE LOGIN {new SqlCommandBuilder().QuoteIdentifier(login)} FROM WINDOWS";
    }

}
