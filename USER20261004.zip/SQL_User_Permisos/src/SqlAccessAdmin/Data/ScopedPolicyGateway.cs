using System.Data;
using System.Text.Json;
using Microsoft.Data.SqlClient;
using SqlAccessAdmin.Models;

namespace SqlAccessAdmin.Data;

public sealed partial class AdminDbGateway
{
    private static IEnumerable<SqlParameter> ContextParameters(PolicyContext context)
    {
        context.Validate();
        return [new("@ServerId", SqlDbType.Int) { Value = context.ServerId },
            new("@DatabaseName", SqlDbType.NVarChar, 128) { Value = context.Database }];
    }
    public async Task<IReadOnlyList<PolicyPermission>> GetPolicyPermissionsAsync(PolicyContext context, CancellationToken ct = default)
    {
        var t = await ExecuteTableAsync("access.usp_Policy_PermissionList", ContextParameters(context), ct);
        return t.Rows.Cast<DataRow>().Select(r => new PolicyPermission(r.Field<string>("PermissionName")!, r.Field<string>("ScopeType")!,
            r.Field<bool>("AllowGrant"), r.Field<bool>("AllowDeny"), r.Field<bool>("AllowRevoke"), r.Field<bool>("Enabled"),
            r.Field<string>("ApprovedBy") ?? "", r.Field<DateTime>("ApprovedAt"))
        { SpecialActivationApproved = r.Field<bool>("SpecialActivationApproved"), SpecialActivationReason = r.Field<string>("SpecialActivationReason") ?? "",
            Origin = r.Field<string>("Origin")!, Supported = r.Field<bool>("Supported") }).ToList();
    }
    public async Task<IReadOnlyList<PolicyRole>> GetPolicyRolesAsync(PolicyContext context, CancellationToken ct = default)
    {
        var t = await ExecuteTableAsync("access.usp_Policy_RoleList", ContextParameters(context), ct);
        return t.Rows.Cast<DataRow>().Select(r => new PolicyRole(r.Field<string>("RoleName")!, r.Field<string>("RoleKind")!,
            r.Field<bool>("Enabled"), r.Field<string>("ApprovedBy") ?? "", r.Field<DateTime>("ApprovedAt"), r.Field<string>("Notes") ?? "")
        { SpecialActivationApproved = r.Field<bool>("SpecialActivationApproved"), SpecialActivationReason = r.Field<string>("SpecialActivationReason") ?? "",
            Origin = r.Field<string>("Origin")!, RoleScope = r.Field<string>("RoleScope")! }).Where(role => !SqlSystemNames.IsReserved(role.Name)).ToList();
    }
    public async Task UpsertPermissionAsync(PolicyContext context, PolicyPermission p, CancellationToken ct = default)
        => await ExecuteTableAsync("access.usp_Policy_PermissionUpsert", ContextParameters(context).Concat(new SqlParameter[]
        { new("@PermissionName", SqlDbType.VarChar, 128) { Value = p.Permission }, new("@ScopeType", SqlDbType.VarChar, 20) { Value = p.Scope },
          new("@AllowGrant", SqlDbType.Bit) { Value = p.AllowGrant }, new("@AllowDeny", SqlDbType.Bit) { Value = p.AllowDeny },
          new("@AllowRevoke", SqlDbType.Bit) { Value = p.AllowRevoke }, new("@Enabled", SqlDbType.Bit) { Value = p.Enabled } }), ct);
    public async Task UpsertRoleAsync(PolicyContext context, PolicyRole role, CancellationToken ct = default)
        => await ExecuteTableAsync("access.usp_Policy_RoleUpsert", ContextParameters(context).Concat(new SqlParameter[]
        { new("@RoleName", SqlDbType.NVarChar, 128) { Value = role.Name }, new("@RoleKind", SqlDbType.VarChar, 10) { Value = role.Kind },
          new("@RoleScope", SqlDbType.VarChar, 10) { Value = role.RoleScope }, new("@Enabled", SqlDbType.Bit) { Value = role.Enabled },
          new("@Notes", SqlDbType.NVarChar, 500) { Value = role.Notes } }), ct);
    public async Task ActivateSpecialPolicyAsync(PolicyContext context, PolicySpecialActivation a, CancellationToken ct = default)
    {
        a.Validate();
        await ExecuteTableAsync("access.usp_Policy_SpecialActivate", ContextParameters(context).Concat(new SqlParameter[]
        { new("@Category", SqlDbType.VarChar, 30) { Value = a.Category }, new("@Value", SqlDbType.NVarChar, 256) { Value = a.Value },
          new("@ScopeType", SqlDbType.VarChar, 20) { Value = a.Scope }, new("@Reason", SqlDbType.NVarChar, 1000) { Value = a.Reason.Trim() },
          new("@ConfirmedName", SqlDbType.NVarChar, 256) { Value = a.ConfirmedName }, new("@RiskAcknowledged", SqlDbType.Bit) { Value = a.RiskAcknowledged } }), ct);
    }
    public async Task RestorePolicyInheritanceAsync(PolicyContext context, string category, string value, string scope, CancellationToken ct = default)
        => await ExecuteTableAsync("access.usp_Policy_RestoreInheritance", ContextParameters(context).Concat(new SqlParameter[]
        { new("@Category", SqlDbType.VarChar, 30) { Value = category }, new("@Value", SqlDbType.NVarChar, 256) { Value = value },
          new("@ScopeType", SqlDbType.VarChar, 20) { Value = scope } }), ct);
    public async Task RegisterDiscoveredRolesAsync(PolicyContext context, IReadOnlyList<DiscoveredPolicyRole> roles, CancellationToken ct = default)
        => await ExecuteTableAsync("access.usp_Policy_DiscoverRoles", ContextParameters(context).Concat(new SqlParameter[]
        { new("@RolesJson", SqlDbType.NVarChar, -1) { Value = JsonSerializer.Serialize(roles) } }), ct);
    public async Task RegisterPolicyDiscoveryAsync(PolicyContext context, PolicyDiscoveryResult result, CancellationToken ct = default)
        => await ExecuteTableAsync("access.usp_Policy_DiscoverRoles", ContextParameters(context).Concat(new SqlParameter[]
        { new("@RolesJson", SqlDbType.NVarChar, -1) { Value = JsonSerializer.Serialize(result.Roles) },
          new("@PermissionsJson", SqlDbType.NVarChar, -1) { Value = JsonSerializer.Serialize(result.Permissions) } }), ct);
    public async Task<PolicyDecision> PreviewRequestAsync(AccessRequestDraft draft, PolicyContext context, CancellationToken ct = default)
    {
        var t = await ExecuteTableAsync("access.usp_AccessRequest_Preview", RequestParameters(draft, false).Concat(ContextParameters(context)), ct);
        var r = t.Rows[0];
        return new(r.Field<bool>("Allowed"), r.Field<bool>("RequiresApproval"), r.Field<string>("RiskLevel") ?? "HIGH", r.Field<string>("Reason") ?? "");
    }
    public async Task<PolicyDecision> PreviewRequestTargetsAsync(AccessRequestDraft draft, IEnumerable<DatabaseItem> targets, CancellationToken ct = default)
    {
        var decisions = new List<PolicyDecision>();
        foreach (var target in targets)
            decisions.Add(await PreviewRequestAsync(draft, new(target.ServerId, target.Name), ct));
        if (decisions.Count == 0) throw new InvalidOperationException("Seleccione un destino para validar la política.");
        return decisions.FirstOrDefault(x => !x.Allowed) ?? decisions[0] with
        { RequiresApproval = decisions.Any(x => x.RequiresApproval), Risk = decisions.Any(x => x.Risk == "HIGH") ? "HIGH" : decisions.Any(x => x.Risk == "MEDIUM") ? "MEDIUM" : "LOW" };
    }
}
