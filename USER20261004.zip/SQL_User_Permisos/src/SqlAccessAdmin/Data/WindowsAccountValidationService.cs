using System.Data;
using Microsoft.Data.SqlClient;
using SqlAccessAdmin.Models;

namespace SqlAccessAdmin.Data;

public sealed partial class DirectSqlServerService
{
    public async Task CheckWindowsAccountAsync(int serverId,string account,CancellationToken ct=default)
    {
        LoginAuthentication.Validate("CREATE_WINDOWS_LOGIN",account,"WINDOWS");
        if(IsInternalOrServicePrincipal(account))
            throw new InvalidOperationException("Las cuentas internas o de servicios no son administrables.");
        var resolved=await ResolveAsync(serverId,ct:ct);
        await using var cn=new SqlConnection(resolved.ConnectionString);
        await cn.OpenAsync(ct);
        await CheckWindowsAccountOnConnectionAsync(cn,account,resolved.Server.TimeoutSeconds,ct);
    }

    private static async Task CheckWindowsAccountOnConnectionAsync(SqlConnection connection,string account,int timeout,CancellationToken ct)
    {
        LoginAuthentication.Validate("CREATE_WINDOWS_LOGIN",account,"WINDOWS");
        await using var cmd=new SqlCommand("sys.xp_logininfo",connection)
            {CommandType=CommandType.StoredProcedure,CommandTimeout=timeout};
        cmd.Parameters.Add(new("@acctname",SqlDbType.NVarChar,128){Value=account});
        var result=cmd.Parameters.Add("@RETURN_VALUE",SqlDbType.Int);
        result.Direction=ParameterDirection.ReturnValue;
        try
        {
            // Una cuenta Windows válida sin login SQL devuelve cero filas y retorno 0.
            // ExecuteNonQuery descarta las filas: su cantidad no demuestra validez.
            await cmd.ExecuteNonQueryAsync(ct);
            ValidateWindowsAccountReturnCode(result.Value);
        }
        catch(SqlException error)when(error.Number==229)
        {
            throw new InvalidOperationException("No pudimos comprobar la cuenta en este momento. Inténtelo de nuevo o comuníquese con el administrador de la aplicación.",error);
        }
        catch(SqlException error)
        {
            throw new InvalidOperationException("No pudimos confirmar la cuenta de Windows. Revise que el dominio y el usuario estén escritos correctamente y vuelva a intentarlo.",error);
        }
    }

    private static void ValidateWindowsAccountReturnCode(object? result)
    {
        if(result is not int code||code!=0)
            throw new InvalidOperationException("No encontramos esa cuenta de Windows. Revise que el dominio y el usuario estén escritos correctamente.");
    }
}
