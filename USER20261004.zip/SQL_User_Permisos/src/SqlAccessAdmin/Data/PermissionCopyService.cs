using System.Data;
using Microsoft.Data.SqlClient;
using SqlAccessAdmin.Models;

namespace SqlAccessAdmin.Data;

public sealed partial class DirectSqlServerService
{
    public async Task<IReadOnlyList<DatabaseItem>> GetCopyDatabasesAsync(ServerItem server,CancellationToken ct=default)
    {
        var resolved=await ResolveAsync(server.Id,ct:ct);
        await using var cn=new SqlConnection(resolved.ConnectionString);await cn.OpenAsync(ct);
        await using var cmd=new SqlCommand("SELECT name FROM sys.databases WHERE state=0 AND HAS_DBACCESS(name)=1 AND name NOT IN ('tempdb','model','msdb') ORDER BY name",cn)
            {CommandTimeout=resolved.Server.TimeoutSeconds};
        await using var reader=await cmd.ExecuteReaderAsync(ct);
        var databases=new List<DatabaseItem>();
        while(await reader.ReadAsync(ct))databases.Add(new(){ServerId=server.Id,Server=server.Name,Name=reader.GetString(0)});
        return databases;
    }

    private static bool IsCopyAccessSupported(PermissionCopyAccessItem item)=>item.Kind=="Rol"
        ?!string.IsNullOrWhiteSpace(item.Role)&&!IsBlockedRole(item.Role)&&!item.Role.Equals("public",StringComparison.OrdinalIgnoreCase)
        :item.Kind=="Permiso"&&PolicyEditorCatalog.CanManagePermission(item.Permission,item.Scope)&&(item.State is "GRANT" or "GRANT_WITH_GRANT_OPTION")
            &&(item.Scope switch
            {
                "DATABASE"=>item.Schema.Length==0&&item.Object.Length==0&&item.Column.Length==0,
                "SCHEMA"=>ValidCopyIdentifier(item.Schema)&&item.Object.Length==0&&item.Column.Length==0,
                "OBJECT"=>ValidCopyIdentifier(item.Schema)&&ValidCopyIdentifier(item.Object)&&item.Column.Length==0,
                "COLUMN"=>ValidCopyIdentifier(item.Schema)&&ValidCopyIdentifier(item.Object)&&ValidCopyIdentifier(item.Column),
                _=>false
            });

    private static bool ValidCopyIdentifier(string value)=>!SqlSystemNames.IsReserved(value)&&!string.IsNullOrWhiteSpace(value)&&value.Length<=128;

    private static string BuildCopiedAccessSql(PermissionCopyAccessItem item,string principal)
    {
        if(!item.CanCopy||!IsCopyAccessSupported(item))throw new InvalidOperationException("El acceso no está autorizado para copiar.");
        var builder=new SqlCommandBuilder();var user=builder.QuoteIdentifier(principal);
        return item.Kind=="Rol"?$"ALTER ROLE {builder.QuoteIdentifier(item.Role)} ADD MEMBER {user}":
            $"GRANT {item.Permission}"+(item.Scope switch
            {
                "SCHEMA"=>$" ON SCHEMA::{builder.QuoteIdentifier(item.Schema)}",
                "OBJECT"=>$" ON OBJECT::{builder.QuoteIdentifier(item.Schema)}.{builder.QuoteIdentifier(item.Object)}",
                "COLUMN"=>$" ON OBJECT::{builder.QuoteIdentifier(item.Schema)}.{builder.QuoteIdentifier(item.Object)} ({builder.QuoteIdentifier(item.Column)})",
                _=>""
            })+$" TO {user}";
    }
    public async Task<IReadOnlyList<PermissionCopySourceUser>> GetCopySourceUsersAsync(DatabaseItem database,CancellationToken ct=default)
    {
        var resolved=await ResolveAsync(database.ServerId,database.Name,ct);
        await using var cn=new SqlConnection(resolved.ConnectionString);await cn.OpenAsync(ct);
        await using var cmd=new SqlCommand("SELECT COALESCE(sp.name COLLATE DATABASE_DEFAULT,dp.name),dp.name FROM sys.database_principals dp LEFT JOIN sys.server_principals sp ON sp.sid=dp.sid AND sp.type IN ('S','U','G','E','X') WHERE dp.type IN ('S','U','G','E','X') AND dp.principal_id>4 ORDER BY dp.name",cn)
            {CommandTimeout=resolved.Server.TimeoutSeconds};
        await using var reader=await cmd.ExecuteReaderAsync(ct);
        var users=new List<PermissionCopySourceUser>();
        while(await reader.ReadAsync(ct))if(!IsInternalOrServicePrincipal(reader.GetString(0))&&!IsInternalOrServicePrincipal(reader.GetString(1)))users.Add(new(reader.GetString(0),reader.GetString(1)));
        return users;
    }

    public Task<(Dictionary<string,List<DatabaseItem>> Sources,List<string> Errors)> GetCopySourceCatalogAsync(
        IReadOnlyList<DatabaseItem> databases,Action<string> progress,CancellationToken ct=default)
        =>ReadCopySourceCatalogAsync(databases,GetCopySourceUsersAsync,progress,ct);

    private static async Task<(Dictionary<string,List<DatabaseItem>> Sources,List<string> Errors)> ReadCopySourceCatalogAsync(
        IReadOnlyList<DatabaseItem> databases,
        Func<DatabaseItem,CancellationToken,Task<IReadOnlyList<PermissionCopySourceUser>>> readUsers,
        Action<string> progress,CancellationToken ct)
    {
        var sources=new Dictionary<string,List<DatabaseItem>>(StringComparer.OrdinalIgnoreCase);
        var errors=new List<string>();
        foreach(var database in databases)
        {
            ct.ThrowIfCancellationRequested();progress(database.Name);
            try
            {
                var users=await readUsers(database,ct);
                ct.ThrowIfCancellationRequested();
                foreach(var user in users)
                {
                    if(!sources.TryGetValue(user.Name,out var list))sources[user.Name]=list=[];
                    list.Add(new(){ServerId=database.ServerId,Server=database.Server,Name=database.Name,CopySourceUser=user.SourceUser});
                }
            }
            catch(OperationCanceledException)when(ct.IsCancellationRequested){throw;}
            catch(Exception error){ct.ThrowIfCancellationRequested();errors.Add($"{database.Name}: {error.Message}");}
        }
        return(sources,errors);
    }

    public async Task EnsureCopyTargetAvailableAsync(int serverId,string target,IEnumerable<DatabaseItem> databases,CancellationToken ct=default)
    {
        if(string.IsNullOrWhiteSpace(target)||target.Trim().Length>128||IsInternalOrServicePrincipal(target))
            throw new InvalidOperationException("Indique un nombre administrable de 1 a 128 caracteres.");
        foreach(var database in new[]{"master"}.Concat(databases.Select(x=>x.Name)).Distinct(StringComparer.OrdinalIgnoreCase))
        {
            var resolved=await ResolveAsync(serverId,database,ct);
            await using var cn=new SqlConnection(resolved.ConnectionString);await cn.OpenAsync(ct);
            await using var cmd=new SqlCommand("SELECT COUNT(*) FROM sys.database_principals WHERE name=@name"+
                (database=="master"?"; SELECT COUNT(*) FROM sys.server_principals WHERE name=@name":""),cn)
                {CommandTimeout=resolved.Server.TimeoutSeconds};
            cmd.Parameters.Add(new("@name",SqlDbType.NVarChar,128){Value=target.Trim()});
            await using var reader=await cmd.ExecuteReaderAsync(ct);
            do
            {
                if(await reader.ReadAsync(ct)&&reader.GetInt32(0)>0)
                    throw new InvalidOperationException($"El nombre '{target.Trim()}' ya existe en el servidor o en {database}. Elija un nombre nuevo.");
            }while(await reader.NextResultAsync(ct));
        }
    }

    public async Task<IReadOnlyList<PermissionCopyAccessItem>> GetPermissionCopyAccessAsync(DatabaseItem database,string source,CancellationToken ct=default)
    {
        var resolved=await ResolveAsync(database.ServerId,database.Name,ct);
        await using var cn=new SqlConnection(resolved.ConnectionString);await cn.OpenAsync(ct);
        await EnsureDatabaseUserAsync(cn,null,source,ct);
        await using var cmd=new SqlCommand("""
            SELECT r.name FROM sys.database_role_members m
            JOIN sys.database_principals r ON r.principal_id=m.role_principal_id
            JOIN sys.database_principals u ON u.principal_id=m.member_principal_id WHERE u.name=@source AND r.name NOT LIKE N'%##%' ORDER BY r.name;
            SELECT p.state_desc,p.permission_name,
                CASE WHEN p.class=0 THEN 'DATABASE' WHEN p.class=3 THEN 'SCHEMA'
                     WHEN p.class=1 AND p.minor_id=0 THEN 'OBJECT' WHEN p.class=1 THEN 'COLUMN' ELSE p.class_desc END,
                COALESCE(CASE WHEN p.class=3 THEN SCHEMA_NAME(p.major_id) WHEN p.class=1 THEN OBJECT_SCHEMA_NAME(p.major_id) END,N''),
                COALESCE(CASE WHEN p.class=1 THEN OBJECT_NAME(p.major_id) END,N''),
                COALESCE(CASE WHEN p.class=1 AND p.minor_id>0 THEN COL_NAME(p.major_id,p.minor_id) END,N'')
            FROM sys.database_permissions p JOIN sys.database_principals u ON u.principal_id=p.grantee_principal_id
            WHERE u.name=@source ORDER BY p.class,p.major_id,p.minor_id,p.permission_name;
            """,cn){CommandTimeout=resolved.Server.TimeoutSeconds};
        cmd.Parameters.Add(new("@source",SqlDbType.NVarChar,128){Value=source});
        var items=new List<PermissionCopyAccessItem>();
        await using var reader=await cmd.ExecuteReaderAsync(ct);
        while(await reader.ReadAsync(ct))items.Add(new(database.Name,"Rol","Asignado","","DATABASE","","","",reader.GetString(0)));
        await reader.NextResultAsync(ct);
        while(await reader.ReadAsync(ct))items.Add(new(database.Name,"Permiso",reader.GetString(0),reader.GetString(1),reader.GetString(2),reader.GetString(3),reader.GetString(4),reader.GetString(5),""));
        await reader.CloseAsync();
        var result=new List<PermissionCopyAccessItem>();
        var decisions=new Dictionary<string,PolicyDecision>(StringComparer.OrdinalIgnoreCase);
        // Omitir una denegación o excepción por columna podría ampliar el acceso del destino.
        if(items.Any(x=>x.State is "DENY" or "REVOKE"))
            return items.Select(x=>x with{CopyStatus="Requiere revisión del administrador"}).ToList();
        var policyRoles=await adminDb.GetPolicyRolesAsync(new(database.ServerId,database.Name),ct);
        var policyBlocks=await adminDb.GetDenyRulesAsync(ct);
        foreach(var item in items)
        {
            var supported=IsCopyAccessSupported(item);
            if(item.Kind=="Rol")supported=supported&&policyRoles.Any(x=>x.Name.Equals(item.Role,StringComparison.OrdinalIgnoreCase)&&PolicyEditorCatalog.CanUseRole(x,policyBlocks));
            if(!supported){result.Add(item with{CopyStatus="No se copiará"});continue;}
            var key=item.Kind=="Rol"?$"ROLE:{item.Role}":$"GRANT:{item.Permission}:{item.Scope}";
            if(!decisions.TryGetValue(key,out var decision))
            {
                decision=await adminDb.PreviewRequestAsync(new(item.Kind=="Rol"?"ADD_ROLE_MEMBER":"PERMISSION_CHANGE",source,null,null,
                    item.Kind=="Rol"?null:"GRANT",item.Kind=="Rol"?null:item.Permission,item.Scope,null,item.Kind=="Rol"?item.Role:null,"TIC-RF-1","Validar copia de accesos"),new(database.ServerId,database.Name),ct);
                decisions.Add(key,decision);
            }
            result.Add(item with{CanCopy=decision.Allowed,CopyStatus=decision.Allowed?
                item.State=="GRANT_WITH_GRANT_OPTION"?"Se copiará sin permitir que el usuario lo asigne a otros":"Se copiará":"No se copiará"});
        }
        return result;
    }

    public async Task<PermissionCopyPlan> ValidatePermissionCopyPlanAsync(AccessRequestDraft draft,IReadOnlyList<DatabaseItem> targets,CancellationToken ct=default)
    {
        LoginAuthentication.Validate(draft.Operation,draft.TargetPrincipal,draft.AuthenticationType);
        if(targets.Count==0||targets.Select(x=>x.ServerId).Distinct().Count()!=1)throw new InvalidOperationException("La copia requiere bases de un único servidor.");
        if(string.Equals(draft.SourcePrincipal,draft.TargetPrincipal,StringComparison.OrdinalIgnoreCase))throw new InvalidOperationException("Origen y destino deben ser distintos.");
        var plan=draft.CopyPlan??throw new InvalidOperationException("Esta copia no tiene un desglose guardado. Genere una solicitud nueva con los accesos por base.");
        ValidateCopyPlanTargets(plan,targets);
        if(draft.Securable!=plan.Fingerprint)throw new InvalidOperationException("La huella no coincide con el desglose guardado de copia.");
        await EnsureCopyTargetAvailableAsync(targets[0].ServerId,draft.TargetPrincipal,targets,ct);
        var liveDatabases=new List<PermissionCopyDatabasePlan>();
        foreach(var target in targets)
        {
            var databasePlan=plan.Databases.Single(x=>x.Database==target.Name);
            liveDatabases.Add(new(target.Name,databasePlan.SourceUser,await GetPermissionCopyAccessAsync(target,databasePlan.SourceUser,ct)));
        }
        var accesses=liveDatabases.SelectMany(x=>x.Accesses).ToList();
        if(accesses.Any(x=>x.State is "DENY" or "REVOKE"))throw new InvalidOperationException("La copia está bloqueada: no se pueden omitir denegaciones o excepciones de acceso del origen.");
        if(!accesses.Any(x=>x.CanCopy))throw new InvalidOperationException("El usuario origen no tiene roles o permisos autorizados para copiar.");
        if(draft.Securable!=new PermissionCopyPlan(2,liveDatabases).Fingerprint)
            throw new InvalidOperationException("Los accesos del origen o su política cambiaron. Vuelva a cargar el origen y genere una solicitud nueva.");
        return plan;
    }

    private static void ValidateCopyPlanTargets(PermissionCopyPlan plan,IReadOnlyList<DatabaseItem> targets)
    {
        PermissionCopyPlan.FromJson(plan.ToJson());
        if(targets.Select(x=>x.Name).Distinct(StringComparer.Ordinal).Count()!=targets.Count
            ||!targets.Select(x=>x.Name).ToHashSet(StringComparer.Ordinal).SetEquals(plan.Databases.Select(x=>x.Database)))
            throw new InvalidOperationException("Las bases destino no coinciden con el detalle de la solicitud.");
        foreach(var database in plan.Databases)
        {
            if(IsInternalOrServicePrincipal(database.SourceUser))throw new InvalidOperationException("El usuario origen de una base no es administrable.");
            if(database.Accesses.Where(x=>x.CanCopy).Any(x=>!IsCopyAccessSupported(x)))throw new InvalidOperationException("El plan contiene un acceso no permitido.");
            if(database.Accesses.Select(x=>x.Identity).Distinct(StringComparer.Ordinal).Count()!=database.Accesses.Count)
                throw new InvalidOperationException("El plan contiene un acceso duplicado.");
        }
    }

    private async Task<IReadOnlyList<OperationResult>> ExecutePermissionCopyAsync(AccessRequestItem request,IReadOnlyList<DatabaseItem> targets,
        string? password,bool passwordPolicy,bool passwordExpiration,bool mustChangePassword,CancellationToken ct)
    {
        LoginAuthentication.ValidateSecret(request.Operation,request.TargetPrincipal,request.AuthenticationType,!string.IsNullOrEmpty(password));
        var sqlLogin=request.AuthenticationType=="SQL";
        var cloneCheck=await adminDb.PreviewRequestAsync(new(request.Operation,request.TargetPrincipal,request.SourcePrincipal,request.AuthenticationType,null,null,null,request.Securable,null,request.ExternalTicketNumber,request.Justification),ct);
        if(!cloneCheck.Allowed)throw new InvalidOperationException(cloneCheck.Reason);
        var savedPlan=await adminDb.GetRequestCopyPlanAsync(request.Id,ct);
        var plan=await ValidatePermissionCopyPlanAsync(new(request.Operation,request.TargetPrincipal,request.SourcePrincipal,request.AuthenticationType,null,null,null,request.Securable,null,request.ExternalTicketNumber,request.Justification){CopyPlan=savedPlan},targets,ct);
        var createCheck=await adminDb.PreviewRequestAsync(new(LoginAuthentication.CreationOperation(request.AuthenticationType),request.TargetPrincipal,null,request.AuthenticationType,null,null,null,null,null,request.ExternalTicketNumber,request.Justification),ct);
        var userCheck=await adminDb.PreviewRequestAsync(new("CREATE_DB_USER",request.TargetPrincipal,null,null,null,null,null,null,null,request.ExternalTicketNumber,request.Justification),ct);
        if(!createCheck.Allowed||!userCheck.Allowed)throw new InvalidOperationException("La política debe permitir crear el tipo de login seleccionado y sus usuarios de base.");
        var master=await ResolveAsync(targets[0].ServerId,ct:ct);
        // La ruta de copia no acepta que un login existente sustituya al nuevo.
        await EnsureLoginAsync(master.ConnectionString,request.TargetPrincipal,sqlLogin,sqlLogin?password:null,
            sqlLogin&&passwordPolicy,sqlLogin&&passwordExpiration,sqlLogin&&mustChangePassword,ct,failIfExists:true);
        var results=new List<OperationResult>();
        var builder=new SqlCommandBuilder();
        foreach(var target in targets)
        {
            try
            {
                var resolved=await ResolveAsync(target.ServerId,target.Name,ct);
                await using var cn=new SqlConnection(resolved.ConnectionString);
                await cn.OpenAsync(ct);
                await using var transaction=(SqlTransaction)await cn.BeginTransactionAsync(ct);
                try
                {
                    var databasePlan=plan.Databases.Single(x=>x.Database==target.Name);
                    await EnsureDatabaseUserAsync(cn,transaction,databasePlan.SourceUser,ct);
                    var user=builder.QuoteIdentifier(request.TargetPrincipal);
                    await using(var create=new SqlCommand($"CREATE USER {user} FOR LOGIN {user}",cn,transaction))await create.ExecuteNonQueryAsync(ct);
                    var changes=databasePlan.Accesses.Where(x=>x.CanCopy).ToList();
                    foreach(var item in changes)
                    {
                        if(item.Kind=="Rol")await ValidateRolePolicyAsync(item.Role,"ADD_ROLE_MEMBER",new(target.ServerId,target.Name),ct);
                        else await ValidatePermissionPolicyAsync(item.Permission,item.Scope,"GRANT",new(target.ServerId,target.Name),ct);
                        if(item.Kind=="Permiso")await EnsureLivePermissionSupportedAsync(cn,transaction,item.Permission,item.Scope,ct);
                        var sql=BuildCopiedAccessSql(item,request.TargetPrincipal);
                        await using var cmd=new SqlCommand(sql,cn,transaction){CommandTimeout=resolved.Server.TimeoutSeconds};
                        await cmd.ExecuteNonQueryAsync(ct);
                    }
                    await transaction.CommitAsync(ct);
                    results.Add(new(target.Server,target.Name,true,$"Login nuevo creado; usuario y {changes.Count} acceso(s) copiados en una transacción."));
                }
                catch(Exception error)
                {
                    try{await transaction.RollbackAsync(CancellationToken.None);}
                    catch(Exception rollback){throw new InvalidOperationException($"{error.Message}. No se pudo confirmar la reversión: {rollback.Message}",error);}
                    throw new InvalidOperationException($"Se revirtió la copia de esta base. {error.Message}",error);
                }
            }
            catch(Exception error){results.Add(new(target.Server,target.Name,false,$"El login nuevo permanece creado. {error.Message}"));}
        }
        return results;
    }
}
