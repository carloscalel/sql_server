using System.Data;
using Microsoft.Data.SqlClient;
using SqlAccessAdmin.Models;

namespace SqlAccessAdmin.Data;

public sealed partial class DirectSqlServerService : IPolicyDiscovery
{
    public Task<IReadOnlyList<DatabaseItem>> GetPolicyDatabasesAsync(ServerItem server, CancellationToken ct = default)
    {
        server.IsSelected = true;
        return GetDatabasesAsync([server], ct);
    }
    public async Task<PolicyDiscoveryResult> DiscoverPolicyAsync(PolicyContext context, CancellationToken ct = default)
    {
        context.Validate();
        if (context.ServerId == 0) return new([]);
        var resolved = await ResolveAsync(context.ServerId, context.Database.Length == 0 ? "master" : context.Database, ct);
        await using var cn = new SqlConnection(resolved.ConnectionString); await cn.OpenAsync(ct);
        var visibilitySql = context.Database.Length == 0
            ? "SELECT IIF(HAS_PERMS_BY_NAME(NULL,NULL,'VIEW ANY DEFINITION')=1 OR HAS_PERMS_BY_NAME(NULL,NULL,'VIEW ANY SECURITY DEFINITION')=1 OR HAS_PERMS_BY_NAME(NULL,NULL,'ALTER ANY SERVER ROLE')=1,1,0)"
            : "SELECT IIF(HAS_PERMS_BY_NAME(DB_NAME(),'DATABASE','VIEW DEFINITION')=1 OR HAS_PERMS_BY_NAME(DB_NAME(),'DATABASE','VIEW SECURITY DEFINITION')=1 OR HAS_PERMS_BY_NAME(DB_NAME(),'DATABASE','ALTER ANY ROLE')=1,1,0)";
        await using var visibility = new SqlCommand(visibilitySql, cn);
        if (Convert.ToInt32(await visibility.ExecuteScalarAsync(ct)) != 1)
            throw new InvalidOperationException("La cuenta técnica no puede consultar el catálogo completo de roles de este destino. El DBA debe revisar sus permisos de visibilidad; no se sincronizó un catálogo parcial.");
        var sql = context.Database.Length == 0
            ? "SELECT name,is_fixed_role FROM sys.server_principals WHERE type='R' AND name<>N'public' AND name NOT LIKE N'%##%' ORDER BY name"
            : "SELECT name,is_fixed_role FROM sys.database_principals WHERE type='R' AND name<>N'public' AND name NOT LIKE N'%##%' ORDER BY name";
        await using var command = new SqlCommand(sql, cn) { CommandTimeout = resolved.Server.TimeoutSeconds };
        await using var reader = await command.ExecuteReaderAsync(ct);
        var roles = new List<DiscoveredPolicyRole>();
        while (await reader.ReadAsync(ct)) roles.Add(new(reader.GetString(0), reader.GetBoolean(1) ? "FIXED" : "CUSTOM",
            context.Database.Length == 0 ? "SERVER" : "DATABASE", "Rol descubierto en " + (context.Database.Length == 0 ? "la instancia" : context.Database)));
        await reader.CloseAsync();
        await using var permissionsCommand = new SqlCommand("SELECT permission_name,class_desc FROM sys.fn_builtin_permissions(DEFAULT)", cn);
        await using var permissionsReader = await permissionsCommand.ExecuteReaderAsync(ct);
        var permissions = new List<DiscoveredPolicyPermission>();
        while (await permissionsReader.ReadAsync(ct))
        {
            permissions.AddRange(SqlPermissionSafety.DiscoverPermissions(permissionsReader.GetString(0), permissionsReader.GetString(1)));
        }
        return new(roles) { Permissions = permissions };
    }
}
