using SqlAccessAdmin.Models;

namespace SqlAccessAdmin.Data;

public interface IPolicyStore
{
    Task<IReadOnlyList<PolicyPermission>> GetPolicyPermissionsAsync(CancellationToken ct = default);
    Task<IReadOnlyList<PolicyRole>> GetPolicyRolesAsync(CancellationToken ct = default);
    Task<IReadOnlyList<DenyRule>> GetDenyRulesAsync(CancellationToken ct = default);
    Task UpsertPermissionAsync(PolicyPermission permission, CancellationToken ct = default);
    Task UpsertRoleAsync(PolicyRole role, CancellationToken ct = default);
    Task UpsertDenyRuleAsync(string category, string value, string reason, CancellationToken ct = default);
    Task ActivateSpecialPolicyAsync(PolicySpecialActivation activation, CancellationToken ct = default);
    Task<IReadOnlyList<ServerItem>> GetServersAsync(CancellationToken ct = default) => Task.FromResult<IReadOnlyList<ServerItem>>([]);
    Task<IReadOnlyList<PolicyPermission>> GetPolicyPermissionsAsync(PolicyContext context, CancellationToken ct = default)
        => context == PolicyContext.General ? GetPolicyPermissionsAsync(ct) : throw new NotSupportedException("Falta la política por destino.");
    Task<IReadOnlyList<PolicyRole>> GetPolicyRolesAsync(PolicyContext context, CancellationToken ct = default)
        => context == PolicyContext.General ? GetPolicyRolesAsync(ct) : throw new NotSupportedException("Falta la política por destino.");
    Task UpsertPermissionAsync(PolicyContext context, PolicyPermission permission, CancellationToken ct = default)
        => context == PolicyContext.General ? UpsertPermissionAsync(permission, ct) : throw new NotSupportedException();
    Task UpsertRoleAsync(PolicyContext context, PolicyRole role, CancellationToken ct = default)
        => context == PolicyContext.General ? UpsertRoleAsync(role, ct) : throw new NotSupportedException();
    Task ActivateSpecialPolicyAsync(PolicyContext context, PolicySpecialActivation activation, CancellationToken ct = default)
        => context == PolicyContext.General ? ActivateSpecialPolicyAsync(activation, ct) : throw new NotSupportedException();
    Task RestorePolicyInheritanceAsync(PolicyContext context, string category, string value, string scope, CancellationToken ct = default)
        => throw new NotSupportedException();
    Task RegisterDiscoveredRolesAsync(PolicyContext context, IReadOnlyList<DiscoveredPolicyRole> roles, CancellationToken ct = default)
        => throw new NotSupportedException();
    Task RegisterPolicyDiscoveryAsync(PolicyContext context, PolicyDiscoveryResult result, CancellationToken ct = default)
        => RegisterDiscoveredRolesAsync(context, result.Roles, ct);
}

public interface IPolicyDiscovery
{
    Task<IReadOnlyList<DatabaseItem>> GetPolicyDatabasesAsync(ServerItem server, CancellationToken ct = default);
    Task<PolicyDiscoveryResult> DiscoverPolicyAsync(PolicyContext context, CancellationToken ct = default);
}
