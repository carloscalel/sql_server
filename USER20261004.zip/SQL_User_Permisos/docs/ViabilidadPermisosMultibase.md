# Viabilidad de permisos a objetos multibase

Los tres escenarios son viables dentro del mismo servidor SQL Server. Un login puede tener un usuario en cada base necesaria, con membresías de rol y permisos sobre objetos independientes por base. SQL Server exige que el usuario tenga acceso a cada base donde recibirá permisos; véase [GRANT](https://learn.microsoft.com/en-us/sql/t-sql/statements/grant-transact-sql?view=sql-server-ver17).

| Escenario | Base 1 | Base 2 |
| --- | --- | --- |
| 1 | Crear usuario y asignar `db_datareader` | Crear usuario y conceder el permiso sobre el objeto elegido |
| 2 | Crear usuario y conceder permisos solo sobre sus objetos elegidos | Crear usuario y conceder permisos solo sobre sus objetos elegidos |
| 3 | Crear usuario, asignar `db_datareader` y conceder el permiso puntual elegido | Crear usuario y asignar `db_datareader` |

En el escenario 3, un `SELECT` adicional sobre una tabla o vista de Base 1 normalmente es redundante: `db_datareader` ya da lectura amplia en esa base. Un permiso puntual no limita el rol existente. `EXECUTE` sobre un procedimiento o una función escalar sí puede añadir un acceso distinto. Referencia: [Roles de base de datos](https://learn.microsoft.com/en-us/sql/relational-databases/security/authentication-access/database-level-roles?view=sql-server-ver17).

## Restricciones actuales de la aplicación

- `AccessRequestStepDraft` y `AccessRequestStepItem` guardan operación, rol, permiso, ámbito y objeto, pero no la base destino de cada paso (`Models/DomainModels.cs`).
- `AdminDbGateway.CreateRequestAsync` envía un catálogo de bases y otro de pasos; el tipo `access.AccessRequestStepType` no incluye una base por paso (`Data/AdminDbGateway.cs`).
- `DirectSqlServerService.ExecuteApprovedRequestAsync` crea el login una vez y aplica todos los pasos a cada base de la solicitud. Por tanto, no permite distinguir un rol para Base 1 de un objeto para Base 2 (`Data/DirectSqlServerService.cs`).
- `24_AutenticacionSqlWindows.sql` rechaza más de un destino cuando hay permisos de objeto, con el error 51339. Esta protección debe conservarse para las solicitudes de formato anterior.
- El asistente almacena una sola base y descarta los objetos al cambiarla (`ViewModels/CreateUserWizardViewModel.cs`).

**No basta con habilitar varias bases en el selector o eliminar el bloqueo SQL.** Con el ejecutor actual se repetirían roles y permisos en bases distintas de las elegidas; si coinciden los nombres de objetos, podría concederse acceso no solicitado.

## Diseño recomendado para una implementación posterior

1. Mantener un login y una solicitud, con un plan de cambios explícito por base. Cada paso de base debe guardar `DatabaseName`; la cabecera crea el login una sola vez. La identidad de un objeto debe incluir base, esquema y nombre, junto con el tipo SQL para validar sus permisos.
2. Mantener independientes los roles y los objetos. Los roles generales pueden seguir aplicándose a las bases marcadas, mientras cada fila de objeto guarda su propia base. Los destinos efectivos son la unión de las bases con roles/mapeo y las bases con objetos, sin duplicados.
3. Migrar el contrato de adminDB: añadir la base destino a los pasos persistidos, crear un tipo de tabla versionado (por ejemplo, `AccessRequestStepTypeV2`) y un procedimiento de creación compatible con el nuevo contrato. Preservar las solicitudes anteriores y su regla de una sola base para objetos; no inferir destinos multibase para pasos históricos que no los guardaron.
4. Validar en cliente y adminDB que cada paso pertenece a un destino de esa solicitud y al único servidor de trabajo. Revalidar política, disponibilidad del usuario y existencia/tipo de cada objeto antes de ejecutar. Duplicados y comparaciones de solicitudes deben incluir la base de cada cambio.
5. Mostrar en la matriz una columna **Base de datos**. Cambiar la base de consulta debe conservar los objetos agregados de otras bases. La confirmación y el historial deben agrupar los cambios por base para que el operador revise el alcance real antes de aprobar.
6. Filtrar los pasos por base durante la ejecución y crear cada usuario una sola vez. Usar una transacción por base para sus cambios y mostrar resultados por base. Es necesario registrar qué bases/pasos finalizaron para reintentar solo los fallidos, sin intentar crear de nuevo el login ni volver a aplicar indiscriminadamente todo el plan.

Una ejecución multibase puede quedar parcialmente completada si una base falla. La transacción por base no equivale a una transacción global; el seguimiento de resultados y los reintentos forman parte del cambio. Los tres escenarios deben probarse también con objetos de igual nombre en bases diferentes y con un fallo intermedio.

La estimación cualitativa es **complejidad media-alta**: afecta formulario, modelo, persistencia SQL, aprobación/historial y ejecutor. No exige cambiar la autenticación SQL/Windows ni crear relaciones de confianza entre bases para conceder permisos independientes. Este documento analiza la viabilidad; no habilita todavía el formato multibase.

## Funciones: cambio implementado en este trabajo

La consulta existente ya enumeraba funciones definidas por el usuario (`FN`, `FS`, `IF`, `TF`, `FT`). Ahora conserva el tipo SQL, muestra etiquetas diferenciadas y añade un filtro **Funciones** al selector. Los permisos de uso ofrecidos por la aplicación son `EXECUTE` para funciones escalares SQL/CLR y `SELECT` para funciones tabulares SQL/CLR, siempre sujetos a la política central. El mismo criterio se aplica a Crear usuario y Modificar accesos; una función sin tipo resuelto no habilita permisos.

La lista corresponde a funciones definidas en la base, no a funciones integradas como `GETDATE()` o `COUNT()`. Referencias: [Tipos de sys.objects](https://learn.microsoft.com/en-us/sql/relational-databases/system-catalog-views/sys-objects-transact-sql?view=sql-server-ver17) y [GRANT: permisos de funciones](https://learn.microsoft.com/en-us/sql/t-sql/statements/grant-transact-sql?view=sql-server-ver17).
