# Política de acceso por instancia y base

## Instalación

En una instalación con los scripts 01–26 aplicados, respaldar adminDB y revisar y ejecutar manualmente:

1. InsumosProduccion/27_PoliticaAccesoPorInstanciaYBase.sql
2. InsumosProduccion/28_CatalogoCredencialesInstancia.sql
3. InsumosProduccion/99_ValidarInstalacion.sql
4. Reiniciar la aplicación actualizada.

No se han ejecutado estos scripts ni cambiado accesos en SQL Server desde esta tarea. Las pruebas locales usan dobles en memoria y renderizado WPF; la validación sintáctica no sustituye una instalación de prueba con SQL Server real.

Si una ejecución anterior de 27 falló por intercalaciones distintas (Msg 468) y después mostró un catálogo inexistente (Msg 208), usar el script corregido y volver a ejecutarlo **completo**, después de respaldar adminDB. No borrar tablas ni reglas: la creación y la importación son repetibles. El catálogo interno de SQL se normaliza a DATABASE_DEFAULT antes de compararlo con adminDB. SSMS puede continuar después de un error entre lotes GO; el mensaje final no reemplaza revisar todos los errores ni ejecutar el validador 99.

El script 27 conserva las tablas antiguas como referencia e importa su configuración únicamente cuando no existe la nueva regla. Esas tablas antiguas ya no son la fuente de la política efectiva: no reaplicar migraciones anteriores después de 27. Las nuevas tablas y procedimientos residen en access, dentro de la base central.

El contrato de nombres de permisos usa 128 caracteres en catálogo, reglas, solicitudes, parámetros SQL y aplicación. El script amplía las columnas existentes conservando los datos y crea AccessRequestStepPolicyType para los pasos, sin eliminar el tipo anterior. Para recuperarse del error 51401 de una versión anterior de 27, detener la aplicación, respaldar adminDB y ejecutar completo el script corregido; aplicar 99 y desplegar el ejecutable actualizado antes de volver a operar. No ignorar el error ni filtrar los permisos largos. Microsoft documenta permission_name como nvarchar(60) en [sys.fn_builtin_permissions](https://learn.microsoft.com/en-us/sql/relational-databases/system-functions/sys-fn-builtin-permissions-transact-sql).

Los roles personalizados del catálogo general antiguo se conservan como referencia, pero no se habilitan automáticamente en todos los destinos por coincidencia de nombre. Actualizar y autorizarlos en cada instancia/base donde deban usarse.

## Uso

Si ya está aplicado 27 y al elegir una instancia aparece REFERENCES / CREDENTIAL, ejecutar solo 28 y después 99, y usar el ejecutable actualizado. CREDENTIAL es un ámbito de instancia distinto de DATABASE SCOPED CREDENTIAL. La carga fallida ya no conserva filas de otro destino ni impide cambiar de pestaña o desplazarse; la edición y el guardado permanecen deshabilitados hasta cargar un catálogo completo. Véase [permisos de SQL Server](https://learn.microsoft.com/en-us/sql/relational-databases/security/permissions-database-engine).

Un solo apartado: **Política de acceso**. Elegir Plantilla general, o una instancia y opcionalmente una base. Las pestañas Roles y Permisos comparten guardado, búsqueda, disponibilidad, origen, restauración y confirmación especial.

- General define las reglas heredables de roles integrados y permisos.
- Cambiar General afecta también a destinos existentes que aún heredan esa regla; no es una copia fija de valores iniciales.
- Instancia sustituye las reglas generales para ese servidor. Sus reglas de base se heredan a las bases; sus roles/permisos de servidor no se heredan como reglas de base.
- Base de datos sustituye únicamente la configuración de esa base.
- Restaurar heredado elimina la regla del nivel seleccionado; no modifica la del padre, los accesos existentes ni el rol SQL.
- Cambiar un destino con un borrador requiere confirmar su descarte. Durante una carga o confirmación especial, los selectores quedan deshabilitados.

Ejemplo: permitir escritura en General; bloquear db_datawriter o INSERT/UPDATE/DELETE en Instancia X; permitirlos solo en X/Ventas. X/Reportes continúa bloqueada e Instancia Y conserva la plantilla.

Bloquear db_datawriter no bloquea por sí solo los permisos directos de escritura ni los permisos heredados de otros roles. Revisar ambos catálogos según la política deseada.

### Descripciones de accesos

Los permisos estándar muestran una explicación breve en **Para qué sirve**, junto al nombre SQL y el ámbito. Los roles integrados muestran su explicación en **Qué permite**. Estos textos son fijos en el ejecutable y están separados de los motivos de protección, las aprobaciones y las reglas heredadas. El buscador también consulta estas explicaciones. Se basan en la documentación de Microsoft sobre [permisos](https://learn.microsoft.com/en-us/sql/relational-databases/security/permissions-database-engine), [roles de base](https://learn.microsoft.com/en-us/sql/relational-databases/security/authentication-access/database-level-roles) y [roles de servidor](https://learn.microsoft.com/en-us/sql/relational-databases/security/authentication-access/server-level-roles). Un permiso desconocido de una versión futura muestra un aviso para revisar su significado; no se inventa una descripción ni cambia su disponibilidad.

Los roles personalizados conservan su descripción administrativa; si está vacía muestran «Sin descripción». Puede editarse en **Detalles avanzados** y persistirse con **Guardar cambios** en el destino seleccionado, sin cambiar la definición del rol SQL. Las descripciones integradas no son editables. Esta mejora solo requiere actualizar el ejecutable; no necesita otra migración SQL ni altera accesos existentes.

## Descubrimiento y persistencia

Seleccionar una instancia/base o pulsar Actualizar consulta sus roles. Un rol personalizado nuevo aparece como pendiente, deshabilitado. Autorizarlo escribe una regla asociada a instancia + base + nombre + ámbito; el mismo nombre en otro destino no recibe esa autorización. Los roles integrados pueden heredar reglas; los personalizados no se autorizan por una plantilla de nombres. Los roles eliminados del catálogo quedan no disponibles cuando se actualiza. Un rol que cambia sus permisos requiere revisión administrativa: la autorización de su nombre no congela la definición SQL.

La cuenta técnica debe tener visibilidad suficiente de todos los roles. Si falta VIEW DEFINITION/VIEW ANY DEFINITION, su equivalente de seguridad en versiones recientes, o la capacidad administrativa correspondiente, el descubrimiento se detiene y no publica una lista parcial. El DBA debe configurar la cuenta; la aplicación no concede estos permisos automáticamente. Véase [visibilidad de metadatos de Microsoft](https://learn.microsoft.com/en-us/sql/relational-databases/security/metadata-visibility-configuration).

Los permisos se obtienen del catálogo incorporado que expone cada instancia, no de una lista máxima de seis nombres. La base central conserva las combinaciones permiso/ámbito y la disponibilidad por versión de servidor. Las clases SQL conocidas tienen un generador delimitado de destinos; una clase nueva no reconocida provoca un error explícito en lugar de omitirla silenciosamente. Véase [sys.fn_builtin_permissions](https://learn.microsoft.com/en-us/sql/relational-databases/system-functions/sys-fn-builtin-permissions-transact-sql).

## Acciones y protección

Todos los permisos reconocidos en el destino pueden habilitarse desde la aplicación. Los básicos usan el interruptor; los protegidos usan Habilitar… con motivo, reconocimiento de riesgo y nombre exacto. Esto es una doble confirmación, no autenticación multifactor. La autorización queda auditada por destino. Bloquear nuevamente retira la autorización especial local.

En Detalles avanzados, GRANT, DENY y REVOKE se configuran independientemente. DENY no equivale a bloquear una opción del catálogo: es una denegación de acceso en SQL. REVOKE retira una concesión o denegación explícita; no elimina los accesos heredados.

Los bloqueos obligatorios antiguos siguen siendo generales y visibles en opciones avanzadas. Una autorización especial permite una excepción de rol o permiso en el destino elegido; los bloqueos de operaciones continúan siendo obligatorios. Volver a establecer un bloqueo invalida las excepciones correspondientes.

La instancia muestra roles como sysadmin; una base muestra roles como db_owner, db_datareader y db_datawriter. Todos los roles de servidor requieren confirmación especial. public no es asignable por esta herramienta, porque SQL lo aplica implícitamente.

Los nombres que contienen ## se excluyen del descubrimiento, la política, los inventarios y las opciones de gestión. No admiten activación especial, asignación, retiro ni copia desde la aplicación, incluso si una regla antigua los había autorizado. No se eliminan los roles, cuentas ni accesos de SQL Server; las reglas históricas se conservan como referencia. Esta exclusión se aplica al actualizar el ejecutable y no requiere repetir migraciones de una instalación existente.

Para solicitar accesos de servidor: seleccionar un login en Modificar accesos y abrir **Acceso de instancia**. Elegir permisos de instancia, asignar o retirar un rol. Se conserva el flujo de ticket, confirmación y ejecución. En permisos de base, la sección avanzada permite solicitar los permisos y ámbitos habilitados fuera de la matriz básica.

El catálogo controla lo que la herramienta puede solicitar; no revoca los accesos ya existentes. Cada solicitud y sus pasos se validan con la política de todos sus destinos al crearla, confirmarla y ejecutarla. La ejecución vuelve a comprobar el permiso en el catálogo de la instancia real. La copia conserva sus límites: solo accesos directos soportados de base y membresías de roles de base; nunca omite DENY/REVOKE del origen ni copia roles de servidor.

## Prueba antes de producción

Validar con dos instancias y dos bases por instancia: herencia, excepciones y restauración; SELECT permitido y escritura bloqueada; nuevos roles personalizados y un mismo nombre en destinos distintos; activación/bloqueo de CONTROL y sysadmin; GRANT/DENY/REVOKE; políticas cambiadas entre creación, confirmación y ejecución; solicitudes con varias bases; rol eliminado o modificado; falta de visibilidad de metadatos; conexión fallida; versiones diferentes de SQL Server; y auditoría. Los permisos de la cuenta técnica deben revisarse con mínimo privilegio.
