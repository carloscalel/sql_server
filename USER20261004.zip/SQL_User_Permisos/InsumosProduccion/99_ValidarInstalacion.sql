USE [adminDB];
GO
SET NOCOUNT ON;
GO

DECLARE @Expected table(ObjectType varchar(10),ObjectName sysname);
INSERT @Expected VALUES
 ('TABLE','AppRole'),('TABLE','AuthorizedPrincipal'),('TABLE','ManagedServer'),('TABLE','AuditEvent'),('TABLE','CryptoConfiguration'),
 ('TABLE','SecurityPolicyOperation'),('TABLE','SecurityPolicyPermission'),('TABLE','SecurityPolicyRole'),('TABLE','SecurityDenyList'),('TABLE','AccessRequest'),('TABLE','AccessRequestTarget'),
 ('TABLE','AccessRequestStep'),('TABLE','SecurityPolicyOverride'),
 ('TABLE','PolicyPermissionRule'),('TABLE','PolicyRoleRule'),('TABLE','PolicyRoleDiscovery'),('TABLE','PolicyPermissionCatalog'),('TABLE','PolicyScopeCatalog'),('TABLE','PolicyPermissionAvailability'),
 ('FUNCTION','ufn_PolicyPermissionEffective'),('FUNCTION','ufn_PolicyRoleEffective'),
 ('PROC','usp_Policy_ContextValidate'),('PROC','usp_Policy_DiscoverRoles'),('PROC','usp_Policy_RestoreInheritance'),('PROC','usp_AccessRequest_TargetPolicyValidate'),
 ('TYPE','AccessRequestTargetType'),('TYPE','AccessRequestStepType'),('TYPE','AccessRequestStepPolicyType'),
 ('FUNCTION','ufn_PolicyPermissionSupported'),('FUNCTION','ufn_PolicyPermissionRequiresActivation'),
 ('PROC','usp_App_LoginContext'),('PROC','usp_Server_List'),
 ('PROC','usp_AuthorizedUser_List'),('PROC','usp_Audit_List'),('PROC','usp_Server_GetConnection'),
 ('PROC','usp_Audit_Write'),('PROC','usp_AuthorizedUser_Upsert'),('PROC','usp_Server_Upsert'),
 ('PROC','usp_Server_SetActive'),('PROC','usp_Crypto_GetKey'),('PROC','usp_AccessRequest_Preview'),('PROC','usp_AccessRequest_Create'),
 ('PROC','usp_AccessRequest_List'),('PROC','usp_AccessRequest_TargetList'),('PROC','usp_AccessRequest_Approve'),
 ('PROC','usp_AccessRequest_MarkExecuted'),('PROC','usp_AccessRequest_StepList'),('PROC','usp_AccessRequest_SecretGet'),
 ('PROC','usp_AccessRequest_SecretDiscard'),('PROC','usp_Audit_ValidateIntegrity'),
 ('PROC','usp_Policy_OperationList'),('PROC','usp_Policy_PermissionList'),('PROC','usp_Policy_RoleList'),
 ('PROC','usp_Policy_DenyList'),('PROC','usp_Policy_PermissionUpsert'),('PROC','usp_Policy_RoleUpsert'),
 ('PROC','usp_Policy_DenyUpsert'),('PROC','usp_Policy_SpecialActivate'),('TRIGGER','tr_AuditEvent_AppendOnly');

SELECT e.ObjectType,e.ObjectName,
 CASE e.ObjectType WHEN 'TYPE' THEN IIF(TYPE_ID(N'[access].'+e.ObjectName) IS NULL,'FALTA','OK')
                   ELSE IIF(OBJECT_ID(N'[access].'+e.ObjectName) IS NULL,'FALTA','OK') END AS [Status]
FROM @Expected e ORDER BY e.ObjectType,e.ObjectName;

SELECT RoleName,Description FROM [access].AppRole ORDER BY RoleName;
SELECT name AS DatabaseRole,
       IIF(name IN (N'SqlAccessAdmin_Administrator',N'SqlAccessAdmin_Operator',N'SqlAccessAdmin_Auditor',N'SqlAccessAdmin_Users'),N'OK',N'REVISAR') AS [Status]
FROM sys.database_principals
WHERE type='R' AND name LIKE N'SqlAccessAdmin[_]%'
ORDER BY name;
SELECT UserId,Principal,RoleName,Active FROM [access].AuthorizedPrincipal ORDER BY Principal;
SELECT ServerId,Name,Host,Instance,Active,Encrypt,TrustServerCertificate,TimeoutSeconds FROM [access].ManagedServer ORDER BY Name;
SELECT RoleName,RoleKind,Enabled,Notes FROM [access].SecurityPolicyRole ORDER BY RoleKind,RoleName;

IF OBJECT_ID(N'[access].usp_Policy_RoleUpsert',N'P') IS NULL
    THROW 51111, 'Falta la administración controlada de roles. Ejecute 17_AdministrarPoliticaPermisosRoles.sql.', 1;

IF NOT EXISTS(SELECT 1 FROM [access].SecurityPolicyOperation WHERE OperationCode='CREATE_WINDOWS_LOGIN' AND Enabled=1)
   OR NOT EXISTS(SELECT 1 FROM [access].SecurityPolicyOperation WHERE OperationCode='MODIFY_LOGIN' AND Enabled=1)
    THROW 51112, 'Falta la política simplificada. Ejecute 12_SimplificarGestionAccesos.sql.', 1;


IF NOT EXISTS
(
    SELECT 1 FROM sys.parameters
    WHERE object_id=OBJECT_ID(N'[access].usp_AccessRequest_List',N'P')
      AND name=N'@ServerId'
)
    THROW 51114, 'Falta el control de servidor único. Ejecute 13_RestringirServidorUnico.sql.', 1;

IF NOT EXISTS
(
    SELECT 1
    FROM [access].SecurityPolicyOperation
    WHERE OperationCode='MODIFY_LOGIN'
      AND Enabled=1
      AND DisplayName=N'Modificar acceso del login'
)
    THROW 51115, 'Falta el rediseño de mapeo de login. Ejecute 14_RedisenarMapeoLogin.sql.', 1;

IF OBJECT_DEFINITION(OBJECT_ID(N'[access].usp_AccessRequest_Create',N'P')) NOT LIKE N'%SqlAccessAdmin.AccessRequestCreate%'
   OR OBJECT_DEFINITION(OBJECT_ID(N'[access].usp_AccessRequest_Approve',N'P')) NOT LIKE N'%SqlAccessAdmin.AccessRequestApprove%'
    THROW 51116, 'Falta el control de solicitudes duplicadas. Ejecute 15_PrevenirSolicitudesDuplicadas.sql.', 1;

IF OBJECT_DEFINITION(OBJECT_ID(N'[access].usp_AccessRequest_Approve',N'P')) NOT LIKE N'%SqlAccessAdmin.SelfConfirmation%'
   OR OBJECT_DEFINITION(OBJECT_ID(N'[access].usp_AccessRequest_MarkExecuted',N'P')) NOT LIKE N'%SqlAccessAdmin.SelfConfirmationExecution%'
    THROW 51117, 'Falta la autoconfirmación. Ejecute 16_HabilitarAutoconfirmacion.sql.', 1;

IF COL_LENGTH(N'[access].AccessRequest',N'ExternalTicketNumber') IS NULL
   OR NOT EXISTS
   (
       SELECT 1 FROM sys.parameters
       WHERE object_id=OBJECT_ID(N'[access].usp_AccessRequest_Create',N'P')
         AND name=N'@ExternalTicketNumber'
   )
    THROW 51118, 'Falta el ticket externo obligatorio. Ejecute 18_TicketExternoSolicitudes.sql.', 1;

IF OBJECT_ID(N'[access].AccessRequestStep',N'U') IS NULL
   OR TYPE_ID(N'[access].AccessRequestStepType') IS NULL
   OR COL_LENGTH(N'[access].AccessRequest',N'SecretCiphertext') IS NULL
   OR OBJECT_ID(N'[access].usp_AccessRequest_SecretGet',N'P') IS NULL
    THROW 51119, 'Falta la solicitud compuesta y contraseña temporal. Ejecute 19_SolicitudCompuestaYContrasenaTemporal.sql.', 1;

IF EXISTS
(
 SELECT 1 FROM @Expected e WHERE
   (e.ObjectType='TYPE' AND TYPE_ID(N'[access].'+e.ObjectName) IS NULL)
   OR (e.ObjectType<>'TYPE' AND OBJECT_ID(N'[access].'+e.ObjectName) IS NULL)
)
    THROW 51110, 'La instalación está incompleta. Revise los objetos marcados como FALTA.', 1;

IF EXISTS
(
    SELECT 1
    FROM @Expected e
    WHERE e.ObjectType<>'TYPE'
      AND OBJECT_ID(N'[dbo].'+QUOTENAME(e.ObjectName)) IS NOT NULL
)
    THROW 51120, 'Aún existen objetos propios de la aplicación en dbo. Ejecute 20_MigrarObjetosAlEsquemaAccess.sql.', 1;

IF EXISTS
(
    SELECT 1
    FROM @Expected e
    WHERE e.ObjectType='TYPE'
      AND TYPE_ID(N'[dbo].'+QUOTENAME(e.ObjectName)) IS NOT NULL
)
    THROW 51121, 'Aún existen tipos propios de la aplicación en dbo. Ejecute 20_MigrarObjetosAlEsquemaAccess.sql.', 1;

IF EXISTS
(
    SELECT 1
    FROM @Expected e
    WHERE e.ObjectType<>'TYPE'
      AND OBJECT_ID(N'[SqlAccessAdmin].'+QUOTENAME(e.ObjectName)) IS NOT NULL
)
    THROW 51122, 'Aún existen objetos propios de la aplicación en el esquema anterior SqlAccessAdmin. Ejecute 20_MigrarObjetosAlEsquemaAccess.sql.', 1;

IF EXISTS
(
    SELECT 1
    FROM @Expected e
    WHERE e.ObjectType='TYPE'
      AND TYPE_ID(N'[SqlAccessAdmin].'+QUOTENAME(e.ObjectName)) IS NOT NULL
)
    THROW 51123, 'Aún existen tipos propios de la aplicación en el esquema anterior SqlAccessAdmin. Ejecute 20_MigrarObjetosAlEsquemaAccess.sql.', 1;

IF ISNULL(OBJECT_DEFINITION(OBJECT_ID(N'[access].usp_AccessRequest_Create',N'P')),N'') NOT LIKE N'%SqlAccessAdmin.AccessChangesComposite%'
   OR ISNULL(OBJECT_DEFINITION(OBJECT_ID(N'[access].usp_AccessRequest_Approve',N'P')),N'') NOT LIKE N'%SqlAccessAdmin.AccessChangesComposite%'
    THROW 51124, 'Falta la solicitud única de cambios de acceso. Ejecute 21_SolicitudUnicaCambiosAcceso.sql.', 1;

IF NOT EXISTS(SELECT 1 FROM [access].SecurityPolicyOperation WHERE OperationCode='CLONE_PERMISSIONS' AND Enabled=1 AND RequiresApproval=1)
   OR ISNULL(OBJECT_DEFINITION(OBJECT_ID(N'[access].usp_AccessRequest_Create',N'P')),N'') NOT LIKE N'%SqlAccessAdmin.PermissionCopyNewLogin%'
    THROW 51125, 'Falta habilitar la copia a usuario nuevo. Ejecute 22_HabilitarCopiaPermisos.sql.', 1;

IF COL_LENGTH(N'[access].AccessRequest',N'CopyPlanJson') IS NULL
   OR OBJECT_ID(N'[access].usp_AccessRequest_CopyPlanGet',N'P') IS NULL
   OR OBJECT_ID(N'[access].usp_AccessRequest_CopyPlanValidate',N'P') IS NULL
   OR ISNULL(OBJECT_DEFINITION(OBJECT_ID(N'[access].usp_AccessRequest_Create',N'P')),N'') NOT LIKE N'%SqlAccessAdmin.PermissionCopyByDatabase%'
    THROW 51126, 'Falta el detalle de copia por base. Ejecute 23_DetalleCopiaPermisosPorBase.sql.', 1;

IF OBJECT_ID(N'[access].usp_AccessRequest_AuthenticationValidate',N'P') IS NULL
   OR ISNULL(OBJECT_DEFINITION(OBJECT_ID(N'[access].usp_AccessRequest_Create',N'P')),N'') NOT LIKE N'%SqlAccessAdmin.LoginAuthenticationSelection%'
   OR ISNULL(OBJECT_DEFINITION(OBJECT_ID(N'[access].usp_AccessRequest_Approve',N'P')),N'') NOT LIKE N'%SqlAccessAdmin.LoginAuthenticationSelection%'
    THROW 51127, 'Falta la selección exclusiva de autenticación SQL o Windows. Ejecute 24_AutenticacionSqlWindows.sql.', 1;
IF OBJECT_ID(N'[access].SecurityPolicyOverride',N'U') IS NULL
   OR OBJECT_ID(N'[access].usp_Policy_SpecialActivate',N'P') IS NULL
   OR ISNULL(OBJECT_DEFINITION(OBJECT_ID(N'[access].usp_AccessRequest_Preview',N'P')),N'') NOT LIKE N'%SqlAccessAdmin.SpecialPolicyActivation%'
    THROW 51128, 'Falta la activación especial de políticas. Ejecute 25_ActivacionEspecialPoliticas.sql.', 1;
IF ISNULL(OBJECT_DEFINITION(OBJECT_ID(N'[access].usp_AccessRequest_Preview',N'P')),N'') NOT LIKE N'%SqlAccessAdmin.PermissionScopeActivation%'
 OR ISNULL(OBJECT_DEFINITION(OBJECT_ID(N'[access].usp_AccessRequest_Create',N'P')),N'') NOT LIKE N'%SqlAccessAdmin.PermissionScopeTargets%'
 THROW 51129,'Falta la validación compartida de permisos y roles. Ejecute 26_ValidacionCompartidaPermisosRoles.sql.',1;
IF ISNULL(OBJECT_DEFINITION(OBJECT_ID(N'[access].usp_AccessRequest_Preview',N'P')),N'') NOT LIKE N'%SqlAccessAdmin.ScopedPolicy%'
 OR ISNULL(OBJECT_DEFINITION(OBJECT_ID(N'[access].usp_AccessRequest_Create',N'P')),N'') NOT LIKE N'%SqlAccessAdmin.ScopedPolicyTargets%'
 OR ISNULL(OBJECT_DEFINITION(OBJECT_ID(N'[access].usp_AccessRequest_Approve',N'P')),N'') NOT LIKE N'%SqlAccessAdmin.ScopedPolicyTargets%'
 THROW 51131,'Falta la política por instancia y base. Ejecute 27_PoliticaAccesoPorInstanciaYBase.sql.',1;
IF EXISTS(SELECT 1 FROM (VALUES(N'PolicyPermissionCatalog'),(N'PolicyPermissionAvailability'),
 (N'PolicyPermissionRule'),(N'AccessRequest'),(N'AccessRequestStep')) tables(Name)
 WHERE ISNULL(COL_LENGTH(N'[access].'+Name,N'PermissionName'),0)<128)
 OR NOT EXISTS(SELECT 1 FROM sys.table_types t JOIN sys.columns c ON c.object_id=t.type_table_object_id
 WHERE t.schema_id=SCHEMA_ID(N'access') AND t.name=N'AccessRequestStepPolicyType'
 AND c.name=N'PermissionName' AND c.max_length=128)
 THROW 51132,'Falta el contrato ampliado de permisos. Vuelva a ejecutar el script 27 actualizado.',1;
IF NOT EXISTS(SELECT 1 FROM [access].PolicyScopeCatalog WHERE ScopeType='CREDENTIAL' AND SqlClass='CREDENTIAL' AND Parts=1 AND IsServer=1)
 THROW 51133,'Falta el ámbito de credenciales de instancia. Ejecute 28_CatalogoCredencialesInstancia.sql.',1;
IF OBJECT_ID(N'dbo.sp_VerificarTicketExiste',N'P') IS NULL
 OR ISNULL(COL_LENGTH(N'[access].AccessRequest',N'ExternalTicketNumber'),0)<50
 OR ISNULL(OBJECT_DEFINITION(OBJECT_ID(N'[access].usp_AccessRequest_Create',N'P')),N'') NOT LIKE N'%@VerifiedTicket%'
 THROW 51134,'Falta la validación de tickets activos. Ejecute nuevamente el script 27 actualizado.',1;
IF EXISTS(SELECT 1 FROM [access].PolicyPermissionRule p WHERE p.Enabled=1
 AND ([access].ufn_PolicyPermissionSupported(p.PermissionName,p.ScopeType)=0
 OR (p.AllowGrant=0 AND p.AllowDeny=0 AND p.AllowRevoke=0)))
 THROW 51113,'Hay permisos activos no reconocidos por el catálogo o sin acciones autorizadas.',1;
SELECT ServerId,DatabaseName,RoleName,RoleScope,Enabled,SpecialActivationApproved FROM [access].PolicyRoleRule ORDER BY ServerId,DatabaseName,RoleScope,RoleName;
SELECT ServerId,DatabaseName,PermissionName,ScopeType,Enabled,AllowGrant,AllowDeny,AllowRevoke,SpecialActivationApproved FROM [access].PolicyPermissionRule ORDER BY ServerId,DatabaseName,ScopeType,PermissionName;
PRINT N'Validación de objetos completada correctamente.';
GO

