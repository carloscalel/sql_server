USE [adminDB];
GO
SET NOCOUNT ON;
SET XACT_ABORT ON;
GO
/* Aplicar manualmente después de 22. Guarda el plan revisado por base.
   Las solicitudes anteriores no se reconstruyen a partir de permisos actuales. */
IF ISNULL(OBJECT_DEFINITION(OBJECT_ID(N'[access].usp_AccessRequest_Create')),N'') NOT LIKE N'%SqlAccessAdmin.PermissionCopyNewLogin%'
    THROW 51347,'Ejecute primero 22_HabilitarCopiaPermisos.sql.',1;
IF COL_LENGTH(N'[access].AccessRequest',N'CopyPlanJson') IS NULL
    ALTER TABLE [access].AccessRequest ADD CopyPlanJson nvarchar(max) NULL;
GO

CREATE OR ALTER PROCEDURE [access].usp_AccessRequest_CopyPlanValidate
 @CopyPlanJson nvarchar(max),@Fingerprint nvarchar(776),@Targets [access].AccessRequestTargetType READONLY
AS
BEGIN
 SET NOCOUNT ON;
 IF ISNULL(ISJSON(@CopyPlanJson),0)<>1
    THROW 51348,'La copia requiere guardar el desglose de accesos por base. Genere una solicitud nueva.',1;
 IF ISNULL(TRY_CONVERT(int,JSON_VALUE(@CopyPlanJson,'$.Version')),0)<>2
    OR ISNULL(LEFT(LTRIM(JSON_QUERY(@CopyPlanJson,'$.Databases')),1),'')<>'['
    THROW 51349,'Formato de plan de copia no compatible.',1;
 IF ISNULL(@Fingerprint,N'') COLLATE Latin1_General_100_BIN2<>
    CONVERT(varchar(64),HASHBYTES('SHA2_256',@CopyPlanJson),2) COLLATE Latin1_General_100_BIN2
    THROW 51350,'La huella no coincide con el desglose de copia guardado.',1;

 DECLARE @Bases table(DatabaseName nvarchar(max),SourceUser nvarchar(max),Accesses nvarchar(max));
 INSERT @Bases SELECT DatabaseName,SourceUser,Accesses
 FROM OPENJSON(@CopyPlanJson,'$.Databases') WITH
 (DatabaseName nvarchar(max) '$.Database',SourceUser nvarchar(max) '$.SourceUser',Accesses nvarchar(max) '$.Accesses' AS JSON);
 IF NOT EXISTS(SELECT 1 FROM @Bases) OR EXISTS
 (SELECT 1 FROM @Bases WHERE NULLIF(LTRIM(RTRIM(DatabaseName)),N'') IS NULL OR LEN(DatabaseName)>128
  OR NULLIF(LTRIM(RTRIM(SourceUser)),N'') IS NULL OR LEN(SourceUser)>128
  OR ISNULL(LEFT(LTRIM(Accesses),1),'')<>'['
  OR LOWER(SourceUser) IN(N'dbo',N'guest',N'sys',N'information_schema')
  OR SourceUser LIKE N'##MS[_]%' OR SourceUser LIKE N'NT AUTHORITY\%' OR SourceUser LIKE N'NT SERVICE\%' OR SourceUser LIKE N'BUILTIN\%')
    THROW 51351,'Una base o usuario origen del plan no es válido.',1;
 IF EXISTS(SELECT DatabaseName FROM @Bases GROUP BY DatabaseName HAVING COUNT(*)>1)
    OR EXISTS(SELECT DatabaseName FROM @Bases EXCEPT SELECT DatabaseName FROM @Targets)
    OR EXISTS(SELECT DatabaseName FROM @Targets EXCEPT SELECT DatabaseName FROM @Bases)
    THROW 51352,'El detalle de copia debe corresponder exactamente a todas las bases destino.',1;

 DECLARE @Accesos table(DatabaseName nvarchar(max),ItemDatabase nvarchar(max),Kind nvarchar(max),StateName nvarchar(max),
  PermissionName nvarchar(max),ScopeType nvarchar(max),SchemaName nvarchar(max),ObjectName nvarchar(max),ColumnName nvarchar(max),RoleName nvarchar(max),CanCopy bit);
 INSERT @Accesos
 SELECT b.DatabaseName,a.ItemDatabase,a.Kind,a.StateName,a.PermissionName,a.ScopeType,a.SchemaName,a.ObjectName,a.ColumnName,a.RoleName,a.CanCopy
 FROM @Bases b CROSS APPLY OPENJSON(b.Accesses) WITH
 (ItemDatabase nvarchar(max) '$.Database',Kind nvarchar(max) '$.Kind',StateName nvarchar(max) '$.State',
  PermissionName nvarchar(max) '$.Permission',ScopeType nvarchar(max) '$.Scope',SchemaName nvarchar(max) '$.Schema',
  ObjectName nvarchar(max) '$.Object',ColumnName nvarchar(max) '$.Column',RoleName nvarchar(max) '$.Role',CanCopy bit '$.CanCopy') a;
 IF EXISTS(SELECT 1 FROM @Accesos WHERE ItemDatabase IS NULL OR ItemDatabase<>DatabaseName OR ISNULL(Kind,N'') NOT IN(N'Rol',N'Permiso')
  OR CanCopy IS NULL OR StateName IS NULL OR ScopeType IS NULL OR PermissionName IS NULL OR SchemaName IS NULL OR ObjectName IS NULL OR ColumnName IS NULL OR RoleName IS NULL
  OR LEN(SchemaName)>128 OR LEN(ObjectName)>128 OR LEN(ColumnName)>128 OR LEN(RoleName)>128
  OR StateName IN('DENY','REVOKE'))
    THROW 51353,'El plan contiene un acceso incompleto o una restricción que no se puede omitir.',1;
 IF NOT EXISTS(SELECT 1 FROM @Accesos WHERE CanCopy=1)
    THROW 51354,'El plan no contiene accesos autorizados para copiar.',1;
 IF EXISTS(SELECT 1 FROM @Accesos WHERE CanCopy=1 AND
  ((Kind=N'Rol' AND (NULLIF(RoleName,N'') IS NULL OR LOWER(RoleName) IN('public','db_owner','db_securityadmin','db_accessadmin','db_ddladmin','db_backupoperator','sysadmin','securityadmin','serveradmin','setupadmin','processadmin','diskadmin','bulkadmin')))
   OR (Kind=N'Permiso' AND (PermissionName NOT IN('SELECT','INSERT','UPDATE','DELETE','EXECUTE') OR ScopeType NOT IN('DATABASE','OBJECT')
       OR StateName NOT IN('GRANT','GRANT_WITH_GRANT_OPTION') OR NULLIF(ColumnName,N'') IS NOT NULL
       OR (ScopeType='OBJECT' AND (NULLIF(SchemaName,N'') IS NULL OR NULLIF(ObjectName,N'') IS NULL))))))
    THROW 51355,'El plan intenta copiar un acceso fuera de la política máxima.',1;

 DECLARE @Check table(Allowed bit,RequiresApproval bit,RiskLevel varchar(10),Reason nvarchar(2000));
 DECLARE @Kind nvarchar(20),@Permission varchar(40),@Scope varchar(20),@Role sysname,@Operation varchar(40),@Action varchar(10);
 DECLARE CopyPolicy CURSOR LOCAL FAST_FORWARD FOR
 SELECT DISTINCT Kind,PermissionName,ScopeType,RoleName FROM @Accesos WHERE CanCopy=1;
 OPEN CopyPolicy;FETCH NEXT FROM CopyPolicy INTO @Kind,@Permission,@Scope,@Role;
 WHILE @@FETCH_STATUS=0
 BEGIN
  SET @Operation=IIF(@Kind=N'Rol','ADD_ROLE_MEMBER','PERMISSION_CHANGE');
  SET @Action=IIF(@Kind=N'Rol',NULL,'GRANT');
  IF @Kind=N'Rol' SET @Permission=NULL; ELSE SET @Role=NULL;
  DELETE FROM @Check;
  INSERT @Check EXEC [access].usp_AccessRequest_Preview @Operation,@Action,@Permission,@Scope,@Role;
  IF NOT EXISTS(SELECT 1 FROM @Check WHERE Allowed=1)
  BEGIN CLOSE CopyPolicy;DEALLOCATE CopyPolicy;THROW 51356,'La política central bloquea un acceso del plan de copia.',1;END;
  FETCH NEXT FROM CopyPolicy INTO @Kind,@Permission,@Scope,@Role;
 END;
 CLOSE CopyPolicy;DEALLOCATE CopyPolicy;
END;
GO

CREATE OR ALTER PROCEDURE [access].usp_AccessRequest_CopyPlanGet @RequestId bigint
AS
BEGIN
 SET NOCOUNT ON;
 SELECT CopyPlanJson FROM [access].AccessRequest WHERE RequestId=@RequestId AND OperationCode='CLONE_PERMISSIONS';
END;
GO
CREATE OR ALTER PROCEDURE [access].usp_AccessRequest_Create
 @OperationCode varchar(40),@TargetPrincipal nvarchar(256),@SourcePrincipal nvarchar(256)=NULL,
 @AuthenticationType varchar(20)=NULL,@PermissionAction varchar(10)=NULL,@PermissionName varchar(40)=NULL,
 @ScopeType varchar(20)=NULL,@Securable nvarchar(776)=NULL,@RoleName sysname=NULL,
 @ExternalTicketNumber varchar(40),@Justification nvarchar(1000),
 @Targets [access].AccessRequestTargetType READONLY,@Steps [access].AccessRequestStepType READONLY,
 @SecretCiphertext varbinary(max)=NULL,@SecretNonce varbinary(12)=NULL,@SecretTag varbinary(16)=NULL,
 @SecretKeyId uniqueidentifier=NULL,@PasswordPolicy bit=0,@PasswordExpiration bit=0,@MustChangePassword bit=0,@CopyPlanJson nvarchar(max)=NULL
AS
BEGIN
 SET NOCOUNT ON;SET XACT_ABORT ON;
 -- SqlAccessAdmin.AccessRequestCreate · SqlAccessAdmin.CompositeRequestCreate · SqlAccessAdmin.AccessChangesComposite
 -- SqlAccessAdmin.PermissionCopyNewLogin · SqlAccessAdmin.PermissionCopyByDatabase
 IF @OperationCode='CLONE_PERMISSIONS'
 BEGIN
  EXEC [access].usp_AccessRequest_CopyPlanValidate @CopyPlanJson,@Securable,@Targets;
  IF ISNULL(@AuthenticationType,'')<>'SQL' OR NULLIF(LTRIM(RTRIM(@SourcePrincipal)),N'') IS NULL
     OR LEN(LTRIM(RTRIM(@TargetPrincipal)))>128 OR LEN(LTRIM(RTRIM(@SourcePrincipal)))>128
     OR UPPER(LTRIM(RTRIM(@TargetPrincipal)))=UPPER(LTRIM(RTRIM(@SourcePrincipal)))
   THROW 51342,'Copiar permisos requiere un usuario origen y un login SQL nuevo distinto.',1;
  IF @Securable IS NULL OR LEN(@Securable)<>64 OR @Securable COLLATE Latin1_General_100_BIN2 LIKE '%[^0-9A-F]%'
   THROW 51343,'La copia requiere la huella de los accesos revisados.',1;
  IF EXISTS(SELECT 1 FROM @Steps) OR @PermissionName IS NOT NULL OR @PermissionAction IS NOT NULL OR @RoleName IS NOT NULL OR @ScopeType IS NOT NULL
   THROW 51344,'El plan de copia no admite cambios manuales.',1;
  DECLARE @ClonePolicy table(Allowed bit,RequiresApproval bit,RiskLevel varchar(10),Reason nvarchar(2000));
  INSERT @ClonePolicy EXEC [access].usp_AccessRequest_Preview 'CREATE_SQL_LOGIN',NULL,NULL,NULL,NULL;
  IF NOT EXISTS(SELECT 1 FROM @ClonePolicy WHERE Allowed=1) THROW 51345,'La política bloquea crear el login SQL.',1;
  DELETE FROM @ClonePolicy;
  INSERT @ClonePolicy EXEC [access].usp_AccessRequest_Preview 'CREATE_DB_USER',NULL,NULL,NULL,NULL;
  IF NOT EXISTS(SELECT 1 FROM @ClonePolicy WHERE Allowed=1) THROW 51345,'La política bloquea crear usuarios de base.',1;
 END;
 IF @OperationCode<>'CLONE_PERMISSIONS' AND @CopyPlanJson IS NOT NULL THROW 51357,'El detalle por base se reserva a copiar permisos.',1;
 SET @ExternalTicketNumber=UPPER(LTRIM(RTRIM(@ExternalTicketNumber)));
 IF @ExternalTicketNumber IS NULL OR @ExternalTicketNumber NOT LIKE 'TIC-RF-%'
    OR LEN(@ExternalTicketNumber)<=7 OR SUBSTRING(@ExternalTicketNumber,8,40) LIKE '%[^0-9]%'
  THROW 51320,'El ticket externo debe usar TIC-RF- seguido únicamente por dígitos.',1;
 IF NOT EXISTS(SELECT 1 FROM @Targets) THROW 51310,'Debe seleccionar destinos.',1;
 IF (SELECT COUNT(DISTINCT ServerId) FROM @Targets)<>1 THROW 51314,'Cada solicitud debe pertenecer a un único servidor.',1;
 IF @Justification IS NULL OR LEN(LTRIM(RTRIM(@Justification)))<10 THROW 51311,'La justificación debe contener al menos 10 caracteres.',1;
 IF @TargetPrincipal IS NULL OR LEN(LTRIM(RTRIM(@TargetPrincipal)))=0 THROW 51337,'Debe indicar el principal destino.',1;
 IF @OperationCode IN('CREATE_SQL_LOGIN','CLONE_PERMISSIONS') AND (@SecretCiphertext IS NULL OR @SecretNonce IS NULL OR @SecretTag IS NULL OR @SecretKeyId IS NULL)
  THROW 51330,'La creación de un login SQL requiere una contraseña temporal cifrada.',1;
 IF @OperationCode IN('CREATE_SQL_LOGIN','CLONE_PERMISSIONS') AND @PasswordExpiration=1 AND @PasswordPolicy=0
  THROW 51331,'CHECK_EXPIRATION requiere CHECK_POLICY activo.',1;
 IF @OperationCode IN('CREATE_SQL_LOGIN','CLONE_PERMISSIONS') AND @MustChangePassword=1 AND (@PasswordPolicy=0 OR @PasswordExpiration=0)
  THROW 51335,'MUST_CHANGE requiere CHECK_POLICY y CHECK_EXPIRATION activos.',1;

 IF EXISTS(SELECT 1 FROM @Steps)
 BEGIN
  IF @OperationCode NOT IN('CREATE_SQL_LOGIN','CREATE_WINDOWS_LOGIN','MODIFY_LOGIN','ADD_ROLE_MEMBER','REMOVE_ROLE_MEMBER','PERMISSION_CHANGE')
   THROW 51332,'Esta operación no admite un plan interno.',1;
  IF @OperationCode IN('CREATE_SQL_LOGIN','CREATE_WINDOWS_LOGIN')
  BEGIN
   IF (SELECT TOP(1) OperationCode FROM @Steps ORDER BY StepOrder)<>'CREATE_DB_USER'
    THROW 51333,'El primer paso del acceso inicial debe crear el usuario de base.',1;
   IF EXISTS(SELECT 1 FROM @Steps WHERE OperationCode NOT IN('CREATE_DB_USER','ADD_ROLE_MEMBER','REMOVE_ROLE_MEMBER','PERMISSION_CHANGE'))
    THROW 51338,'El acceso inicial contiene una operación interna no permitida.',1;
  END
  ELSE
  BEGIN
   IF (SELECT COUNT(*) FROM @Targets)<>1
    THROW 51339,'Una modificación compuesta debe trabajar sobre una sola base de datos.',1;
   IF EXISTS(SELECT 1 FROM @Steps WHERE OperationCode NOT IN('ADD_ROLE_MEMBER','REMOVE_ROLE_MEMBER','PERMISSION_CHANGE'))
    THROW 51338,'La modificación compuesta solo admite roles y permisos.',1;
  END;
  IF EXISTS(SELECT 1 FROM @Steps WHERE StepOrder<=0)
     OR (SELECT MIN(StepOrder) FROM @Steps)<>1
     OR (SELECT MAX(StepOrder) FROM @Steps)<>(SELECT COUNT(*) FROM @Steps)
   THROW 51340,'Los cambios internos deben tener un orden consecutivo desde 1.',1;
 END;
 IF (@OperationCode='PERMISSION_CHANGE' AND @ScopeType='OBJECT')
    OR EXISTS(SELECT 1 FROM @Steps WHERE OperationCode='PERMISSION_CHANGE' AND ScopeType='OBJECT')
 BEGIN
  IF (SELECT COUNT(*) FROM @Targets)<>1 THROW 51339,'Los permisos por objeto requieren una sola base de datos.',1;
 END;

 DECLARE @Check table(Allowed bit,RequiresApproval bit,RiskLevel varchar(10),Reason nvarchar(2000));
 INSERT @Check EXEC [access].usp_AccessRequest_Preview @OperationCode,@PermissionAction,@PermissionName,@ScopeType,@RoleName;
 IF NOT EXISTS(SELECT 1 FROM @Check WHERE Allowed=1) THROW 51312,'Solicitud rechazada por la política central.',1;
 DECLARE @SO varchar(40),@SA varchar(10),@SP varchar(40),@SS varchar(20),@SR sysname;
 DECLARE StepPolicy CURSOR LOCAL FAST_FORWARD FOR SELECT OperationCode,PermissionAction,PermissionName,ScopeType,RoleName FROM @Steps ORDER BY StepOrder;
 OPEN StepPolicy;FETCH NEXT FROM StepPolicy INTO @SO,@SA,@SP,@SS,@SR;
 WHILE @@FETCH_STATUS=0
 BEGIN
  DELETE FROM @Check;INSERT @Check EXEC [access].usp_AccessRequest_Preview @SO,@SA,@SP,@SS,@SR;
  IF NOT EXISTS(SELECT 1 FROM @Check WHERE Allowed=1)
  BEGIN CLOSE StepPolicy;DEALLOCATE StepPolicy;THROW 51334,'Un cambio interno fue rechazado por la política central.',1;END;
  FETCH NEXT FROM StepPolicy INTO @SO,@SA,@SP,@SS,@SR;
 END;
 CLOSE StepPolicy;DEALLOCATE StepPolicy;

 BEGIN TRAN;
 DECLARE @LockResult int;EXEC @LockResult=sys.sp_getapplock @Resource=N'SqlAccessAdmin.AccessRequestCreate',@LockMode='Exclusive',@LockOwner='Transaction',@LockTimeout=10000;
 IF @LockResult<0 THROW 51317,'No fue posible bloquear el registro de solicitudes.',1;
 IF @OperationCode IN('CREATE_SQL_LOGIN','CREATE_WINDOWS_LOGIN','CLONE_PERMISSIONS') AND EXISTS
 (
  SELECT 1 FROM [access].AccessRequest r
  JOIN [access].AccessRequestTarget t ON t.RequestId=r.RequestId
  JOIN @Targets requested ON requested.ServerId=t.ServerId
  WHERE r.Status IN('PENDING','APPROVED') AND r.OperationCode IN('CREATE_SQL_LOGIN','CREATE_WINDOWS_LOGIN','CLONE_PERMISSIONS')
   AND UPPER(LTRIM(RTRIM(r.TargetPrincipal)))=UPPER(LTRIM(RTRIM(@TargetPrincipal)))
 )
 BEGIN ROLLBACK;THROW 51346,'Ya existe una solicitud activa para crear el mismo login en este servidor.',1;END;
 DECLARE @ExistingRequestId bigint;
 SELECT TOP(1) @ExistingRequestId=r.RequestId FROM [access].AccessRequest r WITH(UPDLOCK,HOLDLOCK)
 WHERE r.Status IN('PENDING','APPROVED') AND r.OperationCode=@OperationCode
  AND UPPER(LTRIM(RTRIM(r.TargetPrincipal)))=UPPER(LTRIM(RTRIM(@TargetPrincipal)))
  AND NOT EXISTS(SELECT ServerId,DatabaseName FROM @Targets EXCEPT SELECT ServerId,DatabaseName FROM [access].AccessRequestTarget WHERE RequestId=r.RequestId)
  AND NOT EXISTS(SELECT ServerId,DatabaseName FROM [access].AccessRequestTarget WHERE RequestId=r.RequestId EXCEPT SELECT ServerId,DatabaseName FROM @Targets)
  AND (@OperationCode IN('CREATE_SQL_LOGIN','CREATE_WINDOWS_LOGIN') OR
  (
   ISNULL(r.SourcePrincipal,N'')=ISNULL(@SourcePrincipal,N'') AND ISNULL(r.AuthenticationType,'')=ISNULL(@AuthenticationType,'')
   AND ISNULL(r.PermissionAction,'')=ISNULL(@PermissionAction,'') AND ISNULL(r.PermissionName,'')=ISNULL(@PermissionName,'')
   AND ISNULL(r.ScopeType,'')=ISNULL(@ScopeType,'') AND ISNULL(r.Securable,N'')=ISNULL(@Securable,N'') AND ISNULL(r.RoleName,N'')=ISNULL(@RoleName,N'')
   AND NOT EXISTS
   (
    SELECT StepOrder,OperationCode,PermissionAction,PermissionName,ScopeType,Securable,RoleName FROM @Steps
    EXCEPT
    SELECT StepOrder,OperationCode,PermissionAction,PermissionName,ScopeType,Securable,RoleName FROM [access].AccessRequestStep WHERE RequestId=r.RequestId
   )
   AND NOT EXISTS
   (
    SELECT StepOrder,OperationCode,PermissionAction,PermissionName,ScopeType,Securable,RoleName FROM [access].AccessRequestStep WHERE RequestId=r.RequestId
    EXCEPT
    SELECT StepOrder,OperationCode,PermissionAction,PermissionName,ScopeType,Securable,RoleName FROM @Steps
   )
  ))
 ORDER BY r.RequestId DESC;
 IF @ExistingRequestId IS NOT NULL
 BEGIN
  ROLLBACK;
  DECLARE @DuplicateMessage nvarchar(2048)=CONCAT(N'Ya existe la solicitud activa #',@ExistingRequestId,N' con el mismo plan de cambios y destinos.');
  THROW 51316,@DuplicateMessage,1;
 END;
 INSERT [access].AccessRequest(OperationCode,TargetPrincipal,SourcePrincipal,AuthenticationType,PermissionAction,PermissionName,ScopeType,Securable,RoleName,ExternalTicketNumber,Justification,
  SecretCiphertext,SecretNonce,SecretTag,SecretKeyId,PasswordPolicy,PasswordExpiration,MustChangePassword,CopyPlanJson)
 VALUES(@OperationCode,@TargetPrincipal,@SourcePrincipal,@AuthenticationType,@PermissionAction,@PermissionName,@ScopeType,@Securable,@RoleName,@ExternalTicketNumber,@Justification,
  @SecretCiphertext,@SecretNonce,@SecretTag,@SecretKeyId,@PasswordPolicy,@PasswordExpiration,@MustChangePassword,@CopyPlanJson);
 DECLARE @Id bigint=SCOPE_IDENTITY();
 INSERT [access].AccessRequestTarget(RequestId,ServerId,DatabaseName) SELECT @Id,ServerId,DatabaseName FROM @Targets;
 INSERT [access].AccessRequestStep(RequestId,StepOrder,OperationCode,PermissionAction,PermissionName,ScopeType,Securable,RoleName)
  SELECT @Id,StepOrder,OperationCode,PermissionAction,PermissionName,ScopeType,Securable,RoleName FROM @Steps;
 COMMIT;
 DECLARE @ChangeCount int=1+(SELECT COUNT(*) FROM @Steps);
 IF @OperationCode='CLONE_PERMISSIONS'
  SELECT @ChangeCount=1+(SELECT COUNT(*) FROM OPENJSON(@CopyPlanJson,'$.Databases'))+COUNT(*)
  FROM OPENJSON(@CopyPlanJson,'$.Databases') WITH(Accesses nvarchar(max) '$.Accesses' AS JSON) d
  CROSS APPLY OPENJSON(d.Accesses) WITH(CanCopy bit '$.CanCopy') a WHERE a.CanCopy=1;
 DECLARE @AuditDetail nvarchar(2000)=CONCAT(N'Solicitud #',@Id,N' · ',@ExternalTicketNumber,N' · ',@ChangeCount,N' cambios · ',
  N'CHECK_POLICY=',IIF(@PasswordPolicy=1,N'ON',N'OFF'),N' · CHECK_EXPIRATION=',IIF(@PasswordExpiration=1,N'ON',N'OFF'),N' · MUST_CHANGE=',IIF(@MustChangePassword=1,N'ON',N'OFF'));
 EXEC [access].usp_Audit_Write N'Solicitudes',N'Crear',NULL,NULL,1,@AuditDetail;
 SELECT @Id RequestId,'PENDING' [Status];
END;
GO



CREATE OR ALTER PROCEDURE [access].usp_AccessRequest_Approve
 @RequestId bigint,@Approve bit,@Comment nvarchar(1000)
AS
BEGIN
 SET NOCOUNT ON;SET XACT_ABORT ON;
 -- SqlAccessAdmin.AccessRequestApprove · SqlAccessAdmin.SelfConfirmation · SqlAccessAdmin.AccessChangesComposite
 IF IS_SRVROLEMEMBER(N'sysadmin')<>1 AND NOT EXISTS
 (SELECT 1 FROM [access].AuthorizedPrincipal WHERE Principal=ORIGINAL_LOGIN() AND Active=1 AND RoleName IN('Administrator','Operator'))
  THROW 51301,'Se requiere un usuario Administrator u Operator activo.',1;
 IF @Approve=1 AND EXISTS(SELECT 1 FROM [access].AccessRequest WHERE RequestId=@RequestId AND OperationCode='CLONE_PERMISSIONS')
 BEGIN
  DECLARE @CopyPlan nvarchar(max),@CopyFingerprint nvarchar(776),@CopyTargets [access].AccessRequestTargetType;
  SELECT @CopyPlan=CopyPlanJson,@CopyFingerprint=Securable FROM [access].AccessRequest WHERE RequestId=@RequestId;
  INSERT @CopyTargets SELECT ServerId,DatabaseName FROM [access].AccessRequestTarget WHERE RequestId=@RequestId;
  EXEC [access].usp_AccessRequest_CopyPlanValidate @CopyPlan,@CopyFingerprint,@CopyTargets;
 END;
 BEGIN TRAN;
 DECLARE @LockResult int;EXEC @LockResult=sys.sp_getapplock @Resource=N'SqlAccessAdmin.AccessRequestApprove',@LockMode='Exclusive',@LockOwner='Transaction',@LockTimeout=10000;
 IF @LockResult<0 THROW 51319,'No fue posible bloquear la confirmación de solicitudes.',1;
 IF @Approve=1 AND EXISTS
 (
  SELECT 1 FROM [access].AccessRequest c JOIN [access].AccessRequest a
   ON a.RequestId<>c.RequestId AND a.Status='APPROVED' AND a.OperationCode=c.OperationCode
   AND UPPER(LTRIM(RTRIM(a.TargetPrincipal)))=UPPER(LTRIM(RTRIM(c.TargetPrincipal)))
  WHERE c.RequestId=@RequestId AND c.Status='PENDING'
   AND NOT EXISTS(SELECT ServerId,DatabaseName FROM [access].AccessRequestTarget WHERE RequestId=c.RequestId EXCEPT SELECT ServerId,DatabaseName FROM [access].AccessRequestTarget WHERE RequestId=a.RequestId)
   AND NOT EXISTS(SELECT ServerId,DatabaseName FROM [access].AccessRequestTarget WHERE RequestId=a.RequestId EXCEPT SELECT ServerId,DatabaseName FROM [access].AccessRequestTarget WHERE RequestId=c.RequestId)
   AND (c.OperationCode IN('CREATE_SQL_LOGIN','CREATE_WINDOWS_LOGIN') OR
   (
    ISNULL(a.SourcePrincipal,N'')=ISNULL(c.SourcePrincipal,N'') AND ISNULL(a.AuthenticationType,'')=ISNULL(c.AuthenticationType,'')
    AND ISNULL(a.PermissionAction,'')=ISNULL(c.PermissionAction,'') AND ISNULL(a.PermissionName,'')=ISNULL(c.PermissionName,'')
    AND ISNULL(a.ScopeType,'')=ISNULL(c.ScopeType,'') AND ISNULL(a.Securable,N'')=ISNULL(c.Securable,N'') AND ISNULL(a.RoleName,N'')=ISNULL(c.RoleName,N'')
    AND NOT EXISTS
    (
     SELECT StepOrder,OperationCode,PermissionAction,PermissionName,ScopeType,Securable,RoleName FROM [access].AccessRequestStep WHERE RequestId=c.RequestId
     EXCEPT
     SELECT StepOrder,OperationCode,PermissionAction,PermissionName,ScopeType,Securable,RoleName FROM [access].AccessRequestStep WHERE RequestId=a.RequestId
    )
    AND NOT EXISTS
    (
     SELECT StepOrder,OperationCode,PermissionAction,PermissionName,ScopeType,Securable,RoleName FROM [access].AccessRequestStep WHERE RequestId=a.RequestId
     EXCEPT
     SELECT StepOrder,OperationCode,PermissionAction,PermissionName,ScopeType,Securable,RoleName FROM [access].AccessRequestStep WHERE RequestId=c.RequestId
    )
   ))
 )
 BEGIN ROLLBACK;THROW 51318,'Ya existe otra solicitud equivalente confirmada. Rechace este duplicado.',1;END;
 UPDATE [access].AccessRequest SET Status=IIF(@Approve=1,'APPROVED','REJECTED'),ApprovedBy=ORIGINAL_LOGIN(),ApprovedAt=SYSUTCDATETIME(),ApprovalComment=@Comment
 WHERE RequestId=@RequestId AND Status='PENDING';
 IF @@ROWCOUNT=0 BEGIN ROLLBACK;THROW 51314,'La solicitud no está pendiente.',1;END;
 COMMIT;
 DECLARE @Action nvarchar(50)=IIF(@Approve=1,N'Confirmar',N'Rechazar');
 DECLARE @AuditDetail nvarchar(max)=CONCAT(N'Solicitud #',@RequestId,N' · doble check del operador · ',@Comment);
 EXEC [access].usp_Audit_Write N'Solicitudes',@Action,NULL,NULL,1,@AuditDetail;
END;
GO

CREATE OR ALTER PROCEDURE [access].usp_AccessRequest_List
 @Status varchar(20)=NULL,@ServerId int=NULL
AS
BEGIN
 SET NOCOUNT ON;
 SELECT r.RequestId,r.OperationCode,r.TargetPrincipal,ISNULL(r.SourcePrincipal,N'') SourcePrincipal,
  ISNULL(r.AuthenticationType,'') AuthenticationType,ISNULL(r.PermissionAction,'') PermissionAction,
  ISNULL(r.PermissionName,'') PermissionName,ISNULL(r.ScopeType,'') ScopeType,ISNULL(r.Securable,N'') Securable,
  ISNULL(r.RoleName,N'') RoleName,ISNULL(r.ExternalTicketNumber,'') ExternalTicketNumber,r.Justification,r.Status,
  r.CopyPlanJson,r.RequestedBy,r.RequestedAt,ISNULL(r.ApprovedBy,N'') ApprovedBy,r.ApprovedAt,
  (SELECT COUNT(*) FROM [access].AccessRequestTarget t WHERE t.RequestId=r.RequestId) TargetCount,
  (SELECT COUNT(*) FROM [access].AccessRequestStep s WHERE s.RequestId=r.RequestId) StepCount
 FROM [access].AccessRequest r
 WHERE (@Status IS NULL OR r.Status=@Status)
   AND (@ServerId IS NULL OR
       (EXISTS(SELECT 1 FROM [access].AccessRequestTarget st WHERE st.RequestId=r.RequestId AND st.ServerId=@ServerId)
        AND NOT EXISTS(SELECT 1 FROM [access].AccessRequestTarget ot WHERE ot.RequestId=r.RequestId AND ot.ServerId<>@ServerId)))
 ORDER BY r.RequestedAt DESC;
END;
GO


GRANT EXECUTE ON [access].usp_AccessRequest_CopyPlanGet TO [SqlAccessAdmin_Users];
GRANT EXECUTE ON [access].usp_AccessRequest_Create TO [SqlAccessAdmin_Users];
GRANT EXECUTE ON [access].usp_AccessRequest_Approve TO [SqlAccessAdmin_Users];
GRANT EXECUTE ON [access].usp_AccessRequest_List TO [SqlAccessAdmin_Users];
GO
PRINT N'Detalle de copia por base instalado. Las solicitudes anteriores sin desglose deben regenerarse.';
GO

