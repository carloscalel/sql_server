USE [adminDB];
GO
SET NOCOUNT ON;
SET XACT_ABORT ON;
GO
/*
 27: aplicar después de 26. La política se resuelve General -> Instancia -> Base.
 Conserva la política anterior como plantilla. Roles nuevos se descubren deshabilitados.
 No concede privilegios en las instancias ni aplica excepciones automáticamente.
*/
IF ISNULL(OBJECT_DEFINITION(OBJECT_ID(N'[access].usp_AccessRequest_Create',N'P')),N'') NOT LIKE N'%SqlAccessAdmin.PermissionScopeTargets%'
 THROW 51400,'Ejecute primero el script 26.',1;
IF OBJECT_ID(N'dbo.sp_VerificarTicketExiste',N'P') IS NULL
 THROW 51401,'Falta dbo.sp_VerificarTicketExiste en adminDB.',1;
GRANT EXECUTE ON dbo.sp_VerificarTicketExiste TO [SqlAccessAdmin_Users];
GO
IF EXISTS(SELECT 1 FROM sys.check_constraints WHERE parent_object_id=OBJECT_ID(N'[access].AccessRequest') AND name=N'CK_AccessRequest_ExternalTicket')
 ALTER TABLE [access].AccessRequest DROP CONSTRAINT CK_AccessRequest_ExternalTicket;
GO
IF ISNULL(COL_LENGTH(N'[access].AccessRequest',N'ExternalTicketNumber'),0)<50
 ALTER TABLE [access].AccessRequest ALTER COLUMN ExternalTicketNumber varchar(50) NULL;
GO
IF OBJECT_ID(N'[access].PolicyScopeCatalog',N'U') IS NULL
CREATE TABLE [access].PolicyScopeCatalog(ScopeType varchar(20) PRIMARY KEY,SqlClass varchar(60) NOT NULL,Parts int NOT NULL,IsServer bit NOT NULL);
GO
MERGE [access].PolicyScopeCatalog t USING(VALUES
 ('DATABASE','DATABASE',0,0),
 ('OBJECT','OBJECT',2,0),
 ('SCHEMA','SCHEMA',1,0),
 ('COLUMN','OBJECT',3,0),
 ('SERVER','SERVER',0,1),
 ('USER','USER',1,0),
 ('ROLE','ROLE',1,0),
 ('APPLICATION_ROLE','APPLICATION ROLE',1,0),
 ('TYPE','TYPE',2,0),
 ('XML_SCHEMA','XML SCHEMA COLLECTION',2,0),
 ('ASSEMBLY','ASSEMBLY',1,0),
 ('CERTIFICATE','CERTIFICATE',1,0),
 ('ASYMMETRIC_KEY','ASYMMETRIC KEY',1,0),
 ('SYMMETRIC_KEY','SYMMETRIC KEY',1,0),
 ('DB_CREDENTIAL','DATABASE SCOPED CREDENTIAL',1,0),
 ('CREDENTIAL','CREDENTIAL',1,1),
 ('FULLTEXT_CATALOG','FULLTEXT CATALOG',1,0),
 ('FULLTEXT_STOPLIST','FULLTEXT STOPLIST',1,0),
 ('SEARCH_PROPERTY_LIST','SEARCH PROPERTY LIST',1,0),
 ('SERVICE','SERVICE',1,0),
 ('CONTRACT','CONTRACT',1,0),
 ('MESSAGE_TYPE','MESSAGE TYPE',1,0),
 ('REMOTE_BINDING','REMOTE SERVICE BINDING',1,0),
 ('ROUTE','ROUTE',1,0),
 ('EXTERNAL_LANGUAGE','EXTERNAL LANGUAGE',1,0),
 ('EXTERNAL_LIBRARY','EXTERNAL LIBRARY',1,0),
 ('LOGIN','LOGIN',1,1),
 ('SERVER_ROLE','SERVER ROLE',1,1),
 ('ENDPOINT','ENDPOINT',1,1),
 ('AVAILABILITY_GROUP','AVAILABILITY GROUP',1,1)
) s(ScopeType,SqlClass,Parts,IsServer) ON t.ScopeType=s.ScopeType
WHEN MATCHED THEN UPDATE SET SqlClass=s.SqlClass,Parts=s.Parts,IsServer=s.IsServer
WHEN NOT MATCHED THEN INSERT VALUES(s.ScopeType,s.SqlClass,s.Parts,s.IsServer);
GO
IF OBJECT_ID(N'[access].PolicyPermissionCatalog',N'U') IS NULL
CREATE TABLE [access].PolicyPermissionCatalog(PermissionName varchar(128) NOT NULL,ScopeType varchar(20) NOT NULL,
 CONSTRAINT PK_PolicyPermissionCatalog PRIMARY KEY(PermissionName,ScopeType),
 CONSTRAINT FK_PolicyPermissionCatalog_Scope FOREIGN KEY(ScopeType) REFERENCES [access].PolicyScopeCatalog(ScopeType));
IF OBJECT_ID(N'[access].PolicyPermissionAvailability',N'U') IS NULL
CREATE TABLE [access].PolicyPermissionAvailability(ServerId int NOT NULL,PermissionName varchar(128) NOT NULL,ScopeType varchar(20) NOT NULL,
 CONSTRAINT PK_PolicyPermissionAvailability PRIMARY KEY(ServerId,PermissionName,ScopeType),
 CONSTRAINT FK_PolicyPermissionAvailability_Server FOREIGN KEY(ServerId) REFERENCES [access].ManagedServer(ServerId));
GO
-- Contrato ampliado, también para instalaciones parciales de una versión de 27.
-- Los tipos de tabla no admiten ALTER: se conserva el anterior y se crea uno nuevo.
IF TYPE_ID(N'[access].AccessRequestStepPolicyType') IS NULL
 EXEC(N'CREATE TYPE [access].AccessRequestStepPolicyType AS TABLE(
 StepOrder int NOT NULL,OperationCode varchar(40) NOT NULL,PermissionAction varchar(10) NULL,
 PermissionName varchar(128) NULL,ScopeType varchar(20) NULL,Securable nvarchar(776) NULL,
 RoleName sysname NULL,PRIMARY KEY(StepOrder));');
GRANT REFERENCES ON TYPE::[access].AccessRequestStepPolicyType TO [SqlAccessAdmin_Users];
GO
BEGIN TRY
 BEGIN TRAN;
 DECLARE @PermissionTable sysname,@PermissionSql nvarchar(max),@PermissionPk sysname,@PermissionKeys nvarchar(300),@PermissionNull nvarchar(10);
 DECLARE PermissionWidths CURSOR LOCAL FAST_FORWARD FOR
 SELECT Name FROM (VALUES(N'PolicyPermissionCatalog'),(N'PolicyPermissionAvailability'),
 (N'PolicyPermissionRule'),(N'AccessRequest'),(N'AccessRequestStep')) tables(Name)
 WHERE COL_LENGTH(N'[access].'+Name,N'PermissionName')<128;
 OPEN PermissionWidths;
 FETCH NEXT FROM PermissionWidths INTO @PermissionTable;
 WHILE @@FETCH_STATUS=0
 BEGIN
  SET @PermissionPk=NULL;
  SET @PermissionKeys=CASE @PermissionTable
   WHEN N'PolicyPermissionCatalog' THEN N'PermissionName,ScopeType'
   WHEN N'PolicyPermissionAvailability' THEN N'ServerId,PermissionName,ScopeType'
   WHEN N'PolicyPermissionRule' THEN N'ServerId,DatabaseName,PermissionName,ScopeType' END;
  IF @PermissionKeys IS NOT NULL
   SELECT @PermissionPk=name FROM sys.key_constraints WHERE parent_object_id=OBJECT_ID(N'[access].'+@PermissionTable) AND type='PK';
  SELECT @PermissionNull=IIF(is_nullable=1,N' NULL',N' NOT NULL') FROM sys.columns
   WHERE object_id=OBJECT_ID(N'[access].'+@PermissionTable) AND name=N'PermissionName';
  SET @PermissionSql=CONCAT(
   IIF(@PermissionPk IS NOT NULL,N'ALTER TABLE [access].'+QUOTENAME(@PermissionTable)+N' DROP CONSTRAINT '+QUOTENAME(@PermissionPk)+N';',N''),
   N'ALTER TABLE [access].',QUOTENAME(@PermissionTable),N' ALTER COLUMN PermissionName varchar(128)',@PermissionNull,N';',
   IIF(@PermissionPk IS NOT NULL,N'ALTER TABLE [access].'+QUOTENAME(@PermissionTable)+N' ADD CONSTRAINT '+QUOTENAME(@PermissionPk)+N' PRIMARY KEY('+@PermissionKeys+N');',N''));
  EXEC sys.sp_executesql @PermissionSql;
  FETCH NEXT FROM PermissionWidths INTO @PermissionTable;
 END;
 CLOSE PermissionWidths; DEALLOCATE PermissionWidths;
 COMMIT;
END TRY
BEGIN CATCH
 IF XACT_STATE()<>0 ROLLBACK;
 THROW;
END CATCH;
GO
-- Separar la creación del catálogo de su carga: un error de compilación en la
-- consulta de metadatos no debe impedir que se creen las tablas anteriores.
IF EXISTS(SELECT 1 FROM sys.fn_builtin_permissions(DEFAULT) WHERE LEN(permission_name)>128)
 THROW 51401,'Esta versión contiene un permiso de más de 128 caracteres. Amplíe el contrato antes de instalar.',1;
INSERT [access].PolicyPermissionCatalog(PermissionName,ScopeType)
 SELECT DISTINCT p.permission_name,s.ScopeType FROM
 (SELECT permission_name COLLATE DATABASE_DEFAULT AS permission_name,
         class_desc COLLATE DATABASE_DEFAULT AS class_desc
  FROM sys.fn_builtin_permissions(DEFAULT)) p JOIN [access].PolicyScopeCatalog s
 ON REPLACE(p.class_desc,'_',' ')=s.SqlClass OR (s.SqlClass='OBJECT' AND REPLACE(p.class_desc,'_',' ')='OBJECT OR COLUMN')
 WHERE (s.ScopeType<>'COLUMN' OR p.permission_name IN('SELECT','UPDATE','REFERENCES','UNMASK'))
 AND NOT EXISTS(SELECT 1 FROM [access].PolicyPermissionCatalog c WHERE c.PermissionName=p.permission_name AND c.ScopeType=s.ScopeType);
GO
IF OBJECT_ID(N'[access].PolicyPermissionRule',N'U') IS NULL
CREATE TABLE [access].PolicyPermissionRule(
 ServerId int NOT NULL,DatabaseName nvarchar(128) COLLATE Latin1_General_100_BIN2 NOT NULL,
 PermissionName varchar(128) NOT NULL,ScopeType varchar(20) NOT NULL,Enabled bit NOT NULL,
 AllowGrant bit NOT NULL,AllowDeny bit NOT NULL,AllowRevoke bit NOT NULL,SpecialActivationApproved bit NOT NULL,
 SpecialActivationReason nvarchar(1000) NOT NULL,ApprovedBy nvarchar(256) NOT NULL,ApprovedAt datetime2(3) NOT NULL,
 CONSTRAINT PK_PolicyPermissionRule PRIMARY KEY(ServerId,DatabaseName,PermissionName,ScopeType),
 CONSTRAINT CK_PolicyPermissionRule_Context CHECK(ServerId>=0 AND (ServerId>0 OR DatabaseName=N'')));
IF OBJECT_ID(N'[access].PolicyRoleRule',N'U') IS NULL
CREATE TABLE [access].PolicyRoleRule(
 ServerId int NOT NULL,DatabaseName nvarchar(128) COLLATE Latin1_General_100_BIN2 NOT NULL,
 RoleName nvarchar(128) COLLATE Latin1_General_100_BIN2 NOT NULL,RoleScope varchar(10) NOT NULL,RoleKind varchar(10) NOT NULL,
 Enabled bit NOT NULL,Notes nvarchar(500) NOT NULL,SpecialActivationApproved bit NOT NULL,SpecialActivationReason nvarchar(1000) NOT NULL,
 ApprovedBy nvarchar(256) NOT NULL,ApprovedAt datetime2(3) NOT NULL,
 CONSTRAINT PK_PolicyRoleRule PRIMARY KEY(ServerId,DatabaseName,RoleName,RoleScope),
 CONSTRAINT CK_PolicyRoleRule_Context CHECK(ServerId>=0 AND (ServerId>0 OR DatabaseName=N'') AND (RoleScope<>'SERVER' OR DatabaseName=N''))
);
IF OBJECT_ID(N'[access].PolicyRoleDiscovery',N'U') IS NULL
CREATE TABLE [access].PolicyRoleDiscovery(
 ServerId int NOT NULL,DatabaseName nvarchar(128) COLLATE Latin1_General_100_BIN2 NOT NULL,
 RoleName nvarchar(128) COLLATE Latin1_General_100_BIN2 NOT NULL,RoleScope varchar(10) NOT NULL,RoleKind varchar(10) NOT NULL,
 Description nvarchar(500) NOT NULL,Present bit NOT NULL,LastSeenAt datetime2(3) NOT NULL,
 CONSTRAINT PK_PolicyRoleDiscovery PRIMARY KEY(ServerId,DatabaseName,RoleName,RoleScope),
 CONSTRAINT FK_PolicyRoleDiscovery_Server FOREIGN KEY(ServerId) REFERENCES [access].ManagedServer(ServerId));
GO
-- Importación repetible de la política global anterior, incluyendo excepciones aprobadas.
INSERT [access].PolicyPermissionRule
 SELECT 0,N'',p.PermissionName,p.ScopeType,p.Enabled,p.AllowGrant,p.AllowDeny,p.AllowRevoke,
 CONVERT(bit,IIF(o.Active=1,1,0)),ISNULL(o.Reason,N''),p.ApprovedBy,p.ApprovedAt
 FROM [access].SecurityPolicyPermission p LEFT JOIN [access].SecurityPolicyOverride o
 ON o.Category='PERMISSION' AND o.DeniedValue=p.PermissionName AND o.ScopeType=p.ScopeType
 WHERE NOT EXISTS(SELECT 1 FROM [access].PolicyPermissionRule r WHERE r.ServerId=0 AND r.DatabaseName=N'' AND r.PermissionName=p.PermissionName AND r.ScopeType=p.ScopeType);
INSERT [access].PolicyRoleRule
 SELECT 0,N'',p.RoleName,'DATABASE',p.RoleKind,p.Enabled,ISNULL(p.Notes,N''),
 CONVERT(bit,IIF(o.Active=1,1,0)),ISNULL(o.Reason,N''),p.ApprovedBy,p.ApprovedAt
 FROM [access].SecurityPolicyRole p LEFT JOIN [access].SecurityPolicyOverride o
 ON o.Category='DATABASE_ROLE' AND o.DeniedValue=p.RoleName AND o.ScopeType=''
 WHERE NOT EXISTS(SELECT 1 FROM [access].PolicyRoleRule r WHERE r.ServerId=0 AND r.DatabaseName=N'' AND r.RoleName=p.RoleName COLLATE Latin1_General_100_BIN2 AND r.RoleScope='DATABASE');
INSERT [access].PolicyRoleRule
 SELECT 0,N'',name,'SERVER','FIXED',0,N'Rol integrado del servidor',0,N'',ORIGINAL_LOGIN(),SYSUTCDATETIME()
 FROM sys.server_principals p WHERE type='R' AND is_fixed_role=1 AND name<>N'public' AND name NOT LIKE N'%##%'
 AND NOT EXISTS(SELECT 1 FROM [access].PolicyRoleRule r WHERE r.ServerId=0 AND r.DatabaseName=N'' AND r.RoleName=p.name COLLATE Latin1_General_100_BIN2 AND r.RoleScope='SERVER');
GO
CREATE OR ALTER FUNCTION [access].ufn_PolicyPermissionSupported(@PermissionName varchar(128),@ScopeType varchar(20))
RETURNS bit AS
BEGIN
 RETURN CASE WHEN EXISTS(SELECT 1 FROM [access].PolicyPermissionCatalog WHERE PermissionName=@PermissionName AND ScopeType=@ScopeType) THEN 1 ELSE 0 END;
END;
GO
CREATE OR ALTER FUNCTION [access].ufn_PolicyPermissionRequiresActivation(@PermissionName varchar(128),@ScopeType varchar(20))
RETURNS bit AS
BEGIN
 RETURN CASE WHEN @PermissionName NOT IN('SELECT','INSERT','UPDATE','DELETE','EXECUTE')
 OR @ScopeType NOT IN('DATABASE','OBJECT')
 OR EXISTS(SELECT 1 FROM [access].SecurityDenyList WHERE Active=1 AND Category='PERMISSION' AND DeniedValue=@PermissionName)
 THEN 1 ELSE 0 END;
END;
GO
CREATE OR ALTER FUNCTION [access].ufn_PolicyPermissionEffective(@ServerId int,@DatabaseName nvarchar(128))
RETURNS TABLE AS RETURN
 WITH Keys AS
 (SELECT PermissionName,ScopeType FROM [access].PolicyPermissionCatalog UNION SELECT PermissionName,ScopeType FROM [access].PolicyPermissionRule)
 SELECT k.PermissionName,k.ScopeType,ISNULL(r.Enabled,CONVERT(bit,0)) Enabled,
 ISNULL(r.AllowGrant,CONVERT(bit,1)) AllowGrant,ISNULL(r.AllowDeny,CONVERT(bit,0)) AllowDeny,ISNULL(r.AllowRevoke,CONVERT(bit,1)) AllowRevoke,
 ISNULL(r.SpecialActivationApproved,CONVERT(bit,0)) SpecialActivationApproved,ISNULL(r.SpecialActivationReason,N'') SpecialActivationReason,
 ISNULL(r.ApprovedBy,N'') ApprovedBy,ISNULL(r.ApprovedAt,CONVERT(datetime2(3),'19000101')) ApprovedAt,
 CASE WHEN r.DatabaseName<>N'' THEN 'DATABASE' WHEN r.ServerId>0 THEN 'INSTANCE' ELSE 'GENERAL' END Origin,
 CONVERT(bit,CASE WHEN [access].ufn_PolicyPermissionSupported(k.PermissionName,k.ScopeType)=1
  AND (@ServerId=0 OR NOT EXISTS(SELECT 1 FROM [access].PolicyPermissionAvailability WHERE ServerId=@ServerId)
   OR EXISTS(SELECT 1 FROM [access].PolicyPermissionAvailability a WHERE a.ServerId=@ServerId AND a.PermissionName=k.PermissionName AND a.ScopeType=k.ScopeType))
  THEN 1 ELSE 0 END) Supported
 FROM Keys k LEFT JOIN [access].PolicyScopeCatalog s ON s.ScopeType=k.ScopeType
 OUTER APPLY(SELECT TOP(1) * FROM [access].PolicyPermissionRule x
 WHERE x.PermissionName=k.PermissionName AND x.ScopeType=k.ScopeType AND x.ServerId IN(0,@ServerId)
 AND (x.DatabaseName=N'' OR (x.ServerId=@ServerId AND x.DatabaseName=@DatabaseName))
 ORDER BY CASE WHEN x.DatabaseName<>N'' THEN 2 WHEN x.ServerId>0 THEN 1 ELSE 0 END DESC) r
 WHERE @DatabaseName=N'' OR ISNULL(s.IsServer,0)=0;
GO
CREATE OR ALTER FUNCTION [access].ufn_PolicyRoleEffective(@ServerId int,@DatabaseName nvarchar(128))
RETURNS TABLE AS RETURN
 WITH Keys AS
 (SELECT RoleName,RoleScope FROM [access].PolicyRoleRule WHERE (ServerId=0 AND RoleKind='FIXED')
  OR (ServerId=@ServerId AND (DatabaseName=N'' OR DatabaseName=@DatabaseName))
  OR (@ServerId=0 AND ServerId=0)
  UNION SELECT RoleName,RoleScope FROM [access].PolicyRoleDiscovery WHERE ServerId=@ServerId AND DatabaseName=@DatabaseName AND Present=1)
 SELECT k.RoleName,k.RoleScope,ISNULL(d.RoleKind,ISNULL(r.RoleKind,'CUSTOM')) RoleKind,
 CONVERT(bit,CASE WHEN r.Enabled=1 AND (ISNULL(r.RoleKind,d.RoleKind)='FIXED' OR d.Present=1 OR @ServerId=0) THEN 1 ELSE 0 END) Enabled,
 ISNULL(r.Notes,ISNULL(d.Description,N'')) Notes,ISNULL(r.SpecialActivationApproved,CONVERT(bit,0)) SpecialActivationApproved,
 ISNULL(r.SpecialActivationReason,N'') SpecialActivationReason,ISNULL(r.ApprovedBy,N'') ApprovedBy,
 ISNULL(r.ApprovedAt,CONVERT(datetime2(3),'19000101')) ApprovedAt,
 CASE WHEN r.DatabaseName<>N'' THEN 'DATABASE' WHEN r.ServerId>0 THEN 'INSTANCE' WHEN r.RoleName IS NOT NULL THEN 'GENERAL' ELSE 'DISCOVERED' END Origin
 FROM Keys k
 LEFT JOIN [access].PolicyRoleDiscovery d ON d.ServerId=@ServerId AND d.DatabaseName=@DatabaseName AND d.RoleName=k.RoleName AND d.RoleScope=k.RoleScope
 OUTER APPLY(SELECT TOP(1) * FROM [access].PolicyRoleRule x WHERE x.RoleName=k.RoleName AND x.RoleScope=k.RoleScope
 AND x.ServerId IN(0,@ServerId) AND (x.DatabaseName=N'' OR (x.ServerId=@ServerId AND x.DatabaseName=@DatabaseName))
 AND ((x.RoleKind='FIXED' AND (d.RoleKind IS NULL OR d.RoleKind='FIXED')) OR (x.ServerId=@ServerId AND x.DatabaseName=@DatabaseName))
 ORDER BY CASE WHEN x.DatabaseName<>N'' THEN 2 WHEN x.ServerId>0 THEN 1 ELSE 0 END DESC) r
 WHERE (@DatabaseName=N'' OR k.RoleScope='DATABASE') AND k.RoleName NOT LIKE N'%##%';
GO
CREATE OR ALTER PROCEDURE [access].usp_Policy_ContextValidate @ServerId int=0,@DatabaseName nvarchar(128)=N'',@Write bit=0
AS
BEGIN
 SET NOCOUNT ON;
 IF @ServerId IS NULL OR @ServerId<0 OR @DatabaseName IS NULL OR (@ServerId=0 AND @DatabaseName<>N'')
 OR (@ServerId>0 AND NOT EXISTS(SELECT 1 FROM [access].ManagedServer WHERE ServerId=@ServerId AND Active=1))
 THROW 51402,'Contexto de política no válido o instancia deshabilitada.',1;
 IF @Write=1 AND ISNULL(IS_SRVROLEMEMBER(N'sysadmin'),0)<>1 AND NOT EXISTS
 (SELECT 1 FROM [access].AuthorizedPrincipal WHERE Principal=ORIGINAL_LOGIN() AND Active=1 AND RoleName='Administrator')
 THROW 51301,'Se requiere Administrator.',1;
END;
GO
CREATE OR ALTER PROCEDURE [access].usp_Policy_PermissionList @ServerId int=0,@DatabaseName nvarchar(128)=N''
AS
BEGIN
 SET NOCOUNT ON; EXEC [access].usp_Policy_ContextValidate @ServerId,@DatabaseName,0;
 SELECT * FROM [access].ufn_PolicyPermissionEffective(@ServerId,@DatabaseName) ORDER BY ScopeType,PermissionName;
END;
GO
CREATE OR ALTER PROCEDURE [access].usp_Policy_RoleList @ServerId int=0,@DatabaseName nvarchar(128)=N''
AS
BEGIN
 SET NOCOUNT ON; EXEC [access].usp_Policy_ContextValidate @ServerId,@DatabaseName,0;
 SELECT * FROM [access].ufn_PolicyRoleEffective(@ServerId,@DatabaseName) ORDER BY RoleScope,RoleKind,RoleName;
END;
GO
CREATE OR ALTER PROCEDURE [access].usp_Policy_DiscoverRoles
 @ServerId int,@DatabaseName nvarchar(128)=N'',@RolesJson nvarchar(max),@PermissionsJson nvarchar(max)=NULL
AS
BEGIN
 SET NOCOUNT ON;SET XACT_ABORT ON;
 EXEC [access].usp_Policy_ContextValidate @ServerId,@DatabaseName,1;
 IF @ServerId=0 OR ISNULL(ISJSON(@RolesJson),0)<>1 OR LEFT(LTRIM(@RolesJson),1)<>'['
 THROW 51403,'El descubrimiento requiere una instancia y un catálogo válido.',1;
 DECLARE @Roles table(RoleName nvarchar(128) COLLATE Latin1_General_100_BIN2,RoleKind varchar(10),RoleScope varchar(10),Description nvarchar(500));
 INSERT @Roles SELECT Name,Kind,RoleScope,Description FROM OPENJSON(@RolesJson)
 WITH(Name nvarchar(128),Kind varchar(10),RoleScope varchar(10),Description nvarchar(500));
 DELETE @Roles WHERE RoleName LIKE N'%##%'; -- Solo la copia en memoria; no elimina roles SQL.
 IF EXISTS(SELECT 1 FROM @Roles WHERE NULLIF(RoleName,N'') IS NULL OR RoleKind NOT IN('FIXED','CUSTOM')
  OR RoleScope<>IIF(@DatabaseName=N'','SERVER','DATABASE') OR RoleScope IS NULL OR RoleKind IS NULL OR LOWER(RoleName)=N'public')
 OR EXISTS(SELECT RoleName FROM @Roles GROUP BY RoleName HAVING COUNT(*)>1)
 THROW 51403,'El catálogo de roles no es válido para este destino.',1;
 DECLARE @Permissions table(PermissionName varchar(128),ScopeType varchar(20));
 IF @PermissionsJson IS NOT NULL
 BEGIN
  IF ISNULL(ISJSON(@PermissionsJson),0)<>1 OR LEFT(LTRIM(@PermissionsJson),1)<>'[' THROW 51403,'Catálogo de permisos inválido.',1;
  INSERT @Permissions SELECT Permission,Scope FROM OPENJSON(@PermissionsJson) WITH(Permission varchar(128),Scope varchar(20));
  IF NOT EXISTS(SELECT 1 FROM @Permissions) THROW 51403,'No se puede publicar un catálogo de permisos vacío.',1;
  IF EXISTS(SELECT 1 FROM @Permissions p WHERE PermissionName IS NULL OR PermissionName COLLATE Latin1_General_100_BIN2 LIKE '%[^A-Z ]%'
    OR NULLIF(LTRIM(RTRIM(PermissionName)),'') IS NULL OR ScopeType IS NULL
    OR NOT EXISTS(SELECT 1 FROM [access].PolicyScopeCatalog s WHERE s.ScopeType=p.ScopeType))
   THROW 51403,'El catálogo de permisos contiene un nombre o ámbito inválido.',1;
 END;
 BEGIN TRY
  BEGIN TRAN;
  DECLARE @LockResult int;EXEC @LockResult=sys.sp_getapplock @Resource=N'SqlAccessAdmin.PolicyChanges',@LockMode='Exclusive',@LockOwner='Transaction',@LockTimeout=10000;
  IF @LockResult<0 THROW 51372,'No fue posible bloquear la política.',1;
  UPDATE [access].PolicyRoleDiscovery SET Present=0 WHERE ServerId=@ServerId AND DatabaseName=@DatabaseName;
  INSERT [access].PolicyRoleRule
   SELECT 0,N'',s.RoleName,s.RoleScope,'FIXED',0,ISNULL(s.Description,N''),0,N'',ORIGINAL_LOGIN(),SYSUTCDATETIME()
   FROM @Roles s WHERE s.RoleKind='FIXED' AND NOT EXISTS
   (SELECT 1 FROM [access].PolicyRoleRule r WHERE r.ServerId=0 AND r.DatabaseName=N'' AND r.RoleName=s.RoleName AND r.RoleScope=s.RoleScope);
  MERGE [access].PolicyRoleDiscovery t USING @Roles s ON t.ServerId=@ServerId AND t.DatabaseName=@DatabaseName AND t.RoleName=s.RoleName AND t.RoleScope=s.RoleScope
  WHEN MATCHED THEN UPDATE SET RoleKind=s.RoleKind,Description=ISNULL(s.Description,N''),Present=1,LastSeenAt=SYSUTCDATETIME()
  WHEN NOT MATCHED THEN INSERT VALUES(@ServerId,@DatabaseName,s.RoleName,s.RoleScope,s.RoleKind,ISNULL(s.Description,N''),1,SYSUTCDATETIME());
  IF @PermissionsJson IS NOT NULL
  BEGIN
   INSERT [access].PolicyPermissionCatalog
    SELECT DISTINCT p.PermissionName,p.ScopeType FROM @Permissions p WHERE NOT EXISTS
    (SELECT 1 FROM [access].PolicyPermissionCatalog c WHERE c.PermissionName=p.PermissionName AND c.ScopeType=p.ScopeType);
   DELETE [access].PolicyPermissionAvailability WHERE ServerId=@ServerId;
   INSERT [access].PolicyPermissionAvailability SELECT DISTINCT @ServerId,PermissionName,ScopeType FROM @Permissions;
  END;
  DECLARE @Detail nvarchar(2000)=CONCAT(N'Instancia=',@ServerId,N'; Base=',@DatabaseName,N'; Roles=',(SELECT COUNT(*) FROM @Roles),N'; Sin autorización automática.');
  EXEC [access].usp_Audit_Write N'Política de acceso',N'Actualizar catálogo descubierto',NULL,@DatabaseName,1,@Detail;
  COMMIT;
 END TRY BEGIN CATCH IF XACT_STATE()<>0 ROLLBACK;THROW;END CATCH;
END;
GO
CREATE OR ALTER PROCEDURE [access].usp_Policy_PermissionUpsert
 @PermissionName varchar(128),@ScopeType varchar(20),@AllowGrant bit,@AllowDeny bit,@AllowRevoke bit,@Enabled bit,
 @ServerId int=0,@DatabaseName nvarchar(128)=N''
AS
BEGIN
 SET NOCOUNT ON;SET XACT_ABORT ON;
 EXEC [access].usp_Policy_ContextValidate @ServerId,@DatabaseName,1;
 SET @PermissionName=UPPER(@PermissionName);SET @ScopeType=UPPER(@ScopeType);
 IF [access].ufn_PolicyPermissionSupported(@PermissionName,@ScopeType)=0
  OR (@DatabaseName<>N'' AND EXISTS(SELECT 1 FROM [access].PolicyScopeCatalog WHERE ScopeType=@ScopeType AND IsServer=1))
 THROW 51404,'Permiso o alcance no válido para este destino.',1;
 IF @Enabled IS NULL OR @AllowGrant IS NULL OR @AllowDeny IS NULL OR @AllowRevoke IS NULL
 OR (@Enabled=1 AND @AllowGrant=0 AND @AllowDeny=0 AND @AllowRevoke=0)
 THROW 51306,'Seleccione al menos una acción para el permiso habilitado.',1;
 BEGIN TRY
  BEGIN TRAN;
  DECLARE @LockResult int;EXEC @LockResult=sys.sp_getapplock @Resource=N'SqlAccessAdmin.PolicyChanges',@LockMode='Exclusive',@LockOwner='Transaction',@LockTimeout=10000;
  IF @LockResult<0 THROW 51372,'No fue posible bloquear la política.',1;
  DECLARE @Special bit=0,@Reason nvarchar(1000)=N'';
  SELECT @Special=SpecialActivationApproved,@Reason=SpecialActivationReason FROM [access].ufn_PolicyPermissionEffective(@ServerId,@DatabaseName)
   WHERE PermissionName=@PermissionName AND ScopeType=@ScopeType AND Supported=1;
  IF @Enabled=1 AND [access].ufn_PolicyPermissionRequiresActivation(@PermissionName,@ScopeType)=1 AND @Special=0
   THROW 51309,'Este permiso requiere una activación especial para el destino seleccionado.',1;
  IF @Enabled=0 SELECT @Special=0,@Reason=N'';
  MERGE [access].PolicyPermissionRule t USING(SELECT @ServerId ServerId,@DatabaseName DatabaseName,@PermissionName PermissionName,@ScopeType ScopeType) s
  ON t.ServerId=s.ServerId AND t.DatabaseName=s.DatabaseName AND t.PermissionName=s.PermissionName AND t.ScopeType=s.ScopeType
  WHEN MATCHED THEN UPDATE SET Enabled=@Enabled,AllowGrant=@AllowGrant,AllowDeny=@AllowDeny,AllowRevoke=@AllowRevoke,
   SpecialActivationApproved=@Special,SpecialActivationReason=@Reason,ApprovedBy=ORIGINAL_LOGIN(),ApprovedAt=SYSUTCDATETIME()
  WHEN NOT MATCHED THEN INSERT VALUES(@ServerId,@DatabaseName,@PermissionName,@ScopeType,@Enabled,@AllowGrant,@AllowDeny,@AllowRevoke,@Special,@Reason,ORIGINAL_LOGIN(),SYSUTCDATETIME());
  DECLARE @Detail nvarchar(2000)=CONCAT(N'Instancia=',@ServerId,N'; Base=',@DatabaseName,N'; Permiso=',@PermissionName,N'/',@ScopeType,
   N'; Habilitado=',@Enabled,N'; GRANT=',@AllowGrant,N'; DENY=',@AllowDeny,N'; REVOKE=',@AllowRevoke);
  EXEC [access].usp_Audit_Write N'Política de acceso',N'Actualizar permiso por destino',NULL,@DatabaseName,1,@Detail;
  COMMIT;
 END TRY BEGIN CATCH IF XACT_STATE()<>0 ROLLBACK;THROW;END CATCH;
END;
GO
CREATE OR ALTER PROCEDURE [access].usp_Policy_RoleUpsert
 @RoleName sysname,@RoleKind varchar(10),@Enabled bit,@Notes nvarchar(500)=NULL,
 @ServerId int=0,@DatabaseName nvarchar(128)=N'',@RoleScope varchar(10)='DATABASE'
AS
BEGIN
 SET NOCOUNT ON;SET XACT_ABORT ON;
 EXEC [access].usp_Policy_ContextValidate @ServerId,@DatabaseName,1;
 IF @RoleName IS NULL OR NULLIF(LTRIM(RTRIM(@RoleName)),N'') IS NULL OR LOWER(@RoleName)=N'public' OR @RoleName LIKE N'%##%'
 OR @RoleKind IS NULL OR @RoleKind NOT IN('FIXED','CUSTOM') OR @Enabled IS NULL
 OR @RoleScope IS NULL OR @RoleScope NOT IN('DATABASE','SERVER') OR (@RoleScope='SERVER' AND @DatabaseName<>N'')
 THROW 51405,'Rol, tipo o destino no válido.',1;
 IF @ServerId>0 AND @RoleKind='CUSTOM' AND NOT EXISTS(SELECT 1 FROM [access].PolicyRoleDiscovery
  WHERE ServerId=@ServerId AND DatabaseName=@DatabaseName AND RoleName=@RoleName AND RoleScope=@RoleScope AND Present=1)
 THROW 51405,'Actualice el catálogo: el rol personalizado debe existir en este destino.',1;
 IF @RoleKind='FIXED' AND NOT EXISTS
 (SELECT 1 FROM [access].PolicyRoleRule WHERE ServerId=0 AND RoleName=@RoleName AND RoleScope=@RoleScope AND RoleKind='FIXED')
 THROW 51405,'El rol no pertenece al catálogo de roles integrados. Actualice el destino.',1;
 IF @ServerId>0 AND EXISTS
 (SELECT 1 FROM [access].PolicyRoleDiscovery WHERE ServerId=@ServerId AND DatabaseName=@DatabaseName AND RoleName=@RoleName AND RoleScope=@RoleScope AND Present=1 AND RoleKind<>@RoleKind)
 THROW 51405,'El tipo del rol no coincide con el catálogo del destino.',1;
 BEGIN TRY
  BEGIN TRAN;
  DECLARE @LockResult int;EXEC @LockResult=sys.sp_getapplock @Resource=N'SqlAccessAdmin.PolicyChanges',@LockMode='Exclusive',@LockOwner='Transaction',@LockTimeout=10000;
  IF @LockResult<0 THROW 51372,'No fue posible bloquear la política.',1;
  DECLARE @Special bit=0,@Reason nvarchar(1000)=N'';
  SELECT @Special=SpecialActivationApproved,@Reason=SpecialActivationReason FROM [access].ufn_PolicyRoleEffective(@ServerId,@DatabaseName)
   WHERE RoleName=@RoleName AND RoleScope=@RoleScope;
  IF @Enabled=1 AND @Special=0 AND (@RoleScope='SERVER'
   OR LOWER(@RoleName) IN('db_owner','db_securityadmin','db_accessadmin','db_ddladmin','db_backupoperator')
   OR EXISTS(SELECT 1 FROM [access].SecurityDenyList WHERE Active=1 AND Category IN('DATABASE_ROLE','SERVER_ROLE') AND DeniedValue=@RoleName))
   THROW 51309,'Este rol requiere una activación especial para el destino seleccionado.',1;
  IF @Enabled=0 SELECT @Special=0,@Reason=N'';
  MERGE [access].PolicyRoleRule t USING(SELECT @ServerId ServerId,@DatabaseName DatabaseName,@RoleName RoleName,@RoleScope RoleScope) s
  ON t.ServerId=s.ServerId AND t.DatabaseName=s.DatabaseName AND t.RoleName=s.RoleName AND t.RoleScope=s.RoleScope
  WHEN MATCHED THEN UPDATE SET RoleKind=@RoleKind,Enabled=@Enabled,Notes=ISNULL(@Notes,N''),
   SpecialActivationApproved=@Special,SpecialActivationReason=@Reason,ApprovedBy=ORIGINAL_LOGIN(),ApprovedAt=SYSUTCDATETIME()
  WHEN NOT MATCHED THEN INSERT VALUES(@ServerId,@DatabaseName,@RoleName,@RoleScope,@RoleKind,@Enabled,ISNULL(@Notes,N''),@Special,@Reason,ORIGINAL_LOGIN(),SYSUTCDATETIME());
  DECLARE @Detail nvarchar(2000)=CONCAT(N'Instancia=',@ServerId,N'; Base=',@DatabaseName,N'; Rol=',@RoleName,N'; Clase=',@RoleScope,N'; Habilitado=',@Enabled);
  EXEC [access].usp_Audit_Write N'Política de acceso',N'Actualizar rol por destino',NULL,@DatabaseName,1,@Detail;
  COMMIT;
 END TRY BEGIN CATCH IF XACT_STATE()<>0 ROLLBACK;THROW;END CATCH;
END;
GO
CREATE OR ALTER PROCEDURE [access].usp_Policy_SpecialActivate
 @Category varchar(30),@Value nvarchar(256),@ScopeType varchar(20)=N'',@Reason nvarchar(1000),
 @ConfirmedName nvarchar(256),@RiskAcknowledged bit,@ServerId int=0,@DatabaseName nvarchar(128)=N''
AS
BEGIN
 SET NOCOUNT ON;SET XACT_ABORT ON;
 EXEC [access].usp_Policy_ContextValidate @ServerId,@DatabaseName,1;
 SET @Reason=LTRIM(RTRIM(@Reason));SET @Category=UPPER(@Category);
 IF ISNULL(@RiskAcknowledged,0)<>1 OR @Value IS NULL OR @ConfirmedName IS NULL
 OR @Value COLLATE Latin1_General_100_BIN2<>@ConfirmedName COLLATE Latin1_General_100_BIN2
 OR DATALENGTH(@Value)<>DATALENGTH(@ConfirmedName) OR @Reason IS NULL OR LEN(@Reason) NOT BETWEEN 20 AND 1000
 THROW 51371,'Reconozca el riesgo, escriba el nombre exacto y explique el motivo con 20 a 1000 caracteres.',1;
 IF @Category NOT IN('PERMISSION','DATABASE_ROLE','SERVER_ROLE') OR @Category IS NULL
 THROW 51371,'Categoría no válida.',1;
 DECLARE @RoleScope varchar(10)=IIF(@Category='SERVER_ROLE','SERVER','DATABASE');
 IF @Category<>'PERMISSION' AND (LEN(@Value)>128 OR @ScopeType<>'' OR LOWER(@Value)='public' OR @Value LIKE N'%##%'
  OR (@RoleScope='SERVER' AND @DatabaseName<>N''))
 THROW 51371,'Rol o destino no válido.',1;
 IF @Category='PERMISSION' AND ([access].ufn_PolicyPermissionSupported(CONVERT(varchar(128),@Value),@ScopeType)=0
  OR LEN(@Value)>128 OR (@DatabaseName<>N'' AND EXISTS(SELECT 1 FROM [access].PolicyScopeCatalog WHERE ScopeType=@ScopeType AND IsServer=1)))
 THROW 51371,'Permiso o alcance no válido.',1;
 BEGIN TRY
  BEGIN TRAN;
  DECLARE @LockResult int;EXEC @LockResult=sys.sp_getapplock @Resource=N'SqlAccessAdmin.PolicyChanges',@LockMode='Exclusive',@LockOwner='Transaction',@LockTimeout=10000;
  IF @LockResult<0 THROW 51372,'No fue posible bloquear la política.',1;
  IF @Category='PERMISSION'
  BEGIN
   DECLARE @Grant bit=1,@Deny bit=0,@Revoke bit=1;
   SELECT @Grant=AllowGrant,@Deny=AllowDeny,@Revoke=AllowRevoke FROM [access].ufn_PolicyPermissionEffective(@ServerId,@DatabaseName)
    WHERE PermissionName=@Value AND ScopeType=@ScopeType AND Supported=1;
   IF @Grant=0 AND @Deny=0 AND @Revoke=0 SELECT @Grant=1,@Revoke=1;
   MERGE [access].PolicyPermissionRule t USING(SELECT @ServerId ServerId,@DatabaseName DatabaseName,CONVERT(varchar(128),@Value) PermissionName,@ScopeType ScopeType) s
   ON t.ServerId=s.ServerId AND t.DatabaseName=s.DatabaseName AND t.PermissionName=s.PermissionName AND t.ScopeType=s.ScopeType
   WHEN MATCHED THEN UPDATE SET Enabled=1,AllowGrant=@Grant,AllowDeny=@Deny,AllowRevoke=@Revoke,
    SpecialActivationApproved=1,SpecialActivationReason=@Reason,ApprovedBy=ORIGINAL_LOGIN(),ApprovedAt=SYSUTCDATETIME()
   WHEN NOT MATCHED THEN INSERT VALUES(@ServerId,@DatabaseName,s.PermissionName,@ScopeType,1,@Grant,@Deny,@Revoke,1,@Reason,ORIGINAL_LOGIN(),SYSUTCDATETIME());
  END
  ELSE
  BEGIN
   DECLARE @Kind varchar(10),@Notes nvarchar(500);
   SELECT @Kind=RoleKind,@Notes=Notes FROM [access].ufn_PolicyRoleEffective(@ServerId,@DatabaseName) WHERE RoleName=@Value AND RoleScope=@RoleScope;
   IF @Kind IS NULL THROW 51371,'Actualice el catálogo: el rol debe existir en el destino seleccionado.',1;
   IF @ServerId>0 AND @Kind='CUSTOM' AND NOT EXISTS(SELECT 1 FROM [access].PolicyRoleDiscovery WHERE ServerId=@ServerId AND DatabaseName=@DatabaseName AND RoleName=@Value AND RoleScope=@RoleScope AND Present=1)
    THROW 51371,'El rol personalizado ya no existe en este destino.',1;
   MERGE [access].PolicyRoleRule t USING(SELECT @ServerId ServerId,@DatabaseName DatabaseName,CONVERT(nvarchar(128),@Value) RoleName,@RoleScope RoleScope) s
   ON t.ServerId=s.ServerId AND t.DatabaseName=s.DatabaseName AND t.RoleName=s.RoleName AND t.RoleScope=s.RoleScope
   WHEN MATCHED THEN UPDATE SET Enabled=1,SpecialActivationApproved=1,SpecialActivationReason=@Reason,ApprovedBy=ORIGINAL_LOGIN(),ApprovedAt=SYSUTCDATETIME()
   WHEN NOT MATCHED THEN INSERT VALUES(@ServerId,@DatabaseName,s.RoleName,@RoleScope,@Kind,1,ISNULL(@Notes,N''),1,@Reason,ORIGINAL_LOGIN(),SYSUTCDATETIME());
  END;
  DECLARE @Detail nvarchar(2000)=CONCAT(N'Instancia=',@ServerId,N'; Base=',@DatabaseName,N'; Categoría=',@Category,N'; Valor=',@Value,
   N'; Alcance=',@ScopeType,N'; Nombre confirmado=',@ConfirmedName,N'; Riesgo reconocido; Motivo=',@Reason);
  EXEC [access].usp_Audit_Write N'Política de acceso',N'Autorizar activación especial por destino',NULL,@DatabaseName,1,@Detail;
  COMMIT;
 END TRY BEGIN CATCH IF XACT_STATE()<>0 ROLLBACK;THROW;END CATCH;
END;
GO
CREATE OR ALTER PROCEDURE [access].usp_Policy_RestoreInheritance
 @ServerId int,@DatabaseName nvarchar(128)=N'',@Category varchar(30),@Value nvarchar(256),@ScopeType varchar(20)=N''
AS
BEGIN
 SET NOCOUNT ON;SET XACT_ABORT ON;
 EXEC [access].usp_Policy_ContextValidate @ServerId,@DatabaseName,1;
 IF @ServerId=0 OR @Category IS NULL OR @Category NOT IN('PERMISSION','DATABASE_ROLE','SERVER_ROLE')
  OR @Value IS NULL OR (@Category='SERVER_ROLE' AND @DatabaseName<>N'') THROW 51406,'No se puede restaurar la plantilla general ni un contexto inválido.',1;
 BEGIN TRY
  BEGIN TRAN;
  DECLARE @LockResult int;EXEC @LockResult=sys.sp_getapplock @Resource=N'SqlAccessAdmin.PolicyChanges',@LockMode='Exclusive',@LockOwner='Transaction',@LockTimeout=10000;
  IF @LockResult<0 THROW 51372,'No fue posible bloquear la política.',1;
  IF @Category='PERMISSION' DELETE [access].PolicyPermissionRule WHERE ServerId=@ServerId AND DatabaseName=@DatabaseName AND PermissionName=@Value AND ScopeType=@ScopeType;
  ELSE DELETE [access].PolicyRoleRule WHERE ServerId=@ServerId AND DatabaseName=@DatabaseName AND RoleName=@Value AND RoleScope=IIF(@Category='SERVER_ROLE','SERVER','DATABASE');
  DECLARE @Detail nvarchar(2000)=CONCAT(N'Instancia=',@ServerId,N'; Base=',@DatabaseName,N'; Categoría=',@Category,N'; Valor=',@Value,N'; Alcance=',@ScopeType);
  EXEC [access].usp_Audit_Write N'Política de acceso',N'Restaurar valor heredado',NULL,@DatabaseName,1,@Detail;
  COMMIT;
 END TRY BEGIN CATCH IF XACT_STATE()<>0 ROLLBACK;THROW;END CATCH;
END;
GO
CREATE OR ALTER PROCEDURE [access].usp_AccessRequest_Preview
 @OperationCode varchar(40),@PermissionAction varchar(10)=NULL,@PermissionName varchar(128)=NULL,
 @ScopeType varchar(20)=NULL,@RoleName sysname=NULL,@ServerId int=0,@DatabaseName nvarchar(128)=N''
AS
BEGIN
 SET NOCOUNT ON;
 -- SqlAccessAdmin.SpecialPolicyActivation / SqlAccessAdmin.PermissionScopeActivation / SqlAccessAdmin.ScopedPolicy
 DECLARE @Allowed bit=1,@Reason nvarchar(2000)=N'La solicitud cumple la política de su destino.',@Risk varchar(10),@Approval bit;
 SELECT @Risk=RiskLevel,@Approval=RequiresApproval FROM [access].SecurityPolicyOperation WHERE OperationCode=@OperationCode AND Enabled=1;
 IF @Risk IS NULL SELECT @Allowed=0,@Reason=N'Operación no registrada o deshabilitada.';
 IF @ServerId IS NULL OR @DatabaseName IS NULL OR @ServerId<0 OR (@ServerId=0 AND @DatabaseName<>N'') OR (@ServerId>0 AND NOT EXISTS(SELECT 1 FROM [access].ManagedServer WHERE ServerId=@ServerId AND Active=1))
  SELECT @Allowed=0,@Reason=N'Instancia no registrada o deshabilitada.';
 DECLARE @IsServer bit=IIF(@OperationCode IN('SERVER_PERMISSION_CHANGE','ADD_SERVER_ROLE_MEMBER','REMOVE_SERVER_ROLE_MEMBER'),1,0);
 IF @IsServer=1 SET @DatabaseName=N'';
 IF (@OperationCode IN('PERMISSION_CHANGE','SERVER_PERMISSION_CHANGE') AND (@PermissionName IS NULL OR @ScopeType IS NULL OR @PermissionAction IS NULL))
 OR (@OperationCode IN('ADD_ROLE_MEMBER','REMOVE_ROLE_MEMBER','MODIFY_LOGIN','ADD_SERVER_ROLE_MEMBER','REMOVE_SERVER_ROLE_MEMBER') AND @RoleName IS NULL)
 SELECT @Allowed=0,@Reason=N'Falta el permiso, la acción o el rol de la solicitud.';
 IF @RoleName IS NOT NULL
 BEGIN
  DECLARE @RoleSpecial bit=0,@RoleEnabled bit=0,@RoleScope varchar(10)=IIF(@IsServer=1,'SERVER','DATABASE');
  SELECT @RoleSpecial=SpecialActivationApproved,@RoleEnabled=Enabled FROM [access].ufn_PolicyRoleEffective(@ServerId,@DatabaseName)
   WHERE RoleName=@RoleName AND RoleScope=@RoleScope;
  IF LOWER(@RoleName)='public' OR @RoleEnabled=0 OR (@RoleSpecial=0 AND
   (@RoleScope='SERVER' OR LOWER(@RoleName) IN('db_owner','db_securityadmin','db_accessadmin','db_ddladmin','db_backupoperator')
    OR EXISTS(SELECT 1 FROM [access].SecurityDenyList WHERE Active=1 AND Category IN('DATABASE_ROLE','SERVER_ROLE') AND DeniedValue=@RoleName)))
   SELECT @Allowed=0,@Reason=N'Rol bloqueado o pendiente de autorización en este destino.';
  IF @RoleSpecial=1 SELECT @Risk='HIGH',@Approval=1;
 END;
 IF @PermissionName IS NOT NULL
 BEGIN
  DECLARE @PermissionSpecial bit=0,@PermissionEnabled bit=0,@Grant bit=0,@Deny bit=0,@Revoke bit=0,@Supported bit=0;
  SELECT @PermissionSpecial=SpecialActivationApproved,@PermissionEnabled=Enabled,@Grant=AllowGrant,@Deny=AllowDeny,@Revoke=AllowRevoke,@Supported=Supported
   FROM [access].ufn_PolicyPermissionEffective(@ServerId,@DatabaseName) WHERE PermissionName=@PermissionName AND ScopeType=@ScopeType;
  IF @Supported=0 OR @PermissionEnabled=0 OR @PermissionAction IS NULL OR @PermissionAction NOT IN('GRANT','DENY','REVOKE')
   OR (@PermissionAction='GRANT' AND @Grant=0) OR (@PermissionAction='DENY' AND @Deny=0) OR (@PermissionAction='REVOKE' AND @Revoke=0)
   OR (@PermissionSpecial=0 AND [access].ufn_PolicyPermissionRequiresActivation(@PermissionName,@ScopeType)=1)
   OR NOT EXISTS(SELECT 1 FROM [access].PolicyScopeCatalog WHERE ScopeType=@ScopeType AND IsServer=@IsServer)
   SELECT @Allowed=0,@Reason=N'Permiso, acción o alcance no autorizado en este destino.';
  IF @PermissionSpecial=1 OR @PermissionAction='DENY' SELECT @Risk='HIGH',@Approval=1;
 END;
 IF EXISTS(SELECT 1 FROM [access].SecurityDenyList WHERE Active=1 AND Category='OPERATION' AND DeniedValue=@OperationCode)
  SELECT @Allowed=0,@Reason=N'Operación bloqueada por la política central.';
 SELECT @Allowed Allowed,ISNULL(@Approval,1) RequiresApproval,ISNULL(@Risk,'HIGH') RiskLevel,@Reason Reason;
END;
GO
MERGE [access].SecurityPolicyOperation t USING(VALUES
 ('SERVER_PERMISSION_CHANGE',N'Administrar permisos de instancia'),
 ('ADD_SERVER_ROLE_MEMBER',N'Asignar rol de servidor'),
 ('REMOVE_SERVER_ROLE_MEMBER',N'Retirar rol de servidor')
) s(OperationCode,DisplayName) ON t.OperationCode=s.OperationCode
WHEN NOT MATCHED THEN INSERT(OperationCode,DisplayName,Enabled,RequiresApproval,RiskLevel,Description)
 VALUES(s.OperationCode,s.DisplayName,1,1,'HIGH',N'Sujeto a la política específica de la instancia y a confirmación.');
GO
GRANT EXECUTE ON [access].usp_Policy_DiscoverRoles TO [SqlAccessAdmin_Administrator];
GRANT EXECUTE ON [access].usp_Policy_RestoreInheritance TO [SqlAccessAdmin_Administrator];
GO
CREATE OR ALTER PROCEDURE [access].usp_AccessRequest_TargetPolicyValidate
 @OperationCode varchar(40),@PermissionAction varchar(10),@PermissionName varchar(128),
 @ScopeType varchar(20),@RoleName sysname,@Targets [access].AccessRequestTargetType READONLY,
 @Steps [access].AccessRequestStepPolicyType READONLY
AS
BEGIN
 SET NOCOUNT ON;
 -- SqlAccessAdmin.ScopedPolicyTargets: resolver cada destino; nunca sustituirlo por la plantilla.
 IF NOT EXISTS(SELECT 1 FROM @Targets) OR (SELECT COUNT(DISTINCT ServerId) FROM @Targets)<>1
 THROW 51410,'La política requiere destinos de una sola instancia.',1;
 IF @OperationCode IN('SERVER_PERMISSION_CHANGE','ADD_SERVER_ROLE_MEMBER','REMOVE_SERVER_ROLE_MEMBER')
 AND ((SELECT COUNT(*) FROM @Targets)<>1 OR EXISTS(SELECT 1 FROM @Targets WHERE DatabaseName<>N'master') OR EXISTS(SELECT 1 FROM @Steps))
 THROW 51410,'Una operación de instancia requiere un único destino master y no admite pasos de base.',1;
 DECLARE @Checks table(Allowed bit,RequiresApproval bit,RiskLevel varchar(10),Reason nvarchar(2000));
 DECLARE @Server int,@Database nvarchar(128),@Op varchar(40),@Action varchar(10),@Permission varchar(128),@Scope varchar(20),@Role sysname;
 DECLARE Policies CURSOR LOCAL FAST_FORWARD FOR
 SELECT t.ServerId,t.DatabaseName,p.OperationCode,p.PermissionAction,p.PermissionName,p.ScopeType,p.RoleName
 FROM @Targets t CROSS JOIN
 (SELECT 0 StepOrder,@OperationCode OperationCode,@PermissionAction PermissionAction,@PermissionName PermissionName,@ScopeType ScopeType,@RoleName RoleName
 UNION ALL SELECT StepOrder,OperationCode,PermissionAction,PermissionName,ScopeType,RoleName FROM @Steps) p
 ORDER BY t.ServerId,t.DatabaseName,p.StepOrder;
 OPEN Policies;FETCH NEXT FROM Policies INTO @Server,@Database,@Op,@Action,@Permission,@Scope,@Role;
 WHILE @@FETCH_STATUS=0
 BEGIN
  DELETE FROM @Checks;
  INSERT @Checks EXEC [access].usp_AccessRequest_Preview @Op,@Action,@Permission,@Scope,@Role,@Server,@Database;
  IF NOT EXISTS(SELECT 1 FROM @Checks WHERE Allowed=1)
  BEGIN
   DECLARE @Reason nvarchar(2048);
   SELECT @Reason=CONCAT(N'Instancia ',@Server,N' / ',@Database,N': ',Reason) FROM @Checks;
   CLOSE Policies;DEALLOCATE Policies;THROW 51411,@Reason,1;
  END;
  FETCH NEXT FROM Policies INTO @Server,@Database,@Op,@Action,@Permission,@Scope,@Role;
 END;
 CLOSE Policies;DEALLOCATE Policies;
END;
GO
CREATE OR ALTER PROCEDURE [access].usp_AccessRequest_CopyPlanValidate
 @CopyPlanJson nvarchar(max),@Fingerprint nvarchar(776),@Targets [access].AccessRequestTargetType READONLY
AS
BEGIN
 SET NOCOUNT ON;
 IF ISNULL(ISJSON(@CopyPlanJson),0)<>1
    THROW 51348,'La copia requiere guardar el desglose de accesos por base. Genere una solicitud nueva.',1;
 IF ISNULL(TRY_CONVERT(int,JSON_VALUE(@CopyPlanJson,'$.Version')),0)<>2
    OR ISNULL(LEFT(LTRIM(JSON_QUERY(@CopyPlanJson,'$.Databases')),1),'')<>'['
    THROW 51349,'Formato de plan de copia no compatible.',1;
 IF ISNULL(@Fingerprint,N'') COLLATE Latin1_General_100_BIN2<>
    CONVERT(varchar(64),HASHBYTES('SHA2_256',@CopyPlanJson),2) COLLATE Latin1_General_100_BIN2
    THROW 51350,'La huella no coincide con el desglose de copia guardado.',1;

 DECLARE @Bases table(DatabaseName nvarchar(max),SourceUser nvarchar(max),Accesses nvarchar(max));
 INSERT @Bases SELECT DatabaseName,SourceUser,Accesses
 FROM OPENJSON(@CopyPlanJson,'$.Databases') WITH
 (DatabaseName nvarchar(max) '$.Database',SourceUser nvarchar(max) '$.SourceUser',Accesses nvarchar(max) '$.Accesses' AS JSON);
 IF NOT EXISTS(SELECT 1 FROM @Bases) OR EXISTS
 (SELECT 1 FROM @Bases WHERE NULLIF(LTRIM(RTRIM(DatabaseName)),N'') IS NULL OR LEN(DatabaseName)>128
  OR NULLIF(LTRIM(RTRIM(SourceUser)),N'') IS NULL OR LEN(SourceUser)>128
  OR ISNULL(LEFT(LTRIM(Accesses),1),'')<>'['
  OR LOWER(SourceUser) IN(N'dbo',N'guest',N'sys',N'information_schema')
  OR SourceUser LIKE N'##MS[_]%' OR SourceUser LIKE N'NT AUTHORITY\%' OR SourceUser LIKE N'NT SERVICE\%' OR SourceUser LIKE N'BUILTIN\%')
    THROW 51351,'Una base o usuario origen del plan no es válido.',1;
 IF EXISTS(SELECT DatabaseName FROM @Bases GROUP BY DatabaseName HAVING COUNT(*)>1)
    OR EXISTS(SELECT DatabaseName FROM @Bases EXCEPT SELECT DatabaseName FROM @Targets)
    OR EXISTS(SELECT DatabaseName FROM @Targets EXCEPT SELECT DatabaseName FROM @Bases)
    THROW 51352,'El detalle de copia debe corresponder exactamente a todas las bases destino.',1;

 DECLARE @Accesos table(DatabaseName nvarchar(max),ItemDatabase nvarchar(max),Kind nvarchar(max),StateName nvarchar(max),
  PermissionName nvarchar(max),ScopeType nvarchar(max),SchemaName nvarchar(max),ObjectName nvarchar(max),ColumnName nvarchar(max),RoleName nvarchar(max),CanCopy bit);
 INSERT @Accesos
 SELECT b.DatabaseName,a.ItemDatabase,a.Kind,a.StateName,a.PermissionName,a.ScopeType,a.SchemaName,a.ObjectName,a.ColumnName,a.RoleName,a.CanCopy
 FROM @Bases b CROSS APPLY OPENJSON(b.Accesses) WITH
 (ItemDatabase nvarchar(max) '$.Database',Kind nvarchar(max) '$.Kind',StateName nvarchar(max) '$.State',
  PermissionName nvarchar(max) '$.Permission',ScopeType nvarchar(max) '$.Scope',SchemaName nvarchar(max) '$.Schema',
  ObjectName nvarchar(max) '$.Object',ColumnName nvarchar(max) '$.Column',RoleName nvarchar(max) '$.Role',CanCopy bit '$.CanCopy') a;
 IF EXISTS(SELECT 1 FROM @Accesos WHERE ItemDatabase IS NULL OR ItemDatabase<>DatabaseName OR ISNULL(Kind,N'') NOT IN(N'Rol',N'Permiso')
  OR CanCopy IS NULL OR StateName IS NULL OR ScopeType IS NULL OR PermissionName IS NULL OR SchemaName IS NULL OR ObjectName IS NULL OR ColumnName IS NULL OR RoleName IS NULL
  OR LEN(SchemaName)>128 OR LEN(ObjectName)>128 OR LEN(ColumnName)>128 OR LEN(RoleName)>128
  OR StateName IN('DENY','REVOKE'))
    THROW 51353,'El plan contiene un acceso incompleto o una restricción que no se puede omitir.',1;
 IF NOT EXISTS(SELECT 1 FROM @Accesos WHERE CanCopy=1)
    THROW 51354,'El plan no contiene accesos autorizados para copiar.',1;
 IF EXISTS(SELECT 1 FROM @Accesos WHERE CanCopy=1 AND
  ((Kind=N'Rol' AND (NULLIF(RoleName,N'') IS NULL OR LOWER(RoleName)='public'))
   OR (Kind=N'Permiso' AND ([access].ufn_PolicyPermissionSupported(CONVERT(varchar(128),PermissionName),CONVERT(varchar(20),ScopeType))=0
       OR LEN(PermissionName)>128 OR LEN(ScopeType)>20 OR ScopeType NOT IN('DATABASE','SCHEMA','OBJECT','COLUMN')
       OR StateName NOT IN('GRANT','GRANT_WITH_GRANT_OPTION')
       OR (ScopeType='DATABASE' AND (SchemaName<>N'' OR ObjectName<>N'' OR ColumnName<>N''))
       OR (ScopeType='SCHEMA' AND (NULLIF(LTRIM(RTRIM(SchemaName)),N'') IS NULL OR ObjectName<>N'' OR ColumnName<>N''))
       OR (ScopeType='OBJECT' AND (NULLIF(LTRIM(RTRIM(SchemaName)),N'') IS NULL OR NULLIF(LTRIM(RTRIM(ObjectName)),N'') IS NULL OR ColumnName<>N''))
       OR (ScopeType='COLUMN' AND (NULLIF(LTRIM(RTRIM(SchemaName)),N'') IS NULL OR NULLIF(LTRIM(RTRIM(ObjectName)),N'') IS NULL OR NULLIF(LTRIM(RTRIM(ColumnName)),N'') IS NULL))))))
    THROW 51355,'El plan intenta copiar un acceso fuera de la política máxima.',1;

 DECLARE @Check table(Allowed bit,RequiresApproval bit,RiskLevel varchar(10),Reason nvarchar(2000));
 DECLARE @Database nvarchar(128),@ServerId int=(SELECT TOP(1) ServerId FROM @Targets);
 DECLARE @Kind nvarchar(20),@Permission varchar(128),@Scope varchar(20),@Role sysname,@Operation varchar(40),@Action varchar(10);
 DECLARE CopyPolicy CURSOR LOCAL FAST_FORWARD FOR
 SELECT DISTINCT DatabaseName,Kind,PermissionName,ScopeType,RoleName FROM @Accesos WHERE CanCopy=1;
 OPEN CopyPolicy;FETCH NEXT FROM CopyPolicy INTO @Database,@Kind,@Permission,@Scope,@Role;
 WHILE @@FETCH_STATUS=0
 BEGIN
  SET @Operation=IIF(@Kind=N'Rol','ADD_ROLE_MEMBER','PERMISSION_CHANGE');
  SET @Action=IIF(@Kind=N'Rol',NULL,'GRANT');
  IF @Kind=N'Rol' SET @Permission=NULL; ELSE SET @Role=NULL;
  DELETE FROM @Check;
  INSERT @Check EXEC [access].usp_AccessRequest_Preview @Operation,@Action,@Permission,@Scope,@Role,@ServerId,@Database;
  IF NOT EXISTS(SELECT 1 FROM @Check WHERE Allowed=1)
  BEGIN CLOSE CopyPolicy;DEALLOCATE CopyPolicy;THROW 51356,'La política central bloquea un acceso del plan de copia.',1;END;
  FETCH NEXT FROM CopyPolicy INTO @Database,@Kind,@Permission,@Scope,@Role;
 END;
 CLOSE CopyPolicy;DEALLOCATE CopyPolicy;
END;
GO
CREATE OR ALTER PROCEDURE [access].usp_AccessRequest_Create
 @OperationCode varchar(40),@TargetPrincipal nvarchar(256),@SourcePrincipal nvarchar(256)=NULL,
 @AuthenticationType varchar(20)=NULL,@PermissionAction varchar(10)=NULL,@PermissionName varchar(128)=NULL,
 @ScopeType varchar(20)=NULL,@Securable nvarchar(776)=NULL,@RoleName sysname=NULL,
 @ExternalTicketNumber varchar(50),@Justification nvarchar(1000),
 @Targets [access].AccessRequestTargetType READONLY,@Steps [access].AccessRequestStepPolicyType READONLY,
 @SecretCiphertext varbinary(max)=NULL,@SecretNonce varbinary(12)=NULL,@SecretTag varbinary(16)=NULL,
 @SecretKeyId uniqueidentifier=NULL,@PasswordPolicy bit=0,@PasswordExpiration bit=0,@MustChangePassword bit=0,@CopyPlanJson nvarchar(max)=NULL
AS
BEGIN
 -- SqlAccessAdmin.ScopedPolicyTargets / SqlAccessAdmin.PermissionScopeTargets: un destino para esquema, objeto o columna.
 SET NOCOUNT ON;SET XACT_ABORT ON;
 -- SqlAccessAdmin.AccessRequestCreate · SqlAccessAdmin.CompositeRequestCreate · SqlAccessAdmin.AccessChangesComposite
 -- SqlAccessAdmin.PermissionCopyNewLogin · SqlAccessAdmin.PermissionCopyByDatabase
 -- SqlAccessAdmin.LoginAuthenticationSelection
 EXEC [access].usp_AccessRequest_AuthenticationValidate @OperationCode,@TargetPrincipal,@AuthenticationType,
  @SecretCiphertext,@SecretNonce,@SecretTag,@SecretKeyId,@PasswordPolicy,@PasswordExpiration,@MustChangePassword;
 IF @OperationCode='CLONE_PERMISSIONS'
 BEGIN
  EXEC [access].usp_AccessRequest_CopyPlanValidate @CopyPlanJson,@Securable,@Targets;
  IF ISNULL(@AuthenticationType,'') NOT IN('SQL','WINDOWS') OR NULLIF(LTRIM(RTRIM(@SourcePrincipal)),N'') IS NULL
     OR LEN(LTRIM(RTRIM(@TargetPrincipal)))>128 OR LEN(LTRIM(RTRIM(@SourcePrincipal)))>128
     OR UPPER(LTRIM(RTRIM(@TargetPrincipal)))=UPPER(LTRIM(RTRIM(@SourcePrincipal)))
   THROW 51342,'Copiar permisos requiere un usuario origen y un login nuevo SQL o Windows distinto.',1;
  IF @Securable IS NULL OR LEN(@Securable)<>64 OR @Securable COLLATE Latin1_General_100_BIN2 LIKE '%[^0-9A-F]%'
   THROW 51343,'La copia requiere la huella de los accesos revisados.',1;
  IF EXISTS(SELECT 1 FROM @Steps) OR @PermissionName IS NOT NULL OR @PermissionAction IS NOT NULL OR @RoleName IS NOT NULL OR @ScopeType IS NOT NULL
   THROW 51344,'El plan de copia no admite cambios manuales.',1;
  DECLARE @ClonePolicy table(Allowed bit,RequiresApproval bit,RiskLevel varchar(10),Reason nvarchar(2000));
  DECLARE @CreateLoginOperation varchar(40)=IIF(@AuthenticationType='WINDOWS','CREATE_WINDOWS_LOGIN','CREATE_SQL_LOGIN');
  INSERT @ClonePolicy EXEC [access].usp_AccessRequest_Preview @CreateLoginOperation,NULL,NULL,NULL,NULL;
  IF NOT EXISTS(SELECT 1 FROM @ClonePolicy WHERE Allowed=1) THROW 51345,'La política bloquea crear el tipo de login seleccionado.',1;
  DELETE FROM @ClonePolicy;
  INSERT @ClonePolicy EXEC [access].usp_AccessRequest_Preview 'CREATE_DB_USER',NULL,NULL,NULL,NULL;
  IF NOT EXISTS(SELECT 1 FROM @ClonePolicy WHERE Allowed=1) THROW 51345,'La política bloquea crear usuarios de base.',1;
 END;
 IF @OperationCode<>'CLONE_PERMISSIONS' AND @CopyPlanJson IS NOT NULL THROW 51357,'El detalle por base se reserva a copiar permisos.',1;
 SET @ExternalTicketNumber=UPPER(LTRIM(RTRIM(@ExternalTicketNumber)));
 IF NULLIF(@ExternalTicketNumber,'') IS NULL THROW 51320,'Debe indicar un ticket externo.',1;
 DECLARE @VerifiedTicket table(RESPONSABLE nvarchar(4000),CLIENTE nvarchar(4000),ID_COMPUESTO varchar(50),ASUNTO nvarchar(4000),DESCRIPCION nvarchar(max),ESTADO nvarchar(4000));
 INSERT @VerifiedTicket EXEC dbo.sp_VerificarTicketExiste @Ticket=@ExternalTicketNumber;
 IF NOT EXISTS(SELECT 1 FROM @VerifiedTicket WHERE ID_COMPUESTO=@ExternalTicketNumber)
  THROW 51320,'El ticket no existe, no está activo o no coincide con el identificador consultado.',1;
 SELECT TOP(1) @ExternalTicketNumber=ID_COMPUESTO,
  @Justification=COALESCE(NULLIF(LTRIM(RTRIM(CONVERT(nvarchar(1000),DESCRIPCION))),N''),NULLIF(LTRIM(RTRIM(CONVERT(nvarchar(1000),ASUNTO))),N''))
 FROM @VerifiedTicket WHERE ID_COMPUESTO=@ExternalTicketNumber;
 IF NOT EXISTS(SELECT 1 FROM @Targets) THROW 51310,'Debe seleccionar destinos.',1;
 IF (SELECT COUNT(DISTINCT ServerId) FROM @Targets)<>1 THROW 51314,'Cada solicitud debe pertenecer a un único servidor.',1;
 IF @Justification IS NULL OR LEN(LTRIM(RTRIM(@Justification)))<10 THROW 51311,'La justificación debe contener al menos 10 caracteres.',1;
 IF @TargetPrincipal IS NULL OR LEN(LTRIM(RTRIM(@TargetPrincipal)))=0 THROW 51337,'Debe indicar el principal destino.',1;
 IF (@OperationCode='CREATE_SQL_LOGIN' OR (@OperationCode='CLONE_PERMISSIONS' AND @AuthenticationType='SQL')) AND (@SecretCiphertext IS NULL OR @SecretNonce IS NULL OR @SecretTag IS NULL OR @SecretKeyId IS NULL)
  THROW 51330,'La creación de un login SQL requiere una contraseña temporal cifrada.',1;
 IF (@OperationCode='CREATE_SQL_LOGIN' OR (@OperationCode='CLONE_PERMISSIONS' AND @AuthenticationType='SQL')) AND @PasswordExpiration=1 AND @PasswordPolicy=0
  THROW 51331,'CHECK_EXPIRATION requiere CHECK_POLICY activo.',1;
 IF (@OperationCode='CREATE_SQL_LOGIN' OR (@OperationCode='CLONE_PERMISSIONS' AND @AuthenticationType='SQL')) AND @MustChangePassword=1 AND (@PasswordPolicy=0 OR @PasswordExpiration=0)
  THROW 51335,'MUST_CHANGE requiere CHECK_POLICY y CHECK_EXPIRATION activos.',1;

 IF EXISTS(SELECT 1 FROM @Steps)
 BEGIN
  IF @OperationCode NOT IN('CREATE_SQL_LOGIN','CREATE_WINDOWS_LOGIN','MODIFY_LOGIN','ADD_ROLE_MEMBER','REMOVE_ROLE_MEMBER','PERMISSION_CHANGE')
   THROW 51332,'Esta operación no admite un plan interno.',1;
  IF @OperationCode IN('CREATE_SQL_LOGIN','CREATE_WINDOWS_LOGIN')
  BEGIN
   IF (SELECT TOP(1) OperationCode FROM @Steps ORDER BY StepOrder)<>'CREATE_DB_USER'
    THROW 51333,'El primer paso del acceso inicial debe crear el usuario de base.',1;
   IF EXISTS(SELECT 1 FROM @Steps WHERE OperationCode NOT IN('CREATE_DB_USER','ADD_ROLE_MEMBER','REMOVE_ROLE_MEMBER','PERMISSION_CHANGE'))
    THROW 51338,'El acceso inicial contiene una operación interna no permitida.',1;
  END
  ELSE
  BEGIN
   IF (SELECT COUNT(*) FROM @Targets)<>1
    THROW 51339,'Una modificación compuesta debe trabajar sobre una sola base de datos.',1;
   IF EXISTS(SELECT 1 FROM @Steps WHERE OperationCode NOT IN('ADD_ROLE_MEMBER','REMOVE_ROLE_MEMBER','PERMISSION_CHANGE'))
    THROW 51338,'La modificación compuesta solo admite roles y permisos.',1;
  END;
  IF EXISTS(SELECT 1 FROM @Steps WHERE StepOrder<=0)
     OR (SELECT MIN(StepOrder) FROM @Steps)<>1
     OR (SELECT MAX(StepOrder) FROM @Steps)<>(SELECT COUNT(*) FROM @Steps)
   THROW 51340,'Los cambios internos deben tener un orden consecutivo desde 1.',1;
 END;
 IF (@OperationCode='PERMISSION_CHANGE' AND @ScopeType<>'DATABASE')
    OR EXISTS(SELECT 1 FROM @Steps WHERE OperationCode='PERMISSION_CHANGE' AND ScopeType<>'DATABASE')
 BEGIN
  IF (SELECT COUNT(*) FROM @Targets)<>1 THROW 51339,'Los permisos sobre esquemas, objetos o columnas requieren una sola base de datos.',1;
 END;

 EXEC [access].usp_AccessRequest_TargetPolicyValidate @OperationCode,@PermissionAction,@PermissionName,@ScopeType,@RoleName,@Targets,@Steps;

 BEGIN TRAN;
 DECLARE @LockResult int;EXEC @LockResult=sys.sp_getapplock @Resource=N'SqlAccessAdmin.AccessRequestCreate',@LockMode='Exclusive',@LockOwner='Transaction',@LockTimeout=10000;
 IF @LockResult<0 THROW 51317,'No fue posible bloquear el registro de solicitudes.',1;
 IF @OperationCode IN('CREATE_SQL_LOGIN','CREATE_WINDOWS_LOGIN','CLONE_PERMISSIONS') AND EXISTS
 (
  SELECT 1 FROM [access].AccessRequest r
  JOIN [access].AccessRequestTarget t ON t.RequestId=r.RequestId
  JOIN @Targets requested ON requested.ServerId=t.ServerId
  WHERE r.Status IN('PENDING','APPROVED') AND r.OperationCode IN('CREATE_SQL_LOGIN','CREATE_WINDOWS_LOGIN','CLONE_PERMISSIONS')
   AND UPPER(LTRIM(RTRIM(r.TargetPrincipal)))=UPPER(LTRIM(RTRIM(@TargetPrincipal)))
 )
 BEGIN ROLLBACK;THROW 51346,'Ya existe una solicitud activa para crear el mismo login en este servidor.',1;END;
 DECLARE @ExistingRequestId bigint;
 SELECT TOP(1) @ExistingRequestId=r.RequestId FROM [access].AccessRequest r WITH(UPDLOCK,HOLDLOCK)
 WHERE r.Status IN('PENDING','APPROVED') AND r.OperationCode=@OperationCode
  AND UPPER(LTRIM(RTRIM(r.TargetPrincipal)))=UPPER(LTRIM(RTRIM(@TargetPrincipal)))
  AND NOT EXISTS(SELECT ServerId,DatabaseName FROM @Targets EXCEPT SELECT ServerId,DatabaseName FROM [access].AccessRequestTarget WHERE RequestId=r.RequestId)
  AND NOT EXISTS(SELECT ServerId,DatabaseName FROM [access].AccessRequestTarget WHERE RequestId=r.RequestId EXCEPT SELECT ServerId,DatabaseName FROM @Targets)
  AND (@OperationCode IN('CREATE_SQL_LOGIN','CREATE_WINDOWS_LOGIN') OR
  (
   ISNULL(r.SourcePrincipal,N'')=ISNULL(@SourcePrincipal,N'') AND ISNULL(r.AuthenticationType,'')=ISNULL(@AuthenticationType,'')
   AND ISNULL(r.PermissionAction,'')=ISNULL(@PermissionAction,'') AND ISNULL(r.PermissionName,'')=ISNULL(@PermissionName,'')
   AND ISNULL(r.ScopeType,'')=ISNULL(@ScopeType,'') AND ISNULL(r.Securable,N'')=ISNULL(@Securable,N'') AND ISNULL(r.RoleName,N'')=ISNULL(@RoleName,N'')
   AND NOT EXISTS
   (
    SELECT StepOrder,OperationCode,PermissionAction,PermissionName,ScopeType,Securable,RoleName FROM @Steps
    EXCEPT
    SELECT StepOrder,OperationCode,PermissionAction,PermissionName,ScopeType,Securable,RoleName FROM [access].AccessRequestStep WHERE RequestId=r.RequestId
   )
   AND NOT EXISTS
   (
    SELECT StepOrder,OperationCode,PermissionAction,PermissionName,ScopeType,Securable,RoleName FROM [access].AccessRequestStep WHERE RequestId=r.RequestId
    EXCEPT
    SELECT StepOrder,OperationCode,PermissionAction,PermissionName,ScopeType,Securable,RoleName FROM @Steps
   )
  ))
 ORDER BY r.RequestId DESC;
 IF @ExistingRequestId IS NOT NULL
 BEGIN
  ROLLBACK;
  DECLARE @DuplicateMessage nvarchar(2048)=CONCAT(N'Ya existe la solicitud activa #',@ExistingRequestId,N' con el mismo plan de cambios y destinos.');
  THROW 51316,@DuplicateMessage,1;
 END;
 INSERT [access].AccessRequest(OperationCode,TargetPrincipal,SourcePrincipal,AuthenticationType,PermissionAction,PermissionName,ScopeType,Securable,RoleName,ExternalTicketNumber,Justification,
  SecretCiphertext,SecretNonce,SecretTag,SecretKeyId,PasswordPolicy,PasswordExpiration,MustChangePassword,CopyPlanJson)
 VALUES(@OperationCode,@TargetPrincipal,@SourcePrincipal,@AuthenticationType,@PermissionAction,@PermissionName,@ScopeType,@Securable,@RoleName,@ExternalTicketNumber,@Justification,
  @SecretCiphertext,@SecretNonce,@SecretTag,@SecretKeyId,@PasswordPolicy,@PasswordExpiration,@MustChangePassword,@CopyPlanJson);
 DECLARE @Id bigint=SCOPE_IDENTITY();
 INSERT [access].AccessRequestTarget(RequestId,ServerId,DatabaseName) SELECT @Id,ServerId,DatabaseName FROM @Targets;
 INSERT [access].AccessRequestStep(RequestId,StepOrder,OperationCode,PermissionAction,PermissionName,ScopeType,Securable,RoleName)
  SELECT @Id,StepOrder,OperationCode,PermissionAction,PermissionName,ScopeType,Securable,RoleName FROM @Steps;
 COMMIT;
 DECLARE @ChangeCount int=1+(SELECT COUNT(*) FROM @Steps);
 IF @OperationCode='CLONE_PERMISSIONS'
  SELECT @ChangeCount=1+(SELECT COUNT(*) FROM OPENJSON(@CopyPlanJson,'$.Databases'))+COUNT(*)
  FROM OPENJSON(@CopyPlanJson,'$.Databases') WITH(Accesses nvarchar(max) '$.Accesses' AS JSON) d
  CROSS APPLY OPENJSON(d.Accesses) WITH(CanCopy bit '$.CanCopy') a WHERE a.CanCopy=1;
 DECLARE @AuditDetail nvarchar(2000)=CONCAT(N'Solicitud #',@Id,N' · ',@ExternalTicketNumber,N' · ',@ChangeCount,N' cambios · Autenticación=',COALESCE(@AuthenticationType,'N/A'),N' · ',
  N'CHECK_POLICY=',IIF(@PasswordPolicy=1,N'ON',N'OFF'),N' · CHECK_EXPIRATION=',IIF(@PasswordExpiration=1,N'ON',N'OFF'),N' · MUST_CHANGE=',IIF(@MustChangePassword=1,N'ON',N'OFF'));
 EXEC [access].usp_Audit_Write N'Solicitudes',N'Crear',NULL,NULL,1,@AuditDetail;
 SELECT @Id RequestId,'PENDING' [Status];
END;
GO
CREATE OR ALTER PROCEDURE [access].usp_AccessRequest_Approve
 @RequestId bigint,@Approve bit,@Comment nvarchar(1000)
AS
BEGIN
 SET NOCOUNT ON;SET XACT_ABORT ON;
 -- SqlAccessAdmin.ScopedPolicyTargets / SqlAccessAdmin.AccessRequestApprove · SqlAccessAdmin.SelfConfirmation · SqlAccessAdmin.AccessChangesComposite
 IF IS_SRVROLEMEMBER(N'sysadmin')<>1 AND NOT EXISTS
 (SELECT 1 FROM [access].AuthorizedPrincipal WHERE Principal=ORIGINAL_LOGIN() AND Active=1 AND RoleName IN('Administrator','Operator'))
  THROW 51301,'Se requiere un usuario Administrator u Operator activo.',1;
 -- SqlAccessAdmin.LoginAuthenticationSelection
 IF @Approve=1
 BEGIN
  DECLARE @AuthOperation varchar(40),@AuthTarget nvarchar(256),@AuthType varchar(20),
   @AuthCipher varbinary(max),@AuthNonce varbinary(12),@AuthTag varbinary(16),@AuthKey uniqueidentifier,
   @AuthPolicy bit,@AuthExpiration bit,@AuthMustChange bit;
  SELECT @AuthOperation=OperationCode,@AuthTarget=TargetPrincipal,@AuthType=AuthenticationType,
   @AuthCipher=SecretCiphertext,@AuthNonce=SecretNonce,@AuthTag=SecretTag,@AuthKey=SecretKeyId,
   @AuthPolicy=PasswordPolicy,@AuthExpiration=PasswordExpiration,@AuthMustChange=MustChangePassword
  FROM [access].AccessRequest WHERE RequestId=@RequestId;
  EXEC [access].usp_AccessRequest_AuthenticationValidate @AuthOperation,@AuthTarget,@AuthType,
   @AuthCipher,@AuthNonce,@AuthTag,@AuthKey,@AuthPolicy,@AuthExpiration,@AuthMustChange;
 END;
 IF @Approve=1 AND EXISTS(SELECT 1 FROM [access].AccessRequest WHERE RequestId=@RequestId AND OperationCode='CLONE_PERMISSIONS')
 BEGIN
  DECLARE @CopyPlan nvarchar(max),@CopyFingerprint nvarchar(776),@CopyTargets [access].AccessRequestTargetType;
  SELECT @CopyPlan=CopyPlanJson,@CopyFingerprint=Securable FROM [access].AccessRequest WHERE RequestId=@RequestId;
  INSERT @CopyTargets SELECT ServerId,DatabaseName FROM [access].AccessRequestTarget WHERE RequestId=@RequestId;
  EXEC [access].usp_AccessRequest_CopyPlanValidate @CopyPlan,@CopyFingerprint,@CopyTargets;
 END;
 IF @Approve=1
 BEGIN
  DECLARE @PolicyTargets [access].AccessRequestTargetType,@PolicySteps [access].AccessRequestStepPolicyType;
  DECLARE @PolicyOperation varchar(40),@PolicyAction varchar(10),@PolicyPermission varchar(128),@PolicyScope varchar(20),@PolicyRole sysname;
  SELECT @PolicyOperation=OperationCode,@PolicyAction=PermissionAction,@PolicyPermission=PermissionName,@PolicyScope=ScopeType,@PolicyRole=RoleName FROM [access].AccessRequest WHERE RequestId=@RequestId;
  INSERT @PolicyTargets SELECT ServerId,DatabaseName FROM [access].AccessRequestTarget WHERE RequestId=@RequestId;
  INSERT @PolicySteps SELECT StepOrder,OperationCode,PermissionAction,PermissionName,ScopeType,Securable,RoleName FROM [access].AccessRequestStep WHERE RequestId=@RequestId;
  EXEC [access].usp_AccessRequest_TargetPolicyValidate @PolicyOperation,@PolicyAction,@PolicyPermission,@PolicyScope,@PolicyRole,@PolicyTargets,@PolicySteps;
 END;
 BEGIN TRAN;
 DECLARE @LockResult int;EXEC @LockResult=sys.sp_getapplock @Resource=N'SqlAccessAdmin.AccessRequestApprove',@LockMode='Exclusive',@LockOwner='Transaction',@LockTimeout=10000;
 IF @LockResult<0 THROW 51319,'No fue posible bloquear la confirmación de solicitudes.',1;
 IF @Approve=1 AND EXISTS
 (
  SELECT 1 FROM [access].AccessRequest c JOIN [access].AccessRequest a
   ON a.RequestId<>c.RequestId AND a.Status='APPROVED' AND a.OperationCode=c.OperationCode
   AND UPPER(LTRIM(RTRIM(a.TargetPrincipal)))=UPPER(LTRIM(RTRIM(c.TargetPrincipal)))
  WHERE c.RequestId=@RequestId AND c.Status='PENDING'
   AND NOT EXISTS(SELECT ServerId,DatabaseName FROM [access].AccessRequestTarget WHERE RequestId=c.RequestId EXCEPT SELECT ServerId,DatabaseName FROM [access].AccessRequestTarget WHERE RequestId=a.RequestId)
   AND NOT EXISTS(SELECT ServerId,DatabaseName FROM [access].AccessRequestTarget WHERE RequestId=a.RequestId EXCEPT SELECT ServerId,DatabaseName FROM [access].AccessRequestTarget WHERE RequestId=c.RequestId)
   AND (c.OperationCode IN('CREATE_SQL_LOGIN','CREATE_WINDOWS_LOGIN') OR
   (
    ISNULL(a.SourcePrincipal,N'')=ISNULL(c.SourcePrincipal,N'') AND ISNULL(a.AuthenticationType,'')=ISNULL(c.AuthenticationType,'')
    AND ISNULL(a.PermissionAction,'')=ISNULL(c.PermissionAction,'') AND ISNULL(a.PermissionName,'')=ISNULL(c.PermissionName,'')
    AND ISNULL(a.ScopeType,'')=ISNULL(c.ScopeType,'') AND ISNULL(a.Securable,N'')=ISNULL(c.Securable,N'') AND ISNULL(a.RoleName,N'')=ISNULL(c.RoleName,N'')
    AND NOT EXISTS
    (
     SELECT StepOrder,OperationCode,PermissionAction,PermissionName,ScopeType,Securable,RoleName FROM [access].AccessRequestStep WHERE RequestId=c.RequestId
     EXCEPT
     SELECT StepOrder,OperationCode,PermissionAction,PermissionName,ScopeType,Securable,RoleName FROM [access].AccessRequestStep WHERE RequestId=a.RequestId
    )
    AND NOT EXISTS
    (
     SELECT StepOrder,OperationCode,PermissionAction,PermissionName,ScopeType,Securable,RoleName FROM [access].AccessRequestStep WHERE RequestId=a.RequestId
     EXCEPT
     SELECT StepOrder,OperationCode,PermissionAction,PermissionName,ScopeType,Securable,RoleName FROM [access].AccessRequestStep WHERE RequestId=c.RequestId
    )
   ))
 )
 BEGIN ROLLBACK;THROW 51318,'Ya existe otra solicitud equivalente confirmada. Rechace este duplicado.',1;END;
 UPDATE [access].AccessRequest SET Status=IIF(@Approve=1,'APPROVED','REJECTED'),ApprovedBy=ORIGINAL_LOGIN(),ApprovedAt=SYSUTCDATETIME(),ApprovalComment=@Comment
 WHERE RequestId=@RequestId AND Status='PENDING';
 IF @@ROWCOUNT=0 BEGIN ROLLBACK;THROW 51314,'La solicitud no está pendiente.',1;END;
 COMMIT;
 DECLARE @Action nvarchar(50)=IIF(@Approve=1,N'Confirmar',N'Rechazar');
 DECLARE @AuditDetail nvarchar(max)=CONCAT(N'Solicitud #',@RequestId,N' · doble check del operador · ',@Comment);
 EXEC [access].usp_Audit_Write N'Solicitudes',@Action,NULL,NULL,1,@AuditDetail;
END;
GO
CREATE OR ALTER PROCEDURE [access].usp_Policy_DenyUpsert
 @Category varchar(30),@DeniedValue nvarchar(256),@Reason nvarchar(1000),@Active bit=1
AS
BEGIN
 SET NOCOUNT ON;SET XACT_ABORT ON;
 IF ISNULL(IS_SRVROLEMEMBER(N'sysadmin'),0)<>1 AND NOT EXISTS
 (SELECT 1 FROM [access].AuthorizedPrincipal WHERE Principal=ORIGINAL_LOGIN() AND Active=1 AND RoleName='Administrator')
  THROW 51301,'Se requiere Administrator.',1;
 SET @Category=UPPER(@Category);SET @DeniedValue=LTRIM(RTRIM(@DeniedValue));SET @Reason=LTRIM(RTRIM(@Reason));
 IF @Category IS NULL OR @Category NOT IN('PERMISSION','DATABASE_ROLE','SERVER_ROLE','OPERATION','CLAUSE')
  OR NULLIF(@DeniedValue,N'') IS NULL OR NULLIF(@Reason,N'') IS NULL OR @Active IS NULL
  THROW 51303,'Categoría, valor, motivo o estado no permitido.',1;
 BEGIN TRY
  BEGIN TRAN;
 DECLARE @LockResult int;
 EXEC @LockResult=sys.sp_getapplock @Resource=N'SqlAccessAdmin.PolicyChanges',@LockMode='Exclusive',@LockOwner='Transaction',@LockTimeout=10000;
 IF @LockResult<0 THROW 51372,'No fue posible bloquear la política. Reintente.',1;
  MERGE [access].SecurityDenyList AS t USING(SELECT @Category Category,@DeniedValue DeniedValue) AS s
   ON t.Category=s.Category AND t.DeniedValue=s.DeniedValue
  WHEN MATCHED THEN UPDATE SET Reason=@Reason,Active=IIF(t.IsSystem=1,1,@Active)
  WHEN NOT MATCHED THEN INSERT(Category,DeniedValue,Reason,Active) VALUES(s.Category,s.DeniedValue,@Reason,@Active);
  IF @Active=1 UPDATE [access].SecurityPolicyOverride SET Active=0
   WHERE DeniedValue=@DeniedValue AND (Category=@Category OR (@Category='SERVER_ROLE' AND Category='DATABASE_ROLE'));
  IF @Category='PERMISSION'
   UPDATE [access].PolicyPermissionRule SET SpecialActivationApproved=0,SpecialActivationReason=N'' WHERE PermissionName=@DeniedValue;
  IF @Category IN('DATABASE_ROLE','SERVER_ROLE')
   UPDATE [access].PolicyRoleRule SET SpecialActivationApproved=0,SpecialActivationReason=N'' WHERE RoleName=@DeniedValue AND RoleScope=IIF(@Category='SERVER_ROLE','SERVER','DATABASE');
  DECLARE @Detail nvarchar(2000)=CONCAT(@Category,N': ',@DeniedValue,N'; Motivo=',@Reason);
  EXEC [access].usp_Audit_Write N'Política de seguridad',N'Actualizar bloqueo obligatorio',NULL,NULL,1,@Detail;
  COMMIT;
 END TRY
 BEGIN CATCH
  IF XACT_STATE()<>0 ROLLBACK;
  THROW;
 END CATCH;
END;
GO

-- SSMS puede continuar con los siguientes GO aunque un lote anterior falle.
-- No anunciar una instalación correcta solo por haber alcanzado el último lote.
IF EXISTS
 (SELECT 1 FROM (VALUES
  (N'PolicyScopeCatalog',N'U'),(N'PolicyPermissionCatalog',N'U'),
  (N'PolicyPermissionAvailability',N'U'),(N'PolicyPermissionRule',N'U'),
  (N'PolicyRoleRule',N'U'),(N'PolicyRoleDiscovery',N'U'),
  (N'ufn_PolicyPermissionSupported',N'FN'),(N'ufn_PolicyPermissionRequiresActivation',N'FN'),
  (N'ufn_PolicyPermissionEffective',N'IF'),(N'ufn_PolicyRoleEffective',N'IF'),
  (N'usp_Policy_ContextValidate',N'P'),(N'usp_Policy_DiscoverRoles',N'P'),
  (N'usp_Policy_RestoreInheritance',N'P'),(N'usp_AccessRequest_TargetPolicyValidate',N'P')
 ) expected(Name,Type)
 WHERE OBJECT_ID(N'[access].'+QUOTENAME(expected.Name),expected.Type) IS NULL)
 THROW 51490,'El script 27 quedó incompleto. Revise los errores anteriores y vuelva a ejecutarlo completo después de corregirlos.',1;
GO
IF TYPE_ID(N'[access].AccessRequestStepPolicyType') IS NULL
 OR COL_LENGTH(N'[access].PolicyPermissionCatalog',N'PermissionName')<128
 OR COL_LENGTH(N'[access].PolicyPermissionAvailability',N'PermissionName')<128
 OR COL_LENGTH(N'[access].PolicyPermissionRule',N'PermissionName')<128
 OR COL_LENGTH(N'[access].AccessRequest',N'PermissionName')<128
 OR COL_LENGTH(N'[access].AccessRequestStep',N'PermissionName')<128
 THROW 51492,'El contrato de permisos de 128 caracteres no quedó completo. Revise los errores anteriores.',1;
IF NOT EXISTS(SELECT 1 FROM [access].PolicyPermissionCatalog WHERE PermissionName='SELECT' AND ScopeType='DATABASE')
 THROW 51491,'El catálogo de permisos no se cargó. Revise los errores anteriores y vuelva a ejecutar el script 27 completo.',1;
PRINT N'Finalizó la ejecución del script 27. Revise que no haya errores anteriores y ejecute 99_ValidarInstalacion.sql antes de reiniciar. No se modificaron accesos en servidores destino.';
GO

