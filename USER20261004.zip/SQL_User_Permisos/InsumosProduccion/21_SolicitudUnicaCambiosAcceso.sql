USE [adminDB];
GO
SET NOCOUNT ON;
SET XACT_ABORT ON;
GO

/* Ejecutar manualmente como DBA después de 19 y, si corresponde, 20.
   La cabecera contiene el primer cambio y AccessRequestStep los restantes.
   Una confirmación y una ejecución abarcan todos los cambios de la solicitud.
   No agrupa ni modifica solicitudes históricas. Puede reejecutarse. */
IF OBJECT_ID(N'[access].AccessRequestStep',N'U') IS NULL
   OR TYPE_ID(N'[access].AccessRequestStepType') IS NULL
   OR COL_LENGTH(N'[access].AccessRequest',N'SecretCiphertext') IS NULL
    THROW 51336,'Ejecute primero 19_SolicitudCompuestaYContrasenaTemporal.sql bajo el esquema access.',1;
GO

CREATE OR ALTER PROCEDURE [access].usp_AccessRequest_Create
 @OperationCode varchar(40),@TargetPrincipal nvarchar(256),@SourcePrincipal nvarchar(256)=NULL,
 @AuthenticationType varchar(20)=NULL,@PermissionAction varchar(10)=NULL,@PermissionName varchar(40)=NULL,
 @ScopeType varchar(20)=NULL,@Securable nvarchar(776)=NULL,@RoleName sysname=NULL,
 @ExternalTicketNumber varchar(40),@Justification nvarchar(1000),
 @Targets [access].AccessRequestTargetType READONLY,@Steps [access].AccessRequestStepType READONLY,
 @SecretCiphertext varbinary(max)=NULL,@SecretNonce varbinary(12)=NULL,@SecretTag varbinary(16)=NULL,
 @SecretKeyId uniqueidentifier=NULL,@PasswordPolicy bit=0,@PasswordExpiration bit=0,@MustChangePassword bit=0
AS
BEGIN
 SET NOCOUNT ON;SET XACT_ABORT ON;
 -- SqlAccessAdmin.AccessRequestCreate · SqlAccessAdmin.CompositeRequestCreate · SqlAccessAdmin.AccessChangesComposite
 SET @ExternalTicketNumber=UPPER(LTRIM(RTRIM(@ExternalTicketNumber)));
 IF @ExternalTicketNumber IS NULL OR @ExternalTicketNumber NOT LIKE 'TIC-RF-%'
    OR LEN(@ExternalTicketNumber)<=7 OR SUBSTRING(@ExternalTicketNumber,8,40) LIKE '%[^0-9]%'
  THROW 51320,'El ticket externo debe usar TIC-RF- seguido únicamente por dígitos.',1;
 IF NOT EXISTS(SELECT 1 FROM @Targets) THROW 51310,'Debe seleccionar destinos.',1;
 IF (SELECT COUNT(DISTINCT ServerId) FROM @Targets)<>1 THROW 51314,'Cada solicitud debe pertenecer a un único servidor.',1;
 IF @Justification IS NULL OR LEN(LTRIM(RTRIM(@Justification)))<10 THROW 51311,'La justificación debe contener al menos 10 caracteres.',1;
 IF @TargetPrincipal IS NULL OR LEN(LTRIM(RTRIM(@TargetPrincipal)))=0 THROW 51337,'Debe indicar el principal destino.',1;
 IF @OperationCode='CREATE_SQL_LOGIN' AND (@SecretCiphertext IS NULL OR @SecretNonce IS NULL OR @SecretTag IS NULL OR @SecretKeyId IS NULL)
  THROW 51330,'La creación de un login SQL requiere una contraseña temporal cifrada.',1;
 IF @OperationCode='CREATE_SQL_LOGIN' AND @PasswordExpiration=1 AND @PasswordPolicy=0
  THROW 51331,'CHECK_EXPIRATION requiere CHECK_POLICY activo.',1;
 IF @OperationCode='CREATE_SQL_LOGIN' AND @MustChangePassword=1 AND (@PasswordPolicy=0 OR @PasswordExpiration=0)
  THROW 51335,'MUST_CHANGE requiere CHECK_POLICY y CHECK_EXPIRATION activos.',1;

 IF EXISTS(SELECT 1 FROM @Steps)
 BEGIN
  IF @OperationCode NOT IN('CREATE_SQL_LOGIN','CREATE_WINDOWS_LOGIN','MODIFY_LOGIN','ADD_ROLE_MEMBER','REMOVE_ROLE_MEMBER','PERMISSION_CHANGE')
   THROW 51332,'Esta operación no admite un plan interno.',1;
  IF @OperationCode IN('CREATE_SQL_LOGIN','CREATE_WINDOWS_LOGIN')
  BEGIN
   IF (SELECT TOP(1) OperationCode FROM @Steps ORDER BY StepOrder)<>'CREATE_DB_USER'
    THROW 51333,'El primer paso del acceso inicial debe crear el usuario de base.',1;
   IF EXISTS(SELECT 1 FROM @Steps WHERE OperationCode NOT IN('CREATE_DB_USER','ADD_ROLE_MEMBER','REMOVE_ROLE_MEMBER','PERMISSION_CHANGE'))
    THROW 51338,'El acceso inicial contiene una operación interna no permitida.',1;
  END
  ELSE
  BEGIN
   IF (SELECT COUNT(*) FROM @Targets)<>1
    THROW 51339,'Una modificación compuesta debe trabajar sobre una sola base de datos.',1;
   IF EXISTS(SELECT 1 FROM @Steps WHERE OperationCode NOT IN('ADD_ROLE_MEMBER','REMOVE_ROLE_MEMBER','PERMISSION_CHANGE'))
    THROW 51338,'La modificación compuesta solo admite roles y permisos.',1;
  END;
  IF EXISTS(SELECT 1 FROM @Steps WHERE StepOrder<=0)
     OR (SELECT MIN(StepOrder) FROM @Steps)<>1
     OR (SELECT MAX(StepOrder) FROM @Steps)<>(SELECT COUNT(*) FROM @Steps)
   THROW 51340,'Los cambios internos deben tener un orden consecutivo desde 1.',1;
 END;
 IF (@OperationCode='PERMISSION_CHANGE' AND @ScopeType='OBJECT')
    OR EXISTS(SELECT 1 FROM @Steps WHERE OperationCode='PERMISSION_CHANGE' AND ScopeType='OBJECT')
 BEGIN
  IF (SELECT COUNT(*) FROM @Targets)<>1 THROW 51339,'Los permisos por objeto requieren una sola base de datos.',1;
 END;

 DECLARE @Check table(Allowed bit,RequiresApproval bit,RiskLevel varchar(10),Reason nvarchar(2000));
 INSERT @Check EXEC [access].usp_AccessRequest_Preview @OperationCode,@PermissionAction,@PermissionName,@ScopeType,@RoleName;
 IF NOT EXISTS(SELECT 1 FROM @Check WHERE Allowed=1) THROW 51312,'Solicitud rechazada por la política central.',1;
 DECLARE @SO varchar(40),@SA varchar(10),@SP varchar(40),@SS varchar(20),@SR sysname;
 DECLARE StepPolicy CURSOR LOCAL FAST_FORWARD FOR SELECT OperationCode,PermissionAction,PermissionName,ScopeType,RoleName FROM @Steps ORDER BY StepOrder;
 OPEN StepPolicy;FETCH NEXT FROM StepPolicy INTO @SO,@SA,@SP,@SS,@SR;
 WHILE @@FETCH_STATUS=0
 BEGIN
  DELETE FROM @Check;INSERT @Check EXEC [access].usp_AccessRequest_Preview @SO,@SA,@SP,@SS,@SR;
  IF NOT EXISTS(SELECT 1 FROM @Check WHERE Allowed=1)
  BEGIN CLOSE StepPolicy;DEALLOCATE StepPolicy;THROW 51334,'Un cambio interno fue rechazado por la política central.',1;END;
  FETCH NEXT FROM StepPolicy INTO @SO,@SA,@SP,@SS,@SR;
 END;
 CLOSE StepPolicy;DEALLOCATE StepPolicy;

 BEGIN TRAN;
 DECLARE @LockResult int;EXEC @LockResult=sys.sp_getapplock @Resource=N'SqlAccessAdmin.AccessRequestCreate',@LockMode='Exclusive',@LockOwner='Transaction',@LockTimeout=10000;
 IF @LockResult<0 THROW 51317,'No fue posible bloquear el registro de solicitudes.',1;
 DECLARE @ExistingRequestId bigint;
 SELECT TOP(1) @ExistingRequestId=r.RequestId FROM [access].AccessRequest r WITH(UPDLOCK,HOLDLOCK)
 WHERE r.Status IN('PENDING','APPROVED') AND r.OperationCode=@OperationCode
  AND UPPER(LTRIM(RTRIM(r.TargetPrincipal)))=UPPER(LTRIM(RTRIM(@TargetPrincipal)))
  AND NOT EXISTS(SELECT ServerId,DatabaseName FROM @Targets EXCEPT SELECT ServerId,DatabaseName FROM [access].AccessRequestTarget WHERE RequestId=r.RequestId)
  AND NOT EXISTS(SELECT ServerId,DatabaseName FROM [access].AccessRequestTarget WHERE RequestId=r.RequestId EXCEPT SELECT ServerId,DatabaseName FROM @Targets)
  AND (@OperationCode IN('CREATE_SQL_LOGIN','CREATE_WINDOWS_LOGIN') OR
  (
   ISNULL(r.SourcePrincipal,N'')=ISNULL(@SourcePrincipal,N'') AND ISNULL(r.AuthenticationType,'')=ISNULL(@AuthenticationType,'')
   AND ISNULL(r.PermissionAction,'')=ISNULL(@PermissionAction,'') AND ISNULL(r.PermissionName,'')=ISNULL(@PermissionName,'')
   AND ISNULL(r.ScopeType,'')=ISNULL(@ScopeType,'') AND ISNULL(r.Securable,N'')=ISNULL(@Securable,N'') AND ISNULL(r.RoleName,N'')=ISNULL(@RoleName,N'')
   AND NOT EXISTS
   (
    SELECT StepOrder,OperationCode,PermissionAction,PermissionName,ScopeType,Securable,RoleName FROM @Steps
    EXCEPT
    SELECT StepOrder,OperationCode,PermissionAction,PermissionName,ScopeType,Securable,RoleName FROM [access].AccessRequestStep WHERE RequestId=r.RequestId
   )
   AND NOT EXISTS
   (
    SELECT StepOrder,OperationCode,PermissionAction,PermissionName,ScopeType,Securable,RoleName FROM [access].AccessRequestStep WHERE RequestId=r.RequestId
    EXCEPT
    SELECT StepOrder,OperationCode,PermissionAction,PermissionName,ScopeType,Securable,RoleName FROM @Steps
   )
  ))
 ORDER BY r.RequestId DESC;
 IF @ExistingRequestId IS NOT NULL
 BEGIN
  ROLLBACK;
  DECLARE @DuplicateMessage nvarchar(2048)=CONCAT(N'Ya existe la solicitud activa #',@ExistingRequestId,N' con el mismo plan de cambios y destinos.');
  THROW 51316,@DuplicateMessage,1;
 END;
 INSERT [access].AccessRequest(OperationCode,TargetPrincipal,SourcePrincipal,AuthenticationType,PermissionAction,PermissionName,ScopeType,Securable,RoleName,ExternalTicketNumber,Justification,
  SecretCiphertext,SecretNonce,SecretTag,SecretKeyId,PasswordPolicy,PasswordExpiration,MustChangePassword)
 VALUES(@OperationCode,@TargetPrincipal,@SourcePrincipal,@AuthenticationType,@PermissionAction,@PermissionName,@ScopeType,@Securable,@RoleName,@ExternalTicketNumber,@Justification,
  @SecretCiphertext,@SecretNonce,@SecretTag,@SecretKeyId,@PasswordPolicy,@PasswordExpiration,@MustChangePassword);
 DECLARE @Id bigint=SCOPE_IDENTITY();
 INSERT [access].AccessRequestTarget(RequestId,ServerId,DatabaseName) SELECT @Id,ServerId,DatabaseName FROM @Targets;
 INSERT [access].AccessRequestStep(RequestId,StepOrder,OperationCode,PermissionAction,PermissionName,ScopeType,Securable,RoleName)
  SELECT @Id,StepOrder,OperationCode,PermissionAction,PermissionName,ScopeType,Securable,RoleName FROM @Steps;
 COMMIT;
 DECLARE @ChangeCount int=1+(SELECT COUNT(*) FROM @Steps);
 DECLARE @AuditDetail nvarchar(2000)=CONCAT(N'Solicitud #',@Id,N' · ',@ExternalTicketNumber,N' · ',@ChangeCount,N' cambios · ',
  N'CHECK_POLICY=',IIF(@PasswordPolicy=1,N'ON',N'OFF'),N' · CHECK_EXPIRATION=',IIF(@PasswordExpiration=1,N'ON',N'OFF'),N' · MUST_CHANGE=',IIF(@MustChangePassword=1,N'ON',N'OFF'));
 EXEC [access].usp_Audit_Write N'Solicitudes',N'Crear',NULL,NULL,1,@AuditDetail;
 SELECT @Id RequestId,'PENDING' [Status];
END;
GO

CREATE OR ALTER PROCEDURE [access].usp_AccessRequest_Approve
 @RequestId bigint,@Approve bit,@Comment nvarchar(1000)
AS
BEGIN
 SET NOCOUNT ON;SET XACT_ABORT ON;
 -- SqlAccessAdmin.AccessRequestApprove · SqlAccessAdmin.SelfConfirmation · SqlAccessAdmin.AccessChangesComposite
 IF IS_SRVROLEMEMBER(N'sysadmin')<>1 AND NOT EXISTS
 (SELECT 1 FROM [access].AuthorizedPrincipal WHERE Principal=ORIGINAL_LOGIN() AND Active=1 AND RoleName IN('Administrator','Operator'))
  THROW 51301,'Se requiere un usuario Administrator u Operator activo.',1;
 BEGIN TRAN;
 DECLARE @LockResult int;EXEC @LockResult=sys.sp_getapplock @Resource=N'SqlAccessAdmin.AccessRequestApprove',@LockMode='Exclusive',@LockOwner='Transaction',@LockTimeout=10000;
 IF @LockResult<0 THROW 51319,'No fue posible bloquear la confirmación de solicitudes.',1;
 IF @Approve=1 AND EXISTS
 (
  SELECT 1 FROM [access].AccessRequest c JOIN [access].AccessRequest a
   ON a.RequestId<>c.RequestId AND a.Status='APPROVED' AND a.OperationCode=c.OperationCode
   AND UPPER(LTRIM(RTRIM(a.TargetPrincipal)))=UPPER(LTRIM(RTRIM(c.TargetPrincipal)))
  WHERE c.RequestId=@RequestId AND c.Status='PENDING'
   AND NOT EXISTS(SELECT ServerId,DatabaseName FROM [access].AccessRequestTarget WHERE RequestId=c.RequestId EXCEPT SELECT ServerId,DatabaseName FROM [access].AccessRequestTarget WHERE RequestId=a.RequestId)
   AND NOT EXISTS(SELECT ServerId,DatabaseName FROM [access].AccessRequestTarget WHERE RequestId=a.RequestId EXCEPT SELECT ServerId,DatabaseName FROM [access].AccessRequestTarget WHERE RequestId=c.RequestId)
   AND (c.OperationCode IN('CREATE_SQL_LOGIN','CREATE_WINDOWS_LOGIN') OR
   (
    ISNULL(a.SourcePrincipal,N'')=ISNULL(c.SourcePrincipal,N'') AND ISNULL(a.AuthenticationType,'')=ISNULL(c.AuthenticationType,'')
    AND ISNULL(a.PermissionAction,'')=ISNULL(c.PermissionAction,'') AND ISNULL(a.PermissionName,'')=ISNULL(c.PermissionName,'')
    AND ISNULL(a.ScopeType,'')=ISNULL(c.ScopeType,'') AND ISNULL(a.Securable,N'')=ISNULL(c.Securable,N'') AND ISNULL(a.RoleName,N'')=ISNULL(c.RoleName,N'')
    AND NOT EXISTS
    (
     SELECT StepOrder,OperationCode,PermissionAction,PermissionName,ScopeType,Securable,RoleName FROM [access].AccessRequestStep WHERE RequestId=c.RequestId
     EXCEPT
     SELECT StepOrder,OperationCode,PermissionAction,PermissionName,ScopeType,Securable,RoleName FROM [access].AccessRequestStep WHERE RequestId=a.RequestId
    )
    AND NOT EXISTS
    (
     SELECT StepOrder,OperationCode,PermissionAction,PermissionName,ScopeType,Securable,RoleName FROM [access].AccessRequestStep WHERE RequestId=a.RequestId
     EXCEPT
     SELECT StepOrder,OperationCode,PermissionAction,PermissionName,ScopeType,Securable,RoleName FROM [access].AccessRequestStep WHERE RequestId=c.RequestId
    )
   ))
 )
 BEGIN ROLLBACK;THROW 51318,'Ya existe otra solicitud equivalente confirmada. Rechace este duplicado.',1;END;
 UPDATE [access].AccessRequest SET Status=IIF(@Approve=1,'APPROVED','REJECTED'),ApprovedBy=ORIGINAL_LOGIN(),ApprovedAt=SYSUTCDATETIME(),ApprovalComment=@Comment
 WHERE RequestId=@RequestId AND Status='PENDING';
 IF @@ROWCOUNT=0 BEGIN ROLLBACK;THROW 51314,'La solicitud no está pendiente.',1;END;
 COMMIT;
 DECLARE @Action nvarchar(50)=IIF(@Approve=1,N'Confirmar',N'Rechazar');
 DECLARE @AuditDetail nvarchar(max)=CONCAT(N'Solicitud #',@RequestId,N' · doble check del operador · ',@Comment);
 EXEC [access].usp_Audit_Write N'Solicitudes',@Action,NULL,NULL,1,@AuditDetail;
END;
GO
GRANT EXECUTE ON [access].usp_AccessRequest_Create TO [SqlAccessAdmin_Users];
GRANT EXECUTE ON [access].usp_AccessRequest_Approve TO [SqlAccessAdmin_Users];
GO
PRINT N'Solicitud única para cambios de roles y permisos instalada.';
GO
