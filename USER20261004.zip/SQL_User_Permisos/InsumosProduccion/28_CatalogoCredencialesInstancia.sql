USE [adminDB];
GO
SET NOCOUNT ON;
SET XACT_ABORT ON;
GO
-- Complemento repetible de 27. No cambia autorizaciones ni accesos en destinos.
IF OBJECT_ID(N'[access].PolicyScopeCatalog',N'U') IS NULL
 OR OBJECT_ID(N'[access].PolicyPermissionCatalog',N'U') IS NULL
 THROW 51493,'Ejecute primero el script 27 actualizado.',1;
GO
BEGIN TRY
 BEGIN TRAN;
 MERGE [access].PolicyScopeCatalog AS t
 USING(VALUES('CREDENTIAL','CREDENTIAL',1,CONVERT(bit,1))) AS s(ScopeType,SqlClass,Parts,IsServer)
 ON t.ScopeType=s.ScopeType
 WHEN MATCHED THEN UPDATE SET SqlClass=s.SqlClass,Parts=s.Parts,IsServer=s.IsServer
 WHEN NOT MATCHED THEN INSERT(ScopeType,SqlClass,Parts,IsServer) VALUES(s.ScopeType,s.SqlClass,s.Parts,s.IsServer);
 INSERT [access].PolicyPermissionCatalog(PermissionName,ScopeType)
 SELECT DISTINCT p.PermissionName,'CREDENTIAL'
 FROM(SELECT permission_name COLLATE DATABASE_DEFAULT AS PermissionName,
             class_desc COLLATE DATABASE_DEFAULT AS SqlClass
      FROM sys.fn_builtin_permissions(DEFAULT)) AS p
 WHERE p.SqlClass='CREDENTIAL'
 AND NOT EXISTS(SELECT 1 FROM [access].PolicyPermissionCatalog AS c
                WHERE c.ScopeType='CREDENTIAL' AND c.PermissionName=p.PermissionName);
 COMMIT;
END TRY
BEGIN CATCH
 IF XACT_STATE()<>0 ROLLBACK;
 THROW;
END CATCH;
GO
IF NOT EXISTS(SELECT 1 FROM [access].PolicyScopeCatalog WHERE ScopeType='CREDENTIAL' AND SqlClass='CREDENTIAL' AND Parts=1 AND IsServer=1)
 THROW 51494,'No se registró el ámbito CREDENTIAL. Revise los errores anteriores.',1;
PRINT N'Ámbito de credenciales de instancia registrado. Ejecute 99 y use la aplicación actualizada. Los permisos nuevos siguen bloqueados hasta autorizarlos.';
GO
