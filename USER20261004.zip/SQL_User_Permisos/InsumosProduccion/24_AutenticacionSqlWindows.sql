USE [adminDB];
GO
SET NOCOUNT ON;
SET XACT_ABORT ON;
GO
/* Aplicar manualmente después de 23. Conserva los planes v2 y solicitudes SQL existentes.
   Windows usa una cuenta existente; este script no crea cuentas de Active Directory. */
IF COL_LENGTH(N'[access].AccessRequest',N'CopyPlanJson') IS NULL
 OR OBJECT_ID(N'[access].usp_AccessRequest_CopyPlanValidate',N'P') IS NULL
 OR ISNULL(OBJECT_DEFINITION(OBJECT_ID(N'[access].usp_AccessRequest_Create',N'P')),N'') NOT LIKE N'%SqlAccessAdmin.PermissionCopyByDatabase%'
 THROW 51358,'Ejecute primero 23_DetalleCopiaPermisosPorBase.sql.',1;
GO

CREATE OR ALTER PROCEDURE [access].usp_AccessRequest_AuthenticationValidate
 @OperationCode varchar(40),@TargetPrincipal nvarchar(256),@AuthenticationType varchar(20),
 @SecretCiphertext varbinary(max)=NULL,@SecretNonce varbinary(12)=NULL,@SecretTag varbinary(16)=NULL,
 @SecretKeyId uniqueidentifier=NULL,@PasswordPolicy bit=0,@PasswordExpiration bit=0,@MustChangePassword bit=0
AS
BEGIN
 SET NOCOUNT ON;
 -- SqlAccessAdmin.LoginAuthenticationSelection
 IF @OperationCode NOT IN('CREATE_SQL_LOGIN','CREATE_WINDOWS_LOGIN','CLONE_PERMISSIONS') OR @OperationCode IS NULL RETURN;
 IF ISNULL(@AuthenticationType,'') COLLATE Latin1_General_100_BIN2 NOT IN('SQL','WINDOWS')
  OR (@OperationCode='CREATE_SQL_LOGIN' AND @AuthenticationType<>'SQL')
  OR (@OperationCode='CREATE_WINDOWS_LOGIN' AND @AuthenticationType<>'WINDOWS')
  THROW 51359,'La solicitud debe usar un único tipo de autenticación compatible con su operación: SQL o WINDOWS.',1;
 IF @TargetPrincipal IS NULL OR LEN(LTRIM(RTRIM(@TargetPrincipal)))=0 OR LEN(@TargetPrincipal)>128
  OR DATALENGTH(@TargetPrincipal)<>DATALENGTH(LTRIM(RTRIM(@TargetPrincipal)))
  OR CHARINDEX(NCHAR(9),@TargetPrincipal)>0 OR CHARINDEX(NCHAR(10),@TargetPrincipal)>0 OR CHARINDEX(NCHAR(13),@TargetPrincipal)>0
  THROW 51360,'Indique un nombre de login válido de 1 a 128 caracteres.',1;
 IF @AuthenticationType='SQL'
 BEGIN
  IF CHARINDEX(N'\',@TargetPrincipal)>0
   THROW 51360,'Las cuentas DOMINIO\usuario requieren Windows authentication.',1;
  IF @SecretCiphertext IS NULL OR @SecretNonce IS NULL OR @SecretTag IS NULL OR @SecretKeyId IS NULL
   OR DATALENGTH(@SecretCiphertext)=0 OR DATALENGTH(@SecretNonce)<>12 OR DATALENGTH(@SecretTag)<>16
   THROW 51330,'La creación de un login SQL requiere una contraseña temporal cifrada completa.',1;
  IF @PasswordExpiration=1 AND @PasswordPolicy=0
   THROW 51331,'CHECK_EXPIRATION requiere CHECK_POLICY activo.',1;
  IF @MustChangePassword=1 AND (@PasswordPolicy=0 OR @PasswordExpiration=0)
   THROW 51335,'MUST_CHANGE requiere CHECK_POLICY y CHECK_EXPIRATION activos.',1;
 END
 ELSE
 BEGIN
  DECLARE @Separator int=CHARINDEX(N'\',@TargetPrincipal);
  IF @Separator<=1 OR @Separator>=LEN(@TargetPrincipal)
   OR CHARINDEX(N'\',@TargetPrincipal,@Separator+1)>0 OR CHARINDEX(N'@',@TargetPrincipal)>0
   THROW 51360,'Indique una cuenta Windows existente como DOMINIO\usuario o EQUIPO\usuario.',1;
  DECLARE @Domain nvarchar(256)=LEFT(@TargetPrincipal,@Separator-1),
   @Account nvarchar(256)=SUBSTRING(@TargetPrincipal,@Separator+1,256);
  IF LEN(LTRIM(RTRIM(@Domain)))=0 OR LEN(LTRIM(RTRIM(@Account)))=0
   OR DATALENGTH(@Domain)<>DATALENGTH(LTRIM(RTRIM(@Domain)))
   OR DATALENGTH(@Account)<>DATALENGTH(LTRIM(RTRIM(@Account)))
   THROW 51360,'Indique una cuenta Windows existente como DOMINIO\usuario o EQUIPO\usuario.',1;
  IF @SecretCiphertext IS NOT NULL OR @SecretNonce IS NOT NULL OR @SecretTag IS NOT NULL OR @SecretKeyId IS NOT NULL
   OR ISNULL(@PasswordPolicy,0)=1 OR ISNULL(@PasswordExpiration,0)=1 OR ISNULL(@MustChangePassword,0)=1
   THROW 51361,'Windows authentication no admite contraseñas SQL ni opciones de contraseña SQL.',1;
 END;
END;
GO

CREATE OR ALTER PROCEDURE [access].usp_AccessRequest_Create
 @OperationCode varchar(40),@TargetPrincipal nvarchar(256),@SourcePrincipal nvarchar(256)=NULL,
 @AuthenticationType varchar(20)=NULL,@PermissionAction varchar(10)=NULL,@PermissionName varchar(40)=NULL,
 @ScopeType varchar(20)=NULL,@Securable nvarchar(776)=NULL,@RoleName sysname=NULL,
 @ExternalTicketNumber varchar(40),@Justification nvarchar(1000),
 @Targets [access].AccessRequestTargetType READONLY,@Steps [access].AccessRequestStepType READONLY,
 @SecretCiphertext varbinary(max)=NULL,@SecretNonce varbinary(12)=NULL,@SecretTag varbinary(16)=NULL,
 @SecretKeyId uniqueidentifier=NULL,@PasswordPolicy bit=0,@PasswordExpiration bit=0,@MustChangePassword bit=0,@CopyPlanJson nvarchar(max)=NULL
AS
BEGIN
 SET NOCOUNT ON;SET XACT_ABORT ON;
 -- SqlAccessAdmin.AccessRequestCreate · SqlAccessAdmin.CompositeRequestCreate · SqlAccessAdmin.AccessChangesComposite
 -- SqlAccessAdmin.PermissionCopyNewLogin · SqlAccessAdmin.PermissionCopyByDatabase
 -- SqlAccessAdmin.LoginAuthenticationSelection
 EXEC [access].usp_AccessRequest_AuthenticationValidate @OperationCode,@TargetPrincipal,@AuthenticationType,
  @SecretCiphertext,@SecretNonce,@SecretTag,@SecretKeyId,@PasswordPolicy,@PasswordExpiration,@MustChangePassword;
 IF @OperationCode='CLONE_PERMISSIONS'
 BEGIN
  EXEC [access].usp_AccessRequest_CopyPlanValidate @CopyPlanJson,@Securable,@Targets;
  IF ISNULL(@AuthenticationType,'') NOT IN('SQL','WINDOWS') OR NULLIF(LTRIM(RTRIM(@SourcePrincipal)),N'') IS NULL
     OR LEN(LTRIM(RTRIM(@TargetPrincipal)))>128 OR LEN(LTRIM(RTRIM(@SourcePrincipal)))>128
     OR UPPER(LTRIM(RTRIM(@TargetPrincipal)))=UPPER(LTRIM(RTRIM(@SourcePrincipal)))
   THROW 51342,'Copiar permisos requiere un usuario origen y un login nuevo SQL o Windows distinto.',1;
  IF @Securable IS NULL OR LEN(@Securable)<>64 OR @Securable COLLATE Latin1_General_100_BIN2 LIKE '%[^0-9A-F]%'
   THROW 51343,'La copia requiere la huella de los accesos revisados.',1;
  IF EXISTS(SELECT 1 FROM @Steps) OR @PermissionName IS NOT NULL OR @PermissionAction IS NOT NULL OR @RoleName IS NOT NULL OR @ScopeType IS NOT NULL
   THROW 51344,'El plan de copia no admite cambios manuales.',1;
  DECLARE @ClonePolicy table(Allowed bit,RequiresApproval bit,RiskLevel varchar(10),Reason nvarchar(2000));
  DECLARE @CreateLoginOperation varchar(40)=IIF(@AuthenticationType='WINDOWS','CREATE_WINDOWS_LOGIN','CREATE_SQL_LOGIN');
  INSERT @ClonePolicy EXEC [access].usp_AccessRequest_Preview @CreateLoginOperation,NULL,NULL,NULL,NULL;
  IF NOT EXISTS(SELECT 1 FROM @ClonePolicy WHERE Allowed=1) THROW 51345,'La política bloquea crear el tipo de login seleccionado.',1;
  DELETE FROM @ClonePolicy;
  INSERT @ClonePolicy EXEC [access].usp_AccessRequest_Preview 'CREATE_DB_USER',NULL,NULL,NULL,NULL;
  IF NOT EXISTS(SELECT 1 FROM @ClonePolicy WHERE Allowed=1) THROW 51345,'La política bloquea crear usuarios de base.',1;
 END;
 IF @OperationCode<>'CLONE_PERMISSIONS' AND @CopyPlanJson IS NOT NULL THROW 51357,'El detalle por base se reserva a copiar permisos.',1;
 SET @ExternalTicketNumber=UPPER(LTRIM(RTRIM(@ExternalTicketNumber)));
 IF @ExternalTicketNumber IS NULL OR @ExternalTicketNumber NOT LIKE 'TIC-RF-%'
    OR LEN(@ExternalTicketNumber)<=7 OR SUBSTRING(@ExternalTicketNumber,8,40) LIKE '%[^0-9]%'
  THROW 51320,'El ticket externo debe usar TIC-RF- seguido únicamente por dígitos.',1;
 IF NOT EXISTS(SELECT 1 FROM @Targets) THROW 51310,'Debe seleccionar destinos.',1;
 IF (SELECT COUNT(DISTINCT ServerId) FROM @Targets)<>1 THROW 51314,'Cada solicitud debe pertenecer a un único servidor.',1;
 IF @Justification IS NULL OR LEN(LTRIM(RTRIM(@Justification)))<10 THROW 51311,'La justificación debe contener al menos 10 caracteres.',1;
 IF @TargetPrincipal IS NULL OR LEN(LTRIM(RTRIM(@TargetPrincipal)))=0 THROW 51337,'Debe indicar el principal destino.',1;
 IF (@OperationCode='CREATE_SQL_LOGIN' OR (@OperationCode='CLONE_PERMISSIONS' AND @AuthenticationType='SQL')) AND (@SecretCiphertext IS NULL OR @SecretNonce IS NULL OR @SecretTag IS NULL OR @SecretKeyId IS NULL)
  THROW 51330,'La creación de un login SQL requiere una contraseña temporal cifrada.',1;
 IF (@OperationCode='CREATE_SQL_LOGIN' OR (@OperationCode='CLONE_PERMISSIONS' AND @AuthenticationType='SQL')) AND @PasswordExpiration=1 AND @PasswordPolicy=0
  THROW 51331,'CHECK_EXPIRATION requiere CHECK_POLICY activo.',1;
 IF (@OperationCode='CREATE_SQL_LOGIN' OR (@OperationCode='CLONE_PERMISSIONS' AND @AuthenticationType='SQL')) AND @MustChangePassword=1 AND (@PasswordPolicy=0 OR @PasswordExpiration=0)
  THROW 51335,'MUST_CHANGE requiere CHECK_POLICY y CHECK_EXPIRATION activos.',1;

 IF EXISTS(SELECT 1 FROM @Steps)
 BEGIN
  IF @OperationCode NOT IN('CREATE_SQL_LOGIN','CREATE_WINDOWS_LOGIN','MODIFY_LOGIN','ADD_ROLE_MEMBER','REMOVE_ROLE_MEMBER','PERMISSION_CHANGE')
   THROW 51332,'Esta operación no admite un plan interno.',1;
  IF @OperationCode IN('CREATE_SQL_LOGIN','CREATE_WINDOWS_LOGIN')
  BEGIN
   IF (SELECT TOP(1) OperationCode FROM @Steps ORDER BY StepOrder)<>'CREATE_DB_USER'
    THROW 51333,'El primer paso del acceso inicial debe crear el usuario de base.',1;
   IF EXISTS(SELECT 1 FROM @Steps WHERE OperationCode NOT IN('CREATE_DB_USER','ADD_ROLE_MEMBER','REMOVE_ROLE_MEMBER','PERMISSION_CHANGE'))
    THROW 51338,'El acceso inicial contiene una operación interna no permitida.',1;
  END
  ELSE
  BEGIN
   IF (SELECT COUNT(*) FROM @Targets)<>1
    THROW 51339,'Una modificación compuesta debe trabajar sobre una sola base de datos.',1;
   IF EXISTS(SELECT 1 FROM @Steps WHERE OperationCode NOT IN('ADD_ROLE_MEMBER','REMOVE_ROLE_MEMBER','PERMISSION_CHANGE'))
    THROW 51338,'La modificación compuesta solo admite roles y permisos.',1;
  END;
  IF EXISTS(SELECT 1 FROM @Steps WHERE StepOrder<=0)
     OR (SELECT MIN(StepOrder) FROM @Steps)<>1
     OR (SELECT MAX(StepOrder) FROM @Steps)<>(SELECT COUNT(*) FROM @Steps)
   THROW 51340,'Los cambios internos deben tener un orden consecutivo desde 1.',1;
 END;
 IF (@OperationCode='PERMISSION_CHANGE' AND @ScopeType='OBJECT')
    OR EXISTS(SELECT 1 FROM @Steps WHERE OperationCode='PERMISSION_CHANGE' AND ScopeType='OBJECT')
 BEGIN
  IF (SELECT COUNT(*) FROM @Targets)<>1 THROW 51339,'Los permisos por objeto requieren una sola base de datos.',1;
 END;

 DECLARE @Check table(Allowed bit,RequiresApproval bit,RiskLevel varchar(10),Reason nvarchar(2000));
 INSERT @Check EXEC [access].usp_AccessRequest_Preview @OperationCode,@PermissionAction,@PermissionName,@ScopeType,@RoleName;
 IF NOT EXISTS(SELECT 1 FROM @Check WHERE Allowed=1) THROW 51312,'Solicitud rechazada por la política central.',1;
 DECLARE @SO varchar(40),@SA varchar(10),@SP varchar(40),@SS varchar(20),@SR sysname;
 DECLARE StepPolicy CURSOR LOCAL FAST_FORWARD FOR SELECT OperationCode,PermissionAction,PermissionName,ScopeType,RoleName FROM @Steps ORDER BY StepOrder;
 OPEN StepPolicy;FETCH NEXT FROM StepPolicy INTO @SO,@SA,@SP,@SS,@SR;
 WHILE @@FETCH_STATUS=0
 BEGIN
  DELETE FROM @Check;INSERT @Check EXEC [access].usp_AccessRequest_Preview @SO,@SA,@SP,@SS,@SR;
  IF NOT EXISTS(SELECT 1 FROM @Check WHERE Allowed=1)
  BEGIN CLOSE StepPolicy;DEALLOCATE StepPolicy;THROW 51334,'Un cambio interno fue rechazado por la política central.',1;END;
  FETCH NEXT FROM StepPolicy INTO @SO,@SA,@SP,@SS,@SR;
 END;
 CLOSE StepPolicy;DEALLOCATE StepPolicy;

 BEGIN TRAN;
 DECLARE @LockResult int;EXEC @LockResult=sys.sp_getapplock @Resource=N'SqlAccessAdmin.AccessRequestCreate',@LockMode='Exclusive',@LockOwner='Transaction',@LockTimeout=10000;
 IF @LockResult<0 THROW 51317,'No fue posible bloquear el registro de solicitudes.',1;
 IF @OperationCode IN('CREATE_SQL_LOGIN','CREATE_WINDOWS_LOGIN','CLONE_PERMISSIONS') AND EXISTS
 (
  SELECT 1 FROM [access].AccessRequest r
  JOIN [access].AccessRequestTarget t ON t.RequestId=r.RequestId
  JOIN @Targets requested ON requested.ServerId=t.ServerId
  WHERE r.Status IN('PENDING','APPROVED') AND r.OperationCode IN('CREATE_SQL_LOGIN','CREATE_WINDOWS_LOGIN','CLONE_PERMISSIONS')
   AND UPPER(LTRIM(RTRIM(r.TargetPrincipal)))=UPPER(LTRIM(RTRIM(@TargetPrincipal)))
 )
 BEGIN ROLLBACK;THROW 51346,'Ya existe una solicitud activa para crear el mismo login en este servidor.',1;END;
 DECLARE @ExistingRequestId bigint;
 SELECT TOP(1) @ExistingRequestId=r.RequestId FROM [access].AccessRequest r WITH(UPDLOCK,HOLDLOCK)
 WHERE r.Status IN('PENDING','APPROVED') AND r.OperationCode=@OperationCode
  AND UPPER(LTRIM(RTRIM(r.TargetPrincipal)))=UPPER(LTRIM(RTRIM(@TargetPrincipal)))
  AND NOT EXISTS(SELECT ServerId,DatabaseName FROM @Targets EXCEPT SELECT ServerId,DatabaseName FROM [access].AccessRequestTarget WHERE RequestId=r.RequestId)
  AND NOT EXISTS(SELECT ServerId,DatabaseName FROM [access].AccessRequestTarget WHERE RequestId=r.RequestId EXCEPT SELECT ServerId,DatabaseName FROM @Targets)
  AND (@OperationCode IN('CREATE_SQL_LOGIN','CREATE_WINDOWS_LOGIN') OR
  (
   ISNULL(r.SourcePrincipal,N'')=ISNULL(@SourcePrincipal,N'') AND ISNULL(r.AuthenticationType,'')=ISNULL(@AuthenticationType,'')
   AND ISNULL(r.PermissionAction,'')=ISNULL(@PermissionAction,'') AND ISNULL(r.PermissionName,'')=ISNULL(@PermissionName,'')
   AND ISNULL(r.ScopeType,'')=ISNULL(@ScopeType,'') AND ISNULL(r.Securable,N'')=ISNULL(@Securable,N'') AND ISNULL(r.RoleName,N'')=ISNULL(@RoleName,N'')
   AND NOT EXISTS
   (
    SELECT StepOrder,OperationCode,PermissionAction,PermissionName,ScopeType,Securable,RoleName FROM @Steps
    EXCEPT
    SELECT StepOrder,OperationCode,PermissionAction,PermissionName,ScopeType,Securable,RoleName FROM [access].AccessRequestStep WHERE RequestId=r.RequestId
   )
   AND NOT EXISTS
   (
    SELECT StepOrder,OperationCode,PermissionAction,PermissionName,ScopeType,Securable,RoleName FROM [access].AccessRequestStep WHERE RequestId=r.RequestId
    EXCEPT
    SELECT StepOrder,OperationCode,PermissionAction,PermissionName,ScopeType,Securable,RoleName FROM @Steps
   )
  ))
 ORDER BY r.RequestId DESC;
 IF @ExistingRequestId IS NOT NULL
 BEGIN
  ROLLBACK;
  DECLARE @DuplicateMessage nvarchar(2048)=CONCAT(N'Ya existe la solicitud activa #',@ExistingRequestId,N' con el mismo plan de cambios y destinos.');
  THROW 51316,@DuplicateMessage,1;
 END;
 INSERT [access].AccessRequest(OperationCode,TargetPrincipal,SourcePrincipal,AuthenticationType,PermissionAction,PermissionName,ScopeType,Securable,RoleName,ExternalTicketNumber,Justification,
  SecretCiphertext,SecretNonce,SecretTag,SecretKeyId,PasswordPolicy,PasswordExpiration,MustChangePassword,CopyPlanJson)
 VALUES(@OperationCode,@TargetPrincipal,@SourcePrincipal,@AuthenticationType,@PermissionAction,@PermissionName,@ScopeType,@Securable,@RoleName,@ExternalTicketNumber,@Justification,
  @SecretCiphertext,@SecretNonce,@SecretTag,@SecretKeyId,@PasswordPolicy,@PasswordExpiration,@MustChangePassword,@CopyPlanJson);
 DECLARE @Id bigint=SCOPE_IDENTITY();
 INSERT [access].AccessRequestTarget(RequestId,ServerId,DatabaseName) SELECT @Id,ServerId,DatabaseName FROM @Targets;
 INSERT [access].AccessRequestStep(RequestId,StepOrder,OperationCode,PermissionAction,PermissionName,ScopeType,Securable,RoleName)
  SELECT @Id,StepOrder,OperationCode,PermissionAction,PermissionName,ScopeType,Securable,RoleName FROM @Steps;
 COMMIT;
 DECLARE @ChangeCount int=1+(SELECT COUNT(*) FROM @Steps);
 IF @OperationCode='CLONE_PERMISSIONS'
  SELECT @ChangeCount=1+(SELECT COUNT(*) FROM OPENJSON(@CopyPlanJson,'$.Databases'))+COUNT(*)
  FROM OPENJSON(@CopyPlanJson,'$.Databases') WITH(Accesses nvarchar(max) '$.Accesses' AS JSON) d
  CROSS APPLY OPENJSON(d.Accesses) WITH(CanCopy bit '$.CanCopy') a WHERE a.CanCopy=1;
 DECLARE @AuditDetail nvarchar(2000)=CONCAT(N'Solicitud #',@Id,N' · ',@ExternalTicketNumber,N' · ',@ChangeCount,N' cambios · Autenticación=',COALESCE(@AuthenticationType,'N/A'),N' · ',
  N'CHECK_POLICY=',IIF(@PasswordPolicy=1,N'ON',N'OFF'),N' · CHECK_EXPIRATION=',IIF(@PasswordExpiration=1,N'ON',N'OFF'),N' · MUST_CHANGE=',IIF(@MustChangePassword=1,N'ON',N'OFF'));
 EXEC [access].usp_Audit_Write N'Solicitudes',N'Crear',NULL,NULL,1,@AuditDetail;
 SELECT @Id RequestId,'PENDING' [Status];
END;
GO



CREATE OR ALTER PROCEDURE [access].usp_AccessRequest_Approve
 @RequestId bigint,@Approve bit,@Comment nvarchar(1000)
AS
BEGIN
 SET NOCOUNT ON;SET XACT_ABORT ON;
 -- SqlAccessAdmin.AccessRequestApprove · SqlAccessAdmin.SelfConfirmation · SqlAccessAdmin.AccessChangesComposite
 IF IS_SRVROLEMEMBER(N'sysadmin')<>1 AND NOT EXISTS
 (SELECT 1 FROM [access].AuthorizedPrincipal WHERE Principal=ORIGINAL_LOGIN() AND Active=1 AND RoleName IN('Administrator','Operator'))
  THROW 51301,'Se requiere un usuario Administrator u Operator activo.',1;
 -- SqlAccessAdmin.LoginAuthenticationSelection
 IF @Approve=1
 BEGIN
  DECLARE @AuthOperation varchar(40),@AuthTarget nvarchar(256),@AuthType varchar(20),
   @AuthCipher varbinary(max),@AuthNonce varbinary(12),@AuthTag varbinary(16),@AuthKey uniqueidentifier,
   @AuthPolicy bit,@AuthExpiration bit,@AuthMustChange bit;
  SELECT @AuthOperation=OperationCode,@AuthTarget=TargetPrincipal,@AuthType=AuthenticationType,
   @AuthCipher=SecretCiphertext,@AuthNonce=SecretNonce,@AuthTag=SecretTag,@AuthKey=SecretKeyId,
   @AuthPolicy=PasswordPolicy,@AuthExpiration=PasswordExpiration,@AuthMustChange=MustChangePassword
  FROM [access].AccessRequest WHERE RequestId=@RequestId;
  EXEC [access].usp_AccessRequest_AuthenticationValidate @AuthOperation,@AuthTarget,@AuthType,
   @AuthCipher,@AuthNonce,@AuthTag,@AuthKey,@AuthPolicy,@AuthExpiration,@AuthMustChange;
 END;
 IF @Approve=1 AND EXISTS(SELECT 1 FROM [access].AccessRequest WHERE RequestId=@RequestId AND OperationCode='CLONE_PERMISSIONS')
 BEGIN
  DECLARE @CopyPlan nvarchar(max),@CopyFingerprint nvarchar(776),@CopyTargets [access].AccessRequestTargetType;
  SELECT @CopyPlan=CopyPlanJson,@CopyFingerprint=Securable FROM [access].AccessRequest WHERE RequestId=@RequestId;
  INSERT @CopyTargets SELECT ServerId,DatabaseName FROM [access].AccessRequestTarget WHERE RequestId=@RequestId;
  EXEC [access].usp_AccessRequest_CopyPlanValidate @CopyPlan,@CopyFingerprint,@CopyTargets;
 END;
 BEGIN TRAN;
 DECLARE @LockResult int;EXEC @LockResult=sys.sp_getapplock @Resource=N'SqlAccessAdmin.AccessRequestApprove',@LockMode='Exclusive',@LockOwner='Transaction',@LockTimeout=10000;
 IF @LockResult<0 THROW 51319,'No fue posible bloquear la confirmación de solicitudes.',1;
 IF @Approve=1 AND EXISTS
 (
  SELECT 1 FROM [access].AccessRequest c JOIN [access].AccessRequest a
   ON a.RequestId<>c.RequestId AND a.Status='APPROVED' AND a.OperationCode=c.OperationCode
   AND UPPER(LTRIM(RTRIM(a.TargetPrincipal)))=UPPER(LTRIM(RTRIM(c.TargetPrincipal)))
  WHERE c.RequestId=@RequestId AND c.Status='PENDING'
   AND NOT EXISTS(SELECT ServerId,DatabaseName FROM [access].AccessRequestTarget WHERE RequestId=c.RequestId EXCEPT SELECT ServerId,DatabaseName FROM [access].AccessRequestTarget WHERE RequestId=a.RequestId)
   AND NOT EXISTS(SELECT ServerId,DatabaseName FROM [access].AccessRequestTarget WHERE RequestId=a.RequestId EXCEPT SELECT ServerId,DatabaseName FROM [access].AccessRequestTarget WHERE RequestId=c.RequestId)
   AND (c.OperationCode IN('CREATE_SQL_LOGIN','CREATE_WINDOWS_LOGIN') OR
   (
    ISNULL(a.SourcePrincipal,N'')=ISNULL(c.SourcePrincipal,N'') AND ISNULL(a.AuthenticationType,'')=ISNULL(c.AuthenticationType,'')
    AND ISNULL(a.PermissionAction,'')=ISNULL(c.PermissionAction,'') AND ISNULL(a.PermissionName,'')=ISNULL(c.PermissionName,'')
    AND ISNULL(a.ScopeType,'')=ISNULL(c.ScopeType,'') AND ISNULL(a.Securable,N'')=ISNULL(c.Securable,N'') AND ISNULL(a.RoleName,N'')=ISNULL(c.RoleName,N'')
    AND NOT EXISTS
    (
     SELECT StepOrder,OperationCode,PermissionAction,PermissionName,ScopeType,Securable,RoleName FROM [access].AccessRequestStep WHERE RequestId=c.RequestId
     EXCEPT
     SELECT StepOrder,OperationCode,PermissionAction,PermissionName,ScopeType,Securable,RoleName FROM [access].AccessRequestStep WHERE RequestId=a.RequestId
    )
    AND NOT EXISTS
    (
     SELECT StepOrder,OperationCode,PermissionAction,PermissionName,ScopeType,Securable,RoleName FROM [access].AccessRequestStep WHERE RequestId=a.RequestId
     EXCEPT
     SELECT StepOrder,OperationCode,PermissionAction,PermissionName,ScopeType,Securable,RoleName FROM [access].AccessRequestStep WHERE RequestId=c.RequestId
    )
   ))
 )
 BEGIN ROLLBACK;THROW 51318,'Ya existe otra solicitud equivalente confirmada. Rechace este duplicado.',1;END;
 UPDATE [access].AccessRequest SET Status=IIF(@Approve=1,'APPROVED','REJECTED'),ApprovedBy=ORIGINAL_LOGIN(),ApprovedAt=SYSUTCDATETIME(),ApprovalComment=@Comment
 WHERE RequestId=@RequestId AND Status='PENDING';
 IF @@ROWCOUNT=0 BEGIN ROLLBACK;THROW 51314,'La solicitud no está pendiente.',1;END;
 COMMIT;
 DECLARE @Action nvarchar(50)=IIF(@Approve=1,N'Confirmar',N'Rechazar');
 DECLARE @AuditDetail nvarchar(max)=CONCAT(N'Solicitud #',@RequestId,N' · doble check del operador · ',@Comment);
 EXEC [access].usp_Audit_Write N'Solicitudes',@Action,NULL,NULL,1,@AuditDetail;
END;
GO

GRANT EXECUTE ON [access].usp_AccessRequest_Create TO [SqlAccessAdmin_Users];
GRANT EXECUTE ON [access].usp_AccessRequest_Approve TO [SqlAccessAdmin_Users];
GO
PRINT N'Autenticación SQL o Windows instalada para Crear usuario y Copiar permisos. Reinicie la aplicación.';
GO

