USE [adminDB];
GO
SET NOCOUNT ON;
SET XACT_ABORT ON;
GO
/*
 Aplicar manualmente después de 24. No activa excepciones ni cambia accesos.
 La autorización especial conserva los bloqueos originales y se revoca al bloquear
 nuevamente el elemento. Reconocimiento + nombre escrito NO equivale a MFA.
*/
IF OBJECT_ID(N'[access].usp_AccessRequest_AuthenticationValidate',N'P') IS NULL
 OR OBJECT_ID(N'[access].usp_Policy_RoleUpsert',N'P') IS NULL
 THROW 51370,'Ejecute primero los scripts 17 y 24.',1;
GO
IF OBJECT_ID(N'[access].SecurityPolicyOverride',N'U') IS NULL
CREATE TABLE [access].SecurityPolicyOverride
(
 Category varchar(30) NOT NULL,DeniedValue nvarchar(256) NOT NULL,ScopeType varchar(20) NOT NULL,
 Active bit NOT NULL,Reason nvarchar(1000) NOT NULL,ApprovedBy nvarchar(256) NOT NULL,ApprovedAt datetime2(3) NOT NULL,
 CONSTRAINT PK_SecurityPolicyOverride PRIMARY KEY(Category,DeniedValue,ScopeType),
 CONSTRAINT CK_PolicyOverride_Category CHECK
 ((Category='DATABASE_ROLE' AND ScopeType='' AND LEN(DeniedValue) BETWEEN 1 AND 128
   AND LOWER(DeniedValue) NOT IN('public','sysadmin','securityadmin','serveradmin','setupadmin','processadmin','diskadmin','bulkadmin'))
  OR (Category='PERMISSION' AND ScopeType IN('DATABASE','OBJECT')
      AND DeniedValue IN('SELECT','INSERT','UPDATE','DELETE','EXECUTE'))),
 CONSTRAINT CK_PolicyOverride_Reason CHECK(LEN(LTRIM(RTRIM(Reason))) BETWEEN 20 AND 1000)
);
GO
CREATE OR ALTER PROCEDURE [access].usp_Policy_RoleList
AS
BEGIN
 SET NOCOUNT ON;
 SELECT r.RoleName,r.RoleKind,r.Enabled,r.ApprovedBy,r.ApprovedAt,ISNULL(r.Notes,N'') Notes,
  CAST(IIF(o.Active=1,1,0) AS bit) SpecialActivationApproved,ISNULL(o.Reason,N'') SpecialActivationReason
 FROM [access].SecurityPolicyRole r
 LEFT JOIN [access].SecurityPolicyOverride o ON o.Category='DATABASE_ROLE' AND o.DeniedValue=r.RoleName AND o.ScopeType='' AND o.Active=1
 ORDER BY r.RoleKind,r.RoleName;
END;
GO
CREATE OR ALTER PROCEDURE [access].usp_Policy_PermissionList
AS
BEGIN
 SET NOCOUNT ON;
 SELECT p.PermissionName,p.ScopeType,p.AllowGrant,p.AllowDeny,p.AllowRevoke,p.Enabled,p.ApprovedBy,p.ApprovedAt,
  CAST(IIF(o.Active=1,1,0) AS bit) SpecialActivationApproved,ISNULL(o.Reason,N'') SpecialActivationReason
 FROM [access].SecurityPolicyPermission p
 LEFT JOIN [access].SecurityPolicyOverride o ON o.Category='PERMISSION' AND o.DeniedValue=p.PermissionName AND o.ScopeType=p.ScopeType AND o.Active=1
 ORDER BY p.PermissionName,p.ScopeType;
END;
GO
CREATE OR ALTER PROCEDURE [access].usp_Policy_SpecialActivate
 @Category varchar(30),@Value nvarchar(256),@ScopeType varchar(20),@Reason nvarchar(1000),
 @ConfirmedName nvarchar(256),@RiskAcknowledged bit
AS
BEGIN
 SET NOCOUNT ON;SET XACT_ABORT ON;
 IF ISNULL(IS_SRVROLEMEMBER(N'sysadmin'),0)<>1 AND NOT EXISTS
 (SELECT 1 FROM [access].AuthorizedPrincipal WHERE Principal=ORIGINAL_LOGIN() AND Active=1 AND RoleName='Administrator')
  THROW 51301,'Se requiere Administrator.',1;
 IF ISNULL(@RiskAcknowledged,0)<>1 OR @Value IS NULL OR @ConfirmedName IS NULL
  OR @Value COLLATE Latin1_General_100_BIN2<>@ConfirmedName COLLATE Latin1_General_100_BIN2
  OR DATALENGTH(@Value)<>DATALENGTH(@ConfirmedName)
  THROW 51371,'Reconozca el riesgo y escriba el nombre exacto.',1;
 SET @Reason=LTRIM(RTRIM(@Reason));
 IF @Reason IS NULL OR LEN(@Reason)<20 OR LEN(@Reason)>1000
  THROW 51371,'El motivo debe contener entre 20 y 1000 caracteres.',1;
 IF @Category IS NULL OR @ScopeType IS NULL OR @Category NOT IN('DATABASE_ROLE','PERMISSION')
  THROW 51371,'Categoría o alcance no permitido.',1;
 IF @Category='DATABASE_ROLE' AND
  (@ScopeType<>'' OR LEN(@Value) NOT BETWEEN 1 AND 128
   OR LOWER(@Value) IN('public','sysadmin','securityadmin','serveradmin','setupadmin','processadmin','diskadmin','bulkadmin'))
  THROW 51371,'Este rol no admite activación especial.',1;
 IF @Category='PERMISSION' AND
  (@ScopeType NOT IN('DATABASE','OBJECT') OR @Value NOT IN('SELECT','INSERT','UPDATE','DELETE','EXECUTE'))
  THROW 51371,'Este permiso o alcance no admite activación especial.',1;
 BEGIN TRY
  BEGIN TRAN;
 DECLARE @LockResult int;
 EXEC @LockResult=sys.sp_getapplock @Resource=N'SqlAccessAdmin.PolicyChanges',@LockMode='Exclusive',@LockOwner='Transaction',@LockTimeout=10000;
 IF @LockResult<0 THROW 51372,'No fue posible bloquear la política. Reintente.',1;
  IF @Category='DATABASE_ROLE'
  BEGIN
   IF NOT EXISTS(SELECT 1 FROM [access].SecurityPolicyRole WHERE RoleName=@Value)
    THROW 51371,'El rol debe existir en el catálogo.',1;
   IF EXISTS(SELECT 1 FROM [access].SecurityDenyList WHERE Active=1 AND Category='SERVER_ROLE' AND DeniedValue=@Value)
    THROW 51371,'Los roles de servidor no admiten activación especial.',1;
   IF LOWER(@Value) NOT IN('db_owner','db_securityadmin','db_accessadmin','db_ddladmin','db_backupoperator')
    AND NOT EXISTS(SELECT 1 FROM [access].SecurityDenyList WHERE Active=1 AND Category='DATABASE_ROLE' AND DeniedValue=@Value)
    THROW 51371,'Este rol no necesita una activación especial.',1;
   UPDATE [access].SecurityPolicyRole SET Enabled=1,ApprovedBy=ORIGINAL_LOGIN(),ApprovedAt=SYSUTCDATETIME() WHERE RoleName=@Value;
  END
  ELSE
  BEGIN
   IF NOT EXISTS(SELECT 1 FROM [access].SecurityDenyList WHERE Active=1 AND Category='PERMISSION' AND DeniedValue=@Value)
    THROW 51371,'Este permiso no necesita una activación especial.',1;
   MERGE [access].SecurityPolicyPermission AS t
   USING(SELECT CONVERT(varchar(40),UPPER(@Value)) PermissionName,@ScopeType ScopeType) AS s
    ON t.PermissionName=s.PermissionName AND t.ScopeType=s.ScopeType
   WHEN MATCHED THEN UPDATE SET Enabled=1,AllowDeny=0,
    AllowGrant=IIF(t.AllowGrant=0 AND t.AllowRevoke=0,1,t.AllowGrant),
    AllowRevoke=IIF(t.AllowGrant=0 AND t.AllowRevoke=0,1,t.AllowRevoke),
    ApprovedBy=ORIGINAL_LOGIN(),ApprovedAt=SYSUTCDATETIME()
   WHEN NOT MATCHED THEN INSERT(PermissionName,ScopeType,AllowGrant,AllowDeny,AllowRevoke,Enabled)
    VALUES(s.PermissionName,s.ScopeType,1,0,1,1);
  END;
  MERGE [access].SecurityPolicyOverride AS t
  USING(SELECT @Category Category,@Value DeniedValue,@ScopeType ScopeType) AS s
   ON t.Category=s.Category AND t.DeniedValue=s.DeniedValue AND t.ScopeType=s.ScopeType
  WHEN MATCHED THEN UPDATE SET Active=1,Reason=@Reason,ApprovedBy=ORIGINAL_LOGIN(),ApprovedAt=SYSUTCDATETIME()
  WHEN NOT MATCHED THEN INSERT(Category,DeniedValue,ScopeType,Active,Reason,ApprovedBy,ApprovedAt)
   VALUES(s.Category,s.DeniedValue,s.ScopeType,1,@Reason,ORIGINAL_LOGIN(),SYSUTCDATETIME());
  DECLARE @Detail nvarchar(2000)=CONCAT(N'Categoría=',@Category,N'; Valor=',@Value,N'; Alcance=',@ScopeType,
   N'; Reconocimiento=Sí; Nombre confirmado=',@ConfirmedName,N'; Motivo=',@Reason);
  EXEC [access].usp_Audit_Write N'Política de seguridad',N'Autorizar activación especial',NULL,NULL,1,@Detail;
  COMMIT;
 END TRY
 BEGIN CATCH
  IF XACT_STATE()<>0 ROLLBACK;
  THROW;
 END CATCH;
END;
GO
CREATE OR ALTER PROCEDURE [access].usp_Policy_RoleUpsert
 @RoleName sysname,@RoleKind varchar(10),@Enabled bit,@Notes nvarchar(500)=NULL
AS
BEGIN
 SET NOCOUNT ON;SET XACT_ABORT ON;
 IF ISNULL(IS_SRVROLEMEMBER(N'sysadmin'),0)<>1 AND NOT EXISTS
 (SELECT 1 FROM [access].AuthorizedPrincipal WHERE Principal=ORIGINAL_LOGIN() AND Active=1 AND RoleName='Administrator')
  THROW 51301,'Se requiere Administrator.',1;
 SET @RoleName=LTRIM(RTRIM(@RoleName));SET @RoleKind=UPPER(@RoleKind);
 IF NULLIF(@RoleName,N'') IS NULL OR @RoleKind IS NULL OR @RoleKind NOT IN('FIXED','CUSTOM') OR @Enabled IS NULL
  THROW 51303,'Nombre, tipo o estado de rol no válido.',1;
 IF LOWER(@RoleName) IN('public','sysadmin','securityadmin','serveradmin','setupadmin','processadmin','diskadmin','bulkadmin')
  THROW 51308,'Este rol de servidor o de sistema no puede administrarse.',1;
 BEGIN TRY
  BEGIN TRAN;
 DECLARE @LockResult int;
 EXEC @LockResult=sys.sp_getapplock @Resource=N'SqlAccessAdmin.PolicyChanges',@LockMode='Exclusive',@LockOwner='Transaction',@LockTimeout=10000;
 IF @LockResult<0 THROW 51372,'No fue posible bloquear la política. Reintente.',1;
  IF @Enabled=1 AND
   (EXISTS(SELECT 1 FROM [access].SecurityDenyList WHERE Active=1 AND Category='SERVER_ROLE' AND DeniedValue=@RoleName)
    OR ((LOWER(@RoleName) IN('db_owner','db_securityadmin','db_accessadmin','db_ddladmin','db_backupoperator')
      OR EXISTS(SELECT 1 FROM [access].SecurityDenyList WHERE Active=1 AND Category='DATABASE_ROLE' AND DeniedValue=@RoleName))
     AND NOT EXISTS(SELECT 1 FROM [access].SecurityPolicyOverride WHERE Category='DATABASE_ROLE' AND DeniedValue=@RoleName AND ScopeType='' AND Active=1)))
   THROW 51309,'Este rol requiere una activación especial.',1;
  IF @Enabled=0 UPDATE [access].SecurityPolicyOverride SET Active=0 WHERE Category='DATABASE_ROLE' AND DeniedValue=@RoleName AND ScopeType='';
  MERGE [access].SecurityPolicyRole AS t USING(SELECT @RoleName RoleName) AS s ON t.RoleName=s.RoleName
  WHEN MATCHED THEN UPDATE SET RoleKind=@RoleKind,Enabled=@Enabled,ApprovedBy=ORIGINAL_LOGIN(),ApprovedAt=SYSUTCDATETIME(),Notes=@Notes
  WHEN NOT MATCHED THEN INSERT(RoleName,RoleKind,Enabled,ApprovedBy,ApprovedAt,Notes)
   VALUES(s.RoleName,@RoleKind,@Enabled,ORIGINAL_LOGIN(),SYSUTCDATETIME(),@Notes);
  DECLARE @Detail nvarchar(2000)=CONCAT(N'Rol=',@RoleName,N'; Estado=',IIF(@Enabled=1,N'Permitido',N'Bloqueado; autorización especial retirada'));
  EXEC [access].usp_Audit_Write N'Política de seguridad',N'Actualizar disponibilidad de rol',NULL,NULL,1,@Detail;
  COMMIT;
 END TRY
 BEGIN CATCH
  IF XACT_STATE()<>0 ROLLBACK;
  THROW;
 END CATCH;
END;
GO
CREATE OR ALTER PROCEDURE [access].usp_Policy_PermissionUpsert
 @PermissionName varchar(40),@ScopeType varchar(20),@AllowGrant bit,@AllowDeny bit,@AllowRevoke bit,@Enabled bit
AS
BEGIN
 SET NOCOUNT ON;SET XACT_ABORT ON;
 IF ISNULL(IS_SRVROLEMEMBER(N'sysadmin'),0)<>1 AND NOT EXISTS
 (SELECT 1 FROM [access].AuthorizedPrincipal WHERE Principal=ORIGINAL_LOGIN() AND Active=1 AND RoleName='Administrator')
  THROW 51301,'Se requiere Administrator.',1;
 SET @PermissionName=UPPER(@PermissionName);SET @ScopeType=UPPER(@ScopeType);
 IF @PermissionName IS NULL OR @PermissionName NOT IN('SELECT','INSERT','UPDATE','DELETE','EXECUTE')
  THROW 51302,'Permiso fuera del catálogo admitido.',1;
 IF @ScopeType IS NULL OR @ScopeType NOT IN('DATABASE','OBJECT') THROW 51303,'Ámbito no permitido.',1;
 IF @Enabled IS NULL OR @AllowGrant IS NULL OR @AllowRevoke IS NULL OR ISNULL(@AllowDeny,1)<>0
  OR (@Enabled=1 AND @AllowGrant=0 AND @AllowRevoke=0)
  THROW 51306,'Acciones o estado no permitidos.',1;
 BEGIN TRY
  BEGIN TRAN;
 DECLARE @LockResult int;
 EXEC @LockResult=sys.sp_getapplock @Resource=N'SqlAccessAdmin.PolicyChanges',@LockMode='Exclusive',@LockOwner='Transaction',@LockTimeout=10000;
 IF @LockResult<0 THROW 51372,'No fue posible bloquear la política. Reintente.',1;
  IF @Enabled=1 AND EXISTS(SELECT 1 FROM [access].SecurityDenyList WHERE Active=1 AND Category='PERMISSION' AND DeniedValue=@PermissionName)
   AND NOT EXISTS(SELECT 1 FROM [access].SecurityPolicyOverride WHERE Category='PERMISSION' AND DeniedValue=@PermissionName AND ScopeType=@ScopeType AND Active=1)
   THROW 51309,'Este permiso requiere una activación especial.',1;
  IF @Enabled=0 UPDATE [access].SecurityPolicyOverride SET Active=0 WHERE Category='PERMISSION' AND DeniedValue=@PermissionName AND ScopeType=@ScopeType;
  MERGE [access].SecurityPolicyPermission AS t USING(SELECT @PermissionName PermissionName,@ScopeType ScopeType) AS s
   ON t.PermissionName=s.PermissionName AND t.ScopeType=s.ScopeType
  WHEN MATCHED THEN UPDATE SET AllowGrant=@AllowGrant,AllowDeny=0,AllowRevoke=@AllowRevoke,Enabled=@Enabled,ApprovedBy=ORIGINAL_LOGIN(),ApprovedAt=SYSUTCDATETIME()
  WHEN NOT MATCHED THEN INSERT(PermissionName,ScopeType,AllowGrant,AllowDeny,AllowRevoke,Enabled)
   VALUES(s.PermissionName,s.ScopeType,@AllowGrant,0,@AllowRevoke,@Enabled);
  DECLARE @Detail nvarchar(2000)=CONCAT(@PermissionName,N'/',@ScopeType,N'; Estado=',IIF(@Enabled=1,N'Permitido',N'Bloqueado; autorización especial retirada'));
  EXEC [access].usp_Audit_Write N'Política de seguridad',N'Actualizar permiso',NULL,NULL,1,@Detail;
  COMMIT;
 END TRY
 BEGIN CATCH
  IF XACT_STATE()<>0 ROLLBACK;
  THROW;
 END CATCH;
END;
GO
CREATE OR ALTER PROCEDURE [access].usp_Policy_DenyUpsert
 @Category varchar(30),@DeniedValue nvarchar(256),@Reason nvarchar(1000),@Active bit=1
AS
BEGIN
 SET NOCOUNT ON;SET XACT_ABORT ON;
 IF ISNULL(IS_SRVROLEMEMBER(N'sysadmin'),0)<>1 AND NOT EXISTS
 (SELECT 1 FROM [access].AuthorizedPrincipal WHERE Principal=ORIGINAL_LOGIN() AND Active=1 AND RoleName='Administrator')
  THROW 51301,'Se requiere Administrator.',1;
 SET @Category=UPPER(@Category);SET @DeniedValue=LTRIM(RTRIM(@DeniedValue));SET @Reason=LTRIM(RTRIM(@Reason));
 IF @Category IS NULL OR @Category NOT IN('PERMISSION','DATABASE_ROLE','SERVER_ROLE','OPERATION','CLAUSE')
  OR NULLIF(@DeniedValue,N'') IS NULL OR NULLIF(@Reason,N'') IS NULL OR @Active IS NULL
  THROW 51303,'Categoría, valor, motivo o estado no permitido.',1;
 BEGIN TRY
  BEGIN TRAN;
 DECLARE @LockResult int;
 EXEC @LockResult=sys.sp_getapplock @Resource=N'SqlAccessAdmin.PolicyChanges',@LockMode='Exclusive',@LockOwner='Transaction',@LockTimeout=10000;
 IF @LockResult<0 THROW 51372,'No fue posible bloquear la política. Reintente.',1;
  MERGE [access].SecurityDenyList AS t USING(SELECT @Category Category,@DeniedValue DeniedValue) AS s
   ON t.Category=s.Category AND t.DeniedValue=s.DeniedValue
  WHEN MATCHED THEN UPDATE SET Reason=@Reason,Active=IIF(t.IsSystem=1,1,@Active)
  WHEN NOT MATCHED THEN INSERT(Category,DeniedValue,Reason,Active) VALUES(s.Category,s.DeniedValue,@Reason,@Active);
  IF @Active=1 UPDATE [access].SecurityPolicyOverride SET Active=0
   WHERE DeniedValue=@DeniedValue AND (Category=@Category OR (@Category='SERVER_ROLE' AND Category='DATABASE_ROLE'));
  DECLARE @Detail nvarchar(2000)=CONCAT(@Category,N': ',@DeniedValue,N'; Motivo=',@Reason);
  EXEC [access].usp_Audit_Write N'Política de seguridad',N'Actualizar bloqueo obligatorio',NULL,NULL,1,@Detail;
  COMMIT;
 END TRY
 BEGIN CATCH
  IF XACT_STATE()<>0 ROLLBACK;
  THROW;
 END CATCH;
END;
GO
CREATE OR ALTER PROCEDURE [access].usp_AccessRequest_Preview
 @OperationCode varchar(40),@PermissionAction varchar(10)=NULL,@PermissionName varchar(40)=NULL,@ScopeType varchar(20)=NULL,@RoleName sysname=NULL
AS
BEGIN
 SET NOCOUNT ON;
 -- SqlAccessAdmin.SpecialPolicyActivation: todos los contratos llaman a este validador.
 DECLARE @Allowed bit=1,@Reason nvarchar(2000)=N'La solicitud cumple la política central.',@Risk varchar(10),@Approval bit;
 SELECT @Risk=RiskLevel,@Approval=RequiresApproval FROM [access].SecurityPolicyOperation WHERE OperationCode=@OperationCode AND Enabled=1;
 IF @Risk IS NULL SELECT @Allowed=0,@Reason=N'Operación no registrada o deshabilitada.';
 IF @RoleName IS NOT NULL
 BEGIN
  DECLARE @RoleOverride bit=IIF(EXISTS(SELECT 1 FROM [access].SecurityPolicyOverride WHERE Category='DATABASE_ROLE' AND DeniedValue=@RoleName AND ScopeType='' AND Active=1),1,0);
  IF LOWER(@RoleName) IN('public','sysadmin','securityadmin','serveradmin','setupadmin','processadmin','diskadmin','bulkadmin')
   OR EXISTS(SELECT 1 FROM [access].SecurityDenyList WHERE Active=1 AND Category='SERVER_ROLE' AND DeniedValue=@RoleName)
   OR NOT EXISTS(SELECT 1 FROM [access].SecurityPolicyRole WHERE Enabled=1 AND RoleName=@RoleName)
   OR (@RoleOverride=0 AND (LOWER(@RoleName) IN('db_owner','db_securityadmin','db_accessadmin','db_ddladmin','db_backupoperator')
       OR EXISTS(SELECT 1 FROM [access].SecurityDenyList WHERE Active=1 AND Category='DATABASE_ROLE' AND DeniedValue=@RoleName)))
   SELECT @Allowed=0,@Reason=N'Rol bloqueado o pendiente de activación especial.';
  IF @RoleOverride=1 SELECT @Risk='HIGH',@Approval=1;
 END;
 IF @PermissionName IS NOT NULL
 BEGIN
  DECLARE @PermissionOverride bit=IIF(EXISTS(SELECT 1 FROM [access].SecurityPolicyOverride WHERE Category='PERMISSION' AND DeniedValue=@PermissionName AND ScopeType=@ScopeType AND Active=1),1,0);
  IF @PermissionName NOT IN('SELECT','INSERT','UPDATE','DELETE','EXECUTE') OR @ScopeType IS NULL OR @ScopeType NOT IN('DATABASE','OBJECT')
   OR @PermissionAction IS NULL OR @PermissionAction NOT IN('GRANT','REVOKE')
   OR (@PermissionOverride=0 AND EXISTS(SELECT 1 FROM [access].SecurityDenyList WHERE Active=1 AND Category='PERMISSION' AND DeniedValue=@PermissionName))
   OR NOT EXISTS(SELECT 1 FROM [access].SecurityPolicyPermission WHERE Enabled=1 AND PermissionName=@PermissionName AND ScopeType=@ScopeType
      AND ((@PermissionAction='GRANT' AND AllowGrant=1) OR (@PermissionAction='REVOKE' AND AllowRevoke=1)))
   SELECT @Allowed=0,@Reason=N'Permiso, acción o alcance no autorizado.';
  IF @PermissionOverride=1 SELECT @Risk='HIGH',@Approval=1;
 END;
 IF EXISTS(SELECT 1 FROM [access].SecurityDenyList WHERE Active=1 AND Category='OPERATION' AND DeniedValue=@OperationCode)
  SELECT @Allowed=0,@Reason=N'Operación bloqueada por la política central.';
 SELECT @Allowed Allowed,ISNULL(@Approval,1) RequiresApproval,ISNULL(@Risk,'HIGH') RiskLevel,@Reason Reason;
END;
GO
CREATE OR ALTER PROCEDURE [access].usp_AccessRequest_CopyPlanValidate
 @CopyPlanJson nvarchar(max),@Fingerprint nvarchar(776),@Targets [access].AccessRequestTargetType READONLY
AS
BEGIN
 SET NOCOUNT ON;
 IF ISNULL(ISJSON(@CopyPlanJson),0)<>1
    THROW 51348,'La copia requiere guardar el desglose de accesos por base. Genere una solicitud nueva.',1;
 IF ISNULL(TRY_CONVERT(int,JSON_VALUE(@CopyPlanJson,'$.Version')),0)<>2
    OR ISNULL(LEFT(LTRIM(JSON_QUERY(@CopyPlanJson,'$.Databases')),1),'')<>'['
    THROW 51349,'Formato de plan de copia no compatible.',1;
 IF ISNULL(@Fingerprint,N'') COLLATE Latin1_General_100_BIN2<>
    CONVERT(varchar(64),HASHBYTES('SHA2_256',@CopyPlanJson),2) COLLATE Latin1_General_100_BIN2
    THROW 51350,'La huella no coincide con el desglose de copia guardado.',1;

 DECLARE @Bases table(DatabaseName nvarchar(max),SourceUser nvarchar(max),Accesses nvarchar(max));
 INSERT @Bases SELECT DatabaseName,SourceUser,Accesses
 FROM OPENJSON(@CopyPlanJson,'$.Databases') WITH
 (DatabaseName nvarchar(max) '$.Database',SourceUser nvarchar(max) '$.SourceUser',Accesses nvarchar(max) '$.Accesses' AS JSON);
 IF NOT EXISTS(SELECT 1 FROM @Bases) OR EXISTS
 (SELECT 1 FROM @Bases WHERE NULLIF(LTRIM(RTRIM(DatabaseName)),N'') IS NULL OR LEN(DatabaseName)>128
  OR NULLIF(LTRIM(RTRIM(SourceUser)),N'') IS NULL OR LEN(SourceUser)>128
  OR ISNULL(LEFT(LTRIM(Accesses),1),'')<>'['
  OR LOWER(SourceUser) IN(N'dbo',N'guest',N'sys',N'information_schema')
  OR SourceUser LIKE N'##MS[_]%' OR SourceUser LIKE N'NT AUTHORITY\%' OR SourceUser LIKE N'NT SERVICE\%' OR SourceUser LIKE N'BUILTIN\%')
    THROW 51351,'Una base o usuario origen del plan no es válido.',1;
 IF EXISTS(SELECT DatabaseName FROM @Bases GROUP BY DatabaseName HAVING COUNT(*)>1)
    OR EXISTS(SELECT DatabaseName FROM @Bases EXCEPT SELECT DatabaseName FROM @Targets)
    OR EXISTS(SELECT DatabaseName FROM @Targets EXCEPT SELECT DatabaseName FROM @Bases)
    THROW 51352,'El detalle de copia debe corresponder exactamente a todas las bases destino.',1;

 DECLARE @Accesos table(DatabaseName nvarchar(max),ItemDatabase nvarchar(max),Kind nvarchar(max),StateName nvarchar(max),
  PermissionName nvarchar(max),ScopeType nvarchar(max),SchemaName nvarchar(max),ObjectName nvarchar(max),ColumnName nvarchar(max),RoleName nvarchar(max),CanCopy bit);
 INSERT @Accesos
 SELECT b.DatabaseName,a.ItemDatabase,a.Kind,a.StateName,a.PermissionName,a.ScopeType,a.SchemaName,a.ObjectName,a.ColumnName,a.RoleName,a.CanCopy
 FROM @Bases b CROSS APPLY OPENJSON(b.Accesses) WITH
 (ItemDatabase nvarchar(max) '$.Database',Kind nvarchar(max) '$.Kind',StateName nvarchar(max) '$.State',
  PermissionName nvarchar(max) '$.Permission',ScopeType nvarchar(max) '$.Scope',SchemaName nvarchar(max) '$.Schema',
  ObjectName nvarchar(max) '$.Object',ColumnName nvarchar(max) '$.Column',RoleName nvarchar(max) '$.Role',CanCopy bit '$.CanCopy') a;
 IF EXISTS(SELECT 1 FROM @Accesos WHERE ItemDatabase IS NULL OR ItemDatabase<>DatabaseName OR ISNULL(Kind,N'') NOT IN(N'Rol',N'Permiso')
  OR CanCopy IS NULL OR StateName IS NULL OR ScopeType IS NULL OR PermissionName IS NULL OR SchemaName IS NULL OR ObjectName IS NULL OR ColumnName IS NULL OR RoleName IS NULL
  OR LEN(SchemaName)>128 OR LEN(ObjectName)>128 OR LEN(ColumnName)>128 OR LEN(RoleName)>128
  OR StateName IN('DENY','REVOKE'))
    THROW 51353,'El plan contiene un acceso incompleto o una restricción que no se puede omitir.',1;
 IF NOT EXISTS(SELECT 1 FROM @Accesos WHERE CanCopy=1)
    THROW 51354,'El plan no contiene accesos autorizados para copiar.',1;
 IF EXISTS(SELECT 1 FROM @Accesos WHERE CanCopy=1 AND
  ((Kind=N'Rol' AND (NULLIF(RoleName,N'') IS NULL OR LOWER(RoleName) IN('public','sysadmin','securityadmin','serveradmin','setupadmin','processadmin','diskadmin','bulkadmin')))
   OR (Kind=N'Permiso' AND (PermissionName NOT IN('SELECT','INSERT','UPDATE','DELETE','EXECUTE') OR ScopeType NOT IN('DATABASE','OBJECT')
       OR StateName NOT IN('GRANT','GRANT_WITH_GRANT_OPTION') OR NULLIF(ColumnName,N'') IS NOT NULL
       OR (ScopeType='OBJECT' AND (NULLIF(SchemaName,N'') IS NULL OR NULLIF(ObjectName,N'') IS NULL))))))
    THROW 51355,'El plan intenta copiar un acceso fuera de la política máxima.',1;

 DECLARE @Check table(Allowed bit,RequiresApproval bit,RiskLevel varchar(10),Reason nvarchar(2000));
 DECLARE @Kind nvarchar(20),@Permission varchar(40),@Scope varchar(20),@Role sysname,@Operation varchar(40),@Action varchar(10);
 DECLARE CopyPolicy CURSOR LOCAL FAST_FORWARD FOR
 SELECT DISTINCT Kind,PermissionName,ScopeType,RoleName FROM @Accesos WHERE CanCopy=1;
 OPEN CopyPolicy;FETCH NEXT FROM CopyPolicy INTO @Kind,@Permission,@Scope,@Role;
 WHILE @@FETCH_STATUS=0
 BEGIN
  SET @Operation=IIF(@Kind=N'Rol','ADD_ROLE_MEMBER','PERMISSION_CHANGE');
  SET @Action=IIF(@Kind=N'Rol',NULL,'GRANT');
  IF @Kind=N'Rol' SET @Permission=NULL; ELSE SET @Role=NULL;
  DELETE FROM @Check;
  INSERT @Check EXEC [access].usp_AccessRequest_Preview @Operation,@Action,@Permission,@Scope,@Role;
  IF NOT EXISTS(SELECT 1 FROM @Check WHERE Allowed=1)
  BEGIN CLOSE CopyPolicy;DEALLOCATE CopyPolicy;THROW 51356,'La política central bloquea un acceso del plan de copia.',1;END;
  FETCH NEXT FROM CopyPolicy INTO @Kind,@Permission,@Scope,@Role;
 END;
 CLOSE CopyPolicy;DEALLOCATE CopyPolicy;
END;
GO
GRANT EXECUTE ON [access].usp_Policy_SpecialActivate TO [SqlAccessAdmin_Administrator];
GO
PRINT N'Activación especial instalada. No se habilitó ninguna excepción automáticamente.';
GO

