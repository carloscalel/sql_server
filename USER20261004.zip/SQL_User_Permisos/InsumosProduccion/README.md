# Insumos de preparación de `adminDB`

Estos archivos son insumos de infraestructura. **La aplicación no los ejecuta, no crea la base de datos y no realiza migraciones automáticas.** Deben ser revisados, ajustados y ejecutados manualmente por un DBA con una cuenta privilegiada.

## Orden de ejecución

1. `00_CrearBaseDatos.sql` — opcional; omitir si `adminDB` ya existe.
2. `01_CrearEsquema.sql` — tablas, restricciones, índices y tipo de tabla.
3. `02_CrearProcedimientosConsulta.sql` — login, catálogos y auditoría.
4. `03_CrearProcedimientosOperacion.sql` — operaciones auditadas y ejecución remota.
5. `04_CrearRolesYPermisos.sql` — roles de mínimo privilegio y permisos sobre SP.
6. `05_DatosIniciales.sql` — plantilla que el DBA debe personalizar antes de ejecutar.
7. `07_CorreccionLoginSysadmin.sql` — actualización puntual para instalaciones existentes.
8. `08_ConfigurarConexionDirectaYCifrado.sql` — migración y clave AES-GCM central; requiere una contraseña elegida por el DBA.
9. `09_RenombrarRolesSqlAccessAdmin.sql` — migra los nombres heredados de roles en instalaciones existentes.
10. `10_PoliticaSolicitudesEIntegridad.sql` — allowlist, denylist, solicitudes, aprobación y cadena hash de auditoría.
11. `11_BloquearModificacionRoles.sql` — elimina en instalaciones existentes la ruta para registrar o modificar roles desde la aplicación.
12. `12_SimplificarGestionAccesos.sql` — habilita cuentas Windows/modificación de login y reduce los permisos a lectura, escritura y ejecución de rutinas por base u objeto.
13. `13_RestringirServidorUnico.sql` — obliga a que cada solicitud nueva pertenezca a un solo servidor y habilita el filtro de solicitudes por servidor.
14. `14_RedisenarMapeoLogin.sql` — redefine “Modificar login” como mapeo controlado a una base y asignación de un rol aprobado.
15. `15_PrevenirSolicitudesDuplicadas.sql` — rechaza de forma transaccional solicitudes equivalentes que continúen pendientes o aprobadas e impide aprobar dos duplicados históricos.
16. `16_HabilitarAutoconfirmacion.sql` — convierte la aprobación en un doble check: Administrator y Operator pueden confirmar, rechazar y ejecutar sus propias gestiones.
17. `17_AdministrarPoliticaPermisosRoles.sql` — permite al Administrator habilitar o deshabilitar permisos y roles asignables sin modificar la definición de los roles SQL.
18. `18_TicketExternoSolicitudes.sql` — incorpora el ticket externo obligatorio en solicitudes, aprobación e historial; el script 27 actualizado sustituye su validación de formato por la comprobación real en `dbo.sp_VerificarTicketExiste`.
19. `19_SolicitudCompuestaYContrasenaTemporal.sql` — unifica login, usuario de base, roles y permisos en una solicitud; cifra la contraseña temporal y exige política, expiración y cambio en el primer login.
20. `20_MigrarObjetosAlEsquemaAccess.sql` — solo para instalaciones existentes: mueve tablas, tipos, procedimientos y el trigger desde `dbo` o desde el esquema transitorio `SqlAccessAdmin` hacia `access`, conservando datos y permisos.
21. `21_SolicitudUnicaCambiosAcceso.sql` — reúne todos los cambios de roles y permisos en una sola solicitud; valida cada cambio y compara el plan completo al detectar duplicados.
22. `22_HabilitarCopiaPermisos.sql` — habilita la copia de accesos a un login SQL nuevo con contraseña temporal cifrada y huella de los accesos revisados.
23. `23_DetalleCopiaPermisosPorBase.sql` — guarda el desglose completo de copia con el usuario origen, roles y permisos de cada base; valida el plan al crear y confirmar la solicitud.
24. `24_AutenticacionSqlWindows.sql` — permite seleccionar exclusivamente SQL o Windows al crear usuarios y copiar permisos; valida la autenticación al crear y confirmar, con contraseña cifrada únicamente para SQL.
25. `25_ActivacionEspecialPoliticas.sql` — autoriza excepciones explícitas y auditadas para roles de base y permisos admitidos; conserva los bloqueos originales.
26. `26_ValidacionCompartidaPermisosRoles.sql` — aplica la misma confirmación especial a permisos protegidos de esquema, columna y REFERENCES; revalida en solicitudes, copia y ejecución sin habilitar excepciones automáticamente.
27. `27_PoliticaAccesoPorInstanciaYBase.sql` — plantilla general, reglas de instancia/base, descubrimiento de roles personalizados, catálogo de permisos de SQL Server y GRANT/DENY/REVOKE por destino; además valida cada ticket activo mediante `dbo.sp_VerificarTicketExiste` y toma su descripción como motivo.
28. `28_CatalogoCredencialesInstancia.sql` — registra CREDENTIAL como ámbito de instancia, sin habilitar permisos ni cambiar accesos.
29. `99_ValidarInstalacion.sql` — comprobación final, solo lectura.

Para esta versión aplique 27 después de 26, luego 28, ejecute 99 y reinicie la aplicación actualizada. Si 27 ya está aplicado, solo hace falta 28 antes de 99. No reaplique scripts anteriores después de 27: las tablas antiguas de política quedan como referencia y las reglas vigentes residen en PolicyPermissionRule/PolicyRoleRule. La aplicación no ejecuta migraciones automáticamente. Consulte [la guía de política por destino](../docs/PoliticaAccesoPorDestino.md) para uso, límites y prueba de integración.

Todos los scripts usan `GO`, por lo que deben ejecutarse con SSMS, Azure Data Studio o `sqlcmd` en modo compatible. Los scripts `01` a `04` son repetibles. El archivo `05` contiene variables que intencionalmente provocan un error hasta ser personalizadas.

Todos los objetos propios de la aplicación se crean bajo el esquema corto `[access]`. El nombre representa autorización y gestión de accesos sin confundirse con autenticación solamente ni con toda la administración de SQL Server. Los roles de base de datos `SqlAccessAdmin_*` permanecen como principales de seguridad porque no pertenecen a un esquema.

Para una instalación existente que todavía usa `dbo` o que alcanzó a usar el esquema transitorio `SqlAccessAdmin`, ejecute primero `20_MigrarObjetosAlEsquemaAccess.sql` con la aplicación detenida y despliegue inmediatamente la versión actualizada del ejecutable. Después puede aplicar, en orden, cualquier migración funcional pendiente (`09` a `19`), luego `21`, `22`, `23`, `24`, `25`, `26`, `27`, `28` y finalmente `99`. La migración `20` conserva datos, relaciones y permisos; además recompila los módulos para reemplazar referencias calificadas a los esquemas anteriores.

Si la instalación ya usa `access` y tiene aplicado `19`, para habilitar solicitudes con varios cambios ejecute `21_SolicitudUnicaCambiosAcceso.sql`; para la copia de accesos aplique luego `22`, `23`, `24`, `25`, `26`, `27` y `28`, y termine con `99_ValidarInstalacion.sql`. La aplicación conserva el primer cambio en la cabecera y los restantes como pasos internos. La tarjeta de confirmación y el historial muestran el listado completo. Una modificación compuesta se ejecuta dentro de una transacción en su base destino: si falla un cambio se revierten los demás cambios de esa base. Las solicitudes anteriores conservan su identificación y estado; no se agrupan retroactivamente.

La migración `20` también puede volver a ejecutarse si una versión anterior alcanzó a mover los objetos pero falló durante la recompilación: toma las definiciones directamente desde `access`, las convierte a `ALTER` y valida que no queden referencias al esquema anterior antes de informar que terminó correctamente.

## Ejecución con `sqlcmd`

Para habilitar opciones protegidas desde **Política de acceso**, aplique `25_ActivacionEspecialPoliticas.sql` después de `24` y después `26_ValidacionCompartidaPermisosRoles.sql` y `27_PoliticaAccesoPorInstanciaYBase.sql` y `28_CatalogoCredencialesInstancia.sql`, ejecute `99` y reinicie la aplicación. Ninguna migración habilita excepciones por sí sola. Las pestañas Permisos y Roles comparten la confirmación: solo Administrator puede pulsar **Habilitar…**, justificar con al menos 20 caracteres, reconocer el riesgo y escribir el nombre exacto. **Autorizar y habilitar** guarda inmediatamente la disponibilidad y su excepción en una transacción con auditoría; los cambios pendientes del formulario deben guardarse o descartarse primero. Es una doble confirmación consciente, no MFA ni aprobación de otra persona.

La excepción de un permiso se limita a su combinación exacta de permiso, alcance y destino. Desde el script 27, el catálogo se descubre en cada instancia y permite habilitar todos los permisos reconocidos mediante confirmación especial cuando corresponda. GRANT, DENY y REVOKE se configuran independientemente. Los roles de servidor se gestionan en la instancia y los de base en su destino; public continúa excluido por ser implícito. La excepción de un rol personalizado nunca se propaga por coincidencia de nombre a otras bases. Las solicitudes se revalidan al crear, confirmar y ejecutar; la copia consulta la política de cada base. La cuenta técnica necesita autoridad real para asignar el permiso o rol: la excepción central no le concede privilegios SQL.

La edición de accesos añade una sección plegable para permisos generales, de esquema o de columna. SCHEMA usa `esquema`; COLUMN usa `esquema.objeto.columna` sin corchetes y con una única base destino. La copia utiliza los nombres completos del catálogo, delimitados de forma segura. SELECT/UPDATE/REFERENCES de columna pueden prevalecer sobre un DENY de objeto; el formulario advierte este riesgo. Antes de producción, valide GRANT/REVOKE de esquema y columna, REFERENCES, copia multibase y retiro de autorización en un SQL Server de pruebas. Las pruebas locales no conectan con SQL Server real.

Volver a bloquear una opción y guardar retira su excepción. Habilitarla de nuevo exige repetir la confirmación especial. Agregar un bloqueo obligatorio para el mismo elemento invalida las excepciones existentes. El bloqueo original se conserva en `SecurityDenyList`; desde 27, la excepción exacta y sus metadatos quedan en `PolicyPermissionRule` o `PolicyRoleRule` por destino, con administrador, fecha y motivo; `SecurityPolicyOverride` se conserva como referencia histórica, y sus cambios quedan registrados en la cadena de auditoría. Los operadores no reciben permisos de escritura sobre esas tablas ni de ejecución del procedimiento de activación. Una instalación anterior sin `27` conserva los bloqueos y muestra una indicación de migración al intentar activar permisos extendidos.

Prueba en una instancia aislada: activar `db_owner`, cancelar la confirmación, escribir un nombre incorrecto, probar sin reconocer el riesgo y con motivo corto; comprobar que un Operator no puede activar por UI ni mediante el procedimiento; crear/confirmar/ejecutar una membresía autorizada; copiar una membresía autorizada y volver a bloquear antes de ejecutar para comprobar que se rechaza; activar `SELECT` solo en `OBJECT` y verificar que `DATABASE` sigue protegido; volver a bloquear y comprobar que exige una nueva autorización. Revisar identidad, motivo y fecha en auditoría. Las verificaciones locales usan datos simulados y no modifican SQL Server.

Para los formularios **2. Crear usuario** y **3. Copiar permisos**, aplique `24_AutenticacionSqlWindows.sql` después de `23`, luego `25_ActivacionEspecialPoliticas.sql` , `26_ValidacionCompartidaPermisosRoles.sql` y `27_PoliticaAccesoPorInstanciaYBase.sql` y `28_CatalogoCredencialesInstancia.sql`, ejecute `99` y reinicie la aplicación. Elija **SQL authentication** o **Windows authentication**; cada solicitud guarda un solo tipo. Cambiar a Windows borra las contraseñas temporales y oculta su sección. Cambiar nuevamente a SQL exige ingresar y confirmar una contraseña nueva.

Windows requiere una cuenta ya existente en formato `DOMINIO\usuario` o `EQUIPO\usuario`, por ejemplo `CAEL\cael_test01`. En ambos formularios pulse **Comprobar nombres**: el aplicativo consulta `master.sys.xp_logininfo` desde el servidor SQL seleccionado. El retorno `0` confirma que Windows reconoce la cuenta, incluso si todavía no tiene un login SQL y el procedimiento devuelve cero filas. Un ✓ verde indica una comprobación válida y una ✕ roja indica que no se pudo comprobar, con el motivo correspondiente. La disponibilidad del nombre en SQL Server se muestra por separado y nunca sustituye esta comprobación.

El envío queda bloqueado hasta comprobar la cuenta; también permanece bloqueado mientras la consulta está en curso o si hay error de formato, conexión, permisos o resolución Windows. Cambiar el nombre, el servidor, la operación o el tipo de autenticación invalida el resultado y descarta respuestas tardías. El aplicativo vuelve a consultar la identidad antes de registrar la solicitud y antes de crear el login Windows. No requiere otra migración de `adminDB` después de `24`.

La conexión técnica al servidor de trabajo debe tener `CONTROL SERVER` o permiso **EXECUTE sobre `sys.xp_logininfo` en `master`**. Use el permiso específico cuando corresponda; no es necesario ampliar a `CONTROL SERVER`. Un DBA puede concederlo al usuario técnico que ya exista en `master` (sustituya el nombre de este ejemplo):

```sql
USE [master];
GO
GRANT EXECUTE ON OBJECT::sys.xp_logininfo TO [UsuarioTecnicoEnMaster];
GO
```

Esta concesión se revisa y ejecuta manualmente en cada servidor de trabajo, no en `adminDB`. La aplicación no concede permisos automáticamente. Si falta ese permiso, el formulario informa el problema y conserva el bloqueo. SQL Server también necesita poder consultar el equipo o dominio de la cuenta. [Referencia oficial de xp_logininfo](https://learn.microsoft.com/en-us/sql/relational-databases/system-stored-procedures/xp-logininfo-transact-sql).

El aplicativo crea el login con `CREATE LOGIN [...] FROM WINDOWS` y sus usuarios de base con el mismo nombre. No crea cuentas de dominio, no cambia contraseñas de Windows ni admite un nombre Windows bajo SQL authentication. La política debe permitir `CREATE_WINDOWS_LOGIN` y, en copia, también `CREATE_DB_USER` y `CLONE_PERMISSIONS`. El origen puede ser SQL o Windows independientemente del tipo seleccionado para el destino.

La migración conserva los planes JSON v2 y las solicitudes SQL anteriores con desglose válido. Mantiene las comprobaciones de origen, huella, política, destinos, exclusiones y duplicados. En confirmación e historial, la creación del login indica SQL o Windows. La ejecución registra el tipo y aplica opciones de contraseña únicamente a SQL.

Prueba integral en CAEL: crear un login SQL con contraseña y comprobar una cuenta Windows existente antes de crear su login; probar cada tipo con accesos iniciales; copiar desde un origen multibase a un destino SQL y a un destino Windows; alternar el selector con contraseñas ya ingresadas; comprobar una cuenta Windows inexistente, una cuenta válida aún sin login SQL, un nombre ya existente y un error de permiso sobre `xp_logininfo`; modificar el nombre mientras se comprueba y confirmar que no se reutilice el resultado. Verifique confirmación, historial y auditoría. Los chequeos locales no comprueban Active Directory ni abren conexiones SQL reales.

Para habilitar **Copiar permisos**, aplique `22_HabilitarCopiaPermisos.sql`, `23_DetalleCopiaPermisosPorBase.sql` `24_AutenticacionSqlWindows.sql`, `25_ActivacionEspecialPoliticas.sql` , `26_ValidacionCompartidaPermisosRoles.sql` y `27_PoliticaAccesoPorInstanciaYBase.sql` y `28_CatalogoCredencialesInstancia.sql` después de `21`, ejecute `99` y reinicie la aplicación para recargar la política. La operación crea un login nuevo del tipo seleccionado: el nombre no puede existir en el servidor ni en las bases del origen. El selector reúne usuarios administrables de las bases consultables (excepto `tempdb`, `model` y `msdb`) y la tabla muestra sus roles y permisos directos sin permitir cambios. Solo se copian membresías de roles de base y permisos directos aprobados en DATABASE/OBJECT/SCHEMA/COLUMN, con autorización especial cuando corresponda y conforme al catálogo y a la política del destino. No se copian roles de servidor. Los ámbitos no admitidos y accesos protegidos aparecen como excluidos; GRANT WITH GRANT OPTION se copia sin delegación. Si el origen tiene DENY o excepciones REVOKE, se bloquea toda la copia para evitar ampliar los accesos al omitir una restricción. Los roles conservan sus permisos heredados sin modificar su definición.

Después de `22`, aplique `23_DetalleCopiaPermisosPorBase.sql`, luego `24`, `25`, `26`, `27` y `28` y ejecute `99`. La solicitud conserva el plan revisado como JSON y una huella de su contenido. Confirmación e historial enumeran la creación del login, el usuario de cada base y todos los roles y permisos autorizados con sus destinos. Las exclusiones quedan guardadas, pero no se ejecutan. El catálogo agrupa por login los usuarios asociados mediante SID, aunque tengan nombres diferentes en sus bases. La ejecución crea el login una sola vez y usa el usuario origen específico de cada base para revalidar el estado; nunca mezcla los permisos de bases distintas. Si el origen, el plan o la política cambian, la ejecución se bloquea y debe generarse una solicitud nueva.

Las solicitudes de copia anteriores a `23` no guardaron este desglose. Se conservan en el historial con una indicación explícita; para confirmar o ejecutar una copia anterior, rechácela y genere una nueva. No se inventa el listado histórico consultando los permisos actuales del origen.

Cada base usa una transacción para crear su usuario y copiar accesos. El login es una operación de instancia independiente: si falla una base, el login y las bases completadas permanecen; el resultado lo informa y el DBA debe revisar antes de reintentar. El principal técnico necesita consultar metadatos de seguridad, crear logins SQL/usuarios y asignar las membresías y permisos autorizados. Pruebe en SQL Server real un origen con varios permisos en varias bases (también con nombres de usuario diferentes), un nombre existente, cambios de política/origen y un fallo intermedio.

```powershell
sqlcmd -S SERVIDOR\INSTANCIA -E -b -i .\InsumosProduccion\00_CrearBaseDatos.sql
sqlcmd -S SERVIDOR\INSTANCIA -E -b -i .\InsumosProduccion\01_CrearEsquema.sql
sqlcmd -S SERVIDOR\INSTANCIA -E -b -i .\InsumosProduccion\02_CrearProcedimientosConsulta.sql
sqlcmd -S SERVIDOR\INSTANCIA -E -b -i .\InsumosProduccion\03_CrearProcedimientosOperacion.sql
sqlcmd -S SERVIDOR\INSTANCIA -E -b -i .\InsumosProduccion\04_CrearRolesYPermisos.sql
```

Los scripts `05` y `08` son plantillas y requieren personalización explícita. No deben incluirse sin revisión en una ejecución desatendida.

## Decisiones de seguridad

- Los servidores administrados se alcanzan mediante conexiones TLS directas desde el aplicativo; no se requieren linked servers.
- `Encrypt` es obligatorio por defecto; `TrustServerCertificate` debe permanecer desactivado cuando exista una PKI válida.
- Las columnas `CredentialCiphertext`, `CredentialNonce` y `CredentialTag` guardan el sobre AES-256-GCM. La clave de 256 bits se genera aleatoriamente en `adminDB` y queda envuelta por una clave AES-256 protegida mediante certificado y Database Master Key de SQL Server.
- La contraseña temporal de un nuevo login SQL se conserva únicamente cifrada con AES-256-GCM hasta la ejecución. Windows no guarda ningún secreto SQL.
- La cuenta configurada para cada destino debe tener únicamente los permisos necesarios para crear logins, usuarios y membresías autorizadas.
- Los roles de base de datos son inmutables para la aplicación: solo pueden consultarse y asignarse o retirarse como membresías de usuarios. No se crean, editan ni reciben permisos mediante la aplicación.
- La matriz básica mantiene los permisos de datos habituales. Desde 27, la política y las solicitudes avanzadas admiten las combinaciones de permiso/ámbito reconocidas por SQL Server, incluidas acciones GRANT/DENY/REVOKE y accesos de instancia con autorización especial; la cuenta técnica conserva sus propios límites SQL.
- Antes de consultar o gestionar accesos se selecciona un único servidor de trabajo. Una solicitud no puede mezclar servidores y las solicitudes históricas multiserver quedan bloqueadas para ejecución.
- La confirmación es un segundo paso consciente del mismo operador, no una segregación de funciones. Administrator y Operator pueden confirmar o rechazar su propia solicitud antes de ejecutarla; todos los pasos quedan auditados.

Antes de producción, el DBA debe revisar políticas de contraseñas, certificados TLS, retención de auditoría, respaldos y permisos del principal técnico.
