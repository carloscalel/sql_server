USE [adminDB];
GO
SET NOCOUNT ON;
SET XACT_ABORT ON;
GO

/* Ejecutar manualmente como DBA después de 21.
   Habilita copiar accesos a un login SQL nuevo con contraseña cifrada.
   La aplicación valida cada acceso y la huella del origen antes de ejecutar.
   Repetible; conserva solicitudes e historial. */
IF ISNULL(OBJECT_DEFINITION(OBJECT_ID(N'[access].usp_AccessRequest_Create')),N'') NOT LIKE N'%SqlAccessAdmin.AccessChangesComposite%'
    THROW 51341,'Ejecute primero 21_SolicitudUnicaCambiosAcceso.sql.',1;
IF OBJECT_ID(N'[access].AccessRequestStep',N'U') IS NULL
   OR TYPE_ID(N'[access].AccessRequestStepType') IS NULL
   OR COL_LENGTH(N'[access].AccessRequest',N'SecretCiphertext') IS NULL
    THROW 51336,'Ejecute primero 19_SolicitudCompuestaYContrasenaTemporal.sql bajo el esquema access.',1;
GO

CREATE OR ALTER PROCEDURE [access].usp_AccessRequest_Create
 @OperationCode varchar(40),@TargetPrincipal nvarchar(256),@SourcePrincipal nvarchar(256)=NULL,
 @AuthenticationType varchar(20)=NULL,@PermissionAction varchar(10)=NULL,@PermissionName varchar(40)=NULL,
 @ScopeType varchar(20)=NULL,@Securable nvarchar(776)=NULL,@RoleName sysname=NULL,
 @ExternalTicketNumber varchar(40),@Justification nvarchar(1000),
 @Targets [access].AccessRequestTargetType READONLY,@Steps [access].AccessRequestStepType READONLY,
 @SecretCiphertext varbinary(max)=NULL,@SecretNonce varbinary(12)=NULL,@SecretTag varbinary(16)=NULL,
 @SecretKeyId uniqueidentifier=NULL,@PasswordPolicy bit=0,@PasswordExpiration bit=0,@MustChangePassword bit=0
AS
BEGIN
 SET NOCOUNT ON;SET XACT_ABORT ON;
 -- SqlAccessAdmin.AccessRequestCreate · SqlAccessAdmin.CompositeRequestCreate · SqlAccessAdmin.AccessChangesComposite
 -- SqlAccessAdmin.PermissionCopyNewLogin
 IF @OperationCode='CLONE_PERMISSIONS'
 BEGIN
  IF ISNULL(@AuthenticationType,'')<>'SQL' OR NULLIF(LTRIM(RTRIM(@SourcePrincipal)),N'') IS NULL
     OR LEN(LTRIM(RTRIM(@TargetPrincipal)))>128 OR LEN(LTRIM(RTRIM(@SourcePrincipal)))>128
     OR UPPER(LTRIM(RTRIM(@TargetPrincipal)))=UPPER(LTRIM(RTRIM(@SourcePrincipal)))
   THROW 51342,'Copiar permisos requiere un usuario origen y un login SQL nuevo distinto.',1;
  IF @Securable IS NULL OR LEN(@Securable)<>64 OR @Securable COLLATE Latin1_General_100_BIN2 LIKE '%[^0-9A-F]%'
   THROW 51343,'La copia requiere la huella de los accesos revisados.',1;
  IF EXISTS(SELECT 1 FROM @Steps) OR @PermissionName IS NOT NULL OR @PermissionAction IS NOT NULL OR @RoleName IS NOT NULL OR @ScopeType IS NOT NULL
   THROW 51344,'El plan de copia no admite cambios manuales.',1;
  DECLARE @ClonePolicy table(Allowed bit,RequiresApproval bit,RiskLevel varchar(10),Reason nvarchar(2000));
  INSERT @ClonePolicy EXEC [access].usp_AccessRequest_Preview 'CREATE_SQL_LOGIN',NULL,NULL,NULL,NULL;
  IF NOT EXISTS(SELECT 1 FROM @ClonePolicy WHERE Allowed=1) THROW 51345,'La política bloquea crear el login SQL.',1;
  DELETE FROM @ClonePolicy;
  INSERT @ClonePolicy EXEC [access].usp_AccessRequest_Preview 'CREATE_DB_USER',NULL,NULL,NULL,NULL;
  IF NOT EXISTS(SELECT 1 FROM @ClonePolicy WHERE Allowed=1) THROW 51345,'La política bloquea crear usuarios de base.',1;
 END;
 SET @ExternalTicketNumber=UPPER(LTRIM(RTRIM(@ExternalTicketNumber)));
 IF @ExternalTicketNumber IS NULL OR @ExternalTicketNumber NOT LIKE 'TIC-RF-%'
    OR LEN(@ExternalTicketNumber)<=7 OR SUBSTRING(@ExternalTicketNumber,8,40) LIKE '%[^0-9]%'
  THROW 51320,'El ticket externo debe usar TIC-RF- seguido únicamente por dígitos.',1;
 IF NOT EXISTS(SELECT 1 FROM @Targets) THROW 51310,'Debe seleccionar destinos.',1;
 IF (SELECT COUNT(DISTINCT ServerId) FROM @Targets)<>1 THROW 51314,'Cada solicitud debe pertenecer a un único servidor.',1;
 IF @Justification IS NULL OR LEN(LTRIM(RTRIM(@Justification)))<10 THROW 51311,'La justificación debe contener al menos 10 caracteres.',1;
 IF @TargetPrincipal IS NULL OR LEN(LTRIM(RTRIM(@TargetPrincipal)))=0 THROW 51337,'Debe indicar el principal destino.',1;
 IF @OperationCode IN('CREATE_SQL_LOGIN','CLONE_PERMISSIONS') AND (@SecretCiphertext IS NULL OR @SecretNonce IS NULL OR @SecretTag IS NULL OR @SecretKeyId IS NULL)
  THROW 51330,'La creación de un login SQL requiere una contraseña temporal cifrada.',1;
 IF @OperationCode IN('CREATE_SQL_LOGIN','CLONE_PERMISSIONS') AND @PasswordExpiration=1 AND @PasswordPolicy=0
  THROW 51331,'CHECK_EXPIRATION requiere CHECK_POLICY activo.',1;
 IF @OperationCode IN('CREATE_SQL_LOGIN','CLONE_PERMISSIONS') AND @MustChangePassword=1 AND (@PasswordPolicy=0 OR @PasswordExpiration=0)
  THROW 51335,'MUST_CHANGE requiere CHECK_POLICY y CHECK_EXPIRATION activos.',1;

 IF EXISTS(SELECT 1 FROM @Steps)
 BEGIN
  IF @OperationCode NOT IN('CREATE_SQL_LOGIN','CREATE_WINDOWS_LOGIN','MODIFY_LOGIN','ADD_ROLE_MEMBER','REMOVE_ROLE_MEMBER','PERMISSION_CHANGE')
   THROW 51332,'Esta operación no admite un plan interno.',1;
  IF @OperationCode IN('CREATE_SQL_LOGIN','CREATE_WINDOWS_LOGIN')
  BEGIN
   IF (SELECT TOP(1) OperationCode FROM @Steps ORDER BY StepOrder)<>'CREATE_DB_USER'
    THROW 51333,'El primer paso del acceso inicial debe crear el usuario de base.',1;
   IF EXISTS(SELECT 1 FROM @Steps WHERE OperationCode NOT IN('CREATE_DB_USER','ADD_ROLE_MEMBER','REMOVE_ROLE_MEMBER','PERMISSION_CHANGE'))
    THROW 51338,'El acceso inicial contiene una operación interna no permitida.',1;
  END
  ELSE
  BEGIN
   IF (SELECT COUNT(*) FROM @Targets)<>1
    THROW 51339,'Una modificación compuesta debe trabajar sobre una sola base de datos.',1;
   IF EXISTS(SELECT 1 FROM @Steps WHERE OperationCode NOT IN('ADD_ROLE_MEMBER','REMOVE_ROLE_MEMBER','PERMISSION_CHANGE'))
    THROW 51338,'La modificación compuesta solo admite roles y permisos.',1;
  END;
  IF EXISTS(SELECT 1 FROM @Steps WHERE StepOrder<=0)
     OR (SELECT MIN(StepOrder) FROM @Steps)<>1
     OR (SELECT MAX(StepOrder) FROM @Steps)<>(SELECT COUNT(*) FROM @Steps)
   THROW 51340,'Los cambios internos deben tener un orden consecutivo desde 1.',1;
 END;
 IF (@OperationCode='PERMISSION_CHANGE' AND @ScopeType='OBJECT')
    OR EXISTS(SELECT 1 FROM @Steps WHERE OperationCode='PERMISSION_CHANGE' AND ScopeType='OBJECT')
 BEGIN
  IF (SELECT COUNT(*) FROM @Targets)<>1 THROW 51339,'Los permisos por objeto requieren una sola base de datos.',1;
 END;

 DECLARE @Check table(Allowed bit,RequiresApproval bit,RiskLevel varchar(10),Reason nvarchar(2000));
 INSERT @Check EXEC [access].usp_AccessRequest_Preview @OperationCode,@PermissionAction,@PermissionName,@ScopeType,@RoleName;
 IF NOT EXISTS(SELECT 1 FROM @Check WHERE Allowed=1) THROW 51312,'Solicitud rechazada por la política central.',1;
 DECLARE @SO varchar(40),@SA varchar(10),@SP varchar(40),@SS varchar(20),@SR sysname;
 DECLARE StepPolicy CURSOR LOCAL FAST_FORWARD FOR SELECT OperationCode,PermissionAction,PermissionName,ScopeType,RoleName FROM @Steps ORDER BY StepOrder;
 OPEN StepPolicy;FETCH NEXT FROM StepPolicy INTO @SO,@SA,@SP,@SS,@SR;
 WHILE @@FETCH_STATUS=0
 BEGIN
  DELETE FROM @Check;INSERT @Check EXEC [access].usp_AccessRequest_Preview @SO,@SA,@SP,@SS,@SR;
  IF NOT EXISTS(SELECT 1 FROM @Check WHERE Allowed=1)
  BEGIN CLOSE StepPolicy;DEALLOCATE StepPolicy;THROW 51334,'Un cambio interno fue rechazado por la política central.',1;END;
  FETCH NEXT FROM StepPolicy INTO @SO,@SA,@SP,@SS,@SR;
 END;
 CLOSE StepPolicy;DEALLOCATE StepPolicy;

 BEGIN TRAN;
 DECLARE @LockResult int;EXEC @LockResult=sys.sp_getapplock @Resource=N'SqlAccessAdmin.AccessRequestCreate',@LockMode='Exclusive',@LockOwner='Transaction',@LockTimeout=10000;
 IF @LockResult<0 THROW 51317,'No fue posible bloquear el registro de solicitudes.',1;
 IF @OperationCode IN('CREATE_SQL_LOGIN','CREATE_WINDOWS_LOGIN','CLONE_PERMISSIONS') AND EXISTS
 (
  SELECT 1 FROM [access].AccessRequest r
  JOIN [access].AccessRequestTarget t ON t.RequestId=r.RequestId
  JOIN @Targets requested ON requested.ServerId=t.ServerId
  WHERE r.Status IN('PENDING','APPROVED') AND r.OperationCode IN('CREATE_SQL_LOGIN','CREATE_WINDOWS_LOGIN','CLONE_PERMISSIONS')
   AND UPPER(LTRIM(RTRIM(r.TargetPrincipal)))=UPPER(LTRIM(RTRIM(@TargetPrincipal)))
 )
 BEGIN ROLLBACK;THROW 51346,'Ya existe una solicitud activa para crear el mismo login en este servidor.',1;END;
 DECLARE @ExistingRequestId bigint;
 SELECT TOP(1) @ExistingRequestId=r.RequestId FROM [access].AccessRequest r WITH(UPDLOCK,HOLDLOCK)
 WHERE r.Status IN('PENDING','APPROVED') AND r.OperationCode=@OperationCode
  AND UPPER(LTRIM(RTRIM(r.TargetPrincipal)))=UPPER(LTRIM(RTRIM(@TargetPrincipal)))
  AND NOT EXISTS(SELECT ServerId,DatabaseName FROM @Targets EXCEPT SELECT ServerId,DatabaseName FROM [access].AccessRequestTarget WHERE RequestId=r.RequestId)
  AND NOT EXISTS(SELECT ServerId,DatabaseName FROM [access].AccessRequestTarget WHERE RequestId=r.RequestId EXCEPT SELECT ServerId,DatabaseName FROM @Targets)
  AND (@OperationCode IN('CREATE_SQL_LOGIN','CREATE_WINDOWS_LOGIN') OR
  (
   ISNULL(r.SourcePrincipal,N'')=ISNULL(@SourcePrincipal,N'') AND ISNULL(r.AuthenticationType,'')=ISNULL(@AuthenticationType,'')
   AND ISNULL(r.PermissionAction,'')=ISNULL(@PermissionAction,'') AND ISNULL(r.PermissionName,'')=ISNULL(@PermissionName,'')
   AND ISNULL(r.ScopeType,'')=ISNULL(@ScopeType,'') AND ISNULL(r.Securable,N'')=ISNULL(@Securable,N'') AND ISNULL(r.RoleName,N'')=ISNULL(@RoleName,N'')
   AND NOT EXISTS
   (
    SELECT StepOrder,OperationCode,PermissionAction,PermissionName,ScopeType,Securable,RoleName FROM @Steps
    EXCEPT
    SELECT StepOrder,OperationCode,PermissionAction,PermissionName,ScopeType,Securable,RoleName FROM [access].AccessRequestStep WHERE RequestId=r.RequestId
   )
   AND NOT EXISTS
   (
    SELECT StepOrder,OperationCode,PermissionAction,PermissionName,ScopeType,Securable,RoleName FROM [access].AccessRequestStep WHERE RequestId=r.RequestId
    EXCEPT
    SELECT StepOrder,OperationCode,PermissionAction,PermissionName,ScopeType,Securable,RoleName FROM @Steps
   )
  ))
 ORDER BY r.RequestId DESC;
 IF @ExistingRequestId IS NOT NULL
 BEGIN
  ROLLBACK;
  DECLARE @DuplicateMessage nvarchar(2048)=CONCAT(N'Ya existe la solicitud activa #',@ExistingRequestId,N' con el mismo plan de cambios y destinos.');
  THROW 51316,@DuplicateMessage,1;
 END;
 INSERT [access].AccessRequest(OperationCode,TargetPrincipal,SourcePrincipal,AuthenticationType,PermissionAction,PermissionName,ScopeType,Securable,RoleName,ExternalTicketNumber,Justification,
  SecretCiphertext,SecretNonce,SecretTag,SecretKeyId,PasswordPolicy,PasswordExpiration,MustChangePassword)
 VALUES(@OperationCode,@TargetPrincipal,@SourcePrincipal,@AuthenticationType,@PermissionAction,@PermissionName,@ScopeType,@Securable,@RoleName,@ExternalTicketNumber,@Justification,
  @SecretCiphertext,@SecretNonce,@SecretTag,@SecretKeyId,@PasswordPolicy,@PasswordExpiration,@MustChangePassword);
 DECLARE @Id bigint=SCOPE_IDENTITY();
 INSERT [access].AccessRequestTarget(RequestId,ServerId,DatabaseName) SELECT @Id,ServerId,DatabaseName FROM @Targets;
 INSERT [access].AccessRequestStep(RequestId,StepOrder,OperationCode,PermissionAction,PermissionName,ScopeType,Securable,RoleName)
  SELECT @Id,StepOrder,OperationCode,PermissionAction,PermissionName,ScopeType,Securable,RoleName FROM @Steps;
 COMMIT;
 DECLARE @ChangeCount int=1+(SELECT COUNT(*) FROM @Steps);
 DECLARE @AuditDetail nvarchar(2000)=CONCAT(N'Solicitud #',@Id,N' · ',@ExternalTicketNumber,N' · ',@ChangeCount,N' cambios · ',
  N'CHECK_POLICY=',IIF(@PasswordPolicy=1,N'ON',N'OFF'),N' · CHECK_EXPIRATION=',IIF(@PasswordExpiration=1,N'ON',N'OFF'),N' · MUST_CHANGE=',IIF(@MustChangePassword=1,N'ON',N'OFF'));
 EXEC [access].usp_Audit_Write N'Solicitudes',N'Crear',NULL,NULL,1,@AuditDetail;
 SELECT @Id RequestId,'PENDING' [Status];
END;
GO


MERGE [access].SecurityPolicyOperation AS target
USING (SELECT 'CLONE_PERMISSIONS' OperationCode) AS source ON target.OperationCode=source.OperationCode
WHEN MATCHED THEN UPDATE SET DisplayName=N'Copiar permisos a un usuario nuevo',Enabled=1,RequiresApproval=1,RiskLevel='HIGH',
 Description=N'Crea un login SQL y usuarios de base; copia solo roles y permisos autorizados del origen revisado.'
WHEN NOT MATCHED THEN INSERT(OperationCode,DisplayName,Enabled,RequiresApproval,RiskLevel,Description)
 VALUES(source.OperationCode,N'Copiar permisos a un usuario nuevo',1,1,'HIGH',N'Copia de accesos revisados a un login SQL nuevo.');
GO
DECLARE @Detail nvarchar(2000)=N'CLONE_PERMISSIONS habilitado: login SQL nuevo, contraseña cifrada y revisión del origen.';
EXEC [access].usp_Audit_Write N'Política central',N'Habilitar copia de permisos',NULL,NULL,1,@Detail;
GO
GRANT EXECUTE ON [access].usp_AccessRequest_Create TO [SqlAccessAdmin_Users];
GO
PRINT N'Copia de permisos a usuario nuevo habilitada. Reinicie la aplicación para recargar la política.';
GO

