using System.IO;
using System.Windows;
using System.Windows.Controls;
using SqlAccessAdmin.Models;
using SqlAccessAdmin.Views;

internal static partial class Program
{
    private static void RunFunctionPermissionChecks(string[] args)
    {
        var allPermissions=new HashSet<string>{"SELECT","INSERT","UPDATE","DELETE","EXECUTE"};
        var functions=new List<DatabaseObjectItem>();
        foreach(var type in new[]{"FN","FS","IF","TF","FT"})
        {
            var item=new DatabaseObjectItem(1,"CAEL","Ventas","dbo","fn_"+type,"FUNCTION"){SqlObjectType=type};
            functions.Add(item);
            var row=new ObjectPermissionRow(item,allPermissions);
            var scalar=type is "FN" or "FS";
            Check(row.CanExecute==scalar&&row.CanSelect!=scalar,"La función "+type+" habilita un permiso de uso incorrecto");
            Check(!row.CanInsert&&!row.CanUpdate&&!row.CanDelete,"La función "+type+" admite cambios de datos en la matriz");
            row.GrantExecute=true;row.GrantSelect=true;
            Check(row.SelectedPermissions.SequenceEqual(new[]{scalar?"EXECUTE":"SELECT"}),"La función "+type+" guarda un permiso incompatible");
            var blocked=new ObjectPermissionRow(item,new HashSet<string>());
            blocked.GrantSelect=true;blocked.GrantExecute=true;
            Check(!blocked.SelectedPermissions.Any(),"La función "+type+" omite la política central");
            Check(row.TypeDisplay.Contains("Función")&&item.DisplayName.Contains(row.TypeDisplay),"El catálogo no identifica la función "+type);
        }
        var unresolved=new ObjectPermissionRow(new(1,"CAEL","Ventas","dbo","fn_sin_tipo","FUNCTION"),allPermissions);
        Check(!unresolved.CanSelect&&!unresolved.CanExecute,"Una función sin tipo resuelto permite elegir permisos");
        var table=new DatabaseObjectItem(1,"CAEL","Ventas","dbo","Factura","TABLE");
        var procedure=new DatabaseObjectItem(1,"CAEL","Ventas","dbo","sp_Informe","PROCEDURE");
        var selector=new DatabaseObjectSelectorWindow(functions.Concat(new[]{table,procedure}),[]);
        selector.SelectedTypeFilter="Funciones";
        Check(selector.FilteredItems.Cast<DatabaseObjectSelectionItem>().Count()==5,"El filtro de funciones no incluye escalares, tabulares y CLR");
        selector.SearchText="escalar";
        Check(selector.FilteredItems.Cast<DatabaseObjectSelectionItem>().Count()==2,"No se pueden buscar funciones por su tipo en español");
        selector.SearchText="TF";
        Check(selector.FilteredItems.Cast<DatabaseObjectSelectionItem>().Single().Item.SqlObjectType=="TF","La búsqueda no reconoce el código SQL de la función");
        selector.Items.Single(x=>x.Item.SqlObjectType=="TF").IsSelected=true;
        selector.SelectedTypeFilter="Tablas";selector.SearchText="";
        Check(selector.FilteredItems.Cast<DatabaseObjectSelectionItem>().Single().Item==table,"El filtro de tablas incluye funciones");
        Check(selector.SelectedObjects.Single().SqlObjectType=="TF","Cambiar el filtro borra las funciones seleccionadas");
        selector.SelectedTypeFilter="Funciones";
        selector.ApplyTemplate();
        var selectorContent=(FrameworkElement)selector.Content;
        selectorContent.Measure(new Size(744,565));selectorContent.Arrange(new Rect(0,0,744,565));selectorContent.UpdateLayout();
        Check(((ComboBox)selector.FindName("ObjectTypeSelector")).SelectedItem as string=="Funciones","El filtro WPF no está enlazado");
        if(args.Length>4)
        {
            Directory.CreateDirectory(args[4]);
            selector.Content=null;
            var preview=new Border{Background=(System.Windows.Media.Brush)selector.FindResource("CanvasBrush"),DataContext=selector,Child=selectorContent};
            preview.Measure(new Size(744,565));preview.Arrange(new Rect(0,0,744,565));preview.UpdateLayout();
            RenderPreview(preview,Path.Combine(args[4],"selector-funciones.png"),744,565);
        }
        selector.Close();
    }
}
