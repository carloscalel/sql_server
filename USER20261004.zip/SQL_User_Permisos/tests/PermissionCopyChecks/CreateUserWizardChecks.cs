using System.Collections;
using System.Collections.ObjectModel;
using System.IO;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using SqlAccessAdmin.Infrastructure;
using SqlAccessAdmin.Models;
using SqlAccessAdmin.ViewModels;
using SqlAccessAdmin.Views;

internal static partial class Program
{
    private static void RunCreateUserWizardChecks(string[] args)
    {
        // Ejercita el VM real con catálogos simulados, sin inicializar servicios SQL.
        var vm=(AccessViewModel)RuntimeHelpers.GetUninitializedObject(typeof(AccessViewModel));
        void Field(string name,object value)=>typeof(AccessViewModel).GetField(name,BindingFlags.Instance|BindingFlags.NonPublic)!.SetValue(vm,value);
        object? Invoke(string name,params object[] values)=>typeof(AccessViewModel).GetMethod(name,BindingFlags.Instance|BindingFlags.NonPublic)!.Invoke(vm,values);
        Field("_operation",new PolicyOperation("CREATE_SQL_LOGIN","Crear login SQL",true,true,"HIGH",""));
        Field("_authenticationType","SQL");Field("_targetPrincipal","ventas_nuevo");
        Field("_externalTicketDigits","10542");Field("_justification","Crear acceso para el equipo de ventas");
        Field("_verifiedExternalTicket",new ExternalTicketDetails("soporte","ventas","10542","Crear acceso","Crear acceso para el equipo de ventas","Abierto"));
        Field("_temporaryPassword","UnaClaveSegura123!Ejemplo");Field("_temporaryPasswordConfirmation","UnaClaveSegura123!Ejemplo");
        Field("_selectedWorkingServer",new ServerItem{Id=1,Name="CAEL",IsSelected=true});
        Field("_isCreateLoginTargetAvailable",true);Field("_createLoginTargetValidationMessage","Nombre disponible");
        Field("_createUserDatabaseError","");
        Field("_createUserDatabasesLoaded",true);
        Field("<Databases>k__BackingField",new ObservableCollection<DatabaseItem>());
        Field("<Permissions>k__BackingField",new ObservableCollection<PolicyPermission>());
        Field("<InitialAccessRoleChoices>k__BackingField",new ObservableCollection<RoleSelectionItem>());
        Field("<InitialAccessPermissionChoices>k__BackingField",new ObservableCollection<PermissionSelectionItem>());
        Field("<PermissionChoices>k__BackingField",new ObservableCollection<PermissionSelectionItem>());
        Field("<ObjectPermissionRows>k__BackingField",new ObservableCollection<ObjectPermissionRow>());
        Field("<DatabaseRoleChoices>k__BackingField",new ObservableCollection<DatabaseRoleSelectionItem>());
        Field("<PreviewCommand>k__BackingField",new AsyncCommand(()=>Task.CompletedTask));
        Field("<SubmitCommand>k__BackingField",new AsyncCommand(()=>Task.CompletedTask,()=>vm.CanSubmitCreateUserWizard));
        Invoke("InitializeCreateUserWizard");
        Check(vm.IsExternalTicketValid&&vm.VerifiedTicketSummary.Contains("ventas")&&vm.VerifiedTicketSummary.Contains("soporte"),"Los datos útiles del ticket validado no quedan disponibles para la interfaz");
        Check(vm.IsCreateUserAccountStep&&vm.IsCreateUserFinalStep&&vm.CanSubmitCreateUserWizard,"El login sin accesos exige pasos opcionales");
        var master=new DatabaseItem{ServerId=1,Server="CAEL",Name="master"};
        (IReadOnlyList<DatabaseItem> Targets,IReadOnlyList<AccessRequestStepDraft> Steps) Plan()
        {
            var plans=((IEnumerable)Invoke("BuildSubmissionPlans",new List<DatabaseItem>{master})!).Cast<object>().ToList();
            Check(plans.Count==1,"Crear usuario genera más de una solicitud");
            var plan=plans[0];var type=plan.GetType();
            return ((IReadOnlyList<DatabaseItem>)type.GetProperty("Targets")!.GetValue(plan)!,
                (IReadOnlyList<AccessRequestStepDraft>)type.GetProperty("Steps")!.GetValue(plan)!);
        }
        var plan=Plan();
        Check(plan.Targets.Single().Name=="master"&&plan.Steps.Count==0,"El login sin mapeo conserva accesos ocultos");
        vm.Justification="corta";
        Check(!vm.CanSubmitCreateUserWizard&&vm.CreateUserStepValidationMessage.Contains("justificación"),"La justificación no bloquea el envío");
        vm.Justification="Crear acceso para el equipo de ventas";
        vm.ExternalTicketDigits="";Check(!vm.CanSubmitCreateUserWizard,"El ticket vacío no bloquea el envío");vm.ExternalTicketDigits="10542";
        Field("_verifiedExternalTicket",new ExternalTicketDetails("soporte","ventas","10542","Crear acceso","Crear acceso para el equipo de ventas","Abierto"));Invoke("RefreshCreateUserWizard");
        vm.TemporaryPasswordConfirmation="OtraClave123!";Check(!vm.CanSubmitCreateUserWizard,"El asistente ignora contraseñas diferentes");
        vm.TemporaryPasswordConfirmation=vm.TemporaryPassword;

        Field("_includeInitialAccess",true);Invoke("RefreshCreateUserWizard");
        Check(!vm.IsCreateUserFinalStep&&vm.CreateUserNextCommand.CanExecute(null),"No se puede avanzar al mapeo");
        vm.CreateUserNextCommand.Execute(null);
        Check(vm.IsCreateUserMappingStep&&!vm.CanSubmitCreateUserWizard,"El mapeo sin bases permite enviar");
        var sales=new DatabaseItem{ServerId=1,Server="CAEL",Name="Ventas"};
        var reports=new DatabaseItem{ServerId=1,Server="CAEL",Name="Reportes"};
        vm.Databases.Add(sales);vm.Databases.Add(reports);sales.IsSelected=true;
        Check(vm.IsCreateUserFinalStep&&vm.CanSubmitCreateUserWizard,"El mapeo exige roles o permisos innecesarios");
        Invoke("ValidateRequest");
        plan=Plan();Check(plan.Targets.Single().Name=="Ventas"&&plan.Steps.Single().Operation=="CREATE_DB_USER","El mapeo simple no crea el usuario de base");
        var role=new RoleSelectionItem(new("db_datareader","FIXED",true,"admin",DateTime.UtcNow,"")){IsSelected=true};
        vm.InitialAccessRoleChoices.Add(role);reports.IsSelected=true;
        plan=Plan();Check(plan.Targets.Count==2&&plan.Steps[1].Role=="db_datareader","El mapeo multibase pierde roles");
        vm.IncludeInitialObjectPermissions=true;
        Check(!vm.CreateUserNextCommand.CanExecute(null)&&vm.CreateUserStepValidationMessage.Contains("solo una"),"Los objetos pueden concederse accidentalmente en varias bases");
        Check(vm.CreateUserObjectDatabase=="","El contexto de objetos falla con múltiples bases");
        reports.IsSelected=false;vm.CreateUserNextCommand.Execute(null);
        Check(vm.IsCreateUserObjectsStep&&!vm.CanSubmitCreateUserWizard,"El paso de objetos vacío permite enviar");
        vm.Permissions.Add(new("SELECT","OBJECT",true,false,true,true,"admin",DateTime.UtcNow));
        vm.Permissions.Add(new("EXECUTE","OBJECT",true,false,true,true,"admin",DateTime.UtcNow));
        var table=new DatabaseObjectItem(1,"CAEL","Ventas","dbo","Factura","TABLE");
        var procedure=new DatabaseObjectItem(1,"CAEL","Ventas","dbo","sp_Informe","PROCEDURE");
        vm.ApplyCreateUserObjects([table,procedure]);
        var tableRow=vm.CreateUserObjectRows.Single(x=>x.Item==table);var procedureRow=vm.CreateUserObjectRows.Single(x=>x.Item==procedure);
        Check(tableRow.CanSelect&&!tableRow.CanExecute&&procedureRow.CanExecute&&!procedureRow.CanSelect,"La matriz admite permisos incompatibles con el objeto");
        tableRow.GrantSelect=true;procedureRow.GrantExecute=true;
        Check(vm.CanSubmitCreateUserWizard,"Los permisos de objeto válidos no habilitan el envío");
        plan=Plan();
        Check(plan.Targets.Count==1&&plan.Steps.Select(x=>x.Operation).SequenceEqual(new[]{"CREATE_DB_USER","ADD_ROLE_MEMBER","PERMISSION_CHANGE","PERMISSION_CHANGE"}),"El plan de creación no conserva el orden de ejecución");
        Check(plan.Steps.Where(x=>x.Scope=="OBJECT").Select(x=>x.Securable).ToHashSet().SetEquals(new[]{"dbo.Factura","dbo.sp_Informe"}),"Se pierde el destino de los permisos por objeto");
        Check(plan.Steps.Where(x=>x.Scope=="OBJECT").All(x=>x.PermissionAction=="GRANT"),"La creación concede acciones distintas de GRANT");
        vm.CreateUserPreviousCommand.Execute(null);
        Check(vm.IsCreateUserMappingStep&&vm.CreateUserObjectRows.Count==2&&tableRow.GrantSelect,"Anterior pierde los permisos seleccionados");
        vm.CreateUserPreviousCommand.Execute(null);
        Check(vm.IsCreateUserAccountStep&&vm.ExternalTicketDigits=="10542"&&vm.Justification.Contains("ventas")&&vm.TemporaryPasswordConfirmation==vm.TemporaryPassword,"Anterior pierde los datos generales");
        vm.CreateUserNextCommand.Execute(null);vm.CreateUserNextCommand.Execute(null);
        vm.ApplyCreateUserObjects([table,procedure]);
        Check(vm.CreateUserObjectRows.Single(x=>x.Item==table).GrantSelect,"Volver al selector borra permisos retenidos");
        vm.Permissions.Clear();Check(!vm.CanSubmitCreateUserWizard,"La revocación de política permite guardar un permiso antiguo");
        vm.Permissions.Add(new("SELECT","OBJECT",true,false,true,true,"admin",DateTime.UtcNow));
        vm.Permissions.Add(new("EXECUTE","OBJECT",true,false,true,true,"admin",DateTime.UtcNow));
        vm.SelectedCreateUserObjectRow=procedureRow;vm.RemoveCreateUserObjectCommand.Execute(null);
        Check(vm.CreateUserObjectRows.Count==1&&vm.CanSubmitCreateUserWizard,"Quitar un objeto destruye los permisos restantes");
        sales.IsSelected=false;reports.IsSelected=true;
        Check(vm.CreateUserObjectRows.Count==0&&!vm.CanSubmitCreateUserWizard,"Cambiar la base conserva objetos obsoletos");
        vm.ApplyCreateUserObjects([table]);Check(vm.CreateUserObjectRows.Count==0,"El selector acepta objetos de otra base");
        vm.IncludeInitialAccess=false;
        Check(vm.IncludeInitialObjectPermissions&&!role.IsSelected&&vm.Databases.All(x=>!x.IsSelected),"Quitar el mapeo desactiva los permisos por objeto o conserva roles ocultos");
        Check(ReferenceEquals(vm.SelectedCreateUserObjectDatabase,reports)&&vm.CreateUserObjectDatabaseChoices.Count==2,"El flujo de objetos sigue restringido al mapeo anterior");
        vm.SelectedCreateUserObjectDatabase=null;
        Check(!vm.CanAddCreateUserObjects&&!vm.CanSubmitCreateUserWizard&&vm.CreateUserStepValidationMessage.Contains("Seleccione la base"),"Los objetos permiten agregar sin seleccionar su propia base");
        vm.CreateUserPreviousCommand.Execute(null);
        Check(vm.IsCreateUserAccountStep&&!vm.IsCreateUserFinalStep&&vm.CreateUserNextCommand.CanExecute(null),"Solo objetos no vuelve directamente a la cuenta");
        vm.CreateUserNextCommand.Execute(null);
        Check(vm.IsCreateUserObjectsStep&&vm.CreateUserObjectsStepNumber==2&&vm.CreateUserStepTitle.StartsWith("Paso 2:"),"Solo objetos pasa por mapeo o muestra una numeración incorrecta");
        vm.SelectedCreateUserObjectDatabase=sales;
        Check(vm.CanAddCreateUserObjects&&!sales.IsSelected,"Seleccionar la base de objetos altera el mapeo");
        vm.ApplyCreateUserObjects([table]);vm.CreateUserObjectRows.Single().GrantSelect=true;
        role.IsSelected=true;
        vm.InitialAccessPermissionChoices.Add(new(new("SELECT","DATABASE",true,false,true,true,"admin",DateTime.UtcNow)){IsSelected=true});
        Invoke("ValidateRequest");plan=Plan();
        Check(plan.Targets.Count==1&&plan.Targets[0].Name=="Ventas"&&plan.Targets[0].IsSelected,"Solo objetos no incluye su base en la solicitud");
        Check(plan.Steps.Count==2&&plan.Steps[0].Operation=="CREATE_DB_USER"&&plan.Steps[1].Scope=="OBJECT","Solo objetos incluye roles o permisos generales ocultos");
        Check(vm.CanSubmitCreateUserWizard,"Solo objetos válido depende del check de mapeo");
        var realEditor=new AccessRequestEditor{DataContext=vm,Width=1200};
        void LayoutReal(){realEditor.Measure(new Size(1200,800));realEditor.Arrange(new Rect(0,0,1200,800));realEditor.UpdateLayout();}
        LayoutReal();
        var realDatabaseSelector=(ComboBox)realEditor.FindName("CreateUserObjectDatabaseSelector");
        Check(realDatabaseSelector.Items.Count==2&&ReferenceEquals(realDatabaseSelector.SelectedItem,sales),"El selector WPF real no muestra las bases del flujo independiente");
        Invoke("RefreshCreateUserWizard");LayoutReal();
        Check(ReferenceEquals(realDatabaseSelector.SelectedItem,sales)&&vm.CreateUserObjectRows.Count==1,"Actualizar la vista borra la base o los objetos seleccionados");
        Check(((Button)realEditor.FindName("CreateUserPreviousButton")).IsEnabled
            &&((Button)realEditor.FindName("CreateUserSubmitButton")).IsEnabled,"Los botones reales de solo objetos no se habilitan");
        realDatabaseSelector.SelectedItem=reports;LayoutReal();
        Check(ReferenceEquals(vm.SelectedCreateUserObjectDatabase,reports)&&vm.CreateUserObjectRows.Count==0,"El selector real no cambia la base o conserva objetos obsoletos");
        realDatabaseSelector.SelectedItem=sales;vm.ApplyCreateUserObjects([table]);vm.CreateUserObjectRows.Single().GrantSelect=true;LayoutReal();
        vm.CreateUserPreviousCommand.Execute(null);LayoutReal();
        Check(((CheckBox)realEditor.FindName("CreateUserMappingOption")).IsChecked==false
            &&((CheckBox)realEditor.FindName("CreateUserObjectsOption")).IsChecked==true,"Los checks reales no permiten solo objetos");
        vm.CreateUserNextCommand.Execute(null);LayoutReal();
        Check(vm.IsCreateUserObjectsStep&&((TextBlock)realEditor.FindName("CreateUserObjectsStepLabel")).Text=="2. Permisos a objetos","La navegación real muestra un paso saltado");
        vm.CreateUserPreviousCommand.Execute(null);vm.CreateUserNextCommand.Execute(null);
        Check(vm.CreateUserObjectRows.Single().GrantSelect&&vm.SelectedCreateUserObjectDatabase==sales,"Anterior pierde la base o los permisos del flujo de objetos");
        var scalarFunction=new DatabaseObjectItem(1,"CAEL","Ventas","dbo","fn_TotalFactura","FUNCTION"){SqlObjectType="FN"};
        var tableFunction=new DatabaseObjectItem(1,"CAEL","Ventas","dbo","fn_FacturasPorCliente","FUNCTION"){SqlObjectType="IF"};
        vm.ApplyCreateUserObjects([table,scalarFunction,tableFunction]);
        vm.CreateUserObjectRows.Single(x=>x.Item==scalarFunction).GrantExecute=true;
        vm.CreateUserObjectRows.Single(x=>x.Item==tableFunction).GrantSelect=true;
        Check(vm.CanSubmitCreateUserWizard,"El asistente no permite asignar permisos a funciones");
        plan=Plan();
        Check(plan.Steps.Any(x=>x.Securable=="dbo.fn_TotalFactura"&&x.Permission=="EXECUTE")
            &&plan.Steps.Any(x=>x.Securable=="dbo.fn_FacturasPorCliente"&&x.Permission=="SELECT"),"El plan no guarda los permisos específicos de cada función");
        LayoutReal();
        if(args.Length>4)RenderPreview(realEditor,Path.Combine(args[4],"crear-usuario-funciones.png"),1200,800);
        Field("_isLoadingCreateUserDatabases",true);
        Check(!vm.CanAddCreateUserObjects&&!vm.CanSubmitCreateUserWizard,"Solo objetos ignora una carga de bases pendiente");
        Field("_isLoadingCreateUserDatabases",false);Field("_createUserDatabaseError","Error de catálogo");
        Check(!vm.CanAddCreateUserObjects&&vm.CreateUserStepValidationMessage=="Error de catálogo","Solo objetos ignora un fallo de catálogo");
        Field("_createUserDatabaseError","");
        vm.SelectedCreateUserObjectDatabase=reports;
        Check(vm.CreateUserObjectRows.Count==0&&!vm.CanSubmitCreateUserWizard,"Cambiar la base propia conserva permisos de otra base");
        vm.SelectedCreateUserObjectDatabase=new DatabaseItem{ServerId=2,Server="Otro",Name="Ventas"};
        Check(!vm.CanAddCreateUserObjects,"El selector admite una base de otro servidor");
        vm.IncludeInitialObjectPermissions=false;
        Check(!vm.IncludeInitialAccess&&vm.SelectedCreateUserObjectDatabase is null&&vm.CreateUserObjectRows.Count==0,"Desactivar objetos activa mapeo o conserva su selección");
        Invoke("ResetCreateUserWizard");
        Check(vm.CreateUserStep==1&&vm.CanSubmitCreateUserWizard,"Reiniciar no vuelve al primer paso");
        Field("<Roles>k__BackingField",new ObservableCollection<PolicyRole>());
        var readPermission=new PolicyPermission("SELECT","DATABASE",true,false,true,true,"admin",DateTime.UnixEpoch);
        var writePermission=new PolicyPermission("UPDATE","DATABASE",true,false,true,true,"admin",DateTime.UnixEpoch);
        var readRole=new PolicyRole("db_datareader","FIXED",true,"admin",DateTime.UnixEpoch,"Lectura");
        var customRole=new PolicyRole("LecturaFacturas","CUSTOM",true,"admin",DateTime.UnixEpoch,"Lectura limitada");
        Field("_createUserPolicies",new Dictionary<string,(IReadOnlyList<PolicyPermission> Permissions,IReadOnlyList<PolicyRole> Roles)>
        {
            ["Ventas"]=([readPermission,writePermission],[readRole,customRole]),
            ["Reportes"]=([readPermission,writePermission with{AllowGrant=false}],[readRole])
        });
        Field("_includeInitialAccess",true);Field("_createUserDatabasesLoaded",true);
        sales.IsSelected=true;reports.IsSelected=false;Invoke("RefreshCreateUserScopedChoices");
        Check(vm.InitialAccessRoleChoices.Any(x=>x.Name=="LecturaFacturas")&&vm.InitialAccessPermissionChoices.Any(x=>x.Name=="UPDATE"),"El asistente omite la autorización específica de la base");
        vm.InitialAccessRoleChoices.Single(x=>x.Name=="LecturaFacturas").IsSelected=true;
        reports.IsSelected=true;
        Check(vm.InitialAccessRoleChoices.All(x=>x.Name!="LecturaFacturas")&&vm.InitialAccessPermissionChoices.All(x=>x.Name!="UPDATE"),"Un plan multibase incluye un rol o GRANT no autorizado en todas las bases");
        reports.IsSelected=false;
        Check(vm.InitialAccessRoleChoices.Any(x=>x.Name=="LecturaFacturas"&&!x.IsSelected),"Cambiar destinos reactiva un rol que quedó excluido");

        var context=new CopyPreviewContext{IsClonePermissionsOperation=false,IncludeInitialAccess=true,IncludeInitialObjectPermissions=true};
        context.Databases.Add(new(){ServerId=1,Server="CAEL",Name="Ventas",IsSelected=true});
        context.Databases.Add(new(){ServerId=1,Server="CAEL",Name="Reportes"});
        context.SelectedCreateUserObjectDatabase=context.Databases[0];
        context.InitialAccessRoleChoices.Add(new(new("db_datareader","FIXED",true,"admin",DateTime.UtcNow,"")){IsSelected=true});
        context.InitialAccessRoleChoices.Add(new(new("db_datawriter","FIXED",true,"admin",DateTime.UtcNow,"")));
        context.InitialAccessPermissionChoices.Add(new(new("SELECT","DATABASE",true,false,true,true,"admin",DateTime.UtcNow)));
        context.CreateUserObjectRows.Add(new(table,new HashSet<string>{"SELECT"}){GrantSelect=true});
        context.CreateUserObjectRows.Add(new(procedure,new HashSet<string>{"EXECUTE"}){GrantExecute=true});
        var editor=new AccessRequestEditor{DataContext=context,Width=1200};
        void Layout(){editor.Measure(new Size(1200,800));editor.Arrange(new Rect(0,0,1200,800));editor.UpdateLayout();}
        void Render(string name){if(args.Length<=4)return;Directory.CreateDirectory(args[4]);RenderPreview(editor,Path.Combine(args[4],name+".png"),1200,800);}
        Layout();
        Check(VisibleInTree((TextBox)editor.FindName("RequestTicketBox"),editor)&&VisibleInTree((TextBox)editor.FindName("RequestJustificationBox"),editor),"El primer paso no conserva ticket y justificación");
        Check(VisibleInTree((Button)editor.FindName("CreateUserNextButton"),editor)&&!VisibleInTree((Button)editor.FindName("CreateUserSubmitButton"),editor),"El primer paso permite omitir accesos pendientes");
        Render("crear-usuario-1-sql");context.IsWindowsAuthentication=true;Layout();Render("crear-usuario-1-windows");
        context.SetCreateStep(2);Layout();
        Check(VisibleInTree((DataGrid)editor.FindName("CreateUserDatabaseGrid"),editor)&&!VisibleInTree((TextBox)editor.FindName("RequestTicketBox"),editor),"El mapeo muestra datos del primer paso");
        Check(!VisibleInTree((RadioButton)editor.FindName("SqlAuthenticationOption"),editor),"El mapeo muestra credenciales");
        var activeStep=Descendants(editor).OfType<Border>().Single(x=>x.Tag is true);
        Check(((SolidColorBrush)activeStep.Background).Color==Color.FromRgb(229,237,255),"El indicador lateral no destaca el paso activo");
        Render("crear-usuario-2-mapeo");context.SetCreateStep(3);Layout();
        Check(VisibleInTree((DataGrid)editor.FindName("CreateUserObjectGrid"),editor)&&VisibleInTree((Button)editor.FindName("CreateUserSubmitButton"),editor),"El último paso no muestra matriz o envío");
        Check(!VisibleInTree((Button)editor.FindName("CreateUserNextButton"),editor),"El último paso muestra Siguiente");
        Render("crear-usuario-3-objetos");
        Check(VisibleInTree((ComboBox)editor.FindName("CreateUserObjectDatabaseSelector"),editor),"El paso de objetos no incluye selector de base");
        context.IncludeInitialAccess=false;context.SetCreateStep(1);Layout();
        Check(!((CheckBox)editor.FindName("CreateUserMappingOption")).IsChecked.GetValueOrDefault()
            &&((CheckBox)editor.FindName("CreateUserObjectsOption")).IsChecked.GetValueOrDefault(),"Solo objetos obliga a marcar el mapeo en la vista");
        context.CreateUserNextCommand.Execute(null);Layout();
        Check(VisibleInTree((DataGrid)editor.FindName("CreateUserObjectGrid"),editor)&&!VisibleInTree((DataGrid)editor.FindName("CreateUserDatabaseGrid"),editor),"La vista de solo objetos pasa por mapeo");
        Check(((TextBlock)editor.FindName("CreateUserObjectsStepLabel")).Text=="2. Permisos a objetos","El indicador lateral no renumera solo objetos");
        Render("crear-usuario-solo-objetos");
        Check(((Button)editor.FindName("CreateUserSubmitButton")).TransformToAncestor(editor).Transform(new Point()).Y<800,"El botón final queda fuera de la pantalla");
    }
}
