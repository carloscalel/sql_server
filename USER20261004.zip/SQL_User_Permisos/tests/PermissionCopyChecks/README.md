# Comprobaciones de accesos SQL

Ejecutar en Windows con .NET 8:

```powershell
dotnet run --project tests/PermissionCopyChecks/PermissionCopyChecks.csproj -c Release
```

El ejecutable verifica huellas del origen, cambios de política, delimitación de identificadores, roles protegidos, ámbitos/acciones prohibidos, delegación, validación de contraseña y contexto del formulario. Comprueba además el guardado/lectura JSON del plan, nombres de origen diferentes por base, Unicode, destinos incompletos o duplicados, separación de permisos entre tres bases y conservación del detalle en el historial. Construye el editor y la confirmación WPF sin abrir ventanas para comprobar sus enlaces y el listado completo de cambios. No abre conexiones ni ejecuta cambios en SQL Server.

También verifica la selección exclusiva SQL/Windows en creación y copia, los tipos conservados en el borrador y el historial, la limpieza de contraseñas al alternar, el rechazo de identidades o secretos incompatibles y la generación delimitada de `CREATE LOGIN [...] FROM WINDOWS`.

Las comprobaciones de nombres usan consultas simuladas para verificar bloqueo previo, progreso, check verde, X roja, fallos de permisos, respuesta tardía tras cambiar el nombre o la autenticación y comprobación ligada al servidor. También verifican que `xp_logininfo` solo se acepte con retorno entero `0`, sin depender de filas de accesos SQL. Los enlaces WPF de Comprobar nombres se comprueban en los dos formularios y se ocultan para SQL authentication. La resolución Windows real y el permiso sobre `xp_logininfo` deben probarse en CAEL.

El asistente de Crear usuario se comprueba con el VM real y catálogos simulados: ticket y justificación obligatorios, navegación y conservación de datos, login sin accesos, mapeo sin roles, roles multibase, opciones de mapeo/objetos independientes, salto directo a objetos y numeración dinámica, selección de base en el paso de objetos, descarte de roles o permisos generales ocultos, matriz según tipo y política, orden de pasos, eliminación de objetos y descarte al cambiar de base. Se verifican también las vistas WPF, el enlace del selector de base al VM real y los botones visibles en cada paso.

También comprueba las funciones escalares SQL/CLR (`FN`, `FS`) y tabulares (`IF`, `TF`, `FT`): permisos de uso compatibles, bloqueo por política, búsqueda y filtro por tipo sin perder la selección, enlace WPF y conservación de `EXECUTE`/`SELECT` en el plan de creación. Las funciones sin tipo resuelto no permiten seleccionar permisos.

Opcionalmente pase una ruta PNG para renderizar el formulario SQL y una segunda ruta para renderizar la solicitud de confirmación con datos simulados; una tercera renderiza Copiar permisos Windows y una cuarta Crear usuario Windows. Un quinto argumento indica la carpeta donde guardar las vistas del asistente (General SQL, General Windows, Mapeo, Objetos combinados, Solo objetos y Funciones) a 1200×800, además del selector filtrado por funciones. Las pruebas contra SQL Server real y los pasos de instalación se describen en `InsumosProduccion/README.md`.
