using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Reflection;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using SqlAccessAdmin;
using SqlAccessAdmin.Data;
using SqlAccessAdmin.Models;
using SqlAccessAdmin.Views;
using SqlAccessAdmin.ViewModels;
using System.Runtime.CompilerServices;

internal static partial class Program
{
    private static int _checks;
    private static void Check(bool value,string description)
    {if(!value)throw new InvalidOperationException(description);_checks++;}
    private static object? Call(string name,params object[] args)=>typeof(DirectSqlServerService)
        .GetMethod(name,BindingFlags.Static|BindingFlags.NonPublic)!.Invoke(null,args);
    private static void Reject(PermissionCopyAccessItem item)
    {
        Check(!(bool)Call("IsCopyAccessSupported",item)!,"El acceso prohibido se considera copiable");
        try{Call("BuildCopiedAccessSql",item,"nuevo");throw new Exception("Se generó SQL para un acceso prohibido");}
        catch(TargetInvocationException exception)when(exception.InnerException is InvalidOperationException){_checks++;}
    }
    [STAThread]
    private static void Main(string[] args)
    {
        try{RunChecks(args);}
        catch(Exception error){Console.Error.WriteLine(error);Environment.ExitCode=1;}
    }
    private static void RunChecks(string[] args)
    {
        var item=new PermissionCopyAccessItem("Ventas","Permiso","GRANT","SELECT","OBJECT","dbo","Factura","","",true,"Copiar");
        var role=item with{Kind="Rol",Role="db_datareader",Permission="",Scope="DATABASE",State="Asignado"};
        var fingerprint=PermissionCopyAccessItem.Fingerprint(new[]{item,role});
        Check(fingerprint.Length==64,"Huella inválida");
        Check(fingerprint==PermissionCopyAccessItem.Fingerprint(new[]{role,item}),"La huella depende del orden de consulta");
        foreach(var changed in new[]{item with{Object="Otra"},item with{CanCopy=false},item with{State="DENY"},item with{Database="Otra"},item with{Permission="UPDATE"},item with{Schema="ventas"}})
            Check(fingerprint!=PermissionCopyAccessItem.Fingerprint(new[]{changed,role}),"No se detectó un cambio del origen/política");
        Check(PermissionCopyAccessItem.Fingerprint(new[]{item with{Schema="a|b",Object="c"}})!=
            PermissionCopyAccessItem.Fingerprint(new[]{item with{Schema="a",Object="b|c"}}),"Colisión por separadores en identificadores");
        Check((string)Call("BuildCopiedAccessSql",item,"nuevo")! == "GRANT SELECT ON OBJECT::[dbo].[Factura] TO [nuevo]","GRANT inválido");
        Check((string)Call("BuildCopiedAccessSql",item with{Schema="s.x",Object="t]x"},"u]x")! ==
            "GRANT SELECT ON OBJECT::[s.x].[t]]x] TO [u]]x]","Identificadores SQL sin delimitar");
        Check((string)Call("BuildCopiedAccessSql",role,"nuevo")! == "ALTER ROLE [db_datareader] ADD MEMBER [nuevo]","Membresía inválida");
        Check((string)Call("BuildCopiedAccessSql",item with{Scope="DATABASE",Schema="",Object=""},"nuevo")! == "GRANT SELECT TO [nuevo]","GRANT DATABASE inválido");
        Check(!((string)Call("BuildCopiedAccessSql",item with{State="GRANT_WITH_GRANT_OPTION"},"nuevo")!).Contains("WITH GRANT OPTION"),"Se delegaron permisos");
        Reject(item with{State="DENY"});Reject(item with{State="REVOKE"});Reject(item with{Scope="SCHEMA"});Reject(item with{Scope="COLUMN"});Reject(item with{Permission="CONTROL; DROP TABLE x"});Reject(item with{Object=""});
        Reject(role with{Role="public"});
        Check((string)Call("BuildCopiedAccessSql",item with{Permission="CONTROL"},"nuevo")! == "GRANT CONTROL ON OBJECT::[dbo].[Factura] TO [nuevo]","Un permiso ampliado autorizado no se puede generar");
        foreach(var sensitiveRole in new[]{"db_owner","db_securityadmin","db_accessadmin","db_ddladmin","db_backupoperator"})
        {
            var policy=new PolicyRole(sensitiveRole,"FIXED",true,"admin",DateTime.UtcNow,"");
            try { Call("ValidateRolePolicySnapshot",sensitiveRole,new[]{policy},Array.Empty<DenyRule>()); throw new Exception("Rol sensible sin autorización"); }
            catch(TargetInvocationException exception)when(exception.InnerException is InvalidOperationException){_checks++;}
            Call("ValidateRolePolicySnapshot",sensitiveRole,new[]{policy with{SpecialActivationApproved=true}},Array.Empty<DenyRule>());
            Check((string)Call("BuildCopiedAccessSql",role with{Role=sensitiveRole},"nuevo")! == $"ALTER ROLE [{sensitiveRole}] ADD MEMBER [nuevo]","No se genera una membresía de base autorizada");
        }
        try{Call("BuildCopiedAccessSql",item with{CanCopy=false},"nuevo");throw new Exception("Se ignoró la política");}
        catch(TargetInvocationException exception)when(exception.InnerException is InvalidOperationException){_checks++;}

        // Una base con error no debe borrar el catálogo de las demás ni ocultar que está incompleto.
        var catalogDatabases=new[]{"Ventas","Inaccesible","Reportes"}
            .Select(name=>new DatabaseItem{ServerId=1,Server="CAEL",Name=name}).ToArray();
        var consulted=new List<string>();
        Func<DatabaseItem,CancellationToken,Task<IReadOnlyList<PermissionCopySourceUser>>> readUsers=(database,ct)=>
        {
            consulted.Add(database.Name);
            return database.Name=="Inaccesible"
                ?Task.FromException<IReadOnlyList<PermissionCopySourceUser>>(new InvalidOperationException("Sin acceso a la base"))
                :Task.FromResult<IReadOnlyList<PermissionCopySourceUser>>([new(database.Name=="Ventas"?"origen":"ORIGEN",database.Name+"_usuario")]);
        };
        var catalogTask=(Task<(Dictionary<string,List<DatabaseItem>> Sources,List<string> Errors)>)Call(
            "ReadCopySourceCatalogAsync",catalogDatabases,readUsers,(Action<string>)(_=>{}),CancellationToken.None)!;
        var catalog=catalogTask.GetAwaiter().GetResult();
        Check(consulted.SequenceEqual(new[]{"Ventas","Inaccesible","Reportes"}),"Una base fallida impide consultar las siguientes");
        Check(catalog.Sources.Count==1&&catalog.Sources["origen"].Count==2,"Se pierden los usuarios de las bases que respondieron");
        Check(catalog.Sources["origen"][1].CopySourceUser=="Reportes_usuario","El catálogo pierde el usuario de cada base");
        Check(catalog.Errors.Count==1&&catalog.Errors[0].Contains("Inaccesible: Sin acceso"),"El catálogo oculta la base que falló");
        consulted.Clear();
        using(var cancelled=new CancellationTokenSource())
        {
            cancelled.Cancel();
            var cancelledTask=(Task<(Dictionary<string,List<DatabaseItem>>,List<string>)>)Call(
                "ReadCopySourceCatalogAsync",catalogDatabases,readUsers,(Action<string>)(_=>{}),cancelled.Token)!;
            try{cancelledTask.GetAwaiter().GetResult();throw new Exception("Se ignoró la cancelación del catálogo");}
            catch(OperationCanceledException){_checks++;}
            Check(consulted.Count==0,"Una carga cancelada sigue consultando bases");
        }

        // Verifica las reglas del VM sin ejecutar su inicialización ni conectarse a SQL.
        var vm=(AccessViewModel)RuntimeHelpers.GetUninitializedObject(typeof(AccessViewModel));
        void Field(string name,object value)=>typeof(AccessViewModel).GetField(name,BindingFlags.Instance|BindingFlags.NonPublic)!.SetValue(vm,value);
        Field("_operation",new PolicyOperation("CLONE_PERMISSIONS","Copiar",true,true,"HIGH",""));
        Field("_authenticationType","SQL");
        Field("_temporaryPassword","");Field("_temporaryPasswordConfirmation","");
        Check(vm.RequiresTemporaryPassword&&!vm.IsTemporaryPasswordValid,"La copia permite omitir la contraseña temporal");
        Check(vm.HasTopRequestDetails&&!vm.HasBottomRequestDetails&&!vm.IsBasicIdentityOperation&&!vm.IsStandardDatabaseOperation,"Se muestran los bloques heredados de copia");
        Field("_temporaryPassword","UnaClaveSegura123!Ejemplo");Field("_temporaryPasswordConfirmation","OtraClaveSegura123!Ejemplo");
        Check(!vm.IsTemporaryPasswordValid,"Se aceptan contraseñas diferentes");
        Field("_temporaryPasswordConfirmation","UnaClaveSegura123!Ejemplo");
        Check(vm.IsTemporaryPasswordValid,"Se rechaza una contraseña segura confirmada");
        Field("<CopySourceAccesses>k__BackingField",new ObservableCollection<PermissionCopyAccessItem>{item});
        Field("_copyAccessLoaded",true);Field("_copyTargetAvailable",true);Field("_copyCatalogComplete",true);
        Check(vm.CanSubmitPermissionCopy,"Se bloquea una copia con catálogo y accesos completos");
        Field("_copyCatalogComplete",false);
        Check(!vm.CanSubmitPermissionCopy,"Se permite enviar una copia tras fallar la consulta de una base");
        Field("_copyCatalogComplete",true);Field("_isLoadingCopySources",true);
        Check(!vm.CanSubmitPermissionCopy,"Se permite enviar mientras se consulta el catálogo");
        Field("<Databases>k__BackingField",new ObservableCollection<DatabaseItem>());
        Field("_copySourceDatabases",new Dictionary<string,List<DatabaseItem>>());
        Field("_selectedCopySource","origen");
        using(var catalogCancellation=new CancellationTokenSource())
        using(var accessCancellation=new CancellationTokenSource())
        {
            Field("_copyCatalogCancellation",catalogCancellation);Field("_copyLoadCancellation",accessCancellation);
            vm.SelectedCopySource=null;
            Check(!catalogCancellation.IsCancellationRequested,"Limpiar la selección cancela la carga del catálogo de usuarios");
            Check(accessCancellation.IsCancellationRequested,"Limpiar la selección no cancela los permisos del usuario anterior");
        }
        var request=new AccessRequestItem(1,"CLONE_PERMISSIONS","nuevo","origen","SQL","","","",fingerprint,"","TIC-RF-1","Copia de ejemplo","PENDING","operador",DateTime.Now,"",null,2,0);
        Check(request.RequestTitle.Contains("usuario nuevo")&&request.Changes[0].Description.Contains("origen")&&request.Changes[0].Description.Contains("nuevo"),"La confirmación no identifica el origen y destino");
        var other=item with{Database="Contabilidad",Permission="UPDATE"};
        var excluded=other with{Permission="CONTROL",CanCopy=false,CopyStatus="Excluido"};
        var multiPlan=new PermissionCopyPlan(2,new[]
        {
            new PermissionCopyDatabasePlan("Ventas","ventas_origen",new[]{item,role}),
            new PermissionCopyDatabasePlan("Contabilidad","conta_origen",new[]{other,excluded}),
            new PermissionCopyDatabasePlan("Reportes","lector_origen",new[]{item with{Database="Reportes",Scope="DATABASE",Schema="",Object=""}})
        });
        var roundTrip=PermissionCopyPlan.FromJson(multiPlan.ToJson());
        Check(multiPlan.Fingerprint==roundTrip.Fingerprint,"El detalle cambia al guardarse y recuperarse como JSON");
        Check(multiPlan.ChangeCount==8,"El contador no incluye login, usuarios y accesos de todas las bases");
        var changes=multiPlan.DescribeChanges("nuevo");
        Check(changes.Count==8&&!changes.Any(x=>x.Description.Contains("CONTROL")),"Las exclusiones se ejecutan o se cuentan como accesos concedidos");
        Check(changes.Any(x=>x.Description=="[Ventas] Conceder SELECT · dbo.Factura"),"Falta el SELECT de Ventas");
        Check(changes.Any(x=>x.Description=="[Contabilidad] Conceder UPDATE · dbo.Factura"),"Falta el UPDATE de Contabilidad");
        Check(!changes.Any(x=>x.Description=="[Ventas] Conceder UPDATE · dbo.Factura"),"Se mezclan permisos entre bases");
        Check(changes.Any(x=>x.Description.Contains("[Contabilidad]")&&x.Description.Contains("conta_origen")),"Se pierde el usuario específico de una base");
        var reversed=multiPlan with{Databases=multiPlan.Databases.Reverse().Select(x=>x with{Accesses=x.Accesses.Reverse().ToList()}).ToList()};
        Check(multiPlan.Fingerprint==reversed.Fingerprint,"La huella del plan depende del orden de consulta");
        Check(multiPlan.Fingerprint!=(multiPlan with{Databases=multiPlan.Databases.Take(2).ToList()}).Fingerprint,"No se detecta una base faltante");
        Check(multiPlan.Fingerprint!=(multiPlan with{Databases=multiPlan.Databases.Select(x=>x with{SourceUser="otro"}).ToList()}).Fingerprint,"No se detecta un cambio de usuario origen");
        var targets=multiPlan.Databases.Select(x=>new DatabaseItem{ServerId=1,Name=x.Database}).ToArray();
        Call("ValidateCopyPlanTargets",multiPlan,targets);_checks++;
        try{Call("ValidateCopyPlanTargets",multiPlan,targets.Take(2).ToArray());throw new Exception("Se aceptaron destinos incompletos");}
        catch(TargetInvocationException error)when(error.InnerException is InvalidOperationException){_checks++;}
        try{Call("ValidateCopyPlanTargets",multiPlan,targets.Append(targets[0]).ToArray());throw new Exception("Se aceptó una base duplicada");}
        catch(TargetInvocationException error)when(error.InnerException is InvalidOperationException){_checks++;}
        var unicode=multiPlan with{Databases=new[]{new PermissionCopyDatabasePlan("Nómina","José",new[]{item with{Database="Nómina",Object="Detalle💼"}})}};
        Check(unicode.Fingerprint==PermissionCopyPlan.FromJson(unicode.ToJson()).Fingerprint,"Se pierde información Unicode al guardar el plan");
        var copyRequest=request with{CopyPlan=roundTrip,Securable=roundTrip.Fingerprint,TargetCount=3,DestinationSummary="CAEL / Ventas, CAEL / Contabilidad, CAEL / Reportes"};
        Check(copyRequest.ChangeCount==copyRequest.Changes.Count&&copyRequest.ChangesTitle.Contains("8"),"La tarjeta muestra el contador genérico de copia");
        Check(copyRequest.Changes.SequenceEqual((copyRequest with{Status="EXECUTED"}).Changes),"El historial pierde el detalle de los accesos de la solicitud");
        var windowsCopy=copyRequest with{AuthenticationType="WINDOWS",TargetPrincipal=@"CAEL\cael_test01"};
        Check(windowsCopy.Changes[0].Description==@"Crear login Windows CAEL\cael_test01","La copia Windows se describe como login SQL");
        Check(windowsCopy.AuthenticationDisplay=="Windows authentication"&&copyRequest.AuthenticationDisplay=="SQL authentication","No se distingue el tipo guardado en confirmación e historial");
        Check(windowsCopy.Changes.Skip(1).Count()==copyRequest.Changes.Skip(1).Count(),"Windows pierde cambios de acceso del plan multibase");

        Check((string)Call("BuildWindowsLoginSql",@"CAEL\cael_test01")! == @"CREATE LOGIN [CAEL\cael_test01] FROM WINDOWS","La creación Windows incluye contraseña o sintaxis incorrecta");
        Check((string)Call("BuildWindowsLoginSql",@"DOMINIO\u]x")! == @"CREATE LOGIN [DOMINIO\u]]x] FROM WINDOWS","El nombre Windows no queda delimitado");
        foreach(var operation in new[]{"CREATE_SQL_LOGIN","CREATE_WINDOWS_LOGIN","CLONE_PERMISSIONS"})
        foreach(var auth in new[]{"SQL","WINDOWS"})
        {
            var valid=operation=="CLONE_PERMISSIONS"||operation==LoginAuthentication.CreationOperation(auth);
            try
            {
                LoginAuthentication.ValidateSecret(operation,auth=="WINDOWS"?@"CAEL\usuario":"usuario",auth,auth=="SQL");
                Check(valid,"Se acepta una operación con otra autenticación");
            }
            catch(InvalidOperationException){Check(!valid,"Se rechaza una autenticación compatible");}
        }
        void RejectIdentity(string operation,string target,string? auth,bool secret)
        {
            try{LoginAuthentication.ValidateSecret(operation,target,auth,secret);}
            catch(InvalidOperationException){_checks++;return;}
            throw new InvalidOperationException("Se acepta una identidad o secreto incompatible: "+target);
        }
        foreach(var invalid in new[]{"usuario","usuario@dominio",@"\usuario",@"CAEL\",@"CAEL\u\otro",@" CAEL\usuario",@"CAEL \usuario",@"CAEL\ usuario","CAEL\\u\n"})
            RejectIdentity("CREATE_WINDOWS_LOGIN",invalid,"WINDOWS",false);
        RejectIdentity("CREATE_SQL_LOGIN",@"CAEL\usuario","SQL",true);
        RejectIdentity("CLONE_PERMISSIONS","usuario",null,true);
        RejectIdentity("CLONE_PERMISSIONS","usuario","SQL,WINDOWS",true);
        RejectIdentity("CREATE_SQL_LOGIN","usuario","SQL",false);
        RejectIdentity("CLONE_PERMISSIONS",@"CAEL\usuario","WINDOWS",true);
        RejectIdentity("CREATE_WINDOWS_LOGIN",@"CAEL\usuario","WINDOWS",true);
        RejectIdentity("CREATE_WINDOWS_LOGIN",@"CAEL\"+new string('u',124),"WINDOWS",false);

        // Cambia el VM real sin inicialización ni conexión: conserva el plan y borra secretos.
        Field("<PreviewCommand>k__BackingField",new SqlAccessAdmin.Infrastructure.AsyncCommand(()=>Task.CompletedTask));
        Field("<SubmitCommand>k__BackingField",new SqlAccessAdmin.Infrastructure.AsyncCommand(()=>Task.CompletedTask));
        Field("<Operations>k__BackingField",new ObservableCollection<PolicyOperation>
        {
            new("CREATE_SQL_LOGIN","Crear login SQL",true,true,"HIGH",""),
            new("CREATE_WINDOWS_LOGIN","Crear login Windows",true,true,"HIGH","")
        });
        Field("_targetPrincipal",@"CAEL\usuario");
        Field("_temporaryPassword","UnaClaveSegura123!Ejemplo");Field("_temporaryPasswordConfirmation","UnaClaveSegura123!Ejemplo");
        Field("_selectedCopySource","origen");
        vm.CopySourceAccesses.Add(item);
        vm.IsWindowsAuthentication=true;
        Check(vm.IsWindowsAuthentication&&!vm.IsSqlAuthentication&&!vm.RequiresTemporaryPassword&&vm.IsTemporaryPasswordValid,"Windows requiere una contraseña SQL");
        Check(vm.TemporaryPassword.Length==0&&vm.TemporaryPasswordConfirmation.Length==0,"Cambiar a Windows conserva contraseñas");
        Check(vm.IsClonePermissionsOperation&&vm.SelectedCopySource=="origen"&&vm.CopySourceAccesses.Count==1,"Cambiar autenticación destruye el origen o el plan de copia");
        Field("_externalTicketDigits","10542");Field("_justification","Crear acceso inicial de ejemplo");
        var draftMethod=typeof(AccessViewModel).GetMethod("Draft",BindingFlags.Instance|BindingFlags.NonPublic)!;
        var windowsDraft=(AccessRequestDraft)draftMethod.Invoke(vm,new object?[]{null,null,null})!;
        Check(windowsDraft.Operation=="CLONE_PERMISSIONS"&&windowsDraft.AuthenticationType=="WINDOWS","La copia Windows se guarda como SQL");
        vm.IsSqlAuthentication=true;
        Check(vm.IsSqlAuthentication&&!vm.IsWindowsAuthentication&&vm.RequiresTemporaryPassword&&!vm.IsTemporaryPasswordValid,"Volver a SQL reutiliza una contraseña anterior");
        Field("_operation",new PolicyOperation("CREATE_SQL_LOGIN","Crear login SQL",true,true,"HIGH",""));
        Field("_externalTicketDigits","10542");Field("_justification","Crear acceso inicial de ejemplo");Field("_includeInitialAccess",true);
        vm.IsWindowsAuthentication=true;
        Check(vm.SelectedOperation?.Code=="CREATE_WINDOWS_LOGIN"&&vm.IncludeInitialAccess&&vm.ExternalTicketDigits=="10542"&&vm.Justification.Contains("ejemplo"),"Cambiar a Windows borra los datos de creación o conserva la operación SQL");
        Check(vm.RequiresAuthenticationType&&!vm.RequiresTemporaryPassword&&vm.TargetPrincipalLabel.Contains("Windows"),"Crear Windows no actualiza el formulario");
        windowsDraft=(AccessRequestDraft)draftMethod.Invoke(vm,new object?[]{null,null,null})!;
        Check(windowsDraft.Operation=="CREATE_WINDOWS_LOGIN"&&windowsDraft.AuthenticationType=="WINDOWS","La creación Windows se guarda como SQL");
        Check(!vm.CanUseValidatedWindowsName,"Crear Windows permite omitir Comprobar nombres");
        Call("ValidateWindowsAccountReturnCode",0);_checks++;
        foreach(var badReturn in new object?[]{1,-1,null,DBNull.Value,"0"})
        {
            try{Call("ValidateWindowsAccountReturnCode",new object[]{badReturn!});throw new Exception("Se acepta una comprobación Windows sin retorno 0");}
            catch(TargetInvocationException error)when(error.InnerException is InvalidOperationException){_checks++;}
        }
        Field("_selectedWorkingServer",new ServerItem{Id=1,Name="CAEL"});
        var checkNameMethod=typeof(AccessViewModel).GetMethod("CheckWindowsNameAsync",BindingFlags.Instance|BindingFlags.NonPublic)!;
        Task CheckName(Func<int,string,CancellationToken,Task> callback)=>(Task)checkNameMethod.Invoke(vm,new object[]{callback})!;
        var nameChecks=0;
        CheckName((serverId,name,ct)=>
        {
            Check(serverId==1&&name==@"CAEL\usuario","Comprobar nombres usa otra cuenta o servidor");
            nameChecks++;return Task.CompletedTask;
        }).GetAwaiter().GetResult();
        Check(nameChecks==1&&vm.IsWindowsNameValidated&&vm.CanUseValidatedWindowsName,"Una cuenta Windows comprobada no habilita el envío");
        Check(vm.WindowsNameValidationIcon=="✓"&&vm.WindowsNameValidationForeground=="#15803D","Una cuenta comprobada no muestra check verde");
        CheckName((_,_,_)=>Task.FromException(new InvalidOperationException("Cuenta inexistente"))).GetAwaiter().GetResult();
        Check(!vm.IsWindowsNameValidated&&!vm.CanUseValidatedWindowsName&&vm.WindowsNameValidationMessage=="Cuenta inexistente","Una cuenta inexistente permite enviar");
        Check(vm.WindowsNameValidationIcon=="✕"&&vm.WindowsNameValidationForeground=="#B42318","Una cuenta inválida no muestra X roja");
        CheckName((_,_,_)=>Task.FromException(new InvalidOperationException("Sin permisos de consulta"))).GetAwaiter().GetResult();
        Check(!vm.CanUseValidatedWindowsName&&vm.WindowsNameValidationMessage.Contains("Sin permisos"),"Un error técnico se convierte en validación positiva");
        var pendingName=new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
        var pendingNameTask=CheckName((_,_,_)=>pendingName.Task);
        Check(vm.IsCheckingWindowsName&&!vm.CanUseValidatedWindowsName&&vm.WindowsNameValidationIcon=="…","Se habilita el envío durante la comprobación");
        vm.TargetPrincipal="";
        pendingName.SetResult();pendingNameTask.GetAwaiter().GetResult();
        Check(!vm.IsWindowsNameValidated&&!vm.CanUseValidatedWindowsName&&!vm.IsCheckingWindowsName,"Una respuesta anterior valida otro nombre");
        Check(vm.WindowsNameValidationIcon=="ℹ","Cambiar la cuenta conserva el icono anterior");
        Field("_targetPrincipal",@"CAEL\usuario");
        Field("_operation",new PolicyOperation("CLONE_PERMISSIONS","Copiar",true,true,"HIGH",""));
        Field("_isLoadingCopySources",false);Field("_copyCatalogComplete",true);Field("_copyAccessLoaded",true);Field("_copyTargetAvailable",true);
        Check(!vm.CanSubmitPermissionCopy,"Copiar permisos Windows permite omitir Comprobar nombres");
        CheckName((_,_,_)=>Task.CompletedTask).GetAwaiter().GetResult();
        Check(vm.CanSubmitPermissionCopy,"La copia Windows válida queda bloqueada");
        Field("_selectedWorkingServer",new ServerItem{Id=2,Name="OTRO"});
        Check(!vm.IsWindowsNameValidated&&!vm.CanSubmitPermissionCopy,"La comprobación Windows se reutiliza en otro servidor");
        Field("_selectedWorkingServer",new ServerItem{Id=1,Name="CAEL"});
        var pendingAuthentication=new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
        var pendingAuthenticationTask=CheckName((_,_,_)=>pendingAuthentication.Task);
        vm.IsSqlAuthentication=true;
        pendingAuthentication.SetResult();pendingAuthenticationTask.GetAwaiter().GetResult();
        Check(!vm.IsWindowsNameValidated&&!vm.IsCheckingWindowsName&&vm.CanUseValidatedWindowsName,"Cambiar a SQL conserva una validación Windows en curso");
        // Evitar consultas reales en la continuación de las comprobaciones de formulario.
        if(typeof(AccessViewModel).GetField("_copyTargetCancellation",BindingFlags.Instance|BindingFlags.NonPublic)!.GetValue(vm) is CancellationTokenSource pendingTargetCancellation)
            pendingTargetCancellation.Cancel();
        Field("_selectedWorkingServer",null!);
        Field("_operation",new PolicyOperation("CREATE_SQL_LOGIN","Crear login SQL",true,true,"HIGH",""));
        vm.IsWindowsAuthentication=true;
        vm.IsSqlAuthentication=true;
        Check(vm.SelectedOperation?.Code=="CREATE_SQL_LOGIN"&&vm.RequiresTemporaryPassword&&!vm.IsTemporaryPasswordValid,"Crear SQL no recupera su validación");
        var sqlDraft=(AccessRequestDraft)draftMethod.Invoke(vm,new object?[]{null,null,null})!;
        Check(sqlDraft.Operation=="CREATE_SQL_LOGIN"&&sqlDraft.AuthenticationType=="SQL","La creación SQL se guarda como Windows");
        Field("_operation",new PolicyOperation("MODIFY_LOGIN","Modificar",true,true,"HIGH",""));
        Check(!vm.RequiresAuthenticationType&&!vm.RequiresTemporaryPassword,"Modificar accesos permite elegir un tipo para crear login");
        var malformed=multiPlan.ToJson().Replace("\"Version\":2","\"Version\":99");
        try{PermissionCopyPlan.FromJson(malformed);throw new Exception("Se aceptó un formato incompatible");}
        catch(InvalidOperationException){_checks++;}
        var incomplete=multiPlan with{Databases=new[]{multiPlan.Databases[0] with{Accesses=new[]{item with{Database="OtraBase"}}}}};
        try{PermissionCopyPlan.FromJson(incomplete.ToJson());throw new Exception("Se aceptó un acceso de otra base");}
        catch(InvalidOperationException){_checks++;}

        var app=new App();app.InitializeComponent();
        RunPolicyEditorChecks(args);
        RunPolicyActivationChecks(args);
        RunScopedPolicyChecks(args);
        RunSystemRoleChecks();
        RunAccessDescriptionChecks(args);
        if(args.Length>0&&args[0]=="--policy-preview")args=[];
        RunFunctionPermissionChecks(args);
        RunCreateUserWizardChecks(args);
        var context=new CopyPreviewContext(item,role);
        var editor=new AccessRequestEditor{DataContext=context,Width=1440};
        editor.Measure(new Size(1440,1500));editor.Arrange(new Rect(0,0,1440,1500));editor.UpdateLayout();
        var combo=(ComboBox)editor.FindName("CopySourceSelector");combo.ApplyTemplate();
        Check(!combo.IsEditable,"El origen permite texto libre como selección");
        Check(combo.Items.Count==2,"La lista de origen no tiene usuarios");
        var sourceStatus=(TextBlock)editor.FindName("CopySourceLoadStatus");
        Check(sourceStatus.Text==context.CopySourcesMessage&&VisibleInTree(sourceStatus,editor),"El estado de carga no está junto al selector");
        var popup=(Popup)combo.Template.FindName("PART_Popup",combo);
        ((FrameworkElement)popup.Child).Measure(new Size(700,320));
        ((FrameworkElement)popup.Child).Arrange(new Rect(0,0,700,320));
        ((FrameworkElement)popup.Child).UpdateLayout();
        Check(Descendants(popup.Child).OfType<ComboBoxItem>().Count()==2,"Los usuarios existen pero el desplegable no genera sus filas");
        var search=Descendants(popup.Child).OfType<TextBox>().Single();
        Check(ReferenceEquals(search.DataContext,context),"El buscador del desplegable no recibe el contexto");
        search.SetCurrentValue(TextBox.TextProperty,"origen");search.GetBindingExpression(TextBox.TextProperty)!.UpdateSource();
        Check(context.CopySourceSearch=="origen","El buscador no actualiza el filtro");
        Check(combo.Items.Count==1,"El desplegable no filtra los usuarios");
        var grid=Descendants(editor).OfType<DataGrid>().Single(x=>ReferenceEquals(x.ItemsSource,context.CopySourceAccesses));
        Check(grid.IsReadOnly&&!grid.CanUserAddRows&&!grid.CanUserDeleteRows,"La tabla permite modificar accesos");
        Check(grid.Columns.Count==7,"La tabla no muestra el detalle completo");
        var visible=Descendants(editor).OfType<TextBlock>().Where(x=>x.IsVisible||VisibleInTree(x,editor)).ToList();
        var ticket=visible.First(x=>x.Text=="Número de ticket");
        var identity=visible.First(x=>x.Text.Contains("Usuario de referencia y nueva cuenta"));
        Check(ticket.TranslatePoint(new Point(),editor).Y<identity.TranslatePoint(new Point(),editor).Y,"El ticket no es el primer bloque de datos");
        var editorButtons=Descendants(editor).OfType<Button>().Where(x=>VisibleInTree(x,editor)).ToList();
        Check(!editorButtons.Any(x=>Convert.ToString(x.Content)?.Contains("Vista previa",StringComparison.OrdinalIgnoreCase)==true),"El editor todavía muestra el botón Vista previa");
        var submit=editorButtons.Single(x=>Convert.ToString(x.Content)?.Contains("Enviar a confirmación",StringComparison.OrdinalIgnoreCase)==true);
        Check(submit.TranslatePoint(new Point(),editor).Y<ticket.TranslatePoint(new Point(),editor).Y,"Enviar a confirmación no está en la cabecera del formulario");
        Check(Descendants(editor).OfType<PasswordBox>().All(x=>VisibleInTree(x,editor)),"La copia no muestra contraseña y confirmación");
        var sqlOption=(RadioButton)editor.FindName("SqlAuthenticationOption");
        var windowsOption=(RadioButton)editor.FindName("WindowsAuthenticationOption");
        Check(VisibleInTree(sqlOption,editor)&&VisibleInTree(windowsOption,editor)&&sqlOption.IsChecked==true&&windowsOption.IsChecked==false,"Falta el selector exclusivo de autenticación");
        windowsOption.SetCurrentValue(ToggleButton.IsCheckedProperty,true);
        windowsOption.GetBindingExpression(ToggleButton.IsCheckedProperty)!.UpdateSource();
        editor.UpdateLayout();
        Check(context.IsWindowsAuthentication&&!context.IsSqlAuthentication&&windowsOption.IsChecked==true&&sqlOption.IsChecked==false,"Los botones permiten ambos tipos o no actualizan el contexto");
        Check(Descendants(editor).OfType<PasswordBox>().All(x=>!VisibleInTree(x,editor)),"La copia Windows muestra contraseña SQL");
        var copyNameCheck=(WindowsNameValidation)editor.FindName("CopyWindowsNameValidation");
        Check(VisibleInTree(copyNameCheck,editor),"La copia Windows no muestra Comprobar nombres");
        var checkNamesButton=(Button)copyNameCheck.FindName("CheckNamesButton");
        Check(ReferenceEquals(checkNamesButton.Command,context.CheckWindowsNameCommand),"El botón Comprobar nombres no está enlazado");
        checkNamesButton.Command.Execute(null);editor.UpdateLayout();
        Check(((TextBlock)copyNameCheck.FindName("ValidationIcon")).Text=="✓"
            &&((SolidColorBrush)((TextBlock)copyNameCheck.FindName("ValidationIcon")).Foreground).Color==Color.FromRgb(21,128,61),"El control WPF no muestra check verde");
        context.ShowWindowsNameResult(false);editor.UpdateLayout();
        Check(((TextBlock)copyNameCheck.FindName("ValidationIcon")).Text=="✕"
            &&((SolidColorBrush)((TextBlock)copyNameCheck.FindName("ValidationIcon")).Foreground).Color==Color.FromRgb(180,35,24),"El control WPF no muestra X roja");
        context.ShowWindowsNameResult(true);editor.UpdateLayout();
        if(args.Length>2)RenderPreview(editor,args[2],1440,1500);
        var createContext=new CopyPreviewContext(){IsClonePermissionsOperation=false,TargetPrincipal=@"CAEL\cael_test01"};
        createContext.IsWindowsAuthentication=true;
        createContext.SelectedOperation=new{Name="Crear login Windows"};
        var createEditor=new AccessRequestEditor{DataContext=createContext,Width=1440};
        createEditor.Measure(new Size(1440,1000));createEditor.Arrange(new Rect(0,0,1440,1000));createEditor.UpdateLayout();
        Check(VisibleInTree((RadioButton)createEditor.FindName("WindowsAuthenticationOption"),createEditor)
            &&Descendants(createEditor).OfType<PasswordBox>().All(x=>!VisibleInTree(x,createEditor)),"Crear usuario Windows oculta el selector o muestra una contraseña SQL");
        Check(!VisibleInTree((ComboBox)createEditor.FindName("CopySourceSelector"),createEditor),"Crear usuario muestra un origen de copia");
        var createNameCheck=(WindowsNameValidation)createEditor.FindName("CreateWindowsNameValidation");
        Check(VisibleInTree(createNameCheck,createEditor),"Crear usuario Windows no muestra Comprobar nombres");
        createContext.ShowWindowsNameResult(true);createEditor.UpdateLayout();
        if(args.Length>3)RenderPreview(createEditor,args[3],1440,1000);
        sqlOption.SetCurrentValue(ToggleButton.IsCheckedProperty,true);
        sqlOption.GetBindingExpression(ToggleButton.IsCheckedProperty)!.UpdateSource();
        editor.UpdateLayout();
        Check(context.IsSqlAuthentication&&Descendants(editor).OfType<PasswordBox>().All(x=>VisibleInTree(x,editor)),"Volver a SQL no muestra la contraseña");
        Check(!VisibleInTree(copyNameCheck,editor),"SQL authentication muestra Comprobar nombres Windows");
        if(args.Length>0)
        {
            var bitmap=new RenderTargetBitmap(1440,1500,96,96,PixelFormats.Pbgra32);bitmap.Render(editor);
            var encoder=new PngBitmapEncoder();encoder.Frames.Add(BitmapFrame.Create(bitmap));
            using var output=System.IO.File.Create(System.IO.Path.GetFullPath(args[0]));encoder.Save(output);
        }
        var confirmation=new AccessView{DataContext=new CopyConfirmationContext(copyRequest),Width=1440,Background=Brushes.White};
        confirmation.Measure(new Size(1440,1100));confirmation.Arrange(new Rect(0,0,1440,1100));confirmation.UpdateLayout();
        var changeList=Descendants(confirmation).OfType<ListBox>().Single(x=>ReferenceEquals(x.DataContext,copyRequest));
        Check(changeList.Items.Count==8,"La confirmación WPF no lista todos los accesos de las tres bases");
        if(args.Length>1)
        {
            var bitmap=new RenderTargetBitmap(1440,1100,96,96,PixelFormats.Pbgra32);bitmap.Render(confirmation);
            var encoder=new PngBitmapEncoder();encoder.Frames.Add(BitmapFrame.Create(bitmap));
            using var output=System.IO.File.Create(System.IO.Path.GetFullPath(args[1]));encoder.Save(output);
        }
        Console.WriteLine($"{_checks} comprobaciones de accesos superadas.");
    }
    private static void RenderPreview(UIElement element,string path,int width,int height)
    {
        var bitmap=new RenderTargetBitmap(width,height,96,96,PixelFormats.Pbgra32);bitmap.Render(element);
        var encoder=new PngBitmapEncoder();encoder.Frames.Add(BitmapFrame.Create(bitmap));
        using var output=System.IO.File.Create(System.IO.Path.GetFullPath(path));encoder.Save(output);
    }
    private static bool VisibleInTree(DependencyObject item,DependencyObject root)
    {
        for(var current=item;current is not null&&current!=root;current=VisualTreeHelper.GetParent(current))
            if(current is UIElement element&&element.Visibility!=Visibility.Visible)return false;
        return true;
    }
    private static IEnumerable<DependencyObject> Descendants(DependencyObject item)
    {
        for(var index=0;index<VisualTreeHelper.GetChildrenCount(item);index++)
        {
            var child=VisualTreeHelper.GetChild(item,index);yield return child;
            foreach(var descendant in Descendants(child))yield return descendant;
        }
    }
}

public class CopyPreviewContext : INotifyPropertyChanged
{
    public event PropertyChangedEventHandler? PropertyChanged;
    public bool IsClonePermissionsOperation {get;set;}=true;
    public bool IsStandardAccessOperation=>true;
    public bool IsStandardDatabaseOperation=>false;
    public bool IsBasicIdentityOperation=>!IsClonePermissionsOperation;
    public bool IsExistingAccessOperation=>false;
    public bool IsLoginMappingOperation=>false;
    public bool IsPermissionMatrixOperation=>false;
    public bool IsCreateLoginOperation=>!IsClonePermissionsOperation;
    public bool IsLegacyStandardAccessOperation=>IsStandardAccessOperation&&!IsCreateLoginOperation;
    public int CreateUserStep {get;private set;}=1;
    public bool IsCreateUserAccountStep=>IsCreateLoginOperation&&CreateUserStep==1;
    public bool IsCreateUserMappingStep=>IsCreateLoginOperation&&CreateUserStep==2;
    public bool IsCreateUserObjectsStep=>IsCreateLoginOperation&&CreateUserStep==3;
    public bool ShowCreateUserContext=>IsCreateLoginOperation&&CreateUserStep>1;
    public bool ShowAuthenticationCard=>RequiresAuthenticationType&&(!IsCreateLoginOperation||IsCreateUserAccountStep);
    public bool ShowIdentityCard=>IsBasicIdentityOperation&&(!IsCreateLoginOperation||IsCreateUserAccountStep);
    public bool ShowPasswordCard=>RequiresTemporaryPassword&&(!IsCreateLoginOperation||IsCreateUserAccountStep);
    public bool ShowTicketCard=>HasTopRequestDetails&&(!IsCreateLoginOperation||IsCreateUserAccountStep);
    public bool ShowRequestAccessCard=>!IsCreateLoginOperation;
    public string CreateUserTitle=>"Asistente de creación de usuario · CAEL";
    public int CreateUserObjectsStepNumber=>IncludeInitialAccess?3:2;
    public string CreateUserObjectsStepLabel=>$"{CreateUserObjectsStepNumber}. Permisos a objetos";
    public string CreateUserStepTitle=>CreateUserStep switch{2=>"Paso 2: Mapeo de bases de datos y roles",3=>$"Paso {CreateUserObjectsStepNumber}: Permisos específicos a objetos",_=>"Paso 1: General y cuenta"};
    public string CreateUserContextSummary=>$"{TargetPrincipal} · {(IsWindowsAuthentication?"WINDOWS":"SQL")} · TIC-RF-{ExternalTicketDigits}";
    public bool IncludeInitialObjectPermissions {get;set;}
    public string CreateUserMappingStepHint=>IncludeInitialAccess?"Bases, roles y permisos generales":"Opcional · se omite";
    public string CreateUserObjectsStepHint=>IncludeInitialObjectPermissions?"Tablas, vistas, funciones y procedimientos":"Opcional · se omite";
    public bool IsCreateUserFinalStep=>IsCreateLoginOperation&&(!(IncludeInitialAccess||IncludeInitialObjectPermissions)||CreateUserStep==(IncludeInitialObjectPermissions?3:2));
    public bool ShowCreateUserNextButton=>IsCreateLoginOperation&&!IsCreateUserFinalStep;
    public ObservableCollection<DatabaseItem> Databases {get;}=[];
    public ObservableCollection<RoleSelectionItem> InitialAccessRoleChoices {get;}=[];
    public ObservableCollection<PermissionSelectionItem> InitialAccessPermissionChoices {get;}=[];
    public ObservableCollection<ObjectPermissionRow> CreateUserObjectRows {get;}=[];
    public bool IsLoadingCreateUserDatabases=>false;
    public bool IsLoadingCreateUserObjects=>false;
    public bool HasCreateUserDatabaseError=>false;
    public string CreateUserDatabaseMessage=>$"{Databases.Count} bases disponibles. Marque las que recibirá el usuario.";
    public string CreateUserObjectDatabase=>"Ventas";
    public IEnumerable<DatabaseItem> CreateUserObjectDatabaseChoices=>Databases.Where(x=>!IncludeInitialAccess||x.IsSelected);
    public DatabaseItem? SelectedCreateUserObjectDatabase {get;set;}
    public bool CanAddCreateUserObjects=>SelectedCreateUserObjectDatabase is not null;
    public string CreateUserObjectSummary=>"2 objetos · 2 permisos seleccionados en Ventas.";
    public string CreateUserStepValidationMessage=>"";
    public SqlAccessAdmin.Infrastructure.RelayCommand CreateUserPreviousCommand=>new(()=>SetCreateStep(CreateUserStep==3&&IncludeInitialAccess?2:1),()=>CreateUserStep>1);
    public SqlAccessAdmin.Infrastructure.RelayCommand CreateUserNextCommand=>new(()=>SetCreateStep(CreateUserStep==1&&IncludeInitialAccess?2:3));
    public SqlAccessAdmin.Infrastructure.RelayCommand SubmitCommand=>new(()=>{});
    public SqlAccessAdmin.Infrastructure.RelayCommand CancelAccessManagementCommand=>new(()=>{});
    public void SetCreateStep(int step)
    {
        CreateUserStep=step;
        foreach(var name in new[]{nameof(CreateUserStep),nameof(IsCreateUserAccountStep),nameof(IsCreateUserMappingStep),nameof(IsCreateUserObjectsStep),nameof(ShowCreateUserContext),
            nameof(ShowAuthenticationCard),nameof(ShowIdentityCard),nameof(ShowPasswordCard),nameof(ShowTicketCard),nameof(CreateUserStepTitle),nameof(IsCreateUserFinalStep),nameof(ShowCreateUserNextButton),
            nameof(IncludeInitialAccess),nameof(IncludeInitialObjectPermissions),nameof(CreateUserObjectsStepLabel),nameof(CreateUserObjectDatabaseChoices),nameof(CreateUserPreviousCommand),nameof(CreateUserNextCommand)})
            PropertyChanged?.Invoke(this,new(name));
    }
    public bool RequiresWindowsNameValidation=>IsWindowsAuthentication;
    public bool IsCheckingWindowsName=>false;
    private string _nameCheckState="unchecked";
    public string WindowsNameValidationIcon=>_nameCheckState=="valid"?"✓":_nameCheckState=="failed"?"✕":"ℹ";
    public string WindowsNameValidationForeground=>_nameCheckState=="valid"?"#15803D":_nameCheckState=="failed"?"#B42318":"#60789F";
    public string WindowsNameValidationMessage=>_nameCheckState=="valid"?@"Cuenta Windows comprobada: CAEL\cael_test01. El servidor CAEL reconoce la identidad.":_nameCheckState=="failed"?"Windows no reconoce la cuenta. Revise el nombre y vuelva a comprobar.":"Pulse Comprobar nombres antes de enviar la solicitud.";
    public SqlAccessAdmin.Infrastructure.RelayCommand CheckWindowsNameCommand {get;}
    public void ShowWindowsNameResult(bool valid)
    {
        _nameCheckState=valid?"valid":"failed";
        foreach(var property in new[]{nameof(WindowsNameValidationIcon),nameof(WindowsNameValidationForeground),nameof(WindowsNameValidationMessage)})
            PropertyChanged?.Invoke(this,new(property));
    }
    public string CreateLoginTargetValidationMessage=>"Nombre disponible en SQL Server. La comprobación de la identidad Windows se muestra junto a Comprobar nombres.";
    public bool RequiresSourcePrincipal=>false;
    public bool RequiresRoleInDetails=>false;
    public bool RequiresPermission=>false;
    public bool IncludeInitialAccess {get;set;}
    public string TargetPrincipalHelp=>AuthenticationHelp;
    public bool HasDatabaseAccessEditor=>false;
    public bool HasTopRequestDetails=>true;
    public bool HasBottomRequestDetails=>false;
    public bool RequiresTemporaryPassword=>IsSqlAuthentication;
    public bool RequiresAuthenticationType=>true;
    private string _authenticationType="SQL";
    public bool IsSqlAuthentication {get=>_authenticationType=="SQL";set{if(value)ChangeAuthentication("SQL");}}
    public bool IsWindowsAuthentication {get=>_authenticationType=="WINDOWS";set{if(value)ChangeAuthentication("WINDOWS");}}
    public string AuthenticationHelp=>IsWindowsAuthentication?@"Cuenta existente: DOMINIO\usuario o EQUIPO\usuario. Su contraseña se administra en Windows.":"Crear login SQL con contraseña temporal.";
    public string TargetPrincipalLabel=>IsWindowsAuthentication?@"Cuenta Windows destino (DOMINIO\usuario o EQUIPO\usuario)":"Nombre del nuevo usuario SQL";
    private void ChangeAuthentication(string value)
    {
        _authenticationType=value;
        TargetPrincipal=value=="WINDOWS"?@"CAEL\cael_test01":"ventas_nuevo";
        foreach(var property in new[]{nameof(IsSqlAuthentication),nameof(IsWindowsAuthentication),nameof(RequiresWindowsNameValidation),nameof(RequiresTemporaryPassword),nameof(ShowPasswordCard),nameof(AuthenticationHelp),nameof(TargetPrincipalLabel),nameof(TargetPrincipal),nameof(CopyTargetValidationMessage),nameof(OperationGuidance),nameof(TargetPrincipalHelp)})
            PropertyChanged?.Invoke(this,new(property));
    }
    public bool NeedsPolicyConfiguration=>false;
    public bool HasReducedPasswordSecurity=>false;
    public bool IsSuggestedPasswordLengthValid=>true;
    public bool IsExternalTicketValid=>true;
    public string ExternalTicketDigits {get;set;}="10542";
    public string ExternalTicketValidationMessage=>"Ticket válido: TIC-RF-10542";
    public string Justification {get;set;}="Nuevo usuario con acceso equivalente para el equipo de ventas.";
    public string TargetPrincipal {get;set;}="ventas_nuevo";
    public string CopyTargetValidationMessage=>IsWindowsAuthentication?"Nombre disponible en SQL Server. La comprobación de la identidad Windows se muestra junto a Comprobar nombres.":"Nombre disponible. Se creará un login SQL nuevo.";
    public string CopyAccessMessage=>"ventas_origen: 2 accesos copiables en Ventas. Consulta de solo lectura.";
    public string CopySourcesMessage=>"2 usuarios disponibles. Seleccione el origen.";
    public bool IsLoadingCopySources=>false;
    public bool IsLoadingCopyAccess=>false;
    public bool IsServerOperation=>false;
    public string DestinationInstruction=>"Revise los accesos autorizados del origen.";
    public string EditorBackActionText=>"← Volver a consulta";
    public object SelectedOperation {get;set;}=new{Name="Copiar permisos a un usuario nuevo"};
    public string OperationGuidance=>IsClonePermissionsOperation
        ?IsWindowsAuthentication?"Seleccione el usuario origen e indique la cuenta Windows existente que recibirá sus accesos.":"Seleccione el origen y defina un usuario nuevo con contraseña temporal."
        :IsWindowsAuthentication?"Crea un login para una identidad Windows existente y permite preparar sus usuarios y permisos iniciales.":"Indique el login nuevo y configure una contraseña temporal.";
    public string SuggestedPasswordLengthText {get;set;}="20";
    public string SuggestedPasswordLengthValidationMessage=>"Se generará una contraseña de 20 caracteres.";
    public bool CanEnablePasswordExpiration=>true;
    public bool CanRequirePasswordChange=>true;
    public bool PasswordPolicyEnabled {get;set;}=true;
    public bool PasswordExpirationEnabled {get;set;}=true;
    public bool MustChangePassword {get;set;}=true;
    public string TemporaryPasswordValidationMessage=>"Ingrese y confirme una contraseña temporal segura.";
    public ObservableCollection<PermissionCopyAccessItem> CopySourceAccesses {get;}
    public ICollectionView CopySourcesView {get;}=CollectionViewSource.GetDefaultView(new[]{"ventas_origen","reportes_usuario"});
    public string SelectedCopySource {get;set;}="ventas_origen";
    private string _search="";
    public string CopySourceSearch
    {
        get=>_search;
        set{_search=value;CopySourcesView.Filter=item=>((string)item).Contains(value,StringComparison.OrdinalIgnoreCase);PropertyChanged?.Invoke(this,new(nameof(CopySourceSearch)));}
    }
    public CopyPreviewContext(params PermissionCopyAccessItem[] items)
    {
        CopySourceAccesses=new(items);
        CheckWindowsNameCommand=new(()=>ShowWindowsNameResult(true));
    }
}

public sealed class CopyConfirmationContext : CopyPreviewContext
{
    public bool HasWorkingServer=>true;
    public ObservableCollection<ServerItem> Servers {get;}=[new(){Id=1,Name="CAEL",Host="CAEL"}];
    public ServerItem SelectedWorkingServer {get;set;}
    public string WorkingServerSummary=>"CAEL";
    public bool IsConfirmationStep {get;set;}=true;
    public bool IsModifyAccessStep {get;set;}
    public bool IsCreateUserStep {get;set;}
    public bool IsCopyPermissionsStep {get;set;}
    public int SelectedAccessStep {get;set;}=3;
    public string PendingRequestBadge=>"1 pendiente";
    public ObservableCollection<AccessRequestItem> Requests {get;}
    public AccessRequestItem? SelectedRequest {get;set;}
    public string RequestFilter {get;set;}="";
    public string ApprovalComment {get;set;}="";
    public string Status=>"Una solicitud con todos los roles y permisos en sus bases correspondientes.";
    public CopyConfirmationContext(AccessRequestItem request){SelectedWorkingServer=Servers[0];Requests=[request];}
}
