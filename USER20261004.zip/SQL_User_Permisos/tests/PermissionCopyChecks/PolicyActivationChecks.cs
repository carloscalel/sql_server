using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Media;
using SqlAccessAdmin.Models;
using SqlAccessAdmin.ViewModels;
using SqlAccessAdmin.Views;

internal static partial class Program
{
    private static void RunPolicyActivationChecks(string[] args)
    {
        var store = new PolicyMemoryStore();
        var session = new SessionContext("Admin de pruebas", AppRole.Administrator);
        var vm = new PolicyViewModel(store, session, _ => true);
        var owner = vm.Roles.Single(x => x.Name == "db_owner");
        Check(owner.CanRequestSpecialActivation && owner.ActivateCommand!.CanExecute(null), "No se ofrece activación especial al rol protegido");
        vm.BeginSpecialActivation(owner);
        Check(vm.HasActivation && !vm.CanEdit && !vm.ActivateSpecialCommand.CanExecute(null), "El formulario permite activar sin segunda confirmación");
        vm.ActivateSpecialCommand.Execute(null);
        Check(store.Writes.Count == 0, "Se activa una excepción con un formulario incompleto");
        vm.Activation!.RiskAcknowledged = true;
        vm.Activation.ConfirmedName = "DB_OWNER";
        vm.Activation.Reason = "Necesario para administrar la base de pruebas.";
        Check(!vm.ActivateSpecialCommand.CanExecute(null), "La confirmación no exige el nombre exacto");
        vm.Activation.ConfirmedName = "db_owner";
        Check(vm.ActivateSpecialCommand.CanExecute(null), "La confirmación válida no permite continuar");
        vm.CancelActivationCommand.Execute(null);
        Check(!vm.HasActivation && store.Writes.Count == 0 && owner.IsProtected, "Cancelar habilita o guarda la excepción");
        vm.BeginSpecialActivation(owner);
        Check(vm.Activation!.ConfirmedName == "" && !vm.Activation.RiskAcknowledged, "Se reutiliza la confirmación de una activación cancelada");
        vm.Activation.RiskAcknowledged = true; vm.Activation.ConfirmedName = "db_owner";
        vm.Activation.Reason = "Necesario para administrar la base de pruebas.";
        vm.ActivateSpecialCommand.Execute(null);
        var activated = vm.Roles.Single(x => x.Name == "db_owner");
        Check(!vm.HasActivation && !vm.HasChanges && activated.IsAllowed && !activated.IsProtected && activated.HasSpecialActivation,
            "La activación no persiste la excepción ni recarga su estado efectivo");
        Check(store.Denials.Count == 1 && store.Denials[0].Active, "Se elimina o desactiva el bloqueo original");
        Check(activated.SpecialActivationReason.Contains("base de pruebas"), "Se pierde el motivo de autorización");
        Check(PolicyEditorCatalog.CanUseRole(store.Roles.Single(x => x.Name == "db_owner"), store.Denials), "El catálogo de solicitudes excluye la membresía autorizada");
        var rolePolicy = store.Roles.Single(x => x.Name == "db_owner");
        Check(!PolicyEditorCatalog.CanUseRole(rolePolicy with { Enabled = false }, store.Denials), "Una excepción habilita una regla desactivada");
        Check(!PolicyEditorCatalog.CanUseRole(rolePolicy with{SpecialActivationApproved=false,RoleScope="SERVER"}, [store.Denials[0] with { Category = "SERVER_ROLE" }]), "Un rol de servidor se habilita sin aprobación especial");
        activated.IsAllowed = false; vm.SaveCommand.Execute(null);
        var blocked = vm.Roles.Single(x => x.Name == "db_owner");
        Check(blocked.IsProtected && !blocked.IsAllowed && !blocked.HasSpecialActivation && blocked.CanRequestSpecialActivation,
            "Volver a bloquear conserva una excepción utilizable");
        blocked.IsAllowed = true;
        Check(!vm.HasChanges && !blocked.IsAllowed, "Se reactiva un rol sin repetir la confirmación especial");
        vm.Permissions.First(x => x.IsAllowed).IsAllowed = false;
        vm.BeginSpecialActivation(blocked);
        Check(!vm.HasActivation && !blocked.ActivateCommand!.CanExecute(null), "La activación puede perder cambios pendientes");
        vm.DiscardCommand.Execute(null);
        var column = vm.Permissions.Single(x => x.Scope == "COLUMN");
        vm.BeginSpecialActivation(column);
        Check(vm.HasActivation && column.CanRequestSpecialActivation && !vm.ActivateSpecialCommand.CanExecute(null), "La columna no recibe la misma segunda confirmación que el rol");
        vm.CancelActivationCommand.Execute(null);

        var permissionStore = new PolicyMemoryStore();
        permissionStore.Denials.Add(new(5, "PERMISSION", "SELECT", "Lectura restringida", false, true, "admin", DateTime.UtcNow));
        var permissionVm = new PolicyViewModel(permissionStore, session, _ => true);
        var objectRead = permissionVm.Permissions.Single(x => x.Permission == "SELECT" && x.Scope == "OBJECT");
        permissionVm.BeginSpecialActivation(objectRead);
        permissionVm.Activation!.RiskAcknowledged = true; permissionVm.Activation.ConfirmedName = "SELECT";
        permissionVm.Activation.Reason = "Autorizar lectura de objetos para reportes internos.";
        permissionVm.ActivateSpecialCommand.Execute(null);
        Check(permissionVm.Permissions.Single(x => x.Permission == "SELECT" && x.Scope == "OBJECT").IsAllowed
            && permissionVm.Permissions.Single(x => x.Permission == "SELECT" && x.Scope == "DATABASE").IsProtected,
            "La excepción de objetos habilita también toda la base");
        var unsupported = new PermissionPolicyItem(new("CONTROL", "DATABASE", true, false, true, true, "admin", DateTime.UtcNow)
            { SpecialActivationApproved = true, Supported = false }, "No disponible en el servidor");
        Check(unsupported.IsProtected && !unsupported.IsAllowed && !unsupported.CanRequestSpecialActivation, "Una bandera de excepción habilita permisos fuera del contrato");
        var permanentlyBlocked = new RolePolicyItem(rolePolicy with { Name = "public" }, PolicyEditorCatalog.RoleProtection("public", []));
        Check(permanentlyBlocked.IsProtected && !permanentlyBlocked.IsAllowed && !permanentlyBlocked.CanRequestSpecialActivation, "Una bandera de excepción habilita public");
        var valid = new PolicySpecialActivation("DATABASE_ROLE", "db_owner", "", "Motivo suficientemente largo para esta prueba.", "db_owner", true);
        foreach (var invalid in new[]
        {
            valid with { RiskAcknowledged = false }, valid with { ConfirmedName = "DB_OWNER" }, valid with { ConfirmedName = "db_owner " },
            valid with { Reason = "corto" }, valid with { Reason = new string('x', 1001) }, valid with { Scope = "DATABASE" },
            valid with { Category = "INVALID_ROLE" }, valid with { Value = "public", ConfirmedName = "public" },
            valid with { Category = "PERMISSION", Value = "INSERT", ConfirmedName = "INSERT", Scope = "COLUMN" }
        })
        {
            try { invalid.Validate(); throw new Exception("Se acepta una activación especial inválida"); }
            catch (InvalidOperationException) { _checks++; }
        }
        valid.Validate();
        RunPermissionScopeChecks(args);
        var operatorVm = new PolicyViewModel(new PolicyMemoryStore(), session with { Role = AppRole.Operator }, _ => true);
        operatorVm.BeginSpecialActivation(owner);
        Check(!operatorVm.HasActivation && !operatorVm.ActivateSpecialCommand.CanExecute(null), "Un operador puede activar excepciones");

        var previewStore = new PolicyMemoryStore();
        previewStore.Roles = previewStore.Roles.OrderBy(x => x.Name == "db_owner" ? 0 : 1).ToList();
        var previewVm = new PolicyViewModel(previewStore, session, _ => true);
        var view = new PolicyView { DataContext = previewVm, Background = Brushes.White };
        void Layout(int width, int height)
        {
            view.Width = width; view.Height = height;
            view.Measure(new Size(width, height)); view.Arrange(new Rect(0, 0, width, height)); view.UpdateLayout();
            view.Dispatcher.Invoke(() => { }, System.Windows.Threading.DispatcherPriority.ContextIdle); view.UpdateLayout();
        }
        ((TabControl)view.FindName("PolicyTabs")).SelectedIndex = 1; Layout(960, 680);
        var ownerItem = previewVm.Roles.Single(x => x.Name == "db_owner");
        var roleGrid = (DataGrid)view.FindName("RolesGrid"); roleGrid.ScrollIntoView(ownerItem); Layout(960, 680);
        var enableButton = Descendants(roleGrid).OfType<Button>().First(x => ReferenceEquals(x.DataContext, ownerItem) && x.Content?.ToString() == "Habilitar…");
        enableButton.Command.Execute(null); Layout(960, 680);
        var panel = (Grid)view.FindName("ActivationPanel");
        Check(VisibleInTree(panel, view) && System.Windows.Input.KeyboardNavigation.GetTabNavigation(panel) == System.Windows.Input.KeyboardNavigationMode.Cycle,
            "La confirmación no se muestra o no conserva la navegación por teclado");
        Check(!((Button)view.FindName("ConfirmSpecialActivationButton")).IsEnabled, "La vista habilita el botón antes de completar la confirmación");
        var reason = (TextBox)view.FindName("ActivationReason"); reason.SetCurrentValue(TextBox.TextProperty, "Necesario para administrar la base de pruebas."); reason.GetBindingExpression(TextBox.TextProperty)!.UpdateSource();
        var check = (CheckBox)view.FindName("ActivationRiskCheck"); check.SetCurrentValue(ToggleButton.IsCheckedProperty, true); check.GetBindingExpression(ToggleButton.IsCheckedProperty)!.UpdateSource();
        var typed = (TextBox)view.FindName("ActivationTypedName"); typed.SetCurrentValue(TextBox.TextProperty, "db_owner"); typed.GetBindingExpression(TextBox.TextProperty)!.UpdateSource(); Layout(960, 680);
        Check(previewVm.Activation!.CanActivate && ((Button)view.FindName("ConfirmSpecialActivationButton")).IsEnabled, "Las entradas WPF no actualizan el requisito de activación");
        if (args.Length == 2 && args[0] == "--policy-preview")
        {
            Directory.CreateDirectory(args[1]);
            RenderPreview(view, Path.Combine(args[1], "politica-activacion-especial.png"), 960, 680);
            Layout(720, 490);
            var confirmButton = (Button)view.FindName("ConfirmSpecialActivationButton");
            var confirmPosition = confirmButton.TranslatePoint(new Point(), view);
            Check(confirmPosition.Y >= 0 && confirmPosition.Y + confirmButton.ActualHeight <= 490,
                "La confirmación final no permanece visible en una pantalla compacta");
            RenderPreview(view, Path.Combine(args[1], "politica-activacion-compacta.png"), 720, 490);
        }
        previewVm.CancelActivationCommand.Execute(null); Layout(960, 680);
        Check(!VisibleInTree(panel, view) && !previewVm.HasChanges, "Cancelar deja la confirmación visible o registra una edición");
    }
}
