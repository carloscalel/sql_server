using System.IO;
using System.Windows;
using System.Windows.Automation.Peers;
using System.Windows.Automation.Provider;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Media;
using SqlAccessAdmin.Data;
using SqlAccessAdmin.Models;
using SqlAccessAdmin.ViewModels;
using SqlAccessAdmin.Views;

internal static partial class Program
{
    private static void RunPolicyEditorChecks(string[] args)
    {
        var store = new PolicyMemoryStore();
        var confirm = true;
        var confirmations = new List<string>();
        var session = new SessionContext("Administrador de pruebas", AppRole.Administrator);
        var vm = new PolicyViewModel(store, session, message => { confirmations.Add(message); return confirm; });
        Check(vm.CanEdit && !vm.HasChanges && !vm.SaveCommand.CanExecute(null), "El catálogo comienza con cambios o permite guardar sin cambios");
        Check(vm.Permissions.Count == 11, "Faltan combinaciones disponibles o se oculta el alcance heredado");
        var select = vm.Permissions.Single(x => x.Permission == "SELECT" && x.Scope == "OBJECT");
        var column = vm.Permissions.Single(x => x.Scope == "COLUMN");
        Check(column.IsProtected && !column.CanEdit && !column.IsAllowed, "Un alcance heredado se ofrece como editable");
        column.IsAllowed = true; column.AllowGrant = true;
        Check(!column.IsDirty, "Se puede modificar una regla no compatible");
        var owner = vm.Roles.Single(x => x.Name == "db_owner");
        Check(owner.IsProtected && !owner.IsAllowed && owner.StateDisplay == "Protegido", "Un rol protegido se muestra permitido por su bandera de catálogo");
        owner.IsAllowed = true; owner.Notes = "cambio";
        Check(!owner.IsDirty, "Se permite modificar un rol protegido");
        Check(PolicyEditorCatalog.RoleProtection("SERVERADMIN", []).Length > 0, "La protección máxima omite roles de servidor");
        Check(PolicyEditorCatalog.RoleProtection("db_reporting", []).Length == 0, "Se bloquean roles personalizados por su prefijo");
        var emptyReason = new DenyRule(50, "PERMISSION", "SELECT", "", false, true, "admin", DateTime.UnixEpoch);
        Check(PolicyEditorCatalog.PermissionProtection("SELECT", "OBJECT", [emptyReason]).Length > 0, "Un bloqueo sin motivo deja de proteger el permiso");
        Check(PolicyEditorCatalog.RoleProtection("reportes", [emptyReason with { Category = "DATABASE_ROLE", Value = "reportes" }]).Length > 0, "Un bloqueo sin motivo deja de proteger el rol");
        Check(PolicyEditorCatalog.PermissionProtection("SELECT", "OBJECT", [emptyReason with { Active = false }]).Length == 0, "Un bloqueo inactivo restringe el permiso");
        vm.Search = "leer";
        Check(vm.PermissionView.Cast<object>().Count() == 2, "La búsqueda no encuentra la descripción en lenguaje natural");
        vm.Search = "Select";
        Check(vm.PermissionView.Cast<object>().Count() == 2, "La búsqueda SQL distingue mayúsculas");
        vm.Search = ""; vm.StateFilter = "Protegidos";
        Check(vm.RoleView.Cast<object>().All(x => ((RolePolicyItem)x).IsProtected), "El filtro de protegidos incluye roles editables");
        vm.StateFilter = "Todos";
        select.IsAllowed = false;
        Check(vm.PendingCount == 1 && vm.SaveCommand.CanExecute(null), "Cambiar disponibilidad no activa el guardado");
        select.IsAllowed = true;
        Check(!vm.HasChanges, "Restaurar el estado original mantiene un cambio falso");
        select.AllowGrant = false;
        Check(select.ActionSummary == "Solo retirar" && vm.HasChanges, "La restricción avanzada no se conserva");
        select.IsAllowed = false; select.IsAllowed = true;
        Check(!select.AllowGrant && select.AllowRevoke, "Habilitar sobrescribe una restricción avanzada válida");
        select.AllowRevoke = false;
        vm.SaveCommand.Execute(null);
        Check(store.Writes.Count == 0 && vm.Status.Contains("permita asignar"), "Se guarda un permiso activo sin acciones");
        select.IsAllowed = false; select.IsAllowed = true;
        Check(select.AllowGrant && select.AllowRevoke && !vm.HasChanges, "No se restablecen acciones al habilitar una regla vacía");
        select.IsAllowed = false;
        confirm = false; vm.SaveCommand.Execute(null);
        Check(store.Writes.Count == 0 && vm.HasChanges, "Cancelar la confirmación guarda o descarta cambios");
        vm.RefreshCommand.Execute(null);
        Check(vm.HasChanges && !select.IsAllowed, "Actualizar descarta cambios sin confirmación");
        Check(!vm.ConfirmLeave(), "La salida ignora la cancelación del usuario");
        confirm = true; vm.DiscardCommand.Execute(null);
        Check(!vm.HasChanges && vm.Permissions.Single(x => x.Permission == "SELECT" && x.Scope == "OBJECT").IsAllowed, "Descartar no restaura el catálogo guardado");

        var p1 = vm.Permissions.First(x => x.IsAllowed);
        var p2 = vm.Permissions.Last(x => x.IsAllowed);
        p1.IsAllowed = false; p2.IsAllowed = false;
        store.FailWriteNumber = 2;
        vm.SaveCommand.Execute(null);
        Check(store.Writes.Count == 1 && !p1.IsDirty && p2.IsDirty && vm.PendingCount == 1, "Un fallo parcial pierde cambios o vuelve a marcar lo guardado");
        Check(vm.Status.Contains("Guardados: 1; pendientes: 1") && !vm.Status.Contains("error SQL interno"), "El fallo parcial no explica el resultado o expone errores internos");
        Check(confirmations.Last().Contains("No cambian los accesos ya asignados"), "La confirmación confunde política con revocación de accesos");
        store.FailWriteNumber = null; vm.SaveCommand.Execute(null);
        Check(!vm.HasChanges && store.Writes.Count == 2, "Reintentar reescribe lo guardado o pierde el cambio pendiente");
        Check(store.Writes.OfType<PolicyPermission>().All(x => !x.AllowDeny), "El editor habilita denegaciones fuera del contrato");
        vm.NewRoleName = "db_reporting"; vm.NewRoleNotes = "Reportes";
        vm.AddRoleCommand.Execute(null);
        Check(vm.HasChanges && vm.Roles.Any(x => x.Name == "db_reporting" && x.Kind == "CUSTOM"), "No se agrega un rol personalizado al borrador");
        Check(store.Writes.Count == 2, "Agregar un rol al borrador escribe antes de confirmar");
        vm.DenyValue = "SELECT"; vm.DenyReason = "Solo lectura restringida";
        Check(!vm.AddDenyCommand.CanExecute(null), "Se pueden agregar bloqueos y perder un borrador pendiente");
        vm.SaveCommand.Execute(null);
        Check(store.Writes.OfType<PolicyRole>().Single().Name == "db_reporting", "No se guarda el rol personalizado");
        vm.NewRoleName = "DB_REPORTING"; vm.AddRoleCommand.Execute(null);
        Check(!vm.HasChanges && vm.Status.Contains("ya está"), "Se admiten nombres de rol duplicados");
        vm.NewRoleName = "sysadmin"; vm.AddRoleCommand.Execute(null);
        Check(!vm.HasChanges, "Se registra un rol protegido como personalizado");
        vm.AddDenyCommand.Execute(null);
        Check(vm.Permissions.Where(x => x.Permission == "SELECT").All(x => x.IsProtected && !x.IsAllowed), "El bloqueo guardado no tiene prioridad sobre el catálogo");
        Check(!vm.HasChanges && store.BlockWrites == 1, "Agregar bloqueo genera cambios falsos");
        vm.DenyValue = "SELECT"; vm.DenyReason = "Otro motivo"; vm.AddDenyCommand.Execute(null);
        Check(store.BlockWrites == 1, "El editor sobrescribe un bloqueo obligatorio existente");

        var operatorStore = new PolicyMemoryStore();
        var operatorVm = new PolicyViewModel(operatorStore, session with { Role = AppRole.Operator }, _ => true);
        operatorVm.RefreshCommand.Execute(null); operatorVm.SaveCommand.Execute(null);
        Check(!operatorVm.CanEdit && operatorStore.Reads == 0 && operatorStore.Writes.Count == 0, "Un operador puede cargar o guardar políticas administrativas");
        var failingStore = new PolicyMemoryStore { FailBlockRead = true };
        var failingVm = new PolicyViewModel(failingStore, session, _ => true);
        Check(!failingVm.CanEdit && failingVm.Permissions.Count == 0, "Un catálogo sin bloqueos se publica como editable");
        failingStore.FailBlockRead = false; failingVm.RefreshCommand.Execute(null);
        Check(failingVm.CanEdit, "No se puede reintentar una carga fallida");
        var raceStore = new PolicyMemoryStore();
        var raceVm = new PolicyViewModel(raceStore, session, _ => true);
        raceVm.Roles.Single(x => x.Name == "SqlAccessAdmin_Operator").IsAllowed = false;
        var missing = raceVm.Permissions.Single(x => x.Permission == "UPDATE" && x.Scope == "OBJECT");
        missing.IsAllowed = true;
        raceStore.Denials.Add(new(99, "PERMISSION", "UPDATE", "Bloqueado por otro administrador", false, true, "admin", DateTime.UtcNow));
        raceVm.SaveCommand.Execute(null);
        Check(raceStore.Writes.Count == 0 && raceVm.PendingCount == 2, "Se guarda un permiso bloqueado después de la revisión o se pierde el borrador");
        raceVm.RefreshCommand.Execute(null);
        Check(!raceVm.HasChanges && raceVm.Permissions.Where(x => x.Permission == "UPDATE").All(x => x.IsProtected), "Actualizar no aplica nuevos bloqueos");
        var noteOnly = failingVm.Roles.Single(x => x.Name == "SqlAccessAdmin_Operator");
        noteOnly.Notes = "Descripción actualizada";
        failingVm.SaveCommand.Execute(null);
        Check(failingStore.Writes.OfType<PolicyRole>().Single().Notes == "Descripción actualizada", "Los cambios administrativos del rol no se guardan");
        var reloadStore = new PolicyMemoryStore();
        var reloadVm = new PolicyViewModel(reloadStore, session, _ => true);
        reloadVm.Permissions.First(x => x.IsAllowed).IsAllowed = false;
        reloadStore.BeforePermissionWrite = () =>
        {
            Check(reloadVm.IsBusy && !reloadVm.CanEdit && !reloadVm.SaveCommand.CanExecute(null)
                && !reloadVm.RefreshCommand.CanExecute(null), "Se permiten operaciones simultáneas durante el guardado");
            Check(!reloadVm.ConfirmLeave(), "Se permite salir mientras se está guardando");
            reloadStore.FailBlockRead = true;
        };
        reloadVm.SaveCommand.Execute(null);
        Check(reloadStore.Writes.Count == 1 && !reloadVm.HasChanges && !reloadVm.CanEdit && reloadVm.Status.StartsWith("Cambios guardados: 1"),
            "Un fallo al recargar hace pasar un guardado exitoso por fallido o permite editar datos desactualizados");
        reloadStore.FailBlockRead = false; reloadVm.RefreshCommand.Execute(null);
        Check(reloadVm.CanEdit && !reloadVm.HasChanges, "No se recupera el catálogo después de un guardado sin recarga");

        var previewVm = new PolicyViewModel(new PolicyMemoryStore(), session, _ => true);
        var view = new PolicyView { DataContext = previewVm, Background = Brushes.White };
        void Layout(int width, int height)
        {
            view.Width = width; view.Height = height;
            view.Measure(new Size(width, height)); view.Arrange(new Rect(0, 0, width, height)); view.UpdateLayout();
            view.Dispatcher.Invoke(() => { }, System.Windows.Threading.DispatcherPriority.ContextIdle);
            view.UpdateLayout();
        }
        Layout(960, 680);
        Check(((TabControl)view.FindName("PolicyTabs")).Items.Count == 2, "La pantalla básica conserva paneles innecesarios");
        Check(((Expander)view.FindName("AdvancedPolicyOptions")).Visibility == Visibility.Collapsed, "Las opciones avanzadas aparecen por defecto");
        var grid = (DataGrid)view.FindName("PermissionsGrid");
        var toggle = Descendants(grid).OfType<CheckBox>().First(x => x.Content?.ToString() == "Permitido");
        var toggleItem = (PermissionPolicyItem)toggle.DataContext;
        var peer = new CheckBoxAutomationPeer(toggle);
        ((IToggleProvider)peer.GetPattern(PatternInterface.Toggle)).Toggle();
        Check(!toggleItem.IsAllowed && previewVm.PendingCount == 1, "El interruptor WPF no edita directamente el estado");
        Check(((Button)view.FindName("SavePolicyButton")).IsEnabled, "La vista no habilita Guardar cambios después de editar");
        previewVm.DiscardCommand.Execute(null);
        previewVm.RefreshCommand.Execute(null);
        Layout(960, 680);
        string? previewPath = args.Length == 2 && args[0] == "--policy-preview" ? args[1] : null;
        if (previewPath is not null) { Directory.CreateDirectory(previewPath); RenderPreview(view, Path.Combine(previewPath, "politica-permisos.png"), 960, 680); }
        var tabs = (TabControl)view.FindName("PolicyTabs"); tabs.SelectedIndex = 1; Layout(960, 680);
        var rolesGrid = (DataGrid)view.FindName("RolesGrid");
        Check(Descendants(rolesGrid).OfType<CheckBox>().Any(x => x.Content?.ToString() == "Protegido" && !x.IsEnabled), "El rol protegido no aparece como un interruptor bloqueado");
        if (previewPath is not null) RenderPreview(view, Path.Combine(previewPath, "politica-roles.png"), 960, 680);
        previewVm.ShowAdvanced = true; tabs.SelectedIndex = 0; Layout(960, 680);
        Check(Descendants(grid).OfType<CheckBox>().Any(x => x.Content?.ToString() == "Asignar" && VisibleInTree(x, view)), "Los detalles avanzados no permiten editar acciones");
        if (previewPath is not null) RenderPreview(view, Path.Combine(previewPath, "politica-avanzada.png"), 960, 680);
        previewVm.ShowAdvanced = false; previewVm.Search = "inexistente"; Layout(720, 490);
        Check(!previewVm.HasVisiblePermissions && Descendants(view).OfType<TextBlock>().Any(x => x.Text.StartsWith("No hay resultados") && VisibleInTree(x, view)), "Una búsqueda vacía no muestra ayuda");
        previewVm.Search = ""; Layout(720, 490);
        var saveButton = (Button)view.FindName("SavePolicyButton");
        var savePosition = saveButton.TranslatePoint(new Point(), view);
        Check(savePosition.X >= 0 && savePosition.X + saveButton.ActualWidth <= 720 && savePosition.Y + saveButton.ActualHeight <= 490, "El guardado queda fuera de la pantalla pequeña");
        Check(grid.ActualHeight >= 120 && Descendants(grid).OfType<DataGridRow>().Any(x => VisibleInTree(x, view)), "Los selectores dejan la tabla de permisos sin filas visibles en la vista compacta");
        if (previewPath is not null) RenderPreview(view, Path.Combine(previewPath, "politica-compacta.png"), 720, 490);
        tabs.SelectedIndex = 1; Layout(720, 490);
        Check(rolesGrid.ActualHeight >= 120 && Descendants(rolesGrid).OfType<DataGridRow>().Any(x => VisibleInTree(x, view)), "La vista compacta no deja espacio para los roles");
    }

    private sealed class PolicyMemoryStore : IPolicyStore
    {
        public List<PolicyPermission> Permissions =
        [new("SELECT", "OBJECT", true, false, true, true, "admin", DateTime.UnixEpoch),
         new("SELECT", "DATABASE", true, false, true, true, "admin", DateTime.UnixEpoch),
         new("INSERT", "DATABASE", true, false, true, true, "admin", DateTime.UnixEpoch),
         new("DELETE", "DATABASE", true, false, true, true, "admin", DateTime.UnixEpoch),
         new("UPDATE", "COLUMN", false, false, true, false, "admin", DateTime.UnixEpoch)];
        public List<PolicyRole> Roles =
        [new("db_accessadmin", "FIXED", false, "admin", DateTime.UnixEpoch, "Administrar acceso"),
         new("db_backupoperator", "FIXED", false, "admin", DateTime.UnixEpoch, "Crear respaldos"),
         new("db_datareader", "FIXED", true, "admin", DateTime.UnixEpoch, "Leer todas las tablas y vistas"),
         new("db_datawriter", "FIXED", true, "admin", DateTime.UnixEpoch, "Agregar, modificar y eliminar datos"),
         new("db_ddladmin", "FIXED", false, "admin", DateTime.UnixEpoch, "Modificar objetos de la base"),
         new("db_owner", "FIXED", true, "admin", DateTime.UnixEpoch, "Control total de la base"),
         new("SqlAccessAdmin_Operator", "CUSTOM", true, "admin", DateTime.UnixEpoch, "Operador de la herramienta")];
        public List<DenyRule> Denials = [new(1, "DATABASE_ROLE", "db_owner", "Control total de la base: protegido por seguridad.", true, true, "admin", DateTime.UnixEpoch)];
        public List<object> Writes = [];
        public int Reads, BlockWrites;
        private int _writeAttempts;
        public int? FailWriteNumber;
        public bool FailBlockRead;
        public Action? BeforePermissionWrite;
        public Task<IReadOnlyList<PolicyPermission>> GetPolicyPermissionsAsync(CancellationToken ct = default)
        { Reads++; return Task.FromResult<IReadOnlyList<PolicyPermission>>(Permissions.ToList()); }
        public Task<IReadOnlyList<PolicyRole>> GetPolicyRolesAsync(CancellationToken ct = default) => Task.FromResult<IReadOnlyList<PolicyRole>>(Roles.ToList());
        public Task<IReadOnlyList<DenyRule>> GetDenyRulesAsync(CancellationToken ct = default) => FailBlockRead
            ? Task.FromException<IReadOnlyList<DenyRule>>(new Exception("error SQL interno")) : Task.FromResult<IReadOnlyList<DenyRule>>(Denials.ToList());
        public Task UpsertPermissionAsync(PolicyPermission permission, CancellationToken ct = default)
        {
            if (++_writeAttempts == FailWriteNumber) return Task.FromException(new Exception("error SQL interno"));
            BeforePermissionWrite?.Invoke();
            Writes.Add(permission); Permissions.RemoveAll(x => x.Permission == permission.Permission && x.Scope == permission.Scope); Permissions.Add(permission);
            return Task.CompletedTask;
        }
        public Task UpsertRoleAsync(PolicyRole role, CancellationToken ct = default)
        { Writes.Add(role); Roles.RemoveAll(x => x.Name == role.Name); Roles.Add(role); return Task.CompletedTask; }
        public Task UpsertDenyRuleAsync(string category, string value, string reason, CancellationToken ct = default)
        { BlockWrites++; Denials.Add(new(100, category, value, reason, false, true, "admin", DateTime.UtcNow)); return Task.CompletedTask; }
        public Task ActivateSpecialPolicyAsync(PolicySpecialActivation activation, CancellationToken ct = default)
        {
            activation.Validate();
            if (activation.Category == "DATABASE_ROLE")
            {
                var role = Roles.Single(x => x.Name == activation.Value);
                var updated = role with { Enabled = true, SpecialActivationApproved = true, SpecialActivationReason = activation.Reason };
                Roles[Roles.IndexOf(role)] = updated; Writes.Add(updated);
            }
            else
            {
                var permission = Permissions.FirstOrDefault(x => x.Permission == activation.Value && x.Scope == activation.Scope)
                    ?? new(activation.Value, activation.Scope, true, false, true, false, "admin", DateTime.UtcNow);
                Permissions.Remove(permission);
                var updated = permission with { Enabled = true, SpecialActivationApproved = true, SpecialActivationReason = activation.Reason };
                Permissions.Add(updated); Writes.Add(updated);
            }
            return Task.CompletedTask;
        }
    }
}
