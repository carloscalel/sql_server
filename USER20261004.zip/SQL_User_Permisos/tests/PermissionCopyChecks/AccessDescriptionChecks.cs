using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using SqlAccessAdmin.Models;
using SqlAccessAdmin.ViewModels;
using SqlAccessAdmin.Views;

internal static partial class Program
{
    private static void RunAccessDescriptionChecks(string[] args)
    {
        // Database-level permissions and specialized objects in the built-in SQL catalog.
        var names = new[]{
            "ADMINISTER DATABASE BULK OPERATIONS","ALTER","ALTER ANY APPLICATION ROLE","ALTER ANY ASSEMBLY",
            "ALTER ANY ASYMMETRIC KEY","ALTER ANY CERTIFICATE","ALTER ANY COLUMN ENCRYPTION KEY",
            "ALTER ANY COLUMN MASTER KEY","ALTER ANY CONTRACT","ALTER ANY DATABASE AUDIT",
            "ALTER ANY DATABASE DDL TRIGGER","ALTER ANY DATABASE EVENT NOTIFICATION","ALTER ANY DATABASE EVENT SESSION",
            "ALTER ANY DATABASE EVENT SESSION ADD EVENT","ALTER ANY DATABASE EVENT SESSION ADD TARGET",
            "ALTER ANY DATABASE EVENT SESSION DISABLE","ALTER ANY DATABASE EVENT SESSION DROP EVENT",
            "ALTER ANY DATABASE EVENT SESSION DROP TARGET","ALTER ANY DATABASE EVENT SESSION ENABLE",
            "ALTER ANY DATABASE EVENT SESSION OPTION","ALTER ANY DATABASE SCOPED CONFIGURATION","ALTER ANY DATASPACE",
            "ALTER ANY EXTERNAL DATA SOURCE","ALTER ANY EXTERNAL FILE FORMAT","ALTER ANY EXTERNAL JOB",
            "ALTER ANY EXTERNAL LANGUAGE","ALTER ANY EXTERNAL LIBRARY","ALTER ANY EXTERNAL STREAM",
            "ALTER ANY FULLTEXT CATALOG","ALTER ANY MASK","ALTER ANY MESSAGE TYPE","ALTER ANY REMOTE SERVICE BINDING",
            "ALTER ANY ROLE","ALTER ANY ROUTE","ALTER ANY SCHEMA","ALTER ANY SECURITY POLICY",
            "ALTER ANY SENSITIVITY CLASSIFICATION","ALTER ANY SERVICE","ALTER ANY SYMMETRIC KEY","ALTER ANY USER",
            "ALTER LEDGER","ALTER LEDGER CONFIGURATION","AUTHENTICATE","BACKUP DATABASE","BACKUP LOG","CHECKPOINT",
            "CONNECT","CONNECT REPLICATION","CONTROL","CREATE AGGREGATE","CREATE ANY DATABASE EVENT SESSION",
            "CREATE ASSEMBLY","CREATE ASYMMETRIC KEY","CREATE CERTIFICATE","CREATE CONTRACT","CREATE DATABASE",
            "CREATE DATABASE DDL EVENT NOTIFICATION","CREATE DEFAULT","CREATE EXTERNAL LANGUAGE","CREATE EXTERNAL LIBRARY",
            "CREATE FULLTEXT CATALOG","CREATE FUNCTION","CREATE MESSAGE TYPE","CREATE PROCEDURE","CREATE QUEUE",
            "CREATE REMOTE SERVICE BINDING","CREATE ROLE","CREATE ROUTE","CREATE RULE","CREATE SCHEMA","CREATE SEQUENCE",
            "CREATE SERVICE","CREATE SYMMETRIC KEY","CREATE SYNONYM","CREATE TABLE","CREATE TYPE","CREATE USER","CREATE VIEW",
            "CREATE XML SCHEMA COLLECTION","DELETE","DROP ANY DATABASE EVENT SESSION","ENABLE LEDGER","EXECUTE",
            "EXECUTE ANY EXTERNAL ENDPOINT","EXECUTE ANY EXTERNAL SCRIPT","INSERT","KILL DATABASE CONNECTION","REFERENCES",
            "SELECT","SHOWPLAN","SUBSCRIBE QUERY NOTIFICATIONS","TAKE OWNERSHIP","UNMASK","UPDATE",
            "VIEW ANY COLUMN ENCRYPTION KEY DEFINITION","VIEW ANY COLUMN MASTER KEY DEFINITION",
            "VIEW ANY SENSITIVITY CLASSIFICATION","VIEW CRYPTOGRAPHICALLY SECURED DEFINITION",
            "VIEW DATABASE PERFORMANCE STATE","VIEW DATABASE SECURITY AUDIT","VIEW DATABASE SECURITY STATE",
            "VIEW DATABASE STATE","VIEW DEFINITION","VIEW LEDGER CONTENT","VIEW SECURITY DEFINITION",
            "VIEW PERFORMANCE DEFINITION","VIEW CHANGE TRACKING","RECEIVE","SEND"
        };
        foreach(var name in names)
        {
            var text=SqlAccessDescriptions.Permission(name,"DATABASE");
            Check(text.Length is > 15 and <= 180&&!text.StartsWith("Permiso avanzado")&&!text.Contains(name,StringComparison.Ordinal), "Falta una explicación breve y clara de "+name);
        }
        Check(SqlAccessDescriptions.Permission("CREATE CONTRACT","DATABASE").Contains("mensajes"),"La descripción de CREATE CONTRACT no explica su uso");
        Check(SqlAccessDescriptions.Permission("ALTER ANY ROLE","DATABASE").Contains("personalizados"),"ALTER ANY ROLE se confunde con roles integrados");
        Check(SqlAccessDescriptions.Permission("REFERENCES","CREDENTIAL").Contains("credencial"),"REFERENCES no adapta su explicación al destino");
        Check(SqlAccessDescriptions.Permission("PERMISSION FROM FUTURE","DATABASE").StartsWith("Permiso avanzado"),"Se inventa una explicación para un permiso desconocido");
        var fixedNames=new[]{"db_owner","db_accessadmin","db_securityadmin","db_backupoperator","db_ddladmin",
            "db_datareader","db_datawriter","db_denydatareader","db_denydatawriter"};
        foreach(var name in fixedNames)
        {
            var role=new RolePolicyItem(new(name,"FIXED",true,"admin",DateTime.UnixEpoch,"Texto antiguo poco claro"));
            Check(role.Description==SqlAccessDescriptions.FixedRole(name,"DATABASE")&&!role.HasCustomDescription&&!role.CanEditDescription,"El rol integrado usa una descripción antigua o editable: "+name);
            role.Notes="Intento de cambiar el texto estándar";
            Check(!role.IsDirty&&role.ToPolicy("admin",DateTime.UnixEpoch).Notes=="Texto antiguo poco claro","La explicación fija altera datos de política");
        }
        foreach(var name in new[]{"sysadmin","serveradmin","securityadmin","processadmin","setupadmin","bulkadmin","diskadmin","dbcreator"})
        {
            var role=new RolePolicyItem(new(name,"FIXED",false,"admin",DateTime.UnixEpoch,"Texto antiguo"){RoleScope="SERVER"});
            Check(role.Description==SqlAccessDescriptions.FixedRole(name,"SERVER")&&role.Description.Length>20&&!role.HasCustomDescription,"Falta la explicación del rol integrado de instancia: "+name);
        }
        var custom=new RolePolicyItem(new("LecturaFacturas","CUSTOM",false,"admin",DateTime.UnixEpoch,""));
        Check(custom.Description=="Sin descripción"&&custom.CanEditDescription,"Se inventa o bloquea una descripción personalizada");
        custom.Notes="Leer únicamente las facturas autorizadas.";
        Check(custom.Description==custom.Notes&&custom.IsDirty,"No se puede editar la descripción de un rol personalizado");
        var sameName=new RolePolicyItem(new("db_datareader","CUSTOM",false,"admin",DateTime.UnixEpoch,"Descripción personalizada"));
        Check(sameName.Description=="Descripción personalizada","Un rol personalizado recibe una explicación de rol fijo por su nombre");
        var store=new PolicyMemoryStore();
        store.Permissions.AddRange(new[]{"ALTER ANY ROLE","ALTER ANY ROUTE","ALTER ANY SCHEMA","CREATE CONTRACT","ALTER ANY SECURITY POLICY"}
            .Select(name=>new PolicyPermission(name,"DATABASE",true,false,true,false,"admin",DateTime.UnixEpoch)));
        var vm=new PolicyViewModel(store,new("admin",AppRole.Administrator),_=>true);
        vm.Search="mensajes";
        Check(vm.PermissionView.Cast<PermissionPolicyItem>().Any(x=>x.Permission=="CREATE CONTRACT"),"La búsqueda no incluye las nuevas explicaciones");
        vm.Search="";
        var view=new PolicyView{DataContext=vm,Background=Brushes.White,Width=1600,Height=850};
        void Layout()
        {
            view.Measure(new Size(1600,850));view.Arrange(new Rect(0,0,1600,850));view.UpdateLayout();
            view.Dispatcher.Invoke(()=>{},System.Windows.Threading.DispatcherPriority.ContextIdle);
            view.UpdateLayout();
        }
        Layout();
        var grid=(DataGrid)view.FindName("PermissionsGrid");
        Check(grid.Columns.Any(x=>Equals(x.Header,"Para qué sirve")),"La explicación solo está en un tooltip o en detalles avanzados");
        vm.Search="CREATE CONTRACT";Layout();
        Check(Descendants(grid).OfType<TextBlock>().Any(x=>x.Text.Contains("mensajes")&&VisibleInTree(x,view)),"La explicación de CREATE CONTRACT no aparece en la fila");
        if(args.Length==2&&args[0]=="--policy-preview")
        {
            vm.Search="";Layout();
            RenderPreview(view,Path.Combine(args[1],"politica-descripciones-permisos.png"),1600,850);
            vm.Search="CREATE CONTRACT";Layout();
            RenderPreview(view,Path.Combine(args[1],"politica-descripcion-contrato.png"),1600,850);
            vm.Search="";
            ((TabControl)view.FindName("PolicyTabs")).SelectedIndex=1;Layout();
            RenderPreview(view,Path.Combine(args[1],"politica-descripciones-roles.png"),1600,850);
        }
        ((TabControl)view.FindName("PolicyTabs")).SelectedIndex=1;
        vm.ShowAdvanced=true;vm.Search="SqlAccessAdmin_Operator";Layout();
        var rolesGrid=(DataGrid)view.FindName("RolesGrid");
        var customEditor=Descendants(rolesGrid).OfType<TextBox>()
            .FirstOrDefault(x=>x.DataContext is RolePolicyItem {HasCustomDescription:true}&&VisibleInTree(x,view));
        Check(customEditor is {IsEnabled:true,MaxLength:500},"No aparece el editor de descripción de un rol personalizado en Detalles avanzados");
        customEditor!.Text="Gestionar solicitudes de acceso desde la aplicación.";
        customEditor.GetBindingExpression(TextBox.TextProperty)!.UpdateSource();
        Check(vm.PendingCount==1&&store.Writes.Count==0,"Editar la descripción no conserva el borrador o guarda sin confirmación");
        vm.SaveCommand.Execute(null);
        Check(store.Writes.OfType<PolicyRole>().Single().Notes=="Gestionar solicitudes de acceso desde la aplicación.","No se guarda la descripción personalizada con la política");
        vm.Search="db_datareader";Layout();
        Check(!Descendants(rolesGrid).OfType<TextBox>().Any(x=>VisibleInTree(x,view)),"El texto estándar de un rol integrado es editable en la vista");
        Check(store.Writes.OfType<PolicyPermission>().Count()==0,"Las descripciones modifican reglas de permisos");
        vm.Search="";vm.ShowAdvanced=false;
        var compact=new PolicyView{DataContext=vm,Background=Brushes.White,Width=720,Height=490};
        void CompactLayout()
        {
            compact.Measure(new Size(720,490));compact.Arrange(new Rect(0,0,720,490));compact.UpdateLayout();
            compact.Dispatcher.Invoke(()=>{},System.Windows.Threading.DispatcherPriority.ContextIdle);compact.UpdateLayout();
        }
        CompactLayout();
        var compactGrid=(DataGrid)compact.FindName("PermissionsGrid");
        Check(Descendants(compactGrid).OfType<TextBlock>().Any(x=>x.Text=="Consultar datos sin modificarlos."&&VisibleInTree(x,compact)),"La ventana pequeña no muestra la explicación");
        if(args.Length==2&&args[0]=="--policy-preview")
            RenderPreview(compact,Path.Combine(args[1],"politica-descripciones-compacta.png"),720,490);
        compactGrid.ScrollIntoView(vm.PermissionView.Cast<PermissionPolicyItem>().First(),compactGrid.Columns[4]);CompactLayout();
        var visibleToggle=Descendants(compactGrid).OfType<CheckBox>().First(x=>x.Content?.ToString()=="Permitido");
        var togglePosition=visibleToggle.TranslatePoint(new Point(),compactGrid);
        Check(togglePosition.X>=0&&togglePosition.X+visibleToggle.ActualWidth<=compactGrid.ActualWidth,"El desplazamiento horizontal no permite alcanzar Disponibilidad en una ventana pequeña");
    }
}
