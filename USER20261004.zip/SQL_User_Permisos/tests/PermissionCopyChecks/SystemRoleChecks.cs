using System.Data;
using System.Reflection;
using SqlAccessAdmin.Models;
using SqlAccessAdmin.ViewModels;

internal static partial class Program
{
    private static void RunSystemRoleChecks()
    {
        var store=new PolicyMemoryStore();
        foreach(var name in new[]{"##MS_LoginManager##","##MS_ServerStateReader##","personalizado##interno"})
        {
            var role=new PolicyRole(name,"FIXED",true,"admin",DateTime.UnixEpoch,"")
                {RoleScope="SERVER",SpecialActivationApproved=true};
            store.Roles.Add(role);
            Check(PolicyEditorCatalog.IsPermanentlyBlockedRole(name)&&!PolicyEditorCatalog.CanUseRole(role,[]),"Una autorización antigua habilita un rol reservado");
            var request=new PolicySpecialActivation("SERVER_ROLE",name,"","Confirmación válida de pruebas de seguridad",name,true);
            try{request.Validate();throw new Exception("Se permite activar un rol con ##");}
            catch(InvalidOperationException){_checks++;}
            try{Call("BuildServerRoleSql","usuario",name,true);throw new Exception("Se genera una membresía de rol reservado");}
            catch(TargetInvocationException error)when(error.InnerException is InvalidOperationException){_checks++;}
            var item=new PermissionCopyAccessItem("Ventas","Rol","Asignado","","DATABASE","","","",name,true,"Copiar");
            Reject(item);
        }
        var vm=new PolicyViewModel(store,new("admin",AppRole.Administrator),_=>true);
        Check(vm.Roles.All(x=>!SqlSystemNames.IsReserved(x.Name))&&vm.RoleView.Cast<RolePolicyItem>().All(x=>!SqlSystemNames.IsReserved(x.Name)),"La política muestra roles reservados ya guardados");
        Check(vm.Roles.Any(x=>x.Name=="db_datareader")&&vm.Roles.Any(x=>x.Name=="SqlAccessAdmin_Operator"),"El filtro oculta roles administrables");
        var table=new DataTable();table.Columns.Add("Rol");table.Columns.Add("Principal");
        table.Rows.Add("##MS_LoginManager##","usuario");table.Rows.Add("normal","usuario##interno");table.Rows.Add("normal","usuario");
        Call("RemoveReservedInventoryRows",table);
        Check(table.Rows.Count==1&&table.Rows[0].Field<string>("Principal")=="usuario","El inventario conserva nombres reservados o elimina entradas normales");
    }
}
