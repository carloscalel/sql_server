using System.IO;
using System.Reflection;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using SqlAccessAdmin.Data;
using SqlAccessAdmin.Models;
using SqlAccessAdmin.ViewModels;
using SqlAccessAdmin.Views;

internal static partial class Program
{
    private static void RunScopedPolicyChecks(string[] args)
    {
        var longPermission = "VIEW " + new string('A', 55);
        Check(SqlPermissionSafety.IsPermissionName(longPermission), "El catálogo sigue rechazando permisos de más de 40 caracteres");
        Check(SqlPermissionSafety.IsPermissionName(new string('A', 128)) && !SqlPermissionSafety.IsPermissionName(new string('A', 129)), "El límite ampliado de permisos no se valida correctamente");
        Check((string)Call("BuildPermissionSql", "usuario", "GRANT", longPermission, "DATABASE", "")! == $"GRANT {longPermission} TO [usuario]", "Se recorta un permiso largo al generar SQL");
        Check(SqlPermissionSafety.DiscoverPermissions("REFERENCES","CREDENTIAL").Single().Scope=="CREDENTIAL", "REFERENCES/CREDENTIAL impide descubrir la instancia");
        Check(SqlPermissionSafety.Scope("CREDENTIAL") is {IsServer:true,Parts:1}, "La credencial de instancia se clasifica como permiso de base");
        Check(SqlPermissionSafety.DiscoverPermissions("REFERENCES","DATABASE_SCOPED_CREDENTIAL").Single().Scope=="DB_CREDENTIAL", "Las credenciales de base se confunden con las de instancia");
        Check(SqlPermissionSafety.DiscoverPermissions("SELECT","OBJECT_OR_COLUMN").Select(x=>x.Scope).SequenceEqual(new[]{"OBJECT","COLUMN"}), "El descubrimiento pierde permisos de columna");
        Check((string)Call("BuildPermissionSql","login","GRANT","REFERENCES","CREDENTIAL","Credencial]x")! == "GRANT REFERENCES ON CREDENTIAL::[Credencial]]x] TO [login]", "No se genera el permiso de credencial con destino delimitado");
        try{SqlPermissionSafety.DiscoverPermissions("REFERENCES","UNKNOWN_CLASS");throw new Exception("Se omite silenciosamente una clase no reconocida");}
        catch(InvalidOperationException){_checks++;}
        var store=new ScopedPolicyStore();
        var confirm=true;
        var vm=new PolicyViewModel(store,new("admin",AppRole.Administrator),_=>confirm,discovery:store);
        Check(vm.Instances.Count==3&&vm.Context==PolicyContext.General,"No se cargan las instancias");
        vm.SelectedInstance=vm.Instances[1];
        Check(vm.Context==new PolicyContext(1)&&vm.Databases.Count==3,"Cambiar instancia no carga las bases");
        var writer=vm.Roles.Single(x=>x.Name=="db_datawriter");
        Check(writer.IsAllowed&&writer.OriginDisplay=="General","La instancia no hereda la plantilla");
        writer.IsAllowed=false;
        confirm=false;vm.SelectedInstance=vm.Instances[2];
        Check(vm.Context.ServerId==1&&vm.HasChanges,"Cambiar destino pierde un borrador sin confirmación");
        confirm=true;vm.SaveCommand.Execute(null);
        writer=vm.Roles.Single(x=>x.Name=="db_datawriter");
        Check(!writer.IsAllowed&&writer.OriginDisplay=="Instancia"&&writer.RestoreCommand!.CanExecute(null),"No persiste el bloqueo de instancia");
        vm.SelectedDatabase=vm.Databases.Single(x=>x.Name=="Ventas");
        writer=vm.Roles.Single(x=>x.Name=="db_datawriter");
        Check(!writer.IsAllowed&&writer.Origin=="INSTANCE"&&!writer.CanRestoreInheritance,"La base no hereda el bloqueo de su instancia");
        writer.IsAllowed=true;vm.SaveCommand.Execute(null);
        Check(vm.Roles.Single(x=>x.Name=="db_datawriter").Origin=="DATABASE","La excepción de base no conserva su origen");
        var context=new PolicyContext(1,"Ventas");
        var custom=vm.Roles.Single(x=>x.Name=="LecturaFacturas");
        Check(!custom.IsAllowed&&custom.Origin=="DISCOVERED","El rol descubierto se habilita automáticamente");
        custom.IsAllowed=true;vm.SaveCommand.Execute(null);
        Check(store.RoleWrites.Last().Context==context&&vm.Roles.Single(x=>x.Name=="LecturaFacturas").IsAllowed,"La autorización personalizada no se guarda por base");
        var control=vm.Permissions.Single(x=>x.Permission=="CONTROL"&&x.Scope=="DATABASE");
        Check(control.IsProtected&&control.CanRequestSpecialActivation,"CONTROL no se puede habilitar desde la aplicación");
        vm.BeginSpecialActivation(control);
        Check(vm.Activation!.Destination.Contains("Ventas"),"La segunda confirmación no identifica el destino");
        vm.Activation.Reason="Autorizar CONTROL en esta base específica de pruebas.";
        vm.Activation.ConfirmedName="CONTROL";vm.Activation.RiskAcknowledged=true;
        vm.ActivateSpecialCommand.Execute(null);
        control=vm.Permissions.Single(x=>x.Permission=="CONTROL"&&x.Scope=="DATABASE");
        Check(control.IsAllowed&&control.Origin=="DATABASE"&&!vm.HasChanges,"No se conserva la excepción protegida en su destino");
        control.AllowGrant=false;control.AllowRevoke=false;control.AllowDeny=true;vm.SaveCommand.Execute(null);
        Check(store.PermissionWrites.Last().Rule.AllowDeny&&!store.PermissionWrites.Last().Rule.AllowGrant,"No se guarda una política de solo DENY");
        Call("ValidatePermissionPolicySnapshot","CONTROL","DATABASE","DENY",store.GetPolicyPermissionsAsync(context).Result.ToArray(),Array.Empty<DenyRule>());
        try{Call("ValidatePermissionPolicySnapshot","CONTROL","DATABASE","GRANT",store.GetPolicyPermissionsAsync(context).Result.ToArray(),Array.Empty<DenyRule>());throw new Exception("Se ignora la acción autorizada");}
        catch(TargetInvocationException e)when(e.InnerException is InvalidOperationException){_checks++;}
        vm.SelectedDatabase=vm.Databases.Single(x=>x.Name=="Reportes");
        Check(!vm.Roles.Single(x=>x.Name=="db_datawriter").IsAllowed&&!vm.Roles.Single(x=>x.Name=="LecturaFacturas").IsAllowed,"Una base hereda excepciones de otra");
        Check(vm.Permissions.Single(x=>x.Permission=="CONTROL"&&x.Scope=="DATABASE").IsProtected,"La excepción de CONTROL se filtra a otra base");
        vm.SelectedInstance=vm.Instances[2];vm.SelectedDatabase=vm.Databases.Single(x=>x.Name=="Ventas");
        Check(vm.Roles.Single(x=>x.Name=="db_datawriter").IsAllowed&&!vm.Roles.Single(x=>x.Name=="LecturaFacturas").IsAllowed,"La política de una instancia afecta a otra");
        vm.SelectedInstance=vm.Instances[1];vm.SelectedDatabase=vm.Databases.Single(x=>x.Name=="Ventas");
        writer=vm.Roles.Single(x=>x.Name=="db_datawriter");writer.RestoreCommand!.Execute(null);
        Check(!vm.Roles.Single(x=>x.Name=="db_datawriter").IsAllowed&&vm.Roles.Single(x=>x.Name=="db_datawriter").Origin=="INSTANCE","Restaurar no elimina solo la excepción de base");
        control=vm.Permissions.Single(x=>x.Permission=="CONTROL"&&x.Scope=="DATABASE");
        control.RestoreCommand!.Execute(null);
        Check(vm.Permissions.Single(x=>x.Permission=="CONTROL"&&x.Scope=="DATABASE").IsProtected,"Restaurar conserva una autorización especial local");
        vm.SelectedDatabase=vm.Databases[0];
        var admin=vm.Roles.Single(x=>x.Name=="sysadmin");
        Check(admin.IsProtected&&admin.CanRequestSpecialActivation&&admin.RoleScope=="SERVER","No se puede autorizar un rol de servidor");
        vm.BeginSpecialActivation(admin);
        Check(vm.Activation!.ToRequest().Category=="SERVER_ROLE","La activación de servidor se envía como rol de base");
        vm.Activation.Reason="Autorizar administración de la instancia de pruebas.";
        vm.Activation.ConfirmedName="sysadmin";vm.Activation.RiskAcknowledged=true;vm.ActivateSpecialCommand.Execute(null);
        Check(vm.Roles.Single(x=>x.Name=="sysadmin").IsAllowed,"La autorización de sysadmin no es utilizable");
        vm.SelectedInstance=vm.Instances[2];
        Check(vm.Roles.Single(x=>x.Name=="sysadmin").IsProtected,"La autorización de servidor se comparte entre instancias");
        Check((string)Call("BuildPermissionSql","u]x","DENY","ALTER ANY USER","DATABASE","")! == "DENY ALTER ANY USER TO [u]]x]","No se genera DENY de un permiso ampliado");
        Check((string)Call("BuildPermissionSql","login","GRANT","CONTROL SERVER","SERVER","")! == "GRANT CONTROL SERVER TO [login]","No se genera un permiso de instancia");
        Check((string)Call("BuildPermissionSql","login","GRANT","IMPERSONATE","LOGIN","Otro]login")! == "GRANT IMPERSONATE ON LOGIN::[Otro]]login] TO [login]","No se delimita un securable de instancia");
        Check((string)Call("BuildServerRoleSql","u]x","sysadmin",true)! == "ALTER SERVER ROLE [sysadmin] ADD MEMBER [u]]x]","SQL de membresía de servidor incorrecto");
        foreach(var text in new[]{"SELECT; DROP TABLE t","SELECT\nGRANT CONTROL","SELECT--","SELECT TO [x]"})
            Check(!SqlPermissionSafety.IsPermissionName(text),"Un nombre de permiso permite inyección");
        vm.SelectedInstance=vm.Instances[1];vm.SelectedDatabase=vm.Databases.Single(x=>x.Name=="Ventas");
        var view=new PolicyView{DataContext=vm,Background=Brushes.White,Width=1100,Height=760};
        ((TabControl)view.FindName("PolicyTabs")).SelectedIndex=1;
        view.Measure(new Size(1100,760));view.Arrange(new Rect(0,0,1100,760));view.UpdateLayout();
        Check(Equals(((ComboBox)view.FindName("PolicyDatabaseSelector")).SelectedItem,vm.SelectedDatabase),"El selector visual pierde la base elegida");
        if(args.Length==2&&args[0]=="--policy-preview")
            RenderPreview(view,Path.Combine(args[1],"politica-por-base.png"),1100,760);
        vm.SelectedDatabase=vm.Databases[0];
        var read=vm.Permissions.Single(x=>x.Permission=="SELECT"&&x.Scope=="DATABASE");
        read.IsAllowed=false;vm.SaveCommand.Execute(null);
        Check(store.PermissionWrites.Last().Context==new PolicyContext(1)&&store.PermissionWrites.Last().Rule.Origin=="INSTANCE", "El permiso de instancia se guarda en la plantilla general");
        vm.SelectedInstance=vm.Instances[2];
        Check(vm.Permissions.Single(x=>x.Permission=="SELECT"&&x.Scope=="DATABASE").IsAllowed,"Bloquear lectura en X afecta a la instancia Y");
        vm.SelectedInstance=vm.Instances[1];
        Check(!vm.Permissions.Single(x=>x.Permission=="SELECT"&&x.Scope=="DATABASE").IsAllowed,"Se pierde la personalización de permisos al regresar a X");
        store.FailDiscovery=true;vm.SelectedInstance=vm.Instances[2];
        Check(!vm.IsBusy&&!vm.CanEdit&&vm.CanChangeContext&&vm.RefreshCommand.CanExecute(null),"Un error de descubrimiento bloquea los selectores o impide reintentar");
        Check(vm.Roles.Count==0&&vm.Permissions.Count==0&&!vm.SaveCommand.CanExecute(null),"La instancia fallida muestra o permite guardar reglas de otro destino");
        view.UpdateLayout();var tabs=(TabControl)view.FindName("PolicyTabs");
        Check(tabs.IsEnabled,"Un catálogo no disponible congela la navegación de las pestañas");
        tabs.SelectedIndex=0;tabs.SelectedIndex=1;
        Check(tabs.SelectedIndex==1,"No se puede cambiar de pestaña tras fallar el descubrimiento");
        store.FailDiscovery=false;vm.RefreshCommand.Execute(null);
        Check(vm.CanEdit&&vm.Roles.Count>0&&vm.Context==new PolicyContext(2),"Actualizar no recupera la edición del destino seleccionado");
        view.Height=490;view.Measure(new Size(1100,490));view.Arrange(new Rect(0,0,1100,490));view.UpdateLayout();
        var rolesGrid=(DataGrid)view.FindName("RolesGrid");
        var scroller=Descendants(rolesGrid).OfType<ScrollViewer>().First();
        Check(rolesGrid.IsEnabled&&scroller.IsEnabled&&scroller.ScrollableHeight>0,"El catálogo de instancia no permite desplazarse por los roles");
        scroller.ScrollToEnd();view.UpdateLayout();
        view.Dispatcher.Invoke(()=>{},System.Windows.Threading.DispatcherPriority.ContextIdle);view.UpdateLayout();
        Check(scroller.VerticalOffset>0,"El desplazamiento de la pestaña Roles sigue bloqueado");
        view.Height=760;view.Measure(new Size(1100,760));view.Arrange(new Rect(0,0,1100,760));view.UpdateLayout();
        scroller.ScrollToHome();view.UpdateLayout();
        if(args.Length==2&&args[0]=="--policy-preview")
            RenderPreview(view,Path.Combine(args[1],"politica-por-instancia.png"),1100,760);
    }

    private sealed class ScopedPolicyStore:IPolicyStore,IPolicyDiscovery
    {
        private readonly Dictionary<(PolicyContext,string,string),PolicyRole> _roles=[];
        private readonly Dictionary<(PolicyContext,string,string),PolicyPermission> _permissions=[];
        private readonly Dictionary<PolicyContext,IReadOnlyList<DiscoveredPolicyRole>> _discovered=[];
        public List<(PolicyContext Context,PolicyRole Rule)> RoleWrites=[];
        public List<(PolicyContext Context,PolicyPermission Rule)> PermissionWrites=[];
        public bool FailDiscovery;
        public ScopedPolicyStore()
        {
            foreach(var name in new[]{"db_datareader","db_datawriter"})
                _roles[(PolicyContext.General,name,"DATABASE")]=new(name,"FIXED",true,"admin",DateTime.UnixEpoch,"Lectura / escritura");
            _roles[(PolicyContext.General,"sysadmin","SERVER")]=new("sysadmin","FIXED",false,"admin",DateTime.UnixEpoch,"Control de instancia"){RoleScope="SERVER"};
            _permissions[(PolicyContext.General,"CONTROL","DATABASE")]=new("CONTROL","DATABASE",true,false,true,false,"admin",DateTime.UnixEpoch);
            _permissions[(PolicyContext.General,"SELECT","DATABASE")]=new("SELECT","DATABASE",true,false,true,true,"admin",DateTime.UnixEpoch);
        }
        private static IEnumerable<PolicyContext> Parents(PolicyContext c)
        {
            yield return c;
            if(c.Database.Length>0)yield return new(c.ServerId);
            if(c.ServerId>0)yield return PolicyContext.General;
        }
        public Task<IReadOnlyList<ServerItem>> GetServersAsync(CancellationToken ct=default)=>Task.FromResult<IReadOnlyList<ServerItem>>([new(){Id=1,Name="Instancia X",Active=true},new(){Id=2,Name="Instancia Y",Active=true}]);
        public Task<IReadOnlyList<DatabaseItem>> GetPolicyDatabasesAsync(ServerItem s,CancellationToken ct=default)=>Task.FromResult<IReadOnlyList<DatabaseItem>>([new(){ServerId=s.Id,Server=s.Name,Name="Ventas"},new(){ServerId=s.Id,Server=s.Name,Name="Reportes"}]);
        public Task<PolicyDiscoveryResult> DiscoverPolicyAsync(PolicyContext c,CancellationToken ct=default)=>FailDiscovery
            ?Task.FromException<PolicyDiscoveryResult>(new InvalidOperationException("Error de descubrimiento simulado"))
            :Task.FromResult(new PolicyDiscoveryResult(c.Database.Length>0?[new("LecturaFacturas","CUSTOM","DATABASE","Lectura de tablas seleccionadas")]:[]));
        public Task RegisterPolicyDiscoveryAsync(PolicyContext c,PolicyDiscoveryResult r,CancellationToken ct=default){_discovered[c]=r.Roles;return Task.CompletedTask;}
        public Task<IReadOnlyList<PolicyRole>> GetPolicyRolesAsync(PolicyContext c,CancellationToken ct=default)
        {
            var keys=_roles.Keys.Select(x=>(Name:x.Item2,Scope:x.Item3)).Concat(_discovered.GetValueOrDefault(c,[]).Select(x=>(Name:x.Name,Scope:x.RoleScope))).Distinct();
            var result=new List<PolicyRole>();
            foreach(var key in keys.Where(x=>c.Database.Length==0||x.Scope=="DATABASE"))
            {
                var rule=Parents(c).Select(p=>_roles.GetValueOrDefault((p,key.Name,key.Scope)) is {} role&&(role.Kind=="FIXED"||p==c)?role with{Origin=p.Level}:null).FirstOrDefault(x=>x is not null);
                if(rule is not null)result.Add(rule);
                else if(_discovered.GetValueOrDefault(c,[]).Any(x=>x.Name==key.Name))
                    result.Add(new(key.Name,"CUSTOM",false,"",DateTime.UnixEpoch,"Rol descubierto"){Origin="DISCOVERED",RoleScope=key.Scope});
            }
            return Task.FromResult<IReadOnlyList<PolicyRole>>(result);
        }
        public Task<IReadOnlyList<PolicyPermission>> GetPolicyPermissionsAsync(PolicyContext c,CancellationToken ct=default)
        {
            var result=_permissions.Keys.Select(x=>(Name:x.Item2,Scope:x.Item3)).Distinct().Select(key=>Parents(c)
                .Select(p=>_permissions.GetValueOrDefault((p,key.Name,key.Scope)) is {} rule?rule with{Origin=p.Level}:null).First(x=>x is not null)!).ToList();
            return Task.FromResult<IReadOnlyList<PolicyPermission>>(result);
        }
        public Task<IReadOnlyList<DenyRule>> GetDenyRulesAsync(CancellationToken ct=default)=>Task.FromResult<IReadOnlyList<DenyRule>>([]);
        public Task UpsertRoleAsync(PolicyContext c,PolicyRole r,CancellationToken ct=default){_roles[(c,r.Name,r.RoleScope)]=r;RoleWrites.Add((c,r));return Task.CompletedTask;}
        public Task UpsertPermissionAsync(PolicyContext c,PolicyPermission r,CancellationToken ct=default){_permissions[(c,r.Permission,r.Scope)]=r;PermissionWrites.Add((c,r));return Task.CompletedTask;}
        public Task RestorePolicyInheritanceAsync(PolicyContext c,string category,string value,string scope,CancellationToken ct=default)
        {if(category=="PERMISSION")_permissions.Remove((c,value,scope));else _roles.Remove((c,value,category=="SERVER_ROLE"?"SERVER":"DATABASE"));return Task.CompletedTask;}
        public async Task ActivateSpecialPolicyAsync(PolicyContext c,PolicySpecialActivation a,CancellationToken ct=default)
        {
            a.Validate();
            if(a.Category=="PERMISSION")
            {var rule=(await GetPolicyPermissionsAsync(c)).Single(x=>x.Permission==a.Value&&x.Scope==a.Scope);await UpsertPermissionAsync(c,rule with{Enabled=true,SpecialActivationApproved=true,SpecialActivationReason=a.Reason,Origin=c.Level});}
            else
            {var rule=(await GetPolicyRolesAsync(c)).Single(x=>x.Name==a.Value);await UpsertRoleAsync(c,rule with{Enabled=true,SpecialActivationApproved=true,SpecialActivationReason=a.Reason,Origin=c.Level});}
        }
        public Task<IReadOnlyList<PolicyPermission>> GetPolicyPermissionsAsync(CancellationToken ct=default)=>throw new Exception("Se usó el contrato general antiguo");
        public Task<IReadOnlyList<PolicyRole>> GetPolicyRolesAsync(CancellationToken ct=default)=>throw new Exception("Se usó el contrato general antiguo");
        public Task UpsertPermissionAsync(PolicyPermission p,CancellationToken ct=default)=>throw new Exception("Escritura sin destino");
        public Task UpsertRoleAsync(PolicyRole r,CancellationToken ct=default)=>throw new Exception("Escritura sin destino");
        public Task ActivateSpecialPolicyAsync(PolicySpecialActivation a,CancellationToken ct=default)=>throw new Exception("Activación sin destino");
        public Task UpsertDenyRuleAsync(string c,string v,string r,CancellationToken ct=default)=>throw new NotSupportedException();
    }
}
