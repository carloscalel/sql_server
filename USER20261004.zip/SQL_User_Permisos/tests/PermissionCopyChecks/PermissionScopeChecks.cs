using System.IO;
using System.Collections.ObjectModel;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Media;
using SqlAccessAdmin.Models;
using SqlAccessAdmin.ViewModels;
using SqlAccessAdmin.Views;

internal static partial class Program
{
    private static void RunPermissionScopeChecks(string[] args)
    {
        var session = new SessionContext("Administrador de pruebas", AppRole.Administrator);
        foreach (var name in PolicyEditorCatalog.SupportedPermissions)
        foreach (var scope in new[]{"DATABASE","OBJECT","SCHEMA","COLUMN"})
        {
            var compatible = PolicyEditorCatalog.CanManagePermission(name, scope);
            if (!compatible)
            {
                var invalid = new PolicyPermission(name, scope, true, false, true, true, "admin", DateTime.UnixEpoch)
                    { SpecialActivationApproved = true };
                Check(!PolicyEditorCatalog.CanUsePermission(invalid, []), "Una excepción habilita una combinación SQL inválida");
                Check(!new PermissionPolicyItem(invalid, PolicyEditorCatalog.PermissionProtection(name, scope, [])).CanRequestSpecialActivation,
                    "Se ofrece activar un permiso de columna inválido");
                continue;
            }
            if (!PolicyEditorCatalog.RequiresPermissionActivation(name, scope)) continue;
            var store = new PolicyMemoryStore();
            store.Permissions.RemoveAll(x => x.Permission == name && x.Scope == scope);
            store.Permissions.Add(new(name, scope, true, false, true, true, "admin", DateTime.UnixEpoch));
            var vm = new PolicyViewModel(store, session, _ => true);
            var item = vm.Permissions.Single(x => x.Permission == name && x.Scope == scope);
            Check(item.IsProtected && !item.IsAllowed && item.ActivateCommand!.CanExecute(null), "El permiso protegido carece de activación especial");
            vm.BeginSpecialActivation(item);
            Check(vm.Activation!.ToRequest().Scope == scope && !vm.ActivateSpecialCommand.CanExecute(null), "La confirmación pierde el alcance o permite una activación vacía");
            vm.Activation.Reason = "Autorización especial para pruebas de permisos protegidos.";
            vm.Activation.ConfirmedName = name;
            Check(!vm.ActivateSpecialCommand.CanExecute(null), "El permiso se puede habilitar sin reconocer el riesgo");
            vm.Activation.RiskAcknowledged = true;
            vm.Activation.ConfirmedName = name.ToLowerInvariant();
            Check(!vm.ActivateSpecialCommand.CanExecute(null), "El permiso no exige su nombre exacto");
            vm.Activation.ConfirmedName = name;
            vm.ActivateSpecialCommand.Execute(null);
            item = vm.Permissions.Single(x => x.Permission == name && x.Scope == scope);
            var saved = store.Permissions.Single(x => x.Permission == name && x.Scope == scope);
            Check(item.IsAllowed && item.HasSpecialActivation && !vm.HasChanges && PolicyEditorCatalog.CanUsePermission(saved, []),
                "La activación no vuelve utilizable el permiso protegido");
            Call("ValidatePermissionPolicySnapshot", name, scope, "GRANT", new[] { saved }, Array.Empty<DenyRule>());
            Check(PolicyEditorCatalog.PermissionProtection(name, scope, [], true) == "", "El catálogo y la ejecución discrepan sobre la excepción");
            item.IsAllowed = false; vm.SaveCommand.Execute(null);
            item = vm.Permissions.Single(x => x.Permission == name && x.Scope == scope);
            Check(item.IsProtected && !item.HasSpecialActivation && item.CanRequestSpecialActivation, "Bloquear un permiso no retira su excepción");
            item.IsAllowed = true;
            Check(!item.IsAllowed && !vm.HasChanges, "Se reactiva un permiso sin repetir la confirmación");
            try { Call("ValidatePermissionPolicySnapshot", name, scope, "GRANT", store.Permissions.ToArray(), Array.Empty<DenyRule>()); throw new Exception("Se ejecuta un permiso después de bloquearlo"); }
            catch (TargetInvocationException ex) when (ex.InnerException is InvalidOperationException) { _checks++; }
        }
        Check((string)Call("BuildPermissionSql", "u]x", "GRANT", "DELETE", "SCHEMA", "ventas]x")! == "GRANT DELETE ON SCHEMA::[ventas]]x] TO [u]]x]", "SQL de esquema incorrecto o sin delimitar");
        Check((string)Call("BuildPermissionSql", "usuario", "REVOKE", "REFERENCES", "COLUMN", "ventas.Factura.Total")! == "REVOKE REFERENCES ON OBJECT::[ventas].[Factura] ([Total]) FROM [usuario]", "SQL de columna incorrecto");
        foreach (var (scope, target) in new[] { ("SCHEMA", "a.b"), ("COLUMN", "dbo..c"), ("COLUMN", "dbo.t"), ("OBJECT", ".dbo.t"), ("DATABASE", "dbo.t"), ("COLUMN", "dbo.t."), ("OBJECT", new string('a',129)+".t") })
        {
            try { Call("BuildPermissionSql", "usuario", "GRANT", "SELECT", scope, target); throw new Exception("Se acepta un destino incompleto o ajeno al ámbito"); }
            catch (TargetInvocationException ex) when (ex.InnerException is InvalidOperationException) { _checks++; }
        }
        var columnAccess = new PermissionCopyAccessItem("Ventas", "Permiso", "GRANT", "REFERENCES", "COLUMN", "dbo", "Factura", "Id]x", "", true, "Copiar");
        Check((string)Call("BuildCopiedAccessSql", columnAccess, "nuevo")! == "GRANT REFERENCES ON OBJECT::[dbo].[Factura] ([Id]]x]) TO [nuevo]", "La copia pierde el alcance de columna");
        Check((string)Call("BuildCopiedAccessSql", columnAccess with { Permission = "EXECUTE", Scope = "SCHEMA", Object = "", Column = "" }, "nuevo")! == "GRANT EXECUTE ON SCHEMA::[dbo] TO [nuevo]", "La copia pierde el alcance de esquema");
        var table = new DatabaseObjectItem(1, "CAEL", "Ventas", "dbo", "Factura", "TABLE");
        var row = new ObjectPermissionRow(table, new HashSet<string> { "REFERENCES" }); row.GrantReferences = true;
        Check(row.PermissionChanges.Single() == ("REFERENCES", "GRANT"), "REFERENCES no se incluye en los cambios por objeto");
        RunPermissionScopeRequestChecks(row);

        var previewStore = new PolicyMemoryStore();
        previewStore.Permissions.Add(new("REFERENCES", "COLUMN", true, false, true, false, "admin", DateTime.UnixEpoch));
        var previewVm = new PolicyViewModel(previewStore, session, _ => true) { Search = "REFERENCES" };
        var view = new PolicyView { DataContext = previewVm, Background = Brushes.White, Width = 960, Height = 680 };
        void Layout() { view.Measure(new Size(960,680)); view.Arrange(new Rect(0,0,960,680)); view.UpdateLayout(); view.Dispatcher.Invoke(() => { }, System.Windows.Threading.DispatcherPriority.ContextIdle); view.UpdateLayout(); }
        Layout();
        var grid = (DataGrid)view.FindName("PermissionsGrid");
        var enable = Descendants(grid).OfType<Button>().Single(x => x.Content?.ToString() == "Habilitar…");
        Check(enable.IsEnabled, "La pestaña de permisos no ofrece el mismo botón que roles");
        enable.Command.Execute(null); Layout();
        var panel = (Grid)view.FindName("ActivationPanel");
        Check(VisibleInTree(panel,view) && previewVm.Activation!.ScopeDisplay == "Columnas", "Permisos no utiliza el formulario compartido con su alcance");
        var reason = (TextBox)view.FindName("ActivationReason"); reason.SetCurrentValue(TextBox.TextProperty,"Autorizar referencias de columna para esta prueba."); reason.GetBindingExpression(TextBox.TextProperty)!.UpdateSource();
        var acknowledgement = (CheckBox)view.FindName("ActivationRiskCheck"); acknowledgement.SetCurrentValue(ToggleButton.IsCheckedProperty,true); acknowledgement.GetBindingExpression(ToggleButton.IsCheckedProperty)!.UpdateSource();
        var nameBox = (TextBox)view.FindName("ActivationTypedName"); nameBox.SetCurrentValue(TextBox.TextProperty,"REFERENCES"); nameBox.GetBindingExpression(TextBox.TextProperty)!.UpdateSource(); Layout();
        Check(((Button)view.FindName("ConfirmSpecialActivationButton")).IsEnabled, "La confirmación WPF de permisos no se puede completar");
        if(args.Length==2 && args[0]=="--policy-preview")
        {
            Directory.CreateDirectory(args[1]);
            RenderPreview(view,Path.Combine(args[1],"politica-activacion-permisos.png"),960,680);
        }
        previewVm.CancelActivationCommand.Execute(null);
        Check(!previewVm.HasActivation && previewStore.Writes.Count==0, "Cancelar el formulario de permisos guarda cambios");
    }

    private static void RunPermissionScopeRequestChecks(ObjectPermissionRow objectRow)
    {
        // Ejercitar el VM real sin inicialización, red ni escrituras en SQL Server.
        var vm=(AccessViewModel)RuntimeHelpers.GetUninitializedObject(typeof(AccessViewModel));
        void Field(string name,object value)=>typeof(AccessViewModel).GetField(name,BindingFlags.Instance|BindingFlags.NonPublic)!.SetValue(vm,value);
        object? Invoke(string name)=>typeof(AccessViewModel).GetMethod(name,BindingFlags.Instance|BindingFlags.NonPublic)!.Invoke(vm,[]);
        var database=new DatabaseItem{ServerId=1,Server="CAEL",Name="Ventas",IsSelected=true};
        Field("_operation",new PolicyOperation("PERMISSION_CHANGE","Permisos",true,true,"HIGH",""));
        Field("_selectedWorkingServer",new ServerItem{Id=1,Name="CAEL"});
        Field("_selectedMappingDatabase",database); Field("_objectPermissionsLoaded",true);
        Field("_targetPrincipal","usuario");Field("_justification","Prueba de permisos sobre esquema y columna");Field("_externalTicketDigits","10604");
        Field("_verifiedExternalTicket",new ExternalTicketDetails("soporte","cliente","10604","Permisos","Prueba de permisos sobre esquema y columna","Abierto"));
        Field("_scope","SCHEMA");Field("_permissionAction","GRANT");Field("_securable","ventas");
        Field("<DatabaseRoleChoices>k__BackingField",new ObservableCollection<DatabaseRoleSelectionItem>());
        Field("<ObjectPermissionRows>k__BackingField",new ObservableCollection<ObjectPermissionRow>{objectRow});
        Field("<Databases>k__BackingField",new ObservableCollection<DatabaseItem>{database});
        Field("<SelectedDatabaseObjects>k__BackingField",new ObservableCollection<DatabaseObjectItem>());
        Field("<DatabaseObjects>k__BackingField",new ObservableCollection<DatabaseObjectItem>());
        var permissions=new ObservableCollection<PolicyPermission>();
        permissions.Add(new("DELETE","SCHEMA",true,false,true,true,"admin",DateTime.UnixEpoch){SpecialActivationApproved=true});
        permissions.Add(new("REFERENCES","COLUMN",true,false,true,true,"admin",DateTime.UnixEpoch){SpecialActivationApproved=true});
        Field("<Permissions>k__BackingField",permissions);
        Field("<AvailablePermissions>k__BackingField",new ObservableCollection<PolicyPermission>());
        Field("<PermissionChoices>k__BackingField",new ObservableCollection<PermissionSelectionItem>());
        Invoke("RefreshAvailablePermissions");vm.PermissionChoices.Single().IsSelected=true;
        vm.Scope=null;vm.Scope="";vm.Scope=" ";
        Check(vm.Scope=="SCHEMA"&&vm.Securable=="ventas"&&vm.PermissionChoices.Single().IsSelected, "Una selección vacía de ámbito destruye el borrador al cargar el formulario");
        vm.PermissionAction=null;vm.PermissionAction="";
        Check(vm.PermissionAction=="GRANT"&&vm.PermissionChoices.Single().IsSelected, "Una selección vacía de acción pierde los permisos elegidos");
        Check(ReferenceEquals(vm.Scopes,vm.Scopes), "El selector recrea su catálogo de ámbitos al leerlo");
        var scopeSelector=new ComboBox{DataContext=vm};
        scopeSelector.SetBinding(ItemsControl.ItemsSourceProperty,new System.Windows.Data.Binding(nameof(AccessViewModel.Scopes)));
        scopeSelector.SetBinding(System.Windows.Controls.Primitives.Selector.SelectedItemProperty,
            new System.Windows.Data.Binding(nameof(AccessViewModel.Scope)){Mode=System.Windows.Data.BindingMode.TwoWay});
        Check(scopeSelector.SelectedItem?.ToString()=="SCHEMA", "El selector WPF no recibe el ámbito actual");
        scopeSelector.SelectedItem=null;
        Check(vm.Scope=="SCHEMA"&&vm.Securable=="ventas"&&vm.PermissionChoices.Single().IsSelected, "SelectedItem=null de WPF corrompe la solicitud de permisos");
        scopeSelector.SelectedItem="COLUMN";
        Check(vm.Scope=="COLUMN"&&vm.RequiresSecurable, "La protección contra null impide seleccionar un ámbito válido");
        scopeSelector.SelectedItem="SCHEMA";vm.Securable="ventas";vm.PermissionChoices.Single().IsSelected=true;
        var drafts=(IReadOnlyList<AccessRequestDraft>)Invoke("Drafts")!;
        Check(drafts.Count==2 && drafts.Any(x=>x.Scope=="SCHEMA"&&x.Securable=="ventas"&&x.Permission=="DELETE")
            &&drafts.Any(x=>x.Scope=="OBJECT"&&x.Permission=="REFERENCES"), "Los permisos adicionales se pierden al combinarse con la matriz");
        Check(((IReadOnlyList<DatabaseItem>)Invoke("ValidateRequest")!).Count==1, "Se rechaza una solicitud válida de esquema");
        vm.Scope="COLUMN";vm.Securable="ventas.Factura.Total";vm.PermissionChoices.Single().IsSelected=true;
        drafts=(IReadOnlyList<AccessRequestDraft>)Invoke("Drafts")!;
        Check(drafts.Any(x=>x.Scope=="COLUMN"&&x.Securable=="ventas.Factura.Total"&&x.Permission=="REFERENCES"), "REFERENCES de columna no llega a la solicitud");
        Invoke("ValidateRequest");
        vm.Securable="ventas..Total";
        try { Invoke("ValidateRequest"); throw new Exception("Se envía una columna sin objeto"); }
        catch(TargetInvocationException ex) when(ex.InnerException is InvalidOperationException){_checks++;}
        vm.Securable="ventas.Factura.Total";
        vm.Databases.Add(new(){ServerId=1,Server="CAEL",Name="Otra",IsSelected=true});
        try { Invoke("ValidateRequest"); throw new Exception("Se envían permisos de columna a varias bases"); }
        catch(TargetInvocationException ex) when(ex.InnerException is InvalidOperationException){_checks++;}
        vm.Databases.Last().IsSelected=false;
        foreach(var (name,scope,target) in new[]{("CONTROL","OBJECT","ventas.Factura"),("CONTROL","TYPE","ventas.TipoFactura"),("ALTER ANY USER","DATABASE","")})
        {
            permissions.Add(new(name,scope,true,true,true,true,"admin",DateTime.UnixEpoch){SpecialActivationApproved=true});
            vm.Scope=scope;vm.PermissionAction="DENY";vm.Securable=target;
            vm.PermissionChoices.Single(x=>x.Name==name).IsSelected=true;
            drafts=(IReadOnlyList<AccessRequestDraft>)Invoke("Drafts")!;
            Check(drafts.Any(x=>x.Permission==name&&x.Scope==scope&&x.PermissionAction=="DENY"&&x.Securable==(target.Length==0?null:target)),
                "Un permiso avanzado habilitado no llega al borrador");
            Invoke("ValidateRequest");
        }
        Field("_operation",new PolicyOperation("SERVER_PERMISSION_CHANGE","Permisos de instancia",true,true,"HIGH",""));
        Field("_scope","SERVER");Field("_permissionAction","DENY");Field("_securable","");
        Field("_permission",new PolicyPermission("CONTROL SERVER","SERVER",true,true,true,true,"admin",DateTime.UnixEpoch){SpecialActivationApproved=true});
        var serverTargets=(IReadOnlyList<DatabaseItem>)Invoke("ValidateRequest")!;
        drafts=(IReadOnlyList<AccessRequestDraft>)Invoke("Drafts")!;
        Check(serverTargets.Single().Name=="master"&&drafts.Single().Permission=="CONTROL SERVER"&&drafts.Single().Scope=="SERVER","Una solicitud de instancia se envía como permiso de base");
        Check(vm.Scopes.All(x=>SqlPermissionSafety.Scope(x)!.IsServer),"El editor de instancia ofrece ámbitos de base");
        Check(ReferenceEquals(vm.Scopes,vm.Scopes),"El catálogo de ámbitos de instancia se recrea al leerlo");
        scopeSelector.ItemsSource=vm.Scopes;
        Check(vm.Scope=="SERVER", "Cambiar el catálogo de ámbitos de base a instancia borra el ámbito elegido");
        scopeSelector.SelectedItem="LOGIN";
        Check(vm.Scope=="LOGIN"&&vm.RequiresSecurable, "El selector WPF de instancia no admite un ámbito específico");
        vm.Scope=null;
        Check(vm.Scope=="LOGIN", "El editor de instancia permite un ámbito null");
        scopeSelector.SelectedItem="SERVER";
        Field("_operation",new PolicyOperation("ADD_SERVER_ROLE_MEMBER","Rol de instancia",true,true,"HIGH",""));
        Field("_role",new PolicyRole("sysadmin","FIXED",true,"admin",DateTime.UnixEpoch,""){RoleScope="SERVER",SpecialActivationApproved=true});
        drafts=(IReadOnlyList<AccessRequestDraft>)Invoke("Drafts")!;
        Check(drafts.Single().Role=="sysadmin"&&drafts.Single().Permission is null&&drafts.Single().Scope is null,"La membresía de servidor incluye permisos ocultos");
    }
}
