using System.Data;

namespace SqlAccessAdmin.Models;

public enum SecurityReportKind { AccessChanges, PasswordChanges, PasswordHistory }

public sealed record SecurityMonitoringSummary(long ExpiredAccesses,long PasswordAlerts,long UnresolvedEvents,
    DateTime? LastCollected,DateTime EvaluatedAt);
public sealed record SecurityAlertItem(long Id,string Type,string Principal,string Server,string Detail,DateTime OccurredAt)
{
    public string Title=>$"{(Type=="TEMPORARY_EXPIRED"?"Vencimiento":"Cambios de contraseña")} · {Principal} · {Server}";
    public string TypeDisplay=>Type=="TEMPORARY_EXPIRED"?"Acceso vencido":"Cambios de contraseña";
    public string OccurredDisplay=>SecurityMonitoringRules.Display(OccurredAt);
}

public interface ISecurityAlertsStore
{
    Task<IReadOnlyList<SecurityAlertItem>> GetActiveSecurityAlertsAsync(CancellationToken ct=default);
    Task ResolvePasswordAlertAsync(long alertId,string reason,CancellationToken ct=default);
}

public sealed record TemporaryAccessItem(long Id,int ServerId,string Server,string Principal,byte[] Sid,
    string Kind,string Database,string Scope,string Securable,string Permission,string Role,
    DateTime ExpiresAt,string State,int Revision,byte[] RowVersion,long RequestId)
{
    public long? ExecutionActionId {get;init;}
    public string Resource=>Kind switch
    {
        "LOGIN"=>"Login de instancia",
        "DATABASE_USER"=>$"Usuario en {Database}",
        "ROLE_MEMBERSHIP"=>$"Rol {Role} · {(Database.Length==0?"Instancia":Database)}",
        _=>$"{Permission} · {Database} · {(Securable.Length==0?Scope:Securable)}"
    };
    public string StateDisplay=>State switch{"EXPIRED_REVIEW"=>"Vencido / Pendiente de revisión","CLOSED"=>"Cerrado",_=>"Vigente"};
    public string ExpiresDisplay=>SecurityMonitoringRules.Display(ExpiresAt);
    public string CloseDescription=>Kind switch
    {
        "LOGIN"=>"Deshabilitar login (conserva permisos y sesiones existentes)",
        "DATABASE_USER"=>"Retirar usuario de esta base (puede fallar si posee objetos)",
        "ROLE_MEMBERSHIP"=>$"Retirar membresía del rol {Role}",
        _=>$"REVOKE {Permission} (puede conservar acceso por otras vías)"
    };
}

public sealed record TemporaryAccessAction(long Id,long TemporaryAccessId,string Action,string Status,
    string Ticket,string Reason,string RequestedBy,DateTime RequestedAt,DateTime? NewExpiresAt,string Result)
{
    public string Principal {get;init;}="";
    public string Server {get;init;}="";
    public string Resource {get;init;}="";
    public string TargetDisplay=>Principal.Length>0?$"{Principal} · {Server} · {Resource}":$"Acceso #{TemporaryAccessId}";
    public string ActionDisplay=>Action=="EXTEND"?"Extender vigencia":"Cerrar acceso";
    public string StatusDisplay=>Status switch
    {
        "PENDING"=>"Pendiente","APPROVED"=>"Aprobada","REJECTED"=>"Rechazada",
        "EXECUTING"=>"En ejecución","EXECUTED"=>"Ejecutada","FAILED"=>"Fallida",_=>Status
    };
    public string NewExpiresDisplay=>NewExpiresAt.HasValue?SecurityMonitoringRules.Display(NewExpiresAt.Value):"—";
}

public static class SecurityMonitoringRules
{
    public const string TimeZoneId="Central America Standard Time";
    public static TimeZoneInfo BusinessZone=>TimeZoneInfo.FindSystemTimeZoneById(TimeZoneId);
    public static DateTime ParseDateTime(DateTime? date,string time)
    {
        if(date is null||!TimeSpan.TryParseExact(time.Trim(),["hh\\:mm","hh\\:mm\\:ss"],
            System.Globalization.CultureInfo.InvariantCulture,out var parsed)||parsed<TimeSpan.Zero||parsed>=TimeSpan.FromDays(1))
            throw new InvalidOperationException("Indique fecha y hora válidas (HH:mm:ss), zona Guatemala.");
        var local=DateTime.SpecifyKind(date.Value.Date+parsed,DateTimeKind.Unspecified);
        if(BusinessZone.IsInvalidTime(local)||BusinessZone.IsAmbiguousTime(local))
            throw new InvalidOperationException("La fecha y hora seleccionadas son ambiguas o inexistentes.");
        return local;
    }
    public static string Display(DateTime value)=>SqlAccessAdmin.Infrastructure.AppTime.Display(value);
    public static string State(bool open,DateTime expiresAt,DateTime now)=>!open?"CLOSED":expiresAt<=now?"EXPIRED_REVIEW":"ACTIVE";
    public static bool PasswordAlertRequired(long count)=>count>=3;
    // El ejecutor ya validó que toda la solicitud pertenece a un ServerId.
    // El nombre amigable puede cambiar durante la ejecución y no es identidad.
    public static bool AppliedToTarget(OperationResult result,DatabaseItem target,string operation)
        =>result.Success&&(result.Database==target.Name
            ||(operation is "SERVER_PERMISSION_CHANGE" or "ADD_SERVER_ROLE_MEMBER")&&target.Name=="master"&&result.Database=="Instancia");
}

public interface ISecurityMonitoringStore
{
    Task<ExternalTicketDetails?> VerifyExternalTicketAsync(string ticket,CancellationToken ct=default);
    Task<SecurityMonitoringSummary> RefreshSecuritySummaryAsync(CancellationToken ct=default);
    Task<IReadOnlyList<TemporaryAccessItem>> GetTemporaryAccessesAsync(CancellationToken ct=default);
    Task<IReadOnlyList<TemporaryAccessAction>> GetTemporaryActionsAsync(CancellationToken ct=default);
    Task RequestTemporaryActionAsync(TemporaryAccessItem item,string action,DateTime? expiresAt,string ticket,string reason,CancellationToken ct=default);
    Task ReviewTemporaryActionAsync(long actionId,bool approve,CancellationToken ct=default);
    Task<TemporaryAccessItem> BeginTemporaryActionAsync(long actionId,CancellationToken ct=default);
    Task CompleteTemporaryActionAsync(long actionId,bool success,string detail,CancellationToken ct=default);
    Task<DataTable> GetSecurityReportAsync(SecurityReportKind kind,DateTime from,DateTime to,int? serverId,CancellationToken ct=default);
}
