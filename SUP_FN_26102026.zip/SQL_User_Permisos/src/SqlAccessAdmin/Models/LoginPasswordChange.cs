namespace SqlAccessAdmin.Models;

public static class LoginPasswordChange
{
    public static void Validate(string login,string? authenticationType,bool hasPassword,bool policy,bool expiration,bool mustChange)
    {
        if(authenticationType!="SQL"||string.IsNullOrWhiteSpace(login)||login.Length>128||login!=login.Trim()
            ||login.Any(char.IsControl)||login.Contains('\\')||SqlSystemNames.IsReserved(login))
            throw new InvalidOperationException("El cambio de contraseña requiere un login SQL válido.");
        if(!hasPassword)throw new InvalidOperationException("El cambio requiere una contraseña cifrada completa.");
        if(expiration&&!policy||mustChange&&(!policy||!expiration))
            throw new InvalidOperationException("El cambio obligatorio requiere política y expiración de contraseñas activas.");
    }
}
