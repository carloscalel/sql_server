namespace SqlAccessAdmin.Models;

public enum ReportExportFormat { Pdf, Csv, Excel }
public enum ReportExportScope { FullReport, ActiveSection }
public sealed record ReportExportColumn(string Header, double Width = 1);
public sealed record ReportExportSection(string Name, IReadOnlyList<ReportExportColumn> Columns, IReadOnlyList<object?[]> Rows);
public sealed record ReportExportDocument(string Title, string Server, string Database, string User,
    DateTimeOffset QueriedAt, string Filters, string ScopeNote, IReadOnlyList<ReportExportSection> Sections);
