using System.Text.Json;

namespace SqlAccessAdmin.Models;

public static class AppRoleCatalog
{
    public static IReadOnlyList<AppRole> Assignable {get;}=[AppRole.Administrator,AppRole.Operator,AppRole.ApproverExecutor,AppRole.Auditor];
    private const AppRole All=AppRole.Administrator|AppRole.Operator|AppRole.ApproverExecutor|AppRole.Auditor;
    public static bool IsValid(AppRole roles)=>roles!=AppRole.None&&(roles&~All)==0;
    public static string Name(AppRole role)=>role switch
    {
        AppRole.Administrator=>"Administrador",AppRole.Operator=>"Operador",
        AppRole.ApproverExecutor=>"AprobadorEjecutor",AppRole.Auditor=>"Auditor",_=>throw new ArgumentOutOfRangeException(nameof(role))
    };
    public static string Display(AppRole roles)=>roles==AppRole.None?"Sin roles":string.Join(" + ",Assignable.Where(x=>roles.HasFlag(x)).Select(Name));
    public static string ToJson(AppRole roles)
    {
        if(!IsValid(roles))throw new InvalidOperationException("Seleccione al menos un rol de aplicación válido.");
        return JsonSerializer.Serialize(Assignable.Where(x=>roles.HasFlag(x)).Select(x=>x.ToString()));
    }
    public static AppRole FromJson(string json,bool allowEmpty=false)
    {
        try
        {
            var names=JsonSerializer.Deserialize<string[]>(json);
            if(allowEmpty&&names is {Length:0})return AppRole.None;
            if(names is null||names.Length==0||names.Length>Assignable.Count)throw new FormatException();
            var roles=AppRole.None;
            foreach(var name in names)
            {
                var role=Assignable.SingleOrDefault(x=>string.Equals(x.ToString(),name,StringComparison.Ordinal));
                if(role==AppRole.None||roles.HasFlag(role))throw new FormatException();
                roles|=role;
            }
            return roles;
        }
        catch(Exception error)when(error is JsonException or FormatException or InvalidOperationException)
        {throw new UnauthorizedAccessException("La lista de roles autorizados en adminDB no es válida.",error);}
    }
}
