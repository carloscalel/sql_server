﻿namespace SqlAccessAdmin.Models;

public enum ReportKind { UserPermissions, RoleCatalog, CredentialAge }

public sealed record ReportUser(string Name, string Type);
public sealed class ReportDatabaseChoice(string name) : SqlAccessAdmin.Infrastructure.BindableBase
{
    private bool _selected;
    public string Name { get; } = name;
    public bool IsSelected { get => _selected; set => Set(ref _selected, value); }
}
public sealed record ReportRoleMembership(string Name, bool IsFixed, bool IsDirect)
{
    public string Level { get; init; } = "Base";
    public string Database { get; init; } = "";
    public string Principal { get; init; } = "";
    public string DatabaseDisplay => ReportCellText.Context(Database);
    public string Kind => Name == "public" ? "Implícito" : IsFixed ? "Fijo" : "Personalizado";
    public string Assignment => Name == "public" ? "Implícita" : IsDirect ? "Directa" : Level == "Instancia" ? "Heredada" : "Por otro rol";
    public string Description => Level == "Instancia" ? ServerRoleDescriptions.Describe(Name, IsFixed) : DatabaseRoleDescriptions.Describe(Name, IsFixed);
}
public sealed record ReportPermission(string Scope, string Schema, string Object, string ObjectType,
    string Column, string Permission, string Action)
{
    public string Level { get; init; } = "Base";
    public string Database { get; init; } = "";
    public string Principal { get; init; } = "";
    public bool CoveredBySysadmin { get; init; }
    public string OriginStatus => !CoveredBySysadmin ? "Asignación directa"
        : Action.StartsWith("GRANT", StringComparison.OrdinalIgnoreCase) ? "Redundante (Cubierto por Sysadmin)"
        : "Sin efecto (Sysadmin)";
    public string DatabaseDisplay => ReportCellText.Context(Database);
    public string SchemaDisplay => ReportCellText.Context(Schema);
    public string ObjectDisplay => Scope == "Instancia" && Object == "(instancia)" ? "—" : ReportCellText.Context(Object);
    public string ObjectTypeDisplay => ReportCellText.Context(ObjectType);
    public string ColumnDisplay => ReportCellText.Context(Column);
}
internal static class ReportCellText
{
    public static string Context(string value) => string.IsNullOrWhiteSpace(value) ? "—" : value;
}
public sealed record ReportDatabaseCoverage(string Database, string User, string Detail);
public sealed record UserAccessReport(IReadOnlyList<ReportRoleMembership> Roles, IReadOnlyList<ReportPermission> Permissions)
{
    public IReadOnlyList<ReportDatabaseCoverage> Databases { get; init; } = [];
}
public sealed record ReportRoleMember(string Name, string Type);
public sealed record ReportRole(string Name, bool IsFixed, IReadOnlyList<ReportRoleMember> Members) : System.ComponentModel.INotifyPropertyChanged
{
    private bool _exportMembers;
    public event System.ComponentModel.PropertyChangedEventHandler? PropertyChanged;
    public bool ExportMembers
    {
        get => _exportMembers;
        set
        {
            if (_exportMembers == value) return;
            _exportMembers = value;
            PropertyChanged?.Invoke(this, new(nameof(ExportMembers)));
        }
    }
    public string Kind => Name == "public" ? "Implícito" : IsFixed ? "Fijo" : "Personalizado";
    public string Description => DatabaseRoleDescriptions.Describe(Name, IsFixed);
    public int MemberCount => Members.Count;
    public string MemberSummary => string.Join(", ", Members.Select(x => x.Name));
}
public sealed record CredentialAgeRow(string Name, bool Disabled, DateTime? PasswordLastSet, int? Days,
    bool? PolicyChecked, bool? ExpirationChecked, string LoginType = "SQL_LOGIN",
    DateTime? LastModified = null, int? ModificationDays = null, string PasswordDateSource = "Servidor")
{
    public CredentialAgeRow WithConfirmedPasswordChange(DateTime changedAt,DateTime createdAt,DateTime now)
    {
        if(LoginType!="SQL_LOGIN" || changedAt<createdAt || changedAt>now || PasswordLastSet>=changedAt) return this;
        return this with { PasswordLastSet=changedAt, Days=(int)(now-changedAt).TotalDays, PasswordDateSource="Cambio confirmado en la aplicación" };
    }
    public string PasswordDateSourceDisplay => PasswordLastSet is null ? "No disponible" : PasswordDateSource;
    public string Status => Disabled ? "Deshabilitado" : "Habilitado";
    public string Classification => LoginType == "WINDOWS_LOGIN" ? "Gestionada por Windows/AD"
        : Days is null ? "Fecha no disponible" : Days > 45 ? "Más de 45 días" : "Hasta 45 días";
}

public static class DatabaseRoleDescriptions
{
    public static string Describe(string name, bool isFixed) => name.ToLowerInvariant() switch
    {
        "public" => "Acceso base compartido por todos los usuarios; la membresía es implícita. Sus permisos pueden modificarse.",
        "db_owner" when isFixed => "Control total de la base: configuración, mantenimiento y eliminación de la base.",
        "db_accessadmin" when isFixed => "Administra el acceso de usuarios a la base de datos.",
        "db_securityadmin" when isFixed => "Administra permisos y membresías de roles personalizados. Puede elevar privilegios.",
        "db_ddladmin" when isFixed => "Crea, modifica y elimina objetos de la base de datos. Puede elevar privilegios.",
        "db_backupoperator" when isFixed => "Puede realizar copias de seguridad de la base de datos.",
        "db_datareader" when isFixed => "Puede leer datos de todas las tablas y vistas de usuario.",
        "db_datawriter" when isFixed => "Puede insertar, modificar y eliminar datos de todas las tablas de usuario.",
        "db_denydatareader" when isFixed => "Deniega la lectura de datos de tablas y vistas de usuario.",
        "db_denydatawriter" when isFixed => "Deniega insertar, modificar y eliminar datos de tablas de usuario.",
        _ when isFixed => "Rol fijo del motor; sus capacidades dependen del tipo de base y de la versión de SQL Server.",
        _ => "Rol personalizado de esta base. Su acceso depende de sus permisos y membresías; el nombre no define sus privilegios."
    };
}

public static class ServerRoleDescriptions
{
    public static string Describe(string name, bool isFixed) => name.ToLowerInvariant() switch
    {
        "sysadmin" => "Control total de la instancia y de todas sus bases, aunque no tenga un usuario mapeado en ellas.",
        "securityadmin" => "Administra logins y permisos de instancia. Puede elevar privilegios.",
        "serveradmin" => "Administra la configuración de la instancia y puede apagar el servidor.",
        "setupadmin" => "Administra servidores vinculados y determinadas operaciones de configuración.",
        "processadmin" => "Puede terminar procesos de SQL Server.",
        "diskadmin" => "Administra archivos de disco de SQL Server.",
        "dbcreator" => "Puede crear, modificar, eliminar y restaurar bases de datos.",
        "bulkadmin" => "Puede ejecutar operaciones de importación masiva.",
        "public" => "Rol de instancia implícito para todos los logins; sus permisos pueden modificarse.",
        _ when isFixed => "Rol fijo de instancia; sus capacidades dependen de la versión de SQL Server.",
        _ => "Rol personalizado de instancia. Sus privilegios dependen de sus permisos y membresías."
    };
}
