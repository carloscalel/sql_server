using System.Data;
using Microsoft.Data.SqlClient;
using SqlAccessAdmin.Models;

namespace SqlAccessAdmin.Data;

public sealed partial class DirectSqlServerService
{
    private async Task ValidateTemporaryPreconditionsAsync(AccessRequestItem request,IReadOnlyList<DatabaseItem> targets,IReadOnlyList<AccessRequestStepItem> steps,CancellationToken ct)
    {
        if(LoginAuthentication.CreatesLogin(request.Operation))return; // creación exige nombre nuevo
        foreach(var target in targets)
        {
            var instance=request.Operation is "SERVER_PERMISSION_CHANGE" or "ADD_SERVER_ROLE_MEMBER";
            var resolved=await ResolveAsync(target.ServerId,instance?"master":target.Name,ct);
            await using var cn=new SqlConnection(resolved.ConnectionString);await cn.OpenAsync(ct);
            var plan=DatabaseChangePlan(request,steps);
            foreach(var step in plan)
            {
                if(step.Operation=="CREATE_DB_USER")
                {
                    await using var exists=new SqlCommand("SELECT COUNT(*) FROM sys.database_principals WHERE name=@principal",cn);
                    exists.Parameters.Add(new("@principal",SqlDbType.NVarChar,256){Value=request.TargetPrincipal});
                    if(Convert.ToInt32(await exists.ExecuteScalarAsync(ct))>0)throw new InvalidOperationException("El usuario de base ya existe: no puede convertirlo implícitamente en temporal.");
                }
                if(step.Operation is "PERMISSION_CHANGE" or "SERVER_PERMISSION_CHANGE"&&step.PermissionAction=="GRANT")
                    await RequireNewTemporaryPermissionAsync(cn,request.TargetPrincipal,step.Permission,step.Scope,step.Securable,ct);
                if(step.Operation is "ADD_ROLE_MEMBER" or "MODIFY_LOGIN" or "ADD_SERVER_ROLE_MEMBER")
                {
                    await using var membership=new SqlCommand(instance
                        ?"SELECT COUNT(*) FROM sys.server_role_members m JOIN sys.server_principals p ON p.principal_id=m.member_principal_id JOIN sys.server_principals r ON r.principal_id=m.role_principal_id WHERE p.name=@principal AND r.name=@role"
                        :"SELECT COUNT(*) FROM sys.database_role_members m JOIN sys.database_principals p ON p.principal_id=m.member_principal_id JOIN sys.database_principals r ON r.principal_id=m.role_principal_id WHERE p.name=@principal AND r.name=@role",cn);
                    membership.Parameters.Add(new("@principal",SqlDbType.NVarChar,256){Value=request.TargetPrincipal});membership.Parameters.Add(new("@role",SqlDbType.NVarChar,128){Value=step.Role});
                    if(Convert.ToInt32(await membership.ExecuteScalarAsync(ct))>0)throw new InvalidOperationException("La membresía ya existe; no se convertirá en temporal.");
                }
            }
        }
    }
    private static async Task RequireNewTemporaryPermissionAsync(SqlConnection cn,string principal,string permission,string scope,string securable,CancellationToken ct,bool denyOnly=false)
    {
        if(scope is not ("DATABASE" or "SCHEMA" or "OBJECT" or "COLUMN" or "SERVER"))
            throw new InvalidOperationException("La vigencia temporal de permisos admite base, esquema, objeto, columna o servidor completo.");
        var parts=scope=="SERVER"?Array.Empty<string>():ValidatePermissionTarget(scope,securable);
        var objectName=parts.Length>=2?$"{new SqlCommandBuilder().QuoteIdentifier(parts[0])}.{new SqlCommandBuilder().QuoteIdentifier(parts[1])}":"";
        await using var command=new SqlCommand(scope=="SERVER"
            ?"SELECT COUNT(*) FROM sys.server_permissions WHERE grantee_principal_id=SUSER_ID(@principal) AND class=100 AND permission_name=@permission AND (@denyOnly=0 OR state='D')"
            :"""
                SELECT COUNT(*) FROM sys.database_permissions
                WHERE grantee_principal_id=DATABASE_PRINCIPAL_ID(@principal) AND permission_name=@permission AND (@denyOnly=0 OR state='D')
                AND ((@scope='DATABASE' AND class=0)
                  OR (@scope='SCHEMA' AND class=3 AND major_id=SCHEMA_ID(@schema))
                  OR (@scope='OBJECT' AND class=1 AND major_id=OBJECT_ID(@object) AND minor_id=0)
                  OR (@scope='COLUMN' AND class=1 AND major_id=OBJECT_ID(@object) AND minor_id=COLUMNPROPERTY(OBJECT_ID(@object),@column,'ColumnId')))
                """,cn);
        command.Parameters.Add(new("@principal",SqlDbType.NVarChar,256){Value=principal});command.Parameters.Add(new("@permission",SqlDbType.NVarChar,128){Value=permission});
        command.Parameters.Add(new("@scope",SqlDbType.VarChar,30){Value=scope});command.Parameters.Add(new("@schema",SqlDbType.NVarChar,128){Value=parts.FirstOrDefault()??""});
        command.Parameters.Add(new("@object",SqlDbType.NVarChar,776){Value=objectName});command.Parameters.Add(new("@column",SqlDbType.NVarChar,128){Value=parts.Length==3?parts[2]:""});
        command.Parameters.Add(new("@denyOnly",SqlDbType.Bit){Value=denyOnly});
        if(Convert.ToInt32(await command.ExecuteScalarAsync(ct))>0)
            throw new InvalidOperationException(denyOnly?"Hay una denegación externa sobre este recurso. Revísela antes de retirar accesos.":"Ya hay un permiso explícito sobre este recurso. Revíselo antes de asignarle una vigencia temporal; no se convertirá un acceso previo.");
    }
}
