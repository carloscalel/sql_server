using System.Data;
using Microsoft.Data.SqlClient;
using SqlAccessAdmin.Models;

namespace SqlAccessAdmin.Data;

internal sealed class ExecutionEvidenceScope : IDisposable
{
    internal sealed class Context(AdminDbGateway gateway,int serverId,long? requestId,long? actionId,string principal,string actor,bool closeLogin)
    {
        internal AdminDbGateway Gateway {get;}=gateway;
        internal int ServerId {get;}=serverId;
        internal long? RequestId {get;}=requestId;
        internal long? ActionId {get;}=actionId;
        internal string Principal {get;}=principal;
        internal string Actor {get;}=actor;
        internal bool CloseLogin {get;}=closeLogin;
        internal Guid? ExecutionId;
        internal int Ordinal;
        internal HashSet<string> CreatedLogins {get;}=new(StringComparer.OrdinalIgnoreCase);
        internal Dictionary<SqlConnection,List<TrackedChange>> Changes {get;}=[];
        internal List<string> Warnings {get;}=[];
    }
    internal sealed class TrackedChange(Guid id,string operation,bool login,PrincipalMetadata? before)
    {
        internal Guid Id {get;}=id;
        internal string Operation {get;}=operation;
        internal bool Login {get;}=login;
        internal PrincipalMetadata? Snapshot=before;
        internal bool Existed=before is not null;
        internal bool Executed,Completed,FinalMetadata,DefinitionChanged;
        internal DateTime CompletedAt;
        internal string State="CONFIRMED";
    }
    private static readonly AsyncLocal<Context?> CurrentContext=new();
    private readonly Context? _previous;
    internal static Context? Current=>CurrentContext.Value;
    private ExecutionEvidenceScope(Context context){_previous=CurrentContext.Value;CurrentContext.Value=context;}
    internal static ExecutionEvidenceScope Begin(AccessRequestItem request,string actor,AdminDbGateway gateway,int serverId)
        =>new(new(gateway,serverId,request.Id,null,request.TargetPrincipal,actor,false));
    internal static ExecutionEvidenceScope BeginClose(TemporaryAccessItem item,string actor,AdminDbGateway gateway)
        =>new(new(gateway,item.ServerId,null,item.ExecutionActionId,item.Principal,actor,item.Kind=="LOGIN"||item.Database.Length==0));
    public void Dispose()=>CurrentContext.Value=_previous;
}

// Seguimiento central de comandos tipados. No usa triggers, Audit, contexto de sesión ni texto SQL.
internal sealed class TrackedSqlConnection : IAsyncDisposable
{
    internal SqlConnection Connection {get;}
    private TrackedSqlConnection(SqlConnection connection)=>Connection=connection;
    internal static async Task<TrackedSqlConnection> OpenAsync(string connectionString,CancellationToken ct)
    {
        var result=new TrackedSqlConnection(new SqlConnection(new SqlConnectionStringBuilder(connectionString){MultipleActiveResultSets=false}.ConnectionString));
        try{await result.Connection.OpenAsync(ct);return result;}catch{await result.Connection.DisposeAsync();throw;}
    }
    internal static bool IsLoginOperation(string operation)=>operation is "CREATE_SQL_LOGIN" or "CREATE_WINDOWS_LOGIN" or "CLONE_SQL_LOGIN" or "ENABLE_LOGIN" or "DISABLE_LOGIN" or "CHANGE_LOGIN_PASSWORD" or "SERVER_PERMISSION_CHANGE" or "ADD_SERVER_ROLE_MEMBER" or "REMOVE_SERVER_ROLE_MEMBER";
    internal static async Task TagChangeAsync(SqlConnection cn,SqlTransaction? tx,string operation,string principal,
        string? action=null,string? permission=null,string? scope=null,string? securable=null,string? role=null,CancellationToken ct=default)
    {
        var context=ExecutionEvidenceScope.Current;if(context is null)return;
        if(!principal.Equals(context.Principal,StringComparison.OrdinalIgnoreCase))throw new InvalidOperationException("El principal del comando difiere de la solicitud.");
        var login=IsLoginOperation(operation)||operation=="CLOSE_TEMPORARY_ACCESS"&&context.CloseLogin;
        var before=await ReadPrincipalMetadataAsync(cn,tx,principal,login,ct);
        context.ExecutionId??=await context.Gateway.BeginAppExecutionAsync(context.RequestId,context.ActionId,context.ServerId,ct);
        var id=await context.Gateway.PrepareAppChangeAsync(context.ExecutionId.Value,++context.Ordinal,login?"":cn.Database,
            login?"LOGIN":"DATABASE_USER",operation,action,permission,scope,securable,role,before?.Sid,ct);
        if(!context.Changes.TryGetValue(cn,out var list)){list=[];context.Changes.Add(cn,list);}
        list.Add(new(id,operation,login,before));
    }
    internal static async Task<int> ExecuteCommandAsync(SqlCommand command,CancellationToken ct)
    {
        var count=await command.ExecuteNonQueryAsync(ct);
        var context=ExecutionEvidenceScope.Current;
        if(context is null||!context.Changes.TryGetValue(command.Connection!,out var list)||list.LastOrDefault() is not {Completed:false} change)return count;
        change.Executed=true;change.CompletedAt=SqlAccessAdmin.Infrastructure.AppTime.Now;
        try
        {
            var after=await ReadPrincipalMetadataAsync(command.Connection!,command.Transaction,context.Principal,change.Login,CancellationToken.None);
            if(after is not null)
            {
                change.DefinitionChanged=change.Snapshot is null||change.Snapshot.ModifiedLocal!=after.ModifiedLocal;
                change.Snapshot=after;change.FinalMetadata=true;change.CompletedAt=after.EngineTime;
            }
        }
        catch{context.Warnings.Add("Cambio confirmado sin lectura final de metadatos; pendiente de conciliación de fechas.");}
        if(change.Operation=="CREATE_DB_USER"&&change.Existed)change.State="NO_CHANGE";
        if(command.Transaction is null)await FinishAsync(context,change);
        return count;
    }
    internal static async Task CommitTrackedAsync(SqlConnection cn)
    {
        var context=ExecutionEvidenceScope.Current;if(context is null||!context.Changes.TryGetValue(cn,out var list))return;
        foreach(var change in list.Where(x=>x.Executed&&!x.Completed))await FinishAsync(context,change);
    }
    internal static async Task RollbackTrackedAsync(SqlConnection cn)
    {
        var context=ExecutionEvidenceScope.Current;if(context is null||!context.Changes.TryGetValue(cn,out var list))return;
        foreach(var change in list.Where(x=>!x.Completed)){change.State="ROLLED_BACK";await FinishAsync(context,change);}
    }
    internal static async Task SkipLastAsync(SqlConnection cn)
    {
        var context=ExecutionEvidenceScope.Current;if(context is null||!context.Changes.TryGetValue(cn,out var list)||list.LastOrDefault() is not {} change)return;
        change.State="NO_CHANGE";await FinishAsync(context,change);
    }
    private static async Task FinishAsync(ExecutionEvidenceScope.Context context,ExecutionEvidenceScope.TrackedChange change)
    {
        try
        {
            await context.Gateway.CompleteAppChangeAsync(change.Id,change.State,change.FinalMetadata?change.Snapshot:null,change.CompletedAt==default?SqlAccessAdmin.Infrastructure.AppTime.Now:change.CompletedAt,CancellationToken.None,change.DefinitionChanged);
            change.Completed=true;
        }
        catch{context.Warnings.Add("No se confirmó el registro central del comando. Revisar el intento reservado antes de una nueva gestión.");}
    }
    internal static async Task<PrincipalMetadata?> ReadPrincipalMetadataAsync(SqlConnection cn,SqlTransaction? tx,string principal,bool login,CancellationToken ct)
    {
        var sql=login?MetadataSql.LoginByName:MetadataSql.UserByName;
        await using var command=new SqlCommand(sql,cn,tx){CommandTimeout=15};command.Parameters.Add(new("@principal",SqlDbType.NVarChar,256){Value=principal});
        await using var reader=await command.ExecuteReaderAsync(ct);
        return await reader.ReadAsync(ct)?PrincipalMetadata.Read(reader,login?"":cn.Database,login?"LOGIN":"DATABASE_USER"):null;
    }
    public async ValueTask DisposeAsync()
    {
        var context=ExecutionEvidenceScope.Current;
        if(context is not null&&context.Changes.TryGetValue(Connection,out var list))
        {
            foreach(var change in list.Where(x=>!x.Completed&&!x.Executed))
            {change.State="UNRESOLVED";await FinishAsync(context,change);}
            context.Changes.Remove(Connection);
        }
        await Connection.DisposeAsync();
    }
}
