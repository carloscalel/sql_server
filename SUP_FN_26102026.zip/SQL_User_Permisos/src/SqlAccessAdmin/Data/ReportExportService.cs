using System.Globalization;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using ClosedXML.Excel;
using MigraDoc.DocumentObjectModel;
using MigraDoc.Rendering;
using SqlAccessAdmin.Models;

namespace SqlAccessAdmin.Data;

public interface IReportExportService
{
    Task ExportAsync(ReportExportDocument report, string path, ReportExportFormat format, CancellationToken ct);
}

public sealed class ReportExportService : IReportExportService
{
    public Task ExportAsync(ReportExportDocument report, string path, ReportExportFormat format, CancellationToken ct) => Task.Run(() =>
    {
        var extension = format switch { ReportExportFormat.Pdf => ".pdf", ReportExportFormat.Csv => ".csv", ReportExportFormat.Excel => ".xlsx", _ => throw new ArgumentOutOfRangeException(nameof(format)) };
        if (!Path.GetExtension(path).Equals(extension, StringComparison.OrdinalIgnoreCase))
            throw new InvalidOperationException($"El archivo debe tener extensión {extension}.");
        var destination = Path.GetFullPath(path);
        var temporary = Path.Combine(Path.GetDirectoryName(destination)!, $".sql-access-report-{Guid.NewGuid():N}.tmp");
        try
        {
            ct.ThrowIfCancellationRequested();
            using (var stream = new FileStream(temporary, FileMode.CreateNew, FileAccess.ReadWrite, FileShare.None))
            {
                switch (format)
                {
                    case ReportExportFormat.Pdf: WritePdf(report, stream, ct); break;
                    case ReportExportFormat.Excel: WriteExcel(report, stream, ct); break;
                    case ReportExportFormat.Csv: WriteCsv(report, stream, ct); break;
                }
            }
            ct.ThrowIfCancellationRequested();
            // Keep an existing report intact if generation fails or the operation is cancelled.
            File.Move(temporary, destination, true);
        }
        finally { if (File.Exists(temporary)) File.Delete(temporary); }
    }, ct);

    private static string Display(object? value) => value switch
    {
        null => "No disponible", DateTime date => date.ToString("yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture),
        bool flag => flag ? "Sí" : "No", _ => Convert.ToString(value, CultureInfo.InvariantCulture) ?? ""
    };
    private static string Context(ReportExportDocument report) =>
        $"Servidor: {report.Server} | Base: {report.Database} | Usuario: {report.User}";

    private static void WriteCsv(ReportExportDocument report, Stream stream, CancellationToken ct)
    {
        // One rectangular RFC 4180 table, even when a report has several distinct sections.
        var headers = report.Sections.SelectMany(s => s.Columns.Select(c => c.Header)).Distinct().ToList();
        var fixedHeaders = new[] { "Reporte", "Servidor", "Base de datos", "Usuario", "Fecha de consulta", "Filtros", "Alcance", "Sección", "Estado de sección" };
        using var writer = new StreamWriter(stream, new UTF8Encoding(true), 4096, leaveOpen: true) { NewLine = "\r\n" };
        void Write(IEnumerable<string> cells) => writer.WriteLine(string.Join(",", cells.Select(EscapeCsv)));
        Write(fixedHeaders.Concat(headers));
        foreach (var section in report.Sections)
        {
            var indexes = section.Columns.Select((c, i) => (c.Header, i)).ToDictionary(x => x.Header, x => x.i);
            var prefix = new[] { report.Title, report.Server, report.Database, report.User, TimeZoneInfo.ConvertTime(report.QueriedAt,SqlAccessAdmin.Infrastructure.AppTime.Zone).ToString("yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture), report.Filters, report.ScopeNote, section.Name };
            if (section.Rows.Count == 0) Write(prefix.Concat(["Sin filas con los filtros actuales"]).Concat(headers.Select(_ => "")));
            foreach (var row in section.Rows)
            {
                ct.ThrowIfCancellationRequested();
                Write(prefix.Concat(["Dato"]).Concat(headers.Select(h => indexes.TryGetValue(h, out var i) ? Display(row[i]) : "")));
            }
        }
    }

    private static string EscapeCsv(string text)
    {
        // Quoting alone does not stop Excel from interpreting SQL identifiers as formulas.
        var start = text.AsSpan().TrimStart();
        if (start.Length > 0 && (start[0] is '=' or '+' or '-' or '@' or '\t' or '\r' or '\n')
            || text.StartsWith('\t') || text.StartsWith('\r') || text.StartsWith('\n')) text = "'" + text;
        return "\"" + text.Replace("\"", "\"\"") + "\"";
    }

    private static void WriteExcel(ReportExportDocument report, Stream stream, CancellationToken ct)
    {
        using var workbook = new XLWorkbook();
        workbook.Properties.Title = report.Title;
        workbook.Properties.Author = "SQL Access Admin";
        foreach (var section in report.Sections)
        {
            ct.ThrowIfCancellationRequested();
            var sheet = workbook.Worksheets.Add(section.Name);
            var count = section.Columns.Count;
            if (section.Rows.Count > 1_048_567) throw new InvalidOperationException("El resultado supera el límite de filas de Excel. Reduzca los resultados con los filtros.");
            var area = sheet.Range(1, 1, 7, count);
            area.Style.Font.FontName = "Calibri";
            void Banner(int row, string value)
            {
                sheet.Range(row, 1, row, count).Merge();
                sheet.Cell(row, 1).Value = value;
                sheet.Cell(row, 1).Style.Alignment.WrapText = true;
            }
            Banner(1, "SQL Access Admin · " + report.Title);
            sheet.Row(1).Height = 30; sheet.Range(1, 1, 1, count).Style.Fill.BackgroundColor = XLColor.FromHtml("#111B2E");
            sheet.Range(1, 1, 1, count).Style.Font.FontColor = XLColor.White; sheet.Range(1, 1, 1, count).Style.Font.Bold = true;
            Banner(2, Context(report)); sheet.Row(2).Height = 32;
            Banner(3, "Consulta: " + TimeZoneInfo.ConvertTime(report.QueriedAt,SqlAccessAdmin.Infrastructure.AppTime.Zone).ToString("yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture) + " · " + report.Filters); sheet.Row(3).Height = 32;
            if (!string.IsNullOrWhiteSpace(report.ScopeNote)) { Banner(4, report.ScopeNote); sheet.Row(4).Height = 48; }
            else sheet.Row(4).Height = 0;
            Banner(5, section.Name + $" · {section.Rows.Count} fila(s)"); sheet.Row(5).Height = 25;
            for (var column = 0; column < count; column++)
            {
                sheet.Cell(7, column + 1).Value = section.Columns[column].Header;
                sheet.Column(column + 1).Width = Math.Clamp(section.Columns[column].Width * 18, 16, 65);
            }
            sheet.Range(7, 1, 7, count).Style.Fill.BackgroundColor = XLColor.FromHtml("#244D89");
            sheet.Range(7, 1, 7, count).Style.Font.FontColor = XLColor.White;
            sheet.Range(7, 1, 7, count).Style.Font.Bold = true;
            sheet.Range(7, 1, 7, count).Style.Alignment.WrapText = true;
            sheet.Row(7).Height = 32;
            for (var i = 0; i < section.Rows.Count; i++)
            {
                ct.ThrowIfCancellationRequested();
                var lines = 1;
                for (var j = 0; j < count; j++)
                {
                    var cell = sheet.Cell(i + 8, j + 1);
                    // Assign strings as values, never FormulaA1, to preserve identifiers verbatim.
                    switch (section.Rows[i][j])
                    {
                        case DateTime date: cell.Value = date; cell.Style.DateFormat.Format = "yyyy-mm-dd hh:mm:ss"; break;
                        case int number: cell.Value = number; break;
                        default: cell.Value = Display(section.Rows[i][j]); break;
                    }
                    cell.Style.Alignment.WrapText = true;
                    cell.Style.Alignment.Vertical = XLAlignmentVerticalValues.Top;
                    if (i % 2 == 1) cell.Style.Fill.BackgroundColor = XLColor.FromHtml("#F0F4FA");
                    var charactersPerLine = Math.Max(8, (int)(sheet.Column(j + 1).Width * 0.8));
                    lines = Math.Max(lines, Display(section.Rows[i][j]).Split('\n').Sum(line => Math.Max(1, (int)Math.Ceiling(line.Length / (double)charactersPerLine))));
                }
                // ClosedXML AdjustToContents does not size wrapped text like Excel's UI does.
                sheet.Row(i + 8).Height = Math.Clamp(8 + lines * 15, 23, 409);
            }
            if (section.Rows.Count > 0)
            {
                sheet.Range(7, 1, section.Rows.Count + 7, count).SetAutoFilter();
            }
            else Banner(8, "Sin filas con los filtros actuales.");
            sheet.SheetView.FreezeRows(7);
            sheet.PageSetup.PageOrientation = XLPageOrientation.Landscape;
            sheet.PageSetup.FitToPages(1, 0);
            sheet.PageSetup.SetRowsToRepeatAtTop(7, 7);
        }
        ct.ThrowIfCancellationRequested(); workbook.SaveAs(stream);
    }

    private static string WrapLongTokens(string text, int limit = 80) => Regex.Replace(text, @"\S{" + (limit + 1) + @",}", m => string.Join("\n", m.Value.Chunk(limit).Select(x => new string(x))));
    private static void WritePdf(ReportExportDocument report, Stream stream, CancellationToken ct)
    {
        var document = new Document();
        document.Info.Title = report.Title; document.Info.Author = "SQL Access Admin";
        var normal = document.Styles[StyleNames.Normal]!;
        normal.Font.Name = "Segoe UI"; normal.Font.Size = 9;
        normal.Font.Color = Color.FromRgb(18, 32, 51);
        var section = document.AddSection();
        section.PageSetup.PageFormat = PageFormat.A4; section.PageSetup.Orientation = Orientation.Landscape;
        section.PageSetup.LeftMargin = Unit.FromCentimeter(1.3); section.PageSetup.RightMargin = Unit.FromCentimeter(1.3);
        section.PageSetup.TopMargin = Unit.FromCentimeter(1.4); section.PageSetup.BottomMargin = Unit.FromCentimeter(1.4);
        section.PageSetup.HeaderDistance = Unit.FromCentimeter(0.45); section.PageSetup.FooterDistance = Unit.FromCentimeter(0.5);
        var header = section.Headers.Primary.AddParagraph("SQL Access Admin · Reportes"); header.Format.Font.Color = Color.FromRgb(36, 77, 137);
        var footer = section.Footers.Primary.AddParagraph(); footer.Format.Alignment = ParagraphAlignment.Right;
        footer.AddText("Página "); footer.AddPageField(); footer.AddText(" de "); footer.AddNumPagesField();
        var title = section.AddParagraph(report.Title); title.Format.Font.Size = 18; title.Format.Font.Bold = true;
        title.Format.SpaceAfter = Unit.FromPoint(6);
        section.AddParagraph(WrapLongTokens(Context(report)));
        section.AddParagraph("Consulta: " + TimeZoneInfo.ConvertTime(report.QueriedAt,SqlAccessAdmin.Infrastructure.AppTime.Zone).ToString("yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture));
        section.AddParagraph("Filtros: " + WrapLongTokens(report.Filters));
        if (!string.IsNullOrWhiteSpace(report.ScopeNote))
        {
            var note = section.AddParagraph(report.ScopeNote); note.Format.Font.Size = 8; note.Format.SpaceAfter = Unit.FromPoint(10);
        }
        foreach (var content in report.Sections)
        {
            ct.ThrowIfCancellationRequested();
            var heading = section.AddParagraph(content.Name + $" · {content.Rows.Count} fila(s)");
            heading.Format.Font.Bold = true; heading.Format.KeepWithNext = true;
            heading.Format.SpaceBefore = Unit.FromPoint(10); heading.Format.SpaceAfter = Unit.FromPoint(6);
            if (content.Rows.Count == 0) { section.AddParagraph("Sin filas con los filtros actuales."); continue; }
            var table = section.AddTable(); table.Borders.Width = 0.4; table.Borders.Color = Color.FromRgb(210, 221, 237);
            table.Format.Font.Size = 8; table.Format.SpaceAfter = Unit.FromPoint(4); table.Format.SpaceBefore = Unit.FromPoint(4);
            var weight = content.Columns.Sum(c => c.Width);
            foreach (var column in content.Columns) table.AddColumn(Unit.FromCentimeter(27.1 * column.Width / weight));
            var row = table.AddRow(); row.HeadingFormat = true; row.Format.Font.Bold = true;
            row.Shading.Color = Color.FromRgb(36, 77, 137); row.Format.Font.Color = Colors.White;
            for (var i = 0; i < content.Columns.Count; i++) row.Cells[i].AddParagraph(content.Columns[i].Header);
            for (var i = 0; i < content.Rows.Count; i++)
            {
                ct.ThrowIfCancellationRequested(); row = table.AddRow();
                if (i % 2 == 1) row.Shading.Color = Color.FromRgb(240, 244, 250);
                for (var j = 0; j < content.Columns.Count; j++)
                    row.Cells[j].AddParagraph(WrapLongTokens(Display(content.Rows[i][j]), Math.Max(8, (int)(27.1 * content.Columns[j].Width / weight * 5))));
            }
        }
        ct.ThrowIfCancellationRequested();
        var renderer = new PdfDocumentRenderer { Document = document };
        renderer.RenderDocument(); ct.ThrowIfCancellationRequested();
        renderer.PdfDocument.Save(stream, false);
    }
}
