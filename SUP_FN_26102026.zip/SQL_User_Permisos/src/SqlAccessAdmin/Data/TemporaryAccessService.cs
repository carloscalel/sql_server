using System.Data;
using Microsoft.Data.SqlClient;
using SqlAccessAdmin.Models;

namespace SqlAccessAdmin.Data;

public sealed partial class DirectSqlServerService
{
    public async Task<IReadOnlyList<OperationResult>> ExecuteApprovedRequestAsync(AccessRequestItem request,IEnumerable<DatabaseItem> targets,
        string? newLoginPassword,IReadOnlyList<AccessRequestStepItem>? steps=null,bool passwordPolicy=true,bool passwordExpiration=true,
        bool mustChangePassword=true,CancellationToken ct=default)
    {
        await adminDb.RequireReviewRequestsAsync(ct);
        var session=await adminDb.LoginAsync(ct);
        var targetList=targets.ToList();
        if(!await adminDb.HasSecurityMonitoringAsync(ct))throw new InvalidOperationException("Aplique 36, 33 actualizado (contrato v4) y 99 en el pivote antes de ejecutar gestiones.");
        var expiry=await adminDb.GetRequestValidityAsync(request.Id,ct,requireApproved:true);
        if(expiry.HasValue&&expiry<=SqlAccessAdmin.Infrastructure.AppTime.Now)throw new InvalidOperationException("La vigencia de esta solicitud ya venció. Rechácela y genere una nueva.");
        if(expiry.HasValue)await ValidateTemporaryPreconditionsAsync(request,targetList,steps??[],ct);
        if(targetList.Count==0||targetList.Select(x=>x.ServerId).Distinct().Count()!=1)throw new InvalidOperationException("La solicitud requiere destinos de una única instancia.");
        using var evidence=ExecutionEvidenceScope.Begin(request,session.Principal,adminDb,targetList[0].ServerId);
        var results=(await ExecuteApprovedRequestCoreAsync(request,targetList,newLoginPassword,steps,passwordPolicy,passwordExpiration,mustChangePassword,ct)).ToList();
        if(expiry.HasValue)
        {
            // Registrar cada destino aplicado aunque falle otra base. El login es
            // independiente de los pasos de base y puede permanecer tras un fallo.
            foreach(var target in targetList)
            {
                var index=results.FindIndex(r=>SecurityMonitoringRules.AppliedToTarget(r,target,request.Operation));
                var login=LoginAuthentication.CreatesLogin(request.Operation);
                if(index<0&&(!login||ExecutionEvidenceScope.Current?.CreatedLogins.Contains(request.TargetPrincipal)!=true))continue;
                try
                {
                    var resolved=await ResolveAsync(target.ServerId,login?"master":target.Name,CancellationToken.None);
                    await using var cn=new SqlConnection(resolved.ConnectionString);await cn.OpenAsync(CancellationToken.None);
                    await using var command=new SqlCommand(login||request.Operation is "SERVER_PERMISSION_CHANGE" or "ADD_SERVER_ROLE_MEMBER"
                        ?"SELECT sid FROM sys.server_principals WHERE name=@principal"
                        :"SELECT sid FROM sys.database_principals WHERE name=@principal",cn){CommandTimeout=30};
                    command.Parameters.Add(new("@principal",SqlDbType.NVarChar,256){Value=request.TargetPrincipal});
                    if(await command.ExecuteScalarAsync(CancellationToken.None) is not byte[] sid)
                    {
                        if(login&&index<0)continue; // no se creó el login
                        throw new InvalidOperationException("No se pudo comprobar el SID creado/modificado.");
                    }
                    await adminDb.RegisterTemporaryExecutionAsync(request.Id,target.ServerId,target.Name,sid,CancellationToken.None);
                }
                catch(Exception error)
                {
                    var detail="El acceso SQL puede estar aplicado; no se confirmó su seguimiento temporal. Conciliar antes de repetir: "+error.Message;
                    if(index>=0)results[index]=results[index] with{Success=false,Message=detail};
                    else results.Add(new(target.Server,target.Name,false,detail));
                }
            }
        }
        if(ExecutionEvidenceScope.Current?.Warnings is {Count:>0} warnings)
            results.Add(new(targetList[0].Server,"Seguimiento central",false,string.Join(" ",warnings.Distinct())));
        return results;
    }

    public async Task<string> CloseTemporaryAccessAsync(TemporaryAccessItem item,CancellationToken ct=default)
    {
        var session=await adminDb.LoginAsync(ct);
        if(!session.IsAdministrator)throw new UnauthorizedAccessException("Solo Administrador puede ejecutar cierres temporales.");
        using var evidence=ExecutionEvidenceScope.BeginClose(item,session.Principal,adminDb);
        var database=item.Kind=="LOGIN"||item.Database.Length==0?"master":item.Database;
        var resolved=await ResolveAsync(item.ServerId,database,ct);
        await using var lease=await TrackedSqlConnection.OpenAsync(resolved.ConnectionString,ct);var cn=lease.Connection;
        var instance=item.Kind=="LOGIN"||item.Database.Length==0;
        await using var identity=new SqlCommand(instance?"SELECT sid FROM sys.server_principals WHERE name=@principal":"SELECT sid FROM sys.database_principals WHERE name=@principal",cn);
        identity.Parameters.Add(new("@principal",SqlDbType.NVarChar,256){Value=item.Principal});
        var current=await identity.ExecuteScalarAsync(ct);
        if(current is not byte[] sid)throw new InvalidOperationException("El principal ya no existe. Se requiere conciliación de identidad; no se cerró la alerta.");
        if(!sid.AsSpan().SequenceEqual(item.Sid))throw new InvalidOperationException("El SID cambió: el nombre corresponde a otra cuenta. No se ejecutó el cierre.");
        var builder=new SqlCommandBuilder();string sql;
        if(item.Kind=="LOGIN")
        {
            if(IsInternalOrServicePrincipal(item.Principal))throw new InvalidOperationException("Principal interno no administrable.");
            var decision=await adminDb.PreviewRequestAsync(new("DISABLE_LOGIN",item.Principal,null,null,null,null,null,null,null,"TIC-RF-1","Cierre manual de vigencia temporal"),new(item.ServerId),ct);
            if(!decision.Allowed)throw new InvalidOperationException(decision.Reason);
            sql=$"ALTER LOGIN {builder.QuoteIdentifier(item.Principal)} DISABLE";
        }
        else if(item.Kind=="PERMISSION")
        {
            await ValidatePermissionPolicyAsync(item.Permission,item.Scope,"REVOKE",new(item.ServerId,item.Database),ct);
            // No retirar accidentalmente una denegación externa que sustituyó al GRANT.
            await RequireNewTemporaryPermissionAsync(cn,item.Principal,item.Permission,item.Scope,item.Securable,ct,denyOnly:true);
            sql=BuildPermissionSql(item.Principal,"REVOKE",item.Permission,item.Scope,item.Securable);
        }
        else if(item.Kind=="ROLE_MEMBERSHIP")
        {
            await ValidateRolePolicyAsync(item.Role,instance?"REMOVE_SERVER_ROLE_MEMBER":"REMOVE_ROLE_MEMBER",new(item.ServerId,item.Database),ct);
            sql=$"ALTER {(instance?"SERVER ":"")}ROLE {builder.QuoteIdentifier(item.Role)} DROP MEMBER {builder.QuoteIdentifier(item.Principal)}";
        }
        else if(item.Kind=="DATABASE_USER")
        {
            await EnsureDatabaseUserAsync(cn,null,item.Principal,ct);
            sql=$"DROP USER {builder.QuoteIdentifier(item.Principal)}";
        }
        else throw new InvalidOperationException("Tipo de cierre no compatible.");
        var trackedOperation=item.Kind switch
        {
            "LOGIN"=>"DISABLE_LOGIN","DATABASE_USER"=>"DROP_DB_USER",
            "ROLE_MEMBERSHIP"=>instance?"REMOVE_SERVER_ROLE_MEMBER":"REMOVE_ROLE_MEMBER",
            _=>instance?"SERVER_PERMISSION_CHANGE":"PERMISSION_CHANGE"
        };
        await TrackedSqlConnection.TagChangeAsync(cn,null,trackedOperation,item.Principal,"REVOKE",item.Permission,item.Scope,item.Securable,item.Role,ct);
        var guard=instance?"IF NOT EXISTS(SELECT 1 FROM sys.server_principals WHERE name=@principal AND sid=@expectedSid) THROW 51724,'La identidad cambió antes del cierre.',1;"
            :"IF NOT EXISTS(SELECT 1 FROM sys.database_principals WHERE name=@principal AND sid=@expectedSid) THROW 51724,'La identidad cambió antes del cierre.',1;";
        await using var command=new SqlCommand(guard+"\n"+sql,cn){CommandTimeout=60};
        command.Parameters.Add(new("@principal",SqlDbType.NVarChar,256){Value=item.Principal});command.Parameters.Add(new("@expectedSid",SqlDbType.VarBinary,85){Value=item.Sid});
        await TrackedSqlConnection.ExecuteCommandAsync(command,ct);
        return item.CloseDescription+". Operación confirmada por SQL Server; el acceso efectivo puede depender de otros roles o sesiones.";
    }
}
