using SqlAccessAdmin.Models;

namespace SqlAccessAdmin.Data;

public interface IAuthorizedUserStore
{
    Task<SessionContext> LoginAsync(CancellationToken ct = default);
    Task<IReadOnlyList<AuthorizedUser>> GetUsersAsync(CancellationToken ct = default);
    Task<IReadOnlyList<AuthorizedPrincipalOption>> GetAvailablePrincipalsAsync(CancellationToken ct = default);
    Task SaveAuthorizedUserAsync(AuthorizedUserEditData user, CancellationToken ct = default);
}
