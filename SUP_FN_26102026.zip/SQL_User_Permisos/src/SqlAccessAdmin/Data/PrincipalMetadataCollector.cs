using System.Data;
using Microsoft.Data.SqlClient;
namespace SqlAccessAdmin.Data;

public sealed partial class DirectSqlServerService
{
    public async Task<IReadOnlyList<string>> CollectPrincipalMetadataAsync(CancellationToken ct=default)
    {
        await adminDb.RequireReviewRequestsAsync(ct);
        var warnings=new List<string>();
        foreach(var server in (await adminDb.GetServersAsync(ct)).Where(s=>s.Active))
        {
            ct.ThrowIfCancellationRequested();
            try
            {
                var resolved=await ResolveAsync(server.Id,"master",ct);
                await using var cn=new SqlConnection(resolved.ConnectionString);await cn.OpenAsync(ct);
                await using(var permission=new SqlCommand("SELECT CONVERT(bit,CASE WHEN HAS_PERMS_BY_NAME(NULL,NULL,'VIEW ANY DEFINITION')=1 OR IS_SRVROLEMEMBER('sysadmin')=1 THEN 1 ELSE 0 END)",cn){CommandTimeout=15})
                    if(!Convert.ToBoolean(await permission.ExecuteScalarAsync(ct)))throw new InvalidOperationException("Se requiere visibilidad completa de metadatos de seguridad (VIEW ANY DEFINITION).");
                await ReadMetadataBatchAsync(server.Id,cn,MetadataSql.Logins,"","LOGIN",ct);
                var databases=new List<string>();
                await using(var command=new SqlCommand("SELECT name FROM sys.databases WHERE state=0 AND database_id NOT IN(2,3,4) ORDER BY name",cn){CommandTimeout=15})
                await using(var reader=await command.ExecuteReaderAsync(ct))while(await reader.ReadAsync(ct))databases.Add(reader.GetString(0));
                foreach(var database in databases)
                {
                    ct.ThrowIfCancellationRequested();
                    try
                    {
                        var builder=new SqlConnectionStringBuilder(resolved.ConnectionString){InitialCatalog=database};
                        await using var db=new SqlConnection(builder.ConnectionString);await db.OpenAsync(ct);
                        await using(var permission=new SqlCommand("SELECT CONVERT(bit,CASE WHEN HAS_PERMS_BY_NAME(DB_NAME(),'DATABASE','VIEW DEFINITION')=1 OR IS_SRVROLEMEMBER('sysadmin')=1 THEN 1 ELSE 0 END)",db){CommandTimeout=15})
                            if(!Convert.ToBoolean(await permission.ExecuteScalarAsync(ct)))throw new InvalidOperationException("Falta VIEW DEFINITION para consultar todos los usuarios.");
                        await ReadMetadataBatchAsync(server.Id,db,MetadataSql.Users,database,"DATABASE_USER",ct);
                    }
                    catch(OperationCanceledException){throw;}
                    catch(Exception error){warnings.Add($"{server.Name} / {database}: metadatos sin actualizar. "+(error is SqlException sql?$"SQL {sql.Number}.":error.Message));}
                }
            }
            catch(OperationCanceledException){throw;}
            catch(Exception error){warnings.Add(server.Name+": consulta de metadatos no completada. "+(error is SqlException sql?$"SQL {sql.Number}. Revise conexión y permisos.":error.Message));}
        }
        return warnings;
    }
    private async Task ReadMetadataBatchAsync(int serverId,SqlConnection cn,string sql,string database,string kind,CancellationToken ct)
    {
        var batch=new List<PrincipalMetadata>(500);var readAny=false;
        await using var command=new SqlCommand(sql,cn){CommandTimeout=30};
        await using var reader=await command.ExecuteReaderAsync(ct);
        while(await reader.ReadAsync(ct))
        {
            readAny=true;batch.Add(PrincipalMetadata.Read(reader,database,kind));
            if(batch.Count==500){await adminDb.ImportPrincipalMetadataAsync(serverId,batch,ct);batch.Clear();}
        }
        if(batch.Count>0||!readAny)await adminDb.ImportPrincipalMetadataAsync(serverId,batch,ct);
    }
}
