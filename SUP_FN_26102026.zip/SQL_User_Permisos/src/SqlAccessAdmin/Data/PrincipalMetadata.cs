using Microsoft.Data.SqlClient;
namespace SqlAccessAdmin.Data;

internal sealed record PrincipalMetadata(string DatabaseName,string PrincipalKind,string Sid,string PrincipalName,
    DateTime ModifiedLocal,DateTime? PasswordSetLocal,int EngineOffsetMinutes,DateTime EngineTime)
{
    internal static PrincipalMetadata Read(SqlDataReader reader,string database,string kind)=>new(database,kind,
        Convert.ToHexString((byte[])reader["sid"]),(string)reader["name"],
        SqlAccessAdmin.Infrastructure.AppTime.FromEngineLocal((DateTime)reader["modify_date"],(int)reader["EngineOffsetMinutes"]),
        reader["PasswordSetLocal"] is DateTime date?SqlAccessAdmin.Infrastructure.AppTime.FromEngineLocal(date,(int)reader["EngineOffsetMinutes"]):null,
        (int)reader["EngineOffsetMinutes"],SqlAccessAdmin.Infrastructure.AppTime.FromUtc((DateTime)reader["EngineTime"]));
}
internal static class MetadataSql
{
    internal const string LoginColumns="sid,name,modify_date,CONVERT(datetime2(7),CASE WHEN type='S' THEN LOGINPROPERTY(name,'PasswordLastSetTime') END) PasswordSetLocal,DATEPART(TZOFFSET,SYSDATETIMEOFFSET()) EngineOffsetMinutes,SYSUTCDATETIME() EngineTime";
    internal const string UserColumns="sid,name,modify_date,CONVERT(datetime2(7),NULL) PasswordSetLocal,DATEPART(TZOFFSET,SYSDATETIMEOFFSET()) EngineOffsetMinutes,SYSUTCDATETIME() EngineTime";
    internal const string LoginByName="SELECT "+LoginColumns+" FROM sys.server_principals WHERE name=@principal";
    internal const string UserByName="SELECT "+UserColumns+" FROM sys.database_principals WHERE name=@principal";
    internal const string Logins="SELECT "+LoginColumns+" FROM sys.server_principals WHERE type IN('S','U','G') AND principal_id>1 AND name NOT LIKE '##%'";
    internal const string Users="SELECT "+UserColumns+" FROM sys.database_principals WHERE type IN('S','U','G') AND principal_id>4 AND sid IS NOT NULL";
}
