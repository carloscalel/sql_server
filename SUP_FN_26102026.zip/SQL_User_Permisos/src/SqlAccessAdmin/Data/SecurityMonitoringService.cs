using SqlAccessAdmin.Models;

namespace SqlAccessAdmin.Data;

public sealed class SecurityMonitoringService(AdminDbGateway gateway,DirectSqlServerService direct,SessionContext session) : IDisposable
{
    private readonly CancellationTokenSource _lifetime=new();
    private readonly SemaphoreSlim _gate=new(1,1);
    private Task? _loop;
    private bool _disposed;
    public SecurityMonitoringSummary? Summary {get;private set;}
    public IReadOnlyList<SecurityAlertItem> ActiveAlerts {get;private set;}=[];
    public string Status {get;private set;}="Pendiente de actualización de seguridad.";
    public event Action? Changed;
    public void Start(){if(_loop is null&&!_disposed)_loop=RunAsync();}
    private async Task RunAsync()
    {
        try{while(!_lifetime.IsCancellationRequested){await RefreshAsync();await Task.Delay(TimeSpan.FromSeconds(60),_lifetime.Token);}}
        catch(OperationCanceledException){} // cierre/revocación de la sesión
    }
    public async Task RefreshAsync(bool compareMetadata=true)
    {
        if(_disposed)return;
        try
        {
            // Una revisión confirmada debe refrescar los contadores aunque haya
            // un ciclo periódico en curso; ese refresco solo consulta el pivote.
            if(compareMetadata){if(!await _gate.WaitAsync(0))return;}
            else await _gate.WaitAsync(_lifetime.Token);
        }
        catch(OperationCanceledException){return;}
        try
        {
            var warnings=new List<string>();
            if(!await gateway.HasSecurityMonitoringAsync(_lifetime.Token))
                throw new InvalidOperationException("Aplique la migración 33 para activar alertas, vigencias y reportes de seguridad.");
            if(compareMetadata&&session.CanReviewRequests)
                warnings.AddRange(await direct.CollectPrincipalMetadataAsync(_lifetime.Token));
            var summary=await gateway.RefreshSecuritySummaryAsync(_lifetime.Token);
            var activeAlerts=await gateway.GetActiveSecurityAlertsAsync(_lifetime.Token);
            _lifetime.Token.ThrowIfCancellationRequested();if(_disposed)return;
            Summary=summary;ActiveAlerts=activeAlerts;
            Status=!compareMetadata?"Alertas centrales actualizadas.":warnings.Count>0?string.Join(" | ",warnings):summary.LastCollected.HasValue
                ?session.CanReviewRequests?"Metadatos y alertas actualizados. Refresco cada 60 segundos."
                    :"Alertas centrales consultadas. Los datos corresponden a la última consulta de metadatos registrada."
                :"Sin referencia de metadatos todavía. La primera consulta establece la referencia inicial.";
            Changed?.Invoke();
        }
        catch(OperationCanceledException){}
        catch(Exception e){if(!_disposed){Status="Datos de seguridad no actualizados: "+e.Message;Changed?.Invoke();}}
        finally{_gate.Release();}
    }
    public void Dispose(){if(_disposed)return;_disposed=true;_lifetime.Cancel();Changed=null;}
}
