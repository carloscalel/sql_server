﻿using System.Data;
using System.Text.Json;
using Microsoft.Data.SqlClient;
using SqlAccessAdmin.Models;

namespace SqlAccessAdmin.Data;

public sealed partial class AdminDbGateway : ISecurityMonitoringStore,ISecurityAlertsStore
{
    private bool? _securityMonitoringAvailable;
    public async Task<bool> HasSecurityMonitoringAsync(CancellationToken ct=default)
    {
        if(_securityMonitoringAvailable.HasValue)return _securityMonitoringAvailable.Value;
        await LoginAsync(ct);
        await using var cn=new SqlConnection(ConnectionString);await cn.OpenAsync(ct);
        await using var cmd=new SqlCommand("SELECT CONVERT(bit,CASE WHEN OBJECT_ID(N'access.usp_AppChange_Prepare',N'P') IS NULL OR NOT EXISTS(SELECT 1 FROM access.SecurityMonitoringVersion WHERE Id=1 AND Version=4) THEN 0 ELSE 1 END)",cn);
        return (_securityMonitoringAvailable=Convert.ToBoolean(await cmd.ExecuteScalarAsync(ct))).Value;
    }
    private async Task<long> CreateRequestWithValidityAsync(IEnumerable<SqlParameter> parameters,DateTime expiresAt,CancellationToken ct)
    {
        if(expiresAt<=SqlAccessAdmin.Infrastructure.AppTime.Now)throw new InvalidOperationException("La fecha de vencimiento debe ser futura.");
        await LoginAsync(ct);
        await using var cn=new SqlConnection(ConnectionString);await cn.OpenAsync(ct);
        await using var tx=(SqlTransaction)await cn.BeginTransactionAsync(ct);
        try
        {
            await using var cmd=new SqlCommand("access.usp_AccessRequest_Create",cn,tx){CommandType=CommandType.StoredProcedure,CommandTimeout=120};
            cmd.Parameters.AddRange(parameters.ToArray());
            var id=Convert.ToInt64(await cmd.ExecuteScalarAsync(ct));
            await AttachRequestValidityAsync(cn,tx,id,expiresAt,ct);
            await tx.CommitAsync(ct);return id;
        }
        catch{try{await tx.RollbackAsync(CancellationToken.None);}catch{}throw;}
    }
    private async Task<DataTable> SecurityTableAsync(string procedure,SqlParameter[]? parameters=null,CancellationToken ct=default)
    {
        try
        {
            var result=await ExecuteTableAsync(procedure,parameters,ct);
            await LoginAsync(ct); // no publicar resultados tras revocación durante la consulta
            return result;
        }
        catch(SqlException ex)when(ex.Number is 208 or 2812)
        {throw new InvalidOperationException("Monitoreo de seguridad no instalado. Aplique 36_HoraLocalGuatemala.sql, después 33 actualizado y valide con 99.",ex);}
    }
    public async Task<SecurityMonitoringSummary> RefreshSecuritySummaryAsync(CancellationToken ct=default)
    {
        var t=await SecurityTableAsync("access.usp_SecurityMonitoring_Summary",ct:ct);var r=t.Rows[0];
        return new(r.Field<long>("ExpiredAccesses"),r.Field<long>("PasswordAlerts"),r.Field<long>("UnresolvedEvents"),r.Field<DateTime?>("LastCollected"),r.Field<DateTime>("EvaluatedAt"));
    }
    public async Task<IReadOnlyList<SecurityAlertItem>> GetActiveSecurityAlertsAsync(CancellationToken ct=default)
        =>(await SecurityTableAsync("access.usp_SecurityAlert_ActiveList",ct:ct)).Rows.Cast<DataRow>()
            .Select(r=>new SecurityAlertItem(r.Field<long>("AlertId"),r.Field<string>("AlertType")??"",r.Field<string>("Principal")??"",
                r.Field<string>("Server")??"",r.Field<string>("Detail")??"",r.Field<DateTime>("OccurredAt"))).ToList();
    private static TemporaryAccessItem MapTemporary(DataRow r)=>new(r.Field<long>("TemporaryAccessId"),r.Field<int>("ServerId"),r.Field<string>("Server")??"",
        r.Field<string>("PrincipalName")??"",(byte[])r["PrincipalSid"],r.Field<string>("AccessKind")??"",r.Field<string>("DatabaseName")??"",
        r.Field<string>("ScopeType")??"",r.Field<string>("Securable")??"",r.Field<string>("PermissionName")??"",r.Field<string>("RoleName")??"",
        r.Field<DateTime>("ExpiresAt"),r.Field<string>("ReviewState")??"",r.Field<int>("Revision"),(byte[])r["RowVersion"],r.Field<long>("CreatedRequestId"));
    public async Task<IReadOnlyList<TemporaryAccessItem>> GetTemporaryAccessesAsync(CancellationToken ct=default)
        =>(await SecurityTableAsync("access.usp_TemporaryAccess_List",ct:ct)).Rows.Cast<DataRow>().Select(MapTemporary).ToList();
    public async Task<IReadOnlyList<TemporaryAccessAction>> GetTemporaryActionsAsync(CancellationToken ct=default)
        =>(await SecurityTableAsync("access.usp_TemporaryAccessAction_List",ct:ct)).Rows.Cast<DataRow>().Select(r=>new TemporaryAccessAction(
            r.Field<long>("ActionId"),r.Field<long>("TemporaryAccessId"),r.Field<string>("ActionCode")??"",r.Field<string>("Status")??"",
            r.Field<string>("Ticket")??"",r.Field<string>("Reason")??"",r.Field<string>("RequestedBy")??"",r.Field<DateTime>("RequestedAt"),
            r.Field<DateTime?>("NewExpiresAt"),r.Field<string>("Result")??"")
            {Principal=r.Field<string>("PrincipalName")??"",Server=r.Field<string>("Server")??"",Resource=r.Field<string>("Resource")??""}).ToList();
    public async Task RequestTemporaryActionAsync(TemporaryAccessItem item,string action,DateTime? expiresAt,string ticket,string reason,CancellationToken ct=default)
        =>await SecurityTableAsync("access.usp_TemporaryAccessAction_Create",[
            new("@TemporaryAccessId",SqlDbType.BigInt){Value=item.Id},new("@ExpectedRowVersion",SqlDbType.Binary,8){Value=item.RowVersion},
            new("@ActionCode",SqlDbType.VarChar,10){Value=action},new("@NewExpiresAt",SqlDbType.DateTime2){Value=(object?)expiresAt??DBNull.Value},
            new("@Ticket",SqlDbType.VarChar,50){Value=ticket.Trim()},new("@Reason",SqlDbType.NVarChar,1000){Value=reason.Trim()}],ct);
    public async Task ReviewTemporaryActionAsync(long actionId,bool approve,CancellationToken ct=default)
        =>await SecurityTableAsync("access.usp_TemporaryAccessAction_Review",[new("@ActionId",SqlDbType.BigInt){Value=actionId},new("@Approve",SqlDbType.Bit){Value=approve}],ct);
    public async Task<TemporaryAccessItem> BeginTemporaryActionAsync(long actionId,CancellationToken ct=default)
        =>MapTemporary((await SecurityTableAsync("access.usp_TemporaryAccessAction_Begin",[new("@ActionId",SqlDbType.BigInt){Value=actionId}],ct)).Rows[0]) with{ExecutionActionId=actionId};
    public async Task CompleteTemporaryActionAsync(long actionId,bool success,string detail,CancellationToken ct=default)
        =>await SecurityTableAsync("access.usp_TemporaryAccessAction_Complete",[new("@ActionId",SqlDbType.BigInt){Value=actionId},new("@Success",SqlDbType.Bit){Value=success},
            new("@Detail",SqlDbType.NVarChar,2000){Value=detail.Length>2000?detail[..2000]:detail}],ct);
    internal async Task<IReadOnlyDictionary<string,DateTime>> GetConfirmedPasswordDatesAsync(int serverId,CancellationToken ct)
    {
        try
        {
            var table=await SecurityTableAsync("access.usp_Report_ConfirmedPasswordDates",
                [new("@ServerId",SqlDbType.Int){Value=serverId}],ct);
            return table.Rows.Cast<DataRow>().ToDictionary(r=>Convert.ToHexString((byte[])r["PrincipalSid"]),r=>r.Field<DateTime>("ChangedAt"));
        }
        catch(InvalidOperationException error) when(error.InnerException is SqlException { Number: 2812 })
        {
            throw new InvalidOperationException("Para mostrar los cambios de contraseña confirmados, solicite al administrador actualizar los reportes con el script 37.",error);
        }
    }

    public Task<DataTable> GetSecurityReportAsync(SecurityReportKind kind,DateTime from,DateTime to,int? serverId,CancellationToken ct=default)
    {
        var parameters=new List<SqlParameter>{
            new("@From",SqlDbType.DateTime2){Value=from},new("@To",SqlDbType.DateTime2){Value=to},
            new("@ServerId",SqlDbType.Int){Value=(object?)serverId??DBNull.Value}};
        if(kind!=SecurityReportKind.AccessChanges)parameters.Add(new("@History",SqlDbType.Bit){Value=kind==SecurityReportKind.PasswordHistory});
        return SecurityTableAsync(kind==SecurityReportKind.AccessChanges?"access.usp_Report_SecurityChanges":"access.usp_Report_PasswordChanges",parameters.ToArray(),ct);
    }

    internal async Task AttachRequestValidityAsync(SqlConnection cn,SqlTransaction transaction,long requestId,DateTime expiresAt,CancellationToken ct)
    {
        await using var cmd=new SqlCommand("access.usp_RequestValidity_Attach",cn,transaction){CommandType=CommandType.StoredProcedure};
        cmd.Parameters.Add(new("@RequestId",SqlDbType.BigInt){Value=requestId});
        cmd.Parameters.Add(new("@ExpiresAt",SqlDbType.DateTime2){Value=expiresAt});
        await cmd.ExecuteNonQueryAsync(ct);
    }
    public async Task<DateTime?> GetRequestValidityAsync(long id,CancellationToken ct=default,bool requireApproved=false)
    {
        var t=await SecurityTableAsync("access.usp_RequestValidity_Get",[new("@RequestId",SqlDbType.BigInt){Value=id},new("@RequireApproved",SqlDbType.Bit){Value=requireApproved}],ct);
        return t.Rows.Count==0?null:t.Rows[0].Field<DateTime?>("ExpiresAt");
    }
    internal async Task RegisterTemporaryExecutionAsync(long requestId,int serverId,string database,byte[] sid,CancellationToken ct)
        =>await SecurityTableAsync("access.usp_TemporaryAccess_RegisterExecution",[new("@RequestId",SqlDbType.BigInt){Value=requestId},
            new("@ServerId",SqlDbType.Int){Value=serverId},new("@DatabaseName",SqlDbType.NVarChar,128){Value=database},
            new("@PrincipalSid",SqlDbType.VarBinary,85){Value=sid}],ct);

    public async Task ResolvePasswordAlertAsync(long alertId,string reason,CancellationToken ct=default)
        =>await SecurityTableAsync("access.usp_PasswordAlert_Resolve",[
            new("@AlertId",SqlDbType.BigInt){Value=alertId},new("@Reason",SqlDbType.NVarChar,1000){Value=reason.Trim()}],ct);

    internal async Task<Guid> BeginAppExecutionAsync(long? requestId,long? actionId,int serverId,CancellationToken ct)
    {
        var t=await SecurityTableAsync("access.usp_AppExecution_Begin",[
            new("@RequestId",SqlDbType.BigInt){Value=(object?)requestId??DBNull.Value},new("@ActionId",SqlDbType.BigInt){Value=(object?)actionId??DBNull.Value},
            new("@ServerId",SqlDbType.Int){Value=serverId}],ct);
        return t.Rows[0].Field<Guid>("ExecutionId");
    }
    internal async Task<Guid> PrepareAppChangeAsync(Guid execution,int ordinal,string database,string kind,string operation,string? action,
        string? permission,string? scope,string? securable,string? role,string? sid,CancellationToken ct)
    {
        var t=await SecurityTableAsync("access.usp_AppChange_Prepare",[
            new("@ExecutionId",SqlDbType.UniqueIdentifier){Value=execution},new("@Ordinal",SqlDbType.Int){Value=ordinal},
            new("@DatabaseName",SqlDbType.NVarChar,128){Value=database},new("@PrincipalKind",SqlDbType.VarChar,20){Value=kind},
            new("@OperationCode",SqlDbType.VarChar,40){Value=operation},new("@PermissionAction",SqlDbType.VarChar,10){Value=(object?)action??DBNull.Value},
            new("@PermissionName",SqlDbType.NVarChar,128){Value=(object?)permission??DBNull.Value},new("@ScopeType",SqlDbType.VarChar,30){Value=(object?)scope??DBNull.Value},
            new("@Securable",SqlDbType.NVarChar,776){Value=(object?)securable??DBNull.Value},new("@RoleName",SqlDbType.NVarChar,128){Value=(object?)role??DBNull.Value},
            new("@PrincipalSid",SqlDbType.VarBinary,85){Value=sid is null?DBNull.Value:Convert.FromHexString(sid)}],ct);
        return t.Rows[0].Field<Guid>("EventId");
    }
    internal async Task CompleteAppChangeAsync(Guid id,string state,PrincipalMetadata? snapshot,DateTime completed,CancellationToken ct,bool definitionChanged=false)
        =>await SecurityTableAsync("access.usp_AppChange_Complete",[
            new("@EventId",SqlDbType.UniqueIdentifier){Value=id},new("@State",SqlDbType.VarChar,16){Value=state},
            new("@PrincipalSid",SqlDbType.VarBinary,85){Value=snapshot is null?DBNull.Value:Convert.FromHexString(snapshot.Sid)},
            new("@ModifiedLocal",SqlDbType.DateTime2){Value=(object?)snapshot?.ModifiedLocal??DBNull.Value},
            new("@PasswordSetLocal",SqlDbType.DateTime2){Value=(object?)snapshot?.PasswordSetLocal??DBNull.Value},
            new("@EngineOffsetMinutes",SqlDbType.Int){Value=(object?)snapshot?.EngineOffsetMinutes??DBNull.Value},new("@CompletedAt",SqlDbType.DateTime2){Value=completed},
            new("@DefinitionChanged",SqlDbType.Bit){Value=definitionChanged}],ct);
    internal async Task ImportPrincipalMetadataAsync(int serverId,IReadOnlyList<PrincipalMetadata> snapshots,CancellationToken ct)
        =>await SecurityTableAsync("access.usp_PrincipalMetadata_Import",[
            new("@ServerId",SqlDbType.Int){Value=serverId},new("@SnapshotsJson",SqlDbType.NVarChar,-1){Value=JsonSerializer.Serialize(snapshots)}],ct);
}
