﻿namespace SqlAccessAdmin.Data;

// Read-only queries. Never expand inherited roles into one row per object.
internal static class ReportsSql
{
    internal const string DatabaseVisibility = """
        IF COALESCE(HAS_PERMS_BY_NAME(DB_NAME(), 'DATABASE', 'VIEW DEFINITION'), 0) <> 1
            THROW 51000, N'El reporte requiere VIEW DEFINITION en la base para consultar el catálogo completo. Solicite al DBA revisar la visibilidad de metadatos.', 1;
        """;

    internal const string Databases = """
        SELECT name FROM sys.databases
        WHERE state = 0 AND HAS_DBACCESS(name) = 1
        ORDER BY name;
        """;

    internal const string Users = LoginVisibility + """

        SELECT name, type_desc FROM sys.server_principals
        WHERE type IN ('S','U') AND name NOT LIKE N'##%'
          AND name NOT IN (N'dbo',N'guest',N'INFORMATION_SCHEMA',N'sys')
          AND UPPER(name) NOT LIKE N'NT AUTHORITY\%'
          AND UPPER(name) NOT LIKE N'NT SERVICE\%'
        ORDER BY name;
        """;

    internal const string UserAccess = DatabaseVisibility + """

        DECLARE @id int, @mapped sysname;
        SELECT TOP (1) @id=principal_id,@mapped=name FROM sys.database_principals
        WHERE sid=@sid AND type IN ('S','U') AND name NOT IN (N'dbo',N'guest',N'INFORMATION_SCHEMA',N'sys')
        ORDER BY principal_id;
        SELECT COALESCE(@mapped,N'') AS MappedUser,
               CAST(CASE WHEN EXISTS(SELECT 1 FROM sys.databases WHERE database_id=DB_ID() AND owner_sid=@sid) THEN 1 ELSE 0 END AS bit) AS IsOwner;
        ;WITH memberships AS
        (
            SELECT rm.role_principal_id, 1 AS depth,
                CAST('/' + CAST(@id AS varchar(11)) + '/' + CAST(rm.role_principal_id AS varchar(11)) + '/' AS varchar(max)) AS path
            FROM sys.database_role_members rm WHERE rm.member_principal_id=@id
            UNION ALL
            SELECT rm.role_principal_id, m.depth + 1,
                CAST(m.path + CAST(rm.role_principal_id AS varchar(11)) + '/' AS varchar(max))
            FROM sys.database_role_members rm INNER JOIN memberships m ON rm.member_principal_id=m.role_principal_id
            WHERE CHARINDEX('/' + CAST(rm.role_principal_id AS varchar(11)) + '/', m.path)=0
        )
        SELECT r.name, r.is_fixed_role, CAST(MAX(CASE WHEN m.depth=1 THEN 1 ELSE 0 END) AS bit) AS IsDirect
        FROM memberships m INNER JOIN sys.database_principals r ON r.principal_id=m.role_principal_id
        GROUP BY r.name, r.is_fixed_role
        UNION
        SELECT name, is_fixed_role, CAST(0 AS bit) FROM sys.database_principals WHERE name=N'public' AND type='R' AND @id IS NOT NULL
        ORDER BY name OPTION (MAXRECURSION 32767);

        SELECT CASE p.class WHEN 0 THEN N'Base' WHEN 3 THEN N'Esquema'
                   ELSE CASE WHEN p.minor_id>0 THEN N'Columna' ELSE N'Objeto' END END AS Scope,
               COALESCE(s.name, os.name, N'') AS SchemaName,
               COALESCE(o.name, N'') AS ObjectName,
               COALESCE(RTRIM(o.type), N'') AS ObjectType,
               COALESCE(c.name, N'') AS ColumnName, p.permission_name,
               CASE p.state WHEN 'W' THEN N'GRANT WITH GRANT OPTION' WHEN 'R' THEN N'REVOKE (excepción de columna)'
                    WHEN 'D' THEN N'DENY' ELSE N'GRANT' END AS Action
        FROM sys.database_permissions p
        LEFT JOIN sys.objects o ON p.class=1 AND p.major_id=o.object_id
        LEFT JOIN sys.schemas os ON os.schema_id=o.schema_id
        LEFT JOIN sys.schemas s ON p.class=3 AND p.major_id=s.schema_id
        LEFT JOIN sys.columns c ON p.class=1 AND p.major_id=c.object_id AND p.minor_id=c.column_id
        WHERE p.grantee_principal_id=@id AND
              (p.class IN (0,3) OR (p.class=1 AND o.is_ms_shipped=0 AND o.type IN ('U','V','P','PC','FN','IF','TF','FS','FT')))
        ORDER BY Scope, SchemaName, ObjectName, ColumnName, p.permission_name, Action;
        """;

    internal const string LoginVisibility = """
        IF COALESCE(HAS_PERMS_BY_NAME(NULL, NULL, 'VIEW ANY DEFINITION'),0)<>1
           AND COALESCE(HAS_PERMS_BY_NAME(NULL, NULL, 'ALTER ANY LOGIN'),0)<>1
           AND COALESCE(HAS_PERMS_BY_NAME(NULL, NULL, 'VIEW ANY SECURITY DEFINITION'),0)<>1
            THROW 51003, N'El reporte requiere visibilidad de los logins SQL y Windows. Solicite al DBA revisar los permisos de metadatos de la instancia.', 1;
        """;

    internal const string ServerAccess = """
        IF COALESCE(HAS_PERMS_BY_NAME(NULL, NULL, 'VIEW ANY DEFINITION'),0)<>1
           AND COALESCE(HAS_PERMS_BY_NAME(NULL, NULL, 'VIEW ANY SECURITY DEFINITION'),0)<>1
            THROW 51004, N'El reporte de instancia requiere VIEW ANY DEFINITION o VIEW ANY SECURITY DEFINITION para consultar roles y permisos completos.', 1;
        DECLARE @id int, @loginSid varbinary(85);
        SELECT @id=principal_id,@loginSid=sid FROM sys.server_principals
        WHERE name=@user AND type IN ('S','U') AND name NOT LIKE N'##%'
          AND name NOT IN (N'dbo',N'guest',N'INFORMATION_SCHEMA',N'sys');
        IF @id IS NULL THROW 51001, N'El login SQL o Windows ya no existe. Actualice los catálogos.', 1;
        SELECT @loginSid AS LoginSid;
        ;WITH memberships AS
        (
            SELECT rm.role_principal_id,1 AS depth,
                   CAST('/'+CAST(@id AS varchar(11))+'/'+CAST(rm.role_principal_id AS varchar(11))+'/' AS varchar(max)) AS path
            FROM sys.server_role_members rm WHERE rm.member_principal_id=@id
            UNION ALL
            SELECT rm.role_principal_id,m.depth+1,CAST(m.path+CAST(rm.role_principal_id AS varchar(11))+'/' AS varchar(max))
            FROM sys.server_role_members rm INNER JOIN memberships m ON rm.member_principal_id=m.role_principal_id
            WHERE CHARINDEX('/'+CAST(rm.role_principal_id AS varchar(11))+'/',m.path)=0
        )
        SELECT r.name,r.is_fixed_role,CAST(MAX(CASE WHEN m.depth=1 THEN 1 ELSE 0 END) AS bit) AS IsDirect
        FROM memberships m INNER JOIN sys.server_principals r ON r.principal_id=m.role_principal_id
        GROUP BY r.name,r.is_fixed_role
        UNION
        SELECT name,is_fixed_role,CAST(0 AS bit) FROM sys.server_principals WHERE name=N'public' AND type='R'
        UNION
        SELECT sr.name,sr.is_fixed_role,CAST(0 AS bit) FROM sys.server_principals sr
        WHERE sr.name=N'sysadmin' AND sr.type='R' AND IS_SRVROLEMEMBER(N'sysadmin',@user)=1
          AND NOT EXISTS(SELECT 1 FROM memberships m WHERE m.role_principal_id=sr.principal_id)
        ORDER BY name OPTION(MAXRECURSION 32767);
        SELECT CASE p.class WHEN 100 THEN N'Instancia' WHEN 101 THEN N'Login/rol'
                 WHEN 105 THEN N'Endpoint' WHEN 108 THEN N'Grupo de disponibilidad' ELSE p.class_desc END AS Scope,
               N'' AS SchemaName,
               CASE p.class WHEN 100 THEN N'(instancia)' WHEN 101 THEN COALESCE(target.name,N'(no visible)')
                    WHEN 105 THEN COALESCE(ep.name,N'(no visible)') WHEN 108 THEN N'Id '+CONVERT(nvarchar(128),p.major_id)
                    ELSE CONVERT(nvarchar(128),p.major_id) END AS ObjectName,
               N'' AS ObjectType,N'' AS ColumnName,p.permission_name,
               CASE p.state WHEN 'W' THEN N'GRANT WITH GRANT OPTION' WHEN 'D' THEN N'DENY' WHEN 'R' THEN N'REVOKE' ELSE N'GRANT' END AS Action
        FROM sys.server_permissions p
        LEFT JOIN sys.server_principals target ON p.class=101 AND target.principal_id=p.major_id
        LEFT JOIN sys.endpoints ep ON p.class=105 AND ep.endpoint_id=p.major_id
        WHERE p.grantee_principal_id=@id ORDER BY Scope,ObjectName,p.permission_name,Action;
        """;

    internal const string Roles = DatabaseVisibility + LoginVisibility + """

        ;WITH eligible_users AS
        (
            SELECT dp.principal_id, dp.name, sp.type_desc
            FROM sys.database_principals dp
            INNER JOIN sys.server_principals sp ON sp.sid=dp.sid AND sp.type IN ('S','U')
            WHERE dp.type IN ('S','U')
              AND dp.name NOT IN (N'dbo',N'guest',N'INFORMATION_SCHEMA',N'sys')
        )
        SELECT r.name, r.is_fixed_role, m.name AS MemberName, m.type_desc AS MemberType
        FROM sys.database_principals r
        LEFT JOIN sys.database_role_members rm ON rm.role_principal_id=r.principal_id
        LEFT JOIN eligible_users m ON m.principal_id=rm.member_principal_id
        WHERE r.type='R' AND r.name<>N'public'
        UNION ALL
        SELECT r.name, r.is_fixed_role, m.name, m.type_desc
        FROM sys.database_principals r
        LEFT JOIN eligible_users m ON 1=1
        WHERE r.type='R' AND r.name=N'public'
        ORDER BY name, MemberName;
        """;

    internal const string CredentialAge = """
        IF COALESCE(HAS_PERMS_BY_NAME(NULL, NULL, 'VIEW ANY DEFINITION'),0)<>1
           AND COALESCE(HAS_PERMS_BY_NAME(NULL, NULL, 'ALTER ANY LOGIN'),0)<>1
           AND COALESCE(HAS_PERMS_BY_NAME(NULL, NULL, 'VIEW ANY SECURITY DEFINITION'),0)<>1
            THROW 51002, N'No hay visibilidad de todos los logins. El DBA debe revisar los permisos de metadatos de seguridad de la instancia.', 1;
        DECLARE @now datetime = GETDATE();
        SELECT l.name, l.sid, DATEADD(minute,-360-DATEPART(TZOFFSET,SYSDATETIMEOFFSET()),l.create_date) CreatedAt, l.type_desc AS LoginType, l.is_disabled, DATEADD(minute,-360-DATEPART(TZOFFSET,SYSDATETIMEOFFSET()),a.LastSet) LastSet,
               CASE WHEN a.LastSet IS NULL THEN NULL
                    ELSE DATEDIFF(day,a.LastSet,@now) - CASE WHEN DATEADD(day,DATEDIFF(day,a.LastSet,@now),a.LastSet)>@now THEN 1 ELSE 0 END END AS DaysElapsed,
               DATEADD(minute,-360-DATEPART(TZOFFSET,SYSDATETIMEOFFSET()),l.modify_date) LastModified,
               DATEDIFF(day,l.modify_date,@now) - CASE WHEN DATEADD(day,DATEDIFF(day,l.modify_date,@now),l.modify_date)>@now THEN 1 ELSE 0 END AS ModificationDays,
               sl.is_policy_checked, sl.is_expiration_checked
        FROM sys.server_principals l
        LEFT JOIN sys.sql_logins sl ON sl.principal_id=l.principal_id
        OUTER APPLY (SELECT CASE WHEN l.type='S' THEN TRY_CONVERT(datetime,LOGINPROPERTY(l.name,'PasswordLastSetTime')) END AS RawLastSet) raw
        OUTER APPLY (SELECT CASE WHEN raw.RawLastSet>=l.create_date AND raw.RawLastSet<=@now THEN raw.RawLastSet END AS LastSet) a
        WHERE l.type IN ('S','U')
          AND l.name NOT LIKE N'##%'
          AND l.name NOT LIKE N'NT %'
          AND l.name NOT LIKE N'NT SERVICE%'
        ORDER BY l.name;
        """;
}
