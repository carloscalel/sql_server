using System.Data;
using Microsoft.Data.SqlClient;
using SqlAccessAdmin.Models;

namespace SqlAccessAdmin.Data;

public sealed partial class DirectSqlServerService
{
    public async Task ValidatePasswordChangeLoginAsync(int serverId,string login,CancellationToken ct=default)
    {
        LoginPasswordChange.Validate(login,"SQL",true,true,true,true);
        if(IsInternalOrServicePrincipal(login))throw new InvalidOperationException("El login seleccionado no es administrable.");
        var resolved=await ResolveAsync(serverId,"master",ct);
        await using var cn=new SqlConnection(resolved.ConnectionString);await cn.OpenAsync(ct);
        await using var command=new SqlCommand(PasswordChangeLoginGuardSql,cn){CommandTimeout=resolved.Server.TimeoutSeconds};
        command.Parameters.Add(new("@login",SqlDbType.NVarChar,128){Value=login});
        await TrackedSqlConnection.ExecuteCommandAsync(command,ct);
    }

    // Volver a comprobar el tipo real en el destino evita usar el catálogo de la UI como autorización.
    private const string PasswordChangeLoginGuardSql="""
        IF NOT EXISTS(SELECT 1 FROM sys.sql_logins WHERE name=@login AND principal_id<>1)
            THROW 51600,N'El login SQL no existe, no es visible o es una cuenta de sistema.',1;
        """;

    private static string BuildLoginPasswordChangeSql(string login,bool policy,bool expiration,bool mustChange)
    {
        LoginPasswordChange.Validate(login,"SQL",true,policy,expiration,mustChange);
        if(IsInternalOrServicePrincipal(login))throw new InvalidOperationException("El login seleccionado no es administrable.");
        // El secreto llega como parámetro. QUOTENAME escapa el literal dentro del servidor (máximo 128 caracteres).
        return PasswordChangeLoginGuardSql+"\n"+$"""
            IF @password IS NULL OR DATALENGTH(@password)<32 OR DATALENGTH(@password)>256
                THROW 51601,N'La contraseña debe contener entre 16 y 128 caracteres.',1;
            DECLARE @sql nvarchar(max)=N'ALTER LOGIN {new SqlCommandBuilder().QuoteIdentifier(login).Replace("'","''")} WITH PASSWORD=N'
                +QUOTENAME(@password,N'''')+N'{(mustChange?" MUST_CHANGE":"")}, CHECK_POLICY={(policy?"ON":"OFF")}, CHECK_EXPIRATION={(expiration?"ON":"OFF")};';
            EXEC sys.sp_executesql @sql;
            """;
    }

    private static async Task ChangeLoginPasswordAsync(string connectionString,string login,string? password,bool policy,bool expiration,bool mustChange,CancellationToken ct)
    {
        LoginPasswordChange.Validate(login,"SQL",!string.IsNullOrEmpty(password),policy,expiration,mustChange);
        if(password!.Length is <16 or >128)throw new InvalidOperationException("La contraseña debe contener entre 16 y 128 caracteres.");
        await using var connectionLease=await TrackedSqlConnection.OpenAsync(connectionString,ct);var cn=connectionLease.Connection;
        await using var command=new SqlCommand(BuildLoginPasswordChangeSql(login,policy,expiration,mustChange),cn){CommandTimeout=60};
        command.Parameters.Add(new("@login",SqlDbType.NVarChar,128){Value=login});
        command.Parameters.Add(new("@password",SqlDbType.NVarChar,128){Value=password});
        await TrackedSqlConnection.TagChangeAsync(cn,null,"CHANGE_LOGIN_PASSWORD",login,ct:ct);
        await TrackedSqlConnection.ExecuteCommandAsync(command,ct);
    }
}
