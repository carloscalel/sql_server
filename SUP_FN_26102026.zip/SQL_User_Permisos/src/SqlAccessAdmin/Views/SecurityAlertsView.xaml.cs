using System.Windows.Controls;
namespace SqlAccessAdmin.Views;
public partial class SecurityAlertsView : UserControl
{
    public SecurityAlertsView()=>InitializeComponent();
}
