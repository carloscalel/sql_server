using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using SqlAccessAdmin.ViewModels;

namespace SqlAccessAdmin.Views;

public partial class LoginPasswordEditor : UserControl
{
    private AccessViewModel? _viewModel;
    public LoginPasswordEditor()
    {
        InitializeComponent();
        DataContextChanged+=(_,_)=>Subscribe(DataContext as AccessViewModel);
        Loaded+=(_,_)=>Subscribe(DataContext as AccessViewModel);
        Unloaded+=(_,_)=>Subscribe(null);
    }
    private void Subscribe(AccessViewModel? viewModel)
    {
        if(_viewModel is not null)_viewModel.TemporaryPasswordCleared-=ClearPasswordBoxes;
        _viewModel=viewModel;
        if(_viewModel is not null)_viewModel.TemporaryPasswordCleared+=ClearPasswordBoxes;
    }
    private void ClearPasswordBoxes()
    {TemporaryPasswordBox.Clear();TemporaryPasswordConfirmationBox.Clear();}
    private void PasswordLength_OnPreviewTextInput(object sender,TextCompositionEventArgs e)
    {e.Handled=e.Text.Any(character=>!char.IsDigit(character));}
    private void TemporaryPassword_OnPasswordChanged(object sender,RoutedEventArgs e)
    {if(DataContext is AccessViewModel vm)vm.TemporaryPassword=((PasswordBox)sender).Password;}
    private void TemporaryPasswordConfirmation_OnPasswordChanged(object sender,RoutedEventArgs e)
    {if(DataContext is AccessViewModel vm)vm.TemporaryPasswordConfirmation=((PasswordBox)sender).Password;}
    private void GeneratePassword_OnClick(object sender,RoutedEventArgs e)
    {
        if(DataContext is not AccessViewModel vm)return;
        try
        {
            var password=vm.GenerateTemporaryPassword();
            TemporaryPasswordBox.Password=password;TemporaryPasswordConfirmationBox.Password=password;
            vm.Status=$"Contraseña segura de {password.Length} caracteres sugerida. Cópiela y entréguela al usuario mediante un canal seguro.";
        }
        catch(InvalidOperationException error){vm.Status=error.Message;}
    }
    private void CopyPassword_OnClick(object sender,RoutedEventArgs e)
    {
        if(DataContext is not AccessViewModel vm)return;
        if(!vm.IsTemporaryPasswordValid){vm.Status=vm.TemporaryPasswordValidationMessage;return;}
        Clipboard.SetText(vm.TemporaryPassword);
        vm.Status="Contraseña copiada. Entréguela al usuario por un canal seguro.";
    }
}
