using System.ComponentModel;
using System.Windows;
using SqlAccessAdmin.ViewModels;

namespace SqlAccessAdmin.Views;

public partial class SecurityAlertsWindow : Window
{
    private readonly SecurityAlertsViewModel _viewModel;
    private bool _forceClose;
    public string? NavigationTarget {get;private set;}
    public SecurityAlertsWindow(SecurityAlertsViewModel viewModel)
    {
        _viewModel=viewModel;InitializeComponent();DataContext=viewModel;
        viewModel.NavigationRequested+=Navigate;
        Closed+=(_,_)=>{viewModel.NavigationRequested-=Navigate;viewModel.Dispose();};
    }
    private async void OnLoaded(object sender,RoutedEventArgs e)
    {
        var area=SystemParameters.WorkArea;
        MaxWidth=area.Width;MaxHeight=area.Height;
        await _viewModel.LoadAsync();
    }
    private void Navigate(string target){NavigationTarget=target;Close();if(IsVisible)NavigationTarget=null;}
    private void Close_Click(object sender,RoutedEventArgs e)=>Close();
    private void OnClosing(object? sender,CancelEventArgs e)
    {
        if(_forceClose)return;
        if(_viewModel.IsBusy){e.Cancel=true;return;}
        if(!string.IsNullOrWhiteSpace(_viewModel.Reason)
            &&!ConfirmationWindow.Confirm("Descartar motivo sin registrar","El motivo escrito aún no se ha registrado. ¿Desea cerrar esta ventana y descartarlo?","Descartar y cerrar","ALERTAS DE SEGURIDAD"))e.Cancel=true;
    }
    public void CloseForSessionEnd(){_forceClose=true;_viewModel.Dispose();Close();}
}
