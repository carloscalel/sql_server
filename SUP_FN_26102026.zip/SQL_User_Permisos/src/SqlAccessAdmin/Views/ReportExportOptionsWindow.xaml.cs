using System.Windows;
using SqlAccessAdmin.Models;

namespace SqlAccessAdmin.Views;

public partial class ReportExportOptionsWindow : Window
{
    public ReportExportScope Scope => ActiveSectionOption.IsChecked == true ? ReportExportScope.ActiveSection : ReportExportScope.FullReport;

    public ReportExportOptionsWindow(ReportExportFormat format, string activeSection)
    {
        InitializeComponent();
        FormatDescription.Text = format switch
        {
            ReportExportFormat.Pdf => "PDF: las secciones elegidas se integran en un documento continuo.",
            ReportExportFormat.Excel => "Excel: cada sección elegida se guarda en una hoja independiente del mismo libro.",
            _ => "CSV: los datos elegidos se identifican mediante la columna Sección en un solo archivo."
        };
        ActiveSectionDescription.Text = activeSection;
    }

    private void ContinueClick(object sender, RoutedEventArgs e) => DialogResult = true;
}
