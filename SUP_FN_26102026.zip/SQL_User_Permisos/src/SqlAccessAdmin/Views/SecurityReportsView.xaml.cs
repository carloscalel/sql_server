using System.Windows;
using System.Windows.Controls;

namespace SqlAccessAdmin.Views;

public partial class SecurityReportsView : UserControl
{
    public SecurityReportsView() => InitializeComponent();

    private void OnAutoGeneratingColumn(object sender, DataGridAutoGeneratingColumnEventArgs e)
    {
        e.Column.MinWidth = 100;
        e.Column.Width = new DataGridLength(e.PropertyName switch
        {
            "Detalle" => 360,
            "Fuente" => 230,
            "Evento" => 260,
            "SID" => 250,
            _ when e.PropertyType == typeof(DateTime) || e.PropertyType == typeof(DateTimeOffset) => 170,
            _ => 150
        });
        if (e.Column is DataGridTextColumn textColumn)
        {
            textColumn.ElementStyle = (Style)Resources["ReportCellText"];
            if (e.PropertyType == typeof(DateTime) || e.PropertyType == typeof(DateTimeOffset))
                textColumn.Binding.StringFormat = "dd/MM/yyyy HH:mm:ss";
        }
    }
}
