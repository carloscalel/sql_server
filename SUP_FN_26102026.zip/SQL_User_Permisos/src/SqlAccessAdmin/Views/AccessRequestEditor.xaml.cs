using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.ComponentModel;
using SqlAccessAdmin.ViewModels;

namespace SqlAccessAdmin.Views;

public partial class AccessRequestEditor : UserControl
{
    private AccessViewModel? _subscribedViewModel;

    public AccessRequestEditor()
    {
        InitializeComponent();
        DataContextChanged+=OnDataContextChanged;
        Loaded+=(_,_)=>SubscribeTo(DataContext as AccessViewModel);
        Unloaded+=(_,_)=>SubscribeTo(null);
    }

    private void OnDataContextChanged(object sender,DependencyPropertyChangedEventArgs e)=>SubscribeTo(e.NewValue as AccessViewModel);

    private void SubscribeTo(AccessViewModel? viewModel)
    {
        if(_subscribedViewModel is not null)
        {
            _subscribedViewModel.PropertyChanged-=ViewModel_OnPropertyChanged;
        }
        _subscribedViewModel=viewModel;
        if(_subscribedViewModel is not null)
        {
            _subscribedViewModel.PropertyChanged+=ViewModel_OnPropertyChanged;
        }
    }

    private void ViewModel_OnPropertyChanged(object? sender,PropertyChangedEventArgs e)
    {
        if(e.PropertyName!=nameof(AccessViewModel.CreateUserStep)||sender is not AccessViewModel vm)return;
        if(_displayedCreateUserStep==vm.CreateUserStep)return;
        _displayedCreateUserStep=vm.CreateUserStep;EditorScroll.ScrollToTop();
    }
    private int _displayedCreateUserStep=1;

    private async void AddCreateUserObjects_OnClick(object sender,RoutedEventArgs e)
    {
        if(DataContext is not AccessViewModel vm||vm.IsLoadingCreateUserObjects)return;
        var objects=await vm.LoadCreateUserObjectsAsync();
        if(objects.Count==0)return;
        var selector=new DatabaseObjectSelectorWindow(objects,vm.CreateUserObjectRows.Select(x=>x.Item))
        {Owner=Window.GetWindow(this)};
        if(selector.ShowDialog()==true)vm.ApplyCreateUserObjects(selector.SelectedObjects);
    }

    private void TicketNumber_OnPreviewTextInput(object sender,TextCompositionEventArgs e)
    {
        e.Handled=e.Text.Any(character=>!char.IsDigit(character));
    }

    private async void SelectObjects_OnClick(object sender,RoutedEventArgs e)
    {
        if(DataContext is not AccessViewModel vm)return;
        await vm.LoadDatabaseObjectsForSelectionAsync();
        if(vm.DatabaseObjects.Count==0)return;
        var selector=new DatabaseObjectSelectorWindow(vm.DatabaseObjects,vm.SelectedDatabaseObjects)
        {
            Owner=Window.GetWindow(this)
        };
        if(selector.ShowDialog()==true)vm.ApplySelectedDatabaseObjects(selector.SelectedObjects);
    }

    private void SelectAllPermissions_OnClick(object sender,RoutedEventArgs e)
    {
        if(DataContext is not AccessViewModel vm)return;
        foreach(var permission in vm.PermissionChoices)permission.IsSelected=true;
    }

    private void ClearPermissions_OnClick(object sender,RoutedEventArgs e)
    {
        if(DataContext is not AccessViewModel vm)return;
        foreach(var permission in vm.PermissionChoices)permission.IsSelected=false;
    }

}
