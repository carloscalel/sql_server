using System.Windows;
using SqlAccessAdmin.ViewModels;

namespace SqlAccessAdmin.Views;

public partial class LoginPasswordChangeWindow : Window
{
    public LoginPasswordChangeWindow()=>InitializeComponent();
    private void Submit_OnClick(object sender,RoutedEventArgs e)
    {
        if(DataContext is AccessViewModel vm&&vm.IsExternalTicketValid&&!vm.IsVerifyingExternalTicket&&vm.IsTemporaryPasswordValid)
            DialogResult=true;
    }
}
