using System.ComponentModel;
using System.Windows;
using System.Windows.Controls;
using SqlAccessAdmin.ViewModels;

namespace SqlAccessAdmin.Views;

public partial class MainWindow : Window
{
    public MainWindow() => InitializeComponent();
    private void Logout_Click(object sender, RoutedEventArgs e) => Close();
    private void ReportsHeader_Click(object sender, RoutedEventArgs e)
    {
        if(ReportsNavigation.Items[0] is TreeViewItem reports)reports.IsExpanded=!reports.IsExpanded;
    }

    protected override void OnClosing(CancelEventArgs e)
    {
        if (DataContext is MainViewModel { Current: PolicyViewModel policy } && !policy.ConfirmLeave()) e.Cancel = true;
        if (DataContext is MainViewModel { Current: UsersViewModel users } && !users.ConfirmLeave()) e.Cancel = true;
        base.OnClosing(e);
    }

    protected override void OnClosed(EventArgs e)
    {
        if(DataContext is MainViewModel main)main.Dispose();
        base.OnClosed(e);
        // Close() first honors pending-edit checks; accepted closure ends every window.
        Application.Current?.Shutdown();
    }
}
