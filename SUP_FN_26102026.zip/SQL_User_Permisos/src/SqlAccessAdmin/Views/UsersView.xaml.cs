using System.Windows;
using System.Windows.Controls;

namespace SqlAccessAdmin.Views;

public partial class UsersView : UserControl
{
    public UsersView()=>InitializeComponent();
    private void ResetEditorScroll(object sender,RoutedEventArgs e)=>EditorScrollViewer?.ScrollToTop();
}
