using System.Windows.Controls;

namespace SqlAccessAdmin.Views;

public partial class ReportsView : UserControl
{
    public ReportsView() => InitializeComponent();
}
