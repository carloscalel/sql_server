using System.Windows.Controls;
namespace SqlAccessAdmin.Views;
public partial class TemporaryAccessView : UserControl
{
    public TemporaryAccessView()=>InitializeComponent();
}
