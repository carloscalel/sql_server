using System.Windows;
using Microsoft.Data.SqlClient;

namespace SqlAccessAdmin;

public partial class App : Application
{
    protected override void OnExit(ExitEventArgs e)
    {
        // Operations own and dispose their SQL connections. Release pooled connections
        // for both adminDB and direct servers as the application terminates.
        try { SqlConnection.ClearAllPools(); }
        finally { base.OnExit(e); }
    }
}
