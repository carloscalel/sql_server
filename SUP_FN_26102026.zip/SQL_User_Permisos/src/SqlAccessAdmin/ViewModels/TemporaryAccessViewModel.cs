using System.Collections.ObjectModel;
using System.Windows;
using SqlAccessAdmin.Infrastructure;
using SqlAccessAdmin.Models;
using SqlAccessAdmin.Data;

namespace SqlAccessAdmin.ViewModels;

public sealed class TemporaryAccessViewModel : BindableBase,IDisposable
{
    private readonly ISecurityMonitoringStore _store;
    private readonly Func<TemporaryAccessItem,CancellationToken,Task<string>> _close;
    private readonly Func<string,bool> _confirm;
    private readonly CancellationTokenSource _lifetime=new();
    private bool _disposed,_busy;
    private string _status="",_filter="",_ticket="",_reason="",_expiryTime="18:00:00";
    private DateTime? _expiryDate=SqlAccessAdmin.Infrastructure.AppTime.Now.Date.AddDays(1);
    private TemporaryAccessItem? _selected;
    private TemporaryAccessAction? _selectedAction;
    private SecurityMonitoringService? _monitor;
    private ExternalTicketDetails? _verifiedTicket;
    private bool _verifyingTicket;
    private int _ticketRevision;
    private string _ticketValidationMessage="Ingrese el identificador completo y pulse Validar ticket.";
    public bool IsAdministrator {get;}
    public ObservableCollection<TemporaryAccessItem> Accesses {get;}=[];
    public ObservableCollection<TemporaryAccessAction> Actions {get;}=[];
    public IEnumerable<TemporaryAccessItem> FilteredAccesses=>Accesses.Where(x=>Filter.Length==0||$"{x.Principal} {x.Server} {x.Resource} {x.StateDisplay}".Contains(Filter,StringComparison.OrdinalIgnoreCase));
    public string Filter {get=>_filter;set{if(Set(ref _filter,value))Raise(nameof(FilteredAccesses));}}
    public string Status {get=>_status;private set=>Set(ref _status,value);}
    public bool IsBusy {get=>_busy;private set{if(Set(ref _busy,value))RefreshCommands();}}
    public TemporaryAccessItem? Selected {get=>_selected;set{Set(ref _selected,value);RefreshCommands();}}
    public TemporaryAccessAction? SelectedAction {get=>_selectedAction;set{Set(ref _selectedAction,value);RefreshCommands();}}
    public string Ticket
    {
        get=>_ticket;
        set
        {
            var ticket=(value??"").TrimStart().ToUpperInvariant();
            if(ticket.Length>50)ticket=ticket[..50];
            if(!Set(ref _ticket,ticket))return;
            _ticketRevision++;_verifiedTicket=null;Reason="";
            TicketValidationMessage=string.IsNullOrWhiteSpace(ticket)?"Ingrese el identificador completo y pulse Validar ticket.":"El ticket todavía no ha sido validado.";
            RaiseTicketState();
        }
    }
    public string Reason {get=>_reason;private set{if(Set(ref _reason,value))RefreshCommands();}}
    public bool IsTicketValid=>_verifiedTicket is not null&&_verifiedTicket.Number.Equals(Ticket.Trim(),StringComparison.OrdinalIgnoreCase);
    public string VerifiedTicketSummary=>_verifiedTicket?.Summary??"";
    public string TicketValidationMessage {get=>_ticketValidationMessage;private set=>Set(ref _ticketValidationMessage,value);}
    public DateTime? ExpiryDate {get=>_expiryDate;set=>Set(ref _expiryDate,value);}
    public string ExpiryTime {get=>_expiryTime;set=>Set(ref _expiryTime,value);}
    public AsyncCommand RefreshCommand {get;}
    public AsyncCommand ExtendCommand {get;}
    public AsyncCommand CloseCommand {get;}
    public AsyncCommand ApproveCommand {get;}
    public AsyncCommand RejectCommand {get;}
    public AsyncCommand ExecuteCommand {get;}
    public AsyncCommand VerifyTicketCommand {get;}
    public TemporaryAccessViewModel(ISecurityMonitoringStore store,SessionContext session,
        Func<TemporaryAccessItem,CancellationToken,Task<string>> close,Func<string,bool>? confirm=null)
    {
        _store=store;IsAdministrator=session.IsAdministrator;_close=close;
        _confirm=confirm??(text=>MessageBox.Show(text,"Usuarios temporales",MessageBoxButton.YesNo,MessageBoxImage.Warning)==MessageBoxResult.Yes);
        RefreshCommand=new(LoadAsync,()=>!IsBusy&&!_disposed);
        VerifyTicketCommand=new(VerifyTicketAsync,CanVerifyTicket);
        ExtendCommand=new(()=>SubmitAsync("EXTEND"),CanAct);CloseCommand=new(()=>SubmitAsync("CLOSE"),CanAct);
        ApproveCommand=new(()=>ReviewAsync(true),()=>CanReview("PENDING"));RejectCommand=new(()=>ReviewAsync(false),()=>CanReview("PENDING")||CanReview("APPROVED"));
        ExecuteCommand=new(ExecuteAsync,()=>CanReview("APPROVED"));
    }
    private bool CanAct()=>!_disposed&&!IsBusy&&!_verifyingTicket&&IsAdministrator&&IsTicketValid&&Reason.Trim().Length>=10&&Selected is {State:not "CLOSED"};
    private bool CanVerifyTicket()=>!_disposed&&!IsBusy&&!_verifyingTicket&&IsAdministrator&&!string.IsNullOrWhiteSpace(Ticket);
    private void RaiseTicketState(){Raise(nameof(IsTicketValid));Raise(nameof(VerifiedTicketSummary));RefreshCommands();}
    public async Task VerifyTicketAsync()
    {
        if(!CanVerifyTicket())return;
        var requested=Ticket.Trim();var revision=_ticketRevision;
        _verifyingTicket=true;_verifiedTicket=null;Reason="";
        TicketValidationMessage="Consultando el ticket en adminDB...";RaiseTicketState();
        try
        {
            var ticket=await _store.VerifyExternalTicketAsync(requested,_lifetime.Token);
            if(_disposed||revision!=_ticketRevision)return;
            if(ticket is null)TicketValidationMessage="No existe un ticket activo con ese identificador. Revise el dato o su estado.";
            else if(!ticket.Number.Equals(requested,StringComparison.OrdinalIgnoreCase))
                TicketValidationMessage="adminDB devolvió un identificador distinto al consultado; el ticket no se habilitó.";
            else
            {
                _verifiedTicket=ticket;
                Reason=string.IsNullOrWhiteSpace(ticket.Description)?ticket.Subject:ticket.Description;
                TicketValidationMessage=$"✓ Ticket activo verificado: {ticket.Number}";
            }
        }
        catch(OperationCanceledException){}
        catch(Exception e){if(!_disposed&&revision==_ticketRevision)TicketValidationMessage=$"No fue posible validar el ticket en adminDB: {e.Message}";}
        finally{_verifyingTicket=false;RaiseTicketState();}
    }
    public void AttachMonitor(SecurityMonitoringService monitor){_monitor=monitor;monitor.Changed+=OnMonitoringChanged;}
    private void OnMonitoringChanged(){if(!_disposed&&!IsBusy)_ = LoadAsync();}
    private bool CanReview(string status)=>!_disposed&&!IsBusy&&IsAdministrator&&SelectedAction?.Status==status;
    private void RefreshCommands(){VerifyTicketCommand?.Refresh();RefreshCommand?.Refresh();ExtendCommand?.Refresh();CloseCommand?.Refresh();ApproveCommand?.Refresh();RejectCommand?.Refresh();ExecuteCommand?.Refresh();}
    public async Task LoadAsync()
    {
        if(IsBusy||_disposed)return;IsBusy=true;
        try{await ReloadAsync();Status="Los accesos vencidos se mantienen operativos hasta completar una acción manual. Se muestran hasta 5000 vigencias y 1000 acciones.";}
        catch(OperationCanceledException){}catch(Exception e){if(!_disposed)Status=e.Message;}finally{IsBusy=false;}
    }
    private async Task ReloadAsync()
    {
        var selected=Selected?.Id;var action=SelectedAction?.Id;
        await _store.RefreshSecuritySummaryAsync(_lifetime.Token);
        var accesses=await _store.GetTemporaryAccessesAsync(_lifetime.Token);
        var actions=await _store.GetTemporaryActionsAsync(_lifetime.Token);
        _lifetime.Token.ThrowIfCancellationRequested();if(_disposed)return;
        Accesses.Clear();foreach(var item in accesses)Accesses.Add(item);
        Actions.Clear();foreach(var item in actions)Actions.Add(item);
        Selected=Accesses.FirstOrDefault(x=>x.Id==selected);SelectedAction=Actions.FirstOrDefault(x=>x.Id==action);Raise(nameof(FilteredAccesses));
    }
    private async Task SubmitAsync(string action)
    {
        if(!CanAct())return;var selected=Selected!;IsBusy=true;
        try
        {
            if(Ticket.Trim().Length==0||Reason.Trim().Length<10)throw new InvalidOperationException("Ingrese un ticket activo y un motivo de al menos 10 caracteres.");
            var expiry=action=="EXTEND"?SecurityMonitoringRules.ParseDateTime(ExpiryDate,ExpiryTime):(DateTime?)null;
            if(action=="EXTEND"&&(expiry<=SqlAccessAdmin.Infrastructure.AppTime.Now||expiry<=selected.ExpiresAt))throw new InvalidOperationException("La extensión debe superar la fecha vigente y el instante actual.");
            var description=action=="EXTEND"?$"Extender hasta {SecurityMonitoringRules.Display(expiry!.Value)}":selected.CloseDescription;
            if(!_confirm($"Solicitar para {selected.Principal}: {description}.\nSe enviará a revisión; el acceso todavía no cambia."))return;
            await _store.RequestTemporaryActionAsync(selected,action,expiry,Ticket,Reason,_lifetime.Token);
            await ReloadAsync();Status="Acción enviada a revisión. Confirme y ejecute la fila de la cola.";
        }
        catch(OperationCanceledException){}catch(Exception e){if(!_disposed)Status=e.Message;}finally{IsBusy=false;}
    }
    private async Task ReviewAsync(bool approve)
    {
        if(!CanReview("PENDING")&&(approve||!CanReview("APPROVED")))return;var action=SelectedAction!;IsBusy=true;
        try{await _store.ReviewTemporaryActionAsync(action.Id,approve,_lifetime.Token);await ReloadAsync();Status=approve?"Acción aprobada; falta ejecutarla.":"Acción rechazada; las alertas permanecen.";}
        catch(OperationCanceledException){}catch(Exception e){if(!_disposed)Status=e.Message;}finally{IsBusy=false;}
    }
    public async Task ExecuteAsync()
    {
        if(!CanReview("APPROVED"))return;var action=SelectedAction!;
        if(!_confirm($"Ejecutar acción #{action.Id}: {action.ActionDisplay}.\n{action.TargetDisplay}\nVigencia nueva: {action.NewExpiresDisplay}\nTicket: {action.Ticket}\nMotivo: {action.Reason}\nUn cierre puede modificar el acceso SQL."))return;
        IsBusy=true;var claimed=false;var completed=false;
        try
        {
            var access=await _store.BeginTemporaryActionAsync(action.Id,_lifetime.Token);claimed=true;
            var detail=action.Action=="EXTEND"?"Vigencia extendida mediante revisión administrativa.":await _close(access,_lifetime.Token);
            // Al confirmar un cambio remoto, persistir el resultado con un token independiente.
            await _store.CompleteTemporaryActionAsync(action.Id,true,detail,CancellationToken.None);completed=true;
            await ReloadAsync();Status="Acción completada. La alerta de esta revisión quedó resuelta.";
        }
        catch(Exception e)
        {
            if(claimed&&!completed)
            {
                try{await _store.CompleteTemporaryActionAsync(action.Id,false,"No se confirmó el cierre/extensión. Revisar destino antes de reintentar. "+e.Message,CancellationToken.None);}
                catch{if(!_disposed)Status="Resultado pendiente de conciliación: no se pudo registrar el estado. La alerta continúa activa.";return;}
            }
            if(!_disposed)Status=e is OperationCanceledException?"Acción cancelada; revise su resultado antes de repetirla.":e.Message;
        }
        finally{IsBusy=false;}
    }
    public void Dispose(){if(_disposed)return;_disposed=true;_lifetime.Cancel();if(_monitor is not null)_monitor.Changed-=OnMonitoringChanged;RefreshCommands();}
}
