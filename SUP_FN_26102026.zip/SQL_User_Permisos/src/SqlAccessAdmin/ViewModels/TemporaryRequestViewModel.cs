using SqlAccessAdmin.Models;

namespace SqlAccessAdmin.ViewModels;

public sealed partial class AccessViewModel
{
    private bool _isTemporaryAccess;
    private DateTime? _temporaryExpiryDate=SqlAccessAdmin.Infrastructure.AppTime.Now.Date.AddDays(1);
    private string _temporaryExpiryTime="18:00:00";
    public bool IsTemporaryAccess {get=>_isTemporaryAccess;set=>Set(ref _isTemporaryAccess,value);}
    public DateTime? TemporaryExpiryDate {get=>_temporaryExpiryDate;set=>Set(ref _temporaryExpiryDate,value);}
    public string TemporaryExpiryTime {get=>_temporaryExpiryTime;set=>Set(ref _temporaryExpiryTime,value);}
    private DateTime? GetTemporaryExpiry()
    {
        if(!IsTemporaryAccess)return null;
        var value=SecurityMonitoringRules.ParseDateTime(TemporaryExpiryDate,TemporaryExpiryTime);
        if(value<=SqlAccessAdmin.Infrastructure.AppTime.Now)throw new InvalidOperationException("La vigencia temporal debe finalizar en el futuro.");
        return value;
    }
}
