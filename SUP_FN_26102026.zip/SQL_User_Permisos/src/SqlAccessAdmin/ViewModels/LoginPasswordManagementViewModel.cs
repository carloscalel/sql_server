using System.Windows;
using SqlAccessAdmin.Infrastructure;
using SqlAccessAdmin.Models;
using SqlAccessAdmin.Views;

namespace SqlAccessAdmin.ViewModels;

public sealed partial class AccessViewModel
{
    private bool _isChangingManagedLoginPassword;
    private AsyncCommand? _changeManagedLoginPasswordCommand;
    public AsyncCommand ChangeManagedLoginPasswordCommand=>_changeManagedLoginPasswordCommand??=new(
        SubmitManagedLoginPasswordChangeAsync,()=>CanRequestManagedLoginPasswordChange);
    public bool IsChangingManagedLoginPassword=>_isChangingManagedLoginPassword;
    public bool CanRequestManagedLoginPasswordChange=>CanCreateRequests&&IsExistingAccessOperation
        &&SelectedWorkingServer is not null&&SelectedServerLogin?.Type=="SQL_LOGIN"
        &&Same(TargetPrincipal,SelectedServerLogin.Name)&&!IsInternalOrServicePrincipal(TargetPrincipal)
        &&IsExternalTicketValid&&!IsVerifyingExternalTicket&&Justification.Trim().Length>=10&&!_requestSubmitted
        &&!_isStartingAccessManagement&&!_isSubmittingLoginStateChange&&!_isSubmittingAccessRequest&&!_isChangingManagedLoginPassword
        &&Operations.Any(x=>x.Enabled&&x.Code=="CHANGE_LOGIN_PASSWORD");
    public string ManagedLoginPasswordHint=>SelectedServerLogin?.Type!="SQL_LOGIN"
        ?"El cambio de contraseña solo está disponible para logins SQL."
        :!IsExternalTicketValid?"Valide primero el ticket para cambiar la contraseña."
        :!Operations.Any(x=>x.Enabled&&x.Code=="CHANGE_LOGIN_PASSWORD")
            ?"La operación no está habilitada. El DBA debe revisar la política y aplicar el script 32."
            :"Cambiar contraseña requiere confirmación y ejecución. Puede exigir el cambio en el próximo inicio de sesión.";
    public string PasswordCardTitle=>IsChangingManagedLoginPassword?"🔑  Nueva contraseña":"🔑  Contraseña temporal";
    public string PasswordCardHelp=>IsChangingManagedLoginPassword
        ?"Defina la nueva contraseña y elija si el usuario debe cambiarla en su próximo inicio de sesión."
        :"Defina una contraseña inicial segura y elija si debe cambiarse en el primer inicio de sesión.";

    private async Task SubmitManagedLoginPasswordChangeAsync()
    {
        if(!CanRequestManagedLoginPasswordChange)return;
        var server=SelectedWorkingServer!;var login=SelectedServerLogin!;
        var ticket=ExternalTicketNumber;var justification=Justification.Trim();
        _isChangingManagedLoginPassword=true;
        ClearTemporaryPassword();SuggestedPasswordLengthText="20";
        PasswordPolicyEnabled=true;PasswordExpirationEnabled=true;MustChangePassword=true;
        RefreshManagedLoginState();RaisePasswordValidationState();
        Raise(nameof(IsChangingManagedLoginPassword));Raise(nameof(PasswordCardTitle));Raise(nameof(PasswordCardHelp));
        try
        {
            var dialog=new LoginPasswordChangeWindow {DataContext=this,Owner=Application.Current.MainWindow};
            if(dialog.ShowDialog()!=true){Status="Cambio de contraseña cancelado. No se creó ninguna solicitud.";return;}
            EnsureCurrentContext();
            if(!IsTemporaryPasswordValid)throw new InvalidOperationException(TemporaryPasswordValidationMessage);
            var password=TemporaryPassword;var policy=PasswordPolicyEnabled;var expiration=PasswordExpirationEnabled;var mustChange=MustChangePassword;
            var draft=new AccessRequestDraft("CHANGE_LOGIN_PASSWORD",login.Name,null,"SQL",null,null,null,null,null,ticket,justification);
            IReadOnlyList<DatabaseItem> targets=[new(){ServerId=server.Id,Server=server.Name,Name="master",IsSelected=true}];
            Status=$"Validando la solicitud de cambio de contraseña de {login.Name}…";
            await _direct.ValidatePasswordChangeLoginAsync(server.Id,login.Name);
            EnsureCurrentContext();
            var duplicate=await FindActiveDuplicateAsync(draft,targets,[]);
            if(duplicate is not null)throw new InvalidOperationException($"Ya existe la solicitud activa #{duplicate} para cambiar esta contraseña. Revísela en 'Confirmar y ejecutar'.");
            var decision=await _db.PreviewRequestTargetsAsync(draft,targets);
            if(!decision.Allowed)throw new InvalidOperationException(decision.Reason);
            var secret=await ProtectTemporaryPasswordAsync();
            EnsureCurrentContext();
            if(password!=TemporaryPassword||policy!=PasswordPolicyEnabled||expiration!=PasswordExpirationEnabled||mustChange!=MustChangePassword)
                throw new InvalidOperationException("La configuración de contraseña cambió. Vuelva a solicitar el cambio.");
            var id=await _db.CreateRequestAsync(draft,targets,[],secret);
            if(ReferenceEquals(SelectedWorkingServer,server)&&ReferenceEquals(SelectedServerLogin,login)&&IsExistingAccessOperation)
            {_requestSubmitted=true;IsManagingAccess=false;SelectedAccessStep=3;}
            Status=$"Solicitud #{id} para cambiar la contraseña de {login.Name} enviada. Confírmela y ejecútela en 'Confirmar y ejecutar'.";
        }
        catch(Exception error){Status=error.Message;}
        finally
        {
            ClearTemporaryPassword();_isChangingManagedLoginPassword=false;
            Raise(nameof(IsChangingManagedLoginPassword));Raise(nameof(PasswordCardTitle));Raise(nameof(PasswordCardHelp));
            RaisePasswordValidationState();RefreshManagedLoginState();SubmitCommand.Refresh();
        }

        void EnsureCurrentContext()
        {
            if(!CanCreateRequests||!ReferenceEquals(SelectedWorkingServer,server)||!ReferenceEquals(SelectedServerLogin,login)
                ||!IsExistingAccessOperation||!IsExternalTicketValid||IsVerifyingExternalTicket||ExternalTicketNumber!=ticket
                ||Justification.Trim()!=justification||!Same(TargetPrincipal,login.Name))
                throw new InvalidOperationException("El usuario, servidor o ticket cambió. Revise los datos y vuelva a solicitar el cambio.");
        }
    }
}
