using System.Collections.ObjectModel;
using SqlAccessAdmin.Data;
using SqlAccessAdmin.Infrastructure;
using SqlAccessAdmin.Models;
using SqlAccessAdmin.Views;

namespace SqlAccessAdmin.ViewModels;

public sealed class UsersViewModel : BindableBase
{
    private readonly IAuthorizedUserStore _store;
    private readonly SessionContext _session;
    private readonly Func<string,bool>? _confirm;
    private AuthorizedUser? _selected;
    private AuthorizedPrincipalOption? _selectedPrincipal;
    private string? _catalogError;
    private string _principal="",_type="WINDOWS",_notes="",_status="Seleccione un usuario o agregue uno nuevo.";
    private AppRole _role=AppRole.Operator;
    private bool _active=true,_busy,_editing,_authorizationValid=true;
    public ObservableCollection<AuthorizedUser> Users {get;}=[];
    public ObservableCollection<AuthorizedPrincipalOption> AvailablePrincipals {get;}=[];
    public bool IsNewUser=>_selected is null;
    public bool IsExistingUser=>!IsNewUser;
    public bool HasEditor=>_editing;
    public bool IsEditorEmpty=>!HasEditor;
    public bool IsAdministrator=>_authorizationValid&&_session.IsAdministrator;
    public bool IsBusy {get=>_busy;private set{if(Set(ref _busy,value))RefreshState();}}
    public bool CanEdit=>IsAdministrator&&!IsBusy&&_editing;
    public bool CanEditIdentity=>CanEdit&&IsNewUser&&AvailablePrincipals.Count>0;
    public bool HasChanges=>_editing&&(_selected is null||Principal!=_selected.Principal||PrincipalType!=_selected.Type||Role!=_selected.Role||Active!=_selected.Active||Notes!=_selected.Notes);
    public string EditorTitle=>!HasEditor?"Usuarios autorizados":_selected is null?"Agregar usuario autorizado":"Modificar usuario autorizado";
    public string SessionSummary=>$"Sesión: {_session.Principal} · {_session.RoleDisplay}";
    public string Status {get=>_status;private set=>Set(ref _status,value);}
    public AuthorizedUser? SelectedUser
    {
        get=>_selected;
        set
        {
            if(Equals(_selected,value))return;
            if(IsBusy||!ConfirmDiscard()){Raise();return;}
            SetEditor(value,value is not null);
        }
    }
    public string Principal=>_principal;
    public string PrincipalType=>_type;
    public AuthorizedPrincipalOption? SelectedPrincipal
    {
        get=>_selectedPrincipal;
        set
        {
            if(!CanEditIdentity||(value is not null&&!AvailablePrincipals.Contains(value)))return;
            if(!Set(ref _selectedPrincipal,value))return;
            _principal=value?.Principal??"";_type=value?.Type??"";
            Raise(nameof(Principal));Raise(nameof(PrincipalType));RefreshState();
        }
    }
    public AppRole Role {get=>_role;set{if(CanEdit&&Set(ref _role,value))RefreshState();}}
    public bool HasAdministratorRole {get=>Role.HasFlag(AppRole.Administrator);set=>SetRole(AppRole.Administrator,value);}
    public bool HasOperatorRole {get=>Role.HasFlag(AppRole.Operator);set=>SetRole(AppRole.Operator,value);}
    public bool HasApproverExecutorRole {get=>Role.HasFlag(AppRole.ApproverExecutor);set=>SetRole(AppRole.ApproverExecutor,value);}
    public bool HasAuditorRole {get=>Role.HasFlag(AppRole.Auditor);set=>SetRole(AppRole.Auditor,value);}
    private void SetRole(AppRole role,bool selected)=>Role=selected?Role|role:Role&~role;
    public bool Active {get=>_active;set{if(CanEdit&&Set(ref _active,value))RefreshState();}}
    public string Notes {get=>_notes;set{if(CanEdit&&Set(ref _notes,value))RefreshState();}}
    public AsyncCommand RefreshCommand {get;}
    public RelayCommand AddCommand {get;}
    public AsyncCommand SaveCommand {get;}
    public AsyncCommand RevokeCommand {get;}
    public RelayCommand CancelCommand {get;}

    public UsersViewModel(IAuthorizedUserStore store,SessionContext session,Func<string,bool>? confirm=null)
    {
        _store=store;_session=session;
        _confirm=confirm;
        RefreshCommand=new(async()=>{if(!IsBusy&&ConfirmDiscard())await LoadAsync();},()=>!IsBusy);
        AddCommand=new(()=>{if(IsAdministrator&&!IsBusy&&ConfirmDiscard()){SetEditor(null,true);Status=_catalogError??(AvailablePrincipals.Count==0?"No hay cuentas disponibles. Actualice después de que el DBA registre una cuenta en la instancia de adminDB. Para reactivar un usuario, selecciónelo en la tabla.":"Seleccione la cuenta a la que desea dar acceso a la aplicación.");}},()=>IsAdministrator&&!IsBusy);
        SaveCommand=new(()=>SaveAsync(false),()=>CanEdit&&HasChanges&&(!IsNewUser||SelectedPrincipal is not null));
        RevokeCommand=new(()=>SaveAsync(true),()=>IsAdministrator&&!IsBusy&&_selected is {Active:true}&&!IsCurrentUser(_selected.Principal));
        CancelCommand=new(()=>{if(!IsBusy&&ConfirmDiscard())SetEditor(_selected,_selected is not null);},()=>!IsBusy&&HasChanges);
        _=LoadAsync();
    }
    private bool IsCurrentUser(string principal)=>string.Equals(principal,_session.Principal,StringComparison.OrdinalIgnoreCase);
    private bool Confirm(string message,string heading,string acceptLabel)=>_confirm?.Invoke(message)??ConfirmationWindow.Confirm(heading,message,acceptLabel);
    private bool ConfirmDiscard()=>!HasChanges||Confirm("Hay cambios de usuarios sin guardar. Si continúa, se perderán los cambios del formulario.","Descartar cambios pendientes","Descartar cambios");
    public bool ConfirmLeave()
    {
        if(IsBusy){Status="Espere a que termine la operación antes de salir de usuarios autorizados.";return false;}
        return ConfirmDiscard();
    }
    private void SetEditor(AuthorizedUser? user,bool editing)
    {
        _selected=user;_selectedPrincipal=null;_editing=editing;_principal=user?.Principal??"";_type=user?.Type??"";
        _role=user?.Role??(editing?AppRole.Operator:AppRole.None);_active=user?.Active??editing;_notes=user?.Notes??"";
        foreach(var property in new[]{nameof(SelectedUser),nameof(SelectedPrincipal),nameof(Principal),nameof(PrincipalType),nameof(IsNewUser),nameof(IsExistingUser),nameof(HasEditor),nameof(IsEditorEmpty),nameof(Role),nameof(Active),nameof(Notes),nameof(EditorTitle)})Raise(property);
        RefreshState();
    }
    private void RefreshState()
    {
        foreach(var property in new[]{nameof(IsAdministrator),nameof(CanEdit),nameof(CanEditIdentity),nameof(HasChanges),nameof(HasAdministratorRole),nameof(HasOperatorRole),nameof(HasApproverExecutorRole),nameof(HasAuditorRole)})Raise(property);
        AddCommand.Refresh();SaveCommand.Refresh();RevokeCommand.Refresh();CancelCommand.Refresh();RefreshCommand.Refresh();
    }
    private async Task CheckAdministratorAsync()
    {
        if(!IsAdministrator)throw new UnauthorizedAccessException("Solo un administrador activo puede agregar usuarios, modificar roles o quitar acceso.");
        var current=await _store.LoginAsync();
        if(!current.IsAdministrator||current.Role!=_session.Role||!IsCurrentUser(current.Principal))
            throw new UnauthorizedAccessException("Su acceso o rol cambió. Cierre la aplicación e inicie sesión nuevamente.");
    }
    private async Task LoadAsync()
    {
        if(IsBusy)return;
        IsBusy=true;
        try
        {
            await CheckAdministratorAsync();
            var users=await _store.GetUsersAsync();
            Users.Clear();foreach(var user in users)Users.Add(user);
            SetEditor(null,false);
            Status=$"{Users.Count} usuario(s) registrado(s). Solo los registros activos pueden ingresar.";
            await LoadAvailablePrincipalsAsync();
        }
        catch(UnauthorizedAccessException error){_authorizationValid=false;SetEditor(null,false);Status=error.Message;}
        catch(Exception error){Status=$"No fue posible cargar los usuarios: {error.Message}";}
        finally{IsBusy=false;}
    }
    private async Task LoadAvailablePrincipalsAsync()
    {
        AvailablePrincipals.Clear();_catalogError=null;
        try
        {
            var principals=await _store.GetAvailablePrincipalsAsync();
            foreach(var principal in principals.Where(x=>x.Type is "WINDOWS" or "SQL_LOGIN")
                .Where(x=>!Users.Any(user=>string.Equals(user.Principal,x.Principal,StringComparison.OrdinalIgnoreCase)))
                .OrderBy(x=>x.Principal,StringComparer.OrdinalIgnoreCase))AvailablePrincipals.Add(principal);
        }
        catch(UnauthorizedAccessException){throw;}
        catch(Exception error){_catalogError=$"No fue posible cargar las cuentas disponibles: {error.Message}";Status=_catalogError;}
        RefreshState();
    }
    private async Task SaveAsync(bool revoke)
    {
        if(IsBusy)return;
        if(!IsAdministrator){Status="Solo un administrador activo puede modificar usuarios autorizados.";return;}
        IsBusy=true;
        try
        {
            await CheckAdministratorAsync();
            if(revoke&&(_selected is null||!_selected.Active))throw new InvalidOperationException("Seleccione un usuario con acceso activo.");
            if(!revoke&&!_editing)throw new InvalidOperationException("Seleccione un usuario o agregue uno nuevo.");
            if(revoke&&HasChanges&&!Confirm("Se descartarán los cambios del formulario y se quitará el acceso del usuario seleccionado.","Quitar acceso y descartar cambios","Continuar"))return;
            var draft=revoke
                ?new AuthorizedUserEditData(_selected!.Id,_selected.Principal,_selected.Type,_selected.Role,false,_selected.Notes,_selected.RowVersion.ToArray())
                :new AuthorizedUserEditData(_selected?.Id,Principal.Trim(),PrincipalType,Role,Active,Notes.Trim(),_selected?.RowVersion.ToArray()??[]);
            ValidateDraft(draft);
            if(!draft.Id.HasValue)
            {
                var currentPrincipals=await _store.GetAvailablePrincipalsAsync();
                if(!currentPrincipals.Any(x=>x.Principal==draft.Principal&&x.Type==draft.Type))
                    throw new InvalidOperationException("La cuenta seleccionada ya no está disponible. Actualice el listado y seleccione una cuenta existente.");
            }
            var action=revoke||!draft.Active?"Quitar el acceso a la aplicación":draft.Id.HasValue?"Modificar usuario y rol":"Agregar usuario autorizado";
            if(!Confirm($"Principal: {draft.Principal}\nRoles: {AppRoleCatalog.Display(draft.Role)}\nAcceso: {(draft.Active?"Activo":"Inactivo")}\n\n{(draft.Active?"El usuario tendrá acceso con los roles indicados.":"El usuario no podrá ingresar a la aplicación. Se conservarán su registro y auditoría.")}",action,revoke||!draft.Active?"Quitar acceso":"Guardar cambios"))return;
            await _store.SaveAuthorizedUserAsync(draft);
            SetEditor(null,false);
            Status=$"Cambio guardado para {draft.Principal}.";
            try
            {
                var users=await _store.GetUsersAsync();
                Users.Clear();foreach(var user in users)Users.Add(user);
                await LoadAvailablePrincipalsAsync();
            }
            catch(UnauthorizedAccessException error){_authorizationValid=false;Status=$"Cambio guardado. {error.Message}";}
            catch(Exception error){Status=$"Cambio guardado. No fue posible actualizar el listado: {error.Message}";}
        }
        catch(UnauthorizedAccessException error){_authorizationValid=false;Status=error.Message;}
        catch(Exception error){Status=error.Message;}
        finally{IsBusy=false;}
    }
    private void ValidateDraft(AuthorizedUserEditData draft)
    {
        if(!draft.Id.HasValue&&(SelectedPrincipal is null||!AvailablePrincipals.Contains(SelectedPrincipal)||SelectedPrincipal.Principal!=draft.Principal||SelectedPrincipal.Type!=draft.Type))
            throw new InvalidOperationException("Seleccione una cuenta existente del listado.");
        if(string.IsNullOrWhiteSpace(draft.Principal)||draft.Principal.Length>256)throw new InvalidOperationException("Seleccione un principal de hasta 256 caracteres.");
        if(!AppRoleCatalog.IsValid(draft.Role))throw new InvalidOperationException("Seleccione al menos un rol de aplicación válido.");
        if(draft.Notes.Length>500)throw new InvalidOperationException("Las notas admiten hasta 500 caracteres.");
        if(draft.Type is not ("WINDOWS" or "SQL_LOGIN" or "BOOTSTRAP")||(!draft.Id.HasValue&&draft.Type=="BOOTSTRAP"))
            throw new InvalidOperationException("Los nuevos usuarios deben ser WINDOWS o SQL_LOGIN. BOOTSTRAP solo se conserva en registros existentes.");
        if(!draft.Id.HasValue&&draft.Type=="WINDOWS"&&(draft.Principal.Split('\\') is not [var domain,var user]||string.IsNullOrWhiteSpace(domain)||string.IsNullOrWhiteSpace(user)))
            throw new InvalidOperationException(@"Para Windows indique DOMINIO\usuario o EQUIPO\usuario.");
        if(Users.Any(x=>x.Id!=draft.Id&&string.Equals(x.Principal,draft.Principal,StringComparison.OrdinalIgnoreCase)))
            throw new InvalidOperationException("Ese principal ya está registrado. Selecciónelo para modificarlo o reactivar su acceso.");
        if(draft.Id.HasValue&&draft.RowVersion.Length!=8)throw new InvalidOperationException("Actualice el listado. El registro no tiene una versión válida; verifique la instalación del script 29.");
        if(IsCurrentUser(draft.Principal)&&(!draft.Active||!draft.Role.HasFlag(AppRole.Administrator)))
            throw new InvalidOperationException("No puede quitar su propio acceso ni reducir su propio rol. Solicite el cambio a otro administrador.");
    }
}
