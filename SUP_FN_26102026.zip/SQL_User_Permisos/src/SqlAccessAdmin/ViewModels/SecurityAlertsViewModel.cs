using System.Collections.ObjectModel;
using SqlAccessAdmin.Infrastructure;
using SqlAccessAdmin.Models;
using SqlAccessAdmin.Views;

namespace SqlAccessAdmin.ViewModels;

public enum SecurityAlertFilter { All, Expired, Password }

public sealed class SecurityAlertsViewModel : BindableBase,IDisposable
{
    private readonly ISecurityAlertsStore _store;
    private readonly Func<Task>? _onReviewed;
    private readonly Func<string,bool> _confirm;
    private readonly CancellationTokenSource _lifetime=new();
    private bool _busy,_disposed;
    private string _reason="",_status="",_search="";
    private SecurityAlertFilter _filter;
    private SecurityAlertItem? _selected;
    public ObservableCollection<SecurityAlertItem> Alerts {get;}=[];
    public IEnumerable<SecurityAlertItem> FilteredAlerts=>Alerts.Where(x=>
        (Filter==SecurityAlertFilter.All||x.Type==(Filter==SecurityAlertFilter.Expired?"TEMPORARY_EXPIRED":"PASSWORD_FREQUENCY"))
        &&(Search.Length==0||$"{x.Principal} {x.Server} {x.Detail}".Contains(Search,StringComparison.OrdinalIgnoreCase)));
    public SecurityAlertFilter Filter {get=>_filter;private set{if(Set(ref _filter,value))OnFilterChanged();}}
    public string Search {get=>_search;set{if(Set(ref _search,value))OnFilterChanged();}}
    public bool IsAll=>Filter==SecurityAlertFilter.All;
    public bool IsExpired=>Filter==SecurityAlertFilter.Expired;
    public bool IsPassword=>Filter==SecurityAlertFilter.Password;
    public string CountDisplay=>$"{FilteredAlerts.Count()} alertas visibles · máximo 50 alertas activas recientes";
    public bool IsBusy {get=>_busy;private set{if(Set(ref _busy,value))RefreshCommands();}}
    public bool HasSelection=>Selected is not null;
    public bool IsExpirySelection=>Selected?.Type=="TEMPORARY_EXPIRED";
    public bool CanReviewPasswordAlerts {get;}
    public bool CanViewPasswordHistory {get;}
    public bool ShowReview=>Selected?.Type=="PASSWORD_FREQUENCY"&&CanReviewPasswordAlerts;
    public bool ShowReadOnly=>Selected?.Type=="PASSWORD_FREQUENCY"&&!CanReviewPasswordAlerts;
    public SecurityAlertItem? Selected
    {
        get=>_selected;
        set
        {
            if(IsBusy)return;
            if(!Set(ref _selected,value))return;
            Reason="";Status="";RaiseSelection();
        }
    }
    public string Reason {get=>_reason;set{if(Set(ref _reason,value))RefreshCommands();}}
    public string Status {get=>_status;private set=>Set(ref _status,value);}
    public string MonitoringStatus {get;}
    public AsyncCommand RefreshCommand {get;}
    public AsyncCommand ReviewCommand {get;}
    public RelayCommand AllCommand {get;}
    public RelayCommand ExpiredCommand {get;}
    public RelayCommand PasswordCommand {get;}
    public RelayCommand TemporaryAccessCommand {get;}
    public RelayCommand PasswordHistoryCommand {get;}
    public event Action<string>? NavigationRequested;

    public SecurityAlertsViewModel(ISecurityAlertsStore store,SessionContext session,
        SecurityAlertFilter filter=SecurityAlertFilter.All,Func<Task>? onReviewed=null,
        string monitoringStatus="",Func<string,bool>? confirm=null)
    {
        _store=store;_filter=filter;_onReviewed=onReviewed;MonitoringStatus=monitoringStatus;
        CanReviewPasswordAlerts=session.CanAudit;CanViewPasswordHistory=session.CanAudit;
        _confirm=confirm??(message=>ConfirmationWindow.Confirm("Registrar revisión",message,"Registrar revisión","ALERTAS DE SEGURIDAD"));
        RefreshCommand=new(LoadAsync,()=>!_disposed&&!IsBusy);
        ReviewCommand=new(ReviewAsync,CanReview);
        AllCommand=new(()=>Filter=SecurityAlertFilter.All,CanChangeFilter);
        ExpiredCommand=new(()=>Filter=SecurityAlertFilter.Expired,CanChangeFilter);
        PasswordCommand=new(()=>Filter=SecurityAlertFilter.Password,CanChangeFilter);
        TemporaryAccessCommand=new(()=>Navigate("TEMPORARY"),()=>CanChangeFilter()&&IsExpirySelection);
        PasswordHistoryCommand=new(()=>Navigate("PASSWORD_HISTORY"),()=>CanChangeFilter()&&CanViewPasswordHistory);
    }
    private bool CanChangeFilter()=>!_disposed&&!IsBusy;
    private bool CanReview()=>CanChangeFilter()&&ShowReview&&Reason.Trim().Length>=10&&Alerts.Any(x=>x.Id==Selected?.Id);
    private void Navigate(string target){if(CanChangeFilter())NavigationRequested?.Invoke(target);}
    private void OnFilterChanged()
    {
        if(Selected is not null&&!FilteredAlerts.Any(x=>x.Id==Selected.Id))Selected=null;
        Raise(nameof(FilteredAlerts));Raise(nameof(CountDisplay));Raise(nameof(IsAll));Raise(nameof(IsExpired));Raise(nameof(IsPassword));
    }
    private void RaiseSelection(){Raise(nameof(HasSelection));Raise(nameof(IsExpirySelection));Raise(nameof(ShowReview));Raise(nameof(ShowReadOnly));RefreshCommands();}
    private void RefreshCommands()
    {
        RefreshCommand?.Refresh();ReviewCommand?.Refresh();AllCommand?.Refresh();ExpiredCommand?.Refresh();PasswordCommand?.Refresh();TemporaryAccessCommand?.Refresh();PasswordHistoryCommand?.Refresh();
    }
    public async Task LoadAsync()
    {
        if(!CanChangeFilter())return;IsBusy=true;Status="Actualizando alertas…";
        try{await ReloadAsync();if(!_disposed)Status="";}
        catch(OperationCanceledException){}
        catch(Exception e){if(!_disposed)Status="No se pudieron actualizar las alertas: "+e.Message;}
        finally{IsBusy=false;}
    }
    private async Task ReloadAsync()
    {
        var alerts=await _store.GetActiveSecurityAlertsAsync(_lifetime.Token);
        _lifetime.Token.ThrowIfCancellationRequested();if(_disposed)return;
        var oldId=_selected?.Id;
        Alerts.Clear();foreach(var item in alerts)Alerts.Add(item);
        _selected=FilteredAlerts.FirstOrDefault(x=>x.Id==oldId);
        if(_selected is null)Reason="";
        Raise(nameof(Selected));RaiseSelection();Raise(nameof(FilteredAlerts));Raise(nameof(CountDisplay));
    }
    public async Task ReviewAsync()
    {
        if(!CanReview())return;
        var alert=Selected!;var reason=Reason.Trim();
        if(!_confirm($"Registrar la revisión de {alert.Principal} en {alert.Server}.\n\n{reason}\n\nEl historial y el contador se conservan. Un nuevo cambio puede generar otra alerta."))return;
        IsBusy=true;Status="Registrando la revisión. Espere a que finalice…";var recorded=false;
        try
        {
            await _store.ResolvePasswordAlertAsync(alert.Id,reason,_lifetime.Token);recorded=true;
            if(_disposed)return;
            Alerts.Remove(alert);_selected=null;Reason="";Raise(nameof(Selected));RaiseSelection();Raise(nameof(FilteredAlerts));Raise(nameof(CountDisplay));
            if(_onReviewed is not null)await _onReviewed();
            await ReloadAsync();
            if(!_disposed)Status="Revisión registrada. La alerta quedó atendida; el historial y el contador se conservan.";
        }
        catch(OperationCanceledException){}
        catch(Exception e){if(!_disposed)Status=(recorded?"Revisión registrada, pero no se pudo actualizar la lista: ":"No se pudo registrar la revisión: ")+e.Message;}
        finally{IsBusy=false;}
    }
    public void Dispose(){if(_disposed)return;_disposed=true;_lifetime.Cancel();NavigationRequested=null;RefreshCommands();}
}
