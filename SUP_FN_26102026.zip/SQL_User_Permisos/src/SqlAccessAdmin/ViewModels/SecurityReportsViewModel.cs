﻿using System.Collections.ObjectModel;
using System.Data;
using SqlAccessAdmin.Data;
using SqlAccessAdmin.Infrastructure;
using SqlAccessAdmin.Models;

namespace SqlAccessAdmin.ViewModels;

public sealed class SecurityReportsViewModel : BindableBase,IDisposable
{
    private readonly ISecurityMonitoringStore _store;
    private readonly Func<CancellationToken,Task<IReadOnlyList<ServerItem>>> _servers;
    private readonly IReportExportService _export;
    private readonly IReportSaveDialog _save;
    private CancellationTokenSource? _operation;
    private bool _disposed,_busy;
    private string _status="Seleccione un servidor y un período. Luego pulse Consultar para ver los cambios registrados.",_filter="";
    private DateTime? _from=SqlAccessAdmin.Infrastructure.AppTime.Now.Date.AddDays(-7),
        _to=SqlAccessAdmin.Infrastructure.AppTime.Now.Date;
    private ServerItem? _server;
    private DataTable? _raw;
    private DataView? _rows;
    private DateTimeOffset _queriedAt;
    private string _queryContext="";
    public SecurityReportKind Kind {get;private set;}
    public bool IsPasswordReport=>Kind!=SecurityReportKind.AccessChanges;
    public string Title=>Kind==SecurityReportKind.AccessChanges?"Cambios de accesos":"Cambios de contraseña";
    public string Description=>Kind==SecurityReportKind.AccessChanges
        ?"Consulte los cambios de acceso realizados desde la aplicación. Si un cambio aparece como «Externo», solo se conoce la última fecha detectada; no se puede confirmar quién lo hizo ni qué permisos cambió."
        :Kind==SecurityReportKind.PasswordHistory?"Revise los cambios de contraseña realizados desde la aplicación. Los cambios marcados como «Externos» muestran solo la última fecha detectada, sin identificar quién los hizo. El contador incluye únicamente los cambios confirmados por la aplicación."
        :"Compare cuántos cambios de contraseña se confirmaron desde la aplicación. No se cuentan las contraseñas iniciales ni los cambios realizados fuera de ella. Los días se calculan en hora de Guatemala.";
    public ObservableCollection<ServerItem> Servers {get;}=[];
    public ServerItem? SelectedServer {get=>_server;set{if(Set(ref _server,value))ClearResults();}}
    public DateTime? FromDate {get=>_from;set{if(Set(ref _from,value))ClearResults();}}
    public DateTime? ToDate {get=>_to;set{if(Set(ref _to,value))ClearResults();}}
    public string Filter {get=>_filter;set{if(Set(ref _filter,value))ApplyFilter();}}
    public string Status {get=>_status;private set=>Set(ref _status,value);}
    public bool IsBusy {get=>_busy;private set{if(Set(ref _busy,value))RefreshCommands();}}
    public DataView? Rows {get=>_rows;private set{Set(ref _rows,value);Raise(nameof(RowCount));RefreshCommands();}}
    public int RowCount=>Rows?.Count??0;
    public AsyncCommand QueryCommand {get;}
    public RelayCommand CancelCommand {get;}
    public AsyncCommand PdfCommand {get;}
    public AsyncCommand CsvCommand {get;}
    public AsyncCommand ExcelCommand {get;}
    public AsyncCommand ShowRankingCommand {get;}
    public AsyncCommand ShowHistoryCommand {get;}
    public SecurityReportsViewModel(ISecurityMonitoringStore store,SecurityReportKind kind,
        Func<CancellationToken,Task<IReadOnlyList<ServerItem>>> servers,IReportExportService? export=null,IReportSaveDialog? save=null)
    {
        _store=store;Kind=kind;_servers=servers;_export=export??new ReportExportService();_save=save??new ReportSaveDialog();
        QueryCommand=new(QueryAsync,()=>!IsBusy&&!_disposed);
        CancelCommand=new(()=>_operation?.Cancel(),()=>IsBusy);
        PdfCommand=new(()=>ExportAsync(ReportExportFormat.Pdf),CanExport);
        CsvCommand=new(()=>ExportAsync(ReportExportFormat.Csv),CanExport);
        ExcelCommand=new(()=>ExportAsync(ReportExportFormat.Excel),CanExport);
        ShowRankingCommand=new(()=>ChangePasswordModeAsync(SecurityReportKind.PasswordChanges),()=>IsPasswordReport&&!IsBusy&&!_disposed);
        ShowHistoryCommand=new(()=>ChangePasswordModeAsync(SecurityReportKind.PasswordHistory),()=>IsPasswordReport&&!IsBusy&&!_disposed);
    }
    public async Task InitializeAsync()
    {
        if(_disposed)return;
        var cts=new CancellationTokenSource();_operation=cts;IsBusy=true;
        try{var servers=await _servers(cts.Token);cts.Token.ThrowIfCancellationRequested();if(_disposed)return;
            Servers.Clear();Servers.Add(new(){Id=0,Name="Todos los servidores"});foreach(var server in servers)Servers.Add(server);SelectedServer=Servers[0];}
        catch(OperationCanceledException){}catch(Exception e){if(!_disposed)Status=e.Message;}
        finally{if(ReferenceEquals(_operation,cts))_operation=null;cts.Dispose();IsBusy=false;}
    }
    private bool CanExport()=>!_disposed&&!IsBusy&&Rows is not null;
    private void RefreshCommands(){QueryCommand?.Refresh();CancelCommand?.Refresh();PdfCommand?.Refresh();CsvCommand?.Refresh();ExcelCommand?.Refresh();ShowRankingCommand?.Refresh();ShowHistoryCommand?.Refresh();}
    private async Task ChangePasswordModeAsync(SecurityReportKind kind){Kind=kind;Raise(nameof(Kind));Raise(nameof(Description));ClearResults();await QueryAsync();}
    private void ClearResults(){_operation?.Cancel();_raw=null;Rows=null;}
    public async Task QueryAsync()
    {
        if(IsBusy||_disposed)return;
        var cts=new CancellationTokenSource();_operation=cts;IsBusy=true;_raw=null;Rows=null;
        try
        {
            if(FromDate is null||ToDate is null||ToDate<FromDate||ToDate.Value.Date-FromDate.Value.Date>TimeSpan.FromDays(366))
                throw new InvalidOperationException("Seleccione un período válido de hasta un año.");
            var from=SecurityMonitoringRules.ParseDateTime(FromDate,"00:00:00");
            var to=SecurityMonitoringRules.ParseDateTime(ToDate.Value.AddDays(1),"00:00:00");
            var server=SelectedServer?.Id is >0?SelectedServer.Id:(int?)null;
            var data=await _store.GetSecurityReportAsync(Kind,from,to,server,cts.Token);
            cts.Token.ThrowIfCancellationRequested();if(_disposed)return;
            _queryContext=$"{FromDate:yyyy-MM-dd} a {ToDate:yyyy-MM-dd} · Guatemala · {SelectedServer?.Name??"Todos"}";
            _queriedAt=SqlAccessAdmin.Infrastructure.AppTime.OffsetNow;_raw=data;ApplyFilter();
            Status=$"{data.Rows.Count} resultados encontrados. Máximo por consulta: {(Kind==SecurityReportKind.PasswordChanges?1000:5000)}; si se alcanza, seleccione un período más corto. Los cambios externos muestran solo la última fecha detectada, sin identificar quién los realizó.";
        }
        catch(OperationCanceledException){if(!_disposed)Status="Consulta cancelada; no se publicaron resultados.";}
        catch(Exception e){if(!_disposed)Status=e.Message;}
        finally{if(ReferenceEquals(_operation,cts))_operation=null;cts.Dispose();IsBusy=false;}
    }
    private void ApplyFilter()
    {
        if(_raw is null){Rows=null;return;}
        var filtered=_raw.Clone();var query=Filter.Trim();
        foreach(DataRow row in _raw.Rows)
            if(query.Length==0||row.ItemArray.Any(value=>Convert.ToString(value)?.Contains(query,StringComparison.OrdinalIgnoreCase)==true))filtered.ImportRow(row);
        Rows=filtered.DefaultView;
    }
    private async Task ExportAsync(ReportExportFormat format)
    {
        if(!CanExport())return;
        var path=_save.ChoosePath(format,Kind==SecurityReportKind.AccessChanges?"Cambios_accesos":"Cambios_contrasena");
        if(path is null)return;
        // Capturar filas y orden visible antes del trabajo en segundo plano.
        var rows=Rows!.Cast<DataRowView>().Select(r=>r.Row.ItemArray.Select(v=>v==DBNull.Value?null:v).ToArray()).ToList();
        var columns=Rows!.Table!.Columns.Cast<DataColumn>().Select(c=>new ReportExportColumn(c.ColumnName)).ToList();
        var document=new ReportExportDocument(Title,SelectedServer?.Name??"Todos","","",_queriedAt,
            _queryContext+$" · Búsqueda: {Filter}",Description,[new(Title,columns,rows)]);
        var cts=new CancellationTokenSource();_operation=cts;IsBusy=true;
        try{await _export.ExportAsync(format==ReportExportFormat.Pdf?ToPdfLayout(document):document,path,format,cts.Token);if(!_disposed)Status=$"Archivo exportado: {path}";}
        catch(OperationCanceledException){if(!_disposed)Status="Exportación cancelada.";}
        catch(Exception e){if(!_disposed)Status=e.Message;}
        finally{if(ReferenceEquals(_operation,cts))_operation=null;cts.Dispose();IsBusy=false;}
    }
    public static ReportExportDocument ToPdfLayout(ReportExportDocument report)
    {
        // SQL/JSON puede ser largo: las filas de una tabla PDF no se dividen entre
        // páginas. Fichas de dos columnas con fragmentos acotados evitan recortes.
        var sections=report.Sections.Select(section=>
        {
            var fields=new List<object?[]>();var ordinal=0;
            foreach(var row in section.Rows)
            {
                ordinal++;
                for(var column=0;column<section.Columns.Count;column++)
                {
                    var text=(row[column] is DateTime date?date.ToString("yyyy-MM-dd HH:mm:ss",System.Globalization.CultureInfo.InvariantCulture)
                        :Convert.ToString(row[column],System.Globalization.CultureInfo.InvariantCulture)??"No disponible").Replace("\r\n","\n");
                    if(text.Length==0)text="—";
                    var offset=0;var part=0;
                    while(offset<text.Length)
                    {
                        var end=Math.Min(offset+400,text.Length);var lines=0;
                        for(var i=offset;i<end;i++)if(text[i]=='\n'&&++lines==8){end=i+1;break;}
                        fields.Add([$"{ordinal} · {section.Columns[column].Header}"+(part++>0?" (continuación)":""),text[offset..end]]);offset=end;
                    }
                }
            }
            return new ReportExportSection(section.Name,[new("Campo",1),new("Detalle",4)],fields);
        }).ToList();
        return report with{Sections=sections,ScopeNote=report.ScopeNote+" Detalle completo por evento."};
    }
    public void Dispose(){if(_disposed)return;_disposed=true;_operation?.Cancel();RefreshCommands();}
}
