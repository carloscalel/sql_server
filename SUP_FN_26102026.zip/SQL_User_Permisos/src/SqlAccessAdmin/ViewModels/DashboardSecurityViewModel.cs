using SqlAccessAdmin.Data;
using SqlAccessAdmin.Models;
using SqlAccessAdmin.Infrastructure;
using SqlAccessAdmin.Views;
using System.Windows;

namespace SqlAccessAdmin.ViewModels;

public sealed partial class DashboardViewModel
{
    private readonly SecurityMonitoringService? _monitor;
    private bool _securityDisposed;
    private SecurityAlertsWindow? _alertsWindow;
    public RelayCommand ShowSecurityAlertsCommand {get;private set;}=null!;
    public RelayCommand ShowExpiredAlertsCommand {get;private set;}=null!;
    public RelayCommand ShowPasswordAlertsCommand {get;private set;}=null!;
    public RelayCommand ShowPasswordHistoryCommand {get;private set;}=null!;
    private void InitializeSecurityAlerts(AdminDbGateway db,Action? openTemporaries,Action? openPasswordHistory)
    {
        bool CanOpen()=>!_securityDisposed&&_alertsWindow is null;
        void Open(SecurityAlertFilter filter)
        {
            if(!CanOpen())return;
            using var vm=new SecurityAlertsViewModel(db,Session,filter,
                onReviewed:()=>_monitor?.RefreshAsync(compareMetadata:false)??Task.CompletedTask,
                monitoringStatus:$"{SecurityStatus}\nÚltima consulta de metadatos: {LastEvidenceCollection}");
            var window=new SecurityAlertsWindow(vm);_alertsWindow=window;RefreshAlertCommands();
            var owner=Application.Current?.Windows.OfType<Window>().FirstOrDefault(x=>x.IsActive)??Application.Current?.MainWindow;
            if(owner is {IsVisible:true})window.Owner=owner;
            else window.WindowStartupLocation=WindowStartupLocation.CenterScreen;
            try
            {
                window.ShowDialog();
                if(_securityDisposed)return;
                if(window.NavigationTarget=="TEMPORARY")openTemporaries?.Invoke();
                else if(window.NavigationTarget=="PASSWORD_HISTORY")openPasswordHistory?.Invoke();
            }
            finally{_alertsWindow=null;RefreshAlertCommands();}
        }
        ShowSecurityAlertsCommand=new(()=>Open(SecurityAlertFilter.All),CanOpen);
        ShowExpiredAlertsCommand=new(()=>Open(SecurityAlertFilter.Expired),CanOpen);
        ShowPasswordAlertsCommand=new(()=>Open(SecurityAlertFilter.Password),CanOpen);
        ShowPasswordHistoryCommand=new(()=>{if(CanOpen()&&Session.CanAudit)openPasswordHistory?.Invoke();},()=>CanOpen()&&Session.CanAudit&&openPasswordHistory is not null);
    }
    private void RefreshAlertCommands(){ShowSecurityAlertsCommand?.Refresh();ShowExpiredAlertsCommand?.Refresh();ShowPasswordAlertsCommand?.Refresh();ShowPasswordHistoryCommand?.Refresh();}
    public string ExpiredAccessCount=>_monitor?.Summary?.ExpiredAccesses.ToString()??"—";
    public string PasswordAlertCount=>_monitor?.Summary?.PasswordAlerts.ToString()??"—";
    public string UnresolvedPasswordCount=>_monitor?.Summary?.UnresolvedEvents.ToString()??"—";
    public string LastEvidenceCollection=>_monitor?.Summary?.LastCollected is { } date?SecurityMonitoringRules.Display(date):"Sin referencia inicial todavía";
    public string SecurityStatus=>_monitor?.Status??"Actualización de seguridad no iniciada.";
    private void OnSecurityChanged()
    {
        Raise(nameof(ExpiredAccessCount));Raise(nameof(PasswordAlertCount));Raise(nameof(UnresolvedPasswordCount));Raise(nameof(LastEvidenceCollection));Raise(nameof(SecurityStatus));
    }
    public void Dispose()
    {
        _securityDisposed=true;if(_monitor is not null)_monitor.Changed-=OnSecurityChanged;
        _alertsWindow?.CloseForSessionEnd();RefreshAlertCommands();
    }
}
