using System.Windows;

namespace SqlAccessAdmin.Infrastructure;

// DataGrid columns are outside the visual tree; a Freezable inherits the view's context.
public sealed class BindingProxy : Freezable
{
    public static readonly DependencyProperty DataProperty = DependencyProperty.Register(nameof(Data), typeof(object), typeof(BindingProxy));
    public object? Data { get => GetValue(DataProperty); set => SetValue(DataProperty, value); }
    protected override Freezable CreateInstanceCore() => new BindingProxy();
}
