namespace SqlAccessAdmin.Infrastructure;

public static class AppTime
{
    public static TimeZoneInfo Zone=>TimeZoneInfo.FindSystemTimeZoneById("Central America Standard Time");
    public static DateTimeOffset OffsetNow=>TimeZoneInfo.ConvertTime(DateTimeOffset.UtcNow,Zone);
    public static DateTime Now=>DateTime.SpecifyKind(OffsetNow.DateTime,DateTimeKind.Unspecified);
    public static DateTime FromUtc(DateTime value)=>DateTime.SpecifyKind(TimeZoneInfo.ConvertTimeFromUtc(DateTime.SpecifyKind(value,DateTimeKind.Utc),Zone),DateTimeKind.Unspecified);
    public static DateTime FromEngineLocal(DateTime value,int engineOffsetMinutes)=>DateTime.SpecifyKind(
        TimeZoneInfo.ConvertTime(new DateTimeOffset(DateTime.SpecifyKind(value,DateTimeKind.Unspecified),TimeSpan.FromMinutes(engineOffsetMinutes)),Zone).DateTime,DateTimeKind.Unspecified);
    public static string Display(DateTime value)=>value.ToString("yyyy-MM-dd HH:mm:ss",System.Globalization.CultureInfo.InvariantCulture);
}
