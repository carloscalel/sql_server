SET NOCOUNT ON;
INSERT access.ManagedServer(ServerId,Name,Active) VALUES(1,N'Laboratorio',1);
INSERT access.AccessRequest VALUES(1,'PERMISSION_CHANGE',N'ana','GRANT','SELECT','OBJECT',N'dbo.Factura',NULL,'PENDING',N'fixture-admin','TIC-1');
INSERT access.AccessRequestTarget VALUES(1,1,N'Ventas');
DECLARE @Expiry datetime2(7)=DATEADD(day,1,access.ufn_AppNow());
BEGIN TRAN;
EXEC access.usp_RequestValidity_Attach 1,@Expiry;
COMMIT;
UPDATE access.AccessRequest SET Status='APPROVED' WHERE RequestId=1;
EXEC access.usp_TemporaryAccess_RegisterExecution 1,1,N'Ventas',0x010203;
EXEC access.usp_TemporaryAccess_RegisterExecution 1,1,N'Ventas',0x010203;
IF (SELECT COUNT(*) FROM access.TemporaryAccess)<>1 THROW 51900,'Registro temporal no idempotente.',1;
UPDATE access.TemporaryAccess SET ExpiresAt=DATEADD(second,-1,access.ufn_AppNow());
EXEC access.usp_SecurityMonitoring_Summary;
EXEC access.usp_SecurityMonitoring_Summary;
IF (SELECT COUNT(*) FROM access.SecurityAlert WHERE IsActive=1)<>1 THROW 51900,'Vencimiento duplicado o ausente.',1;
DECLARE @Id bigint=(SELECT TemporaryAccessId FROM access.TemporaryAccess),@Rv binary(8)=(SELECT RowVersion FROM access.TemporaryAccess);
EXEC access.usp_TemporaryAccessAction_Create @Id,@Rv,'EXTEND',@Expiry,'TIC-1',N'Extensión probada en laboratorio';
DECLARE @Action bigint=(SELECT MAX(ActionId) FROM access.TemporaryAccessAction);
EXEC access.usp_TemporaryAccessAction_Review @Action,1;
IF NOT EXISTS(SELECT 1 FROM access.SecurityAlert WHERE IsActive=1) THROW 51900,'Aprobar resolvió una alerta antes de ejecutar.',1;
EXEC access.usp_TemporaryAccessAction_Begin @Action;
EXEC access.usp_TemporaryAccessAction_Complete @Action,1,N'Extensión confirmada';
IF EXISTS(SELECT 1 FROM access.SecurityAlert WHERE IsActive=1) OR NOT EXISTS(SELECT 1 FROM access.TemporaryAccess WHERE Revision=2 AND IsOpen=1)
 THROW 51900,'Extensión inconsistente.',1;
UPDATE access.TemporaryAccess SET ExpiresAt=DATEADD(second,-1,access.ufn_AppNow());
EXEC access.usp_SecurityMonitoring_Summary;
SET @Rv=(SELECT RowVersion FROM access.TemporaryAccess);
EXEC access.usp_TemporaryAccessAction_Create @Id,@Rv,'CLOSE',NULL,'TIC-1',N'Cierre probado en laboratorio';
SET @Action=(SELECT MAX(ActionId) FROM access.TemporaryAccessAction);
EXEC access.usp_TemporaryAccessAction_Review @Action,1;
EXEC access.usp_TemporaryAccessAction_Begin @Action;
EXEC access.usp_TemporaryAccessAction_Complete @Action,0,N'Fallo simulado del destino';
IF NOT EXISTS(SELECT 1 FROM access.SecurityAlert WHERE IsActive=1) OR NOT EXISTS(SELECT 1 FROM access.TemporaryAccess WHERE IsOpen=1)
 THROW 51900,'El cierre fallido resolvió la alerta o cerró el acceso.',1;
PRINT N'LAB_SQL_RESULT Vigencias, revisión, idempotencia y alertas persistentes: correctos.';
GO
