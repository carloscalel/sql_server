SET NOCOUNT ON;
DECLARE @Fixed datetime2(7)='2026-10-26T23:05:00',@Source uniqueidentifier=NEWID(),@Execution uniqueidentifier=NEWID();
INSERT access.AuthorizedPrincipal(UserId,CreatedAt) VALUES(7,@Fixed);
INSERT access.ManagedServer(ServerId,Name,Active,CreatedAt) VALUES(7,N'Conversión UTC',1,@Fixed);
INSERT access.AccessRequest(RequestId,OperationCode,TargetPrincipal,Status,RequestedBy,ExternalTicketNumber) VALUES(700,'PERMISSION_CHANGE',N'time-fixture','APPROVED',N'fixture-admin','TIC-TIME');
INSERT access.AccessRequestTarget VALUES(700,7,N'Ventas');
INSERT access.SecurityEvidenceSource(SourceId,ServerId,LastCollectedUtc,CoverageStartedUtc,Health,MetadataCheckedUtc) VALUES(@Source,7,@Fixed,@Fixed,N'Fixture UTC',@Fixed);
INSERT access.RequestValidity(RequestId,ExpiresAtUtc,CreatedBy,CreatedAtUtc) VALUES(700,@Fixed,N'fixture-admin',@Fixed);
INSERT access.AppExecution(ExecutionId,RequestId,ServerId,PrincipalName,Actor,StartedAtUtc) VALUES(@Execution,700,7,N'time-fixture',N'fixture-admin',@Fixed);
INSERT access.AppSecurityChange(EventId,ExecutionId,Ordinal,SourceId,DatabaseName,PrincipalKind,PrincipalName,OperationCode,State,PreparedAtUtc,CompletedAtUtc,ModifiedLocal,PasswordSetLocal,EngineOffsetMinutes)
 VALUES(NEWID(),@Execution,1,@Source,N'Ventas','DATABASE_USER',N'time-fixture','PERMISSION_CHANGE','CONFIRMED',@Fixed,@Fixed,@Fixed,@Fixed,0);
INSERT access.PrincipalMetadataSnapshot VALUES(7,N'Ventas','DATABASE_USER',0x7788,N'time-fixture',@Fixed,@Fixed,0,'BASELINE','BASELINE',@Fixed,@Fixed,@Fixed);
EXEC access.usp_Audit_Write @Form=N'Prueba de horas',@Action=N'Antes de conversión',@Success=1,@Detail=N'Contenido histórico conservado';
EXEC access.usp_Audit_Write @Form=N'Prueba de horas',@Action=N'Antes de conversión 2',@Success=1;
SELECT AuditId,EventDate,EventHash,PreviousHash INTO #OriginalAudit FROM access.AuditEvent;
GO
