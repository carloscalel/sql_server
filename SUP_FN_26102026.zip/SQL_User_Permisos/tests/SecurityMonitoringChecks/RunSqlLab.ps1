param([string]$Server='localhost',[switch]$TrustCertificate)
$ErrorActionPreference='Stop'
$repoRoot=(Resolve-Path (Join-Path $PSScriptRoot '../..')).Path
$labName='SqlAccessAdmin_MonitoringChecks_'+[guid]::NewGuid().ToString('N')
if($labName -notmatch '^SqlAccessAdmin_MonitoringChecks_[a-f0-9]{32}$'){throw 'Nombre de laboratorio inválido.'}
$outputDir=Join-Path $repoRoot 'artifacts/security-monitoring-sql'
New-Item -ItemType Directory -Path $outputDir -Force | Out-Null
function Invoke-LabSql([string]$Db,[string[]]$Arguments) {
 $sqlArgs=@('-S',$Server,'-d',$Db,'-E','-b','-r','1','-l','15','-f','65001')
 if($TrustCertificate){$sqlArgs+='-C'}
 $labOutput=& sqlcmd @sqlArgs @Arguments 2>&1
 $labOutput | Set-Content -LiteralPath (Join-Path $outputDir 'last-output.txt') -Encoding utf8
 if($LASTEXITCODE -ne 0){$labOutput | Select-Object -Last 16 | Write-Output;throw 'Falló el laboratorio SQL.'}
 $labOutput | Where-Object {$_ -match 'LAB_SQL_RESULT'} | Write-Output
}
$fixture=Get-Content (Join-Path $PSScriptRoot 'SqlLabFixture.sql') -Raw
$auditFixture=Get-Content (Join-Path $PSScriptRoot 'SqlTimeAuditFixture.sql') -Raw
$legacy=(Get-Content (Join-Path $repoRoot 'docs/archive/monitoring-v2/33_v3_utc.sql.txt') -Raw).Replace('USE [adminDB];',"USE [$labName];")
$timeMigration=(Get-Content (Join-Path $repoRoot 'InsumosProduccion/36_HoraLocalGuatemala.sql') -Raw).Replace('USE [adminDB];',"USE [$labName];")
$timeSeed=Get-Content (Join-Path $PSScriptRoot 'SqlTimeSeed.sql') -Raw
$timeChecks=Get-Content (Join-Path $PSScriptRoot 'SqlTimeChecks.sql') -Raw
$migration=(Get-Content (Join-Path $repoRoot 'InsumosProduccion/33_MonitoreoSeguridadYTemporales.sql') -Raw).Replace('USE [adminDB];',"USE [$labName];")
$checks=Get-Content (Join-Path $PSScriptRoot 'SqlLabChecks.sql') -Raw
$scriptPath=Join-Path $outputDir 'lab.sql'
Set-Content -LiteralPath $scriptPath -Value ($fixture+"`n"+$auditFixture+"`n"+$legacy+"`n"+$timeSeed+"`n"+$timeMigration+"`n"+$migration+"`n"+$timeChecks+"`n"+$checks) -Encoding utf8
$created=$false
try {
 Invoke-LabSql 'master' @('-Q',"CREATE DATABASE [$labName];")
 $created=$true
 Invoke-LabSql $labName @('-i',$scriptPath)
 $probeArgs=@('--sql-lab',$Server,$labName)
 if($TrustCertificate){$probeArgs+='--trust-certificate'}
 & dotnet run --project (Join-Path $PSScriptRoot 'SecurityMonitoringChecks.csproj') -c Release --no-restore -- @probeArgs
 if($LASTEXITCODE -ne 0){throw 'Falló la integración C#/SQL del laboratorio.'}
 $reapply=Join-Path $outputDir 'reapply.sql'
 $before="USE [$labName]; SELECT (SELECT COUNT(*) FROM access.AppSecurityChange) Commands,(SELECT COUNT(*) FROM access.PrincipalMetadataSnapshot) Snapshots,(SELECT SUM(ChangeCount) FROM access.AppPasswordDaily) Changes,(SELECT MAX(EventDate) FROM access.AuditEvent) AuditTime,(SELECT MAX(ExpiresAt) FROM access.TemporaryAccess) Expiry INTO #Before;`nGO`n"
 Set-Content -LiteralPath $reapply -Value ($before+$timeMigration+"`n"+$migration+"`nIF (SELECT SUM(ChangeCount) FROM access.AppPasswordDaily)<>(SELECT Changes FROM #Before) OR (SELECT COUNT(*) FROM access.AppSecurityChange)<>(SELECT Commands FROM #Before) OR (SELECT COUNT(*) FROM access.PrincipalMetadataSnapshot)<>(SELECT Snapshots FROM #Before) OR (SELECT MAX(EventDate) FROM access.AuditEvent)<>(SELECT AuditTime FROM #Before) OR (SELECT MAX(ExpiresAt) FROM access.TemporaryAccess)<>(SELECT Expiry FROM #Before) THROW 51900,'Reaplicar 36/33 alteró las horas o el historial.',1; DECLARE @Integrity table(HashedEvents bigint,BrokenLinks int,AlteredEvents int,IsValid bit); INSERT @Integrity EXEC access.usp_Audit_ValidateIntegrity; IF EXISTS(SELECT 1 FROM @Integrity WHERE IsValid=0) THROW 51930,'Se alteró la cadena al reaplicar.',1; PRINT N'LAB_SQL_RESULT Reaplicación de 36 y 33 v4: horas, historial y referencias conservados.';") -Encoding utf8
 Invoke-LabSql $labName @('-i',$reapply)
} finally {
 if($created){
  if($labName -notmatch '^SqlAccessAdmin_MonitoringChecks_[a-f0-9]{32}$'){throw 'Limpieza rechazada.'}
  Invoke-LabSql $labName @('-Q',"IF SUSER_ID(N'${labName}_Login') IS NOT NULL DROP LOGIN [${labName}_Login];")
  Invoke-LabSql 'master' @('-Q',"ALTER DATABASE [$labName] SET SINGLE_USER WITH ROLLBACK IMMEDIATE; DROP DATABASE [$labName];")
 }
}
