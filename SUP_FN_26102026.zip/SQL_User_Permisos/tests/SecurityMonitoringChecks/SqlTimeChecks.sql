IF (SELECT CreatedAt FROM access.AuthorizedPrincipal WHERE UserId=7)<>CONVERT(datetime2(3),'2026-10-26T17:05:00') THROW 51920,'No se convirtió la fecha de la tabla base.',1;
IF (SELECT ExpiresAt FROM access.RequestValidity WHERE RequestId=700)<>CONVERT(datetime2(7),'2026-10-26T17:05:00') THROW 51921,'La vigencia no conserva su instante local.',1;
IF EXISTS(SELECT 1 FROM access.AuditEvent e JOIN #OriginalAudit b ON b.AuditId=e.AuditId WHERE e.EventHash<>b.EventHash OR e.PreviousHash<>b.PreviousHash OR e.EventDate<>DATEADD(hour,-6,b.EventDate))
 THROW 51922,'Se alteraron los hashes o no se convirtió EventDate.',1;
IF EXISTS(SELECT 1 FROM access.AppSecurityChange WHERE PrincipalName=N'time-fixture' AND (CompletedAt<>'2026-10-26T17:05:00' OR ModifiedLocal<>'2026-10-26T17:05:00')) THROW 51923,'No se normalizaron fechas del motor y de ejecución.',1;
IF EXISTS(SELECT 1 FROM sys.columns c JOIN sys.tables t ON c.object_id=t.object_id WHERE t.schema_id=SCHEMA_ID(N'access') AND RIGHT(c.name,3)='Utc' AND TYPE_NAME(c.user_type_id) IN('datetime','datetime2','smalldatetime')) THROW 51924,'Quedan columnas de fecha UTC.',1;
DECLARE @Integrity table(HashedEvents bigint,BrokenLinks int,AlteredEvents int,IsValid bit);
INSERT @Integrity EXEC access.usp_Audit_ValidateIntegrity;
IF EXISTS(SELECT 1 FROM @Integrity WHERE IsValid=0) THROW 51925,'La cadena histórica perdió integridad.',1;
EXEC access.usp_Audit_Write @Form=N'Prueba de horas',@Action=N'Después de conversión',@Success=1;
DELETE @Integrity;INSERT @Integrity EXEC access.usp_Audit_ValidateIntegrity;
IF EXISTS(SELECT 1 FROM @Integrity WHERE IsValid=0) THROW 51926,'El evento local no enlaza con los hashes anteriores.',1;
IF ABS(DATEDIFF(second,(SELECT MAX(EventDate) FROM access.AuditEvent),access.ufn_AppNow()))>10 THROW 51927,'La auditoría nueva no usa hora local.',1;
-- El validador también debe detectar alteración de la fecha local visible.
BEGIN TRAN;
DISABLE TRIGGER access.tr_AuditEvent_AppendOnly ON access.AuditEvent;
UPDATE access.AuditEvent SET EventDate=DATEADD(minute,1,EventDate) WHERE AuditId=(SELECT MIN(AuditId) FROM access.AuditEvent);
DELETE @Integrity;INSERT @Integrity EXEC access.usp_Audit_ValidateIntegrity;
IF EXISTS(SELECT 1 FROM @Integrity WHERE IsValid=1) THROW 51928,'La fecha local adulterada no fue detectada.',1;
ROLLBACK;
-- El contador cambia de día a medianoche local, sin desplazar otras seis horas.
DECLARE @Source uniqueidentifier=(SELECT SourceId FROM access.SecurityEvidenceSource WHERE ServerId=7),@I int=701,@Execution uniqueidentifier,@Event uniqueidentifier,@Time datetime2(7);
WHILE @I<=702
BEGIN
 SET @Execution=NEWID();SET @Event=NEWID();SET @Time=CASE WHEN @I=701 THEN CONVERT(datetime2(7),'2026-10-26T23:59:59') ELSE CONVERT(datetime2(7),'2026-10-27T00:00:00') END;
 INSERT access.AccessRequest(RequestId,OperationCode,TargetPrincipal,Status,RequestedBy,ExternalTicketNumber) VALUES(@I,'CHANGE_LOGIN_PASSWORD',N'midnight-fixture','APPROVED',N'fixture-admin','TIC-TIME');
 INSERT access.AccessRequestTarget VALUES(@I,7,N'master');
 INSERT access.AppExecution(ExecutionId,RequestId,ServerId,PrincipalName,Actor) VALUES(@Execution,@I,7,N'midnight-fixture',N'fixture-admin');
 INSERT access.AppSecurityChange(EventId,ExecutionId,Ordinal,SourceId,DatabaseName,PrincipalKind,PrincipalName,PrincipalSid,OperationCode)
 VALUES(@Event,@Execution,1,@Source,N'','LOGIN',N'midnight-fixture',0xFF0011,'CHANGE_LOGIN_PASSWORD');
 EXEC access.usp_AppChange_Complete @Event,'CONFIRMED',0xFF0011,@Time,@Time,-360,@Time,1;
 SET @I+=1;
END;
IF (SELECT COUNT(*) FROM access.AppPasswordDaily WHERE SourceId=@Source AND ChangeCount=1 AND BusinessDate IN('2026-10-26','2026-10-27'))<>2 THROW 51929,'El día local del contador cambió al convertir las horas.',1;
DELETE access.AppPasswordDaily WHERE SourceId=@Source;
DELETE access.AppSecurityChange WHERE ExecutionId IN(SELECT ExecutionId FROM access.AppExecution WHERE RequestId IN(700,701,702));
DELETE access.AppExecution WHERE RequestId IN(700,701,702);
DELETE access.RequestValidity WHERE RequestId=700;
DELETE access.AccessRequestTarget WHERE RequestId IN(700,701,702);
DELETE access.AccessRequest WHERE RequestId IN(700,701,702);
DELETE access.PrincipalMetadataSnapshot WHERE ServerId=7;
DELETE access.SecurityEvidenceSource WHERE ServerId=7;
DELETE access.ManagedServer WHERE ServerId=7;
PRINT N'LAB_SQL_RESULT Hora local: 23:05 pasa a 17:05 en tablas base, vigencia, ejecución y metadatos; hashes originales intactos, cadena mixta válida y alteración visible detectada.';
GO
