param([Parameter(Mandatory=$true)][string]$PivotServer,[string]$Database='adminDB',[string]$TargetServer='',[switch]$TrustCertificate)
$ErrorActionPreference='Stop'
function Invoke-ReadCheck([string]$ServerName,[string]$DatabaseName,[string]$Query) {
 $taskArgs=@('-S',$ServerName,'-d',$DatabaseName,'-E','-b','-l','15','-Q',$Query)
 if($TrustCertificate){$taskArgs+='-C'}
 & sqlcmd @taskArgs
 if($LASTEXITCODE -ne 0){throw 'La comprobación SQL falló.'}
}
Invoke-ReadCheck $PivotServer $Database @'
SET NOCOUNT ON;
IF OBJECT_ID(N'access.AppSecurityChange',N'U') IS NULL OR OBJECT_ID(N'access.PrincipalMetadataSnapshot',N'U') IS NULL
 OR OBJECT_ID(N'access.usp_AppChange_Prepare',N'P') IS NULL OR OBJECT_ID(N'access.usp_AppChange_Complete',N'P') IS NULL
 OR OBJECT_ID(N'access.usp_PrincipalMetadata_Import',N'P') IS NULL
 THROW 51770,'Falta el contrato central v4. Aplique 36, después 33 actualizado y valide con 99.',1;
IF NOT EXISTS(SELECT 1 FROM access.SecurityMonitoringVersion WHERE Id=1 AND Version=4) THROW 51771,'Versión de seguimiento incorrecta.',1;
PRINT N'Contrato central de operaciones de la app y metadatos correcto.';
'@
if($TargetServer){
 Invoke-ReadCheck $TargetServer 'master' @'
SET NOCOUNT ON;
IF COALESCE(HAS_PERMS_BY_NAME(NULL,NULL,'VIEW ANY DEFINITION'),0)<>1 AND COALESCE(IS_SRVROLEMEMBER('sysadmin'),0)<>1
 THROW 51773,'Falta visibilidad completa de metadatos de seguridad.',1;
SELECT TOP(5) name,modify_date,LOGINPROPERTY(name,'PasswordLastSetTime') PasswordLastSetTime FROM sys.server_principals WHERE type='S' AND principal_id>1;
PRINT N'Destino consultable sin instalación adicional. Validar acceso y VIEW DEFINITION en cada base de trabajo.';
'@
}
