SET NOCOUNT ON;
GO
CREATE SCHEMA access AUTHORIZATION dbo;
GO
CREATE ROLE SqlAccessAdmin_Users;

CREATE TABLE access.ManagedServer(ServerId int PRIMARY KEY,Name nvarchar(128),Active bit,CreatedAt datetime2(3) NOT NULL DEFAULT SYSUTCDATETIME());
CREATE TABLE access.SecurityPolicyOperation(OperationCode varchar(40) PRIMARY KEY);
INSERT access.SecurityPolicyOperation VALUES('CHANGE_LOGIN_PASSWORD');
CREATE TABLE access.AccessRequest(RequestId bigint PRIMARY KEY,OperationCode varchar(40),TargetPrincipal nvarchar(256),
 PermissionAction varchar(10),PermissionName varchar(128),ScopeType varchar(30),Securable nvarchar(776),RoleName nvarchar(128),
 Status varchar(20),RequestedBy nvarchar(256),ExternalTicketNumber varchar(50));
CREATE TABLE access.AccessRequestStep(StepId bigint IDENTITY PRIMARY KEY,RequestId bigint,StepOrder int,
 OperationCode varchar(40),PermissionAction varchar(10),PermissionName varchar(128),ScopeType varchar(30),Securable nvarchar(776),RoleName nvarchar(128));
CREATE TABLE access.AccessRequestTarget(RequestId bigint,ServerId int,DatabaseName sysname);
CREATE TABLE access.LabAudit(Action nvarchar(200),Success bit,Detail nvarchar(2000));
GO
CREATE FUNCTION access.ufn_App_Principal() RETURNS nvarchar(256) AS BEGIN RETURN N'fixture-admin'; END;
GO
CREATE FUNCTION access.ufn_App_HasPermission(@Permission varchar(40)) RETURNS bit AS
BEGIN RETURN CASE WHEN CONVERT(varchar(40),SESSION_CONTEXT(N'Lab.Denied'))=@Permission THEN 0 ELSE 1 END; END;
GO
CREATE PROCEDURE access.usp_App_RequirePermission @Permission varchar(40) AS
BEGIN IF access.ufn_App_HasPermission(@Permission)=0 THROW 51001,'Permiso denegado en laboratorio.',1; END;
GO
CREATE PROCEDURE access.usp_Audit_Write @Form nvarchar(200),@Action nvarchar(200),@Success bit,@Detail nvarchar(2000) AS
BEGIN SET NOCOUNT ON; INSERT access.LabAudit VALUES(@Action,@Success,@Detail); END;
GO
CREATE PROCEDURE dbo.sp_VerificarTicketExiste @Ticket varchar(50) AS
BEGIN SET NOCOUNT ON; SELECT N'Equipo' RESPONSABLE,N'Lab' CLIENTE,@Ticket ID_COMPUESTO,N'Prueba' ASUNTO,N'Prueba' DESCRIPCION,N'ACTIVO' ESTADO; END;

GO
CREATE PROCEDURE access.usp_App_LoginContext AS BEGIN SET NOCOUNT ON; SELECT 2 AuthorizationVersion,CONVERT(bit,1) IsAuthorized,N'fixture-admin' Principal,N'["Administrator"]' Roles; END;
GO
