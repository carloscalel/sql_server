using System.Data;
using System.Reflection;
using System.Text.Json;
using System.Text.RegularExpressions;
using Microsoft.Data.SqlClient;
using SqlAccessAdmin.Data;
using SqlAccessAdmin.Models;

internal static class SqlMonitoringLab
{
    internal static async Task<int> RunAsync(string server,string database,bool trustCertificate)
    {
        if(!Regex.IsMatch(database,"^SqlAccessAdmin_MonitoringChecks_[a-f0-9]{32}$"))throw new InvalidOperationException("Base ajena al laboratorio.");
        var builder=new SqlConnectionStringBuilder{DataSource=server,InitialCatalog=database,IntegratedSecurity=true,Encrypt=true,TrustServerCertificate=trustCertificate};
        var login=database+"_Login";
        var gateway=new AdminDbGateway(new(server,"",database,true,null,null,true,trustCertificate));
        await using var cn=new SqlConnection(builder.ConnectionString);await cn.OpenAsync();
        async Task Execute(string sql){await using var command=new SqlCommand(sql,cn){CommandTimeout=60};await command.ExecuteNonQueryAsync();}
        async Task<long> Scalar(string sql){await using var command=new SqlCommand(sql,cn);return Convert.ToInt64(await command.ExecuteScalarAsync());}
        async Task Snapshot()
        {
            var metadata=await TrackedSqlConnection.ReadPrincipalMetadataAsync(cn,null,login,true,CancellationToken.None);
            if(metadata is null)throw new Exception("Falta login de laboratorio.");
            await gateway.ImportPrincipalMetadataAsync(1,[metadata],CancellationToken.None);
        }
        AccessRequestItem Request(long id,string operation)=>new(id,operation,login,"","SQL","","","","","","TIC-LAB","Prueba de registro central","APPROVED","fixture-admin",SqlAccessAdmin.Infrastructure.AppTime.Now,"fixture-admin",SqlAccessAdmin.Infrastructure.AppTime.Now,1,0);
        async Task Seed(long id,string operation,string db)
        {
            await using var cmd=new SqlCommand("INSERT access.AccessRequest(RequestId,OperationCode,TargetPrincipal,Status,RequestedBy,ExternalTicketNumber) VALUES(@id,@operation,@principal,'APPROVED',N'fixture-admin','TIC-LAB'); INSERT access.AccessRequestTarget VALUES(@id,1,@db);",cn);
            cmd.Parameters.AddWithValue("@id",id);cmd.Parameters.AddWithValue("@operation",operation);cmd.Parameters.AddWithValue("@principal",login);cmd.Parameters.AddWithValue("@db",db);await cmd.ExecuteNonQueryAsync();
        }
        try
        {
            await Execute($"CREATE LOGIN [{login}] WITH PASSWORD=N'Lab-Initial-Password-2026!x',CHECK_POLICY=OFF;");
            await Snapshot();
            if(await Scalar("SELECT COUNT(*) FROM access.PrincipalMetadataSnapshot WHERE ModificationOrigin='BASELINE' AND PasswordOrigin='BASELINE'")!=1)throw new Exception("La referencia inicial se marcó como externa.");
            var sql=(string)typeof(DirectSqlServerService).GetMethod("BuildLoginPasswordChangeSql",BindingFlags.NonPublic|BindingFlags.Static)!.Invoke(null,[login,false,false,false])!;
            for(var i=0;i<4;i++)
            {
                await Seed(100+i,"CHANGE_LOGIN_PASSWORD","master");
                using(var scope=ExecutionEvidenceScope.Begin(Request(100+i,"CHANGE_LOGIN_PASSWORD"),"fixture-admin",gateway,1))
                {
                    await using var lease=await TrackedSqlConnection.OpenAsync(builder.ConnectionString,CancellationToken.None);
                    await TrackedSqlConnection.TagChangeAsync(lease.Connection,null,"CHANGE_LOGIN_PASSWORD",login);
                    await using var command=new SqlCommand(sql,lease.Connection){CommandTimeout=60};command.Parameters.AddWithValue("@login",login);command.Parameters.AddWithValue("@password",$"Lab-Changed-Password-{i}-2026!x");
                    await TrackedSqlConnection.ExecuteCommandAsync(command,CancellationToken.None);
                }
                await Snapshot();
                if(await Scalar("SELECT SUM(ChangeCount) FROM access.AppPasswordDaily")!=i+1)throw new Exception("Contador de la app incorrecto.");
                if(await Scalar("SELECT COUNT(*) FROM access.SecurityAlert WHERE AlertType='PASSWORD_FREQUENCY' AND IsActive=1")!=(i<2?0:1))throw new Exception("Umbral o deduplicación de alerta incorrectos.");
            }
            if(await Scalar("SELECT COUNT(*) FROM access.PrincipalMetadataSnapshot WHERE PasswordOrigin='APP' AND ModificationOrigin='APP'")!=1)throw new Exception("No se concilió el cambio confirmado de la app.");
            var id=(Guid)(await new SqlCommand("SELECT TOP(1) EventId FROM access.AppSecurityChange WHERE OperationCode='CHANGE_LOGIN_PASSWORD'",cn).ExecuteScalarAsync())!;
            await gateway.CompleteAppChangeAsync(id,"CONFIRMED",null,SqlAccessAdmin.Infrastructure.AppTime.Now,CancellationToken.None);
            if(await Scalar("SELECT SUM(ChangeCount) FROM access.AppPasswordDaily")!=4)throw new Exception("Reentrega duplicó el contador.");
            var rejected=false;
            try{await gateway.BeginAppExecutionAsync(100,null,1,CancellationToken.None);}catch(SqlException error)when(error.Number==51803){rejected=true;}
            if(!rejected)throw new Exception("Se permitió reejecutar una solicitud con intento reservado.");
            await Task.Delay(100);
            await Execute($"ALTER LOGIN [{login}] WITH PASSWORD=N'Lab-External-Password-2026!x';");await Snapshot();await Snapshot();
            if(await Scalar("SELECT COUNT(*) FROM access.PrincipalMetadataSnapshot WHERE PasswordOrigin='EXTERNAL' AND ModificationOrigin='EXTERNAL'")!=1||await Scalar("SELECT SUM(ChangeCount) FROM access.AppPasswordDaily")!=4)
                throw new Exception("La referencia externa fue atribuida a la app o sumó cambios.");
            await Execute($"ALTER LOGIN [{login}] WITH DEFAULT_LANGUAGE=us_english;");await Snapshot();
            if(await Scalar("SELECT COUNT(*) FROM access.PrincipalMetadataSnapshot WHERE PasswordOrigin='EXTERNAL'")!=1)throw new Exception("Un cambio de configuración eliminó la referencia externa de contraseña.");
            await Seed(104,"DISABLE_LOGIN","master");
            using(var scope=ExecutionEvidenceScope.Begin(Request(104,"DISABLE_LOGIN"),"fixture-admin",gateway,1))
            {
                await using var lease=await TrackedSqlConnection.OpenAsync(builder.ConnectionString,CancellationToken.None);
                await TrackedSqlConnection.TagChangeAsync(lease.Connection,null,"DISABLE_LOGIN",login);
                await using var state=new SqlCommand($"ALTER LOGIN [{login}] DISABLE",lease.Connection);
                await TrackedSqlConnection.ExecuteCommandAsync(state,CancellationToken.None);
            }
            await Snapshot();
            if(await Scalar("SELECT COUNT(*) FROM access.PrincipalMetadataSnapshot WHERE PasswordOrigin='EXTERNAL' AND ModificationOrigin='APP'")!=1)
                throw new Exception("Una operación de estado de la app absorbió indebidamente la contraseña externa.");
            var alert=(await gateway.GetActiveSecurityAlertsAsync()).First(x=>x.Type=="PASSWORD_FREQUENCY");await gateway.ResolvePasswordAlertAsync(alert.Id,"Revisión confirmada en laboratorio.");
            await gateway.CompleteAppChangeAsync(id,"CONFIRMED",null,SqlAccessAdmin.Infrastructure.AppTime.Now,CancellationToken.None);
            if(await Scalar("SELECT COUNT(*) FROM access.SecurityAlert WHERE AlertType='PASSWORD_FREQUENCY' AND IsActive=1")!=0)throw new Exception("Reentrega reabrió la alerta revisada.");
            await Execute($"CREATE USER [{login}] FOR LOGIN [{login}];");await Seed(200,"PERMISSION_CHANGE",database);
            var userReference=await TrackedSqlConnection.ReadPrincipalMetadataAsync(cn,null,login,false,CancellationToken.None);
            // Referencia anterior controlada: no todos los ALTER USER avanzan modify_date.
            await gateway.ImportPrincipalMetadataAsync(1,[userReference! with{ModifiedLocal=userReference!.ModifiedLocal.AddSeconds(-2)}],CancellationToken.None);
            await Task.Delay(1100);await Execute($"ALTER USER [{login}] WITH DEFAULT_SCHEMA=sys;");
            userReference=await TrackedSqlConnection.ReadPrincipalMetadataAsync(cn,null,login,false,CancellationToken.None);
            await gateway.ImportPrincipalMetadataAsync(1,[userReference!],CancellationToken.None);
            var externalUserDate=userReference!.ModifiedLocal;
            if(await Scalar("SELECT COUNT(*) FROM access.PrincipalMetadataSnapshot WHERE PrincipalKind='DATABASE_USER' AND ModificationOrigin='EXTERNAL'")!=1)
                throw new Exception("No se observó la modificación externa de definición preparada para la prueba.");
            using(var scope=ExecutionEvidenceScope.Begin(Request(200,"PERMISSION_CHANGE"),"fixture-admin",gateway,1))
            {
                await using var lease=await TrackedSqlConnection.OpenAsync(builder.ConnectionString,CancellationToken.None);var connection=lease.Connection;
                await using var tx=(SqlTransaction)await connection.BeginTransactionAsync();
                await TrackedSqlConnection.TagChangeAsync(connection,tx,"PERMISSION_CHANGE",login,"GRANT","SELECT","OBJECT","access.LabAudit");
                await using var command=new SqlCommand($"GRANT SELECT ON access.LabAudit TO [{login}]",connection,tx);await TrackedSqlConnection.ExecuteCommandAsync(command,CancellationToken.None);
                if(await Scalar("SELECT COUNT(*) FROM access.AppSecurityChange WHERE State='PENDING' AND OperationCode='PERMISSION_CHANGE'")!=1)throw new Exception("Se confirmó antes del commit.");
                await tx.RollbackAsync();await TrackedSqlConnection.RollbackTrackedAsync(connection);
            }
            if(await Scalar("SELECT COUNT(*) FROM access.AppSecurityChange WHERE State='ROLLED_BACK'")!=1)throw new Exception("Se perdió la reversión confirmada.");
            await Seed(201,"PERMISSION_CHANGE",database);
            using(var scope=ExecutionEvidenceScope.Begin(Request(201,"PERMISSION_CHANGE"),"fixture-admin",gateway,1))
            {
                await using var lease=await TrackedSqlConnection.OpenAsync(builder.ConnectionString,CancellationToken.None);var connection=lease.Connection;
                await using var tx=(SqlTransaction)await connection.BeginTransactionAsync();
                await TrackedSqlConnection.TagChangeAsync(connection,tx,"PERMISSION_CHANGE",login,"GRANT","SELECT","OBJECT","access.LabAudit");
                await using var command=new SqlCommand($"GRANT SELECT ON access.LabAudit TO [{login}]",connection,tx);await TrackedSqlConnection.ExecuteCommandAsync(command,CancellationToken.None);
                await tx.CommitAsync();await TrackedSqlConnection.CommitTrackedAsync(connection);
            }
            if(await Scalar("SELECT COUNT(*) FROM access.AppSecurityChange WHERE State='CONFIRMED' AND OperationCode='PERMISSION_CHANGE'")!=1)throw new Exception("Falta permiso confirmado después del commit.");
            userReference=await TrackedSqlConnection.ReadPrincipalMetadataAsync(cn,null,login,false,CancellationToken.None);
            await gateway.ImportPrincipalMetadataAsync(1,[userReference!],CancellationToken.None);
            if(userReference!.ModifiedLocal==externalUserDate&&await Scalar("SELECT COUNT(*) FROM access.PrincipalMetadataSnapshot WHERE PrincipalKind='DATABASE_USER' AND ModificationOrigin='EXTERNAL'")!=1)
                throw new Exception("Conceder un permiso desde la app absorbió una fecha de definición externa anterior.");
            var from=SqlAccessAdmin.Infrastructure.AppTime.Now.Date.AddDays(-1);var to=from.AddDays(3);
            var history=await gateway.GetSecurityReportAsync(SecurityReportKind.PasswordHistory,from,to,null);
            if(history.Rows.Count!=5||history.Rows.Cast<DataRow>().Count(r=>r.Field<string>("Fuente")!.StartsWith("Externo"))!=1)throw new Exception("Historial no separa app y última fecha externa.");
            if(JsonSerializer.Serialize(history.Rows.Cast<DataRow>().Select(r=>r.ItemArray)).Contains("Lab-Changed-Password",StringComparison.Ordinal))throw new Exception("Se almacenó un secreto.");
            var changes=await gateway.GetSecurityReportAsync(SecurityReportKind.AccessChanges,from,to,null);
            if(changes.Rows.Count<6)throw new Exception("Reporte de cambios incompleto.");
            await Seed(202,"DROP_DB_USER",database);
            using(var scope=ExecutionEvidenceScope.Begin(Request(202,"DROP_DB_USER"),"fixture-admin",gateway,1))
            {
                await using var lease=await TrackedSqlConnection.OpenAsync(builder.ConnectionString,CancellationToken.None);
                await TrackedSqlConnection.TagChangeAsync(lease.Connection,null,"DROP_DB_USER",login);
                await using var drop=new SqlCommand($"DROP USER [{login}]",lease.Connection);
                await TrackedSqlConnection.ExecuteCommandAsync(drop,CancellationToken.None);
            }
            await Task.Delay(1100);await Execute($"CREATE USER [{login}] FOR LOGIN [{login}];");
            userReference=await TrackedSqlConnection.ReadPrincipalMetadataAsync(cn,null,login,false,CancellationToken.None);
            await gateway.ImportPrincipalMetadataAsync(1,[userReference!],CancellationToken.None);
            if(await Scalar("SELECT COUNT(*) FROM access.PrincipalMetadataSnapshot WHERE PrincipalKind='DATABASE_USER' AND ModificationOrigin='EXTERNAL'")!=1)
                throw new Exception("Una baja confirmada bloqueó la observación del usuario recreado.");
            await Seed(105,"CHANGE_LOGIN_PASSWORD","master");
            using(var scope=ExecutionEvidenceScope.Begin(Request(105,"CHANGE_LOGIN_PASSWORD"),"fixture-admin",gateway,1))
            {
                await using var lease=await TrackedSqlConnection.OpenAsync(builder.ConnectionString,CancellationToken.None);
                await TrackedSqlConnection.TagChangeAsync(lease.Connection,null,"CHANGE_LOGIN_PASSWORD",login);
                // Simular caída después de reservar, sin inventar respuesta del motor.
            }
            if((await gateway.RefreshSecuritySummaryAsync()).UnresolvedEvents!=1||await Scalar("SELECT SUM(ChangeCount) FROM access.AppPasswordDaily")!=4)
                throw new Exception("Un resultado incierto sumó contraseñas o desapareció del resumen.");
            // Identidad recreada: mismo nombre, SID diferente, referencia nueva sin falso externo.
            var snapshot=await TrackedSqlConnection.ReadPrincipalMetadataAsync(cn,null,login,true,CancellationToken.None);
            await gateway.ImportPrincipalMetadataAsync(1,[snapshot! with{Sid="0102030405"}],CancellationToken.None);
            if(await Scalar("SELECT COUNT(*) FROM access.PrincipalMetadataSnapshot WHERE PrincipalSid=0x0102030405 AND ModificationOrigin='BASELINE'")!=1)throw new Exception("Se confundieron identidades con el mismo nombre.");
            await Execute("EXEC sys.sp_set_session_context N'Lab.Denied',N'REVIEW_REQUEST';");
            try
            {
                var failed=false;
                await using var denied=new SqlCommand("EXEC access.usp_PrincipalMetadata_Import 1,N'[]';",cn);
                try{await denied.ExecuteNonQueryAsync();}catch(SqlException error)when(error.Number==51001){failed=true;}
                if(!failed)throw new Exception("El importador ignoró los permisos.");
            }
            finally{await Execute("EXEC sys.sp_set_session_context N'Lab.Denied',NULL;");}
            Console.WriteLine("LAB_SQL_RESULT Seguimiento real sin captura instalada: 4 cambios de contraseña desde C#, umbral 3, reentrega, origen externo por fecha, referencia inicial/SID, rollback/commit, permisos y reportes correctos.");
            return 0;
        }
        finally
        {
            await Execute($"IF DATABASE_PRINCIPAL_ID(N'{login}') IS NOT NULL DROP USER [{login}]; IF SUSER_ID(N'{login}') IS NOT NULL DROP LOGIN [{login}];");
        }
    }
}
