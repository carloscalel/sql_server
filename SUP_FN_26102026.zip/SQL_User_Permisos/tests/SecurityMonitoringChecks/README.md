# Comprobaciones de seguimiento de la app y metadatos

```powershell
dotnet run --project .\tests\SecurityMonitoringChecks -c Release -- .\artifacts\security-monitoring-previews
```

Comprueba vigencias, día de Guatemala, umbral 3, flujo de extensión/cierre, ticket validado, alertas persistentes, autorizaciones de la ventana de alertas, cancelación/fallos/respuestas tardías, filtros, exportaciones PDF/CSV/Excel, renders WPF y sintaxis de los scripts centrales. No conecta a SQL Server.

La biblioteca ScriptDom es una dependencia **de pruebas de sintaxis**, no del cliente ni del worker.

## Laboratorio SQL aislado

```powershell
.\tests\SecurityMonitoringChecks\RunSqlLab.ps1 -Server localhost -TrustCertificate
```

Requiere una instancia DBA de pruebas. Crea una base y un login con GUID exclusivo, convierte desde el contrato UTC con 36 y ejecuta el 33 v4 real con sustitutos de identidad/ticket, usa la instrumentación C# real y el comando parametrizado de contraseñas WPF. Comprueba cuatro cambios reales, umbral, idempotencia, revisión, referencia inicial, coincidencia de la app, última fecha externa sin sumarla al contador, SID diferente con mismo nombre, rollback/commit y permisos. Reaplica 36/33 verificando conservación de horas y datos. Comprueba hashes originales intactos, cadena de auditoría mixta, adulteración de fecha visible, medianoche y normalización de fechas de motores en otros husos.

No instala captura, trigger de servidor ni Audit; no modifica `adminDB` ni cuentas existentes. Elimina únicamente su login/base aleatorios al terminar. Las comprobaciones de vigencias usan objetos auxiliares del laboratorio y no sustituyen pruebas de roles, tickets, carga y red del entorno real. El laboratorio anterior está archivado como referencia histórica y no es parte de esta ejecución.

Vistas generadas: `artifacts/security-monitoring-previews`. Todos sus registros son datos simulados.
