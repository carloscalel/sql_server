using System.Data;
using System.Diagnostics;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Threading;
using Microsoft.SqlServer.TransactSql.ScriptDom;
using SqlAccessAdmin;
using SqlAccessAdmin.Data;
using SqlAccessAdmin.Infrastructure;
using SqlAccessAdmin.Models;
using SqlAccessAdmin.ViewModels;
using SqlAccessAdmin.Views;

internal static class Program
{
    private static int _checks;
    [STAThread]
    private static int Main(string[] args)
    {
        try
        {
            if(args.FirstOrDefault()=="--sql-lab")return SqlMonitoringLab.RunAsync(args[1],args[2],args.Contains("--trust-certificate")).GetAwaiter().GetResult();
            var app=new App();app.InitializeComponent();
            SynchronizationContext.SetSynchronizationContext(new DispatcherSynchronizationContext());
            var output=Path.GetFullPath(args.FirstOrDefault()??"artifacts/security-monitoring-previews");Directory.CreateDirectory(output);
            Rules();ParseSql();
            var store=new FakeStore();
            using var temporaries=new TemporaryAccessViewModel(store,new("admin",AppRole.Administrator),(_,_)=>Task.FromResult("Cierre SQL confirmado"),_=>true);
            Run(temporaries.LoadAsync());temporaries.Selected=temporaries.Accesses.Single();
            Check(temporaries.Selected.StateDisplay=="Vencido / Pendiente de revisión"&&store.ActiveAlert,"Vencido conserva acceso y alerta activa");
            temporaries.Ticket="TIC-CH-123";
            Check(!temporaries.ExtendCommand.CanExecute(null)&&!temporaries.CloseCommand.CanExecute(null),"Temporal exige validar ticket antes de solicitar");
            Run(temporaries.VerifyTicketAsync());
            Check(temporaries.IsTicketValid&&temporaries.Reason=="Motivo autorizado del ticket de pruebas","Temporal obtiene motivo del ticket validado");
            temporaries.Ticket="TIC-CH-124";
            Check(!temporaries.IsTicketValid&&temporaries.Reason==""&&!temporaries.ExtendCommand.CanExecute(null),"Cambiar ticket invalida validación y motivo");
            Run(temporaries.VerifyTicketAsync());
            temporaries.ExpiryDate=SqlAccessAdmin.Infrastructure.AppTime.Now.AddDays(3).Date;temporaries.ExpiryTime="18:15:30";
            temporaries.ExtendCommand.Execute(null);Pump();
            Check(store.Item.Revision==1&&store.ActiveAlert&&store.Queue.Single().Status=="PENDING","Solicitar extensión no cambia vigencia ni alerta");
            temporaries.SelectedAction=temporaries.Actions.Single();temporaries.ApproveCommand.Execute(null);Pump();
            Check(store.Queue.Single().Status=="APPROVED"&&store.ActiveAlert,"Confirmar sin ejecutar conserva alerta");
            Run(temporaries.ExecuteAsync());
            Check(store.Item.Revision==2&&!store.ActiveAlert&&store.Queue.Single().Status=="EXECUTED","Extensión aplicada resuelve alerta de la revisión anterior");
            Check(store.Item.State=="ACTIVE","Extensión mantiene el acceso abierto");
            using var auditor=new TemporaryAccessViewModel(store,new("auditor",AppRole.Auditor),(_,_)=>throw new Exception("No debe ejecutar"),_=>true);
            Run(auditor.LoadAsync());auditor.Selected=auditor.Accesses.Single();auditor.SelectedAction=auditor.Actions.Single();
            Check(!auditor.ExtendCommand.CanExecute(null)&&!auditor.CloseCommand.CanExecute(null)&&!auditor.ExecuteCommand.CanExecute(null),"Auditor consulta temporales sin ejecutar acciones");
            CloseFailure();TicketValidation();AlertReview();
            var exporter=new FakeExport();var save=new FakeSave();
            using var report=new SecurityReportsViewModel(store,SecurityReportKind.AccessChanges,_=>Task.FromResult<IReadOnlyList<ServerItem>>([new(){Id=1,Name="Producción SQL"}]),exporter,save);
            Run(report.InitializeAsync());Run(report.QueryAsync());Check(report.RowCount==2,"Reporte central devuelve eventos");
            report.Filter="ANA";Check(report.RowCount==1,"Búsqueda por principal sin distinguir mayúsculas");
            foreach(var command in new[]{report.PdfCommand,report.CsvCommand,report.ExcelCommand}){command.Execute(null);Pump();Check(exporter.Last is not null&&!exporter.Last.Sections.SelectMany(s=>s.Rows).SelectMany(r=>r).Any(v=>Equals(v,"Luis")),"Exportar conserva filtro visible");}
            Check(exporter.Last!.Filters.Contains("Guatemala"),"Exportación identifica zona y período");
            report.Filter="";report.Rows!.Sort="[Principal] DESC";report.CsvCommand.Execute(null);Pump();
            Check((string?)exporter.Last!.Sections[0].Rows[0][0]=="Luis","Exportar respeta orden visible");
            report.ToDate=report.FromDate!.Value.AddDays(-1);Run(report.QueryAsync());Check(report.Rows is null&&report.Status.Contains("período"),"Rango inválido no conserva resultados exportables");
            report.FromDate=SqlAccessAdmin.Infrastructure.AppTime.Now.Date.AddDays(-7);report.ToDate=SqlAccessAdmin.Infrastructure.AppTime.Now.Date;Run(report.QueryAsync());
            LateReport(store);Run(RealExportsAsync(exporter.Last!,output));
            var longText=string.Join('\n',Enumerable.Repeat("SELECT dbo.Factura · "+new string('x',150),80));
            var pdfLayout=SecurityReportsViewModel.ToPdfLayout(exporter.Last! with{Sections=[new("Detalle",[new("Comando")],[new object?[]{longText}])]});
            Check(pdfLayout.Sections[0].Columns.Count==2&&string.Concat(pdfLayout.Sections[0].Rows.Select(r=>r[1]))==longText,"PDF conserva íntegro un comando largo sin una fila imposible de paginar");
            Run(new ReportExportService().ExportAsync(pdfLayout,Path.Combine(output,"detalle-largo.pdf"),ReportExportFormat.Pdf,CancellationToken.None));
            var bindings=new StringWriter();PresentationTraceSources.DataBindingSource.Listeners.Add(new TextWriterTraceListener(bindings));PresentationTraceSources.DataBindingSource.Switch.Level=SourceLevels.Error;
            Render(new DashboardView{DataContext=new DashboardPreview
            {
                ExpiredAccessCount="1",PasswordAlertCount="1",UnresolvedPasswordCount="0",LastEvidenceCollection="2026-10-22 12:00:00",
                SecurityStatus="Captura actualizada",Status="",Servers=2,Users=4,Session=new SessionContext("DOMINIO\\admin",AppRole.Administrator),RefreshCommand=new RelayCommand(()=>{}),
            }},Path.Combine(output,"resumen-alertas.png"),1100,900);
            AlertPreviews(output);
            var dashboard=new DashboardView{DataContext=new DashboardPreview()};
            Render(dashboard,Path.Combine(output,"resumen-sin-alertas.png"),950,800);
            Check(!VisualDescendants(dashboard).OfType<TextBox>().Any(),"Resumen no expone el campo de motivo ni un formulario de revisión");
            Render(new TemporaryAccessView{DataContext=temporaries},Path.Combine(output,"usuarios-temporales.png"),1100,850);
            Render(new TemporaryAccessView{DataContext=temporaries},Path.Combine(output,"usuarios-temporales-compacto.png"),950,620);
            var reviewView=new TemporaryAccessView{DataContext=temporaries};
            ((TabControl)reviewView.FindName("TemporaryTabs")).SelectedIndex=1;
            Render(reviewView,Path.Combine(output,"usuarios-temporales-revision.png"),1100,850);
            using(var empty=new TemporaryAccessViewModel(store,new("admin",AppRole.Administrator),(_,_)=>Task.FromResult(""),_=>true))
                Render(new TemporaryAccessView{DataContext=empty},Path.Combine(output,"usuarios-temporales-vacio.png"),950,620);
            Render(new TemporaryAccessView{DataContext=auditor},Path.Combine(output,"usuarios-temporales-auditor.png"),950,620);
            using(var expired=new TemporaryAccessViewModel(new FakeStore(),new("admin",AppRole.Administrator),(_,_)=>Task.FromResult(""),_=>true))
            {
                Run(expired.LoadAsync());expired.Selected=expired.Accesses.Single();
                Render(new TemporaryAccessView{DataContext=expired},Path.Combine(output,"usuarios-temporales-vencido.png"),1100,850);
            }
            Render(new SecurityReportsView{DataContext=report},Path.Combine(output,"cambios-accesos.png"),1100,760);
            using var passwords=new SecurityReportsViewModel(store,SecurityReportKind.PasswordChanges,_=>Task.FromResult<IReadOnlyList<ServerItem>>([]),exporter,save);
            Run(passwords.InitializeAsync());Run(passwords.QueryAsync());passwords.ShowHistoryCommand.Execute(null);Pump();
            Check(passwords.Kind==SecurityReportKind.PasswordHistory&&store.LastKind==SecurityReportKind.PasswordHistory,"Historial de contraseñas separado del ranking");
            Render(new SecurityReportsView{DataContext=passwords},Path.Combine(output,"cambios-contrasena.png"),1100,760);
            RenderNavigation(temporaries,Path.Combine(output,"menu-temporales.png"));
            Check(bindings.ToString().Length==0,"Enlaces WPF sin errores: "+bindings);
            Console.WriteLine($"{_checks} comprobaciones correctas. No se abrió SQL Server. Vistas: {output}");return 0;
        }
        catch(Exception error){Console.Error.WriteLine(error);return 1;}
    }
    private static void Rules()
    {
        var expiry=new DateTime(2026,10,23,0,0,0,DateTimeKind.Unspecified);
        Check(SecurityMonitoringRules.State(true,expiry,expiry.AddTicks(-1))=="ACTIVE","Antes del límite sigue vigente");
        Check(SecurityMonitoringRules.State(true,expiry,expiry)=="EXPIRED_REVIEW","Igualdad exacta cambia a pendiente");
        Check(SecurityMonitoringRules.State(false,expiry,expiry)=="CLOSED","Solo cierre explícito cierra seguimiento");
        Check(SecurityMonitoringRules.ParseDateTime(new(2026,10,23),"00:00:00")==expiry,"Medianoche se conserva igual en interfaz y base de datos");
        var local=new DateTime(2026,10,26,17,5,0,DateTimeKind.Unspecified);
        Check(AppTime.FromUtc(new(2026,10,26,23,5,0,DateTimeKind.Utc))==local,"Una fecha universal se normaliza una sola vez a la hora de Guatemala");
        Check(AppTime.FromEngineLocal(new(2026,10,26,23,5,0),0)==local,"Metadatos de un motor en otra zona se normalizan a Guatemala");
        Check(AppTime.FromEngineLocal(local,-360)==local,"Un motor en Guatemala no aplica una segunda conversión");
        Check(AppTime.FromEngineLocal(new(2026,10,27,4,35,0),330)==local,"La normalización conserva la fecha al cambiar de día en otro huso");
        Check(SecurityMonitoringRules.Display(local)=="2026-10-26 17:05:00","Interfaz muestra la misma hora almacenada sin sufijo de zona");
        Check(SecurityMonitoringRules.ParseDateTime(local.Date,"17:05:00").Kind==DateTimeKind.Unspecified,"La vigencia se envía a SQL como hora local sin conversión implícita");
        Check(!SecurityMonitoringRules.PasswordAlertRequired(2)&&SecurityMonitoringRules.PasswordAlertRequired(3)&&SecurityMonitoringRules.PasswordAlertRequired(4),"Umbral inclusivo de tres cambios");
        var rejected=false;try{SecurityMonitoringRules.ParseDateTime(new(2026,10,23),"24:00:00");}catch(InvalidOperationException){rejected=true;}
        Check(rejected,"Hora inválida rechazada");
        var instance=new OperationResult("SQL","Instancia",true,"Aplicado");var target=new DatabaseItem{ServerId=1,Server="SQL",Name="master"};
        Check(SecurityMonitoringRules.AppliedToTarget(instance,target,"SERVER_PERMISSION_CHANGE"),"Un permiso de instancia aplicado se registra con destino master aunque el resultado diga Instancia");
        Check(!SecurityMonitoringRules.AppliedToTarget(instance,target,"PERMISSION_CHANGE"),"Un resultado de instancia no se confunde con un permiso de base");
        Check(SecurityMonitoringRules.AppliedToTarget(instance with{Server="Nombre actualizado"},target,"SERVER_PERMISSION_CHANGE"),"Renombrar el catálogo no pierde seguimiento de una solicitud de servidor único");
    }
    private static void ParseSql()
    {
        var root=Directory.GetCurrentDirectory();
        foreach(var path in new[]{"InsumosProduccion/33_MonitoreoSeguridadYTemporales.sql","InsumosProduccion/36_HoraLocalGuatemala.sql","InsumosProduccion/99_ValidarInstalacion.sql"})
        {
            new TSql170Parser(true).Parse(new StringReader(File.ReadAllText(Path.Combine(root,path))),out var errors);
            Check(errors.Count==0,$"Sintaxis SQL {path}: "+string.Join(" | ",errors.Select(e=>$"L{e.Line}: {e.Message}")));
        }
    }
    private static void AlertReview()
    {
        var store=new FakeAlertsStore();var updated=0;
        using var vm=new SecurityAlertsViewModel(store,new("admin",AppRole.Administrator),onReviewed:()=>{updated++;return Task.CompletedTask;},confirm:_=>true);
        Run(vm.LoadAsync());vm.Selected=vm.Alerts.First(x=>x.Type=="TEMPORARY_EXPIRED");vm.Reason="Revisado con el equipo de operación";
        Check(!vm.ReviewCommand.CanExecute(null)&&vm.TemporaryAccessCommand.CanExecute(null),"Vencimiento solo permite continuar en Usuarios temporales");
        Run(vm.ReviewAsync());Check(store.Resolved.Count==0,"Invocar revisión directamente no descarta vencimientos");
        var navigation="";vm.NavigationRequested+=target=>navigation=target;vm.TemporaryAccessCommand.Execute(null);
        Check(navigation=="TEMPORARY","Vencimiento solicita navegación al módulo temporal");
        vm.Selected=vm.Alerts.First(x=>x.Type=="PASSWORD_FREQUENCY");
        Check(vm.Reason==""&&!vm.ReviewCommand.CanExecute(null),"Cambiar de alerta limpia el motivo y exige constancia nueva");
        vm.Reason="corto";Check(!vm.ReviewCommand.CanExecute(null),"Motivo menor a diez caracteres no habilita revisión");
        vm.Reason="Revisado con el equipo de operación";Run(vm.ReviewAsync());
        Check(store.Resolved.Single().Id==2&&updated==1&&!vm.Alerts.Any(x=>x.Id==2)&&vm.Selected is null&&vm.Reason=="","Revisión confirmada guarda motivo, actualiza contadores y retira solo alerta atendida");
        Check(vm.Alerts.Single().Type=="TEMPORARY_EXPIRED","Revisar contraseña conserva el vencimiento pendiente");
        foreach(var role in new[]{AppRole.Operator,AppRole.ApproverExecutor})
        {
            var restrictedStore=new FakeAlertsStore();using var restricted=new SecurityAlertsViewModel(restrictedStore,new("consulta",role),confirm:_=>true);
            Run(restricted.LoadAsync());restricted.Selected=restricted.Alerts.Last();restricted.Reason="Motivo suficientemente largo";Run(restricted.ReviewAsync());
            Check(!restricted.ShowReview&&!restricted.ReviewCommand.CanExecute(null)&&restrictedStore.Resolved.Count==0,"Rol sin auditoría no puede registrar revisión: "+role);
        }
        var failedStore=new FakeAlertsStore{FailReview=true};using var failure=new SecurityAlertsViewModel(failedStore,new("auditor",AppRole.Auditor),confirm:_=>true);
        Run(failure.LoadAsync());failure.Selected=failure.Alerts.Last();failure.Reason="Verificación de cambios confirmada";Run(failure.ReviewAsync());
        Check(failure.ShowReview&&failure.Selected?.Id==2&&failure.Reason.Length>10&&failure.Status.Contains("No se pudo")&&failedStore.Resolved.Count==0,"Fallo al guardar conserva alerta y motivo para el Auditor");
        var cancelStore=new FakeAlertsStore();using var canceled=new SecurityAlertsViewModel(cancelStore,new("admin",AppRole.Administrator),confirm:_=>false);
        Run(canceled.LoadAsync());canceled.Selected=canceled.Alerts.Last();canceled.Reason="Revisión que no será confirmada";Run(canceled.ReviewAsync());
        Check(cancelStore.Resolved.Count==0&&canceled.Selected is not null,"Cancelar confirmación no registra revisión");
        canceled.ExpiredCommand.Execute(null);Check(canceled.FilteredAlerts.Count()==1&&canceled.Selected is null&&canceled.Reason=="","Filtro limpia selección y motivo de la alerta oculta");
        canceled.Search="sin coincidencias";Check(!canceled.FilteredAlerts.Any(),"Búsqueda de alertas informa lista vacía");
        var delayedStore=new FakeAlertsStore{Delay=new()};using var delayed=new SecurityAlertsViewModel(delayedStore,new("admin",AppRole.Administrator),confirm:_=>true);
        var loading=delayed.LoadAsync();delayed.Dispose();delayedStore.Delay.SetResult(delayedStore.Items);Run(loading);
        Check(delayed.Alerts.Count==0,"Respuesta tardía no publica alertas después de cerrar la ventana");
        var committedStore=new FakeAlertsStore();using var committed=new SecurityAlertsViewModel(committedStore,new("admin",AppRole.Administrator),onReviewed:()=>throw new Exception("Refresco fallido"),confirm:_=>true);
        Run(committed.LoadAsync());committed.Selected=committed.Alerts.Last();committed.Reason="Revisión registrada correctamente";Run(committed.ReviewAsync());
        Check(committedStore.Resolved.Count==1&&committed.Status.StartsWith("Revisión registrada")&&!committed.ReviewCommand.CanExecute(null),"Fallo posterior de refresco no presenta una revisión guardada como fallida");
    }
    private static void AlertPreviews(string output)
    {
        using var vm=new SecurityAlertsViewModel(new FakeAlertsStore(),new("admin",AppRole.Administrator),monitoringStatus:"Alertas centrales actualizadas.",confirm:_=>true);
        Run(vm.LoadAsync());vm.Selected=vm.Alerts.Last();vm.Reason="Se verificaron los cambios con el responsable de la cuenta.";
        var window=new SecurityAlertsWindow(vm);var content=(FrameworkElement)window.Content;window.Content=null;content.Margin=new Thickness(0);
        var surface=new Border{Padding=new Thickness(24),Child=content,DataContext=vm};
        Render(surface,Path.Combine(output,"ventana-alertas.png"),1120,720);
        Render(surface,Path.Combine(output,"ventana-alertas-compacta.png"),900,560);
        vm.Selected=vm.Alerts.First();Render(surface,Path.Combine(output,"ventana-alertas-vencimiento.png"),1120,720);
        using var empty=new SecurityAlertsViewModel(new FakeAlertsStore{Items=[]},new("admin",AppRole.Administrator));Run(empty.LoadAsync());
        Render(new SecurityAlertsView{DataContext=empty},Path.Combine(output,"ventana-alertas-vacia.png"),852,510);
        using var restricted=new SecurityAlertsViewModel(new FakeAlertsStore(),new("operador",AppRole.Operator));Run(restricted.LoadAsync());restricted.Selected=restricted.Alerts.Last();
        Render(new SecurityAlertsView{DataContext=restricted},Path.Combine(output,"ventana-alertas-consulta.png"),852,510);
        var confirmation=new ConfirmationWindow("Registrar revisión","Registrar la revisión de integracion en Producción SQL.\n\nSe verificaron los cambios con el responsable de la cuenta.\n\nEl historial y el contador se conservan.","Registrar revisión","ALERTAS DE SEGURIDAD");
        var confirmationContent=(FrameworkElement)confirmation.Content;confirmation.Content=null;confirmationContent.DataContext=confirmation;confirmationContent.Margin=new Thickness(16);
        Render(new Border{Padding=new Thickness(16),Child=confirmationContent},Path.Combine(output,"confirmacion-alerta.png"),550,430);
    }
    private static IEnumerable<DependencyObject> VisualDescendants(DependencyObject root)
    {
        for(var i=0;i<VisualTreeHelper.GetChildrenCount(root);i++)
        {var child=VisualTreeHelper.GetChild(root,i);yield return child;foreach(var nested in VisualDescendants(child))yield return nested;}
    }
    private static void TicketValidation()
    {
        var store=new FakeStore();
        using var vm=new TemporaryAccessViewModel(store,new("admin",AppRole.Administrator),(_,_)=>Task.FromResult(""),_=>true);
        Run(vm.LoadAsync());vm.Selected=vm.Accesses.Single();vm.Ticket="tic-ch-123";
        vm.VerifyTicketCommand.Execute(null);Pump();
        Check(vm.IsTicketValid&&vm.CloseCommand.CanExecute(null),"Botón valida mediante el contrato compartido de tickets");
        store.TicketLookup=_=>Task.FromResult<ExternalTicketDetails?>(null);Run(vm.VerifyTicketAsync());
        Check(!vm.IsTicketValid&&vm.Reason==""&&!vm.CloseCommand.CanExecute(null),"Ticket inexistente elimina validación anterior y bloquea cierre");
        store.TicketLookup=_=>Task.FromResult<ExternalTicketDetails?>(new("","","OTRO","","Descripción válida de otro ticket","Activo"));Run(vm.VerifyTicketAsync());
        Check(!vm.IsTicketValid&&vm.Reason=="","Identificador distinto no habilita solicitudes temporales");
        store.TicketLookup=_=>Task.FromException<ExternalTicketDetails?>(new InvalidOperationException("Sin conexión"));Run(vm.VerifyTicketAsync());
        Check(!vm.IsTicketValid&&vm.TicketValidationMessage.Contains("Sin conexión"),"Error de consulta conserva bloqueo e informa el fallo");
        store.TicketLookup=number=>Task.FromResult<ExternalTicketDetails?>(new("","",number,"Asunto utilizado como motivo","","Activo"));Run(vm.VerifyTicketAsync());
        Check(vm.IsTicketValid&&vm.Reason=="Asunto utilizado como motivo","Sin descripción se utiliza asunto del ticket");
        var pending=new TaskCompletionSource<ExternalTicketDetails?>();store.TicketLookup=_=>pending.Task;
        var validation=vm.VerifyTicketAsync();vm.Ticket="TIC-CH-456";vm.Ticket="TIC-CH-123";
        pending.SetResult(new("","","TIC-CH-123","","Descripción de respuesta tardía","Activo"));Run(validation);
        Check(!vm.IsTicketValid&&vm.Reason=="","Respuesta tardía no valida un ticket editado durante la consulta");
    }
    private static void CloseFailure()
    {
        var store=new FakeStore();
        using var vm=new TemporaryAccessViewModel(store,new("admin",AppRole.Administrator),(_,_)=>throw new InvalidOperationException("SQL no confirmó el cierre"),_=>true);
        Run(vm.LoadAsync());vm.Selected=vm.Accesses.Single();vm.Ticket="TIC-CH-321";Run(vm.VerifyTicketAsync());vm.CloseCommand.Execute(null);Pump();
        vm.SelectedAction=vm.Actions.Single();vm.ApproveCommand.Execute(null);Pump();Run(vm.ExecuteAsync());
        Check(store.ActiveAlert&&store.Item.State=="EXPIRED_REVIEW"&&store.Queue.Single().Status=="FAILED","Cierre fallido conserva alerta y acceso pendiente");
    }
    private static void LateReport(FakeStore store)
    {
        using var vm=new SecurityReportsViewModel(store,SecurityReportKind.AccessChanges,_=>Task.FromResult<IReadOnlyList<ServerItem>>([]));
        Run(vm.InitializeAsync());store.Delay=new(TaskCreationOptions.RunContinuationsAsynchronously);
        var pending=vm.QueryAsync();vm.FromDate=vm.FromDate!.Value.AddDays(-1);store.Delay.SetResult(FakeStore.Data());Run(pending);
        Check(vm.Rows is null,"Respuesta tardía no repone datos tras cambiar contexto");store.Delay=null;
    }
    private static async Task RealExportsAsync(ReportExportDocument document,string output)
    {
        foreach(var format in Enum.GetValues<ReportExportFormat>())
        {
            var path=Path.Combine(output,"reporte-seguridad"+(format==ReportExportFormat.Pdf?".pdf":format==ReportExportFormat.Csv?".csv":".xlsx"));
            await new ReportExportService().ExportAsync(document,path,format,CancellationToken.None);
            Check(new FileInfo(path).Length>100,"Exportación real "+format);
        }
    }
    private static void RenderNavigation(object current,string path)
    {
        var window=new MainWindow{DataContext=new NavigationFixture(current)};
        var tree=(TreeView)window.FindName("ReportsNavigation");((TreeViewItem)tree.Items[0]).IsExpanded=true;
        var content=(FrameworkElement)window.Content;window.Content=null;content.Resources=window.Resources;content.DataContext=window.DataContext;
        Render(content,path,1360,950);
    }
    private static void Render(FrameworkElement view,string path,int width,int height)
    {
        view.Width=width;view.Height=height;view.Measure(new(width,height));view.Arrange(new(0,0,width,height));view.UpdateLayout();Pump();
        var background=new DrawingVisual();using(var draw=background.RenderOpen())draw.DrawRectangle(new SolidColorBrush(Color.FromRgb(244,247,252)),null,new(0,0,width,height));
        var bitmap=new RenderTargetBitmap(width,height,96,96,PixelFormats.Pbgra32);bitmap.Render(background);bitmap.Render(view);
        var encoder=new PngBitmapEncoder();encoder.Frames.Add(BitmapFrame.Create(bitmap));using var file=File.Create(path);encoder.Save(file);
    }
    private static void Run(Task task)
    {
        while(!task.IsCompleted){Pump();Thread.Sleep(1);}task.GetAwaiter().GetResult();Pump();
    }
    private static void Pump(){var frame=new DispatcherFrame();Dispatcher.CurrentDispatcher.BeginInvoke(DispatcherPriority.Background,new Action(()=>frame.Continue=false));Dispatcher.PushFrame(frame);}
    private static void Check(bool value,string message){if(!value)throw new InvalidOperationException(message);_checks++;}
}

internal sealed class DashboardPreview
{
    public string ExpiredAccessCount {get;set;}="";
    public string PasswordAlertCount {get;set;}="";
    public string UnresolvedPasswordCount {get;set;}="";
    public string LastEvidenceCollection {get;set;}="";
    public string SecurityStatus {get;set;}="";
    public string Status {get;set;}="";
    public int Servers {get;set;}
    public int Users {get;set;}
    public SessionContext Session {get;set;}=new("preview",AppRole.Administrator);
    public RelayCommand RefreshCommand {get;set;}=new(()=>{});
    public RelayCommand ShowSecurityAlertsCommand {get;}=new(()=>{});
    public RelayCommand ShowExpiredAlertsCommand {get;}=new(()=>{});
    public RelayCommand ShowPasswordAlertsCommand {get;}=new(()=>{});
    public RelayCommand ShowPasswordHistoryCommand {get;}=new(()=>{});
}

internal sealed class FakeAlertsStore : ISecurityAlertsStore
{
    public List<SecurityAlertItem> Items=[new(1,"TEMPORARY_EXPIRED","ana","Producción SQL","SELECT · Ventas · dbo.Factura. Requiere extensión o cierre mediante una solicitud con ticket.",SqlAccessAdmin.Infrastructure.AppTime.Now),
        new(2,"PASSWORD_FREQUENCY","integracion","Producción SQL","Se confirmaron 3 cambios de contraseña en el mismo día calendario de Guatemala. Revise el historial y documente el resultado.",SqlAccessAdmin.Infrastructure.AppTime.Now)];
    public List<(long Id,string Reason)> Resolved=[];
    public bool FailReview;
    public TaskCompletionSource<IReadOnlyList<SecurityAlertItem>>? Delay;
    public Task<IReadOnlyList<SecurityAlertItem>> GetActiveSecurityAlertsAsync(CancellationToken ct=default)=>Delay?.Task??Task.FromResult<IReadOnlyList<SecurityAlertItem>>(Items.ToList());
    public Task ResolvePasswordAlertAsync(long id,string reason,CancellationToken ct=default)
    {
        if(FailReview)throw new InvalidOperationException("No se pudo guardar en el pivote.");
        Resolved.Add((id,reason));Items.RemoveAll(x=>x.Id==id);return Task.CompletedTask;
    }
}

internal sealed class FakeStore : ISecurityMonitoringStore
{
    public Func<string,Task<ExternalTicketDetails?>> TicketLookup=number=>Task.FromResult<ExternalTicketDetails?>(new("Operador","Cliente",number,"Solicitud","Motivo autorizado del ticket de pruebas","Activo"));
    public Task<ExternalTicketDetails?> VerifyExternalTicketAsync(string ticket,CancellationToken ct=default)=>TicketLookup(ticket);
    internal TemporaryAccessItem Item=new(1,1,"Producción SQL","ana",[1,2,3],"PERMISSION","Ventas","OBJECT","dbo.Factura","SELECT","",SqlAccessAdmin.Infrastructure.AppTime.Now.AddHours(-1),"EXPIRED_REVIEW",1,new byte[8],99);
    internal bool ActiveAlert=true;
    internal List<TemporaryAccessAction> Queue=[];
    internal TaskCompletionSource<DataTable>? Delay;
    internal SecurityReportKind LastKind;
    public Task<SecurityMonitoringSummary> RefreshSecuritySummaryAsync(CancellationToken ct=default)=>Task.FromResult(new SecurityMonitoringSummary(ActiveAlert?1:0,1,0,SqlAccessAdmin.Infrastructure.AppTime.Now,SqlAccessAdmin.Infrastructure.AppTime.Now));
    public Task<IReadOnlyList<TemporaryAccessItem>> GetTemporaryAccessesAsync(CancellationToken ct=default)=>Task.FromResult<IReadOnlyList<TemporaryAccessItem>>([Item]);
    public Task<IReadOnlyList<TemporaryAccessAction>> GetTemporaryActionsAsync(CancellationToken ct=default)=>Task.FromResult<IReadOnlyList<TemporaryAccessAction>>(Queue.ToList());
    public Task RequestTemporaryActionAsync(TemporaryAccessItem item,string action,DateTime? expiresAt,string ticket,string reason,CancellationToken ct=default)
    {Queue.Add(new(Queue.Count+1,item.Id,action,"PENDING",ticket,reason,"admin",SqlAccessAdmin.Infrastructure.AppTime.Now,expiresAt,""));return Task.CompletedTask;}
    public Task ReviewTemporaryActionAsync(long id,bool approve,CancellationToken ct=default){var i=Queue.FindIndex(a=>a.Id==id);Queue[i]=Queue[i] with{Status=approve?"APPROVED":"REJECTED"};return Task.CompletedTask;}
    public Task<TemporaryAccessItem> BeginTemporaryActionAsync(long id,CancellationToken ct=default){var i=Queue.FindIndex(a=>a.Id==id);Queue[i]=Queue[i] with{Status="EXECUTING"};return Task.FromResult(Item);}
    public Task CompleteTemporaryActionAsync(long id,bool success,string detail,CancellationToken ct=default)
    {var i=Queue.FindIndex(a=>a.Id==id);var a=Queue[i];Queue[i]=a with{Status=success?"EXECUTED":"FAILED",Result=detail};if(success){ActiveAlert=false;Item=Item with{Revision=Item.Revision+1,ExpiresAt=a.NewExpiresAt??Item.ExpiresAt,State=a.Action=="EXTEND"?"ACTIVE":"CLOSED"};}return Task.CompletedTask;}
    public Task<DataTable> GetSecurityReportAsync(SecurityReportKind kind,DateTime from,DateTime to,int? serverId,CancellationToken ct=default){LastKind=kind;return Delay?.Task??Task.FromResult(Data());}
    internal static DataTable Data(){var t=new DataTable();t.Columns.Add("Principal");t.Columns.Add("Cambio");t.Columns.Add("Fuente");t.Rows.Add("Ana","GRANT SELECT dbo.Factura","Aplicación");t.Rows.Add("Luis","Última modificación observada","Externo — sin registro en la app");return t;}
}
internal sealed class FakeExport : IReportExportService
{internal ReportExportDocument? Last;public Task ExportAsync(ReportExportDocument document,string path,ReportExportFormat format,CancellationToken ct){Last=document;return Task.CompletedTask;}}
internal sealed class FakeSave : IReportSaveDialog
{public ReportExportScope? ChooseScope(ReportExportFormat format,string section)=>ReportExportScope.FullReport;public string? ChoosePath(ReportExportFormat format,string name)=>"unused";}
internal sealed class NavigationFixture(object current)
{
    public object Current=>current;public string Title=>"Usuarios temporales";public SessionContext Session=>new("DOMINIO\\administrador",AppRole.Administrator);
    public bool CanAnyReports=>true;public bool HasSessionError=>false;public string SessionStatus=>"";public ReportKind? ActiveReport=>null;
    private static readonly RelayCommand Noop=new(()=>{});
    public RelayCommand DashboardCommand=>Noop;public RelayCommand AccessCommand=>Noop;public RelayCommand TemporaryAccessCommand=>Noop;
    public RelayCommand UserPermissionsReportCommand=>Noop;public RelayCommand RoleCatalogReportCommand=>Noop;public RelayCommand CredentialAgeReportCommand=>Noop;
    public RelayCommand AccessChangesReportCommand=>Noop;public RelayCommand PasswordChangesReportCommand=>Noop;public RelayCommand RequestHistoryCommand=>Noop;
    public RelayCommand ServersCommand=>Noop;public RelayCommand UsersCommand=>Noop;public RelayCommand PolicyCommand=>Noop;public RelayCommand AuditCommand=>Noop;
}
