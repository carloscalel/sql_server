CREATE TABLE access.AuditEvent(AuditId bigint IDENTITY PRIMARY KEY,EventDate datetime2(3) NOT NULL DEFAULT SYSUTCDATETIME(),
 Principal nvarchar(256) NOT NULL,Form nvarchar(100) NOT NULL,Action nvarchar(100) NOT NULL,ServerName sysname NULL,DatabaseName sysname NULL,
 Success bit NOT NULL,Detail nvarchar(2000) NULL,CorrelationId uniqueidentifier NOT NULL,PreviousHash varbinary(32) NULL,EventHash varbinary(32) NULL);
CREATE TABLE access.AuthorizedPrincipal(UserId int PRIMARY KEY,CreatedAt datetime2(3) NOT NULL DEFAULT SYSUTCDATETIME());
GO
CREATE OR ALTER TRIGGER [access].tr_AuditEvent_AppendOnly ON [access].AuditEvent INSTEAD OF UPDATE,DELETE AS
BEGIN THROW 51300,'AuditEvent es append-only; UPDATE y DELETE están prohibidos.',1; END;
GO

CREATE OR ALTER PROCEDURE [access].usp_Audit_Write
    @Form nvarchar(100),@Action nvarchar(100),@ServerName sysname=NULL,@DatabaseName sysname=NULL,
    @Success bit,@Detail nvarchar(2000)=NULL,@CorrelationId uniqueidentifier=NULL
AS
BEGIN
 SET NOCOUNT ON;SET XACT_ABORT ON;
 DECLARE @LockResult int,@PreviousHash varbinary(32),@EventHash varbinary(32),@EventDate datetime2(3)=SYSUTCDATETIME(),@Principal nvarchar(256)=ORIGINAL_LOGIN(),@Correlation uniqueidentifier=COALESCE(@CorrelationId,NEWID()),@Payload nvarchar(max);
 BEGIN TRAN;
 EXEC @LockResult=sys.sp_getapplock @Resource=N'SqlAccessAdmin.AuditHashChain',@LockMode='Exclusive',@LockOwner='Transaction',@LockTimeout=10000;
 IF @LockResult<0 THROW 51320,'No fue posible bloquear la cadena de auditoría.',1;
 SELECT TOP(1) @PreviousHash=EventHash FROM [access].AuditEvent WITH(UPDLOCK,HOLDLOCK) WHERE EventHash IS NOT NULL ORDER BY AuditId DESC;
 SET @PreviousHash=COALESCE(@PreviousHash,CONVERT(varbinary(32),0x));
 SET @Payload=CONCAT(CONVERT(nvarchar(33),@EventDate,126),N'|',@Principal,N'|',@Form,N'|',@Action,N'|',COALESCE(@ServerName,N''),N'|',COALESCE(@DatabaseName,N''),N'|',CONVERT(nvarchar(1),@Success),N'|',COALESCE(@Detail,N''),N'|',CONVERT(nvarchar(36),@Correlation));
 SET @EventHash=HASHBYTES('SHA2_256',@PreviousHash+CONVERT(varbinary(max),@Payload));
 INSERT [access].AuditEvent(EventDate,Principal,Form,Action,ServerName,DatabaseName,Success,Detail,CorrelationId,PreviousHash,EventHash)
 VALUES(@EventDate,@Principal,@Form,@Action,@ServerName,@DatabaseName,@Success,@Detail,@Correlation,@PreviousHash,@EventHash);
 COMMIT;
END;
GO

CREATE OR ALTER PROCEDURE [access].usp_Audit_ValidateIntegrity
AS
BEGIN
 SET NOCOUNT ON;
 ;WITH c AS
 (
  SELECT AuditId,PreviousHash,EventHash,LAG(EventHash,1,CONVERT(varbinary(32),0x)) OVER(ORDER BY AuditId) ExpectedPrevious,
   HASHBYTES('SHA2_256',PreviousHash+CONVERT(varbinary(max),CONCAT(CONVERT(nvarchar(33),EventDate,126),N'|',Principal,N'|',Form,N'|',Action,N'|',COALESCE(ServerName,N''),N'|',COALESCE(DatabaseName,N''),N'|',CONVERT(nvarchar(1),Success),N'|',COALESCE(Detail,N''),N'|',CONVERT(nvarchar(36),CorrelationId)))) ExpectedHash
  FROM [access].AuditEvent WHERE EventHash IS NOT NULL
 )
 SELECT COUNT_BIG(*) HashedEvents,COALESCE(SUM(CASE WHEN PreviousHash=ExpectedPrevious THEN 0 ELSE 1 END),0) BrokenLinks,
        COALESCE(SUM(CASE WHEN EventHash=ExpectedHash THEN 0 ELSE 1 END),0) AlteredEvents,
        CAST(IIF(COALESCE(SUM(CASE WHEN PreviousHash=ExpectedPrevious AND EventHash=ExpectedHash THEN 0 ELSE 1 END),0)=0,1,0) AS bit) IsValid
 FROM c;
END;
GO

