param(
 [string]$Server='',
 [string]$ScriptDomPath='C:/Program Files/Microsoft SQL Server Management Studio 22/Release/Common7/IDE/Extensions/Application/Microsoft.SqlServer.TransactSql.ScriptDom.dll'
)
$ErrorActionPreference='Stop'
Add-Type -Path $ScriptDomPath
$repositoryRoot=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../..'))
$parser=[Microsoft.SqlServer.TransactSql.ScriptDom.TSql160Parser]::new($true)
function Parse-Sql([string]$sql,[string]$name) {
 $parseErrors=$null
 $fragment=$parser.Parse([IO.StringReader]::new($sql),[ref]$parseErrors)
 if($parseErrors.Count -gt 0){throw ($name+': '+(($parseErrors | ForEach-Object {"línea $($_.Line): $($_.Message)"}) -join '; '))}
 return $fragment
}
$migration=[IO.File]::ReadAllText((Join-Path $repositoryRoot 'InsumosProduccion/32_CambiarContrasenaLogin.sql'))
$tree=Parse-Sql $migration 'Migración 32'
$assignments=[Collections.Generic.List[object]]::new()
function Find-Replacements($node) {
 if($node -isnot [Microsoft.SqlServer.TransactSql.ScriptDom.TSqlFragment]){return}
 if($node -is [Microsoft.SqlServer.TransactSql.ScriptDom.SetVariableStatement] -and $node.Variable.Name -in '@Old','@New') {
  $assignments.Add($node)
 }
 foreach($property in $node.GetType().GetProperties()) {
  if($property.Name -eq 'ScriptTokenStream' -or $property.GetIndexParameters().Length -gt 0){continue}
  $value=$property.GetValue($node)
  if($value -is [Microsoft.SqlServer.TransactSql.ScriptDom.TSqlFragment]){Find-Replacements $value}
  elseif($value -is [Collections.IEnumerable] -and $value -isnot [string]) {
   foreach($child in $value){if($child -is [Microsoft.SqlServer.TransactSql.ScriptDom.TSqlFragment]){Find-Replacements $child}}
  }
 }
}
Find-Replacements $tree
if($assignments.Count -ne 8){throw 'Se esperaban cuatro pares de reemplazos explícitos.'}
$headerBlock=[regex]::Match($migration,'(?s)-- SqlAccessAdmin.LoginPasswordChange.HeaderStart(.*?)-- SqlAccessAdmin.LoginPasswordChange.HeaderEnd').Groups[1].Value
if(-not $headerBlock){throw 'No se encontró la normalización del encabezado del script 32.'}
$headerCases=[Collections.Generic.List[string]]::new()
$sources=@(
 @('usp_AccessRequest_AuthenticationValidate','24_AutenticacionSqlWindows.sql','ACCESS_REQUESTS'),
 @('usp_AccessRequest_Create','27_PoliticaAccesoPorInstanciaYBase.sql','CREATE_REQUEST'),
 @('usp_AccessRequest_TargetPolicyValidate','27_PoliticaAccesoPorInstanciaYBase.sql','ACCESS_REQUESTS'),
 @('usp_AccessRequest_List','23_DetalleCopiaPermisosPorBase.sql','ACCESS_REQUESTS')
)
for($index=0;$index -lt $sources.Count;$index++) {
 $name,$file,$permission=$sources[$index]
 $original=[IO.File]::ReadAllText((Join-Path $repositoryRoot ('InsumosProduccion/'+$file))).Replace("`r",'')
 $pattern='(?ms)^CREATE OR ALTER PROCEDURE \[access\]\.'+[regex]::Escape($name)+'\b.*?(?=^GO\s*$)'
 $definition=[regex]::Match($original,$pattern).Value
 if(-not $definition){throw ('No se encontró '+$name)}
 # Reproducir la guarda de 30 sin conectar a SQL Server.
 $begin=[regex]::new('(?m)^BEGIN$')
 $definition=$begin.Replace($definition,"BEGIN`n -- SqlAccessAdmin.MultiRoleGuard.v1 $permission`n EXEC [access].usp_App_RequirePermission '$permission';",1)
 $old=$assignments[2*$index].Expression.Value
 $new=$assignments[2*$index+1].Expression.Value
 if(([regex]::Matches($definition,[regex]::Escape($old))).Count -ne 1){throw ('Ancla ambigua o ausente: '+$name)}
 $transformed=$definition.Replace($old,$new)
 $body=$transformed.Substring('CREATE OR ALTER PROCEDURE'.Length)
 # Ejecutar el bloque T-SQL de producción sobre definiciones sintéticas, sin ALTER/CREATE reales.
 foreach($keyword in 'PROCEDURE','PROC') {
  foreach($separator in ' ',"   ","`t","`n","`r`n") {
   foreach($verb in 'CREATE','ALTER','CREATE OR ALTER') {
    $paddedVerb=$verb.Replace(' ',$separator)
    $inputHeader=$paddedVerb+$separator+$keyword
    $expectedHeader='ALTER'+$separator+$keyword
    foreach($leading in '',"`r`n`t ") {
     $inputDefinition=$leading+$inputHeader+$body
     $expectedDefinition=$expectedHeader+$body
     $headerCases.Add("(N'$name',N'"+$inputDefinition.Replace("'","''")+"',N'"+$expectedDefinition.Replace("'","''")+"')")
    }
   }
  }
 }
 $transformed=$transformed.Replace('CREATE OR ALTER PROCEDURE','ALTER PROCEDURE')
 $null=Parse-Sql $transformed $name
 if(-not $transformed.Contains('SqlAccessAdmin.MultiRoleGuard.v1 '+$permission) -or
    -not $transformed.Contains("usp_App_RequirePermission '$permission'")){throw ('Se perdió autorización: '+$name)}
 if(-not $transformed.Contains('SqlAccessAdmin.LoginPasswordChange.v1')){throw ('Falta marcador idempotente: '+$name)}
 Write-Output ($name+': transformación y sintaxis correctas; autorización conservada.')
}
$null=Parse-Sql ([IO.File]::ReadAllText((Join-Path $repositoryRoot 'InsumosProduccion/99_ValidarInstalacion.sql'))) 'Validación 99'
$parameterizedSql=Join-Path $repositoryRoot 'artifacts/password-preview/cambiar-contrasena-parametrizado.sql'
if(Test-Path -LiteralPath $parameterizedSql){$null=Parse-Sql ([IO.File]::ReadAllText($parameterizedSql)) 'Ejecutor parametrizado'}
$headerSql="SET NOCOUNT ON;
DECLARE @Cases table(Id int IDENTITY(1,1),Name sysname,Definition nvarchar(max),Expected nvarchar(max));
INSERT @Cases(Name,Definition,Expected) VALUES "+($headerCases -join ",`n")+";
DECLARE @Index int=1,@Name sysname,@Definition nvarchar(max),@Expected nvarchar(max),@NormalizedHeader nvarchar(512),@Message nvarchar(2048);
WHILE @Index<=(SELECT COUNT(*) FROM @Cases)
BEGIN
 SELECT @Name=Name,@Definition=Definition,@Expected=Expected FROM @Cases WHERE Id=@Index;
"+$headerBlock+"
 IF CONVERT(varbinary(max),@Definition)<>CONVERT(varbinary(max),@Expected)
  THROW 51616,'La normalización alteró el cuerpo o produjo un encabezado incorrecto.',1;
 SET @Index+=1;
END;
SELECT COUNT(*) AS EncabezadosValidados FROM @Cases;"
$null=Parse-Sql $headerSql 'Regresión de encabezados'
$outputDirectory=Join-Path $repositoryRoot 'artifacts/password-preview'
$null=New-Item -ItemType Directory -Path $outputDirectory -Force
$headerTestPath=Join-Path $outputDirectory 'comprobar-encabezados-32.sql'
[IO.File]::WriteAllText($headerTestPath,$headerSql,[Text.Encoding]::Unicode)
if($Server) {
 & sqlcmd -S $Server -E -d master -b -l 5 -i $headerTestPath
 if($LASTEXITCODE -ne 0){throw 'Falló la comprobación de encabezados en SQL Server.'}
 Write-Output 'Se ejecutó únicamente el bloque de normalización con variables de tabla; no se aplicaron migraciones ni se alteraron objetos.'
} else {
 Write-Output ('Migraciones 32/99 verificadas sin conexiones a SQL Server. Generada regresión SQL con '+$headerCases.Count+' variantes de encabezado.')
}
