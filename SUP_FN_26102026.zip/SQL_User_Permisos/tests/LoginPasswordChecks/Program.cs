using System.IO;
using System.Reflection;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Threading;
using SqlAccessAdmin;
using SqlAccessAdmin.Data;
using SqlAccessAdmin.Models;
using SqlAccessAdmin.ViewModels;
using SqlAccessAdmin.Views;

internal static class Program
{
    private static int _checks;
    [STAThread]
    private static void Main(string[] args)
    {
        var app=new App();app.InitializeComponent();
        var vm=CreateViewModel(AppRole.Operator);
        Check(!vm.CanRequestManagedLoginPasswordChange,"No se habilita sin ticket");
        Set(vm,"_verifiedExternalTicket",new ExternalTicketDetails("Operador","Cliente","TIC-CH-43442","Cambio de contraseña","Cambio autorizado de contraseña de pruebas","Activo"));
        Check(vm.CanRequestManagedLoginPasswordChange,"Operador con ticket validado puede solicitar");
        Check(vm.ChangeManagedLoginPasswordCommand.CanExecute(null),"El comando respeta la habilitación");
        Set(vm,"_selectedServerLogin",new ServerLoginItem("usuario_prueba","WINDOWS_LOGIN",true));
        Check(!vm.CanRequestManagedLoginPasswordChange,"Windows queda excluido");
        Set(vm,"_selectedServerLogin",new ServerLoginItem("usuario_prueba","SQL_LOGIN",false));
        Check(vm.CanRequestManagedLoginPasswordChange,"Un login SQL deshabilitado conserva la opción sin habilitarse");
        foreach(var busy in new[]{"_isSubmittingAccessRequest","_isSubmittingLoginStateChange","_isChangingManagedLoginPassword","_isVerifyingExternalTicket","_requestSubmitted"})
        {
            Set(vm,busy,true);Check(!vm.CanRequestManagedLoginPasswordChange,$"Bloqueo durante {busy}");Set(vm,busy,false);
        }
        vm.Operations.Clear();Check(!vm.CanRequestManagedLoginPasswordChange,"La operación requiere migración/política habilitada");
        vm.Operations.Add(new("CHANGE_LOGIN_PASSWORD","Cambiar contraseña",true,true,"HIGH",""));
        vm.ExternalTicketDigits="TIC-CH-43443";
        Check(!vm.CanRequestManagedLoginPasswordChange,"Editar el ticket invalida el acceso al formulario");
        foreach(var role in new[]{AppRole.Auditor,AppRole.ApproverExecutor})
        {
            var restricted=CreateViewModel(role);Set(restricted,"_verifiedExternalTicket",new ExternalTicketDetails("","","TIC-CH-43442","","Motivo válido de pruebas","Activo"));
            Check(!restricted.CanRequestManagedLoginPasswordChange,$"{role} no crea solicitudes");
        }
        Set(vm,"_isChangingManagedLoginPassword",true);
        Check(!vm.IsTemporaryPasswordValid,"Cambiar contraseña exige contraseña confirmada");
        vm.SuggestedPasswordLengthText="16";var shortest=vm.GenerateTemporaryPassword();
        Check(shortest.Length==16&&vm.IsTemporaryPasswordValid,"Generación mínima con complejidad y confirmación");
        vm.SuggestedPasswordLengthText="128";var longest=vm.GenerateTemporaryPassword();
        Check(longest.Length==128&&vm.IsTemporaryPasswordValid,"Generación máxima");
        vm.TemporaryPasswordConfirmation="diferente";Check(!vm.IsTemporaryPasswordValid,"Se bloquea una confirmación diferente");
        vm.TemporaryPassword=new string('A',129)+"a1!";vm.TemporaryPasswordConfirmation=vm.TemporaryPassword;
        Check(!vm.IsTemporaryPasswordValid,"No se truncan contraseñas mayores a 128 caracteres");
        vm.SuggestedPasswordLengthText="15";ExpectFailure(()=>vm.GenerateTemporaryPassword(),"Longitud inferior rechazada");
        vm.SuggestedPasswordLengthText="129";ExpectFailure(()=>vm.GenerateTemporaryPassword(),"Longitud superior rechazada");
        vm.PasswordPolicyEnabled=false;Check(!vm.PasswordExpirationEnabled&&!vm.MustChangePassword,"Desactivar política retira opciones incompatibles");
        vm.MustChangePassword=true;Check(!vm.MustChangePassword,"No se fuerza cambio sin política/expiración");
        vm.PasswordPolicyEnabled=true;vm.PasswordExpirationEnabled=true;vm.MustChangePassword=true;
        Check(vm.MustChangePassword,"Cambio obligatorio con opciones compatibles");
        vm.MustChangePassword=false;Check(!vm.MustChangePassword,"Contraseña permanente seleccionable");
        LoginPasswordChange.Validate("usuario","SQL",true,true,true,false);_checks++;
        ExpectFailure(()=>LoginPasswordChange.Validate("DOMINIO\\usuario","WINDOWS",true,true,true,true),"Servicio rechaza Windows");
        ExpectFailure(()=>LoginPasswordChange.Validate("usuario","SQL",false,true,true,true),"Servicio rechaza secreto ausente");
        ExpectFailure(()=>LoginPasswordChange.Validate("usuario","SQL",true,false,true,true),"Servicio rechaza opciones incompatibles");
        var build=typeof(DirectSqlServerService).GetMethod("BuildLoginPasswordChangeSql",BindingFlags.NonPublic|BindingFlags.Static)!;
        var sql=(string)build.Invoke(null,["usuario']prueba",true,true,true])!;
        Check(sql.Contains("QUOTENAME(@password")&&sql.Contains("@login")&&sql.Contains("sys.sql_logins"),"Ejecución parametrizada y comprobación real de login SQL");
        Check(sql.Contains("[usuario'']]prueba]")&&sql.Contains("MUST_CHANGE"),"El nombre se delimita y escapa dentro del SQL dinámico");
        var permanent=(string)build.Invoke(null,["usuario",true,false,false])!;
        Check(!permanent.Contains("MUST_CHANGE")&&permanent.Contains("CHECK_EXPIRATION=OFF"),"Cambio permanente no fuerza renovación");
        var request=new AccessRequestItem(1,"CHANGE_LOGIN_PASSWORD","usuario","","SQL","","","","","","TIC-CH-1","Motivo de prueba","PENDING","operador",SqlAccessAdmin.Infrastructure.AppTime.Now,"",null,1,0)
            {PasswordPolicy=true,PasswordExpiration=true,MustChangePassword=true};
        Check(request.Changes.Single().Description.Contains("obligatorio (contraseña temporal)"),"Confirmación presenta opciones del secreto");
        Check(!request.Changes.Single().Description.Contains(longest),"El secreto no aparece en el detalle");

        if(args.Length>0)
        {
            Directory.CreateDirectory(args[0]);
            File.WriteAllText(Path.Combine(args[0],"cambiar-contrasena-parametrizado.sql"),sql);
            Set(vm,"_verifiedExternalTicket",new ExternalTicketDetails("","","TIC-CH-43443","","Motivo válido de pruebas","Activo"));
            vm.SuggestedPasswordLengthText="20";vm.GenerateTemporaryPassword();vm.MustChangePassword=true;
            var window=new LoginPasswordChangeWindow {DataContext=vm};
            var dialogContent=(FrameworkElement)window.Content;window.Content=null;dialogContent.DataContext=vm;
            dialogContent.Measure(new(872,642));dialogContent.Arrange(new(0,0,872,642));dialogContent.UpdateLayout();
            var passwordEditor=FindVisual<LoginPasswordEditor>(dialogContent)!;
            ((PasswordBox)passwordEditor.FindName("TemporaryPasswordBox")).Password=vm.TemporaryPassword;
            ((PasswordBox)passwordEditor.FindName("TemporaryPasswordConfirmationBox")).Password=vm.TemporaryPassword;
            Render(dialogContent,872,642,Path.Combine(args[0],"cambiar-contrasena.png"));
            Set(vm,"_isChangingManagedLoginPassword",false);
            Set(vm,"_selectedServerLogin",new ServerLoginItem("usuario_prueba","SQL_LOGIN",true));
            Set(vm,"_externalTicketValidationMessage","✓ Ticket activo verificado: TIC-CH-43443");
            var editor=new AccessRequestEditor {DataContext=vm};
            Render(editor,1530,850,Path.Combine(args[0],"boton-cambiar-contrasena.png"));
            var passwordButton=(Button)editor.FindName("ManagedLoginPasswordActionButton");
            Check(passwordButton.IsEnabled,"Botón WPF habilitado con ticket y login SQL");
            vm.ExternalTicketDigits="TIC-CH-99999";
            Check(!passwordButton.IsEnabled,"Botón WPF deshabilitado inmediatamente al editar el ticket");
        }
        Console.WriteLine($"{_checks} comprobaciones correctas. Sin conexiones a SQL Server.");
        app.Shutdown();
    }

    private static AccessViewModel CreateViewModel(AppRole role)
    {
        // El carácter nulo provoca un error local al construir la conexión; no se abre ninguna conexión.
        var gateway=new AdminDbGateway(new("\0","","adminDB",true,null,null,true,false));
        var vm=new AccessViewModel(gateway,new DirectSqlServerService(gateway),new("prueba",role));
        Set(vm,"_selectedWorkingServer",new ServerItem{Id=1,Name="SQL PRUEBAS",Host="PRUEBAS",Active=true});
        Set(vm,"_selectedServerLogin",new ServerLoginItem("usuario_prueba","SQL_LOGIN",true));
        Set(vm,"_operation",new PolicyOperation("MODIFY_LOGIN","Modificar accesos",true,true,"HIGH",""));
        Set(vm,"_isManagingAccess",true);Set(vm,"_targetPrincipal","usuario_prueba");
        Set(vm,"_externalTicketDigits","TIC-CH-43442");Set(vm,"_justification","Cambio autorizado de contraseña de pruebas");
        vm.Operations.Add(new("CHANGE_LOGIN_PASSWORD","Cambiar contraseña",true,true,"HIGH",""));
        return vm;
    }
    private static void Set(object target,string field,object? value)=>target.GetType().GetField(field,BindingFlags.Instance|BindingFlags.NonPublic)!.SetValue(target,value);
    private static T? FindVisual<T>(DependencyObject root) where T:DependencyObject
    {
        if(root is T found)return found;
        for(var i=0;i<VisualTreeHelper.GetChildrenCount(root);i++)
            if(FindVisual<T>(VisualTreeHelper.GetChild(root,i)) is { } child)return child;
        return null;
    }
    private static void Check(bool condition,string name)
    {if(!condition)throw new InvalidOperationException(name);_checks++;}
    private static void ExpectFailure(Action action,string name)
    {try{action();}catch(InvalidOperationException){_checks++;return;}throw new InvalidOperationException(name);}
    private static void Render(FrameworkElement content,int width,int height,string path)
    {
        var border=new Border{Background=new SolidColorBrush(Color.FromRgb(246,248,252)),Child=content,Width=width,Height=height};
        border.Measure(new(width,height));border.Arrange(new(0,0,width,height));border.UpdateLayout();
        Dispatcher.CurrentDispatcher.Invoke(()=>{},DispatcherPriority.ContextIdle);
        var bitmap=new RenderTargetBitmap(width,height,96,96,PixelFormats.Pbgra32);bitmap.Render(border);
        var encoder=new PngBitmapEncoder();encoder.Frames.Add(BitmapFrame.Create(bitmap));
        using var file=File.Create(path);encoder.Save(file);
        _checks++;
    }
}
