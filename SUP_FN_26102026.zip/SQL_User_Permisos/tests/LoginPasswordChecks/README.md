# Comprobaciones del cambio de contraseña

Ejecutar desde la raíz en Windows:

```powershell
dotnet run --project tests/LoginPasswordChecks/LoginPasswordChecks.csproj
```

El ejecutable comprueba ticket obligatorio, roles, tipo de login, bloqueos durante envío, invalidación del ticket, longitudes, complejidad, confirmación, opciones compatibles y detalle de revisión sin secreto. No abre conexiones SQL. La reflexión prepara estados del ViewModel sin cargar catálogos externos.

Para generar vistas del formulario y del botón con los recursos WPF reales:

```powershell
dotnet run --project tests/LoginPasswordChecks/LoginPasswordChecks.csproj -- artifacts/password-preview
```

La prueba no demuestra permisos SQL reales ni sustituye la validación integral en una instancia de pruebas: aplicar 32 → 99, solicitar con ticket, confirmar, ejecutar, comprobar el nuevo inicio de sesión y MUST_CHANGE, rechazar otra solicitud y verificar que se descarta el sobre cifrado.

Con ScriptDom instalado (incluido en SSMS 22), también se puede comprobar la sintaxis de 32/99, las cuatro transformaciones sobre los contratos previos y la conservación de las guardas de autorización, sin ejecutar SQL:

```powershell
./tests/LoginPasswordChecks/CheckMigration.ps1
```

Use `-ScriptDomPath` si la biblioteca está en otra ubicación.

Para ejecutar la regresión de encabezados en un SQL Server accesible mediante autenticación Windows:

```powershell
./tests/LoginPasswordChecks/CheckMigration.ps1 -Server localhost
```

Evalúa el bloque de normalización extraído del script 32 sobre 240 variantes de CREATE, ALTER, CREATE OR ALTER, PROC/PROCEDURE, espacios, tabulaciones y saltos de línea. Usa únicamente variables de tabla en `master`: no aplica migraciones ni crea o altera objetos. Comprueba también que el cuerpo del procedimiento permanece intacto.
