# Comprobaciones de Reportes

Ejecutable Windows/.NET 8 WPF con dobles de `IReportsDataSource`. No necesita iniciar la aplicación ni modificar SQL Server.

```powershell
dotnet run --project .\tests\ReportsChecks
dotnet run --project .\tests\ReportsChecks -- .\artifacts\report-previews
```

Cubre selección de contexto, ejecución mediante ICommand, filtros de acción y miembros, roles vacíos, public implícito, fechas desconocidas, cuentas deshabilitadas, resultados vacíos, errores, cancelación y respuestas tardías de proveedores que ignoran el token. También carga las vistas WPF para detectar errores de XAML y enlaces. El modo de vistas previas renderiza los tres reportes con datos simulados y una vista de 1280×800 con el menú expandido.

También genera PDF, CSV y XLSX de los tres reportes. Reabre PDF y Excel, valida el esquema OpenXML, comprueba tipos de fecha/número, filtros y orden exportados, escape CSV, Unicode, protección frente a fórmulas, cancelación y errores de guardado. Comprueba que el catálogo omite miembros por defecto y que la selección explícita de uno o varios roles limita el detalle en los tres formatos, incluidos roles sin miembros, filtros que ocultan marcas y reinicio de la consulta. Genera un PDF de varias páginas para revisar el encabezado repetido. Las muestras quedan en `exports/` dentro de la carpeta de vistas previas; sin argumento se usa una carpeta temporal única. Las capturas verifican además que la cabecera Reportes coincide en posición y anchura con los demás botones del menú y que las casillas WPF actualizan la selección.

Comprobación opcional contra una instancia real, con autenticación integrada y certificado confiado solo por este ejecutable de pruebas local:

```powershell
dotnet run --project .\tests\ReportsChecks -- .\artifacts\report-previews --sql-smoke localhost
```

Ejecuta seis consultas reales de solo lectura en `master`: bases, logins, acceso de instancia, acceso de base por SID, roles y antigüedad de credenciales. También sustituye las vistas de sistema por variables de tabla para comprobar roles anidados, ciclos, sysadmin heredado, permisos de instancia y de base, propietarios y logins sin mapeo. El selector y el catálogo verifican tipos SQL/Windows y exclusión de internos, grupos y certificados. Las comprobaciones del ViewModel cubren varias bases, solo instancia, alias de usuario Windows, exportación con contexto, respuestas tardías y rechazo de resultados parciales. Las capturas muestran las tres pestañas y el selector de bases. Esos datos de prueba solo existen durante el lote. No instala objetos ni aplica migraciones. No sustituye la prueba integral con `adminDB`, conexiones de destinos e identidades del entorno de producción.
