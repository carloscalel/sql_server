/* Selección de cuentas existentes para agregar usuarios autorizados.
   Aplicar manualmente después de 30 y antes de 99. No crea logins ni concede
   permisos de instancia. Reaplicar 31 si se vuelve a ejecutar 29 o 30. */
USE [adminDB];
GO
IF OBJECT_ID(N'access.AppTimeConvention',N'U') IS NOT NULL THROW 51856,'La base ya usa hora de Guatemala. No reaplique migraciones históricas; use 36, 33 actualizado y 99.',1;
GO
SET NOCOUNT ON;
GO
IF OBJECT_ID(N'[access].AuthorizedPrincipalRole',N'U') IS NULL
 OR ISNULL(OBJECT_DEFINITION(OBJECT_ID(N'[access].usp_AuthorizedUser_Upsert',N'P')),N'') NOT LIKE N'%SqlAccessAdmin.MultiRoleMaintenance.v1%'
 THROW 51510, 'Aplique primero 30_RolesMultiplesYSeparacionSolicitudes.sql.', 1;
GO
CREATE OR ALTER PROCEDURE [access].usp_AuthorizedUser_AvailablePrincipals
AS
BEGIN
 SET NOCOUNT ON;
 -- SqlAccessAdmin.AvailablePrincipals.v1
 EXEC [access].usp_App_RequirePermission 'ADMIN';
 -- Evitar presentar un catálogo parcial por falta de visibilidad de metadatos.
 IF COALESCE(HAS_PERMS_BY_NAME(NULL,NULL,'VIEW ANY DEFINITION'),0)=0
    AND COALESCE(HAS_PERMS_BY_NAME(NULL,NULL,'VIEW ANY SECURITY DEFINITION'),0)=0
    AND COALESCE(HAS_PERMS_BY_NAME(NULL,NULL,'ALTER ANY LOGIN'),0)=0
    THROW 51512, 'El DBA debe habilitar la consulta de metadatos de logins para el administrador en la instancia de adminDB.', 1;
 SELECT p.name AS Principal,
        CONVERT(varchar(20),CASE p.type WHEN 'U' THEN 'WINDOWS' ELSE 'SQL_LOGIN' END) AS PrincipalType
 FROM sys.server_principals p
 WHERE p.type IN ('U','S') AND p.is_disabled=0 AND p.name NOT LIKE N'##%'
   AND NOT EXISTS(SELECT 1 FROM [access].AuthorizedPrincipal a WHERE a.Principal=p.name COLLATE DATABASE_DEFAULT)
 ORDER BY p.name;
END;
GO
CREATE OR ALTER PROCEDURE [access].usp_AuthorizedUser_Upsert
    @UserId int=NULL, @Principal nvarchar(256), @PrincipalType varchar(20),
    @RolesJson nvarchar(500), @Active bit, @Notes nvarchar(500)=NULL,
    @ExpectedRowVersion binary(8)=NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    -- SqlAccessAdmin.AuthorizedUserMaintenance.v1 / SqlAccessAdmin.MultiRoleMaintenance.v1
    DECLARE @PrimaryRole varchar(20), @OldRolesJson nvarchar(500), @Actor nvarchar(256), @CanonicalActor nvarchar(256), @LockResult int, @SavedId int,
            @OldPrincipal nvarchar(256), @OldType varchar(20), @OldRole varchar(20),
            @OldActive bit, @Version binary(8), @AdminCount int, @Detail nvarchar(2000);
    SET @Principal=LTRIM(RTRIM(@Principal));
    SET @Notes=NULLIF(LTRIM(RTRIM(@Notes)),N'');
    IF @Principal IS NULL OR @Principal=N''
        THROW 51002, 'Indique el principal que inicia sesión en adminDB.', 1;
    IF @RolesJson IS NULL OR ISJSON(@RolesJson)<>1 OR LEFT(LTRIM(@RolesJson),1)<>N'['
        THROW 51002,'Seleccione al menos un rol de aplicación válido.',1;
    IF NOT EXISTS(SELECT 1 FROM OPENJSON(@RolesJson))
       OR EXISTS(SELECT 1 FROM OPENJSON(@RolesJson) WHERE [type]<>1
          OR DATALENGTH([value])<>DATALENGTH(LTRIM(RTRIM([value])))
          OR [value] COLLATE Latin1_General_100_BIN2 NOT IN(N'Administrator',N'Operator',N'ApproverExecutor',N'Auditor'))
       OR EXISTS(SELECT [value] FROM OPENJSON(@RolesJson) GROUP BY [value] HAVING COUNT(*)>1)
        THROW 51002,'La lista de roles contiene valores inválidos o duplicados.',1;
    DECLARE @NewRoles table(RoleName varchar(20) PRIMARY KEY);
    INSERT @NewRoles SELECT CONVERT(varchar(20),[value]) FROM OPENJSON(@RolesJson);
    SELECT TOP(1) @PrimaryRole=RoleName FROM @NewRoles ORDER BY CASE RoleName WHEN 'Administrator' THEN 1 WHEN 'Operator' THEN 2 WHEN 'ApproverExecutor' THEN 3 ELSE 4 END;
    IF @PrincipalType IS NULL OR @PrincipalType NOT IN ('WINDOWS','SQL_LOGIN','BOOTSTRAP') OR @Active IS NULL
        THROW 51002, 'Tipo de principal o estado no válido.', 1;
    IF @UserId IS NULL AND @PrincipalType='BOOTSTRAP'
        THROW 51002, 'Los nuevos usuarios deben ser WINDOWS o SQL_LOGIN.', 1;
    IF @UserId IS NULL AND @PrincipalType='WINDOWS'
       AND (CHARINDEX(N'\',@Principal)<=1 OR CHARINDEX(N'\',@Principal)>=LEN(@Principal)
            OR CHARINDEX(N'\',@Principal,CHARINDEX(N'\',@Principal)+1)>0)
        THROW 51002, 'Para Windows indique DOMINIO\usuario o EQUIPO\usuario.', 1;

    BEGIN TRY
        BEGIN TRANSACTION;
        EXEC @LockResult=sys.sp_getapplock @Resource=N'SqlAccessAdmin.AuthorizedUserMaintenance',
             @LockMode='Exclusive',@LockOwner='Transaction',@LockTimeout=15000;
        IF @LockResult<0 THROW 51003, 'Hay otro mantenimiento en curso. Actualice y reintente.', 1;
        -- Bloqueos de datos protegen también ante cambios externos durante esta operación.
        SELECT @AdminCount=COUNT(*) FROM [access].AuthorizedPrincipal p WITH (UPDLOCK,HOLDLOCK)
        JOIN [access].AuthorizedPrincipalRole r WITH (UPDLOCK,HOLDLOCK) ON r.UserId=p.UserId
        WHERE p.Active=1 AND r.RoleName='Administrator';
        SET @Actor=[access].ufn_App_Principal();
        SELECT @CanonicalActor=SUSER_SNAME(original_security_id) FROM sys.dm_exec_sessions WHERE session_id=@@SPID;
        IF [access].ufn_App_HasPermission('ADMIN')=0
            THROW 51001, 'Solo un administrador activo de la aplicación puede mantener usuarios autorizados.', 1;
        -- Proteger también la cuenta propia si se intenta registrar su otro alias.
        IF (@Principal=@Actor OR @Principal=@CanonicalActor OR @Principal=ORIGINAL_LOGIN()) AND (@Active=0 OR @PrimaryRole<>'Administrator')
            THROW 51007, 'No puede quitar su propio acceso ni reducir su propio rol. Solicite el cambio a otro administrador.', 1;

        IF @UserId IS NOT NULL
        BEGIN
            SELECT @OldPrincipal=Principal,@OldType=PrincipalType,@OldRole=RoleName,@OldActive=Active,@Version=RowVersion
            FROM [access].AuthorizedPrincipal WITH (UPDLOCK,HOLDLOCK) WHERE UserId=@UserId;
            IF @OldPrincipal IS NULL THROW 51004, 'El usuario ya no existe. Actualice el listado.', 1;
            IF @ExpectedRowVersion IS NULL OR @ExpectedRowVersion<>@Version
                THROW 51005, 'Otro administrador modificó este usuario. Actualice antes de guardar.', 1;
            IF @OldPrincipal<>@Principal OR @OldType<>@PrincipalType
                THROW 51006, 'La identidad de un usuario registrado no se puede cambiar. Agregue otra identidad.', 1;
            SET @OldRolesJson=[access].ufn_App_UserRolesJson(@UserId);
            IF EXISTS(SELECT 1 FROM [access].AuthorizedPrincipalRole WHERE UserId=@UserId AND RoleName='Administrator') AND @OldActive=1 AND (@Active=0 OR @PrimaryRole<>'Administrator') AND @AdminCount<=1
                THROW 51008, 'Debe conservar al menos un administrador activo.', 1;
        END;
        IF EXISTS(SELECT 1 FROM [access].AuthorizedPrincipal WITH (UPDLOCK,HOLDLOCK)
                  WHERE Principal=@Principal AND (@UserId IS NULL OR UserId<>@UserId))
            THROW 51009, 'Ese principal ya está registrado. Modifique o reactive el registro existente.', 1;

        IF @UserId IS NULL
        BEGIN
            -- SqlAccessAdmin.ExistingPrincipalSelection.v1
            IF NOT EXISTS(SELECT 1 FROM sys.server_principals p
                WHERE p.name COLLATE DATABASE_DEFAULT=@Principal AND p.is_disabled=0
                  AND p.name NOT LIKE N'##%'
                  AND ((p.type='U' AND @PrincipalType='WINDOWS') OR (p.type='S' AND @PrincipalType='SQL_LOGIN')))
                THROW 51511, 'La cuenta seleccionada no existe, está deshabilitada o su tipo no coincide. Actualice el listado.', 1;
            INSERT [access].AuthorizedPrincipal(Principal,PrincipalType,RoleName,Active,Notes)
            VALUES(@Principal,@PrincipalType,@PrimaryRole,@Active,@Notes);
            SET @SavedId=CONVERT(int,SCOPE_IDENTITY());
        END
        ELSE
        BEGIN
            UPDATE [access].AuthorizedPrincipal SET RoleName=@PrimaryRole,Active=@Active,Notes=@Notes WHERE UserId=@UserId;
            SET @SavedId=@UserId;
        END;
        DELETE [access].AuthorizedPrincipalRole WHERE UserId=@SavedId;
        INSERT [access].AuthorizedPrincipalRole(UserId,RoleName) SELECT @SavedId,RoleName FROM @NewRoles;
        SET @Detail=CONCAT(N'UserId=',@SavedId,N'; Principal=',@Principal,N'; Tipo=',@PrincipalType,
                          N'; Roles anteriores=',COALESCE(@OldRolesJson,N'(nuevo)'),N'; Roles nuevos=',[access].ufn_App_UserRolesJson(@SavedId),
                          N'; Activo anterior=',COALESCE(CONVERT(nvarchar(1),@OldActive),N'(nuevo)'),N'; Activo nuevo=',@Active,
                          N'; Administrador=',@Actor,N'; Login original=',ORIGINAL_LOGIN());
        EXEC [access].usp_Audit_Write @Form=N'Usuarios autorizados',@Action=N'Guardar usuario',
             @Success=1,@Detail=@Detail;
        COMMIT TRANSACTION;
        SELECT UserId,RowVersion FROM [access].AuthorizedPrincipal WHERE UserId=@SavedId;
    END TRY
    BEGIN CATCH
        IF XACT_STATE()<>0 ROLLBACK TRANSACTION;
        THROW;
    END CATCH;
END;
GO

GRANT EXECUTE ON [access].usp_AuthorizedUser_AvailablePrincipals TO [SqlAccessAdmin_Users];
GRANT EXECUTE ON [access].usp_AuthorizedUser_AvailablePrincipals TO [SqlAccessAdmin_Administrator];
GO
