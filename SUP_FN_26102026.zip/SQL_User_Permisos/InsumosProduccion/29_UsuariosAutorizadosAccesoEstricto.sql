/*
  Aplicar manualmente por el DBA después de 28 y antes de 99.
  Respaldar adminDB y comprobar que el nombre DOMINIO\usuario del administrador
  tenga un registro activo Administrator antes de actualizar el cliente.
  No registra usuarios, no crea logins y no concede acceso a las instancias.
*/
USE [adminDB];
GO
IF OBJECT_ID(N'access.AppTimeConvention',N'U') IS NOT NULL THROW 51856,'La base ya usa hora de Guatemala. No reaplique migraciones históricas; use 36, 33 actualizado y 99.',1;
GO
SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
GO

CREATE OR ALTER FUNCTION [access].ufn_App_Principal()
RETURNS nvarchar(256)
AS
BEGIN
    -- SqlAccessAdmin.CanonicalWindowsIdentity.v1
    -- El SID original no cambia con EXECUTE AS. No usar el contexto suplantado.
    DECLARE @OriginalSid varbinary(85), @Original nvarchar(256)=ORIGINAL_LOGIN(), @Canonical nvarchar(256);
    SELECT @OriginalSid=original_security_id FROM sys.dm_exec_sessions WHERE session_id=@@SPID;
    IF @OriginalSid IS NULL RETURN NULL;
    SET @Canonical=SUSER_SNAME(@OriginalSid);
    IF @Canonical IS NULL RETURN @Original;
    -- Prioridad al nombre DOMINIO\\usuario registrado, incluso si está inactivo.
    -- Un alias alternativo activo no puede eludir la baja del registro canónico.
    IF EXISTS(SELECT 1 FROM [access].AuthorizedPrincipal WHERE Principal=@Canonical) RETURN @Canonical;
    IF EXISTS(SELECT 1 FROM [access].AuthorizedPrincipal WHERE Principal=@Original) RETURN @Original;
    RETURN @Canonical;
END;
GO

CREATE OR ALTER PROCEDURE [access].usp_App_LoginContext
AS
BEGIN
    SET NOCOUNT ON;
    -- SqlAccessAdmin.ExplicitAuthorization.v1: sin excepción por roles de SQL Server.
    DECLARE @Principal nvarchar(256)=[access].ufn_App_Principal();
    SELECT @Principal AS Principal, p.RoleName AS [Role],
           CAST(CASE WHEN p.UserId IS NULL THEN 0 ELSE 1 END AS bit) AS IsAuthorized,
           CAST(1 AS int) AS AuthorizationVersion, ORIGINAL_LOGIN() AS OriginalPrincipal,
           CASE WHEN p.UserId IS NULL
                THEN N'El principal ['+@Principal+N'] no tiene acceso activo en Usuarios autorizados. Solicite autorización a un administrador.'
                ELSE N'Principal autorizado mediante un registro activo en Usuarios autorizados.' END AS Detail
    FROM (VALUES(1)) AS singleRow(Id)
    LEFT JOIN [access].AuthorizedPrincipal p ON p.Principal=@Principal AND p.Active=1
        AND p.RoleName IN ('Administrator','Operator','Auditor');
END;
GO

CREATE OR ALTER PROCEDURE [access].usp_AuthorizedUser_List
AS
BEGIN
    SET NOCOUNT ON;
    IF NOT EXISTS(SELECT 1 FROM [access].AuthorizedPrincipal WHERE Principal=[access].ufn_App_Principal()
                  AND Active=1 AND RoleName IN ('Administrator','Operator','Auditor'))
        THROW 51001, 'El usuario no tiene acceso activo a la aplicación.', 1;
    SELECT UserId,Principal,PrincipalType,RoleName AS [Role],Active,ISNULL(Notes,N'') AS Notes,RowVersion
    FROM [access].AuthorizedPrincipal ORDER BY Principal;
END;
GO

CREATE OR ALTER PROCEDURE [access].usp_AuthorizedUser_Upsert
    @UserId int=NULL, @Principal nvarchar(256), @PrincipalType varchar(20),
    @Role varchar(20), @Active bit, @Notes nvarchar(500)=NULL,
    @ExpectedRowVersion binary(8)=NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    -- SqlAccessAdmin.AuthorizedUserMaintenance.v1
    DECLARE @Actor nvarchar(256), @CanonicalActor nvarchar(256), @LockResult int, @SavedId int,
            @OldPrincipal nvarchar(256), @OldType varchar(20), @OldRole varchar(20),
            @OldActive bit, @Version binary(8), @AdminCount int, @Detail nvarchar(2000);
    SET @Principal=LTRIM(RTRIM(@Principal));
    SET @Notes=NULLIF(LTRIM(RTRIM(@Notes)),N'');
    IF @Principal IS NULL OR @Principal=N''
        THROW 51002, 'Indique el principal que inicia sesión en adminDB.', 1;
    IF @Role IS NULL OR @Role NOT IN ('Administrator','Operator','Auditor')
        THROW 51002, 'Rol de aplicación no permitido.', 1;
    IF @PrincipalType IS NULL OR @PrincipalType NOT IN ('WINDOWS','SQL_LOGIN','BOOTSTRAP') OR @Active IS NULL
        THROW 51002, 'Tipo de principal o estado no válido.', 1;
    IF @UserId IS NULL AND @PrincipalType='BOOTSTRAP'
        THROW 51002, 'Los nuevos usuarios deben ser WINDOWS o SQL_LOGIN.', 1;
    IF @UserId IS NULL AND @PrincipalType='WINDOWS'
       AND (CHARINDEX(N'\',@Principal)<=1 OR CHARINDEX(N'\',@Principal)>=LEN(@Principal)
            OR CHARINDEX(N'\',@Principal,CHARINDEX(N'\',@Principal)+1)>0)
        THROW 51002, 'Para Windows indique DOMINIO\usuario o EQUIPO\usuario.', 1;

    BEGIN TRY
        BEGIN TRANSACTION;
        EXEC @LockResult=sys.sp_getapplock @Resource=N'SqlAccessAdmin.AuthorizedUserMaintenance',
             @LockMode='Exclusive',@LockOwner='Transaction',@LockTimeout=15000;
        IF @LockResult<0 THROW 51003, 'Hay otro mantenimiento en curso. Actualice y reintente.', 1;
        -- Bloqueos de datos protegen también ante cambios externos durante esta operación.
        SELECT @AdminCount=COUNT(*) FROM [access].AuthorizedPrincipal WITH (UPDLOCK,HOLDLOCK)
        WHERE Active=1 AND RoleName='Administrator';
        SET @Actor=[access].ufn_App_Principal();
        SELECT @CanonicalActor=SUSER_SNAME(original_security_id) FROM sys.dm_exec_sessions WHERE session_id=@@SPID;
        IF NOT EXISTS(SELECT 1 FROM [access].AuthorizedPrincipal WITH (UPDLOCK,HOLDLOCK)
                      WHERE Principal=@Actor AND Active=1 AND RoleName='Administrator')
            THROW 51001, 'Solo un administrador activo de la aplicación puede mantener usuarios autorizados.', 1;
        -- Proteger también la cuenta propia si se intenta registrar su otro alias.
        IF (@Principal=@Actor OR @Principal=@CanonicalActor OR @Principal=ORIGINAL_LOGIN()) AND (@Active=0 OR @Role<>'Administrator')
            THROW 51007, 'No puede quitar su propio acceso ni reducir su propio rol. Solicite el cambio a otro administrador.', 1;

        IF @UserId IS NOT NULL
        BEGIN
            SELECT @OldPrincipal=Principal,@OldType=PrincipalType,@OldRole=RoleName,@OldActive=Active,@Version=RowVersion
            FROM [access].AuthorizedPrincipal WITH (UPDLOCK,HOLDLOCK) WHERE UserId=@UserId;
            IF @OldPrincipal IS NULL THROW 51004, 'El usuario ya no existe. Actualice el listado.', 1;
            IF @ExpectedRowVersion IS NULL OR @ExpectedRowVersion<>@Version
                THROW 51005, 'Otro administrador modificó este usuario. Actualice antes de guardar.', 1;
            IF @OldPrincipal<>@Principal OR @OldType<>@PrincipalType
                THROW 51006, 'La identidad de un usuario registrado no se puede cambiar. Agregue otra identidad.', 1;
            IF @OldRole='Administrator' AND @OldActive=1 AND (@Active=0 OR @Role<>'Administrator') AND @AdminCount<=1
                THROW 51008, 'Debe conservar al menos un administrador activo.', 1;
        END;
        IF EXISTS(SELECT 1 FROM [access].AuthorizedPrincipal WITH (UPDLOCK,HOLDLOCK)
                  WHERE Principal=@Principal AND (@UserId IS NULL OR UserId<>@UserId))
            THROW 51009, 'Ese principal ya está registrado. Modifique o reactive el registro existente.', 1;

        IF @UserId IS NULL
        BEGIN
            INSERT [access].AuthorizedPrincipal(Principal,PrincipalType,RoleName,Active,Notes)
            VALUES(@Principal,@PrincipalType,@Role,@Active,@Notes);
            SET @SavedId=CONVERT(int,SCOPE_IDENTITY());
        END
        ELSE
        BEGIN
            UPDATE [access].AuthorizedPrincipal SET RoleName=@Role,Active=@Active,Notes=@Notes WHERE UserId=@UserId;
            SET @SavedId=@UserId;
        END;
        SET @Detail=CONCAT(N'UserId=',@SavedId,N'; Principal=',@Principal,N'; Tipo=',@PrincipalType,
                          N'; Rol anterior=',COALESCE(@OldRole,N'(nuevo)'),N'; Rol nuevo=',@Role,
                          N'; Activo anterior=',COALESCE(CONVERT(nvarchar(1),@OldActive),N'(nuevo)'),N'; Activo nuevo=',@Active,
                          N'; Administrador=',@Actor,N'; Login original=',ORIGINAL_LOGIN());
        EXEC [access].usp_Audit_Write @Form=N'Usuarios autorizados',@Action=N'Guardar usuario',
             @Success=1,@Detail=@Detail;
        COMMIT TRANSACTION;
        SELECT UserId,RowVersion FROM [access].AuthorizedPrincipal WHERE UserId=@SavedId;
    END TRY
    BEGIN CATCH
        IF XACT_STATE()<>0 ROLLBACK TRANSACTION;
        THROW;
    END CATCH;
END;
GO

/* Instalaciones existentes: actualizar solamente la comparación de identidad
   de los procedimientos conocidos. Conservar contratos de tickets, políticas,
   solicitudes, ejecución y auditoría; no reaplicar scripts antiguos completos. */
DECLARE @IdentityProcedures table(Id int IDENTITY(1,1),ProcedureName sysname,Definition nvarchar(max));
INSERT @IdentityProcedures(ProcedureName,Definition)
SELECT p.name,m.definition FROM sys.procedures p
JOIN sys.sql_modules m ON m.object_id=p.object_id
WHERE p.schema_id=SCHEMA_ID(N'access') AND p.name IN
 (N'usp_Server_Upsert',N'usp_Server_SetActive',N'usp_Policy_PermissionUpsert',N'usp_Policy_RoleUpsert',
  N'usp_Policy_DenyUpsert',N'usp_Policy_SpecialActivate',N'usp_Policy_ContextValidate',
  N'usp_AccessRequest_Approve',N'usp_AccessRequest_MarkExecuted',N'usp_AccessRequest_SecretGet');
DECLARE @Index int=1,@Count int=(SELECT COUNT(*) FROM @IdentityProcedures),@Definition nvarchar(max),@ProcedureName sysname,
        @NormalizedHeader nvarchar(512),@FailureMessage nvarchar(2048);
BEGIN TRY
 BEGIN TRANSACTION;
 WHILE @Index<=@Count
 BEGIN
  SELECT @Definition=Definition,@ProcedureName=ProcedureName FROM @IdentityProcedures WHERE Id=@Index;
  IF @Definition IS NULL
  BEGIN
   SET @FailureMessage=CONCAT(N'No se puede revisar la definición de [access].',QUOTENAME(@ProcedureName),N'. Solicite revisión al DBA.');
   THROW 51010,@FailureMessage,1;
  END;
  IF CHARINDEX(N'Principal=ORIGINAL_LOGIN()',@Definition)>0
  BEGIN
   SET @Definition=REPLACE(@Definition,N'Principal=ORIGINAL_LOGIN()',N'Principal=[access].ufn_App_Principal()');
   -- SqlAccessAdmin.ProcedureHeaderWhitespace.v1
   -- sys.sql_modules puede devolver CREATE   PROCEDURE o un salto de línea inicial.
   -- Normalizar una copia del encabezado; no colapsar espacios del cuerpo ni de literales.
   WHILE LEFT(@Definition,1) IN(N' ',NCHAR(9),NCHAR(10),NCHAR(13))
    SET @Definition=SUBSTRING(@Definition,2,LEN(@Definition));
   SET @NormalizedHeader=UPPER(LEFT(@Definition,512));
   SET @NormalizedHeader=REPLACE(REPLACE(REPLACE(@NormalizedHeader,NCHAR(9),N' '),NCHAR(10),N' '),NCHAR(13),N' ');
   WHILE CHARINDEX(N'  ',@NormalizedHeader)>0 SET @NormalizedHeader=REPLACE(@NormalizedHeader,N'  ',N' ');
   IF @NormalizedHeader LIKE N'CREATE PROCEDURE %' OR @NormalizedHeader LIKE N'CREATE PROC %'
    SET @Definition=STUFF(@Definition,1,6,N'ALTER');
   ELSE IF @NormalizedHeader LIKE N'CREATE OR ALTER PROCEDURE %' OR @NormalizedHeader LIKE N'CREATE OR ALTER PROC %'
    SET @Definition=SUBSTRING(@Definition,CHARINDEX(N'ALTER',UPPER(@Definition)),LEN(@Definition));
   ELSE IF @NormalizedHeader NOT LIKE N'ALTER PROCEDURE %' AND @NormalizedHeader NOT LIKE N'ALTER PROC %'
   BEGIN
    SET @FailureMessage=CONCAT(N'No se reconoce el encabezado de [access].',QUOTENAME(@ProcedureName),N'. Solicite revisión al DBA.');
    THROW 51010,@FailureMessage,1;
   END;
   EXEC sys.sp_executesql @Definition;
   PRINT N'Identidad actualizada en [access].'+QUOTENAME(@ProcedureName);
  END;
  SET @Index+=1;
 END;
 COMMIT TRANSACTION;
END TRY
BEGIN CATCH
 IF XACT_STATE()<>0 ROLLBACK TRANSACTION;
 THROW;
END CATCH;
GO

/* El SP verifica el rol vigente en la tabla, aun si se llama sin la interfaz.
   Se permite ejecutarlo a los roles de conexión existentes para que un cambio
   de rol de aplicación no dependa de membresías SQL antiguas para este módulo. */
GRANT EXECUTE ON [access].usp_App_LoginContext TO [SqlAccessAdmin_Users];
GRANT EXECUTE ON [access].usp_App_LoginContext TO [SqlAccessAdmin_Administrator];
GRANT EXECUTE ON [access].usp_App_LoginContext TO [SqlAccessAdmin_Operator];
GRANT EXECUTE ON [access].usp_App_LoginContext TO [SqlAccessAdmin_Auditor];
GRANT EXECUTE ON [access].usp_AuthorizedUser_List TO [SqlAccessAdmin_Users];
GRANT EXECUTE ON [access].usp_AuthorizedUser_List TO [SqlAccessAdmin_Administrator];
GRANT EXECUTE ON [access].usp_AuthorizedUser_List TO [SqlAccessAdmin_Operator];
GRANT EXECUTE ON [access].usp_AuthorizedUser_List TO [SqlAccessAdmin_Auditor];
GRANT EXECUTE ON [access].usp_AuthorizedUser_Upsert TO [SqlAccessAdmin_Users];
GRANT EXECUTE ON [access].usp_AuthorizedUser_Upsert TO [SqlAccessAdmin_Administrator];
GRANT EXECUTE ON [access].usp_AuthorizedUser_Upsert TO [SqlAccessAdmin_Operator];
GRANT EXECUTE ON [access].usp_AuthorizedUser_Upsert TO [SqlAccessAdmin_Auditor];
GO
