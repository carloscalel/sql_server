/* Complemento de 33 y 36. Aplicar en adminDB; no modifica cuentas ni contraseñas. */
USE [adminDB];
GO
CREATE OR ALTER PROCEDURE access.usp_Report_ConfirmedPasswordDates @ServerId int
AS
BEGIN
 SET NOCOUNT ON;
 EXEC access.usp_App_RequirePermission 'ACCESS_REQUESTS';
 SELECT c.PrincipalSid, MAX(c.CompletedAt) AS ChangedAt
 FROM access.AppSecurityChange c
 JOIN access.SecurityEvidenceSource s ON s.SourceId=c.SourceId
 WHERE s.ServerId=@ServerId AND c.PrincipalKind='LOGIN'
   AND c.OperationCode='CHANGE_LOGIN_PASSWORD' AND c.State='CONFIRMED'
   AND c.PrincipalSid IS NOT NULL AND c.CompletedAt IS NOT NULL
 GROUP BY c.PrincipalSid;
END;
GO
GRANT EXECUTE ON access.usp_Report_ConfirmedPasswordDates TO SqlAccessAdmin_Users;
GO
