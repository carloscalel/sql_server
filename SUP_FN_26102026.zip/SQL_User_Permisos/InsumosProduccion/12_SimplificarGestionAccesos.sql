USE [adminDB];
GO
IF OBJECT_ID(N'access.AppTimeConvention',N'U') IS NOT NULL THROW 51856,'La base ya usa hora de Guatemala. No reaplique migraciones históricas; use 36, 33 actualizado y 99.',1;
GO
SET NOCOUNT ON;
SET XACT_ABORT ON;
GO

/*
  Migra la política a un modelo simple:
    - Instancia: crear/modificar/habilitar/deshabilitar logins.
    - Base u objeto: SELECT, INSERT, UPDATE, DELETE.
    - EXECUTE se conserva únicamente porque SQL Server lo requiere para rutinas.
*/

MERGE [access].SecurityPolicyOperation AS target
USING (VALUES
 ('CREATE_WINDOWS_LOGIN',N'Crear login Windows','MEDIUM',1,N'Crea un login para una identidad Windows existente'),
 ('MODIFY_LOGIN',N'Modificar login','HIGH',1,N'Cambia la base predeterminada y permite restablecer contraseña SQL durante la ejecución')
) AS source(OperationCode,DisplayName,RiskLevel,RequiresApproval,Description)
ON target.OperationCode=source.OperationCode
WHEN MATCHED THEN UPDATE SET DisplayName=source.DisplayName,RiskLevel=source.RiskLevel,RequiresApproval=source.RequiresApproval,Description=source.Description,Enabled=1
WHEN NOT MATCHED THEN INSERT(OperationCode,DisplayName,RiskLevel,RequiresApproval,Description)
VALUES(source.OperationCode,source.DisplayName,source.RiskLevel,source.RequiresApproval,source.Description);

UPDATE [access].SecurityPolicyOperation
SET Enabled=0
WHERE OperationCode IN('CLONE_SQL_LOGIN','CLONE_PERMISSIONS');

UPDATE [access].SecurityPolicyPermission
SET Enabled=0
WHERE PermissionName NOT IN('SELECT','INSERT','UPDATE','DELETE','EXECUTE')
   OR ScopeType NOT IN('DATABASE','OBJECT');

UPDATE [access].SecurityPolicyPermission
SET AllowDeny=0
WHERE Enabled=1;

MERGE [access].SecurityPolicyPermission AS target
USING (VALUES
 ('SELECT','DATABASE'),('SELECT','OBJECT'),
 ('INSERT','DATABASE'),('INSERT','OBJECT'),
 ('UPDATE','DATABASE'),('UPDATE','OBJECT'),
 ('DELETE','DATABASE'),('DELETE','OBJECT'),
 ('EXECUTE','DATABASE'),('EXECUTE','OBJECT')
) AS source(PermissionName,ScopeType)
ON target.PermissionName=source.PermissionName AND target.ScopeType=source.ScopeType
WHEN MATCHED THEN UPDATE SET AllowGrant=1,AllowDeny=0,AllowRevoke=1,Enabled=1,ApprovedBy=ORIGINAL_LOGIN(),ApprovedAt=SYSUTCDATETIME()
WHEN NOT MATCHED THEN INSERT(PermissionName,ScopeType,AllowGrant,AllowDeny,AllowRevoke,Enabled)
VALUES(source.PermissionName,source.ScopeType,1,0,1,1);

DECLARE @Detail nvarchar(2000)=N'Política simplificada: ciclo de vida de logins y acceso de lectura/escritura por base u objeto.';
EXEC [access].usp_Audit_Write N'Política central',N'Simplificar gestión de accesos',NULL,NULL,1,@Detail;
GO

SELECT OperationCode,DisplayName,Enabled,RiskLevel
FROM [access].SecurityPolicyOperation
ORDER BY DisplayName;

SELECT PermissionName,ScopeType,AllowGrant,AllowDeny,AllowRevoke,Enabled
FROM [access].SecurityPolicyPermission
ORDER BY PermissionName,ScopeType;
GO

