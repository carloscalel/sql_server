/* SQL Access Admin: aplicar en adminDB después de 32, con clientes detenidos.
   No instala triggers en destinos ni revoca accesos. Terminar con 99.
   Fechas; día de contraseña: Guatemala (Central America Standard Time). */
USE [adminDB];
GO
SET NOCOUNT ON; SET XACT_ABORT ON;
SET ANSI_NULLS ON; SET QUOTED_IDENTIFIER ON; SET ANSI_PADDING ON;
SET ANSI_WARNINGS ON; SET ARITHABORT ON; SET CONCAT_NULL_YIELDS_NULL ON; SET NUMERIC_ROUNDABORT OFF;
IF OBJECT_ID(N'access.ufn_App_HasPermission',N'FN') IS NULL
 OR NOT EXISTS(SELECT 1 FROM access.SecurityPolicyOperation WHERE OperationCode='CHANGE_LOGIN_PASSWORD')
 THROW 51700,'Instale primero 30, 31 y 32.',1;
IF OBJECT_ID(N'access.AppTimeConvention',N'U') IS NULL THROW 51850,'Aplique primero 36_HoraLocalGuatemala.sql.',1;
IF COL_LENGTH(N'access.TemporaryAccess',N'ExpiresAtUtc') IS NOT NULL THROW 51851,'Convierta primero las fechas con 36_HoraLocalGuatemala.sql.',1;
IF OBJECT_ID(N'access.SecurityMonitoringVersion',N'U') IS NULL
BEGIN
 BEGIN TRAN;
 CREATE TABLE access.SecurityMonitoringVersion(Id int NOT NULL PRIMARY KEY CHECK(Id=1),Version int NOT NULL);
 CREATE TABLE access.SecurityEvidenceSource
 (SourceId uniqueidentifier NOT NULL PRIMARY KEY,ServerId int NOT NULL UNIQUE REFERENCES access.ManagedServer(ServerId),
  LastCollected datetime2(7) NOT NULL,CoverageStarted datetime2(7) NOT NULL,Health nvarchar(1000) NOT NULL);
 CREATE TABLE access.RequestValidity
 (RequestId bigint NOT NULL PRIMARY KEY REFERENCES access.AccessRequest(RequestId),ExpiresAt datetime2(7) NOT NULL,
  CreatedBy nvarchar(256) NOT NULL,CreatedAt datetime2(7) NOT NULL DEFAULT access.ufn_AppNow());
 CREATE TABLE access.TemporaryAccess
 (TemporaryAccessId bigint IDENTITY NOT NULL PRIMARY KEY,ServerId int NOT NULL REFERENCES access.ManagedServer(ServerId),
  PrincipalSid varbinary(85) NOT NULL,PrincipalName nvarchar(256) NOT NULL,AccessKind varchar(20) NOT NULL,
  DatabaseName sysname NOT NULL,ScopeType varchar(30) NOT NULL,Securable nvarchar(776) NOT NULL,
  PermissionName nvarchar(128) NOT NULL,RoleName sysname NOT NULL,ExpiresAt datetime2(7) NOT NULL,
  CreatedRequestId bigint NOT NULL REFERENCES access.AccessRequest(RequestId),ResourceKey binary(32) NOT NULL,
  IsOpen bit NOT NULL DEFAULT 1,Revision int NOT NULL DEFAULT 1,ClosedAt datetime2(7) NULL,
  ClosedBy nvarchar(256) NULL,RowVersion rowversion NOT NULL,
  CONSTRAINT CK_TemporaryAccess_Kind CHECK(AccessKind IN('LOGIN','DATABASE_USER','PERMISSION','ROLE_MEMBERSHIP')),
  CONSTRAINT UQ_TemporaryAccess_RequestResource UNIQUE(CreatedRequestId,ResourceKey));
 CREATE INDEX IX_TemporaryAccess_Due ON access.TemporaryAccess(ExpiresAt,TemporaryAccessId) INCLUDE(Revision) WHERE IsOpen=1;
 CREATE UNIQUE INDEX UX_TemporaryAccess_OpenResource ON access.TemporaryAccess(ResourceKey) WHERE IsOpen=1;
 CREATE TABLE access.TemporaryAccessAction
 (ActionId bigint IDENTITY NOT NULL PRIMARY KEY,TemporaryAccessId bigint NOT NULL REFERENCES access.TemporaryAccess(TemporaryAccessId),
  ActionCode varchar(10) NOT NULL CHECK(ActionCode IN('EXTEND','CLOSE')),ExpectedRevision int NOT NULL,
  NewExpiresAt datetime2(7) NULL,Ticket varchar(50) NOT NULL,Reason nvarchar(1000) NOT NULL,
  RequestedBy nvarchar(256) NOT NULL,RequestedAt datetime2(7) NOT NULL DEFAULT access.ufn_AppNow(),
  ReviewedBy nvarchar(256) NULL,ExecutingBy nvarchar(256) NULL,Status varchar(16) NOT NULL DEFAULT 'PENDING',
  IsPending bit NOT NULL DEFAULT 1,Result nvarchar(2000) NULL,CompletedAt datetime2(7) NULL,
  CONSTRAINT CK_TemporaryAction_Status CHECK(Status IN('PENDING','APPROVED','REJECTED','EXECUTING','EXECUTED','FAILED')));
 CREATE UNIQUE INDEX UX_TemporaryAction_Pending ON access.TemporaryAccessAction(TemporaryAccessId) WHERE IsPending=1;
 CREATE TABLE access.SecurityAlert
 (AlertId bigint IDENTITY NOT NULL PRIMARY KEY,AlertType varchar(24) NOT NULL,AlertKey binary(32) NOT NULL,
  TemporaryAccessId bigint NULL REFERENCES access.TemporaryAccess(TemporaryAccessId),Revision int NULL,
  SourceId uniqueidentifier NULL,PrincipalSid varbinary(85) NULL,BusinessDate date NULL,
  ObservedCount bigint NULL,OccurredAt datetime2(7) NOT NULL,DetectedAt datetime2(7) NOT NULL DEFAULT access.ufn_AppNow(),
  IsActive bit NOT NULL DEFAULT 1,ResolvedAt datetime2(7) NULL,ResolvedBy nvarchar(256) NULL,
  ResolutionActionId bigint NULL REFERENCES access.TemporaryAccessAction(ActionId),ResolutionReason nvarchar(1000) NULL);
 CREATE UNIQUE INDEX UX_SecurityAlert_Active ON access.SecurityAlert(AlertType,AlertKey) WHERE IsActive=1;
 CREATE INDEX IX_SecurityAlert_Active ON access.SecurityAlert(AlertType) INCLUDE(TemporaryAccessId,ObservedCount) WHERE IsActive=1;
 CREATE INDEX IX_SecurityAlert_ActiveDate ON access.SecurityAlert(DetectedAt DESC)
  INCLUDE(AlertType,TemporaryAccessId,SourceId,PrincipalSid,BusinessDate,ObservedCount) WHERE IsActive=1;
 INSERT access.SecurityMonitoringVersion VALUES(1,4); COMMIT;
END;
GO
IF OBJECT_ID(N'access.AppExecution',N'U') IS NULL
BEGIN
 CREATE TABLE access.AppExecution(ExecutionId uniqueidentifier NOT NULL PRIMARY KEY,RequestId bigint NULL REFERENCES access.AccessRequest(RequestId),
  ActionId bigint NULL REFERENCES access.TemporaryAccessAction(ActionId),ServerId int NOT NULL REFERENCES access.ManagedServer(ServerId),
  PrincipalName nvarchar(256) NOT NULL,Actor nvarchar(256) NOT NULL,StartedAt datetime2(7) NOT NULL DEFAULT access.ufn_AppNow());
 CREATE UNIQUE INDEX UX_AppExecution_Request ON access.AppExecution(RequestId) WHERE RequestId IS NOT NULL;
 CREATE UNIQUE INDEX UX_AppExecution_Action ON access.AppExecution(ActionId) WHERE ActionId IS NOT NULL;
 CREATE TABLE access.AppSecurityChange(EventId uniqueidentifier NOT NULL PRIMARY KEY,ExecutionId uniqueidentifier NOT NULL REFERENCES access.AppExecution(ExecutionId),
  Ordinal int NOT NULL,SourceId uniqueidentifier NOT NULL REFERENCES access.SecurityEvidenceSource(SourceId),DatabaseName sysname NOT NULL,
  PrincipalKind varchar(20) NOT NULL,PrincipalName nvarchar(256) NOT NULL,PrincipalSid varbinary(85) NULL,
  OperationCode varchar(40) NOT NULL,PermissionAction varchar(10) NULL,PermissionName nvarchar(128) NULL,ScopeType varchar(30) NULL,
  Securable nvarchar(776) NULL,RoleName sysname NULL,State varchar(16) NOT NULL DEFAULT 'PENDING',PreparedAt datetime2(7) NOT NULL DEFAULT access.ufn_AppNow(),
  CompletedAt datetime2(7) NULL,ModifiedLocal datetime2(7) NULL,PasswordSetLocal datetime2(7) NULL,EngineOffsetMinutes int NULL,DefinitionChanged bit NOT NULL DEFAULT 0,
  CONSTRAINT UQ_AppChange_Ordinal UNIQUE(ExecutionId,Ordinal),CONSTRAINT CK_AppChange_State CHECK(State IN('PENDING','CONFIRMED','UNRESOLVED','NO_CHANGE','ROLLED_BACK')));
 CREATE INDEX IX_AppChange_Date ON access.AppSecurityChange(CompletedAt) INCLUDE(SourceId,OperationCode,State,PrincipalSid);
 CREATE INDEX IX_AppChange_Match ON access.AppSecurityChange(SourceId,DatabaseName,PrincipalKind,PrincipalSid) INCLUDE(ModifiedLocal,PasswordSetLocal,State,OperationCode);
 CREATE TABLE access.AppPasswordDaily(SourceId uniqueidentifier NOT NULL,PrincipalSid varbinary(85) NOT NULL,BusinessDate date NOT NULL,
  PrincipalName nvarchar(256) NOT NULL,ChangeCount bigint NOT NULL,LastChange datetime2(7) NOT NULL,PRIMARY KEY(SourceId,PrincipalSid,BusinessDate));
 CREATE TABLE access.PrincipalMetadataSnapshot(ServerId int NOT NULL REFERENCES access.ManagedServer(ServerId),DatabaseName sysname NOT NULL,
  PrincipalKind varchar(20) NOT NULL,PrincipalSid varbinary(85) NOT NULL,PrincipalName nvarchar(256) NOT NULL,
  ModifiedLocal datetime2(7) NOT NULL,PasswordSetLocal datetime2(7) NULL,EngineOffsetMinutes int NOT NULL,
  ModificationOrigin varchar(16) NOT NULL,PasswordOrigin varchar(16) NULL,ModificationDetected datetime2(7) NOT NULL,
  PasswordDetected datetime2(7) NULL,LastChecked datetime2(7) NOT NULL,
  PRIMARY KEY(ServerId,DatabaseName,PrincipalKind,PrincipalSid));
END;
GO
IF COL_LENGTH(N'access.SecurityEvidenceSource',N'MetadataChecked') IS NULL
 ALTER TABLE access.SecurityEvidenceSource ADD MetadataChecked datetime2(7) NULL;
IF COL_LENGTH(N'access.AppSecurityChange',N'DefinitionChanged') IS NULL
 ALTER TABLE access.AppSecurityChange ADD DefinitionChanged bit NOT NULL DEFAULT 0;
GO
CREATE OR ALTER PROCEDURE access.usp_AppExecution_Begin @RequestId bigint=NULL,@ActionId bigint=NULL,@ServerId int
AS
BEGIN
 SET NOCOUNT ON;SET XACT_ABORT ON;EXEC access.usp_App_RequirePermission 'REVIEW_REQUEST';
 DECLARE @Actor nvarchar(256)=access.ufn_App_Principal(),@Principal nvarchar(256),@Id uniqueidentifier=NEWID();
 IF (@RequestId IS NULL AND @ActionId IS NULL) OR (@RequestId IS NOT NULL AND @ActionId IS NOT NULL) THROW 51800,'Identifique una solicitud o un cierre aprobado.',1;
 IF @RequestId IS NOT NULL
 BEGIN
  SELECT @Principal=TargetPrincipal FROM access.AccessRequest WHERE RequestId=@RequestId AND Status='APPROVED';
  IF @Principal IS NULL OR NOT EXISTS(SELECT 1 FROM access.AccessRequestTarget WHERE RequestId=@RequestId AND ServerId=@ServerId)
   OR EXISTS(SELECT 1 FROM access.AccessRequestTarget WHERE RequestId=@RequestId AND ServerId<>@ServerId)
   THROW 51801,'Solicitud no aprobada o destino incompatible.',1;
 END
 ELSE
 BEGIN
  EXEC access.usp_App_RequirePermission 'ADMIN';
  SELECT @Principal=t.PrincipalName FROM access.TemporaryAccessAction a JOIN access.TemporaryAccess t ON t.TemporaryAccessId=a.TemporaryAccessId
   WHERE a.ActionId=@ActionId AND a.ActionCode='CLOSE' AND a.Status='EXECUTING' AND a.ExecutingBy=@Actor AND t.ServerId=@ServerId;
  IF @Principal IS NULL THROW 51802,'El cierre no está reservado para esta identidad.',1;
 END;
 BEGIN TRY
  INSERT access.AppExecution(ExecutionId,RequestId,ActionId,ServerId,PrincipalName,Actor) VALUES(@Id,@RequestId,@ActionId,@ServerId,@Principal,@Actor);
 END TRY BEGIN CATCH
  IF ERROR_NUMBER() IN(2601,2627) THROW 51803,'Esta gestión ya tiene un intento de ejecución. Revise su historial y el destino; no se reejecuta automáticamente.',1;
  THROW;
 END CATCH;
 SELECT @Id ExecutionId;
END;
GO
CREATE OR ALTER PROCEDURE access.usp_AppChange_Prepare @ExecutionId uniqueidentifier,@Ordinal int,@DatabaseName sysname,@PrincipalKind varchar(20),
 @OperationCode varchar(40),@PermissionAction varchar(10)=NULL,@PermissionName nvarchar(128)=NULL,@ScopeType varchar(30)=NULL,
 @Securable nvarchar(776)=NULL,@RoleName sysname=NULL,@PrincipalSid varbinary(85)=NULL
AS
BEGIN
 SET NOCOUNT ON;SET XACT_ABORT ON;EXEC access.usp_App_RequirePermission 'REVIEW_REQUEST';
 DECLARE @ServerId int,@Principal nvarchar(256),@Request bigint,@Source uniqueidentifier,@Event uniqueidentifier=NEWID(),@Lock int;
 SELECT @ServerId=ServerId,@Principal=PrincipalName,@Request=RequestId FROM access.AppExecution WHERE ExecutionId=@ExecutionId AND Actor=access.ufn_App_Principal();
 IF @ServerId IS NULL OR @Ordinal<1 OR @DatabaseName IS NULL OR @PrincipalKind NOT IN('LOGIN','DATABASE_USER')
  OR @OperationCode NOT IN('CREATE_SQL_LOGIN','CREATE_WINDOWS_LOGIN','CREATE_DB_USER','DROP_DB_USER','ADD_ROLE_MEMBER','REMOVE_ROLE_MEMBER','MODIFY_LOGIN',
   'ADD_SERVER_ROLE_MEMBER','REMOVE_SERVER_ROLE_MEMBER','PERMISSION_CHANGE','SERVER_PERMISSION_CHANGE','ENABLE_LOGIN','DISABLE_LOGIN','CHANGE_LOGIN_PASSWORD','CLOSE_TEMPORARY_ACCESS')
  THROW 51804,'Intento o detalle tipado inválido.',1;
 IF @Request IS NOT NULL AND @PrincipalKind='DATABASE_USER' AND NOT EXISTS(SELECT 1 FROM access.AccessRequestTarget WHERE RequestId=@Request AND ServerId=@ServerId AND DatabaseName=@DatabaseName)
  THROW 51805,'La base no pertenece a la solicitud.',1;
 IF @OperationCode='CHANGE_LOGIN_PASSWORD' AND (@Request IS NULL OR NOT EXISTS(SELECT 1 FROM access.AccessRequest WHERE RequestId=@Request AND OperationCode='CHANGE_LOGIN_PASSWORD'))
  THROW 51813,'Una contraseña requiere su solicitud específica aprobada.',1;
 IF EXISTS(SELECT 1 FROM access.AccessRequest WHERE RequestId=@Request AND OperationCode='CHANGE_LOGIN_PASSWORD') AND @OperationCode<>'CHANGE_LOGIN_PASSWORD'
  THROW 51814,'La solicitud de contraseña no admite otros comandos.',1;
 BEGIN TRY
  BEGIN TRAN;
  DECLARE @Resource nvarchar(255)=CONCAT(N'SqlAccessAdmin.Evidence.',@ServerId);
  EXEC @Lock=sys.sp_getapplock @Resource=@Resource,@LockMode='Exclusive',@LockOwner='Transaction',@LockTimeout=5000;
  IF @Lock<0 THROW 51806,'Otra operación está registrando seguimiento.',1;
  SELECT @Source=SourceId FROM access.SecurityEvidenceSource WHERE ServerId=@ServerId;
  IF @Source IS NULL
  BEGIN
   SET @Source=NEWID();INSERT access.SecurityEvidenceSource(SourceId,ServerId,LastCollected,CoverageStarted,Health)
    VALUES(@Source,@ServerId,access.ufn_AppNow(),access.ufn_AppNow(),N'Registro de operaciones de la aplicación.');
  END;
  IF EXISTS(SELECT 1 FROM access.AppSecurityChange WHERE ExecutionId=@ExecutionId AND Ordinal=@Ordinal)
   THROW 51807,'El comando ya está reservado. No debe reenviarse al destino.',1;
  INSERT access.AppSecurityChange(EventId,ExecutionId,Ordinal,SourceId,DatabaseName,PrincipalKind,PrincipalName,PrincipalSid,OperationCode,
   PermissionAction,PermissionName,ScopeType,Securable,RoleName)
  VALUES(@Event,@ExecutionId,@Ordinal,@Source,@DatabaseName,@PrincipalKind,@Principal,@PrincipalSid,@OperationCode,@PermissionAction,@PermissionName,@ScopeType,@Securable,@RoleName);
  COMMIT;
 END TRY BEGIN CATCH IF XACT_STATE()<>0 ROLLBACK;THROW;END CATCH;
 SELECT @Event EventId;
END;
GO
CREATE OR ALTER PROCEDURE access.usp_AppChange_Complete @EventId uniqueidentifier,@State varchar(16),@PrincipalSid varbinary(85)=NULL,
 @ModifiedLocal datetime2(7)=NULL,@PasswordSetLocal datetime2(7)=NULL,@EngineOffsetMinutes int=NULL,@CompletedAt datetime2(7)=NULL,@DefinitionChanged bit=0
AS
BEGIN
 SET NOCOUNT ON;SET XACT_ABORT ON;EXEC access.usp_App_RequirePermission 'REVIEW_REQUEST';
 IF @State NOT IN('CONFIRMED','UNRESOLVED','NO_CHANGE','ROLLED_BACK') THROW 51808,'Resultado inválido.',1;
 DECLARE @Server int,@Source uniqueidentifier,@Sid varbinary(85),@Principal nvarchar(256),@Operation varchar(40),@Old varchar(16),@Lock int;
 SELECT @Server=e.ServerId,@Source=c.SourceId FROM access.AppSecurityChange c JOIN access.AppExecution e ON e.ExecutionId=c.ExecutionId
  WHERE c.EventId=@EventId AND e.Actor=access.ufn_App_Principal();
 IF @Server IS NULL THROW 51809,'Comando no reservado para esta identidad.',1;
 BEGIN TRY
  BEGIN TRAN;
  DECLARE @Resource nvarchar(255)=CONCAT(N'SqlAccessAdmin.Evidence.',@Server);
  EXEC @Lock=sys.sp_getapplock @Resource=@Resource,@LockMode='Exclusive',@LockOwner='Transaction',@LockTimeout=5000;
  IF @Lock<0 THROW 51806,'Otra operación está registrando seguimiento.',1;
  SELECT @Old=State,@Sid=COALESCE(@PrincipalSid,PrincipalSid),@Principal=PrincipalName,@Operation=OperationCode FROM access.AppSecurityChange WITH(UPDLOCK,HOLDLOCK) WHERE EventId=@EventId;
  IF @Old=@State BEGIN COMMIT;RETURN;END;
  IF @Old<>'PENDING' THROW 51810,'El comando ya tiene otro resultado. Conciliar antes de modificarlo.',1;
  IF @State='CONFIRMED' AND @Operation='CHANGE_LOGIN_PASSWORD' AND (@Sid IS NULL OR DATALENGTH(@Sid)=0 OR @PasswordSetLocal IS NULL)
   SET @State='UNRESOLVED';
  SET @CompletedAt=COALESCE(@CompletedAt,access.ufn_AppNow());
  UPDATE access.AppSecurityChange SET State=@State,PrincipalSid=@Sid,CompletedAt=@CompletedAt,
   ModifiedLocal=@ModifiedLocal,PasswordSetLocal=@PasswordSetLocal,EngineOffsetMinutes=@EngineOffsetMinutes,DefinitionChanged=@DefinitionChanged WHERE EventId=@EventId;
  IF @State='CONFIRMED' AND @Operation='CHANGE_LOGIN_PASSWORD'
  BEGIN
   DECLARE @Day date=CONVERT(date,@CompletedAt),@Count bigint,@AlertKey binary(32);
   UPDATE access.AppPasswordDaily SET ChangeCount=ChangeCount+1,PrincipalName=@Principal,
    LastChange=CASE WHEN LastChange>@CompletedAt THEN LastChange ELSE @CompletedAt END
    WHERE SourceId=@Source AND PrincipalSid=@Sid AND BusinessDate=@Day;
   IF @@ROWCOUNT=0 INSERT access.AppPasswordDaily VALUES(@Source,@Sid,@Day,@Principal,1,@CompletedAt);
   SELECT @Count=ChangeCount FROM access.AppPasswordDaily WHERE SourceId=@Source AND PrincipalSid=@Sid AND BusinessDate=@Day;
   SET @AlertKey=HASHBYTES('SHA2_256',CONCAT(CONVERT(nvarchar(36),@Source),':',CONVERT(varchar(170),@Sid,2),':',CONVERT(char(10),@Day,23)));
   IF @Count>=3
   BEGIN
    UPDATE access.SecurityAlert SET ObservedCount=@Count WHERE AlertType='PASSWORD_FREQUENCY' AND AlertKey=@AlertKey AND IsActive=1;
    IF @@ROWCOUNT=0 INSERT access.SecurityAlert(AlertType,AlertKey,SourceId,PrincipalSid,BusinessDate,ObservedCount,OccurredAt)
     VALUES('PASSWORD_FREQUENCY',@AlertKey,@Source,@Sid,@Day,@Count,@CompletedAt);
   END;
  END;
  COMMIT;
 END TRY BEGIN CATCH IF XACT_STATE()<>0 ROLLBACK;THROW;END CATCH;
END;
GO
CREATE OR ALTER PROCEDURE access.usp_PrincipalMetadata_Import @ServerId int,@SnapshotsJson nvarchar(max)
AS
BEGIN
 SET NOCOUNT ON;SET XACT_ABORT ON;EXEC access.usp_App_RequirePermission 'REVIEW_REQUEST';
 IF ISJSON(@SnapshotsJson)<>1 OR DATALENGTH(@SnapshotsJson)>8000000 OR (SELECT COUNT(*) FROM OPENJSON(@SnapshotsJson))>500
  THROW 51811,'Lote de metadatos inválido.',1;
 DECLARE @Rows table(DatabaseName sysname NOT NULL,PrincipalKind varchar(20) NOT NULL,PrincipalSid varbinary(85) NOT NULL,
  PrincipalName nvarchar(256) NOT NULL,ModifiedLocal datetime2(7) NOT NULL,PasswordSetLocal datetime2(7) NULL,EngineOffsetMinutes int NOT NULL,
  PRIMARY KEY(DatabaseName,PrincipalKind,PrincipalSid));
 INSERT @Rows SELECT DatabaseName,PrincipalKind,CONVERT(varbinary(85),Sid,2),PrincipalName,ModifiedLocal,PasswordSetLocal,EngineOffsetMinutes
 FROM OPENJSON(@SnapshotsJson) WITH(DatabaseName sysname,PrincipalKind varchar(20),Sid varchar(170),PrincipalName nvarchar(256),
  ModifiedLocal datetime2(7),PasswordSetLocal datetime2(7),EngineOffsetMinutes int);
 IF EXISTS(SELECT 1 FROM @Rows WHERE PrincipalKind NOT IN('LOGIN','DATABASE_USER') OR DATALENGTH(PrincipalSid)=0)
  THROW 51812,'Identidad de metadatos inválida.',1;
 DECLARE @Lock int,@Source uniqueidentifier,@Now datetime2(7)=access.ufn_AppNow(),@Resource nvarchar(255)=CONCAT(N'SqlAccessAdmin.Evidence.',@ServerId);
 BEGIN TRY
  BEGIN TRAN;
  EXEC @Lock=sys.sp_getapplock @Resource=@Resource,@LockMode='Exclusive',@LockOwner='Transaction',@LockTimeout=5000;
  IF @Lock<0 THROW 51806,'Otra operación está registrando seguimiento.',1;
  SELECT @Source=SourceId FROM access.SecurityEvidenceSource WHERE ServerId=@ServerId;
  IF @Source IS NULL
  BEGIN
   SET @Source=NEWID();INSERT access.SecurityEvidenceSource(SourceId,ServerId,LastCollected,CoverageStarted,Health)
    VALUES(@Source,@ServerId,@Now,@Now,N'Referencia inicial de metadatos.');
  END;
  -- Un comando de la app sin resultado no se atribuye automáticamente a un tercero.
  DELETE r FROM @Rows r WHERE EXISTS(SELECT 1 FROM access.AppSecurityChange c WHERE c.SourceId=@Source AND c.DatabaseName=r.DatabaseName
   AND c.PrincipalKind=r.PrincipalKind AND c.PrincipalName=r.PrincipalName AND (c.PrincipalSid=r.PrincipalSid OR c.PrincipalSid IS NULL) AND (c.State IN('PENDING','UNRESOLVED') OR (c.State='CONFIRMED' AND c.ModifiedLocal IS NULL AND c.OperationCode<>'DROP_DB_USER')));
  ;WITH classified AS
  (SELECT r.*,
   CASE WHEN EXISTS(SELECT 1 FROM access.AppSecurityChange c WHERE c.SourceId=@Source AND c.DatabaseName=r.DatabaseName AND c.PrincipalKind=r.PrincipalKind
    AND c.PrincipalSid=r.PrincipalSid AND c.State='CONFIRMED' AND c.DefinitionChanged=1 AND c.ModifiedLocal=r.ModifiedLocal) THEN 'APP' ELSE 'EXTERNAL' END ModificationOrigin,
   CASE WHEN EXISTS(SELECT 1 FROM access.AppSecurityChange c WHERE c.SourceId=@Source AND c.DatabaseName=r.DatabaseName AND c.PrincipalKind=r.PrincipalKind
    AND c.PrincipalSid=r.PrincipalSid AND c.State='CONFIRMED' AND c.OperationCode='CHANGE_LOGIN_PASSWORD' AND c.PasswordSetLocal=r.PasswordSetLocal) THEN 'APP' ELSE 'EXTERNAL' END PasswordOrigin
   FROM @Rows r)
  UPDATE old SET PrincipalName=r.PrincipalName,
   ModificationOrigin=CASE WHEN r.ModificationOrigin='APP' THEN 'APP' WHEN old.ModifiedLocal=r.ModifiedLocal THEN old.ModificationOrigin ELSE r.ModificationOrigin END,
   PasswordOrigin=CASE WHEN r.PasswordSetLocal IS NULL THEN old.PasswordOrigin WHEN r.PasswordOrigin='APP' THEN 'APP' WHEN old.PasswordSetLocal IS NULL THEN 'BASELINE'
    WHEN old.PasswordSetLocal=r.PasswordSetLocal THEN old.PasswordOrigin ELSE r.PasswordOrigin END,
   ModificationDetected=CASE WHEN old.ModifiedLocal=r.ModifiedLocal THEN old.ModificationDetected ELSE @Now END,
   PasswordDetected=CASE WHEN r.PasswordSetLocal IS NULL OR old.PasswordSetLocal=r.PasswordSetLocal THEN old.PasswordDetected ELSE @Now END,
   ModifiedLocal=r.ModifiedLocal,PasswordSetLocal=COALESCE(r.PasswordSetLocal,old.PasswordSetLocal),EngineOffsetMinutes=r.EngineOffsetMinutes,LastChecked=@Now
  FROM access.PrincipalMetadataSnapshot old JOIN classified r ON r.DatabaseName=old.DatabaseName AND r.PrincipalKind=old.PrincipalKind AND r.PrincipalSid=old.PrincipalSid WHERE old.ServerId=@ServerId;
  INSERT access.PrincipalMetadataSnapshot
  SELECT @ServerId,r.DatabaseName,r.PrincipalKind,r.PrincipalSid,r.PrincipalName,r.ModifiedLocal,r.PasswordSetLocal,r.EngineOffsetMinutes,
   CASE WHEN EXISTS(SELECT 1 FROM access.AppSecurityChange c WHERE c.SourceId=@Source AND c.DatabaseName=r.DatabaseName AND c.PrincipalKind=r.PrincipalKind AND c.PrincipalSid=r.PrincipalSid AND c.State='CONFIRMED' AND c.DefinitionChanged=1 AND c.ModifiedLocal=r.ModifiedLocal) THEN 'APP' ELSE 'BASELINE' END,
   CASE WHEN r.PasswordSetLocal IS NULL THEN NULL WHEN EXISTS(SELECT 1 FROM access.AppSecurityChange c WHERE c.SourceId=@Source AND c.PrincipalSid=r.PrincipalSid AND c.State='CONFIRMED' AND c.OperationCode='CHANGE_LOGIN_PASSWORD' AND c.PasswordSetLocal=r.PasswordSetLocal) THEN 'APP' ELSE 'BASELINE' END,
   @Now,CASE WHEN r.PasswordSetLocal IS NOT NULL THEN @Now END,@Now
  FROM @Rows r WHERE NOT EXISTS(SELECT 1 FROM access.PrincipalMetadataSnapshot old WHERE old.ServerId=@ServerId AND old.DatabaseName=r.DatabaseName AND old.PrincipalKind=r.PrincipalKind AND old.PrincipalSid=r.PrincipalSid);
  UPDATE access.SecurityEvidenceSource SET LastCollected=@Now,MetadataChecked=@Now,Health=N'Metadatos consultados. Externo = sin registro coincidente en la app; no identifica actor ni todos los cambios.' WHERE SourceId=@Source;
  COMMIT;
 END TRY BEGIN CATCH IF XACT_STATE()<>0 ROLLBACK;THROW;END CATCH;
END;
GO
CREATE OR ALTER PROCEDURE access.usp_RequestValidity_Attach @RequestId bigint,@ExpiresAt datetime2(7)
AS
BEGIN
 SET NOCOUNT ON;SET XACT_ABORT ON;
 EXEC access.usp_App_RequirePermission 'CREATE_REQUEST';
 IF @@TRANCOUNT=0 THROW 51701,'La vigencia debe guardarse en la transacción de la solicitud.',1;
 IF @ExpiresAt IS NULL OR @ExpiresAt<=access.ufn_AppNow() THROW 51702,'La vigencia debe ser futura.',1;
 IF NOT EXISTS(SELECT 1 FROM access.AccessRequest WITH(UPDLOCK,HOLDLOCK) WHERE RequestId=@RequestId
  AND Status='PENDING' AND RequestedBy=access.ufn_App_Principal()
  AND EXISTS(SELECT 1 FROM
   (SELECT OperationCode,PermissionAction FROM access.AccessRequest WHERE RequestId=@RequestId
    UNION ALL SELECT OperationCode,PermissionAction FROM access.AccessRequestStep WHERE RequestId=@RequestId) p
   WHERE p.OperationCode IN('CREATE_SQL_LOGIN','CREATE_WINDOWS_LOGIN','CREATE_DB_USER','CLONE_PERMISSIONS','ADD_ROLE_MEMBER','MODIFY_LOGIN','ADD_SERVER_ROLE_MEMBER')
    OR (p.OperationCode IN('PERMISSION_CHANGE','SERVER_PERMISSION_CHANGE') AND p.PermissionAction='GRANT')))
  THROW 51703,'Esta solicitud no admite vigencia temporal.',1;
 IF EXISTS(SELECT 1 FROM
  (SELECT OperationCode,PermissionAction,ScopeType FROM access.AccessRequest WHERE RequestId=@RequestId
   UNION ALL SELECT OperationCode,PermissionAction,ScopeType FROM access.AccessRequestStep WHERE RequestId=@RequestId) p
  WHERE p.OperationCode IN('PERMISSION_CHANGE','SERVER_PERMISSION_CHANGE') AND p.PermissionAction='GRANT'
   AND ISNULL(p.ScopeType,'') NOT IN('DATABASE','SCHEMA','OBJECT','COLUMN','SERVER'))
  THROW 51727,'Ámbito no compatible con seguimiento temporal.',1;
 INSERT access.RequestValidity(RequestId,ExpiresAt,CreatedBy) VALUES(@RequestId,@ExpiresAt,access.ufn_App_Principal());
END;
GO
CREATE OR ALTER PROCEDURE access.usp_RequestValidity_List
AS
BEGIN SET NOCOUNT ON;EXEC access.usp_App_RequirePermission 'ACCESS_REQUESTS';SELECT RequestId,ExpiresAt FROM access.RequestValidity;END;
GO
CREATE OR ALTER PROCEDURE access.usp_RequestValidity_Get @RequestId bigint,@RequireApproved bit=0
AS
BEGIN
 SET NOCOUNT ON;EXEC access.usp_App_RequirePermission 'ACCESS_REQUESTS';
 IF @RequireApproved=1
 BEGIN
  EXEC access.usp_App_RequirePermission 'REVIEW_REQUEST';
  IF NOT EXISTS(SELECT 1 FROM access.AccessRequest WHERE RequestId=@RequestId AND Status='APPROVED')
   THROW 51723,'La solicitud ya no está aprobada. Actualice la cola antes de ejecutar.',1;
 END;
 SELECT ExpiresAt FROM access.RequestValidity WHERE RequestId=@RequestId;
END;
GO
CREATE OR ALTER PROCEDURE access.usp_TemporaryAccess_RegisterExecution
 @RequestId bigint,@ServerId int,@DatabaseName sysname,@PrincipalSid varbinary(85)
AS
BEGIN
 SET NOCOUNT ON;SET XACT_ABORT ON;EXEC access.usp_App_RequirePermission 'REVIEW_REQUEST';
 DECLARE @Expiry datetime2(7),@Principal nvarchar(256),@Operation varchar(40),@LockResult int;
 SELECT @Expiry=v.ExpiresAt,@Principal=r.TargetPrincipal,@Operation=r.OperationCode
 FROM access.RequestValidity v JOIN access.AccessRequest r ON r.RequestId=v.RequestId
 WHERE r.RequestId=@RequestId AND r.Status='APPROVED';
 IF @Expiry IS NULL RETURN;
 IF @PrincipalSid IS NULL OR DATALENGTH(@PrincipalSid)=0 THROW 51704,'Falta SID comprobado en el destino.',1;
 IF NOT EXISTS(SELECT 1 FROM access.AccessRequestTarget WHERE RequestId=@RequestId AND ServerId=@ServerId AND DatabaseName=@DatabaseName)
  THROW 51705,'Destino ajeno a la solicitud.',1;
 DECLARE @Resources table(Kind varchar(20),Db sysname,Scope varchar(30),Securable nvarchar(776),Permission nvarchar(128),RoleName sysname);
 IF @Operation IN('CREATE_SQL_LOGIN','CREATE_WINDOWS_LOGIN','CLONE_PERMISSIONS')
  INSERT @Resources VALUES('LOGIN',N'','SERVER',N'',N'',N'');
 ELSE
 BEGIN
  INSERT @Resources
  SELECT CASE WHEN OperationCode='CREATE_DB_USER' THEN 'DATABASE_USER' WHEN OperationCode IN('PERMISSION_CHANGE','SERVER_PERMISSION_CHANGE') THEN 'PERMISSION' ELSE 'ROLE_MEMBERSHIP' END,
   CASE WHEN OperationCode IN('SERVER_PERMISSION_CHANGE','ADD_SERVER_ROLE_MEMBER') THEN N'' ELSE @DatabaseName END,
   ISNULL(ScopeType,''),ISNULL(Securable,N''),ISNULL(PermissionName,N''),ISNULL(RoleName,N'')
  FROM(SELECT OperationCode,ScopeType,Securable,PermissionName,PermissionAction,RoleName FROM access.AccessRequest WHERE RequestId=@RequestId
   UNION ALL SELECT OperationCode,ScopeType,Securable,PermissionName,PermissionAction,RoleName FROM access.AccessRequestStep WHERE RequestId=@RequestId) p
  WHERE OperationCode IN('CREATE_DB_USER','ADD_ROLE_MEMBER','MODIFY_LOGIN','ADD_SERVER_ROLE_MEMBER')
     OR (OperationCode IN('PERMISSION_CHANGE','SERVER_PERMISSION_CHANGE') AND PermissionAction='GRANT');
 END;
 BEGIN TRY
  BEGIN TRAN;
  EXEC @LockResult=sys.sp_getapplock @Resource=N'SqlAccessAdmin.TemporaryMetadata',@LockMode='Exclusive',@LockOwner='Transaction',@LockTimeout=5000;
  IF @LockResult<0 THROW 51706,'No se pudo bloquear el registro temporal.',1;
  INSERT access.TemporaryAccess(ServerId,PrincipalSid,PrincipalName,AccessKind,DatabaseName,ScopeType,Securable,PermissionName,RoleName,ExpiresAt,CreatedRequestId,ResourceKey)
  SELECT DISTINCT @ServerId,@PrincipalSid,@Principal,Kind,Db,Scope,Securable,Permission,RoleName,@Expiry,@RequestId,k.ResourceKey
  FROM @Resources r CROSS APPLY(SELECT CONVERT(binary(32),HASHBYTES('SHA2_256',
   CONCAT(@ServerId,N'|',CONVERT(varchar(170),@PrincipalSid,2),N'|',Kind,N'|',Db,N'|',Scope,N'|',Securable,N'|',Permission,N'|',RoleName))) ResourceKey) k
  WHERE NOT EXISTS(SELECT 1 FROM access.TemporaryAccess WHERE CreatedRequestId=@RequestId AND ResourceKey=k.ResourceKey)
    AND NOT EXISTS(SELECT 1 FROM access.TemporaryAccess WHERE IsOpen=1 AND ResourceKey=k.ResourceKey);
  COMMIT;
 END TRY BEGIN CATCH IF XACT_STATE()<>0 ROLLBACK;THROW;END CATCH;
END;
GO
CREATE OR ALTER PROCEDURE access.usp_SecurityMonitoring_Summary
AS
BEGIN
 SET NOCOUNT ON;SET XACT_ABORT ON;EXEC access.usp_App_RequirePermission 'READ';
 DECLARE @Now datetime2(7)=access.ufn_AppNow(),@LockResult int;
 BEGIN TRY
  BEGIN TRAN;
  EXEC @LockResult=sys.sp_getapplock @Resource=N'SqlAccessAdmin.TemporaryMetadata',@LockMode='Exclusive',@LockOwner='Transaction',@LockTimeout=1000;
  IF @LockResult<0 THROW 51706,'Otro evaluador está trabajando. Reintente.',1;
  INSERT access.SecurityAlert(AlertType,AlertKey,TemporaryAccessId,Revision,OccurredAt)
  SELECT TOP(500) 'TEMPORARY_EXPIRED',k.AlertKey,t.TemporaryAccessId,t.Revision,t.ExpiresAt
  FROM access.TemporaryAccess t CROSS APPLY(SELECT CONVERT(binary(32),HASHBYTES('SHA2_256',CONCAT(t.TemporaryAccessId,':',t.Revision))) AlertKey) k
  WHERE IsOpen=1 AND ExpiresAt<=@Now AND NOT EXISTS(SELECT 1 FROM access.SecurityAlert a
   WHERE a.AlertType='TEMPORARY_EXPIRED' AND a.AlertKey=k.AlertKey AND a.IsActive=1)
  ORDER BY ExpiresAt,TemporaryAccessId;
  COMMIT;
 END TRY BEGIN CATCH IF XACT_STATE()<>0 ROLLBACK;THROW;END CATCH;
 SELECT (SELECT COUNT_BIG(*) FROM access.SecurityAlert WHERE IsActive=1 AND AlertType='TEMPORARY_EXPIRED') ExpiredAccesses,
  (SELECT COUNT_BIG(*) FROM access.SecurityAlert WHERE IsActive=1 AND AlertType='PASSWORD_FREQUENCY') PasswordAlerts,
  (SELECT COUNT_BIG(*) FROM access.AppSecurityChange WHERE OperationCode='CHANGE_LOGIN_PASSWORD' AND State IN('PENDING','UNRESOLVED')) UnresolvedEvents,
  (SELECT MIN(MetadataChecked) FROM access.SecurityEvidenceSource) LastCollected,@Now EvaluatedAt;
END;
GO
CREATE OR ALTER PROCEDURE access.usp_TemporaryAccess_List
AS
BEGIN
 SET NOCOUNT ON;EXEC access.usp_App_RequirePermission 'READ';
 SELECT TOP(5000) t.*,s.Name AS Server,
  CASE WHEN IsOpen=0 THEN 'CLOSED' WHEN ExpiresAt<=access.ufn_AppNow() THEN 'EXPIRED_REVIEW' ELSE 'ACTIVE' END ReviewState
 FROM access.TemporaryAccess t JOIN access.ManagedServer s ON s.ServerId=t.ServerId
 ORDER BY IsOpen DESC,ExpiresAt,TemporaryAccessId;
END;
GO
CREATE OR ALTER PROCEDURE access.usp_SecurityAlert_ActiveList
AS
BEGIN
 SET NOCOUNT ON;EXEC access.usp_App_RequirePermission 'READ';
 SELECT TOP(50) a.AlertId,a.AlertType,COALESCE(t.PrincipalName,p.PrincipalName,N'(identidad histórica)') AS Principal,
  COALESCE(ts.Name,ps.Name,N'') AS Server,a.OccurredAt,
  CASE WHEN a.AlertType='TEMPORARY_EXPIRED' THEN CONCAT(t.AccessKind,N' · ',t.DatabaseName,N' ',t.PermissionName,N' ',t.Securable,N' ',t.RoleName,N'. Venció: ',CONVERT(nvarchar(33),t.ExpiresAt,126),N'. Requiere acción manual.')
   ELSE CONCAT(a.ObservedCount,N' cambios confirmados el ',CONVERT(nvarchar(10),a.BusinessDate,23),N' (día de Guatemala).') END Detail
 FROM access.SecurityAlert a
 LEFT JOIN access.TemporaryAccess t ON t.TemporaryAccessId=a.TemporaryAccessId LEFT JOIN access.ManagedServer ts ON ts.ServerId=t.ServerId
 LEFT JOIN access.SecurityEvidenceSource src ON src.SourceId=a.SourceId LEFT JOIN access.ManagedServer ps ON ps.ServerId=src.ServerId
 OUTER APPLY(SELECT TOP(1) h.PrincipalName FROM access.AppSecurityChange h
  WHERE h.SourceId=a.SourceId AND h.PrincipalSid=a.PrincipalSid ORDER BY h.CompletedAt DESC) p
 WHERE a.IsActive=1 ORDER BY a.DetectedAt DESC,a.AlertId DESC;
END;
GO
CREATE OR ALTER PROCEDURE access.usp_TemporaryAccessAction_List
AS
BEGIN SET NOCOUNT ON;EXEC access.usp_App_RequirePermission 'READ';
 SELECT TOP(1000) a.*,t.PrincipalName,s.Name AS Server,
  CONCAT(t.AccessKind,N' · ',t.DatabaseName,N' · ',t.PermissionName,N' ',t.Securable,N' ',t.RoleName) AS Resource
 FROM access.TemporaryAccessAction a JOIN access.TemporaryAccess t ON t.TemporaryAccessId=a.TemporaryAccessId
 JOIN access.ManagedServer s ON s.ServerId=t.ServerId ORDER BY a.IsPending DESC,a.ActionId DESC;END;
GO
CREATE OR ALTER PROCEDURE access.usp_TemporaryAccessAction_Create
 @TemporaryAccessId bigint,@ExpectedRowVersion binary(8),@ActionCode varchar(10),@NewExpiresAt datetime2(7)=NULL,
 @Ticket varchar(50),@Reason nvarchar(1000)
AS
BEGIN
 SET NOCOUNT ON;SET XACT_ABORT ON;EXEC access.usp_App_RequirePermission 'ADMIN';
 IF @ActionCode IS NULL OR @ActionCode NOT IN('EXTEND','CLOSE') OR LEN(LTRIM(RTRIM(@Reason)))<10
  THROW 51707,'Acción o motivo inválidos.',1;
 DECLARE @Tickets table(RESPONSABLE nvarchar(4000),CLIENTE nvarchar(4000),ID_COMPUESTO varchar(50),ASUNTO nvarchar(4000),DESCRIPCION nvarchar(max),ESTADO nvarchar(4000));
 INSERT @Tickets EXEC dbo.sp_VerificarTicketExiste @Ticket=@Ticket;
 IF NOT EXISTS(SELECT 1 FROM @Tickets WHERE ID_COMPUESTO=@Ticket) THROW 51708,'Ticket activo no encontrado.',1;
 BEGIN TRY
  BEGIN TRAN;
  DECLARE @Revision int,@Expiry datetime2(7);
  SELECT @Revision=Revision,@Expiry=ExpiresAt FROM access.TemporaryAccess WITH(UPDLOCK,HOLDLOCK)
   WHERE TemporaryAccessId=@TemporaryAccessId AND IsOpen=1 AND RowVersion=@ExpectedRowVersion;
  IF @Revision IS NULL THROW 51709,'La vigencia cambió o ya está cerrada. Actualice.',1;
  IF @ActionCode='EXTEND' AND (@NewExpiresAt IS NULL OR @NewExpiresAt<=@Expiry OR @NewExpiresAt<=access.ufn_AppNow())
   THROW 51710,'La extensión debe ser futura y mayor a la fecha actual.',1;
  INSERT access.TemporaryAccessAction(TemporaryAccessId,ActionCode,ExpectedRevision,NewExpiresAt,Ticket,Reason,RequestedBy)
  VALUES(@TemporaryAccessId,@ActionCode,@Revision,CASE WHEN @ActionCode='EXTEND' THEN @NewExpiresAt END,@Ticket,@Reason,access.ufn_App_Principal());
  DECLARE @Detail nvarchar(2000)=CONCAT('Temporal=',@TemporaryAccessId,'; Acción=',@ActionCode,'; Nueva fecha=',CONVERT(nvarchar(33),@NewExpiresAt,126),'; Ticket=',@Ticket);
  EXEC access.usp_Audit_Write @Form=N'Usuarios temporales',@Action=N'Solicitar revisión',@Success=1,@Detail=@Detail;
  COMMIT;
 END TRY BEGIN CATCH IF XACT_STATE()<>0 ROLLBACK;THROW;END CATCH;
END;
GO
CREATE OR ALTER PROCEDURE access.usp_TemporaryAccessAction_Review @ActionId bigint,@Approve bit
AS
BEGIN
 SET NOCOUNT ON;SET XACT_ABORT ON;EXEC access.usp_App_RequirePermission 'ADMIN';
 BEGIN TRY
 BEGIN TRAN;
 IF @Approve=1 AND EXISTS(SELECT 1 FROM access.TemporaryAccessAction WITH(UPDLOCK,HOLDLOCK)
  WHERE ActionId=@ActionId AND ActionCode='EXTEND' AND NewExpiresAt<=access.ufn_AppNow())
  THROW 51710,'La extensión ya venció. Rechace la acción y cree una nueva.',1;
 UPDATE access.TemporaryAccessAction SET Status=CASE WHEN @Approve=1 THEN 'APPROVED' ELSE 'REJECTED' END,
  ReviewedBy=access.ufn_App_Principal(),IsPending=@Approve WHERE ActionId=@ActionId AND (Status='PENDING' OR (@Approve=0 AND Status='APPROVED'));
 IF @@ROWCOUNT<>1 THROW 51711,'La acción ya fue revisada.',1;
 DECLARE @Detail nvarchar(2000)=CONCAT('Acción temporal #',@ActionId,'; Aprobada=',@Approve);
 EXEC access.usp_Audit_Write @Form=N'Usuarios temporales',@Action=N'Revisar acción',@Success=1,@Detail=@Detail;
 COMMIT;
 END TRY BEGIN CATCH IF XACT_STATE()<>0 ROLLBACK;THROW;END CATCH;
END;
GO
CREATE OR ALTER PROCEDURE access.usp_TemporaryAccessAction_Begin @ActionId bigint
AS
BEGIN
 SET NOCOUNT ON;SET XACT_ABORT ON;EXEC access.usp_App_RequirePermission 'ADMIN';
 BEGIN TRY
  BEGIN TRAN;
  UPDATE a SET Status='EXECUTING',ExecutingBy=access.ufn_App_Principal()
  FROM access.TemporaryAccessAction a JOIN access.TemporaryAccess t ON t.TemporaryAccessId=a.TemporaryAccessId
  WHERE a.ActionId=@ActionId AND a.Status='APPROVED' AND t.IsOpen=1 AND t.Revision=a.ExpectedRevision
   AND (a.ActionCode='CLOSE' OR a.NewExpiresAt>access.ufn_AppNow());
  IF @@ROWCOUNT<>1 THROW 51712,'La acción no está aprobada, cambió la vigencia o la extensión ya venció.',1;
  SELECT t.*,s.Name AS Server,CASE WHEN t.ExpiresAt<=access.ufn_AppNow() THEN 'EXPIRED_REVIEW' ELSE 'ACTIVE' END ReviewState
  FROM access.TemporaryAccessAction a JOIN access.TemporaryAccess t ON t.TemporaryAccessId=a.TemporaryAccessId
  JOIN access.ManagedServer s ON s.ServerId=t.ServerId WHERE ActionId=@ActionId;
  COMMIT;
 END TRY BEGIN CATCH IF XACT_STATE()<>0 ROLLBACK;THROW;END CATCH;
END;
GO
CREATE OR ALTER PROCEDURE access.usp_TemporaryAccessAction_Complete @ActionId bigint,@Success bit,@Detail nvarchar(2000)
AS
BEGIN
 SET NOCOUNT ON;SET XACT_ABORT ON;EXEC access.usp_App_RequirePermission 'ADMIN';
 DECLARE @Id bigint,@Revision int,@Action varchar(10),@Expiry datetime2(7),@LockResult int;
 BEGIN TRY
  BEGIN TRAN;
  EXEC @LockResult=sys.sp_getapplock @Resource=N'SqlAccessAdmin.TemporaryMetadata',@LockMode='Exclusive',@LockOwner='Transaction',@LockTimeout=5000;
  IF @LockResult<0 THROW 51706,'No se pudo bloquear la vigencia.',1;
  SELECT @Id=TemporaryAccessId,@Revision=ExpectedRevision,@Action=ActionCode,@Expiry=NewExpiresAt
  FROM access.TemporaryAccessAction WITH(UPDLOCK,HOLDLOCK) WHERE ActionId=@ActionId AND Status='EXECUTING' AND ExecutingBy=access.ufn_App_Principal();
  IF @Id IS NULL THROW 51713,'La acción no está en ejecución para esta identidad.',1;
  IF @Success=1
  BEGIN
   IF @Action='EXTEND' AND @Expiry<=access.ufn_AppNow() THROW 51710,'La extensión ya venció; no se resolvió la alerta.',1;
   UPDATE access.TemporaryAccess SET ExpiresAt=CASE WHEN @Action='EXTEND' THEN @Expiry ELSE ExpiresAt END,
    IsOpen=CASE WHEN @Action='CLOSE' THEN 0 ELSE 1 END,Revision=Revision+1,
    ClosedAt=CASE WHEN @Action='CLOSE' THEN access.ufn_AppNow() END,ClosedBy=CASE WHEN @Action='CLOSE' THEN access.ufn_App_Principal() END
   WHERE TemporaryAccessId=@Id AND Revision=@Revision AND IsOpen=1;
   IF @@ROWCOUNT<>1 THROW 51709,'La vigencia cambió durante la ejecución.',1;
   UPDATE access.SecurityAlert SET IsActive=0,ResolvedAt=access.ufn_AppNow(),ResolvedBy=access.ufn_App_Principal(),
    ResolutionActionId=@ActionId,ResolutionReason=@Detail
   WHERE TemporaryAccessId=@Id AND Revision=@Revision AND AlertType='TEMPORARY_EXPIRED' AND IsActive=1;
  END;
  UPDATE access.TemporaryAccessAction SET Status=CASE WHEN @Success=1 THEN 'EXECUTED' ELSE 'FAILED' END,
   IsPending=0,CompletedAt=access.ufn_AppNow(),Result=@Detail WHERE ActionId=@ActionId;
  DECLARE @AuditDetail nvarchar(2000)=LEFT(CONCAT(N'Acción #',@ActionId,N'; Temporal #',@Id,N'; ',@Action,N'; ',@Detail),2000);
  EXEC access.usp_Audit_Write @Form=N'Usuarios temporales',@Action=N'Ejecutar acción',@Success=@Success,@Detail=@AuditDetail;
  COMMIT;
 END TRY BEGIN CATCH IF XACT_STATE()<>0 ROLLBACK;THROW;END CATCH;
END;
GO
CREATE OR ALTER TRIGGER access.tr_AccessRequest_TemporaryValidity ON access.AccessRequest AFTER UPDATE
AS
BEGIN
 SET NOCOUNT ON;
 IF EXISTS(SELECT 1 FROM inserted i JOIN deleted d ON d.RequestId=i.RequestId JOIN access.RequestValidity v ON v.RequestId=i.RequestId
  WHERE i.Status='APPROVED' AND d.Status<>'APPROVED' AND v.ExpiresAt<=access.ufn_AppNow())
  THROW 51720,'La vigencia temporal ya venció. Genere una solicitud nueva.',1;
END;
GO
CREATE OR ALTER PROCEDURE access.usp_PasswordAlert_Resolve @AlertId bigint,@Reason nvarchar(1000)
AS
BEGIN
 SET NOCOUNT ON;SET XACT_ABORT ON;EXEC access.usp_App_RequirePermission 'AUDIT';
 IF @Reason IS NULL OR LEN(LTRIM(RTRIM(@Reason)))<10 THROW 51728,'Registre un motivo de revisión de al menos 10 caracteres.',1;
 DECLARE @ServerId int=(SELECT src.ServerId FROM access.SecurityAlert a JOIN access.SecurityEvidenceSource src ON src.SourceId=a.SourceId
  WHERE a.AlertId=@AlertId AND a.AlertType='PASSWORD_FREQUENCY'),@LockResult int;
 IF @ServerId IS NULL THROW 51729,'Solo se pueden revisar alertas de frecuencia de contraseñas.',1;
 DECLARE @Resource nvarchar(255)=CONCAT(N'SqlAccessAdmin.Evidence.',@ServerId);
 BEGIN TRY
  BEGIN TRAN;
  EXEC @LockResult=sys.sp_getapplock @Resource=@Resource,@LockMode='Exclusive',@LockOwner='Transaction',@LockTimeout=5000;
  IF @LockResult<0 THROW 51716,'Otra recolección está trabajando sobre el destino.',1;
  UPDATE access.SecurityAlert SET IsActive=0,ResolvedAt=access.ufn_AppNow(),ResolvedBy=access.ufn_App_Principal(),ResolutionReason=@Reason
   WHERE AlertId=@AlertId AND AlertType='PASSWORD_FREQUENCY' AND IsActive=1;
  IF @@ROWCOUNT<>1 THROW 51730,'La alerta ya fue revisada. Actualice el resumen.',1;
  DECLARE @Detail nvarchar(2000)=CONCAT(N'Alerta #',@AlertId,N'; ',@Reason);
  EXEC access.usp_Audit_Write @Form=N'Resumen',@Action=N'Revisar frecuencia de contraseñas',@Success=1,@Detail=@Detail;
  COMMIT;
 END TRY BEGIN CATCH IF XACT_STATE()<>0 ROLLBACK;THROW;END CATCH;
END;
GO
GRANT EXECUTE ON access.usp_PasswordAlert_Resolve TO SqlAccessAdmin_Users;
GO

CREATE OR ALTER PROCEDURE access.usp_Report_SecurityChanges @From datetime2(7),@To datetime2(7),@ServerId int=NULL
AS
BEGIN
 SET NOCOUNT ON;EXEC access.usp_App_RequirePermission 'AUDIT';
 IF @From IS NULL OR @To IS NULL OR @From>=@To OR DATEDIFF(day,@From,@To)>367 THROW 51714,'Período inválido (máximo un año).',1;
 ;WITH events AS
 (SELECT COALESCE(c.CompletedAt,c.PreparedAt) Recorded,s.Name ServerName,NULLIF(c.DatabaseName,N'') DatabaseName,c.PrincipalName,
  CONVERT(varchar(170),c.PrincipalSid,2) Sid,N'Aplicación' Origin,c.OperationCode ChangeType,c.State Result,e.Actor,
  e.RequestId,COALESCE(r.ExternalTicketNumber,a.Ticket) Ticket,
  CONCAT(c.OperationCode,N' ',c.PermissionAction,N' ',c.PermissionName,N' ',c.ScopeType,N' ',c.Securable,N' ',c.RoleName) Detail,
  c.ModifiedLocal EngineDate,c.EventId EventId,c.CompletedAt Checked
  FROM access.AppSecurityChange c JOIN access.AppExecution e ON e.ExecutionId=c.ExecutionId JOIN access.ManagedServer s ON s.ServerId=e.ServerId
  LEFT JOIN access.AccessRequest r ON r.RequestId=e.RequestId LEFT JOIN access.TemporaryAccessAction a ON a.ActionId=e.ActionId
  WHERE (@ServerId IS NULL OR e.ServerId=@ServerId)
  UNION ALL
  SELECT m.ModificationDetected,s.Name,NULLIF(m.DatabaseName,N''),m.PrincipalName,CONVERT(varchar(170),m.PrincipalSid,2),
   N'Externo — sin registro en la app',N'Última modificación del principal',N'REFERENCIA',NULL,NULL,NULL,
   N'Fecha observada sin operación coincidente en la app. No identifica actor ni reconstruye permisos o cambios anteriores.',m.ModifiedLocal,NULL,m.LastChecked
  FROM access.PrincipalMetadataSnapshot m JOIN access.ManagedServer s ON s.ServerId=m.ServerId
  WHERE m.ModificationOrigin='EXTERNAL' AND (@ServerId IS NULL OR m.ServerId=@ServerId))
 SELECT TOP(5000) Recorded AS [Fecha de registro],ServerName Servidor,DatabaseName Base,PrincipalName Principal,Sid SID,Origin Fuente,
  ChangeType Cambio,Result Resultado,Actor AS [Ejecutor aplicativo],RequestId Solicitud,Ticket,Detail Detalle,EngineDate AS [Última modificación],Checked AS [Última consulta],EventId Evento
 FROM events WHERE Recorded>=@From AND Recorded<@To ORDER BY Recorded DESC,PrincipalName;
END;
GO
CREATE OR ALTER PROCEDURE access.usp_Report_PasswordChanges @From datetime2(7),@To datetime2(7),@ServerId int=NULL,@History bit=0
AS
BEGIN
 SET NOCOUNT ON;EXEC access.usp_App_RequirePermission 'AUDIT';
 IF @From IS NULL OR @To IS NULL OR @From>=@To OR DATEDIFF(day,@From,@To)>367 THROW 51714,'Período inválido (máximo un año).',1;
 IF @History=1
 BEGIN
  ;WITH history AS
  (SELECT COALESCE(c.CompletedAt,c.PreparedAt) Recorded,s.Name ServerName,c.PrincipalName,CONVERT(varchar(170),c.PrincipalSid,2) Sid,
   N'Aplicación' Origin,c.State Result,e.Actor,e.RequestId,r.ExternalTicketNumber Ticket,c.PasswordSetLocal EngineDate,c.CompletedAt Checked,
   CASE WHEN c.State='CONFIRMED' THEN N'Cambio confirmado desde la app; incluido en el contador.' ELSE N'Resultado no confirmado; excluido del contador.' END Detail
   FROM access.AppSecurityChange c JOIN access.AppExecution e ON e.ExecutionId=c.ExecutionId JOIN access.ManagedServer s ON s.ServerId=e.ServerId
   LEFT JOIN access.AccessRequest r ON r.RequestId=e.RequestId
   WHERE c.OperationCode='CHANGE_LOGIN_PASSWORD' AND (@ServerId IS NULL OR e.ServerId=@ServerId)
   UNION ALL
   SELECT m.PasswordDetected,s.Name,m.PrincipalName,CONVERT(varchar(170),m.PrincipalSid,2),N'Externo — sin registro en la app',N'REFERENCIA',NULL,NULL,NULL,m.PasswordSetLocal,m.LastChecked,
    N'Última fecha de contraseña observada. No identifica actor ni cantidad de cambios; excluida del contador.'
   FROM access.PrincipalMetadataSnapshot m JOIN access.ManagedServer s ON s.ServerId=m.ServerId
   WHERE m.PrincipalKind='LOGIN' AND m.PasswordOrigin='EXTERNAL' AND (@ServerId IS NULL OR m.ServerId=@ServerId))
  SELECT TOP(5000) Recorded AS [Fecha de registro],ServerName Servidor,PrincipalName Login,Sid SID,Origin Fuente,Result Resultado,
   Actor AS [Ejecutor aplicativo],RequestId Solicitud,Ticket,EngineDate AS [Última contraseña],Checked AS [Última consulta],Detail Detalle
  FROM history WHERE Recorded>=@From AND Recorded<@To ORDER BY Recorded DESC,PrincipalName;
  RETURN;
 END;
 DECLARE @FromLocal datetime2(7)=CONVERT(datetime2(7),@From),
  @ToLocal datetime2(7)=CONVERT(datetime2(7),@To);
 DECLARE @Daily table(SourceId uniqueidentifier,PrincipalSid varbinary(85),BusinessDate date,PrincipalName nvarchar(256),Changes bigint,LastChange datetime2(7));
 IF CONVERT(time,@FromLocal)='00:00:00' AND CONVERT(time,@ToLocal)='00:00:00'
  INSERT @Daily SELECT d.SourceId,d.PrincipalSid,d.BusinessDate,d.PrincipalName,d.ChangeCount,d.LastChange
   FROM access.AppPasswordDaily d JOIN access.SecurityEvidenceSource src ON src.SourceId=d.SourceId
   WHERE d.BusinessDate>=CONVERT(date,@FromLocal) AND d.BusinessDate<CONVERT(date,@ToLocal) AND (@ServerId IS NULL OR src.ServerId=@ServerId);
 ELSE
  INSERT @Daily SELECT c.SourceId,c.PrincipalSid,CONVERT(date,c.CompletedAt),
   MAX(c.PrincipalName),COUNT_BIG(*),MAX(c.CompletedAt)
   FROM access.AppSecurityChange c JOIN access.SecurityEvidenceSource src ON src.SourceId=c.SourceId
   WHERE c.State='CONFIRMED' AND c.OperationCode='CHANGE_LOGIN_PASSWORD' AND c.CompletedAt>=@From AND c.CompletedAt<@To
    AND (@ServerId IS NULL OR src.ServerId=@ServerId)
   GROUP BY c.SourceId,c.PrincipalSid,CONVERT(date,c.CompletedAt);
 SELECT TOP(1000) s.Name Servidor,MAX(d.PrincipalName) Login,CONVERT(varchar(170),d.PrincipalSid,2) SID,N'Aplicación' Fuente,
  SUM(d.Changes) AS [Total de cambios confirmados],MAX(d.Changes) AS [Máximo diario],SUM(CASE WHEN d.Changes>=3 THEN 1 ELSE 0 END) AS [Días con 3 o más],
  MAX(d.LastChange) AS [Último cambio],src.CoverageStarted AS [Inicio de seguimiento],src.MetadataChecked AS [Última consulta de metadatos]
 FROM @Daily d JOIN access.SecurityEvidenceSource src ON src.SourceId=d.SourceId JOIN access.ManagedServer s ON s.ServerId=src.ServerId
 GROUP BY s.Name,d.SourceId,d.PrincipalSid,src.CoverageStarted,src.MetadataChecked ORDER BY SUM(d.Changes) DESC;
END;
GO
-- Contratos anteriores conservan sus datos históricos, pero no aceptan nueva evidencia.
DROP PROCEDURE IF EXISTS access.usp_NativePassword_Import;
DROP PROCEDURE IF EXISTS access.usp_NativePassword_Reconcile;
DROP PROCEDURE IF EXISTS access.usp_SecurityEvidence_Import;
GO
GRANT EXECUTE ON access.usp_AppExecution_Begin TO SqlAccessAdmin_Users;
GRANT EXECUTE ON access.usp_AppChange_Prepare TO SqlAccessAdmin_Users;
GRANT EXECUTE ON access.usp_AppChange_Complete TO SqlAccessAdmin_Users;
GRANT EXECUTE ON access.usp_PrincipalMetadata_Import TO SqlAccessAdmin_Users;
GRANT EXECUTE ON access.usp_RequestValidity_Attach TO SqlAccessAdmin_Users;
GRANT EXECUTE ON access.usp_RequestValidity_Get TO SqlAccessAdmin_Users;
GRANT EXECUTE ON access.usp_RequestValidity_List TO SqlAccessAdmin_Users;
GRANT EXECUTE ON access.usp_TemporaryAccess_RegisterExecution TO SqlAccessAdmin_Users;
GRANT EXECUTE ON access.usp_SecurityMonitoring_Summary TO SqlAccessAdmin_Users;
GRANT EXECUTE ON access.usp_SecurityAlert_ActiveList TO SqlAccessAdmin_Users;
GRANT EXECUTE ON access.usp_TemporaryAccess_List TO SqlAccessAdmin_Users;
GRANT EXECUTE ON access.usp_TemporaryAccessAction_List TO SqlAccessAdmin_Users;
GRANT EXECUTE ON access.usp_TemporaryAccessAction_Create TO SqlAccessAdmin_Users;
GRANT EXECUTE ON access.usp_TemporaryAccessAction_Review TO SqlAccessAdmin_Users;
GRANT EXECUTE ON access.usp_TemporaryAccessAction_Begin TO SqlAccessAdmin_Users;
GRANT EXECUTE ON access.usp_TemporaryAccessAction_Complete TO SqlAccessAdmin_Users;
GRANT EXECUTE ON access.usp_Report_SecurityChanges TO SqlAccessAdmin_Users;
GRANT EXECUTE ON access.usp_Report_PasswordChanges TO SqlAccessAdmin_Users;
UPDATE access.SecurityMonitoringVersion SET Version=4 WHERE Id=1;
GO
