# Documentación de Usuario

**SQL Access Admin — Guía del usuario: el «Cómo se usa»**

Fecha de revisión: 26 de octubre de 2026.

Esta guía incluye administración de accesos, cambio de contraseña SQL, vigencias temporales, alertas y los cinco reportes disponibles. Las fechas se muestran en hora de Guatemala, con formato `yyyy-MM-dd HH:mm:ss`. El vencimiento de una vigencia genera una alerta y conserva el acceso hasta completar una acción administrativa.

## Contenido

- [1. Introducción](#1-introducción)
- [2. Requisitos previos](#2-requisitos-previos)
- [3. Paso a paso: comenzar a utilizar la aplicación](#3-paso-a-paso-comenzar-a-utilizar-la-aplicación)
  - [3.14. Consultar reportes](#314-consultar-reportes)
  - [3.15. Cambiar la contraseña de un login SQL](#315-cambiar-la-contraseña-de-un-login-sql)
  - [3.16. Asignar y gestionar vigencias temporales](#316-asignar-y-gestionar-vigencias-temporales)
  - [3.17. Consultar y atender alertas](#317-consultar-y-atender-alertas)
- [4. Preguntas frecuentes y resolución de problemas](#4-preguntas-frecuentes-y-resolución-de-problemas)

## 1. Introducción

SQL Access Admin es una aplicación de escritorio para administrar cuentas, roles y permisos en servidores SQL Server. Permite crear cuentas, modificar sus accesos, copiar permisos de una cuenta de referencia y cambiar contraseñas SQL, conservando el ticket, la identidad de quien realiza cada gestión y sus resultados. También permite asignar vigencias, revisar alertas y exportar reportes de configuración y seguimiento de seguridad.

El trabajo habitual sigue esta secuencia:

1. Seleccionar el servidor donde se necesita trabajar.
2. Preparar el cambio y validar su ticket.
3. Enviar la solicitud.
4. Revisar y confirmar la solicitud.
5. Ejecutarla y comprobar el resultado.

**Enviar una solicitud o confirmarla todavía no modifica los accesos. Los cambios se aplican al ejecutarla.** Las funciones disponibles dependen de los roles asignados a su cuenta.

### Conceptos que verá en pantalla

| Término | Significado práctico |
| --- | --- |
| Servidor pivote / `adminDB` | Conexión administrativa de entrada. Conserva la configuración, las solicitudes y la auditoría. |
| Servidor de trabajo | Instancia SQL Server donde se consultarán o cambiarán los accesos. Cada solicitud pertenece a un solo servidor. |
| Login | Cuenta que permite iniciar sesión en una instancia SQL Server. |
| Usuario de base de datos | Identidad asociada a una cuenta dentro de una base. Tener un login no concede por sí solo acceso a todas las bases. |
| Rol SQL | Grupo de permisos de una instancia o base de datos. La aplicación permite asignar o retirar membresías autorizadas. |
| Rol de aplicación | Función que puede desempeñar una persona dentro de SQL Access Admin, como Operador o Auditor. |
| Ticket | Identificador de una gestión existente y activa que justifica el cambio solicitado. |
| Objeto | Elemento de una base, como una tabla, vista, función o procedimiento. |
| Vigencia temporal | Fecha de revisión de un acceso nuevo. Vencer genera una alerta; no retira el acceso automáticamente. |
| Aplicación / Externo | Origen del seguimiento: operación registrada por la app o última fecha del motor sin registro confirmado coincidente. Externo no identifica quién hizo el cambio. |
| Por conciliar | Resultado que necesita revisión porque no hay confirmación suficiente de su finalización. No significa ejecución correcta. |

## 2. Requisitos previos

### En su equipo

- **Windows**, para ejecutar la aplicación de escritorio.
- La **carpeta completa de SQL Access Admin** entregada por soporte, con el ejecutable `SqlAccessAdmin.exe`, sus archivos y subcarpetas. Si recibe un archivo comprimido, extráigalo antes de abrir la aplicación.
- **.NET Desktop Runtime 8**, cuando la entrega requiera el runtime instalado. Si soporte entrega una versión que ya lo incluye, no necesita instalarlo por separado.
- Conectividad con el servidor pivote y los servidores de trabajo. Conéctese a la red corporativa o VPN cuando su organización lo requiera.

Para el uso normal del ejecutable no necesita instalar Visual Studio, el SDK de .NET, SQL Server ni SQL Server Management Studio en su equipo.

### Información y acceso que debe recibir

Solicite al administrador los datos del servidor pivote: **servidor**, **instancia** si corresponde, **base administrativa**, tipo de autenticación y configuración de certificado. Necesitará una cuenta registrada, activa y con al menos un rol de aplicación.

Para solicitar cambios también necesita un ticket activo y conocer el servidor, la cuenta y las bases u objetos que se modificarán.

La preparación de `adminDB`, los permisos de conexión y la configuración de los destinos corresponden al DBA o administrador. La aplicación no instala ni actualiza la base administrativa automáticamente. Las instrucciones de infraestructura se encuentran en la [guía de preparación de adminDB](../README.md).

### Qué permite cada rol

| Rol | Funciones disponibles |
| --- | --- |
| **Administrador** | Todas las funciones: solicitudes, ejecución, servidores, usuarios autorizados, política y auditoría. |
| **Operador** | Crear solicitudes de accesos o contraseña SQL; consultar seguimiento, historial y los tres reportes directos. Consultar vigencias y alertas. |
| **AprobadorEjecutor** | Revisar, confirmar, rechazar y ejecutar solicitudes ordinarias; consultar su historial y los tres reportes directos. Consultar vigencias y alertas. |
| **Auditor** | Consultar resumen, auditoría, vigencias y los reportes centrales Cambios de accesos y Cambios de contraseña; registrar revisión de alertas de contraseña. |

Todos los usuarios autorizados pueden consultar **Resumen**. Los roles se pueden combinar y sus funciones se suman. Por ejemplo, Operador + AprobadorEjecutor permite completar el ciclo de una solicitud. Tener privilegios administrativos en SQL Server no sustituye el registro de acceso a esta aplicación.

Solo **Administrador** solicita, confirma, rechaza y ejecuta extensiones o cierres de accesos temporales. Administrador y Auditor consultan/exportan los dos reportes centrales y atienden alertas de contraseña. Los reportes directos **Permisos por usuario**, **Catálogo de roles** e **Inactividad de credenciales** requieren Administrador, Operador o AprobadorEjecutor; Auditor por sí solo no obtiene credenciales de los destinos.

## 3. Paso a paso: comenzar a utilizar la aplicación

### 3.1. Abrir e iniciar sesión

1. Abra la carpeta entregada por soporte y haga doble clic en **SqlAccessAdmin.exe**.
2. En **Ingreso autorizado**, complete los datos del servidor administrativo:

   | Campo | Qué ingresar |
   | --- | --- |
   | **Servidor pivote** | Nombre o dirección del servidor proporcionado por el administrador. El valor inicial `localhost` solo sirve si el pivote está en su propio equipo. |
   | **Instancia** | Nombre de la instancia, si corresponde. Déjelo vacío para la instancia predeterminada. |
   | **Base administrativa** | Nombre indicado por el administrador; normalmente `adminDB`. |

3. Elija cómo conectarse:
   - Con **Usar autenticación integrada de Windows** marcada, se utiliza la cuenta Windows con la que ejecuta la aplicación.
   - Para autenticación SQL, desmarque esa opción e ingrese **Usuario SQL** y **Contraseña SQL**.
4. Mantenga **Cifrar conexión** activado. Configure **Confiar en certificado** según las indicaciones del administrador.
5. Pulse **Ingresar** y espere a que se abra la ventana principal. Si necesita corregir la conexión mientras se está intentando, pulse **Cancelar conexión**.

La conexión de esta pantalla es la del pivote. El servidor donde se gestionarán los permisos se elige después, dentro de **Administrar accesos**.

### 3.2. Reconocer la pantalla principal

En el menú lateral verá su identidad, los roles de la sesión y los módulos disponibles:

| Módulo | Para qué se utiliza |
| --- | --- |
| **Resumen** | Ver sesión, totales, vencimientos, alertas de contraseña y cambios de contraseña por conciliar. **Ver alertas** abre su detalle; **Actualizar resumen** consulta de nuevo. |
| **Administrar accesos** | Preparar solicitudes y consultar la cola de confirmación y ejecución. |
| **Reportes** | Consultar permisos por usuario, catálogo de roles, antigüedad de credenciales y cambios de accesos/contraseña, según los roles de sesión. |
| **Usuarios temporales** | Consultar vigencias; el Administrador solicita y procesa extensiones o cierres. |
| **Historial de solicitudes** | Revisar solicitudes finalizadas por servidor. |
| **Servidores** | Configurar las conexiones de trabajo. Requiere Administrador. |
| **Usuarios autorizados** | Administrar quién puede entrar a la aplicación y con qué roles. Requiere Administrador. |
| **Política de acceso** | Definir qué roles y permisos puede gestionar la herramienta. Requiere Administrador. |
| **Auditoría** | Consultar acciones registradas y validar la integridad del registro. Requiere Auditor o Administrador. |

Si una acción está deshabilitada, compruebe los roles de su sesión y el mensaje de estado de la pantalla.

### 3.3. Elegir el servidor y validar el ticket

1. Entre en **Administrar accesos**.
2. Seleccione un **Servidor de trabajo**. Revise el nombre que aparece en la cabecera: las solicitudes que prepare pertenecerán a ese servidor.
3. Abra la opción que necesita: **1. Modificar accesos**, **2. Crear usuario** o **3. Copiar permisos**.
4. Cuando se muestre el formulario, escriba el identificador completo en **Número de ticket** y pulse **Validar ticket**. Por ejemplo, `TIC-CH-43442` ilustra el formato; debe usar un ticket real de su organización.
5. Espere el mensaje de ticket activo verificado y revise **Motivo de la solicitud**. La aplicación lo completa con la descripción del ticket; este campo es de solo lectura.

Si cambia el identificador, debe validarlo nuevamente. Si el motivo es incorrecto o insuficiente, solicite corregir la información del ticket antes de continuar.

### 3.4. Modificar accesos de una cuenta existente

1. En **1. Modificar accesos**, busque el login por nombre. Puede filtrar por tipo de login y pulsar **Actualizar** para volver a consultar.
2. Selecciónelo y pulse **Cargar y modificar accesos**, o haga doble clic sobre él.
3. Compruebe el login y el servidor que aparecen en la cabecera y valide el ticket.
4. En **Elija la base de datos**, seleccione la base donde necesita trabajar.
5. Abra la sección correspondiente:
   - **Mapeo y roles de base**: marque un rol para asignarlo o desmárquelo para retirarlo. Las casillas inicialmente marcadas representan las membresías actuales. Solo se enviarán los cambios y únicamente podrá modificar roles autorizados.
   - **Permisos por objeto**: elija el alcance, seleccione los objetos cuando corresponda y marque las acciones necesarias. Use los filtros de esquema, tipo y búsqueda para localizar elementos.
6. Revise la base elegida y el resumen de cambios. Pulse **Enviar a confirmación**.
7. Anote el número de solicitud y continúe con [Confirmar y ejecutar](#37-confirmar-rechazar-y-ejecutar-solicitudes), o deje la gestión al AprobadorEjecutor si su rol solo permite crearla.

Los cambios de roles y permisos de la gestión se reúnen en una solicitud. Trabaje sobre la base seleccionada y revise su detalle antes de ejecutarla. Para editar otra cuenta, utilice **Cambiar usuario**; los datos que aún no haya enviado son un borrador.

#### Elegir el alcance del permiso

- **Toda la base de datos** concede el permiso de forma general. Su alcance puede incluir objetos actuales y futuros.
- **Solo objetos específicos** permite elegir tablas, vistas, funciones o procedimientos concretos. Marque solo las acciones que necesita la cuenta.
- **Permisos adicionales · base, esquema o columna** permite trabajar con otras combinaciones autorizadas. Seleccione acción, ámbito y permiso, y complete el elemento siguiendo la ayuda del formulario. Por ejemplo, una columna se indica como `esquema.objeto.columna`, sin corchetes.

| Permiso habitual | Qué permite |
| --- | --- |
| `SELECT` | Consultar datos. |
| `INSERT` | Agregar registros. |
| `UPDATE` | Modificar registros. |
| `DELETE` | Eliminar registros. |
| `EXECUTE` | Ejecutar procedimientos o funciones compatibles. |
| `REFERENCES` | Referenciar el elemento, por ejemplo al definir determinadas relaciones o dependencias. |

La interfaz habilita las opciones compatibles con cada objeto y permitidas por la política. Por ejemplo, una función escalar utiliza `EXECUTE` y una función tabular utiliza `SELECT`.

En las opciones avanzadas, **GRANT** concede un permiso, **DENY** lo deniega explícitamente y **REVOKE** retira una concesión o denegación explícita. Retirar un permiso directo puede dejar accesos que la cuenta siga recibiendo por un rol. Revise la advertencia del formulario al trabajar con columnas: un permiso de columna puede prevalecer sobre una denegación de objeto.

#### Accesos de instancia

Para permisos o roles del servidor, seleccione el login y abra **Acceso de instancia**. Elija **Permisos de instancia**, **Asignar rol de servidor** o **Retirar rol de servidor**, complete el formulario y envíe la solicitud con su ticket. Las opciones deben estar autorizadas para ese destino y pasan por la misma confirmación y ejecución.

#### Consultar desde el explorador

El **Explorador de seguridad SQL Server** permite expandir las carpetas de servidores, bases, logins y usuarios. Al seleccionar un elemento, puede consultar sus permisos explícitos y asignaciones. Las acciones de la barra y del menú contextual dependen del elemento seleccionado y de los roles de su sesión.

### 3.5. Crear una cuenta y sus accesos

1. Seleccione **2. Crear usuario** en el servidor de trabajo.
2. En **Paso 1: Datos de la cuenta**, valide el ticket y elija **Cuenta SQL** o **Cuenta de Windows**.
3. Complete la identidad:
   - **Cuenta SQL**: escriba un nombre nuevo e ingrese y confirme la contraseña temporal. Puede utilizar **Sugerir contraseña segura**. La contraseña debe tener entre 16 y 128 caracteres e incluir mayúscula, minúscula, número y símbolo.
   - **Cuenta de Windows**: escriba una cuenta existente como `DOMINIO\usuario` o `EQUIPO\usuario` y pulse **Comprobar cuenta**. Espere la confirmación con ✓ verde. Aquí no se solicita una contraseña de Windows.
4. Revise las opciones de acceso inicial:
   - **Dar acceso a una base de datos y, opcionalmente, asignar roles o permisos generales**.
   - **Dar acceso a tablas, vistas, funciones o procedimientos específicos**.
5. Si seleccionó acceso a bases, pulse **Siguiente** y marque las bases necesarias. Los roles y permisos generales que elija se aplicarán a todas las bases marcadas. También puede dar acceso a una base sin añadir roles ni permisos generales.
6. Si seleccionó objetos específicos, avance al paso de objetos, elija su base y pulse **Agregar objetos**. Seleccione los elementos y marque los permisos necesarios en la tabla.
7. Revise la cuenta, el ticket y los accesos y pulse **Enviar a confirmación**.

**Puede elegir ambas opciones de acceso, una sola o ninguna.** Si no selecciona ninguna, se creará solamente el login. Si solicita objetos específicos, estos deben pertenecer a una sola base; al combinar objetos con mapeo, seleccione esa misma y única base. Si elige solo objetos, la aplicación crea también el usuario necesario en esa base, sin añadir roles ni permisos generales.

**Anterior** conserva lo que ya escribió. **Cancelar** elimina el borrador. Cambiar la base de objetos descarta las selecciones anteriores de objetos.

#### Contraseña temporal y comprobación de Windows

Las cuentas SQL tienen activadas inicialmente la política de contraseñas, la expiración y el cambio de contraseña en el primer inicio de sesión. Revise **Opciones de contraseña** y conserve esos valores salvo que la gestión autorizada requiera otra configuración. Para exigir el cambio inicial deben estar activadas también la política y la expiración.

Antes de enviar, puede usar **Copiar contraseña temporal** y entregarla al destinatario por el canal seguro definido por su organización. El formulario limpia la contraseña al enviar la solicitud. Las solicitudes actuales conservan el secreto cifrado para su ejecución, por lo que no debe volver a escribirlo al ejecutarlas. Si mantuvo la opción de cambio inicial, el destinatario deberá cambiarlo al conectarse por primera vez mediante una herramienta compatible con SQL Server.

La comprobación de Windows confirma que la cuenta existe; la disponibilidad del nombre para crear el login se revisa por separado. Cambiar la cuenta o el servidor obliga a comprobarla nuevamente. Cambiar de Cuenta SQL a Cuenta de Windows borra las contraseñas ingresadas; si vuelve a SQL, escriba una contraseña nueva. La aplicación registra el acceso en SQL Server: la cuenta de Windows debe existir previamente.

### 3.6. Copiar permisos de una cuenta de referencia

1. Seleccione **3. Copiar permisos**.
2. Valide el ticket y elija el tipo de autenticación de la cuenta nueva.
3. En **Usuario cuyos accesos desea copiar**, busque y seleccione la cuenta de referencia. Use **Actualizar lista** si necesita consultar el catálogo nuevamente.
4. Espere a que termine la revisión de sus bases y accesos.
5. Escriba la identidad de la cuenta nueva. Para SQL, ingrese y confirme su contraseña temporal; para Windows, pulse **Comprobar cuenta** y espere la confirmación.
6. Revise la tabla informativa. Compruebe las bases, los roles y permisos que se copiarán, y los elementos que indican **No se copiará**.
7. Pulse **Enviar a confirmación** y revise después el desglose completo de la solicitud.

La cuenta destino debe ser nueva: su nombre no puede existir como login en el servidor ni como usuario en las bases del plan. La cuenta de referencia puede ser SQL o Windows independientemente del tipo elegido para el destino.

La copia incluye membresías de roles de base y permisos directos admitidos y autorizados en cada base. No copia roles de servidor ni delegación de permisos. La tabla es informativa y no permite modificar el plan fila por fila. Si se detecta una denegación `DENY` o una excepción `REVOKE` en el origen, se bloquea la copia completa y debe solicitar una revisión al administrador.

Si cambian los accesos del origen o la política después de revisar la copia, la ejecución puede bloquearse. Vuelva a consultar y genere una solicitud nueva con el detalle actualizado.

### 3.7. Confirmar, rechazar y ejecutar solicitudes

Requiere **AprobadorEjecutor** o **Administrador**. Con solo Operador, la sección aparece como **4. Solicitudes enviadas** y permite consultar el seguimiento.

1. Seleccione el servidor de trabajo correspondiente.
2. Abra **4. Confirmar y ejecutar** y pulse **Actualizar solicitudes**.
3. Localice la solicitud con **Buscar ticket o principal**.
4. Revise el ticket, la identidad destino, el solicitante, el servidor, las bases y la justificación. Expanda el detalle de cambios y compruebe todas las acciones incluidas.
5. Si está correcta y figura como `PENDING`, pulse **Confirmar**. Si no corresponde realizarla, pulse **Rechazar**. Puede añadir un comentario en el campo destinado a confirmar o rechazar.
6. Una vez en estado `APPROVED`, pulse **Ejecutar** para aplicar los cambios.
7. Revise la tabla de resultados: **Servidor**, **Base**, **Correcto** y **Detalle de ejecución**, además del mensaje de estado.

Un Administrador o un usuario que reúna Operador + AprobadorEjecutor puede confirmar y ejecutar sus propias solicitudes. La aplicación no exige que intervengan dos personas diferentes; aplique el procedimiento de revisión de su organización.

| Estado mostrado | Significado y siguiente acción |
| --- | --- |
| `PENDING` | Enviada y pendiente de revisión. Corresponde confirmar o rechazar. |
| `APPROVED` | Confirmada, pendiente de ejecutar. |
| `EXECUTED` | Ejecución registrada como correcta. Consulte el detalle. |
| `REJECTED` | Rechazada. Si hace falta corregirla, prepare una solicitud nueva. |
| `FAILED` | Ejecución con fallos. Revise los resultados con el DBA antes de volver a solicitar cambios. |
| `CANCELLED` | Solicitud registrada como cancelada. Puede aparecer en el historial. |

Las solicitudes finalizadas pasan al historial. Si hay un fallo, compruebe el resultado por destino: en operaciones de creación o copia que abarcan varias bases, el login y las bases completadas pueden permanecer aunque falle otra base. No dé por hecho que se deshizo toda la gestión.

El seguimiento de comandos tiene estados propios. `CONFIRMED` acredita una respuesta satisfactoria o la confirmación de una transacción; `ROLLED_BACK` registra una reversión comprobada; `NO_CHANGE` indica un paso sin cambio efectivo; `PENDING` o `UNRESOLVED` requiere conciliación. No los confunda con los estados de la solicitud de la tabla anterior. Si se pierde la conexión o la app informa un intento reservado, pida al DBA revisar el destino y el historial antes de generar otra solicitud: repetir el envío podría duplicar un cambio ya aplicado.

### 3.8. Habilitar o deshabilitar un login

1. En **1. Modificar accesos**, cargue el login y valide el ticket.
2. Revise su estado en la cabecera. Pulse **Deshabilitar login** si está habilitado o **Habilitar login** si está deshabilitado.
3. Lea la confirmación y acepte el envío de la solicitud.
4. Confirme y ejecute esa solicitud desde la cola correspondiente.
5. Vuelva a cargar el login para consultar su estado actualizado.

Deshabilitar impide nuevos inicios de sesión y conserva la cuenta y sus permisos. No cierra las sesiones que ya estaban abiertas. Mientras el login esté deshabilitado, primero debe completar su habilitación para enviar cambios de permisos de base.

El cambio de estado es una solicitud independiente. Si tenía cambios de permisos en el borrador, el diálogo advierte que se descartarán al enviar la solicitud de estado.

### 3.9. Consultar historial y auditoría

**Historial de solicitudes**

1. Abra el módulo y seleccione el servidor.
2. Pulse **Actualizar**.
3. Busque por ticket, principal u operación.
4. Revise el estado final, solicitante, aprobador, fecha y justificación. Expanda el listado de cambios para consultar el detalle. Puede utilizar **Copiar ticket**.

Las solicitudes pendientes y aprobadas se consultan en **Administrar accesos**, en la cola de solicitudes.

**Auditoría** — Auditor o Administrador

1. Abra **Auditoría**.
2. Escriba un filtro si necesita limitar la consulta y pulse **Buscar / actualizar**.
3. Revise fecha, usuario, formulario, acción, servidor, base, resultado y detalle.
4. Pulse **Validar integridad** para verificar el registro. Si aparece una alerta de enlaces rotos o eventos alterados, comunique el mensaje al DBA o responsable de seguridad para su revisión.

### 3.10. Configurar servidores — Administrador

1. Entre en **Servidores** y pulse **Agregar servidor**. Para modificar uno existente, selecciónelo y pulse **Editar**.
2. Complete **Nombre amigable**, **Host o dirección IP** e **Instancia**, si corresponde.
3. Elija autenticación Windows o SQL. Windows utiliza la identidad del proceso que ejecuta la aplicación; SQL requiere las credenciales de conexión autorizadas para ese destino.
4. Mantenga **Cifrar conexión (Encrypt)** activado. Configure la confianza del certificado según las instrucciones del DBA. El **Timeout** debe estar entre 5 y 300 segundos.
5. Marque **Servidor habilitado** para dejarlo disponible para operar.
6. Pulse **Probar conexión** y revise el mensaje. Pulse **Guardar servidor** para guardar la configuración.
7. Compruebe el registro en el listado. También puede seleccionarlo y usar **Probar conexión** desde allí.

Al editar un servidor con autenticación SQL, puede dejar la contraseña vacía para conservar la almacenada. Si la prueba del formulario requiere una contraseña, ingrésela para esa comprobación.

**Quitar** deshabilita el servidor en el catálogo de la aplicación; no elimina la instancia SQL Server. Puede administrar su disponibilidad mediante **Activo** o al editar el registro.

### 3.11. Administrar usuarios autorizados — Administrador

Este módulo controla el ingreso a SQL Access Admin. Para crear cuentas o conceder accesos en los servidores de trabajo, utilice **Administrar accesos**.

1. Abra **Usuarios autorizados** y pulse **Agregar usuario**.
2. Seleccione una cuenta Windows individual o SQL existente y habilitada en la instancia de `adminDB`. El tipo se completa automáticamente.
3. Marque uno o varios roles de aplicación y revise **Acceso activo a la aplicación**. Agregue notas si corresponde.
4. Pulse **Guardar cambios**, revise la confirmación y complete el guardado.

Para cambiar roles o notas, seleccione un registro de la tabla, edite y guarde. Para retirar el ingreso, seleccione la cuenta y pulse **Quitar acceso**. El registro se conserva; para reactivarlo, marque **Acceso activo a la aplicación** y guarde.

Las cuentas ya registradas, incluso inactivas, se administran desde la tabla. Si una cuenta no está disponible para agregar, pulse **Actualizar** o solicite al DBA que revise su existencia y estado en la instancia del pivote. El selector no crea cuentas ni enumera todas las personas del dominio.

Debe conservarse al menos un Administrador activo. No puede quitarse su propio acceso ni retirarse su propio rol Administrador; otro administrador debe realizar esos cambios. Si se modifica el acceso o los roles de una sesión abierta, esta se bloqueará al realizar una nueva operación y la persona deberá cerrar e ingresar nuevamente.

### 3.12. Configurar la política de acceso — Administrador

1. Abra **Política de acceso** y seleccione el contexto: plantilla general, una instancia o una base de esa instancia.
2. Consulte las pestañas **Permisos** y **Roles**. Use el buscador y los filtros disponibles para localizar una opción; revise su descripción, disponibilidad y origen.
3. Habilite o bloquee las opciones que corresponda. En **Detalles avanzados** puede revisar las acciones **Asignar**, **Denegar** y **Retirar** por separado.
4. Pulse **Guardar cambios**, revise la confirmación y complete el guardado. Ambas pestañas se guardan juntas. **Descartar** restaura los valores guardados.

La plantilla general proporciona reglas heredadas. La instancia puede sustituirlas para su servidor y la base puede sustituirlas para ese destino. **Restaurar heredado** elimina la regla local y vuelve a utilizar la del nivel superior. Revise el contexto y la columna **Origen** antes de guardar.

Para una opción protegida, guarde o descarte primero los cambios pendientes y pulse **Habilitar…**. Escriba un motivo de al menos 20 caracteres, marque el reconocimiento del riesgo e ingrese el nombre exacto solicitado. **Autorizar y habilitar** guarda la autorización inmediatamente y deja registro de quién la realizó. Es una confirmación adicional, no un segundo factor de autenticación.

Para descubrir roles personalizados, seleccione su instancia y base y pulse **Actualizar**. Los roles nuevos aparecen bloqueados hasta autorizarlos en ese destino. Autorizar un nombre no habilita automáticamente los roles con ese mismo nombre en otras bases.

**La política controla lo que puede solicitarse con la herramienta. Bloquear una opción no retira los accesos ya asignados en SQL Server.** La política se vuelve a comprobar al crear, confirmar y ejecutar solicitudes. Para retirar un acceso existente, prepare la solicitud correspondiente.

### 3.13. Terminar la sesión

Pulse **Cerrar sesión**, al pie del menú lateral. Esta acción cierra las ventanas y termina la aplicación. Para volver a ingresar, abra nuevamente `SqlAccessAdmin.exe`.

Si tiene cambios pendientes en **Política de acceso** o **Usuarios autorizados**, la aplicación pedirá confirmar su descarte; cancelar conserva la aplicación abierta. En los formularios de solicitudes, termine el envío antes de abandonar la gestión si necesita conservarla: un borrador sin enviar no equivale a una solicitud guardada.

### 3.14. Consultar reportes

Abra **Reportes**, justo debajo de **Administrar accesos**, y seleccione una opción del árbol:

- **Permisos y Accesos → Permisos por usuario:** seleccione servidor y un login SQL o Windows. Despliegue **Bases de datos (opcional)** y marque una o varias bases; sin marcas se consulta solo la instancia. Revise las pestañas **Roles asignados**, **Permisos directos** y **Bases revisadas**. Cada fila identifica su nivel y base; `sysadmin` aparece como rol de instancia aunque no tenga usuario mapeado. El selector excluye `dbo`, `guest`, `INFORMATION_SCHEMA` y `sys`. Una tabla de permisos directos vacía no significa que el login carezca de acceso por roles.
- **Permisos y Accesos → Catálogo de roles:** seleccione servidor y base. Consulte las descripciones de roles fijos y personalizados, y seleccione un rol para ver sus usuarios vinculados a un login SQL o Windows. Se excluyen `dbo`, `guest`, `INFORMATION_SCHEMA` y `sys`. El conteo de usuarios aparece solo al activar **Incluir miembros en la exportación**, tanto en pantalla como en los archivos. Puede buscar también por nombre de usuario.
- **Seguridad y Auditoría → Inactividad de credenciales:** seleccione un servidor. Incluye logins SQL y Windows, habilitados o deshabilitados, aunque no tengan operaciones en la app. Los filtros permiten ver todas las cuentas, tipo, estado, contraseñas SQL de más de 45 días completos, hasta 45 días o fecha no disponible. La contraseña Windows se administra en Windows/AD y su fecha no está disponible desde SQL Server. Para SQL, se usa la fecha válida más reciente entre la del motor y el cambio confirmado por la app para la misma cuenta; **Fecha obtenida de** identifica la fuente. Un cambio confirmado hoy muestra 0 días. La fecha de modificación del login se presenta por separado y no sustituye una fecha de contraseña desconocida. Este reporte indica antigüedad de contraseña; no demuestra que la cuenta no se utilice.

Pulse **Consultar** para cargar resultados. **Buscar** filtra las filas y cada reporte ofrece un filtro adicional. Las columnas permiten ordenar; las tablas son de solo lectura. **Actualizar catálogos** limpia el contexto y vuelve a cargar los servidores. Puede cancelar una consulta; cambiar el contexto descarta los resultados anteriores.

Para guardar el reporte, pulse **PDF**, **CSV** o **Excel** junto a «Exportar» y seleccione un archivo. Se conservan los filtros, el orden visible y el contexto de la consulta. Excel separa las secciones en hojas y PDF las presenta con encabezados y páginas; CSV utiliza una columna de sección. El catálogo se exporta sin detalle de miembros por defecto. Para incluirlo, active **Incluir miembros en la exportación (opcional)** y marque uno o varios roles en **Exportar miembros**. Solo se incluirán sus miembros; seleccionar una fila para consultarla no equivale a marcarla para exportación. Los filtros quitan las marcas de roles ocultos y una nueva consulta limpia la selección. No necesita Microsoft Excel instalado para generar el archivo `.xlsx`. **Cancelar** detiene una exportación en curso; cerrar el diálogo de guardado conserva los resultados.

Estos tres reportes consultan los destinos y requieren Administrador, Operador o AprobadorEjecutor. Si faltan permisos de visibilidad, solicite al DBA revisar la cuenta de conexión. El complemento de fechas confirmadas del reporte de credenciales requiere que el DBA haya aplicado el script 37 en el pivote. Consulte [el alcance detallado](../../docs/Reportes.md).

#### Reportes centrales de cambios

Requieren **Administrador o Auditor** y consultan el historial central, sin obtener credenciales de los destinos:

1. Abra **Reportes → Seguridad y Auditoría → Cambios de accesos** o **Cambios de contraseña**.
2. Seleccione un servidor o **Todos los servidores** y un período válido de hasta un año. Las fechas corresponden al calendario de Guatemala e incluyen el día final seleccionado.
3. Pulse **Consultar** y utilice la búsqueda para localizar cuenta, ticket u otros datos. Revise fuente, resultado y detalle.
4. En **Cambios de contraseña**, use **Ranking** para ver cantidades confirmadas y **Historial** para revisar las operaciones, resultados inciertos y últimas fechas externas observadas.
5. Pulse **PDF**, **CSV** o **Excel** para guardar las filas filtradas en el orden visible. Cambiar servidor, período o modo limpia el resultado anterior; puede cancelar una consulta o exportación.

**Cambios de accesos** muestra las operaciones de la aplicación y las últimas modificaciones externas detectadas. Un registro **Externo** solo indica que la última fecha observada no encuentra una operación confirmada coincidente: no informa quién intervino ni qué permisos cambió. La primera consulta establece una referencia inicial; no reconstruye cambios pasados. Varias intervenciones entre consultas no forman un historial completo.

El ranking cuenta únicamente cambios de contraseña SQL **confirmados desde la app**. Excluye contraseñas iniciales, cambios externos, operaciones pendientes o inciertas y contraseñas Windows. El historial conserva los resultados que requieren revisión. Para referencias externas, el período filtra cuándo se detectó la diferencia, sin atribuir una hora de ejecución.

Una consulta devuelve como máximo 1000 filas de ranking o 5000 de historial/cambios de accesos. Si alcanza ese límite, reduzca el período. En PDF, el detalle de estos reportes se presenta por evento para conservar los campos largos.

### 3.15. Cambiar la contraseña de un login SQL

Solicitar requiere **Operador o Administrador**; confirmar y ejecutar requiere **AprobadorEjecutor o Administrador**.

1. En **Administrar accesos → 1. Modificar accesos**, cargue un login SQL administrable de la instancia seleccionada.
2. Valide el ticket y revise el motivo. Pulse **Cambiar contraseña**.
3. Ingrese y confirme una contraseña nueva de 16 a 128 caracteres, con mayúscula, minúscula, número y símbolo. Puede utilizar **Sugerir contraseña segura**.
4. Revise política, expiración y cambio obligatorio en el próximo inicio de sesión. Inicialmente están activados; exigir el cambio requiere mantener también política y expiración.
5. Entregue la contraseña por el canal seguro de su organización y pulse **Enviar a confirmación**. El formulario limpia el secreto al terminar o cancelar.
6. En **4. Confirmar y ejecutar**, revise la solicitud, confírmela y ejecútela. Después compruebe el resultado y, cuando corresponda, el cambio obligatorio al próximo inicio de sesión.

Esta solicitud incluye únicamente la contraseña y sus opciones para ese login de instancia. Los cambios de permisos del borrador principal no se incluyen y se descartan al enviar. La contraseña se conserva cifrada para ejecutar después; no aparece en el detalle ni necesita volver a escribirse en la cola. Cancelar el diálogo no crea una solicitud.

El cambio no aplica a cuentas Windows/AD ni a cuentas internas o de sistema. Si la operación no está habilitada, el DBA debe revisar la política y la instalación del script 32. Una solicitud duplicada activa bloquea un nuevo envío para el mismo cambio.

### 3.16. Asignar y gestionar vigencias temporales

#### Asignar una vigencia nueva

Al preparar una solicitud compatible en **Administrar accesos**, marque **Vigencia temporal** y elija fecha y hora futuras de Guatemala antes de enviarla. Revise ese vencimiento junto con el ticket y los cambios antes de confirmar y ejecutar.

Una cuenta nueva se sigue a nivel de login; un usuario de base nuevo, en su base. Sobre una identidad existente, un permiso o membresía nuevo se sigue por recurso. La aplicación no convierte un acceso permanente previo en temporal. No todos los tipos de cambio admiten vigencia; el cambio de contraseña por sí solo no la admite.

**Al vencer, el acceso permanece y se genera una alerta persistente.** No se revocan permisos, eliminan usuarios ni deshabilitan logins automáticamente.

#### Consultar, extender o cerrar

Todos los usuarios autorizados pueden consultar **Usuarios temporales**. Solo Administrador puede realizar las acciones siguientes:

1. Abra **Usuarios temporales → Accesos temporales** y pulse **Actualizar**. Busque por cuenta, servidor, recurso o estado y seleccione la fila.
2. Ingrese el ticket completo y pulse **Validar**. Revise **Motivo del ticket**, que se completa desde su descripción o asunto. Cambiar el ticket invalida la comprobación.
3. Para extender, indique una fecha/hora futura mayor que la vigente y pulse **Solicitar extensión**. Para cerrar, pulse **Solicitar cierre** y revise la acción propuesta para el recurso.
4. Abra **Revisión de solicitudes**, seleccione la acción y pulse **Confirmar** o **Rechazar**. Una aprobación todavía no cambia la vigencia ni el acceso.
5. Pulse **Ejecutar** en la acción aprobada y revise el resultado. La misma persona con Administrador puede solicitar, confirmar y ejecutar.

| Recurso temporal | Efecto del cierre ejecutado |
| --- | --- |
| Login nuevo | Deshabilita el login; conserva sus permisos y las sesiones ya abiertas. |
| Usuario nuevo de base | Elimina el usuario de esa base; puede fallar si posee objetos. |
| Permiso nuevo | Retira el permiso directo con `REVOKE`; pueden permanecer accesos heredados. |
| Membresía nueva | Retira la pertenencia al rol correspondiente. |

La extensión cambia la vigencia central y no concede permisos SQL nuevos. El cierre comprueba la identidad de la cuenta antes de actuar. La alerta se resuelve solo al completar satisfactoriamente la extensión o el cierre. Rechazar, confirmar sin ejecutar, reiniciar o cambiar de día no la resuelve. Un fallo o una acción que quedó en ejecución tras una caída requiere revisión con el DBA antes de repetirla.

La pantalla consulta hasta 5000 vigencias y 1000 acciones. Consulte [cobertura y operación de temporales](../../docs/MonitoreoSeguridad.md) para los límites del seguimiento.

### 3.17. Consultar y atender alertas

1. En **Resumen**, revise vencimientos, alertas de contraseña y cambios de contraseña por conciliar, junto con el estado de actualización y la última consulta de metadatos.
2. Pulse **Ver alertas**. La ventana muestra hasta 50 alertas activas recientes; filtre por tipo o busque por cuenta, servidor o detalle.
3. Seleccione una alerta de vencimiento y abra **Usuarios temporales** para gestionar su extensión o cierre. No puede descartarla desde esta ventana.
4. Para una alerta de contraseña, Administrador o Auditor puede escribir un motivo de revisión de al menos 10 caracteres y confirmar **Registrar revisión**. Los demás roles pueden consultarla.

La alerta de frecuencia aparece en el **tercer cambio de contraseña SQL confirmado por la app para la misma cuenta e instancia en un día de Guatemala**. El cuarto cambio actualiza la alerta activa. Registrar su revisión conserva contador e historial; un cambio nuevo puede generar otra alerta. Un cambio externo, una contraseña inicial o un resultado incierto no aumenta el contador.

La actualización periódica se realiza cada 60 segundos mientras la app está abierta. La consulta de metadatos de destinos requiere una sesión Administrador/AprobadorEjecutor o el worker configurado por infraestructura; las demás sesiones consultan lo último conservado en el pivote. Si el estado indica error o falta una referencia inicial, no interprete la ausencia de alertas como una comprobación reciente. Para continuar actualizando con WPF cerrado, solicite a infraestructura preparar el worker opcional.

## 4. Preguntas frecuentes y resolución de problemas

### La aplicación no abre o pide instalar .NET

Compruebe que extrajo y conservó la carpeta completa de la entrega. Si Windows solicita un runtime, pida a soporte instalar **.NET Desktop Runtime 8** de la arquitectura correspondiente o entregar la publicación que lo incluya. Copiar únicamente el ejecutable puede dejar dependencias faltantes.

### No puedo ingresar o aparece «adminDB no está preparada o no es accesible»

Revise servidor pivote, instancia, base, autenticación y conexión de red o VPN. Si persiste, envíe el mensaje al DBA para comprobar la instalación y los permisos de la base administrativa. La aplicación no prepara `adminDB` desde la pantalla de ingreso.

### La conexión informa un error de certificado

Confirme el nombre del servidor y la configuración indicada por soporte. Solicite al DBA revisar el certificado y su confianza en el equipo cliente. Mantenga el cifrado y ajuste **Confiar en certificado** únicamente conforme a la configuración aprobada para ese entorno.

### Mi cuenta conecta a SQL Server, pero la aplicación rechaza el ingreso

Un Administrador debe comprobar que su identidad esté registrada, activa y con roles asignados en **Usuarios autorizados**. Esto también se exige a cuentas con privilegios `sysadmin`. En Windows se utiliza la identidad reconocida por la conexión; el administrador debe verificar el nombre canónico cuando existan alias.

### No puedo confirmar o ejecutar mis solicitudes

Compruebe los roles que aparecen en el menú lateral. **Operador** permite crear y dar seguimiento. Para confirmar, rechazar o ejecutar necesita **AprobadorEjecutor** o **Administrador**. Si su función requiere esos permisos, solicite el ajuste al administrador y vuelva a ingresar después del cambio.

### El servidor o la base que necesito no aparece

Verifique el servidor seleccionado y actualice el listado. El administrador debe revisar que el servidor esté habilitado y que su conexión funcione. Si el servidor aparece pero faltan bases u objetos, el DBA debe revisar su disponibilidad y los permisos de consulta de la conexión utilizada.

### «Validar ticket» no acepta el identificador

Ingrese el identificador completo y compruebe que el ticket exista y siga activo. Si la consulta falla o el motivo obtenido no corresponde, solicite revisar el ticket o su integración con `adminDB`. Cambiar el número obliga a validarlo nuevamente. Si se indica que la justificación es demasiado corta, corrija la descripción del ticket con su responsable; el motivo del formulario se completa automáticamente.

### «Siguiente» o «Enviar a confirmación» está deshabilitado

Lea el mensaje del formulario y revise, según la operación:

- Ticket activo validado y motivo suficiente.
- Nombre destino disponible.
- Contraseña SQL válida y confirmada, o cuenta Windows comprobada.
- Bases seleccionadas cuando solicita mapeo.
- Una sola base si solicita objetos específicos al crear la cuenta.
- Al menos un objeto con un permiso marcado si activó esa opción.
- Algún cambio real de rol o permiso si está modificando accesos.
- Finalización de las consultas en curso y disponibilidad de la operación en la política.

### La cuenta de Windows muestra una ✕ o no supera «Comprobar cuenta»

Use `DOMINIO\usuario` o `EQUIPO\usuario` y verifique que la cuenta ya exista. Si cambió el nombre o el servidor, compruébela nuevamente. Si el mensaje indica falta de permisos o un problema de consulta Windows, el DBA debe revisar la conexión del servidor con el dominio y el permiso de la cuenta técnica para comprobar identidades. Un nombre disponible para crear el login no sustituye esta comprobación.

### La contraseña no se acepta o las dos entradas no coinciden

Use entre 16 y 128 caracteres, con mayúscula, minúscula, número y símbolo, y escriba exactamente el mismo valor en ambos campos. Puede utilizar **Sugerir contraseña segura**. SQL Server puede aplicar requisitos adicionales de su entorno durante la ejecución; comunique el detalle al DBA si falla en ese momento.

### El rol o permiso aparece bloqueado

La política puede impedir asignarlo o retirarlo en ese destino. Solicite al Administrador revisar **Política de acceso**, incluido el servidor, base, ámbito y acción. Algunas opciones requieren **Habilitar…**. Los elementos internos cuyos nombres contienen `##` y el rol implícito `public` no se pueden administrar por esta herramienta.

### Ya existe una solicitud activa para el mismo cambio

Abra **4. Confirmar y ejecutar** o **4. Solicitudes enviadas**, seleccione el mismo servidor y busque por ticket o principal. Revise la solicitud pendiente o aprobada antes de volver a enviar. Si necesita reemplazar una pendiente, solicite su revisión y rechazo antes de preparar la corrección.

### La copia de permisos está bloqueada o cambió el origen

Compruebe que terminó la revisión de todas las bases, que el destino sea nuevo y que haya accesos copiables. Si aparecen restricciones `DENY` o `REVOKE`, solicite revisión al administrador. Si cambió el origen o la política, genere una solicitud nueva con el plan actualizado. Una copia antigua sin detalle guardado por base debe rechazarse y recrearse con la versión actual.

### Confirmé una solicitud, pero el usuario aún no tiene acceso

Compruebe si sigue en `APPROVED`: todavía falta pulsar **Ejecutar**. Si figura como `EXECUTED`, revise los destinos y cambios del historial. El acceso efectivo puede depender de otros roles o denegaciones; pida al DBA revisar el caso si el resultado no corresponde a lo esperado.

### La ejecución falló o solo algunos destinos aparecen correctos

Revise **Detalle de ejecución** y consulte el historial y la auditoría disponibles. Informe al DBA el número de solicitud, ticket, servidor, bases y mensaje. En creación o copia multibase pueden quedar cambios aplicados en destinos completados. Antes de generar otra solicitud, confirme qué se realizó y qué falta.

### Aparece un bloqueo de sesión o un conflicto al guardar

Si cambió su acceso o sus roles, cierre la aplicación e ingrese nuevamente. Si otro administrador modificó el mismo usuario autorizado, actualice el registro, revise sus valores actuales y vuelva a aplicar los cambios necesarios. En **Política de acceso**, si se informa un guardado parcial, revise el mensaje y los cambios que siguen pendientes antes de reintentar.

### ¿Quitar acceso elimina la cuenta o sus permisos SQL?

**Quitar acceso**, en Usuarios autorizados, desactiva el ingreso a la aplicación. **Deshabilitar login**, en Administrar accesos, solicita bloquear nuevos inicios de sesión en la instancia elegida y conserva sus permisos. Para retirar permisos SQL existentes, prepare y ejecute cambios de accesos específicos.

### ¿Qué información debo enviar a soporte?

Indique el módulo y la acción que estaba realizando, el texto completo del error, el servidor y base implicados, su tipo de autenticación y, si existen, el ticket y número de solicitud. No incluya contraseñas. Con esos datos, soporte podrá localizar la gestión y revisar su resultado.

### Un acceso temporal venció y todavía funciona

Es el comportamiento previsto: vencer genera una alerta y mantiene el acceso. Un Administrador debe solicitar y completar una extensión o un cierre en **Usuarios temporales**. Confirmar sin ejecutar no resuelve el vencimiento.

### Una contraseña cambió y el contador no aumentó

Solo cuentan cambios SQL confirmados desde la app en el día de Guatemala. Se excluyen contraseñas iniciales, cambios externos o Windows y resultados pendientes o inciertos. Revise **Cambios de contraseña → Historial** con Administrador/Auditor; el contador de alertas activas en Resumen tampoco equivale al total de cambios.

### La fecha de contraseña no aparece o el reporte muestra 0 días

Una fecha desconocida no significa que la cuenta nunca cambió su contraseña. Windows/AD no expone ese dato por esta consulta. Para SQL se descartan fechas inválidas y se complementan con cambios confirmados de la app. Un cambio confirmado hoy muestra 0 días completos. Si falta el complemento, soporte debe revisar el script 37 del pivote.

### Un reporte muestra Externo o Por conciliar

Externo corresponde a la última fecha detectada sin una operación confirmada coincidente; no permite identificar al actor ni reconstruir todos los cambios. Por conciliar indica falta de confirmación suficiente. Informe a soporte el servidor, la cuenta, el ticket/solicitud y el resultado; pida comprobar el destino antes de repetir el cambio.

### Las alertas no se actualizan o faltan módulos después de actualizar

Revise los roles de sesión y el estado de actualización en Resumen. La consulta de destinos depende de conectividad, visibilidad y de una sesión o worker autorizado en funcionamiento. Para la entrega actual, el DBA debe completar el contrato **32 → 36 → 33 v4 → 37 → 99** en el pivote y reiniciar cliente/worker. Cambiar solo el ejecutable no actualiza la base.

### Documentación relacionada

- [Preparación de adminDB y despliegue](../README.md).
- [Documentación Técnica](Documentación%20Técnica.md).
- [Documentación de Proceso](Documentación%20de%20Proceso.md).
- [Detalle de usuarios autorizados](../../docs/UsuariosAutorizados.md).
- [Detalle de política por instancia y base](../../docs/PoliticaAccesoPorDestino.md).
