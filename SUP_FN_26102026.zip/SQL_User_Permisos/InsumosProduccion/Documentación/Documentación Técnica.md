# Documentación Técnica

**SQL Access Admin — El «Cómo está hecho»**

Fecha de revisión: 26 de octubre de 2026. Documento elaborado a partir del código fuente, los proyectos .NET y los scripts SQL presentes en esta entrega.

La entrega incluye cambio de contraseña SQL, cinco reportes exportables, vigencias temporales y alertas persistentes. El cierre de instalación en el pivote es **32 → 36 → 33 v4 → 37 → 99** después de completar los prerrequisitos anteriores. Las fechas estructuradas usan hora de Guatemala. El seguimiento registra comandos y compara metadatos; no instala captura en destinos.

SQL Access Admin es una aplicación de escritorio para administrar accesos en instancias de SQL Server. La base central `adminDB` conserva usuarios autorizados, servidores, políticas, solicitudes y auditoría. El cliente consulta esa base y se conecta directamente a las instancias administradas para consultar y ejecutar cambios aprobados.

El pivote `adminDB` conserva intentos, comandos, resultados y referencias de metadatos en el esquema `access`. El cliente y el worker opcional consultan los catálogos de los destinos y conservan las últimas fechas por instancia, ámbito y SID. La última fecha sin registro confirmado coincidente se clasifica como Externo, sin atribución de actor ni reconstrucción de un historial completo.

## 1. Stack tecnológico

### 1.1. Tecnologías y versiones declaradas

| Componente | Versión o configuración | Uso y evidencia |
| --- | --- | --- |
| C# | Versión de lenguaje no fijada mediante `LangVersion`; C# 12 es la predeterminada del destino .NET 8 | Lógica de presentación, modelos, acceso a datos y seguridad. El código utiliza, entre otras características, constructores primarios y expresiones de colección. |
| .NET | `net8.0-windows` | Destino del cliente, worker y proyectos de comprobaciones. No se fija un parche de runtime en los proyectos. |
| Windows Presentation Foundation (WPF) | Incluido en .NET 8; `UseWPF=true` | Ventanas, controles, enlaces de datos, estilos y comandos. |
| XAML | Formato de interfaz de WPF, sin versión independiente declarada | Vistas y diccionarios de recursos en `Views/` y `Themes/`. |
| Microsoft.Data.SqlClient | **6.1.4** | Conexiones a SQL Server, parámetros, procedimientos y transacciones. |
| ClosedXML | **0.105.0** | Generación de archivos Excel `.xlsx` sin automatización de Office. |
| PDFsharp-MigraDoc-WPF | **6.2.4** | Generación de reportes PDF paginados. |
| ScriptDom | Dependencia de las comprobaciones de sintaxis | Análisis T-SQL de pruebas; no forma parte de las referencias del cliente ni del worker. |
| ADO.NET / System.Data | Bibliotecas de .NET | `DataTable`, lectores de resultados y parámetros tabulares para solicitudes compuestas. |
| System.Text.Json | Biblioteca de .NET 8 | Serialización de roles de aplicación, descubrimiento de políticas y planes de copia. |
| System.Security.Cryptography | Biblioteca de .NET 8 | AES-256-GCM, generación aleatoria, SHA-256 y limpieza de determinados buffers de secretos. |
| SQL Server / T-SQL | Sin versión de servidor fijada en el repositorio | Persistencia, procedimientos almacenados, funciones, tipos de tabla, triggers y catálogos de seguridad. |
| PowerShell y `sqlcmd` | Sin versión fijada | Instalación manual de insumos y comprobaciones SQL. |
| Mermaid | Sintaxis documental; sin dependencia de ejecución | Diagramas de este archivo. Su visualización requiere un visor Markdown compatible. |

Las dependencias del cliente se declaran en [SqlAccessAdmin.csproj](../../src/SqlAccessAdmin/SqlAccessAdmin.csproj). El [worker](../../tools/SecurityMonitoringWorker/SecurityMonitoringWorker.csproj) y los proyectos de [contraseñas](../../tests/LoginPasswordChecks/LoginPasswordChecks.csproj), [reportes](../../tests/ReportsChecks/ReportsChecks.csproj) y [seguimiento](../../tests/SecurityMonitoringChecks/SecurityMonitoringChecks.csproj) referencian al proyecto principal. Los proyectos de pruebas y el worker se compilan por su ruta; la solución contiene el cliente.

No existe un `global.json` que fije el SDK ni un archivo `packages.lock.json` que congele todas las dependencias transitivas. Las versiones anteriores corresponden a referencias declaradas; las dependencias transitivas se resuelven durante `dotnet restore`.

### 1.2. Compatibilidad y herramientas de desarrollo

- El cliente y las comprobaciones WPF se ejecutan en **Windows**, con herramientas capaces de compilar `net8.0-windows`.
- Para desarrollar se necesita el **SDK de .NET 8**, o un SDK posterior compatible que disponga de los recursos necesarios para ese destino. Visual Studio 2022 con soporte para .NET 8 y la carga de trabajo de desarrollo de escritorio con .NET es una opción de IDE.
- La solución utiliza el formato de Visual Studio 17 y compila el proyecto principal en `Debug` o `Release`, con plataforma `Any CPU`.
- Como requisito deducido de los scripts, el pivote necesita un motor que soporte `STRING_AGG`, `CREATE OR ALTER` y JSON mediante `OPENJSON`: una base técnica de **SQL Server 2017 o posterior**, con nivel de compatibilidad de `adminDB` **130 o superior**. Esto no constituye una certificación de todas las versiones; se debe validar la instalación con los insumos de esta entrega.
- Los destinos deben admitir las operaciones solicitadas y exponer sus metadatos a la cuenta de conexión. La disponibilidad de permisos se descubre por instancia con `sys.fn_builtin_permissions`.
- Las consultas del seguimiento de metadatos admiten SQL Server 2016 o posterior; esto no rebaja los requisitos del pivote ni garantiza que todos los permisos operativos existan en cada destino.

## 2. Estructura de archivos y carpetas

El siguiente árbol resume los elementos relevantes para desarrollo y operación. Omite los archivos generados de `bin/`, `obj/` y la configuración local del IDE.

```text
SQL_User_Permisos/
├── SQLUserPermisos.sln                 # Solución del cliente WPF
├── README.md                          # Descripción funcional y ejecución rápida
├── descripcion.txt                    # Material descriptivo del proyecto
├── src/
│   └── SqlAccessAdmin/
│       ├── SqlAccessAdmin.csproj       # WPF, SqlClient, ClosedXML y PDFsharp/MigraDoc
│       ├── App.xaml                   # Recursos globales y ventana de inicio
│       ├── App.xaml.cs                # Liberación de pools al terminar
│       ├── BooleanConverter.cs        # Conversión para enlaces de interfaz
│       ├── Views/                     # Ventanas y controles XAML + code-behind
│       ├── ViewModels/                # Estado de pantalla, navegación y comandos
│       ├── Models/                    # Contratos, roles, políticas y planes
│       ├── Data/                      # Acceso al pivote y a los destinos
│       ├── Security/                  # Protección de secretos con AES-GCM
│       ├── Infrastructure/            # Comandos WPF, guardado y AppTime Guatemala
│       └── Themes/                    # Modern.xaml e Icons.xaml
├── InsumosProduccion/
│   ├── README.md                      # Guía de instalación manual para el DBA
│   ├── 00_CrearBaseDatos.sql           # Creación opcional de adminDB
│   ├── 01_CrearEsquema.sql             # Estructura inicial bajo access
│   ├── 02_CrearProcedimientosConsulta.sql
│   ├── 03_CrearProcedimientosOperacion.sql
│   ├── 04_CrearRolesYPermisos.sql
│   ├── 05_DatosIniciales.sql           # Plantilla del administrador inicial
│   ├── 07_CorreccionLoginSysadmin.sql  # Actualización histórica
│   ├── 08_ConfigurarConexionDirectaYCifrado.sql
│   ├── 09_RenombrarRolesSqlAccessAdmin.sql
│   ├── 10_...sql hasta 19_...sql        # Políticas y evolución de solicitudes
│   ├── 20_MigrarObjetosAlEsquemaAccess.sql
│   ├── 21_...sql hasta 28_...sql        # Cambios compuestos, copia y política por destino
│   ├── 29_UsuariosAutorizadosAccesoEstricto.sql
│   ├── 30_RolesMultiplesYSeparacionSolicitudes.sql
│   ├── 31_SeleccionUsuariosAutorizados.sql
│   ├── 32_CambiarContrasenaLogin.sql
│   ├── 33_MonitoreoSeguridadYTemporales.sql # Contrato v4; ejecutar después de 36
│   ├── 36_HoraLocalGuatemala.sql
│   ├── 37_FechasContrasenaConfirmadas.sql
│   ├── 99_ValidarInstalacion.sql        # Comprobación final de solo lectura
│   └── Documentación/
│       └── Documentación Técnica.md   # Este documento
├── database/
│   └── README-SP-CONTRACT.md           # Referencia a los insumos vigentes
├── docs/
│   ├── UsuariosAutorizados.md          # Identidad, roles e integración
│   ├── PoliticaAccesoPorDestino.md     # Herencia, descubrimiento y activaciones
│   ├── ViabilidadPermisosMultibase.md  # Análisis de una ampliación no implementada
│   ├── ComprobarIdentidadWindows.sql   # Diagnóstico de identidad de solo lectura
│   ├── Reportes.md                    # Consultas directas y exportación
│   ├── MonitoreoSeguridad.md           # Seguimiento vigente y temporales
│   ├── HoraLocalGuatemala.md           # Conversión y convención temporal
│   ├── archive/monitoring-v2/          # Material histórico fuera del despliegue
│   └── Previews/                       # Capturas de referencia de la interfaz
├── tests/
│   ├── LoginPasswordChecks/           # Contraseña SQL y contrato de migración
│   ├── ReportsChecks/                 # Reportes, exportaciones y SQL opcional
│   └── SecurityMonitoringChecks/      # Seguimiento, temporales y laboratorio SQL
├── tools/
│   └── SecurityMonitoringWorker/      # Ciclos de seguimiento sin abrir WPF
└── artifacts/                         # Publicaciones y vistas generadas localmente
```

### 2.1. Responsabilidades del código

| Ubicación o componente | Responsabilidad |
| --- | --- |
| `Views/LoginWindow`, `ViewModels/LoginViewModel` | Capturar la conexión al pivote, autenticar y abrir la ventana principal. |
| `Views/MainWindow`, `ViewModels/MainViewModel` | Navegación, visibilidad por rol, bloqueo de sesión y coordinación de servicios. `MainViewModel.cs` también contiene varias clases de pantalla, incluido `AccessViewModel`. |
| `Views/AccessView`, `AccessRequestEditor`, `ConfirmationWindow` | Edición, revisión y presentación de solicitudes y resultados. |
| `CreateUserWizardViewModel`, `PermissionCopyViewModel`, `LoginStateManagementViewModel` | Asistente de alta, copia de accesos y habilitación o deshabilitación de logins. Parte de la lógica de `AccessViewModel` se distribuye mediante clases parciales. |
| `UsersViewModel`, `PolicyViewModel`, `ServerEditorViewModel` | Mantenimiento de usuarios autorizados, políticas y servidores. |
| `Data/AdminDbGateway.cs` | Fachada ADO.NET del pivote; autenticación, catálogos, solicitudes y auditoría. Implementa `IPolicyStore` e `IAuthorizedUserStore`. |
| `Data/ScopedPolicyGateway.cs` | Parte de `AdminDbGateway` dedicada a reglas por instancia/base y descubrimiento persistido. |
| `Data/DirectSqlServerService.cs` | Conexión directa, inventario de accesos y ejecución de solicitudes aprobadas. |
| `Data/PermissionCopyService.cs`, `PolicyDiscoveryService.cs`, `WindowsAccountValidationService.cs` | Partes de `DirectSqlServerService` para copia, descubrimiento y comprobación de cuentas Windows. |
| `Models/DomainModels.cs`, `AppRoleCatalog.cs` | Contratos de sesión, servidores, bases y solicitudes; roles acumulables y su serialización. |
| `Models/PermissionCopyModels.cs`, `PolicyContext.cs`, `PolicyEditorItems.cs` | Planes de copia, huellas de integridad, contexto de destino y validaciones de política. |
| `Security/AesGcmCredentialProtector.cs` | Cifrado y descifrado de sobres de credenciales y contraseñas temporales. |
| `Infrastructure/BindableBase.cs` | Notificación de cambios y clases `RelayCommand` / `AsyncCommand`. |
| `LoginPasswordManagementViewModel`, `LoginPasswordChangeWindow`, `Data/LoginPasswordChangeService.cs` | Solicitud y ejecución de cambio de contraseña SQL con opciones compatibles y secreto parametrizado. |
| `ReportsViewModel`, `ReportsService`, `ReportsSql`, `ReportExportService` | Tres reportes directos, consultas de catálogo y exportación PDF/CSV/Excel. |
| `SecurityReportsViewModel`, `SecurityMonitoringGateway` | Reportes centrales por período, ranking/historial y acceso a procedimientos de seguimiento. |
| `TemporaryRequestViewModel`, `TemporaryAccessViewModel`, `TemporaryAccessService`, `TemporaryGrantValidation` | Captura de vigencia, solicitudes de extensión/cierre y validación/ejecución por recurso. |
| `ExecutionEvidenceScope`, `TrackedSqlConnection` | Registro tipado antes del comando y confirmación después de respuesta o COMMIT, con resultados inciertos explícitos. |
| `PrincipalMetadataCollector`, `PrincipalMetadata` | Consulta por lotes, identificación por SID y normalización de fechas nativas del motor. |
| `SecurityMonitoringService`, `DashboardSecurityViewModel`, `SecurityAlertsViewModel` | Refresco periódico, resumen, ventana de alertas y revisión motivada. |
| `Infrastructure/AppTime.cs` | Conversión a `Central America Standard Time` y formato de fechas de Guatemala. |
| `tools/SecurityMonitoringWorker/Program.cs` | Ejecución por consola de los ciclos de metadatos y vencimientos con identidad Windows autorizada. |

## 3. Arquitectura y flujo de datos

### 3.1. Organización general

La presentación sigue una organización **MVVM**: las vistas enlazan propiedades y comandos de los ViewModels; estos coordinan modelos y servicios de datos. Se utiliza code-behind para comportamiento propio de las ventanas y controles. Las dependencias se construyen explícitamente, por ejemplo en `LoginViewModel` y `MainViewModel`.

La lógica de negocio se reparte entre el cliente y los procedimientos del pivote. El cliente prepara planes y ejecuta cambios en los destinos; `adminDB` valida identidades, permisos funcionales, políticas, tickets, destinos y transiciones de solicitudes.

```mermaid
flowchart LR
    U[Usuario en Windows] --> V[Vistas WPF / XAML]
    V <--> VM[ViewModels y modelos]
    VM --> G[AdminDbGateway]
    VM --> D[DirectSqlServerService]
    G -->|Procedimientos y parámetros / TLS según configuración| P[(adminDB: esquema access)]
    D -->|Configuración, credenciales y política| G
    D -->|Conexiones directas / TLS según configuración| S[(Instancia SQL Server)]
    S --> B[(Bases administradas)]
    P --> T[dbo.sp_VerificarTicketExiste]
    W[Worker opcional en Windows] -->|Mismos contratos centrales| P
    W -->|Consultas de metadatos| S
```

El cliente necesita conectividad tanto al pivote como a cada destino. Las operaciones actuales utilizan conexiones directas; no dependen de linked servers. No existe un servicio web intermedio propio en esta solución.

### 3.2. Inicio de sesión y autorización

1. `App.xaml` abre `Views/LoginWindow.xaml`.
2. `LoginViewModel` construye `PivotOptions` con los valores del formulario y crea `AdminDbGateway`.
3. `LoginAsync` llama a `access.usp_App_LoginContext` con la identidad autenticada por SQL Server.
4. El contrato exige una fila con `AuthorizationVersion=2`, `IsAuthorized=true`, principal y roles JSON válidos.
5. SQL resuelve la identidad original mediante `access.ufn_App_Principal()`. Para Windows utiliza el SID original y su nombre canónico, como `DOMINIO\usuario`, incluso cuando el nombre original de conexión es un alias MicrosoftAccount.
6. Solo ingresa una identidad registrada, activa y con membresías válidas. Tener `sysadmin` no sustituye el registro de aplicación.
7. Antes de cada operación a través del gateway se consulta nuevamente el contexto. Si cambia la identidad o el conjunto de roles, se dispara `AuthorizationLost` y `MainViewModel` bloquea la sesión. La detección ocurre al realizar una nueva operación; no utiliza notificaciones en tiempo real.

| Rol visible | Código persistido | Funciones |
| --- | --- | --- |
| Administrador | `Administrator` | Todas las funciones, incluida configuración de usuarios, servidores y políticas. |
| Operador | `Operator` | Crear solicitudes y consultar su seguimiento. |
| AprobadorEjecutor | `ApproverExecutor` | Confirmar, rechazar y ejecutar solicitudes. |
| Auditor | `Auditor` | Consultar resumen, auditoría, vigencias y reportes centrales; registrar revisión de alertas de contraseña. |

Las funciones se suman al asignar varios roles. Un Administrador o un usuario con Operador + AprobadorEjecutor puede procesar sus propias solicitudes; el flujo no impone dos personas distintas. Los roles de aplicación determinan funciones dentro del cliente y de sus SP; los permisos SQL de conexión y de ejecución deben prepararse adicionalmente.

Los tres reportes directos requieren `CanAccessRequests` (Administrador/Operador/AprobadorEjecutor). Los dos reportes centrales y la revisión de alertas de contraseña requieren `CanAudit` (Administrador/Auditor). Todos los usuarios autorizados consultan vigencias y alertas; solo Administrador solicita y procesa extensiones/cierres. El ciclo que obtiene metadatos de destinos requiere `CanReviewRequests` (Administrador/AprobadorEjecutor); los demás roles leen el estado central conservado.

### 3.3. Acceso a datos y resolución de destinos

`AdminDbGateway` crea conexiones `SqlConnection` por operación y utiliza `CommandType.StoredProcedure` con parámetros tipados. Los destinos y pasos se envían como parámetros tabulares `access.AccessRequestTargetType` y `access.AccessRequestStepPolicyType`; la copia utiliza además un plan JSON.

`DirectSqlServerService.ResolveAsync` obtiene del pivote el servidor activo y su configuración. Para autenticación SQL, recupera el sobre y el material criptográfico autorizado, descifra la contraseña y construye una cadena con `SqlConnectionStringBuilder`. Para Windows, la conexión integrada utiliza la identidad Windows del proceso cliente.

En los destinos se usan consultas de catálogos, procedimientos de sistema y sentencias T-SQL construidas para las operaciones permitidas. Los valores de consulta se parametrizan; los identificadores de comandos de seguridad se validan y delimitan con `SqlCommandBuilder.QuoteIdentifier`. No todas las operaciones directas son llamadas a procedimientos almacenados.

Cada operación libera su conexión mediante `using`/`await using`. Al cerrar la ventana principal termina la aplicación y `App.OnExit` ejecuta `SqlConnection.ClearAllPools()` para liberar los pools del pivote y los destinos.

### 3.4. Modelo de persistencia central

Los objetos de aplicación residen en el esquema `[access]` de `adminDB`. El procedimiento externo de tickets permanece en `dbo`.

| Grupo | Objetos principales | Información conservada |
| --- | --- | --- |
| Identidad | `AppRole`, `AuthorizedPrincipal`, `AuthorizedPrincipalRole` | Catálogo de roles, identidad, estado y membresías múltiples. `AuthorizedPrincipal.RoleName` se conserva como dato de compatibilidad; las membresías múltiples son la fuente de autorización vigente. |
| Conexiones | `ManagedServer`, `CryptoConfiguration` | Host, instancia, autenticación, opciones TLS, timeout, sobres cifrados y clave envuelta. |
| Solicitudes | `AccessRequest`, `AccessRequestTarget`, `AccessRequestStep` | Cabecera, ticket, actores, estado, destinos, pasos, plan JSON de copia y secreto temporal cifrado cuando corresponde. |
| Política vigente | `PolicyPermissionRule`, `PolicyRoleRule`, `PolicyRoleDiscovery` | Reglas por contexto y roles descubiertos en los destinos. |
| Catálogos | `PolicyPermissionCatalog`, `PolicyScopeCatalog`, `PolicyPermissionAvailability` | Combinaciones permiso/ámbito admitidas y disponibilidad por instancia. |
| Restricciones e historial de política | `SecurityDenyList`, `SecurityPolicyOperation`, `SecurityPolicyPermission`, `SecurityPolicyRole`, `SecurityPolicyOverride` | Bloqueos y operaciones; configuración o excepciones históricas importadas por las migraciones. Desde 27, las reglas por contexto determinan los permisos y roles efectivos. |
| Auditoría | `AuditEvent` | Actor, fecha de Guatemala, acción, destino, éxito, detalle y cadena de integridad. `HashDateBasis` conserva la entrada de fecha original para hashes históricos. |
| Vigencias | `RequestValidity`, `TemporaryAccess`, `TemporaryAccessAction` | Vencimiento de solicitud, recursos temporales, identidad/SID, revisión y resultado de extensiones/cierres. |
| Seguimiento de ejecución | `SecurityEvidenceSource`, `AppExecution`, `AppSecurityChange` | Instancia registrada, intento persistente y comandos tipados con estados y resultados. |
| Metadatos y conteos | `PrincipalMetadataSnapshot`, `AppPasswordDaily` | Referencias por ámbito/SID y conteo de contraseñas confirmadas por instancia/SID/día local. |
| Alertas | `SecurityAlert` | Vencimientos y frecuencia de contraseña, estado activo, revisión y resolución persistida. |
| Versiones y hora | `SecurityMonitoringVersion`, `AppTimeConvention`, `AppTimeConversion` | Contrato de monitoreo v4, convención local y registro de conversiones. |

`AuthorizedPrincipalRole` relaciona cada usuario autorizado con uno o varios roles. `AccessRequestTarget` y `AccessRequestStep` dependen de la solicitud. Las reglas de política identifican su contexto mediante servidor y base, y la información de auditoría permite reconstruir las gestiones.

### 3.5. Ciclo de una solicitud

```mermaid
sequenceDiagram
    actor O as Operador o Administrador
    participant C as Cliente WPF
    participant P as adminDB
    actor A as AprobadorEjecutor o Administrador
    participant S as SQL Server destino
    O->>C: Preparar cambio y consultar ticket
    C->>P: Validar ticket y política por destino
    P-->>C: Motivo del ticket y decisión
    C->>P: Crear solicitud, destinos, pasos o plan
    P-->>C: RequestId / PENDING
    A->>C: Revisar y confirmar o rechazar
    C->>P: usp_AccessRequest_Approve
    P-->>C: APPROVED o REJECTED
    A->>C: Ejecutar solicitud aprobada
    C->>P: Revalidar autorización, política y detalle
    C->>P: Reservar intento y registrar comando tipado
    C->>S: Ejecutar cambios por conexión directa
    S-->>C: Resultado por destino
    C->>P: Confirmar comando después de respuesta o COMMIT
    C->>P: Registrar resultado y auditoría
    P-->>C: EXECUTED o FAILED
```

Toda solicitud pertenece a **un solo servidor**. El pivote evita duplicados equivalentes que continúen pendientes o aprobados. La creación, revisión y ejecución tienen controles funcionales separados, tanto en el cliente como en los procedimientos.

Los estados del contrato son `PENDING`, `APPROVED`, `REJECTED`, `EXECUTED`, `FAILED` y `CANCELLED`. El flujo principal pasa de pendiente a aprobado o rechazado y, tras ejecutar una aprobación, a ejecutado o fallido. La presencia de `CANCELLED` en el contrato no implica una acción de cancelación expuesta en todas las pantallas.

Se admiten creación de login SQL o Windows, creación de usuarios de base, cambios de membresía, permisos, habilitación/deshabilitación de login, copia de accesos y cambio de contraseña de login SQL. La política avanzada incluye accesos de instancia mediante permisos y roles autorizados especialmente. Los roles SQL existentes se consultan y se asignan o retiran como membresías; su definición no se modifica desde el cliente.

El alta puede incluir mapeo a varias bases. Si una solicitud incorpora permisos de objeto, esquema o columna, requiere exactamente una base destino. La ampliación para combinar objetos de bases diferentes se analiza en [ViabilidadPermisosMultibase.md](../../docs/ViabilidadPermisosMultibase.md) y no está implementada.

### 3.6. Política efectiva y descubrimiento

La resolución de reglas sigue la prioridad **base de datos → instancia → plantilla general**. Una regla específica sustituye la heredada; restaurar herencia elimina la regla local. La disponibilidad del catálogo del destino y los bloqueos obligatorios también intervienen en la decisión.

El descubrimiento consulta roles y permisos del servidor seleccionado. Si faltan permisos para obtener un catálogo completo, se detiene la sincronización. Los roles personalizados nuevos aparecen pendientes y requieren autorización en su contexto; compartir nombre con un rol de otro destino no los habilita automáticamente.

Los permisos ordinarios de la matriz incluyen `SELECT`, `INSERT`, `UPDATE`, `DELETE`, `EXECUTE` y `REFERENCES`, según el tipo de objeto. La política avanzada utiliza el catálogo de SQL Server para otros permisos y ámbitos compatibles. `GRANT`, `DENY` y `REVOKE` tienen controles independientes.

Las activaciones especiales exigen motivo, reconocimiento del riesgo y escritura del nombre exacto. Esta confirmación se audita y se revalida en solicitudes y ejecución. Bloquear una opción de política impide gestiones posteriores, pero no retira por sí mismo los accesos existentes del destino.

### 3.7. Secretos, copia y consistencia

**Credenciales y contraseñas temporales.** `AesGcmCredentialProtector` utiliza claves de 32 bytes, nonce aleatorio de 12 bytes y etiqueta de autenticación de 16 bytes. El identificador de clave forma parte de los datos autenticados del sobre. La clave central se genera en SQL Server y se almacena envuelta mediante una clave AES-256 protegida por certificado y Database Master Key. El cliente autorizado obtiene material de clave y descifra en memoria cuando necesita conectarse o crear un login SQL. DPAPI, HSM y gestores externos de secretos no forman parte de esta implementación.

Para Windows no se almacena una contraseña SQL del nuevo usuario. La identidad Windows debe existir y se comprueba en el servidor destino mediante `sys.xp_logininfo`; se exige retorno entero `0`, incluso si no devuelve filas. Se repite la comprobación al enviar y al ejecutar.

**Copia de accesos.** Se guarda un plan JSON v2 con usuario origen y accesos por base, incluidas las exclusiones, y una huella SHA-256. Antes de ejecutar se vuelve a consultar el origen y la política: una diferencia invalida el plan. Se copian membresías y permisos directos compatibles de base, objeto, esquema o columna. No se copian roles de servidor; `GRANT WITH GRANT OPTION` se transforma en concesión sin delegación. Si existen `DENY` o excepciones `REVOKE` en los accesos revisados, se bloquea toda la copia.

**Límites transaccionales.** Los cambios compuestos de permisos/membresías de una base se ejecutan en una transacción. En la copia también se agrupan el usuario nuevo y sus accesos por base. La creación del login es independiente; en el alta con accesos iniciales, los pasos se ejecutan en orden y pueden dejar trabajo aplicado si falla un paso posterior. No hay una transacción global que abarque todas las bases y el pivote.

Por ello, una base completada o un login creado pueden permanecer aunque otra base falle. Además, si el destino confirma cambios y luego falla el registro del resultado en `adminDB`, el estado central puede requerir conciliación. Se deben revisar el destino y la auditoría antes de repetir una gestión con resultado incierto.

**Auditoría.** Los procedimientos registran eventos con cadena hash y el trigger `tr_AuditEvent_AppendOnly` bloquea modificaciones y eliminaciones ordinarias. `usp_Audit_ValidateIntegrity` comprueba enlaces y alteraciones. La integridad de esta cadena complementa los controles SQL y los respaldos; depende también de la administración de la base.

### 3.8. Módulo de Reportes

El menú lateral incorpora **Reportes** inmediatamente debajo de **Administrar accesos**, mediante un árbol plegable con las categorías **Permisos y Accesos** y **Seguridad y Auditoría**. Hay tres reportes directos de configuración y dos reportes centrales de cambios. `ReportsViewModel` y `ReportsView` presentan los directos; `IReportsDataSource`, `ReportsService` y `ReportsSql` separan la interfaz de las consultas de solo lectura a destinos. `SecurityReportsViewModel` y `SecurityReportsView` presentan los centrales mediante el gateway del pivote.

Los reportes directos incluyen permisos por usuario, catálogo dinámico de roles con miembros e Inactividad de credenciales. Este último consulta logins SQL/Windows habilitados y deshabilitados, incluso sin gestiones en la app. Expone filtros de tipo, estado y antigüedad mayor a 45 días completos, hasta 45 días o fecha SQL desconocida; no identifica el último inicio de sesión. Los filtros, resultados vacíos, errores y cancelaciones se administran en el ViewModel, y una respuesta tardía no reemplaza los datos de otro contexto.

Para credenciales SQL, `LOGINPROPERTY(name,'PasswordLastSetTime')` se complementa con `access.usp_Report_ConfirmedPasswordDates` (script 37). Se cruza el SID del catálogo de la instancia con el último `CHANGE_LOGIN_PASSWORD` confirmado para el mismo servidor; no debe ser anterior a la creación del login ni futuro. Si ambas fechas son válidas se usa la más reciente, identificando la fuente. Se descartan fechas nulas, anteriores a la creación o futuras; Windows/AD no ofrece su fecha de contraseña por esta consulta. `modify_date` y sus días se mantienen aparte. Los días son períodos completos de 24 horas; un cambio confirmado hoy muestra 0.

Los cinco reportes pueden exportarse a PDF, CSV UTF-8 y Excel `.xlsx`. `ReportExportDocument` captura contexto, fecha, filtros, orden y secciones; `ReportExportService` genera los archivos en segundo plano y sustituye el destino solo después de completarse. ClosedXML 0.105.0 genera las hojas de Excel y PDFsharp/MigraDoc WPF 6.2.4 compone los PDF paginados. CSV tiene una estructura rectangular y neutraliza entradas que podrían interpretarse como fórmulas. No se utiliza automatización de Office ni una impresora PDF. La publicación debe incluir estas dependencias NuGet.

Permisos por usuario permite exportar todo el reporte o solo la pestaña activa. Catálogo de roles exporta el catálogo y añade miembros solo si se activa esa opción y se marcan roles explícitamente; los filtros retiran marcas ocultas. El PDF de reportes centrales convierte los eventos en fichas de campo/detalle y divide textos largos para evitar recortes.

**Permisos por usuario** permite seleccionar varias bases para un login SQL/Windows de la instancia. Consulta `sys.server_principals`, `sys.server_role_members` y `sys.server_permissions`, y resuelve el usuario de cada base por SID. Los resultados llevan nivel, base y principal; una sección de cobertura identifica bases sin mapeo y acceso por propiedad o `sysadmin`. La instancia se consulta incluso sin bases seleccionadas y `IS_SRVROLEMEMBER` complementa la detección de `sysadmin` reconocida por el motor. Los principales internos de base no aparecen en el selector. Un fallo de consulta por base invalida el resultado completo. Esta capacidad multibase es de consulta y no modifica las limitaciones multibase de solicitudes operativas.

Los reportes directos reutilizan la autorización de conexiones: Administrador, Operador y AprobadorEjecutor. Auditor por sí solo no recibe acceso a las credenciales compartidas. El servicio revalida la sesión antes y después de la consulta. Permisos y catálogo no requieren una migración propia; el complemento de fechas de credenciales sí requiere 37 después de 36/33. La cuenta técnica necesita visibilidad de metadatos del destino.

Los reportes centrales **Cambios de accesos** y **Cambios de contraseña** requieren Administrador/Auditor y el contrato 33 v4. Consultan `usp_Report_SecurityChanges` y `usp_Report_PasswordChanges`; el segundo ofrece ranking e historial. El período usa límites locales desde el inicio del primer día hasta el inicio del día posterior al final elegido. La interfaz admite un período de hasta un año y uno o todos los servidores. Devuelve hasta 1000 filas de ranking o 5000 de historial/cambios de accesos; al alcanzar el límite se debe reducir el período. Las referencias externas se filtran por fecha de detección, sin inventar hora de ejecución.

Consulte [alcance y preparación de Reportes](../../docs/Reportes.md) y [comprobaciones de Reportes](../../tests/ReportsChecks/README.md). Las vistas previas utilizan datos simulados; las comprobaciones SQL opcionales no modifican accesos ni instalan objetos.

### 3.9. Cambio de contraseña SQL

`LoginPasswordManagementViewModel` es una parte de `AccessViewModel`. Habilita la acción para un login `SQL_LOGIN` administrable cargado, ticket validado, motivo válido y operación `CHANGE_LOGIN_PASSWORD` habilitada. Al abrir el diálogo se limpian secretos anteriores y se activan inicialmente política, expiración y cambio obligatorio.

La solicitud usa un único destino de instancia (`master`) y conserva el sobre AES-GCM y las opciones; no incluye los cambios de permisos del borrador. La UI valida complejidad, coincidencia y longitud de 16 a 128 caracteres. `MUST_CHANGE` exige política y expiración. Cambiar identidad, servidor o ticket invalida el contexto del envío; cancelar o terminar limpia el secreto del formulario.

El script 32 incorpora la operación y adapta los contratos de autenticación, creación, validación de política y listado. Crear requiere Administrador/Operador y procesar requiere Administrador/AprobadorEjecutor. `LoginPasswordChangeService` vuelve a comprobar el login real en `sys.sql_logins`, excluye el principal de sistema y construye `ALTER LOGIN` con identificador delimitado. El secreto llega como parámetro y se delimita dentro del servidor; no se guarda texto SQL ni contraseña en el seguimiento tipado. No cambia contraseñas Windows/AD.

### 3.10. Seguimiento de ejecución y metadatos

`ExecutionEvidenceScope` mantiene el contexto de solicitud o cierre temporal con `AsyncLocal`. `TrackedSqlConnection` reserva el intento mediante `usp_AppExecution_Begin` y persiste cada comando con `usp_AppChange_Prepare` antes de enviarlo al destino. Registra operación, principal, ámbito, recurso y ordinal; no conserva contraseñas, hashes de contraseña ni SQL dinámico.

La respuesta satisfactoria confirma un comando sin transacción; los comandos transaccionales se confirman después del COMMIT. `usp_AppChange_Complete` aplica la transición central y evita duplicar una confirmación. El estado del comando es independiente del estado general de la solicitud:

| Estado del comando | Interpretación |
| --- | --- |
| `PENDING` | Comando preparado, sin resultado central final. |
| `CONFIRMED` | Respuesta/COMMIT acreditado; para contraseña se exige SID y fecha final de contraseña. |
| `ROLLED_BACK` | Reversión comprobada; no incrementa conteos. |
| `NO_CHANGE` | Paso sin cambio efectivo, como un usuario ya existente. |
| `UNRESOLVED` | Resultado sin evidencia suficiente; necesita conciliación. |

Un intento reservado no se reejecuta automáticamente. La instrumentación utiliza un token independiente para registrar resultados aunque se cierre/cancele el trabajo de UI; una caída aún puede impedir el registro. Si destino y pivote discrepan, se debe revisar la cuenta, el comando y el resultado real antes de generar una nueva gestión. No existe transacción distribuida ni cola local de recuperación.

`PrincipalMetadataCollector` consulta instancias activas y bases en línea visibles en lotes de hasta 500 filas. Exige `VIEW ANY DEFINITION` de instancia y `VIEW DEFINITION` por base, o los privilegios superiores aceptados por sus comprobaciones. Consulta `sys.server_principals.modify_date`, `sys.database_principals.modify_date` y `LOGINPROPERTY(...,'PasswordLastSetTime')` para SQL. `PrincipalMetadata.Read` normaliza las fechas nativas con el desplazamiento observado del motor.

`usp_PrincipalMetadata_Import` identifica por servidor, ámbito/base y SID. La primera observación establece referencia inicial; el mismo nombre con otro SID inicia una referencia distinta. Fechas de modificación y contraseña se comparan por separado con las observadas en comandos confirmados. Una diferencia sin coincidencia se conserva como última referencia Externo; si hay un comando incierto para esa identidad, se difiere la clasificación hasta conciliarlo.

Externo no acredita autor, herramienta, cantidad ni detalle de permisos. Varios cambios entre consultas, o un cambio revertido entre ellas, pueden no reconstruirse. Las modificaciones de permisos/membresías no necesariamente cambian la fecha del principal. Una base inaccesible conserva su referencia anterior y produce una advertencia; no se deduce la eliminación de usuarios por ausencias del catálogo. La consulta tiene costo y necesita medición de carga según el entorno.

### 3.11. Vigencias y alertas persistentes

La vigencia se adjunta mediante `usp_RequestValidity_Attach` dentro de la misma transacción que crea la solicitud. Debe ser futura y corresponder a operaciones compatibles de alta, mapeo, copia o concesión/membresía nueva. La validación directa impide convertir implícitamente un usuario, permiso o membresía previa en temporal. Los permisos admiten base, esquema, objeto, columna o servidor completo; otros ámbitos se rechazan.

Tras la ejecución se registra el recurso en `TemporaryAccess`. El vencimiento evaluado en el pivote conserva el acceso y materializa alertas en lotes de hasta 500 por evaluación. `TemporaryAccessViewModel` permite consultar hasta 5000 vigencias y 1000 acciones. Solo Administrador crea y procesa acciones con ticket validado y motivo obtenido de su descripción/asunto; el SP vuelve a comprobar el ticket al crear la acción.

La extensión debe superar el vencimiento anterior y la hora actual; actualiza la vigencia central sin conceder permisos nuevos. El cierre comprueba SID y aplica la acción del recurso: deshabilitar login, eliminar usuario, ejecutar `REVOKE` o retirar membresía. Deshabilitar no termina sesiones, `REVOKE` directo no elimina accesos heredados y `DROP USER` puede fallar por propiedad de objetos. El ciclo usa creación, revisión, reserva de ejecución y registro del resultado. Una acción que quede en `EXECUTING` tras una caída requiere conciliación. Solo completar satisfactoriamente extensión/cierre resuelve su alerta.

`AppPasswordDaily` cuenta por instancia/fuente, SID y día calendario de Guatemala. Solo suma `CHANGE_LOGIN_PASSWORD` confirmado. Excluye altas iniciales, configuración, Windows/AD, referencias externas, reentregas y resultados pendientes/inciertos. El tercer cambio genera alerta; los posteriores actualizan la activa. Revisarla no borra historial ni contador; otro cambio nuevo puede crear otra alerta.

`SecurityAlertsViewModel` muestra hasta 50 alertas activas recientes, con búsqueda y filtros. Administrador/Auditor registra revisión de contraseña mediante `usp_PasswordAlert_Resolve`, con motivo de al menos 10 caracteres. Los vencimientos se atienden desde Usuarios temporales. `DashboardSecurityViewModel` conserva contadores y abre la ventana modal; al revisar refresca el resumen central sin volver a consultar destinos.

`SecurityMonitoringService` espera 60 segundos después de cada ciclo mientras WPF está abierto y evita ciclos superpuestos. Consulta metadatos solo con Administrador/AprobadorEjecutor; otras sesiones consultan resumen y alertas del pivote. Si falla una consulta conserva el estado previo y comunica que no está actualizado. El contador de resultados por conciliar del resumen corresponde a comandos de contraseña en `PENDING`/`UNRESOLVED`; no es un total de todos los fallos de acceso. El worker opcional permite continuar esos ciclos fuera de WPF, como se describe en 4.9.

### 3.12. Hora local de Guatemala e integridad histórica

`AppTime` usa `Central America Standard Time`; `Now` devuelve un `DateTime` sin zona incorporada y `Display` usa `yyyy-MM-dd HH:mm:ss`. Las fechas estructuradas se almacenan y muestran como hora local de Guatemala, sin conversión adicional de presentación. Los valores nativos de destinos se normalizan con `EngineOffsetMinutes`; no se comparan por proximidad con el reloj del cliente.

El script 36 revisa las columnas de fecha de `access`, convierte los valores históricos UTC una sola vez, elimina sufijos `Utc` y actualiza defaults/módulos para utilizar `access.ufn_AppNow()`. Una columna sin convención conocida detiene la conversión. `AppTimeConvention` impide una segunda conversión y `AppTimeConversion` conserva su registro. El proceso se ejecuta en transacción con bloqueo de instalación; no altera catálogos ni fechas de contraseña de los destinos.

Antes de convertir `AuditEvent` se valida la cadena. `HashDateBasis` conserva la entrada binaria original de fecha; `EventHash`, `PreviousHash` y textos históricos permanecen intactos. El validador comprueba tanto los hashes anteriores como la conversión de la fecha visible. Los eventos nuevos usan su fecha local y enlazan con la cadena existente. Por ello los textos libres históricos pueden mencionar UTC aunque las columnas estructuradas ya sean locales.

El orden de cierre es **32 → 36 → 33 v4 → 37 → 99**. Las migraciones 01–32 bloquean su reaplicación sobre la convención local para evitar restaurar escrituras o validadores anteriores. Consulte [hora local de Guatemala](../../docs/HoraLocalGuatemala.md).

## 4. Configuración y despliegue

### 4.1. Requisitos previos

| Requisito | Preparación |
| --- | --- |
| Equipo cliente | Windows, SDK para desarrollo y acceso al origen NuGet para la restauración inicial. |
| Pivote | Instancia SQL Server, base `adminDB`, conectividad y cuenta DBA para instalar los insumos. |
| Destinos | Conectividad desde cada equipo cliente y credencial con permisos suficientes para las operaciones autorizadas. |
| TLS | Certificados confiables y nombres de conexión que correspondan al certificado, para trabajar con `Encrypt=true` y `TrustServerCertificate=false`. |
| Autorización inicial | Login válido, usuario de base y registro activo del Administrador inicial. Las migraciones posteriores deben conservar su membresía `Administrator`. |
| Tickets | `dbo.sp_VerificarTicketExiste` instalado en `adminDB` e integrado con la fuente de tickets antes de ejecutar 27. Su implementación no está incluida en los insumos. |
| Herramientas SQL | SSMS o `sqlcmd` capaz de procesar lotes separados por `GO`. |

La cuenta técnica de destino necesita visibilidad de metadatos y capacidad para crear logins/usuarios o asignar los permisos y membresías que vaya a gestionar. El DBA debe preparar esos permisos según el alcance aprobado. Los roles funcionales de la aplicación no conceden automáticamente privilegios en los destinos.

El seguimiento requiere `VIEW ANY DEFINITION` de instancia y `VIEW DEFINITION` en las bases consultadas, o los privilegios superiores admitidos por el código. No requiere conceder `CONTROL SERVER` para leer metadatos. El worker también necesita conectividad, runtime Windows y una identidad registrada con permisos de aplicación y destino. No se instala base, trigger de captura, SQL Server Audit, cola ni lector firmado en destinos.

### 4.2. Preparación manual de `adminDB`

La aplicación no crea `adminDB`, no instala objetos ni ejecuta migraciones. El DBA debe revisar y ejecutar los archivos de [InsumosProduccion](../README.md), comprobar cada error y respaldar la base antes de actualizar una instalación existente.

Para una instalación nueva con los archivos actuales:

| Paso | Insumos | Acción |
| --- | --- | --- |
| 1 | `00_CrearBaseDatos.sql` | Ejecutar solo si la base no existe. También configura recuperación FULL y READ_COMMITTED_SNAPSHOT; revisar estas opciones y el plan de respaldos. |
| 2 | `01` → `02` → `03` → `04` | Crear esquema, tablas iniciales, SP y roles técnicos. |
| 3 | `05_DatosIniciales.sql` | Personalizar principal y tipo. Crear/mapear el usuario SQL y sus roles técnicos según los ejemplos del archivo. |
| 4 | `08_ConfigurarConexionDirectaYCifrado.sql` | Configurar la clave central y su protección. Revisar y sustituir la asignación de `@DatabaseMasterKeyPassword` por un secreto propio antes de ejecutar; custodiarlo fuera de la documentación. |
| 5 | `02` → `03` → `04` | Reaplicar inmediatamente después de 08 para restablecer los contratos y permisos base indicados en la guía de conexiones directas. |
| 6 | `10` → `11` → `12` → `13` → `14` → `15` → `16` → `17` → `18` → `19` | Instalar la evolución de políticas, solicitudes, tickets y secretos temporales. |
| 7 | `21` → `22` → `23` → `24` → `25` → `26` | Incorporar cambios compuestos, copia detallada, autenticación SQL/Windows y activaciones especiales. |
| 8 | Procedimiento externo de tickets | Comprobar el contrato descrito en 4.3 antes de continuar. |
| 9 | `27` → `28` → `29 actualizado` → `30` → `31` | Política por destino, catálogo de credenciales, autorización estricta, roles múltiples y selección de cuentas existentes. |
| 10 | `32_CambiarContrasenaLogin.sql` | Incorporar el cambio de contraseña SQL y sus validaciones; completar antes de convertir fechas. |
| 11 | `36_HoraLocalGuatemala.sql` | Convertir fechas históricas y contratos a la convención local, conservando hashes. Ejecutar antes de 33. |
| 12 | `33_MonitoreoSeguridadYTemporales.sql` actualizado v4 | Instalar vigencias, alertas, comandos tipados, metadatos y reportes centrales. Reaplicar el actual si existe una versión anterior. |
| 13 | `37_FechasContrasenaConfirmadas.sql` | Añadir la consulta de fechas confirmadas para el reporte de credenciales. No cambia cuentas ni contraseñas. |
| 14 | `99_ValidarInstalacion.sql` | Revisar objetos, autorización, contraseña, monitoreo v4, hora local y complemento de fechas. Corregir faltantes antes de abrir cliente/worker. |

`07` es una corrección histórica de login; `09` migra nombres heredados de roles; `20` mueve objetos desde `dbo` o el esquema transitorio `SqlAccessAdmin` hacia `access`. En una instalación nueva cuyos objetos ya se crean en `access`, estos archivos no son pasos funcionales adicionales. En una instalación heredada, el DBA debe seguir las instrucciones de migración de [la guía de insumos](../README.md), incluida la aplicación de 20 con el cliente detenido cuando corresponda.

Para actualizar una instalación existente, detener clientes y worker, respaldar el pivote y aplicar solo los pasos pendientes de acuerdo con su estado:

| Estado previo | Secuencia para completar esta entrega |
| --- | --- |
| 29 actualizado, sin roles múltiples | `30 → 31 → 32 → 36 → 33 v4 → 37 → 99`. |
| 31 completo con fechas históricas UTC | `32 → 36 → 33 v4 → 37 → 99`. |
| 32 completo o monitoreo anterior con fechas UTC | `36 → 33 v4 actualizado → 37 → 99`. |
| Convención local y 33 v4 completos | Aplicar 37 si falta y ejecutar 99. Reaplicar 33 actualizado si corresponde a una revisión del contrato. |

Después se publica la carpeta completa compatible y se reinician las sesiones. No ordenar automáticamente los scripts por número: 36 precede a 33. No reaplicar 01–32 después de convertir la hora; sus guardas impiden restaurar contratos antiguos. Conservar el respaldo y coordinar la recuperación de cliente/base si una actualización falla.

Los antiguos ejemplos de captura en `docs/archive/monitoring-v2` y las propuestas históricas no son instaladores vigentes. Esta entrega no utiliza ni retira automáticamente infraestructura de captura instalada anteriormente; si existiera, su retirada requiere una operación controlada del DBA.

Ejemplo de ejecución individual desde la raíz del proyecto, sustituyendo el servidor por el del entorno:

```powershell
sqlcmd -S 'SERVIDOR\INSTANCIA' -E -b -i '.\InsumosProduccion\01_CrearEsquema.sql'
sqlcmd -S 'SERVIDOR\INSTANCIA' -E -b -i '.\InsumosProduccion\99_ValidarInstalacion.sql'
```

Son ejemplos separados de instalación y validación; entre ambos deben aplicarse los pasos correspondientes de la tabla. `-b` permite detener la ejecución de `sqlcmd` ante errores SQL relevantes. Los scripts 05 y 08 requieren revisión y personalización; no deben incorporarse sin ella a una ejecución automática de todos los archivos.

### 4.3. Dependencia de tickets y cuentas Windows

El script 27 comprueba que exista `dbo.sp_VerificarTicketExiste` y concede su ejecución a `SqlAccessAdmin_Users`. El gateway lo invoca con `@Ticket` de tipo `varchar(50)`. La creación de solicitudes consume su resultado mediante `INSERT ... EXEC`, por lo que necesita las siguientes columnas en este orden y con tipos compatibles:

| Columna | Tipo receptor utilizado por el contrato |
| --- | --- |
| `RESPONSABLE` | `nvarchar(4000)` |
| `CLIENTE` | `nvarchar(4000)` |
| `ID_COMPUESTO` | `varchar(50)` |
| `ASUNTO` | `nvarchar(4000)` |
| `DESCRIPCION` | `nvarchar(max)` |
| `ESTADO` | `nvarchar(4000)` |

La integración debe devolver tickets válidos/activos conforme a su contrato. El SP de solicitud exige que `ID_COMPUESTO` coincida con el ticket consultado y toma como justificación `DESCRIPCION`, o `ASUNTO` si no hay descripción. El motivo resultante debe tener al menos diez caracteres. El sistema externo de tickets y su conexión se preparan fuera de esta solución.

Para comprobar nombres Windows, la cuenta usada en cada destino necesita ejecutar `sys.xp_logininfo` en `master`, además de la conectividad del servidor con el equipo o dominio correspondiente. Ejemplo que el DBA debe adaptar al usuario técnico existente:

```sql
USE [master];
GO
GRANT EXECUTE ON OBJECT::sys.xp_logininfo TO [UsuarioTecnicoEnMaster];
GO
```

Esta concesión se aplica en cada servidor de trabajo que la necesite. La aplicación crea el login SQL asociado a una cuenta Windows existente; la creación de cuentas del dominio o del equipo queda fuera de su alcance.

### 4.4. Restaurar, compilar y ejecutar el entorno de desarrollo

Abrir PowerShell en la raíz del proyecto:

```powershell
dotnet --info
dotnet restore .\SQLUserPermisos.sln
dotnet build .\SQLUserPermisos.sln -c Debug --no-restore
dotnet run --project .\src\SqlAccessAdmin\SqlAccessAdmin.csproj
```

También se puede abrir `SQLUserPermisos.sln` en Visual Studio y seleccionar `SqlAccessAdmin` como proyecto de inicio. Los proyectos de comprobaciones y el worker se ejecutan por su ruta; no están incluidos en la solución.

La conexión al pivote se introduce en la ventana de inicio. No hay un archivo `appsettings.json` de aplicación ni una cadena de conexión de entorno que deba editarse para este flujo.

| Parámetro | Valor inicial en `LoginViewModel` | Uso |
| --- | --- | --- |
| Servidor | `localhost` | Host del pivote. |
| Instancia | Vacía | Opcional; se combina como `servidor\instancia`. |
| Base | `adminDB` | Catálogo central. Los scripts de entrega utilizan ese nombre. |
| Autenticación integrada | Activada | Identidad Windows; puede elegirse autenticación SQL. |
| Usuario y contraseña | Vacíos | Se utilizan si se selecciona autenticación SQL. |
| Cifrar conexión | Activado | `Encrypt=true`. |
| Confiar en certificado | Desactivado | `TrustServerCertificate=false`. |

El gateway configura timeout de conexión de 15 segundos y de comando de 120 segundos. Cada servidor destino conserva su propio timeout; el valor inicial es 30 segundos. Las opciones TLS de los destinos se configuran en el mantenimiento de servidores.

Después de ingresar como Administrador:

1. Registrar o revisar un servidor activo y probar su conexión directa.
2. Comprobar el descubrimiento de bases, roles y permisos, y autorizar la política del contexto necesario.
3. Registrar usuarios autorizados seleccionando logins individuales Windows/SQL ya existentes y habilitados en el pivote; asignar sus roles funcionales.
4. En una instancia de pruebas, validar un ticket y completar el ciclo crear → confirmar → ejecutar con las identidades correspondientes.
5. Revisar resultados, historial y auditoría, incluida la validación de integridad.
6. Cambiar la contraseña de un login SQL de laboratorio mediante solicitud y comprobar el resultado, las opciones y la fecha del reporte de credenciales.
7. Crear un acceso temporal nuevo, comprobar que vencer solo alerta y completar una extensión/cierre con Administrador. Verificar permisos de consulta/revisión con Auditor.
8. Establecer la referencia inicial de metadatos y comprobar reportes centrales, alertas, exportaciones y funcionamiento del worker si se va a utilizar.

### 4.5. Comprobaciones disponibles

Los proyectos disponibles se ejecutan por separado desde la raíz. Sus modos locales usan datos simulados y controles WPF; no acreditan por sí mismos conectividad, tickets ni permisos reales de infraestructura.

```powershell
dotnet run --project .\tests\LoginPasswordChecks -c Release
dotnet run --project .\tests\ReportsChecks -c Release -- .\artifacts\report-previews
dotnet run --project .\tests\SecurityMonitoringChecks -c Release -- .\artifacts\security-monitoring-previews
```

Contraseñas comprueba ticket, roles, complejidad, opciones y detalle sin secreto. Reportes comprueba contexto, filtros, cancelaciones y exportaciones PDF/CSV/Excel; reabre archivos y valida estructura. Seguimiento comprueba temporales, umbral, revisión, autorizaciones, fechas, exportaciones y sintaxis central. ScriptDom pertenece a las pruebas de sintaxis; el cliente y el worker no lo requieren.

Con ScriptDom disponible, el verificador de migración de contraseña comprueba sintaxis y transformaciones sin instalar objetos. Su modo SQL opcional evalúa variantes de encabezados en variables de tabla de `master`:

```powershell
.\tests\LoginPasswordChecks\CheckMigration.ps1
.\tests\LoginPasswordChecks\CheckMigration.ps1 -Server localhost
```

Las consultas opcionales siguientes son de solo lectura; requieren instancia accesible y permisos apropiados:

```powershell
dotnet run --project .\tests\ReportsChecks -c Release -- .\artifacts\report-previews --sql-smoke localhost
.\tests\SecurityMonitoringChecks\CheckSqlInstallation.ps1 -PivotServer localhost -Database adminDB
```

El modo SQL de Reportes consulta catálogos y verifica casos mediante variables de tabla. `CheckSqlInstallation.ps1` comprueba el contrato central v4; con `-TargetServer` también revisa visibilidad de instancia. No sustituye al validador 99 completo ni verifica automáticamente todas las bases destino.

El laboratorio siguiente requiere una instancia DBA de pruebas y **sí crea y elimina sus propios recursos aleatorios**:

```powershell
.\tests\SecurityMonitoringChecks\RunSqlLab.ps1 -Server localhost -TrustCertificate
```

Comprueba contraseñas reales, conteos, idempotencia, referencia inicial/externa, SID distinto, rollback/commit, conversión horaria y hashes históricos utilizando instrumentación real. No modifica `adminDB` ni cuentas existentes; usa una base y login exclusivos del laboratorio. `-TrustCertificate` es una elección explícita del entorno de pruebas.

Consulte alcance, requisitos y límites en [contraseñas](../../tests/LoginPasswordChecks/README.md), [reportes](../../tests/ReportsChecks/README.md) y [seguimiento/laboratorio](../../tests/SecurityMonitoringChecks/README.md). Los comandos se documentan para su ejecución controlada; esta actualización de documentos no acredita que esas comprobaciones se hayan vuelto a ejecutar.

### 4.6. Publicación y entrega del cliente

Ejemplo de publicación para equipos Windows x64 con **.NET Desktop Runtime 8** instalado:

```powershell
dotnet publish .\src\SqlAccessAdmin\SqlAccessAdmin.csproj -c Release -r win-x64 --self-contained false -o .\artifacts\publish\win-x64
```

Para incluir el runtime en la entrega:

```powershell
dotnet publish .\src\SqlAccessAdmin\SqlAccessAdmin.csproj -c Release -r win-x64 --self-contained true -o .\artifacts\publish\win-x64-self-contained
```

Estos son comandos de publicación propuestos para x64; el repositorio no fija un Runtime Identifier ni un perfil de publicación. Se distribuye **la carpeta completa** generada, incluidas las dependencias y componentes nativos de SqlClient, y se ejecuta `SqlAccessAdmin.exe`. La preparación de `adminDB` continúa siendo un paso manual independiente.

Para actualizar un entorno: detener clientes y worker, respaldar y aplicar las migraciones pendientes en el orden de 4.2, ejecutar 99, desplegar las carpetas completas compatibles y abrir sesiones nuevas. Conservar una entrega anterior del cliente y respaldos de la base permite preparar una recuperación coordinada; sustituir solo el ejecutable no revierte contratos SQL ni la conversión horaria.

### 4.7. Diagnóstico básico

| Síntoma | Revisión técnica |
| --- | --- |
| `adminDB` no preparada o no accesible | Nombre de servidor/base, conexión, permisos y ejecución de los insumos; errores SQL 208, 2812 o 4060 pueden producir este mensaje. |
| Se exige actualizar la autorización | Contrato `AuthorizationVersion=2` y scripts 29 actualizado, 30, 31 y 99. |
| Conecta a SQL pero rechaza la entrada | Principal canónico, `Active=1`, membresías de aplicación y roles técnicos del usuario de base. |
| La sesión se bloquea después de cambiar roles | Comportamiento previsto; cerrar y volver a ingresar para obtener una sesión con el nuevo contexto. |
| Falla la conexión cifrada | Certificado confiable, nombre del servidor, acceso de red y configuración TLS. |
| Falla Comprobar nombres Windows | Existencia de la cuenta, resolución del dominio desde SQL Server y permiso sobre `sys.xp_logininfo`. |
| Descubrimiento incompleto o bloqueado | Permisos de visibilidad de metadatos en el destino. |
| Falla o se rechaza el ticket | Existencia del SP externo, parámetro/resultado compatibles, ticket activo, identificador y motivo válido. |
| No se puede ejecutar una copia aprobada | Huella y detalle guardado, política vigente, accesos actuales del origen, exclusiones y disponibilidad del nombre nuevo. |
| Operación parcialmente aplicada | Revisar login y cada base, resultados y auditoría antes de volver a solicitar cambios. |
| Cambiar contraseña está deshabilitado | Tipo SQL y login administrable, ticket/motivo válidos, rol creador y operación del script 32 habilitada. |
| Monitoreo ausente o versión incompatible | Verificar 36 y `SecurityMonitoringVersion.Version=4`; reaplicar 33 actualizado y completar 37/99 con clientes y worker detenidos. |
| Falla Inactividad de credenciales por falta del complemento | Aplicar 37 después de 36/33; comprobar `usp_Report_ConfirmedPasswordDates` y permisos de ejecución. |
| Fechas desplazadas o conversión de hora rechazada | Revisar `AppTimeConvention`, registro de conversión, integridad de auditoría y orden de migraciones; no restar horas manualmente ni reaplicar 01–32. |
| Externo sin actor o sin detalle del permiso | Límite previsto: es la última diferencia de metadatos sin registro confirmado coincidente, no captura completa. |
| Comando pendiente/incierto o intento reservado | Comparar destino, SID, solicitud, `AppExecution` y `AppSecurityChange` antes de generar otra gestión. No reejecutar automáticamente. |
| Vencimiento con acceso todavía activo | Comportamiento previsto; Administrador debe completar extensión/cierre. Un fallo o `EXECUTING` persistente exige conciliación. |
| Alertas/metadatos sin actualizar | Revisar última consulta, advertencias, cliente/worker en ejecución, identidad autorizada, conectividad y visibilidad por instancia/base. |

### 4.8. Referencias del proyecto

- [Descripción y ejecución del cliente](../../README.md).
- [Orden de instalación e insumos para el DBA](../README.md).
- [Identidad y usuarios autorizados](../../docs/UsuariosAutorizados.md).
- [Política por instancia y base](../../docs/PoliticaAccesoPorDestino.md).
- [Contrato de acceso al pivote](../../src/SqlAccessAdmin/Data/AdminDbGateway.cs).
- [Ejecución directa sobre destinos](../../src/SqlAccessAdmin/Data/DirectSqlServerService.cs).
- [Copia de accesos](../../src/SqlAccessAdmin/Data/PermissionCopyService.cs).
- [Protección criptográfica de sobres](../../src/SqlAccessAdmin/Security/AesGcmCredentialProtector.cs).
- [Reportes y exportación](../../docs/Reportes.md).
- [Seguimiento de seguridad y temporales](../../docs/MonitoreoSeguridad.md).
- [Hora de Guatemala y conversión](../../docs/HoraLocalGuatemala.md).
- [Instrumentación de comandos](../../src/SqlAccessAdmin/Data/ExecutionEvidenceScope.cs).
- [Worker de seguimiento](../../tools/SecurityMonitoringWorker/Program.cs).

### 4.9. Publicación y operación del worker opcional

El worker es un ejecutable de consola Windows que reutiliza gateway y servicio directo. No se instala como servicio ni tarea automáticamente. Ejemplo de publicación con runtime de escritorio .NET 8 instalado:

```powershell
dotnet publish .\tools\SecurityMonitoringWorker\SecurityMonitoringWorker.csproj -c Release -r win-x64 --self-contained false -o .\artifacts\publish\worker-win-x64
```

Distribuir la carpeta completa. Para probar desde el código o ejecutar un ciclo:

```powershell
dotnet run --project .\tools\SecurityMonitoringWorker -- 'SERVIDOR_PIVOTE\INSTANCIA' adminDB --once
dotnet run --project .\tools\SecurityMonitoringWorker -- 'SERVIDOR_PIVOTE\INSTANCIA' adminDB
```

La identidad Windows que ejecuta el proceso debe estar registrada y activa en la aplicación. Para consultar destinos requiere Administrador/AprobadorEjecutor y permisos técnicos de metadatos; si el destino usa autenticación integrada, se conecta con esa identidad del proceso. No se pasan contraseñas por argumentos.

| Opción | Comportamiento |
| --- | --- |
| `--once` | Ejecuta un ciclo y termina; un fallo devuelve salida de error. |
| `--expire-only` | Evalúa resumen/vencimientos en el pivote sin obtener credenciales ni consultar metadatos de destinos. No requiere la función de revisión de solicitudes. |
| `--trust-certificate` | Activa explícitamente confianza del certificado de la conexión al pivote según la configuración del entorno. |

Sin `--once`, espera 60 segundos después de cada ciclo, reintenta fallos de ciclo y se detiene al perder autorización. `Ctrl+C` solicita cancelación. La salida muestra contadores, advertencias y errores; infraestructura debe conservarla y configurar ejecución, reinicio y supervisión mediante sus mecanismos Windows aprobados. Con cliente y worker cerrados no hay un proceso propio que evalúe periódicamente; la siguiente consulta central materializa los vencimientos pendientes sin retirar accesos automáticamente.

Las instrucciones anteriores documentan la preparación y operación del sistema; la elaboración de este archivo no aplica migraciones ni cambia accesos en SQL Server.
