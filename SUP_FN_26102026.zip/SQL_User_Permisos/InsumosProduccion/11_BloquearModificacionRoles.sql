USE [adminDB];
GO
IF OBJECT_ID(N'access.AppTimeConvention',N'U') IS NOT NULL THROW 51856,'La base ya usa hora de Guatemala. No reaplique migraciones históricas; use 36, 33 actualizado y 99.',1;
GO
SET NOCOUNT ON;
SET XACT_ABORT ON;
GO

/*
  Migración para instalaciones existentes.
  La aplicación conserva [access].SecurityPolicyRole y [access].usp_Policy_RoleList
  únicamente como catálogo de roles asignables. Se elimina toda ruta de escritura.
*/

DROP PROCEDURE IF EXISTS [access].usp_Policy_RoleUpsert;
GO

IF OBJECT_ID(N'[access].usp_Audit_Write',N'P') IS NOT NULL
    EXEC [access].usp_Audit_Write
        N'Política central',
        N'Bloquear modificación de roles',
        NULL,
        NULL,
        1,
        N'Eliminado [access].usp_Policy_RoleUpsert; los roles quedan disponibles solo para membresías.';
GO

SELECT
    RoleName,
    RoleKind,
    Enabled,
    Notes
FROM [access].SecurityPolicyRole
ORDER BY RoleKind,RoleName;
GO

