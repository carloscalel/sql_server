USE [adminDB];
GO
IF OBJECT_ID(N'access.AppTimeConvention',N'U') IS NOT NULL THROW 51856,'La base ya usa hora de Guatemala. No reaplique migraciones históricas; use 36, 33 actualizado y 99.',1;
GO
SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
GO

CREATE OR ALTER FUNCTION [access].ufn_App_Principal()
RETURNS nvarchar(256)
AS
BEGIN
    -- SqlAccessAdmin.CanonicalWindowsIdentity.v1
    -- El SID original no cambia con EXECUTE AS. No usar el contexto suplantado.
    DECLARE @OriginalSid varbinary(85), @Original nvarchar(256)=ORIGINAL_LOGIN(), @Canonical nvarchar(256);
    SELECT @OriginalSid=original_security_id FROM sys.dm_exec_sessions WHERE session_id=@@SPID;
    IF @OriginalSid IS NULL RETURN NULL;
    SET @Canonical=SUSER_SNAME(@OriginalSid);
    IF @Canonical IS NULL RETURN @Original;
    -- Prioridad al nombre DOMINIO\\usuario registrado, incluso si está inactivo.
    -- Un alias alternativo activo no puede eludir la baja del registro canónico.
    IF EXISTS(SELECT 1 FROM [access].AuthorizedPrincipal WHERE Principal=@Canonical) RETURN @Canonical;
    IF EXISTS(SELECT 1 FROM [access].AuthorizedPrincipal WHERE Principal=@Original) RETURN @Original;
    RETURN @Canonical;
END;
GO

CREATE OR ALTER PROCEDURE [access].usp_App_LoginContext
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @Principal nvarchar(256) = [access].ufn_App_Principal();

    IF EXISTS(SELECT 1 FROM [access].AuthorizedPrincipal WHERE Active=1 AND Principal=@Principal)
    BEGIN
        SELECT TOP (1) Principal, RoleName AS [Role], CAST(1 AS bit) AS IsAuthorized, CAST(1 AS int) AS AuthorizationVersion,
               N'Principal autorizado mediante la lista blanca.' AS Detail
        FROM [access].AuthorizedPrincipal
        WHERE Active=1 AND Principal=@Principal;
        RETURN;
    END;

    -- SqlAccessAdmin.ExplicitAuthorization.v1: roles SQL no autorizan acceso a la aplicación.
    SELECT @Principal AS Principal, CAST(NULL AS varchar(20)) AS [Role], CAST(0 AS bit) AS IsAuthorized, CAST(1 AS int) AS AuthorizationVersion,
           N'El principal detectado por SQL Server ['+@Principal+N'] no está activo en [access].AuthorizedPrincipal.' AS Detail;
END;
GO

CREATE OR ALTER PROCEDURE [access].usp_Server_List
AS
BEGIN
    SET NOCOUNT ON;
    SELECT ServerId, Active, Name, Host, ISNULL(Instance,N'') AS Instance,
           WindowsAuth, ISNULL(SqlUser,N'') AS SqlUser, Encrypt,
           TrustServerCertificate AS TrustCertificate, TimeoutSeconds
    FROM [access].ManagedServer
    ORDER BY Name;
END;
GO

CREATE OR ALTER PROCEDURE [access].usp_Server_GetConnection
    @ServerId int
AS
BEGIN
    SET NOCOUNT ON;
    SELECT ServerId,Name,Host,ISNULL(Instance,N'') AS Instance,WindowsAuth,
           ISNULL(SqlUser,N'') AS SqlUser,CredentialCiphertext,CredentialNonce,CredentialTag,
           CredentialKeyId,Encrypt,TrustServerCertificate,TimeoutSeconds,Active
    FROM [access].ManagedServer WHERE ServerId=@ServerId AND Active=1;
END;
GO

CREATE OR ALTER PROCEDURE [access].usp_AuthorizedUser_List
AS
BEGIN
    SET NOCOUNT ON;
    SELECT UserId, Principal, PrincipalType, RoleName AS [Role], Active, ISNULL(Notes,N'') AS Notes
    FROM [access].AuthorizedPrincipal
    ORDER BY Principal;
END;
GO

CREATE OR ALTER PROCEDURE [access].usp_Audit_List
    @Filter nvarchar(200) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SELECT TOP (500) EventDate, Principal, Form, Action,
           ISNULL(ServerName,N'') AS Server, ISNULL(DatabaseName,N'') AS [Database],
           Success, ISNULL(Detail,N'') AS Detail
    FROM [access].AuditEvent
    WHERE @Filter IS NULL OR @Filter = N''
       OR Principal LIKE N'%' + @Filter + N'%'
       OR Form LIKE N'%' + @Filter + N'%'
       OR Action LIKE N'%' + @Filter + N'%'
       OR ServerName LIKE N'%' + @Filter + N'%'
       OR DatabaseName LIKE N'%' + @Filter + N'%'
       OR Detail LIKE N'%' + @Filter + N'%'
    ORDER BY EventDate DESC, AuditId DESC;
END;
GO

