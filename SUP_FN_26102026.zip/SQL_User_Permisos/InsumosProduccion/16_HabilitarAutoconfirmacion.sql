USE [adminDB];
GO
IF OBJECT_ID(N'access.AppTimeConvention',N'U') IS NOT NULL THROW 51856,'La base ya usa hora de Guatemala. No reaplique migraciones históricas; use 36, 33 actualizado y 99.',1;
GO
SET NOCOUNT ON;
SET XACT_ABORT ON;
GO

/*
  Ejecutar manualmente como DBA después de 15_PrevenirSolicitudesDuplicadas.sql.

  El flujo de aprobación se usa como doble check del mismo operador, no como
  segregación de funciones. Administrator y Operator pueden confirmar o
  rechazar sus propias solicitudes y ejecutar las que hayan confirmado.
  La auditoría, la allowlist y el bloqueo de duplicados permanecen activos.
*/

CREATE OR ALTER PROCEDURE [access].usp_AccessRequest_Approve
    @RequestId bigint,
    @Approve bit,
    @Comment nvarchar(1000)
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    -- SqlAccessAdmin.SelfConfirmation
    IF IS_SRVROLEMEMBER(N'sysadmin')<>1
       AND NOT EXISTS
       (
           SELECT 1
           FROM [access].AuthorizedPrincipal
           WHERE Principal=[access].ufn_App_Principal()
             AND Active=1
             AND RoleName IN('Administrator','Operator')
       )
        THROW 51301,'Se requiere un usuario Administrator u Operator activo.',1;

    BEGIN TRAN;
    DECLARE @ApprovalLockResult int;
    EXEC @ApprovalLockResult=sys.sp_getapplock
        @Resource=N'SqlAccessAdmin.AccessRequestApprove',
        @LockMode='Exclusive',
        @LockOwner='Transaction',
        @LockTimeout=10000;
    IF @ApprovalLockResult<0
        THROW 51319,'No fue posible bloquear la confirmación de solicitudes.',1;

    IF @Approve=1 AND EXISTS
    (
        SELECT 1
        FROM [access].AccessRequest currentRequest
        JOIN [access].AccessRequest approvedRequest
          ON approvedRequest.RequestId<>currentRequest.RequestId
         AND approvedRequest.Status='APPROVED'
         AND approvedRequest.OperationCode=currentRequest.OperationCode
         AND UPPER(LTRIM(RTRIM(approvedRequest.TargetPrincipal)))=UPPER(LTRIM(RTRIM(currentRequest.TargetPrincipal)))
         AND ISNULL(UPPER(LTRIM(RTRIM(approvedRequest.SourcePrincipal))),N'')=ISNULL(UPPER(LTRIM(RTRIM(currentRequest.SourcePrincipal))),N'')
         AND ISNULL(UPPER(approvedRequest.AuthenticationType),'')=ISNULL(UPPER(currentRequest.AuthenticationType),'')
         AND ISNULL(UPPER(approvedRequest.PermissionAction),'')=ISNULL(UPPER(currentRequest.PermissionAction),'')
         AND ISNULL(UPPER(approvedRequest.PermissionName),'')=ISNULL(UPPER(currentRequest.PermissionName),'')
         AND ISNULL(UPPER(approvedRequest.ScopeType),'')=ISNULL(UPPER(currentRequest.ScopeType),'')
         AND ISNULL(UPPER(LTRIM(RTRIM(approvedRequest.Securable))),N'')=ISNULL(UPPER(LTRIM(RTRIM(currentRequest.Securable))),N'')
         AND ISNULL(UPPER(LTRIM(RTRIM(approvedRequest.RoleName))),N'')=ISNULL(UPPER(LTRIM(RTRIM(currentRequest.RoleName))),N'')
        WHERE currentRequest.RequestId=@RequestId
          AND currentRequest.Status='PENDING'
          AND NOT EXISTS
          (
              SELECT ServerId,DatabaseName
              FROM [access].AccessRequestTarget
              WHERE RequestId=currentRequest.RequestId
              EXCEPT
              SELECT ServerId,DatabaseName
              FROM [access].AccessRequestTarget
              WHERE RequestId=approvedRequest.RequestId
          )
          AND NOT EXISTS
          (
              SELECT ServerId,DatabaseName
              FROM [access].AccessRequestTarget
              WHERE RequestId=approvedRequest.RequestId
              EXCEPT
              SELECT ServerId,DatabaseName
              FROM [access].AccessRequestTarget
              WHERE RequestId=currentRequest.RequestId
          )
    )
    BEGIN
        ROLLBACK;
        THROW 51318,'Ya existe otra solicitud equivalente confirmada. Rechace este duplicado.',1;
    END;

    UPDATE [access].AccessRequest
    SET Status=IIF(@Approve=1,'APPROVED','REJECTED'),
        ApprovedBy=ORIGINAL_LOGIN(),
        ApprovedAt=SYSUTCDATETIME(),
        ApprovalComment=@Comment
    WHERE RequestId=@RequestId AND Status='PENDING';
    IF @@ROWCOUNT=0
    BEGIN
        ROLLBACK;
        THROW 51314,'La solicitud no está pendiente.',1;
    END;
    COMMIT;

    DECLARE @Action nvarchar(50)=IIF(@Approve=1,N'Confirmar',N'Rechazar');
    DECLARE @AuditDetail nvarchar(max)=CONCAT(
        N'Solicitud #',@RequestId,N' · doble check del operador · ',@Comment);
    EXEC [access].usp_Audit_Write N'Solicitudes',@Action,NULL,NULL,1,@AuditDetail;
END;
GO

CREATE OR ALTER PROCEDURE [access].usp_AccessRequest_MarkExecuted
    @RequestId bigint,
    @Success bit,
    @Detail nvarchar(2000)
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    -- SqlAccessAdmin.SelfConfirmationExecution
    IF IS_SRVROLEMEMBER(N'sysadmin')<>1
       AND NOT EXISTS
       (
           SELECT 1
           FROM [access].AuthorizedPrincipal
           WHERE Principal=[access].ufn_App_Principal()
             AND Active=1
             AND RoleName IN('Administrator','Operator')
       )
        THROW 51301,'Se requiere un usuario Administrator u Operator activo.',1;

    UPDATE [access].AccessRequest
    SET Status=IIF(@Success=1,'EXECUTED','FAILED'),
        ExecutedBy=ORIGINAL_LOGIN(),
        ExecutedAt=SYSUTCDATETIME()
    WHERE RequestId=@RequestId AND Status='APPROVED';
    IF @@ROWCOUNT=0
        THROW 51315,'La solicitud no está confirmada o ya fue procesada.',1;

    EXEC [access].usp_Audit_Write N'Solicitudes',N'Ejecutar',NULL,NULL,@Success,@Detail;
END;
GO

GRANT EXECUTE ON [access].usp_AccessRequest_Approve TO [SqlAccessAdmin_Users];
GRANT EXECUTE ON [access].usp_AccessRequest_MarkExecuted TO [SqlAccessAdmin_Users];
GO

PRINT N'Autoconfirmación y ejecución por Administrator/Operator habilitadas.';
GO

