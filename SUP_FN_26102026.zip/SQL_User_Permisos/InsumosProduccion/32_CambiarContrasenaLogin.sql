USE [adminDB];
GO
IF OBJECT_ID(N'access.AppTimeConvention',N'U') IS NOT NULL THROW 51856,'La base ya usa hora de Guatemala. No reaplique migraciones históricas; use 36, 33 actualizado y 99.',1;
GO
SET NOCOUNT ON;
SET XACT_ABORT ON;
/* Aplicar después de 31 con los clientes detenidos y terminar con 99.
   Extiende los contratos existentes y conserva sus guardas de autorización múltiple.
   No conecta a destinos ni cambia contraseñas al instalar la migración. */
DECLARE @Modules table(Id int IDENTITY(1,1),Name sysname,Definition nvarchar(max));
INSERT @Modules(Name,Definition)
 SELECT p.name,REPLACE(m.definition,NCHAR(13),N'')
 FROM sys.procedures p JOIN sys.sql_modules m ON m.object_id=p.object_id
 WHERE p.schema_id=SCHEMA_ID(N'access') AND p.name IN
 (N'usp_AccessRequest_AuthenticationValidate',N'usp_AccessRequest_Create',N'usp_AccessRequest_TargetPolicyValidate',N'usp_AccessRequest_List');
IF (SELECT COUNT(*) FROM @Modules)<>4
 OR EXISTS(SELECT 1 FROM @Modules WHERE Definition IS NULL OR Definition NOT LIKE N'%SqlAccessAdmin.MultiRoleGuard.v1%')
 OR OBJECT_ID(N'[access].usp_AuthorizedUser_AvailablePrincipals',N'P') IS NULL
 THROW 51610,'Ejecute primero 27, 29 actualizado, 30 y 31. No se modificó el contrato de contraseñas.',1;
IF NOT EXISTS(SELECT 1 FROM @Modules WHERE Name=N'usp_AccessRequest_Create'
 AND Definition LIKE N'%SqlAccessAdmin.ScopedPolicyTargets%' AND Definition LIKE N'%@VerifiedTicket%')
 THROW 51610,'Falta el contrato actualizado de solicitudes y tickets del script 27.',1;

DECLARE @Index int=1,@Name sysname,@Definition nvarchar(max),@Old nvarchar(max),@New nvarchar(max),
 @NormalizedHeader nvarchar(512),@Message nvarchar(2048);
BEGIN TRY
 BEGIN TRANSACTION;
 WHILE @Index<=4
 BEGIN
  SELECT @Name=Name,@Definition=Definition FROM @Modules WHERE Id=@Index;
  IF @Definition NOT LIKE N'%SqlAccessAdmin.LoginPasswordChange.v1%'
  BEGIN
   IF @Name=N'usp_AccessRequest_AuthenticationValidate'
   BEGIN
    SET @Old=N'IF @OperationCode NOT IN(''CREATE_SQL_LOGIN'',''CREATE_WINDOWS_LOGIN'',''CLONE_PERMISSIONS'') OR @OperationCode IS NULL RETURN;';
    SET @New=N'-- SqlAccessAdmin.LoginPasswordChange.v1
 IF @OperationCode NOT IN(''CREATE_SQL_LOGIN'',''CREATE_WINDOWS_LOGIN'',''CLONE_PERMISSIONS'',''CHANGE_LOGIN_PASSWORD'') OR @OperationCode IS NULL RETURN;
 IF @OperationCode=''CHANGE_LOGIN_PASSWORD'' AND ISNULL(@AuthenticationType,'''') COLLATE Latin1_General_100_BIN2<>''SQL''
  THROW 51611,''Cambiar contraseña requiere autenticación SQL.'',1;
 IF @PasswordPolicy IS NULL OR @PasswordExpiration IS NULL OR @MustChangePassword IS NULL
  THROW 51611,''Indique todas las opciones de contraseña.'',1;';
   END
   ELSE IF @Name=N'usp_AccessRequest_Create'
   BEGIN
    SET @Old=N'EXEC [access].usp_AccessRequest_AuthenticationValidate @OperationCode,@TargetPrincipal,@AuthenticationType,';
    SET @New=N'-- SqlAccessAdmin.LoginPasswordChange.v1
 IF @OperationCode=''CHANGE_LOGIN_PASSWORD'' AND
  (@SourcePrincipal IS NOT NULL OR @PermissionAction IS NOT NULL OR @PermissionName IS NOT NULL
   OR @ScopeType IS NOT NULL OR @Securable IS NOT NULL OR @RoleName IS NOT NULL OR @CopyPlanJson IS NOT NULL)
  THROW 51612,''El cambio de contraseña no admite copia, roles ni permisos adicionales.'',1;
 EXEC [access].usp_AccessRequest_AuthenticationValidate @OperationCode,@TargetPrincipal,@AuthenticationType,';
   END
   ELSE IF @Name=N'usp_AccessRequest_TargetPolicyValidate'
   BEGIN
    SET @Old=N'SET NOCOUNT ON;';
    SET @New=N'SET NOCOUNT ON;
 -- SqlAccessAdmin.LoginPasswordChange.v1
 IF @OperationCode=''CHANGE_LOGIN_PASSWORD'' AND
  ((SELECT COUNT(*) FROM @Targets)<>1 OR EXISTS(SELECT 1 FROM @Targets WHERE DatabaseName<>N''master'')
   OR EXISTS(SELECT 1 FROM @Steps) OR @PermissionAction IS NOT NULL OR @PermissionName IS NOT NULL
   OR @ScopeType IS NOT NULL OR @RoleName IS NOT NULL)
  THROW 51613,''El cambio de contraseña requiere un único destino master y no admite pasos internos.'',1;';
   END
   ELSE IF @Name=N'usp_AccessRequest_List'
   BEGIN
    SET @Old=N'r.CopyPlanJson,r.RequestedBy';
    SET @New=N'/* SqlAccessAdmin.LoginPasswordChange.v1 */ r.PasswordPolicy,r.PasswordExpiration,r.MustChangePassword,
  r.CopyPlanJson,r.RequestedBy';
   END;
   IF CHARINDEX(@Old,@Definition)=0
    THROW 51614,'No se reconoce un contrato anterior. La migración se revierte; solicite revisión del DBA.',1;
   SET @Definition=REPLACE(@Definition,@Old,@New);
   -- SqlAccessAdmin.LoginPasswordChange.HeaderStart
   -- SQL Server puede conservar CREATE   PROCEDURE, tabulaciones y saltos.
   -- Normalizar solo una copia del encabezado; conservar el cuerpo y sus literales.
   WHILE LEFT(@Definition,1) IN(N' ',NCHAR(9),NCHAR(10),NCHAR(13))
    SET @Definition=SUBSTRING(@Definition,2,LEN(@Definition));
   SET @NormalizedHeader=UPPER(LEFT(@Definition,512));
   SET @NormalizedHeader=REPLACE(REPLACE(REPLACE(@NormalizedHeader,NCHAR(9),N' '),NCHAR(10),N' '),NCHAR(13),N' ');
   WHILE CHARINDEX(N'  ',@NormalizedHeader)>0 SET @NormalizedHeader=REPLACE(@NormalizedHeader,N'  ',N' ');
   IF @NormalizedHeader LIKE N'CREATE PROCEDURE %' OR @NormalizedHeader LIKE N'CREATE PROC %'
    SET @Definition=STUFF(@Definition,1,6,N'ALTER');
   ELSE IF @NormalizedHeader LIKE N'CREATE OR ALTER PROCEDURE %' OR @NormalizedHeader LIKE N'CREATE OR ALTER PROC %'
    SET @Definition=SUBSTRING(@Definition,CHARINDEX(N'ALTER',UPPER(@Definition)),LEN(@Definition));
   ELSE IF @NormalizedHeader NOT LIKE N'ALTER PROCEDURE %' AND @NormalizedHeader NOT LIKE N'ALTER PROC %'
   BEGIN
    SET @Message=CONCAT(N'No se reconoce el encabezado de [access].',QUOTENAME(@Name),N'. La migración se revierte.');
    THROW 51614,@Message,1;
   END;
   -- SqlAccessAdmin.LoginPasswordChange.HeaderEnd
   EXEC sys.sp_executesql @Definition;
  END;
  SET @Index+=1;
 END;
 IF NOT EXISTS(SELECT 1 FROM [access].SecurityPolicyOperation WHERE OperationCode='CHANGE_LOGIN_PASSWORD')
  INSERT [access].SecurityPolicyOperation(OperationCode,DisplayName,Enabled,RequiresApproval,RiskLevel,Description)
   VALUES('CHANGE_LOGIN_PASSWORD',N'Cambiar contraseña del login SQL',1,1,'HIGH',
    N'Requiere ticket activo, contraseña cifrada, confirmación y ejecución. Permite exigir cambio en el próximo inicio de sesión.');
 -- Una reinstalación conserva Enabled y los bloqueos configurados por el administrador.
 UPDATE [access].SecurityPolicyOperation SET RequiresApproval=1,RiskLevel='HIGH'
  WHERE OperationCode='CHANGE_LOGIN_PASSWORD';
 IF EXISTS(SELECT 1 FROM sys.procedures p JOIN sys.sql_modules m ON m.object_id=p.object_id
  JOIN @Modules original ON original.Name=p.name WHERE p.schema_id=SCHEMA_ID(N'access')
  AND (m.definition NOT LIKE N'%SqlAccessAdmin.LoginPasswordChange.v1%'
   OR m.definition NOT LIKE N'%SqlAccessAdmin.MultiRoleGuard.v1%'))
  THROW 51614,'No se conservaron todas las validaciones. La migración se revierte.',1;
 COMMIT TRANSACTION;
 PRINT N'Cambio de contraseña instalado. Ejecute 99_ValidarInstalacion.sql y despliegue el cliente compatible antes de reiniciar.';
END TRY
BEGIN CATCH
 IF XACT_STATE()<>0 ROLLBACK TRANSACTION;
 THROW;
END CATCH;
GO
