using SqlAccessAdmin.Data;
using SqlAccessAdmin.Models;

if(args.Length==0)
{
    Console.Error.WriteLine("Uso: SecurityMonitoringWorker <pivote> [adminDB] [--once] [--expire-only] [--trust-certificate]");
    return 2;
}
var server=args[0];var database=args.Skip(1).FirstOrDefault(a=>!a.StartsWith("--",StringComparison.Ordinal))??"adminDB";
using var lifetime=new CancellationTokenSource();
Console.CancelKeyPress+=(_,e)=>{e.Cancel=true;lifetime.Cancel();};
try
{
    // Identidad Windows de servicio registrada en la aplicación. No secretos en argumentos.
    var gateway=new AdminDbGateway(new(server,"",database,true,null,null,true,args.Contains("--trust-certificate")));
    var direct=new DirectSqlServerService(gateway);
    var session=await gateway.LoginAsync(lifetime.Token);
    var expiryOnly=args.Contains("--expire-only");
    if(!expiryOnly&&!session.CanReviewRequests)throw new UnauthorizedAccessException("La consulta de metadatos exige Administrador o AprobadorEjecutor. Use --expire-only para una identidad de solo lectura.");
    do
    {
        try
        {
            if(!expiryOnly)
                foreach(var warning in await direct.CollectPrincipalMetadataAsync(lifetime.Token))Console.Error.WriteLine(warning);
            var summary=await gateway.RefreshSecuritySummaryAsync(lifetime.Token);
            Console.WriteLine($"{SqlAccessAdmin.Infrastructure.AppTime.Now:yyyy-MM-dd HH:mm:ss}: vencimientos={summary.ExpiredAccesses}; alertas contraseñas={summary.PasswordAlerts}; por conciliar={summary.UnresolvedEvents}");
        }
        catch(OperationCanceledException){throw;}
        catch(UnauthorizedAccessException){throw;}
        catch(Exception error) when(!args.Contains("--once"))
        {
            Console.Error.WriteLine($"{SqlAccessAdmin.Infrastructure.AppTime.Now:yyyy-MM-dd HH:mm:ss}: ciclo no actualizado; reintento en 60 segundos. "+
                (error is Microsoft.Data.SqlClient.SqlException sql?$"SQL {sql.Number}. Revise conexión e instalación.":error.Message));
        }
        if(args.Contains("--once"))break;
        await Task.Delay(TimeSpan.FromSeconds(60),lifetime.Token);
    }while(!lifetime.IsCancellationRequested);
    return 0;
}
catch(OperationCanceledException){return 0;}
catch(Exception error){Console.Error.WriteLine(error is Microsoft.Data.SqlClient.SqlException?"SQL Server rechazó la consulta de metadatos. Revise conexión, 36, contrato 33 v4 y 99 en el pivote y permisos de la identidad.":error.Message);return 1;}
