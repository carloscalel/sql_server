﻿# Reportes

Los módulos centrales **Cambios de accesos** y **Cambios de contraseña** se encuentran en **Seguridad y Auditoría**. Administrador y Auditor pueden consultarlos/exportarlos sin obtener credenciales de destinos. Contraseñas ofrece ranking e historial con eventos por conciliar. Requieren 33 v3/99 solo en el pivote. Separan registro de la app y última fecha externa observada; el ranking cuenta solo contraseñas confirmadas de la app; vea [Monitoreo de seguridad](MonitoreoSeguridad.md). Los requisitos de conexiones directas descritos a continuación corresponden a los tres reportes originales.

El módulo está en el menú lateral, justo debajo de **Administrar accesos**. Pulse **Reportes** o su flecha para desplegar el árbol. Conserva el menú oscuro, permite desplazarse si faltara espacio y resalta el reporte abierto.

## Uso

1. Abra una de las opciones del árbol.
2. Seleccione servidor. En **Permisos por usuario**, elija un login SQL/Windows y marque las bases que desea revisar; sin marcas se consulta solo la instancia. En **Catálogo de roles**, elija una base. Los selectores permiten localizar nombres escribiendo su inicio.
3. Pulse **Consultar**. Use **Buscar** para filtrar los resultados sin volver a consultar SQL Server. Las columnas permiten ordenar.
4. Use el filtro adicional de acción, tipo de rol o estado de credenciales. Vacíe la búsqueda y restaure el filtro para recuperar todas las filas.
5. **Actualizar catálogos** vuelve a cargar los servidores y limpia el contexto. **Consultar** repite la consulta del contexto seleccionado. **Cancelar consulta** descarta una consulta en curso.

Cambiar servidor, base o usuario limpia los resultados previos. Navegar a otro módulo, cerrar la aplicación o perder autorización cancela el trabajo pendiente. Las respuestas tardías no se publican en otro contexto.

## Exportar PDF, CSV y Excel

Después de **Consultar**, pulse **PDF**, **CSV** o **Excel** junto a «Exportar» y seleccione el nombre y la ubicación en **Guardar como**. La exportación utiliza los resultados filtrados y el orden visible al iniciarse; no vuelve a consultar SQL Server. Incluye servidor, base, usuario cuando corresponde, fecha de la consulta en formato `yyyy-MM-dd HH:mm:ss` sin zona horaria, filtros y alcance del reporte.

En **Permisos por usuario**, cada botón abre primero **Contenido de la exportación**. Elija **Reporte completo** (predeterminado) o **Solo la pestaña activa**, cuyo nombre aparece en el selector, y pulse **Continuar** para ir a **Guardar como**. Cancelar cualquiera de los dos pasos conserva los resultados y no genera archivos. El alcance elegido queda indicado en los filtros del documento y la exportación de una sola pestaña añade su nombre al archivo sugerido.

El reporte completo integra **Roles asignados**, **Permisos directos** y **Bases revisadas** en el PDF; Excel guarda esos bloques en tres hojas independientes del mismo libro. CSV utiliza un único archivo rectangular, con una columna **Sección** para distinguir los bloques y facilitar su filtrado. Al elegir la pestaña activa, cualquiera de los tres formatos contiene únicamente ese bloque (una sola hoja en Excel). Las secciones vacías se identifican sin inventar datos.

- **PDF:** documento A4 horizontal con tablas, filas alternadas y numeración de páginas. Las secciones aparecen seguidas con un solo encabezado del reporte; se generan páginas adicionales únicamente cuando el contenido lo requiere, repitiendo los encabezados de las tablas que continúan.
- **Excel (.xlsx):** libro nativo, sin requerir Microsoft Excel instalado. Incluye una hoja por sección, filtros de columna y encabezados inmovilizados. Fechas y días se conservan como valores de fecha y números. Las fechas desconocidas se identifican explícitamente.
- **CSV:** tabla UTF-8 con BOM, delimitada por comas y compatible con campos entre comillas, comillas internas y saltos de línea. La columna **Sección** distingue los bloques del reporte y todas las filas mantienen las mismas columnas. Los valores que podrían interpretarse como fórmulas en una hoja de cálculo se prefijan con un apóstrofo.

**Permisos por usuario** exporta roles asignados y permisos directos. **Catálogo de roles** exporta solo el catálogo por defecto. Para añadir usuarios, active **Incluir miembros en la exportación (opcional)** y marque uno o varios roles en la columna **Exportar miembros**. El detalle incluirá exclusivamente los miembros de esos roles, independientemente de la fila que esté seleccionada para consulta. El encabezado identifica los roles elegidos. Si activa la opción sin marcar roles, los botones de exportación permanecen deshabilitados hasta que marque alguno o desactive la opción. Los roles sin miembros permanecen en el catálogo con contador cero. **Inactividad de credenciales** exporta las cuentas filtradas, sus estados y fechas de contraseña.

La selección de miembros corresponde a los roles visibles: aplicar filtros quita las marcas de los roles que quedan ocultos. Quitar un filtro no vuelve a marcarlos automáticamente. Desactivar la opción o realizar una nueva consulta limpia las marcas. Estas opciones se aplican por igual a PDF, CSV y Excel.

Una consulta vacía también puede exportarse; el documento identifica las secciones sin filas. Los botones se deshabilitan antes de consultar y durante otra operación. Puede cancelar una exportación; cerrar el diálogo de guardado no altera los resultados. Los errores se muestran en pantalla y permiten volver a intentarlo. La generación utiliza un archivo temporal y sustituye el destino solo al completarse para conservar un archivo previo si hay errores.

## Permisos y Accesos

### Permisos por usuario

El selector muestra logins reales de la instancia de tipo `SQL_LOGIN` o `WINDOWS_LOGIN`, incluidos los que tienen privilegios elevados y no tienen un usuario mapeado en una base. Excluye `dbo`, `guest`, `INFORMATION_SCHEMA`, `sys`, grupos, certificados y cuentas internas cuyo nombre comienza por `##`. También excluye las cuentas integradas con prefijos `NT AUTHORITY\` y `NT SERVICE\`, sin distinguir mayúsculas; estas cuentas pueden ser de tipo `WINDOWS_LOGIN`, por lo que no basta con filtrar solo por tipo. La exclusión se aplica tanto en la consulta del catálogo como al cargar el selector.

Abra **Login SQL o Windows**, igual que el selector de bases, para acceder a **Buscar login…** y a la lista de usuarios. Cerrado, muestra únicamente el login seleccionado o «Seleccione un login». La búsqueda filtra por cualquier parte del nombre, ignora mayúsculas y espacios al principio o al final y muestra el número de coincidencias, sin volver a consultar SQL Server. Una selección que sigue coincidiendo se conserva; si deja de coincidir, se limpia junto con el reporte anterior y se cancela cualquier consulta pendiente de ese login. Borrar el texto restaura el catálogo admitido sin elegir un usuario automáticamente. Cambiar servidor o actualizar los catálogos reinicia la búsqueda.

Abra **Bases de datos (opcional)** para marcar una o varias bases. Puede buscar por nombre, **Marcar visibles** o **Quitar marcas**. La búsqueda de bases conserva las selecciones realizadas fuera del filtro. Sin marcas, el reporte indica **Solo instancia**. El login se elige independientemente de las bases; el servicio resuelve su usuario en cada una mediante el SID, incluso cuando tiene otro nombre.

Presenta tres pestañas:

- **Roles asignados:** roles de instancia y de las bases seleccionadas, con nivel, base, usuario, tipo y asignación directa/heredada. El rol implícito `public` se omite en pantalla y en las exportaciones. `sysadmin` aparece a nivel de instancia con una descripción de su control total. También se consulta `IS_SRVROLEMEMBER` para añadir `sysadmin` cuando SQL Server lo reconoce y no figura en las rutas de membresía catalogadas. Las rutas múltiples y los ciclos no duplican roles dentro de un contexto.
- **Permisos directos:** permisos registrados directamente para el login en la instancia y para su usuario en cada base. Identifica nivel, base y usuario. Incluye permisos de servidor, sobre otros logins/roles y endpoints, además de base, esquema, objetos y columnas. Conserva `GRANT WITH GRANT OPTION` y excepciones `REVOKE`; no los transforma en concesiones ordinarias. La columna **Origen / Estado** indica «Asignación directa» para un login sin `sysadmin` detectado. Si se detecta ese rol de instancia (directo o heredado), conserva todas las filas y marca las concesiones como «Redundante (Cubierto por Sysadmin)» y los registros `DENY` o `REVOKE` como «Sin efecto (Sysadmin)». Esta clasificación no atribuye acceso efectivo a los demás roles.
- **Bases revisadas:** usuario mapeado y resultado por cada base elegida. Identifica si el login es propietario o tiene control mediante `sysadmin`, aunque no exista un usuario mapeado. La ausencia de mapeo no se interpreta automáticamente como falta de acceso.

PDF, CSV y Excel conservan los contextos y respetan el alcance elegido en el selector de exportación. El reporte completo siempre incluye **Bases revisadas**; si se consulta solo la instancia, esa sección no tiene filas. Cambiar login o selección de bases limpia el reporte anterior. Si una base falla o no puede consultarse, se muestra su nombre en el error y no se publica ni exporta un reporte parcial.

Las celdas contextuales sin dato aplicable (base de una fila de instancia, esquema, objeto, tipo y columna) muestran `—` tanto en pantalla como en las exportaciones; los valores originales se conservan para búsqueda y ordenación. El texto de ayuda de la selección de bases queda solo en la interfaz y se omite de las exportaciones de permisos. El PDF presenta las secciones de forma continua.

No expande cada rol en miles de objetos ni enumera objetos sin permisos directos. Tener una tabla de permisos directos vacía no significa carecer de acceso: los roles pueden concederlo. El reporte muestra configuración de seguridad; no calcula todo el acceso efectivo ni enumera grupos Windows/Active Directory. La resolución de `IS_SRVROLEMEMBER` para cuentas Windows depende de la información que SQL Server pueda obtener. Las descripciones de roles fijos explican su alcance general.

### Catálogo de roles

Consulta dinámicamente los roles de la base, incluso los que no tienen usuarios. Muestra tipo y descripción funcional. La columna **Usuarios** y el campo **Cantidad de usuarios** de las exportaciones aparecen únicamente al activar **Incluir miembros en la exportación**. Seleccione una fila para consultar sus usuarios y su tipo de login. La búsqueda también encuentra roles por el nombre de esos usuarios.

El detalle y el conteo consideran solo usuarios de base vinculados por SID a un `SQL_LOGIN` o `WINDOWS_LOGIN` existente en la instancia. Se excluyen `dbo`, `guest`, `INFORMATION_SCHEMA` y `sys`, así como grupos, roles anidados, usuarios contenidos, cuentas sin login y usuarios asociados a certificados o claves. El nombre mostrado sigue siendo el usuario de base, aunque el login asociado tenga otro nombre; el tipo mostrado corresponde al login.

Las membresías reportadas son directas. `public` muestra las cuentas admitidas como usuarios implícitos, ya que su membresía no se almacena en `sys.database_role_members`. No se calcula un total efectivo a través de roles anidados, grupos o propiedad de la base. La descripción de un rol personalizado no atribuye privilegios a partir de su nombre.

## Seguridad y Auditoría

### Inactividad de credenciales

Consulta `sys.server_principals` de la instancia seleccionada e incluye todos los `SQL_LOGIN` y `WINDOWS_LOGIN`, tengan o no operaciones en la app. Se excluyen grupos Windows, cuentas internas `##`, `NT ` y `NT SERVICE`. Incluye cuentas habilitadas y deshabilitadas y contraseñas recientes.

La fecha de contraseña SQL se obtiene de `LOGINPROPERTY(name,'PasswordLastSetTime')`. Las fechas nulas, anteriores a la creación del login (incluido el valor 1900) o futuras se muestran como **Fecha no disponible**, sin calcular antigüedad. Las contraseñas Windows son administradas por Windows/AD: SQL Server no proporciona su fecha de cambio.

El cliente complementa la fecha del servidor con el último cambio de contraseña **confirmado** por la aplicación para el mismo servidor y la misma identidad de cuenta (SID), posterior a su creación. Si ambas fechas existen, usa la más reciente. Un cambio confirmado hoy muestra **0 días**. La columna **Fecha obtenida de** identifica el origen. Requiere aplicar `37_FechasContrasenaConfirmadas.sql` después de 33 y 36; no modifica cuentas ni contraseñas.

La modificación del login (`modify_date`) y sus días transcurridos se muestran en columnas independientes: otros cambios también actualizan esa fecha, por lo que no sustituye una fecha de contraseña desconocida. Las fechas se presentan en hora de Guatemala. Los días son períodos completos de 24 horas. Los filtros permiten revisar todas las cuentas, habilitadas/deshabilitadas, tipo de login, contraseña de más de 45 días completos, hasta 45 días o fecha SQL no disponible.

El título conserva el nombre funcional solicitado, pero este es un indicador de **antigüedad de contraseña**, no de último uso. No demuestra que una cuenta esté abandonada y no consulta ni infiere la fecha del último inicio de sesión. Nunca recupera contraseñas ni hashes.

La nota técnica sobre el cálculo de antigüedad queda solo en la interfaz; se omite en las exportaciones PDF, CSV y Excel.

## Autorización y preparación

El módulo reutiliza las conexiones directas existentes. Está disponible para **Administrador, Operador y AprobadorEjecutor**, incluidas sus combinaciones. El servicio revalida la autorización antes y después de consultar un destino. **Auditor por sí solo** conserva su acceso actual a resumen y auditoría: el módulo no amplía sus permisos para obtener credenciales compartidas de destinos. El nombre de la categoría «Seguridad y Auditoría» no cambia esta autorización.

No requiere nuevas tablas, procedimientos ni migraciones de `adminDB`. No instala permisos ni cambia accesos de los destinos.

La cuenta de conexión necesita:

- Acceso a la base seleccionada. El selector muestra bases en línea accesibles y visibles con esa conexión.
- `VIEW DEFINITION` en la base para los reportes de usuarios y roles; incluye permisos superiores que lo impliquen. El reporte se detiene si esa comprobación falla.
- Visibilidad de logins de instancia para credenciales y para identificar los usuarios del catálogo de roles: la comprobación acepta `VIEW ANY DEFINITION`, `ALTER ANY LOGIN` o `VIEW ANY SECURITY DEFINITION`, según la versión y los permisos efectivos. Solicite al DBA preparar la visibilidad apropiada; el cliente no concede esos permisos.
- Para los roles y permisos de instancia de **Permisos por usuario**, se requiere `VIEW ANY DEFINITION` o `VIEW ANY SECURITY DEFINITION` efectivo, según la versión. La visibilidad de logins por sí sola no sustituye la lectura del catálogo completo de seguridad de instancia.

Las denegaciones particulares y las restricciones de visibilidad del motor siguen aplicándose. El reporte describe el catálogo que expone SQL Server a la cuenta técnica.

## Implementación y comprobaciones

- `Views/ReportsView.xaml`: pantalla compartida y tablas de solo lectura.
- `ViewModels/ReportsViewModel.cs`: selección de contexto, filtros, estados y cancelación.
- `Data/IReportsDataSource.cs`: contrato que permite comprobar la interfaz sin infraestructura real.
- `Data/ReportsService.cs`: consultas directas parametrizadas, timeout por destino y revalidación de sesión.
- `Data/ReportsSql.cs`: consultas T-SQL de solo lectura y controles de visibilidad.
- `Models/ReportModels.cs`: resultados tipados y descripciones funcionales de roles.
- `Models/ReportExportModels.cs`: instantánea de los resultados y contexto exportados.
- `Data/ReportExportService.cs`: generación local de PDF, CSV y XLSX, con guardado temporal.
- `Infrastructure/ReportSaveDialog.cs`: diálogo de destino de archivo, separado para las comprobaciones.

La exportación incorpora las dependencias NuGet `ClosedXML` 0.105.0 y `PDFsharp-MigraDoc-WPF` 6.2.4. La publicación del cliente debe distribuir su carpeta completa con las nuevas dependencias; no se requieren cambios de base de datos.

Desde la raíz:

```powershell
dotnet build .\SQLUserPermisos.sln
dotnet run --project .\tests\ReportsChecks -- .\artifacts\report-previews
dotnet run --project .\tests\ReportsChecks -- .\artifacts\report-previews --sql-smoke localhost
```

El último comando ejecuta consultas de solo lectura en `master` con la identidad Windows del proceso de prueba. Las vistas previas usan datos simulados, no datos de producción. Consulte el [detalle de comprobaciones](../tests/ReportsChecks/README.md).

## Referencias del motor

- [LOGINPROPERTY: PasswordLastSetTime y permisos](https://learn.microsoft.com/en-us/sql/t-sql/functions/loginproperty-transact-sql).
- [sys.sql_logins y visibilidad de metadatos](https://learn.microsoft.com/en-us/sql/relational-databases/system-catalog-views/sys-sql-logins-transact-sql).
- [Roles de base de datos](https://learn.microsoft.com/en-us/sql/relational-databases/security/authentication-access/database-level-roles).
- [Permisos directos y excepciones de columna](https://learn.microsoft.com/en-us/sql/relational-databases/system-catalog-views/sys-database-permissions-transact-sql).
