# Archivo histórico de monitoreo v2

Estos archivos documentan la implementación anterior de captura DDL/SQL Server Audit. Son texto histórico, no instaladores ni pruebas vigentes. El contrato v3 registra operaciones de la app en el pivote y compara fechas de metadatos, sin instalar componentes en destinos.

Guía vigente: [MonitoreoSeguridad](../../MonitoreoSeguridad.md). No ejecutar estos insumos como despliegue actual.
