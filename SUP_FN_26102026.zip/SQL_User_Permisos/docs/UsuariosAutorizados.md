# Acceso y mantenimiento de usuarios autorizados

El acceso a SQL Server permite establecer la conexión, pero la entrada a SQL Access Admin exige un registro en `adminDB.access.AuthorizedPrincipal` con `Active=1` y al menos una membresía válida en `access.AuthorizedPrincipalRole`. Un sysadmin no registrado, un registro inactivo o un usuario sin roles no puede ingresar.

## Identidad Windows

Se utiliza el nombre canónico que SQL Server reconoce, como `DOMINIO\usuario` o `EQUIPO\usuario`. `access.ufn_App_Principal()` obtiene el SID de la conexión original desde `sys.dm_exec_sessions.original_security_id` y resuelve su nombre mediante `SUSER_SNAME(SID)`. Esto admite `CALEL\josep` aunque `ORIGINAL_LOGIN()` devuelva su alias MicrosoftAccount, sin cambiar el registro al correo. El SID original evita autorizar a una identidad suplantada por EXECUTE AS. Consulte la documentación de [la identidad original de sesión](https://learn.microsoft.com/en-us/sql/relational-databases/system-dynamic-management-views/sys-dm-exec-sessions-transact-sql) y [SUSER_SNAME](https://learn.microsoft.com/en-us/sql/t-sql/functions/suser-sname-transact-sql).

La función da prioridad al registro canónico, incluso si está inactivo: un correo alternativo activo no elude su baja. Si no existe un registro canónico, se puede conservar un registro explícito del nombre original. La identidad no se toma del equipo cliente ni de datos enviados por la aplicación. Cada usuario Windows debe registrarse individualmente; pertenecer a un grupo con conexión SQL no sustituye ese registro. Para SQL authentication se conserva el nombre del login reconocido por el servidor.

## Cuatro roles y permisos acumulables

| Rol mostrado | Código almacenado | Funciones |
| --- | --- | --- |
| Administrador | `Administrator` | Usuarios autorizados, roles, servidores, políticas, creación, confirmación, rechazo, ejecución y auditoría. |
| Operador | `Operator` | Crea solicitudes y consulta su estado; no confirma, rechaza ni ejecuta. |
| AprobadorEjecutor | `ApproverExecutor` | Confirma, rechaza y ejecuta solicitudes; no las crea. |
| Auditor | `Auditor` | Consulta resumen y auditoría; no modifica configuración ni gestiona solicitudes. |

Cada usuario puede tener uno o varios roles. **Operador + AprobadorEjecutor** permite completar el ciclo de solicitudes. **Auditor + Operador** permite consultar auditoría y crear solicitudes. **Administrador** incluye todas las funciones sin necesitar roles adicionales. El resumen está disponible para todos los usuarios activos; la auditoría requiere Auditor o Administrador.

Las membresías de AuthorizedPrincipalRole son la fuente de autorización. AuthorizedPrincipal.RoleName se conserva como rol principal de compatibilidad y no representa todos los permisos del usuario. El cliente, los comandos y los SP separan CREATE_REQUEST de REVIEW_REQUEST. Las llamadas directas a los SP también exigen la función permitida; los roles técnicos SQL y sysadmin no reemplazan las membresías de aplicación.

El cliente exige `AuthorizationVersion=2` y la lista JSON Roles en access.usp_App_LoginContext. El contrato anterior, resultados incompletos o roles vacíos, desconocidos o duplicados se rechazan antes de abrir la ventana principal. La autorización se consulta antes de cada operación contra adminDB. Revocar el acceso o cambiar cualquier membresía bloquea la sesión y exige cerrar e iniciar nuevamente. Esta comprobación no revierte operaciones que ya estén en curso.

## Uso del módulo

Solo un usuario activo con Administrador puede mantener **Usuarios autorizados**. **Agregar usuario** muestra un listado de logins Windows individuales y SQL existentes y habilitados en la instancia donde está `adminDB`. No permite escribir nombres libres ni elegir manualmente el tipo: se obtiene de la cuenta seleccionada. Excluye logins internos `##`, grupos Windows y cuentas ya registradas, incluso inactivas; estas últimas se modifican o reactivan desde la tabla. El rol inicial es Operador; se pueden seleccionar una o varias casillas de roles, estado y notas. El tipo heredado BOOTSTRAP se conserva en registros existentes.

**Guardar cambios** permanece deshabilitado hasta seleccionar una cuenta. El cliente vuelve a consultar su disponibilidad y el SP valida su existencia, estado habilitado y tipo al agregarla. Si no hay cuentas, el módulo indica que el DBA debe registrar primero un login individual en la instancia; no enumera Active Directory ni crea cuentas. Un error de catálogo bloquea las altas y permite seguir editando los registros existentes. **Actualizar** vuelve a consultar el listado.

El catálogo exige visibilidad de los metadatos de logins para no mostrar un listado parcial. El DBA puede conceder `VIEW ANY DEFINITION` al login del administrador en la instancia de `adminDB`; también admite `VIEW ANY SECURITY DEFINITION` en SQL Server 2022 o posterior, o un permiso existente `ALTER ANY LOGIN`. El script no concede estos permisos automáticamente. Consulte [la visibilidad de metadatos de SQL Server](https://learn.microsoft.com/en-us/sql/relational-databases/security/metadata-visibility-configuration) antes de elegir la concesión. Un administrador que ya es sysadmin tiene esta visibilidad.

Seleccione un registro para modificar roles, notas o estado. La identidad y su tipo son inmutables después del alta. **Guardar cambios** confirma el principal, todos los roles y el estado antes de persistirlos. Se exige al menos un rol. **Quitar acceso** desactiva el registro sin eliminarlo ni borrar sus membresías; para reactivarlo, marque **Acceso activo a la aplicación** y guarde. Se advierten los cambios pendientes al actualizar, cambiar de selección, descartar, navegar o cerrar.

Las confirmaciones de este módulo usan una ventana con la tipografía, colores y botones de la aplicación, con acciones explícitas como **Guardar cambios**, **Quitar acceso** y **Descartar cambios**. **Cancelar**, Escape o cerrar la confirmación conserva el formulario. Después de un alta, modificación, baja o reactivación exitosa, la tabla se actualiza sin seleccionar automáticamente al usuario: el panel derecho queda limpio y pide seleccionar un registro o agregar una cuenta. Los errores conservan el borrador para corregirlo o reintentar. Al iniciar otra acción, el formulario vuelve al comienzo. Este ajuste del cliente no requiere otro script SQL.

El SP comprueba el administrador vigente con la identidad de la conexión, sin aceptar un actor suministrado por el cliente. Tiene control de duplicados y concurrencia por RowVersion, protección del último administrador activo y bloqueo de la baja o retirada del rol Administrador propio, incluidos sus alias. Otro administrador debe realizar esos cambios. Un trigger actualiza el RowVersion cuando cambian las membresías, incluso mediante modificaciones directas del DBA. La operación y su auditoría se confirman en una transacción; el [bloqueo de aplicación](https://learn.microsoft.com/en-us/sql/relational-databases/system-stored-procedures/sp-getapplock-transact-sql) serializa los mantenimientos y comprueba errores de adquisición.

El módulo autoriza el uso de la aplicación. No crea cuentas Windows, logins SQL, usuarios de base ni permisos en las instancias administradas. El DBA debe asegurar la conexión a adminDB y la ejecución de los SP mediante los roles técnicos existentes. Cambiar roles de aplicación no concede ni retira los accesos SQL que la cuenta ya tenga.

## Instalación manual

1. Cerrar todas las sesiones de la aplicación, respaldar adminDB y comprobar el nombre canónico con [ComprobarIdentidadWindows.sql](ComprobarIdentidadWindows.sql), que es de solo lectura. Verificar que una identidad válida conserve acceso activo y el rol Administrador.
2. Si sigue pendiente la instalación de tickets, comprobar dbo.sp_VerificarTicketExiste y aplicar **27 actualizado → 28**.
3. Aplicar [29 actualizado](../InsumosProduccion/29_UsuariosAutorizadosAccesoEstricto.sql) si aún falta la identidad canónica, luego [30_RolesMultiplesYSeparacionSolicitudes.sql](../InsumosProduccion/30_RolesMultiplesYSeparacionSolicitudes.sql). Si 29 actualizado ya está completo, continúe con **30 → 31 → 99**. No es necesario cambiar CALEL\josep al correo.
4. Aplicar [31_SeleccionUsuariosAutorizados.sql](../InsumosProduccion/31_SeleccionUsuariosAutorizados.sql) después de 30 y volver a ejecutar 99. Para una instalación con 30 completo, basta **31 → 99**. El script agrega el catálogo y valida que cada alta corresponda a un login existente; conserva roles, concurrencia, auditoría y edición de usuarios anteriores.
5. Desplegar la carpeta completa del cliente actualizado y reiniciar las sesiones. El cliente nuevo rechaza el contrato anterior; los ejecutables antiguos no admiten AuthorizationVersion=2. Retire esas versiones del uso operativo.
6. Administrador y Auditor conservan su rol. Los Operator existentes se migran exclusivamente como Operador y dejan de confirmar o ejecutar. Un Administrador debe añadirles AprobadorEjecutor si necesitan esas funciones. La migración no lo otorga automáticamente; repetir 30 no restaura membresías retiradas.

99 comprueba identidad canónica, membresías múltiples, permisos por función, concurrencia, selección de cuentas existentes y existencia de un administrador activo. La aplicación no ejecuta migraciones. No reaplique 29 después de 30 sin aplicar nuevamente 30: reemplazaría el contrato de roles múltiples. Si reaplica un SP anterior que quite las nuevas comprobaciones, aplique **30 → 31 → 99**.

Si 29 produjo el error 51010 por encabezados CREATE con espacios múltiples o saltos de línea, cargue su versión actualizada. 29 y 30 admiten tabuladores, CREATE, CREATE OR ALTER, ALTER, PROC y PROCEDURE; 30 admite también AS SELECT sin BEGIN y omite comentarios/literales al localizar el cuerpo. Los bloques de actualización se revierten al fallar, pero los lotes anteriores pueden haberse aplicado y admiten repetición. No se colapsan espacios de literales ni se reemplazan contratos de tickets o planes de solicitudes.

## Pruebas de integración

Use cuentas reales separadas; EXECUTE AS no reemplaza el SID de la conexión original. No use un login SQL compartido para probar dos identidades Windows distintas.

| Caso | Resultado esperado |
| --- | --- |
| Usuario con conexión SQL pero sin registro, inactivo o sin roles | Entrada rechazada, incluso con sysadmin. |
| CALEL\josep registrado y MicrosoftAccount como original, mismo SID | Entrada con el nombre Windows registrado. |
| Canónico inactivo y correo alternativo activo | Rechazo: el canónico tiene prioridad. |
| AprobadorEjecutor sin Operador | Confirmación, rechazo y ejecución; creación deshabilitada. |
| Operador sin AprobadorEjecutor | Envío y consulta de estado; confirmación/ejecución deshabilitadas. |
| Operador + AprobadorEjecutor | Ciclo completo; permisos acumulados. |
| Auditor + Operador | Auditoría y creación; confirmación/ejecución bloqueadas. |
| Administrador sin roles adicionales | Todas las funciones. |
| Retirada de uno de varios roles durante una sesión | Bloqueo de sesión en su siguiente operación. |
| Alta duplicada | Rechazo; modificar o reactivar el registro existente. |
| Alta sin selección o con nombre inventado por llamada directa | Guardado bloqueado; el SP exige un login real del tipo indicado. |
| Login deshabilitado, grupo Windows, interno o ya registrado | No aparece en el selector de altas. |
| Login eliminado o deshabilitado tras seleccionarlo | Alta rechazada al guardar; actualizar y seleccionar una cuenta disponible. |
| Catálogo vacío o consulta fallida | Altas bloqueadas con explicación; edición de registros existentes disponible. |
| Baja/reactivación | Active=0 impide entrada y operaciones nuevas; Active=1 restaura los roles conservados. |
| Dos administradores editan el mismo usuario | Segundo guardado con versión antigua rechazado; actualizar antes de reintentar. |
| Baja o retirada del rol Administrador propio | Rechazo; otro administrador debe realizarla. |
| Falla de conexión o auditoría al guardar | Error visible y borrador conservado; una falla transaccional revierte la escritura. |
| Llamada directa a un SP de creación/procesamiento por un rol distinto | Rechazo por su permiso efectivo, aunque tenga roles SQL elevados. |

Revisar tabla, membresías, roles anteriores/nuevos, estado y actor en auditoría. Las pruebas WPF usan datos simulados. La [comprobación SQL de roles múltiples](../tests/SqlChecks/README.md) ejecuta 448 casos del predicado de permisos en variables de tabla y transforma las definiciones instaladas sustituyendo DDL por capturas. Es de solo lectura y no sustituye la migración ni la integración completa.
