# Monitoreo de seguridad y accesos temporales

Contrato vigente: **v4**, 26 de octubre de 2026 (Guatemala).

La aplicación es el canal autorizado para gestionar cambios. El pivote conserva solicitudes, tickets, actores, resultados y seguimiento. En los destinos se ejecutan las operaciones aprobadas y consultas de metadatos; no se instala ninguna base, trigger de captura, SQL Server Audit, cola ni lector firmado.

## Instalación

1. Detener clientes y worker; respaldar `adminDB` del pivote.
2. Sobre una instalación con 32, aplicar **36_HoraLocalGuatemala.sql → 33_MonitoreoSeguridadYTemporales.sql → 99_ValidarInstalacion.sql**. Reaplicar el 33 actualizado si ya tenía v1/v2: el cliente exige v4 para ejecutar cambios. La migración conserva vigencias, alertas e información existente; no convierte evidencia antigua en operaciones confirmadas de la app.
3. Publicar la carpeta completa del cliente y worker; reiniciar sesiones. El cliente ya no usa ScriptDom en ejecución; esa biblioteca queda solo en las pruebas de sintaxis SQL.
4. En cada destino, preparar la cuenta técnica con permisos para las operaciones autorizadas y visibilidad de metadatos: `VIEW ANY DEFINITION` de instancia y `VIEW DEFINITION` en las bases consultadas, o privilegios equivalentes. No ampliar permisos de lectura a CONTROL SERVER. Las consultas del nuevo seguimiento son compatibles con SQL Server 2016+; el pivote conserva los requisitos del resto del proyecto (SQL Server 2017+, compatibilidad 130+).
5. Ejecutar las pruebas funcionales descritas abajo con cuentas de prueba. La app no aplica migraciones automáticamente.

Los antiguos instaladores de captura y el laboratorio previo se conservan como texto histórico en `docs/archive/monitoring-v2`; no forman parte del despliegue vigente. No hay que aplicarlos. Si otro entorno ya instaló infraestructura antigua, esta entrega no la utiliza ni la deshabilita/elimina automáticamente: el DBA debe retirar esa instalación de manera controlada antes de considerar que dejó de tener carga.

## Hora única de Guatemala

El 36 convierte las fechas existentes una sola vez y elimina el sufijo de columnas como ExpiresAtUtc, que pasa a ExpiresAt. Convierte también solicitudes, configuración, políticas y auditoría. Conserva los hashes originales mediante una base binaria de fecha para su verificación histórica; la fecha visible es local. Los textos históricos que forman parte del hash no se reescriben. Consulte [conversión y validación de horas](HoraLocalGuatemala.md).

## Registro de operaciones de la app

Antes del primer comando se reserva un intento persistente por solicitud (o cierre temporal). Cada comando guarda su operación y recurso tipados en el pivote **antes** de enviarse al destino. No se guardan contraseñas, hashes ni texto SQL dinámico en ese seguimiento.

El resultado se confirma después de una respuesta satisfactoria del motor; los comandos de una transacción se confirman únicamente después del COMMIT. Un rollback comprobado queda como `ROLLED_BACK`, sin sumar contraseñas. Un comando sin prueba suficiente de finalización queda `PENDING`/`UNRESOLVED` para conciliación. Los éxitos de otras bases y el login creado se conservan aunque un paso posterior falle.

La identidad del comando y el intento son persistentes. Reentregar su confirmación no suma otra vez. Un intento ya reservado no vuelve a ejecutar la solicitud automáticamente: ante caída de red/proceso o falta de registro central, revisar el destino y el historial antes de generar una nueva gestión. El diseño prioriza evitar ejecutar dos veces un cambio incierto; no es una transacción distribuida ni una cola local de recuperación.

## Fuentes y comparación de fechas

**Aplicación:** registro de una operación gestionada por la app, con su actor, solicitud/ticket, recurso y resultado. Solo `CONFIRMED` acredita la respuesta/commit para el contador.

**Externo — sin registro en la app:** última fecha observada que no encuentra una operación confirmada coincidente. Es un criterio de conciliación, no una prueba criptográfica del origen. No atribuye actor, herramienta ni detalle del cambio. No supone que cada permiso o membresía modifica la definición de su principal.

La comparación consulta `sys.server_principals.modify_date`, `sys.database_principals.modify_date` y `LOGINPROPERTY(...,'PasswordLastSetTime')` para logins SQL. Identifica cada principal por servidor registrado, ámbito/base y SID. Todas las fechas estructuradas se guardan y presentan en **hora de Guatemala**, sin sufijos UTC en la interfaz. Las fechas nativas del motor se normalizan usando el desplazamiento observado; no se equiparan por proximidad a la hora del equipo cliente. Las fechas de modificación y de contraseña se concilian por separado: una operación de estado no borra una referencia de contraseña externa.

La primera consulta establece una **referencia inicial**, sin inventar un cambio externo histórico. Una identidad nueva con el mismo nombre y otro SID establece otra referencia. Se conserva solo la última referencia externa por principal/propiedad. Varias modificaciones entre consultas no permiten reconstruir cuántas ocurrieron ni estados intermedios. Un cambio que se revierte entre consultas puede pasar inadvertido.

Las fechas se comparan con las observadas al ejecutar la app, para el mismo SID y ámbito. La coincidencia no excluye una intervención simultánea externa; el registro del comando confirmado conserva su propia trazabilidad. Si existe un comando pendiente/incierto para esa identidad, se difiere su clasificación externa hasta conciliarlo. El seguimiento no elimina usuarios ausentes del catálogo ni deduce bajas a partir de metadatos incompletos.

Las consultas se realizan en lotes de hasta 500 filas, cada 60 segundos mientras opera WPF/worker. Consultan instancias y bases en línea y avisan por separado de errores de conexión o visibilidad. Una base inaccesible conserva su referencia anterior. No hay promesa de impacto cero: sigue existiendo el costo de leer catálogos y propiedades; ajustar frecuencia/alcance requiere mediciones del entorno.

## Usuarios temporales

En **Administrar accesos**, seleccionar Vigencia temporal y una fecha/hora futura de Guatemala . El alta de un login nuevo se sigue a nivel de login; un usuario nuevo se sigue en su base. Un permiso o membresía nuevo sobre una identidad existente se sigue por recurso. No se convierte un permiso permanente previo en temporal. Se admiten base, esquema, objeto, columna y servidor completo; los ámbitos incompatibles se rechazan.

Al vencer, **el acceso se conserva** y se materializa una alerta persistente. No se ejecutan revocaciones, bajas ni deshabilitaciones automáticas.

En **Usuarios temporales → Accesos temporales**, seleccionar un recurso e ingresar el ticket completo. **Validar** consulta `dbo.sp_VerificarTicketExiste`; el motivo de solo lectura se toma de la descripción o del asunto. Cambiar el ticket invalida la validación. El SP vuelve a comprobar el ticket al guardar.

- **Extensión:** fecha futura mayor a la anterior. En Revisión de solicitudes, confirmar y ejecutar. No cambia permisos SQL.
- **Cierre:** confirmar y ejecutar la acción descrita. Login: deshabilitar; usuario: eliminar; permiso: REVOKE; rol: retirar membresía. Se comprueba el SID antes de actuar.

Solo Administrador solicita, revisa y ejecuta estas acciones; puede ser la misma persona. La alerta se resuelve únicamente al completar la acción satisfactoriamente. Rechazar, confirmar sin ejecutar, cambiar de día o reiniciar no la resuelve. El cierre fallido conserva la alerta. Deshabilitar no termina sesiones; REVOKE directo no quita accesos heredados; DROP USER puede fallar si posee objetos. Una acción `EXECUTING` tras una caída exige conciliación previa.

## Contraseñas y alertas

El contador usa **instancia + SID + día calendario de Guatemala**. Solo incluye `CHANGE_LOGIN_PASSWORD` confirmado de la app. No incluye altas iniciales, cambios de configuración, referencias externas, reentregas, pendientes ni contraseñas Windows/AD.

El tercer cambio confirmado crea una alerta; el cuarto actualiza la misma alerta activa. Revisarla no borra el historial ni el contador. Otra contraseña del mismo día puede generar otra alerta; reentregar una confirmación antigua no la reabre.

Resumen conserva contadores y **Ver alertas**, sin formulario de motivo. La ventana modal muestra filtros, búsqueda y detalle de hasta 50 alertas recientes. Administrador/Auditor puede registrar un motivo de al menos 10 caracteres y confirmar su revisión. El conteo central se actualiza después sin consultar destinos. Las alertas de vencimiento llevan a Usuarios temporales y no se descartan desde esta ventana.

## Reportes

**Cambios de accesos** separa operaciones de la app de las últimas modificaciones externas observadas. Expone fuente, resultado, actor aplicativo/ticket cuando corresponden y hora de Guatemala. `PENDING` y `UNRESOLVED` no se presentan como éxitos.

**Cambios de contraseña → Ranking** cuenta solo cambios confirmados desde la app. **Historial** añade resultados inciertos y últimas fechas externas, siempre excluidas del contador. El período de las referencias externas filtra la fecha local en que se detectó la diferencia; no fabrica una hora de ejecución.

Administrador/Auditor consultan y exportan PDF/CSV/Excel desde el pivote. Auditor no recibe credenciales de destinos. Los otros reportes directos mantienen su autorización existente.

## Worker y operación

```powershell
dotnet run --project .\tools\SecurityMonitoringWorker -- 'SERVIDOR_PIVOTE\INSTANCIA' adminDB --once
dotnet run --project .\tools\SecurityMonitoringWorker -- 'SERVIDOR_PIVOTE\INSTANCIA' adminDB
```

La identidad Windows debe estar registrada, activa y tener Administrador/AprobadorEjecutor para consultar metadatos de destinos. `--expire-only` evalúa únicamente el pivote y no obtiene credenciales de destinos. `--trust-certificate` sigue siendo una opción explícita del entorno.

Sin `--once` repite cada 60 segundos, reintenta fallos de ciclo y se detiene al perder autorización. Publicar sus dependencias y configurarlo mediante la infraestructura Windows aprobada; la aplicación no crea una tarea ni un servicio automáticamente.

## Prueba funcional sugerida

1. Instalar 36/33 v4/99 en el pivote de pruebas. Ejecutar cliente/worker y establecer la referencia inicial de una cuenta de laboratorio; no debe generar un externo por su fecha anterior.
2. Cambiar cuatro veces su contraseña mediante solicitudes válidas de WPF, en el mismo día de Guatemala. Esperar conteos 1/2/3/4 y una alerta a partir del tercero. Consultar actor, ticket y resultados.
3. Registrar la revisión en la ventana de alertas. Conservar contador/historial y retirar solo la alerta activa.
4. Cambiar la contraseña desde SSMS, actualizar metadatos y verificar la última fecha con fuente Externo, sin actor/ticket y sin aumentar el contador de la app. Repetir la consulta: no duplicar registros.
5. Probar un permiso nuevo temporal sobre un usuario con permisos permanentes. Al vencer se alerta únicamente ese recurso; el permiso permanece hasta ejecutar un cierre o extensión aprobados con ticket.
6. Probar fallo por base, rollback, pérdida de visibilidad y caída de conexión. No reejecutar un intento reservado con resultado incierto.

Comprobaciones automatizadas y laboratorio aislado: [README de pruebas](../tests/SecurityMonitoringChecks/README.md).
