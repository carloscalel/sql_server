# Hora local de Guatemala en toda la aplicación

Convención vigente: **v4**. Las fechas estructuradas de la aplicación se almacenan y muestran como hora de Guatemala, con formato `yyyy-MM-dd HH:mm:ss`, sin conversión adicional al mostrarlas ni sufijos de zona en los controles.

## Activación

1. Detener cliente y worker; respaldar el pivote y conservar una entrega anterior compatible.
2. En `adminDB`, ejecutar **36_HoraLocalGuatemala.sql**. Requiere permisos DBA y una instalación histórica cuyas fechas tengan la convención UTC de los insumos anteriores.
3. Aplicar **33_MonitoreoSeguridadYTemporales.sql actualizado**, después **99_ValidarInstalacion.sql**.
4. Publicar cliente y worker compatibles y abrir sesiones nuevas. El cliente comprueba la versión temporal al ingresar para evitar leer datos UTC como locales.

El orden es también `... → 32 → 36 → 33 → 99` en instalaciones nuevas. Las migraciones históricas 01–32 impiden reaplicarse cuando detectan la convención local, para evitar restaurar escrituras UTC o un validador de hash anterior. No ejecutar automáticamente los archivos por número: seguir el orden documentado.

La aplicación no ejecuta esta conversión automáticamente. Sustituir solo el ejecutable no convierte los registros existentes.

## Qué convierte y verifica

El 36 usa una transacción y un bloqueo de instalación. Revisa todas las columnas datetime/datetime2/smalldatetime del esquema `access`: convierte las columnas terminadas en Utc y las fechas históricas catalogadas de identidades, servidores, criptografía, políticas, solicitudes y auditoría. Una columna sin convención conocida hace abortar la migración en lugar de adivinar su zona.

- `ExpiresAtUtc` pasa a `ExpiresAt`; lo mismo ocurre con fechas de creación, ejecución, detección, revisión, cierre, consulta y seguimiento.
- Las fechas históricas UTC se desplazan seis horas, conservando el instante de vencimiento. Por ejemplo, `23:05` pasa a `17:05`.
- Las fechas nativas `ModifiedLocal`/`PasswordSetLocal` se normalizan a Guatemala usando `EngineOffsetMinutes`; los valores nuevos se normalizan al leerlos del destino.
- Se actualizan los defaults y módulos SQL instalados que escribían UTC para que usen `access.ufn_AppNow()`, independiente del huso configurado en el servidor.
- El día de los contadores se obtiene directamente de la fecha local; no se vuelve a convertir. BusinessDate y las claves de alertas mantienen el mismo día de Guatemala.
- `access.AppTimeConvention` evita aplicar una segunda conversión. `access.AppTimeConversion` conserva la relación tabla/columna y cantidad de registros convertidos.

La transformación afecta solo objetos de la aplicación en el pivote. No altera catálogos de SQL Server, bases de negocio ni fechas de contraseñas de los destinos. El reporte de 45 días sigue calculando la antigüedad con las fechas del motor y normaliza la fecha mostrada a Guatemala.

## Integridad de auditoría

Antes de convertir AuditEvent se comprueba su cadena. Los valores EventHash/PreviousHash y el contenido histórico permanecen intactos. Para filas históricas con hash se conserva en `HashDateBasis` la entrada binaria de la fecha utilizada originalmente; EventDate queda en hora local.

El validador comprueba el hash original y que la fecha local visible sea exactamente la conversión correspondiente. Los eventos nuevos se calculan sobre su fecha local y enlazan con la cadena existente. La protección append-only se restaura con su estado anterior. Si falla cualquier comprobación, la transacción revierte.

Los textos libres históricos del detalle se conservan literalmente porque forman parte del hash; pueden contener expresiones horarias antiguas. No son nuevas columnas de fecha ni se reescriben como si se hubiesen creado con otra convención.

## Comprobación práctica

Comparar el mismo vencimiento en WPF y en `access.TemporaryAccess.ExpiresAt`: deben mostrar la misma fecha y hora. Comprobar también RequestValidity, AccessRequest, TemporaryAccessAction, SecurityAlert, AppExecution, AppSecurityChange, PrincipalMetadataSnapshot, políticas y AuditEvent.

Reaplicar 36 no debe restar otras seis horas. Ejecutar `access.usp_Audit_ValidateIntegrity` antes y después debe devolver IsValid=1, manteniendo los hashes originales. El laboratorio de SecurityMonitoringChecks comprueba conversión, reaplicación, integridad, detección de adulteración de fecha y separación de días a medianoche local.
