/* Diagnóstico de solo lectura: ejecutar desde la conexión Windows que usa la app.
   No agrega, modifica ni activa usuarios. No aplica migraciones. */
USE [adminDB];
GO
SET NOCOUNT ON;
DECLARE @Original nvarchar(256)=ORIGINAL_LOGIN(), @Canonical nvarchar(256), @OriginalSid varbinary(85), @Principal nvarchar(256);
SELECT @OriginalSid=original_security_id FROM sys.dm_exec_sessions WHERE session_id=@@SPID;
SET @Canonical=SUSER_SNAME(@OriginalSid);
SET @Principal=CASE WHEN EXISTS(SELECT 1 FROM [access].AuthorizedPrincipal WHERE Principal=@Canonical)
                   THEN @Canonical
                   WHEN EXISTS(SELECT 1 FROM [access].AuthorizedPrincipal WHERE Principal=@Original)
                   THEN @Original ELSE COALESCE(@Canonical,@Original) END;
SELECT @Original AS LoginOriginal,@Canonical AS NombreWindowsSQL,SUSER_SNAME() AS ContextoActual,
       @Principal AS PrincipalAValidar,
       CONVERT(bit,CASE WHEN @OriginalSid=SUSER_SID() THEN 1 ELSE 0 END) AS ContextoCoincideConOriginal;
SELECT UserId,Principal,PrincipalType,RoleName,Active
FROM [access].AuthorizedPrincipal WHERE Principal IN(@Canonical,@Original);
EXEC [access].usp_App_LoginContext;
GO
