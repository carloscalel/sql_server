# Propuesta: auditoría de origen, accesos temporales y frecuencia de contraseñas

Fecha del diseño: 22 de octubre de 2026. Estado: **referencia histórica; implementación vigente enlazada abajo**.

> **Actualización del 25 de octubre de 2026:** este documento conserva el diseño histórico. Los tres módulos ya están integrados y se completó el canal nativo Audit para SQL Server 2022+, la revisión de alertas de contraseña y las pruebas SQL aisladas. Consulte [implementación e instalación vigentes](../../MonitoreoSeguridad.md) y [resultados de validación](../../ValidacionMonitoreoSeguridad.md). Los pendientes que se describen más abajo corresponden a la propuesta original; los ejemplos de esta carpeta no son migraciones. El origen continúa siendo declarado y se conserva captura de respaldo, como permite el apartado 3.3; la supresión mediante planes firmados queda como ampliación de confianza, no se simula con una etiqueta de sesión.

Esta entrega responde a la solicitud de diseñar tablas, reglas, procedimientos e integración paso a paso. No instala infraestructura ni agrega todavía pantallas al ejecutable. Los archivos SQL no pertenecen al orden de migraciones productivas de `InsumosProduccion`.

## 1. Encaje con el código actual

Se revisaron los contratos reales, además de la documentación compartida:

| Componente existente | Integración propuesta |
| --- | --- |
| `Data/DirectSqlServerService.cs`, `ExecuteApprovedRequestAsync` | Mantener autorización y política; propagar contexto y evidencia por cada conexión/paso de escritura. |
| `Data/PermissionCopyService.cs` | Aplicar la misma captura a creación de login, usuario y permisos por base. |
| `Data/AdminDbGateway.cs` | Nuevos métodos para vigencias, alertas y reportes centrales, revalidando la sesión. |
| `ViewModels/MainViewModel.cs`, `DashboardViewModel` | Navegación a Usuarios temporales; indicadores de alertas persistidas en Resumen. |
| `Models/ReportModels.cs`, `ReportsViewModel`, `ReportsView` | Nuevos reportes, filtros y exportaciones mediante la infraestructura existente. |
| `access.AuditEvent`, `usp_Audit_Write` | Conservar auditoría operativa y su cadena; enlazar eventos nuevos por solicitud/correlación. No sustituir su contrato ni truncar JSON a `Detail nvarchar(2000)`. |
| `32_CambiarContrasenaLogin.sql`, `CHANGE_LOGIN_PASSWORD` | Reutilizar el flujo de cambio de contraseña aprobado. No crear otro botón que lo eluda. |

El documento técnico general todavía describe principalmente la evolución hasta 31. El código y la migración 32 ya incorporan el cambio de contraseña; el diseño toma ese estado como referencia.

## 2. Arquitectura propuesta

```mermaid
flowchart LR
    W[WPF: solicitudes y revisión] --> P[(adminDB: gobierno y alertas)]
    W --> X[SQL destino: ejecución aprobada]
    S[SSMS y otros clientes] --> X
    X --> T[Trigger DDL: eventos de seguridad]
    T --> O[(Cola local SqlAccessEvidence)]
    X --> A[SQL Server Audit: contraseñas]
    O --> C[Recolector con reintentos]
    A --> C
    C --> P
    E[Evaluador de vencimientos] --> P
    P --> R[Resumen, temporales y reportes]
```

Cada instancia tiene su base local de evidencia. El trigger hace trabajo local, dentro de la transacción de seguridad, sin llamadas de red al pivote. Un recolector independiente consolida en `adminDB` y continúa aunque WPF esté cerrado. Puede implementarse como servicio Windows .NET o jobs administrados por el DBA; no depende de SQL Server Agent si la edición no lo incluye.

Los eventos DDL de seguridad no son las operaciones cotidianas `SELECT`, `INSERT`, `UPDATE` y `DELETE` sobre datos. No se agregan triggers DML a tablas del negocio. Aun así, no puede prometerse impacto cero: hay consumo de CPU, log, disco y bloqueos en operaciones de seguridad; debe medirse en el entorno.

## 3. Auditoría: origen y detalle sin duplicación

### 3.1. Qué guardar

Por evento: identificador de instancia estable, identificador de evento, fecha UTC, base, actor SQL original y efectivo, host/aplicación declarados, destino, tipo de cambio, solicitud, operación y evidencia de commit.

El origen tiene dos dimensiones:

- `ClaimedOrigin`: APP, SSMS o EXTERNAL, según contexto y nombre de cliente.
- `OriginVerified`: si existe evidencia confiable de que el evento corresponde al paso aprobado.

`APP_NAME()` y `HOST_NAME()` son datos de cliente. Identifican lo declarado y no prueban qué binario se ejecutó. Cualquier usuario puede establecer su propio `SESSION_CONTEXT`; no usar un simple `IF SESSION_CONTEXT(...)='APP' RETURN` como frontera de seguridad.

Una identidad con `sysadmin` puede modificar o deshabilitar estos controles. Para un requisito de evidencia resistente a administradores del motor, enviar además la evidencia a un repositorio externo con permisos/retención independientes y monitorear cambios en la configuración de captura.

### 3.2. Detalle estructurado de la app

Cada comando lógico lleva un `OperationId` estable en sus reintentos y un ordinal de paso; una solicitud puede generar varios. No reutilizar un mismo identificador para todos los comandos internos de una copia.

Ejemplo de `ChangesJson`, preparado desde el plan validado y confirmado con el resultado del destino:

```json
{
  "schemaVersion": 1,
  "requestId": 845,
  "stepOrdinal": 2,
  "principal": "operador_reportes",
  "database": "Ventas",
  "changes": [
    {
      "action": "GRANT",
      "permission": "SELECT",
      "scope": "OBJECT",
      "securable": "dbo.Factura",
      "previousExplicitState": "NONE",
      "newExplicitState": "GRANT"
    }
  ]
}
```

Una fila por permiso/rol/usuario afectado dentro del detalle; no guardar solamente «permisos actualizados». Distinguir comando ejecutado, cambio real del catálogo y acceso efectivo. Un GRANT repetido puede no cambiar el catálogo; un REVOKE puede dejar acceso por roles. Si no se observó el estado previo con garantías de concurrencia, registrarlo como desconocido.

La creación del login se guarda como CREATE_LOGIN; no como cambio de contraseña. Los nombres y SID deben conservarse como eran en el momento del evento; un nombre puede renombrarse o volver a crearse con otro SID.

### 3.3. Cómo evitar duplicación y pérdida

La estrategia evita duplicar el **texto bruto** y produce una sola fila lógica en el reporte:

1. La app establece `SAA.Origin`, `SAA.RequestId`, `SAA.OperationId` y actor en **cada conexión destino**.
2. Para comandos compatibles, un ejecutor confiable registra un recibo estructurado autorizado en la misma transacción: solicitud, paso, sesión, transacción, SID original, tipo de evento, base y hash exacto del comando permitido.
3. El trigger valida esa correspondencia. Si hay recibo válido, conserva solo el sobre mínimo y el detalle estructurado; omite el texto bruto duplicado.
4. Sin recibo válido, captura el evento como externo/origen declarado sin verificar. Nunca se pierde por una etiqueta APP.
5. El recolector inserta por `(SourceId, EventId)`; los reintentos no duplican. La evidencia del motor y la auditoría operativa se relacionan por operación/solicitud; no se hace `UNION ALL` de ambas como cambios independientes.

**No se propone un SP público que reciba cualquier JSON/RequestId y lo dé por aprobado.** El recibo debe proceder de una orden aprobada verificable. Con el modelo actual de cliente WPF y credenciales compartidas, para comprobar esa procedencia hace falta ampliar la frontera de confianza: por ejemplo, un despachador del pivote que firme el plan y un ejecutor local que verifique firma, destino, vigencia y no reutilización. No incluir una clave privada de firma en WPF.

Hasta implementar esa verificación, mantener captura de respaldo y `OriginVerified=0`. La supresión de texto es una optimización posterior, no requisito para comenzar a auditar. Para CREATE/ALTER LOGIN, el ejemplo conserva metadatos y no intenta comparar hashes de comandos con contraseñas enmascaradas; el detalle tipado se concilia posteriormente.

### 3.4. Captura externa

`03_CapturaDestino.sql` usa **un trigger de servidor** para seguridad de servidor y base. Esto cubre bases actuales y nuevas sin instalar otro trigger para el mismo evento. También es posible separar servidor/base, pero debe evitarse el solapamiento.

Se conserva el comando de permisos/membresías y metadatos del resto. No se captura todo DDL de tablas/índices. Para normalizar órdenes externas complejas, usar un parser T-SQL como ScriptDom en el recolector, después de validar la versión correspondiente; no expresiones regulares para interpretar todos los GRANT/REVOKE posibles.

El XML `EVENTDATA` aporta el comando y campos según el evento, pero no es una imagen universal antes/después del catálogo. El requisito de delta exacto externo necesita una línea base de seguridad, seguimiento de cambios y pruebas de concurrencia; cuando falte esa evidencia, mostrar «comando registrado; estado anterior desconocido», sin inventarlo.

No se persiste XML completo para eventos sensibles. Microsoft documenta el ocultamiento de passwords en CREATE/ALTER LOGIN; eso no debe extrapolarse a cualquier secreto presente en un lote. Nunca guardar passwords, hashes de passwords, valores de parámetros secretos o SQL dinámico que los contenga, ni en mensajes de excepción.

### 3.5. Recolector y entrega confiable

Pseudocódigo del proceso de consolidación:

```text
leer lote de outbox WHERE DeliveredAtUtc IS NULL
  adquirir lease acotado si hay varios recolectores
  enviar lote parametrizado/TVP al pivote
  validar SourceId contra la identidad/registro del recolector
  transacción pivote:
    insertar eventos ausentes por PK (SourceId, EventId)
    verificar que una clave existente tenga el mismo contenido
    guardar checkpoint de este lote
  confirmar recepción duradera
  marcar DeliveredAtUtc local SOLO para los EventId confirmados
reintentar con espera creciente ante red caída
```

No avanzar únicamente con `MAX(IDENTITY)`: una transacción que obtuvo un número menor puede confirmar después de otra con número mayor. El ejemplo usa filas pendientes, por lo que no pierde ese evento tardío. No borrar entregados hasta cumplir la retención y comprobar respaldo/recepción.

No usar linked servers, correo, llamadas HTTP, recorridos del catálogo completo ni consultas al pivote dentro del trigger. Si falla el INSERT local, el ejemplo deja fallar la operación de seguridad; no contiene un CATCH que silencie la pérdida. Esta decisión debe probarse y acordarse con la disponibilidad requerida. Si es prioritario continuar el DDL ante fallos, usar un canal independiente de captura y alertar las brechas; un CATCH vacío no aporta garantía de auditoría.

El aprovisionamiento debe firmar los módulos y conceder solo escritura de captura/lectura del dato de transacción necesarios. No conceder INSERT/UPDATE de recibos a la app ni resolver permisos con TRUSTWORTHY, `EXECUTE AS` de una cuenta sysadmin o privilegios de servidor para todos. Una alteración posterior del módulo exige volver a firmarlo.

## 4. Tablas centrales

`01_ModeloCentral.sql` propone tablas adicionales, sin alterar las existentes:

| Tabla | Propósito e índices relevantes |
| --- | --- |
| `SecurityEvidenceSource` | Instancia estable, servidor administrado, zona corporativa, inicio de cobertura y último recolectado. |
| `SecurityChange` | Eventos por origen/evento, fecha y operación; JSON tipado y texto permitido. |
| `TemporaryAccess` | Una vigencia por acceso concreto; índice filtrado `(ExpiresAtUtc, Id)` para abiertos. |
| `TemporaryAccessRequestTerm` | Fecha, acción, recurso y versión que formaban parte de la solicitud aprobada; inmutables. |
| `SecurityAlert` | Alertas activas y resoluciones; clave única filtrada evita duplicación activa. |
| `PasswordChangeHistory` | Evidencia por SID/evento, día de negocio y confirmación. Nunca secretos. |
| `PasswordChangeDaily` | Contador por instancia/SID/día; permite rankings sin contar todo el historial. |

Para un permiso temporal, identificar explícitamente instancia, SID, usuario de base, base, ámbito, esquema/objeto/columna y permiso. Para membresía, añadir el rol. `ResourceJson` debe guardar una versión canónica de este contrato; el SP de creación debe validar sus campos, tipos y claves duplicadas antes de aprobarlo. El esquema de referencia no pretende que `ISJSON=1` sustituya esa validación.

Una cuenta con tres permisos de distinta vigencia necesita tres registros, no una fecha global del login. No convertir implícitamente en temporal un permiso preexistente permanente. Resolver solapamientos mediante el SP y una clave canónica; no retirar un acceso si otra autorización vigente lo sostiene.

Conservar la zona horaria utilizada en cada evento. Configuración inicial propuesta para Guatemala: `Central America Standard Time` en Windows/SQL Server. Persistir fechas en UTC `datetime2(7)`; presentar zona y offset al usuario. No usar GETDATE del equipo como reloj de vencimiento.

## 5. Vencimiento: conserva acceso y mantiene alerta

Regla exacta: `IsOpen=1 AND ExpiresAtUtc <= SYSUTCDATETIME()` implica **Vencido / Pendiente de revisión**. El estado se deriva en `v_TemporaryAccessState`, así no depende de que un job haya modificado una bandera a tiempo. `IsOpen` representa el seguimiento administrativo; no demuestra por sí solo que un acceso del destino siga operativo. Mostrar también última comprobación y «estado del destino no verificado» cuando corresponda.

El detector solamente inserta alertas persistentes. Nunca ejecuta REVOKE, DROP USER ni ALTER LOGIN DISABLE. Una alerta no caduca ni se elimina al cerrar la app o al cambiar el día.

Evaluación propuesta:

- Al completar el login, al cargar Resumen/Usuarios temporales y después de aplicar una acción.
- Refresco compartido cada 60 segundos mientras la sesión está activa; una sola consulta en curso, cancelable, con espera creciente ante errores.
- Servicio/job cada minuto para materializar alertas aun con la app cerrada. Su wrapper firmado requiere una identidad dedicada; el ejemplo interactivo exige autorización READ y no se debe abrir a cuentas anónimas.
- Procesar lotes de 500 y drenar el atraso en el worker con límites. La fecha de estado es exacta, pero la persistencia/notificación tiene una latencia acotada por el intervalo, carga y conectividad; no es una garantía de tiempo real.

El detector serializa su corta sección crítica con `sp_getapplock`, y la clave única protege la idempotencia. Sus bloqueos pueden competir con cambios de vigencia; medirlos con volumen real. Para muchas instancias/filas, dividir por ámbito y usar leases; no multiplicar timers WPF.

### 5.1. Crear vigencia

1. El formulario captura fecha y hora obligatorias más zona corporativa.
2. La solicitud guarda los términos por recurso/paso en `TemporaryAccessRequestTerm` dentro de la misma transacción de creación; el detalle de aprobación muestra esas fechas.
3. Al confirmar y al ejecutar se vuelven a comprobar política, autorización y fecha futura; si ya venció, rechazar y pedir una nueva solicitud. No editar silenciosamente términos aprobados.
4. Crear `TemporaryAccess` solo después de observar la ejecución correcta del acceso correspondiente. Un fallo al dar permisos no debe crear una vigencia aparentemente activa.
5. Si el destino confirmó y falla el pivote, el recibo/outbox permite completar el registro idempotentemente; mostrar «pendiente de conciliación». No volver a conceder a ciegas.

### 5.2. Extender o cerrar

No ofrecer un botón genérico «descartar» para vencimientos. Ofrecer **Solicitar extensión** y **Solicitar cierre**, con ticket, motivo y versión esperada.

La extensión modifica metadatos de vigencia, conserva el acceso y pasa por revisión. El cierre necesita la operación explícita elegida: retirar un permiso/membresía, retirar usuario o deshabilitar login; sus efectos son distintos. Deshabilitar no termina sesiones abiertas ni garantiza que un permiso retirado deje de recibirse por otro rol.

Pseudocódigo del SP de aplicación, que deberá implementarse junto con el contrato de solicitudes:

```text
validar identidad/función de ejecución y términos aprobados inmutables
bloquear solicitud, término y TemporaryAccess con UPDLOCK/HOLDLOCK
si el término ya tiene AppliedAtUtc: devolver resultado anterior
comparar ExpectedRowVersion + Revision; conflicto exige revisar nuevamente
para EXTEND:
  exigir nueva fecha futura y mayor a la anterior
  actualizar vigencia, incrementar Revision
para CLOSE:
  exigir evidencia de la operación de seguridad correcta para este recurso/SID
  reconsultar destino; si queda acceso por otra vía, describirlo explícitamente
  cerrar seguimiento con actor/fecha
resolver SOLO la alerta activa de TemporaryAccessId + Revision anterior
guardar resolución, motivo, RequestId y evento en auditoría operativa
marcar término aplicado
commit de todos los metadatos centrales juntos
```

El detector y estos SP deben tomar el mismo bloqueo lógico o mantener un orden de bloqueos consistente para que la extensión/cierre no deje una alerta insertada tarde. No realizar la consulta de red al destino manteniendo esos locks: obtener evidencia primero y validar su correspondencia dentro de la transacción central.

Un cambio externo detectado no cierra automáticamente la alerta; el administrador lo concilia mediante el flujo de la aplicación. Las solicitudes fallidas/rechazadas no resuelven alertas. Mantener historial de extensiones/resoluciones, sin actualizar ni borrar evidencia anterior.

## 6. Contraseñas: historial, umbral y ranking

### 6.1. Fuente y confirmación

Utilizar `LOGIN_CHANGE_PASSWORD_GROUP` en cada instancia, además del trigger DDL. Un evento ALTER_LOGIN puede ser un cambio de base predeterminada, habilitación, política o idioma. Contarlo siempre como password produciría falsos positivos. `LOGINPROPERTY(...,'PasswordLastSetTime')` solo da la última fecha y pierde cambios intermedios; no puede reconstruir el historial estricto.

El grupo de Audit detecta cambios de password realizados por ALTER LOGIN y `sp_password`. No observará cambios de la contraseña Windows en Active Directory: ese historial requiere la fuente de identidad correspondiente.

**Una fila Audit con `succeeded=1` no debe convertirse automáticamente en cambio confirmado.** Microsoft especifica que, fuera de eventos de login, ese campo representa la comprobación de permisos, no el resultado completo de la operación. Los eventos pueden además fragmentarse. El recolector debe:

1. Descubrir las acciones reales del grupo en la versión instalada (`sys.dm_audit_actions`). Excluir operaciones de configuración que no cambian password, unlock sin cambio y altas iniciales.
2. Reconstruir fragmentos mediante el identificador de secuencia del registro. Persistir evidencia nativa con identificador de archivo/offset/secuencia y generación del origen, sin usar hora+login como clave.
3. Relacionar el evento específico con la evidencia DDL local **confirmada** y operación tipada cuando exista, usando instancia, sesión, transacción, destino y ordinal. Probar las rutas de cambio propio, reset administrativo y `sp_password`; no asumir que todas emiten exactamente la misma secuencia.
4. Si existe una correspondencia única y resultado comprobado, marcar CONFIRMED e invocar `usp_PasswordChange_AppendConfirmed`. Si hay error, rollback, correspondencia ambigua o ruta sin cobertura demostrada, conservar FAILED/OBSERVED/UNRESOLVED para revisión y no inflar el contador de cambios confirmados.
5. Los eventos específicos de contraseña siguen capturándose para la app. Solo la evidencia nativa normalizada alimenta el contador, evitando sumar además la solicitud WPF.

**Esta clasificación y su cobertura por versión quedan pendientes de implementar/probar.** El SQL entregado implementa almacenamiento y reglas posteriores a la confirmación; no incluye un recolector universal ni certifica que Audit+trigger ya resuelvan cualquier reset. Si una ruta no puede confirmarse con esas fuentes, incorporar la señal de finalización/error del motor apropiada para esa versión y mantener el estado incierto hasta resolverla.

### 6.2. Conteo diario

El día se obtiene de la fecha UTC del evento convertida a la zona corporativa del origen, no de su recepción. Esto conserva el día correcto si hubo atraso de recolección.

`02_ProcedimientosCentrales.sql` incluye `usp_PasswordChange_AppendConfirmed`: valida la identidad de recolector, serializa por instancia/SID/día, inserta el historial una vez, incrementa el contador y crea/actualiza una alerta cuando `ChangeCount >= 3`. Todo ocurre en una transacción. Usa UPDATE + INSERT con bloqueo por clave; no MERGE ni COUNT(*) de todo el historial por cada evento.

Tres cambios en dos logins distintos no se suman. Dos cambios antes de medianoche y otro después pertenecen a días distintos. La fecha de creación no cuenta como cambio. Un reintento de entrega no cuenta otra vez. No hay forma de reconstruir todos los cambios previos a habilitar la captura: el reporte debe mostrar el inicio de cobertura.

Las alertas de frecuencia permanecen para revisión de seguridad; no se cierran automáticamente a medianoche. Añadir un SP de resolución ADMIN/AUDIT con motivo e historial, separado del cierre de alertas de vigencias. Un cambio posterior puede generar una nueva alerta si la anterior fue resuelta; documentar esa política en la interfaz.

### 6.3. Reportes

Agregar en Seguridad y Auditoría:

- **Cambios de accesos:** período, servidor, base, principal/SID, actor, origen declarado/verificado, solicitud/ticket, acción y detalle. Separar pendientes de conciliación de eventos confirmados. Mostrar principal SQL real y actor aplicativo cuando use cuenta técnica compartida.
- **Cambios de contraseña:** historial sin secretos y ranking por total, máximo diario, días con tres o más, último cambio, cobertura y atraso de captura. `usp_Report_PasswordChanges` implementa el ranking sobre contadores diarios; añadir detalle paginado por SID/fecha.
- **Accesos temporales:** vigentes, vencidos pendientes y cerrados, con recurso, fecha/zona, última verificación, revisión y resolución.

Los nuevos reportes centrales de seguridad usan ADMIN/AUDIT en SQL; el ejemplo reutiliza la guarda `AUDIT`. Mantener los reportes directos actuales con su autorización vigente. Agregar capacidades de navegación separadas: Auditor podrá leer evidencia central sin recibir credenciales compartidas para destinos. No cambiar globalmente `CanReports` para abrirle todos los reportes directos.

Reutilizar `ReportExportDocument` y exportadores PDF/CSV/XLSX, incluidos filtros, orden, zona horaria, estado de evidencia y cobertura. No concatenar filas de auditoría operativa como si fueran otra modificación del destino.

## 7. Integración C# / WPF paso a paso

`ReferenciaCSharp` es un pequeño proyecto independiente que referencia la aplicación para comprobar compatibilidad. No está incluido en la solución productiva.

1. **Modelos:** añadir DTO de vigencia, términos de solicitud, alertas, detalle de cambios y ranking. Reutilizar `SessionContext` y capacidades actuales; no confundir usuario autorizado de la app con login temporal de un destino.
2. **Captura temporal:** DatePicker + campo HH:mm:ss + zona/offset visibles. Convertir a UTC con las reglas de `ReglasTemporales.cs`; rechazar horas ambiguas/inexistentes o pedir offset explícito. Validar también en SQL.
3. **Solicitudes:** versionar el contrato de creación/detalle/tipos tabulares para términos temporales. Persistirlos con la solicitud, mostrar antes de aprobar y revalidar al ejecutar. La huella/detección de duplicados debe incluir fecha, zona y recurso, también en planes de copia. Crear nuevas migraciones posteriores a 32; no reescribir las viejas ni editar términos ya aprobados.
4. **Conexiones de escritura:** `SessionAuditScope.cs` muestra parámetros tipados, contexto por conexión, MARS deshabilitado y limpieza en finally con token independiente. Reestructurar ejecutores para aceptar esa conexión; envolver un método que abra otra conexión no sirve. Propagar por login, usuarios, roles, permisos, planes compuestos, copia y contraseñas.
5. **Recibos y transacciones:** el helper solo etiqueta. Incorporar ejecutor confiable antes de suprimir texto. Mantener los límites transaccionales existentes: no prometer atomicidad entre login, bases y pivote; usar outbox para conciliación. No envolver en una nueva transacción operaciones cuya compatibilidad no esté validada.
6. **Gateway:** agregar métodos a un archivo parcial para no agrandar `AdminDbGateway.cs`. Para `usp_SecurityAlert_List`, leer ambos resultsets: `ExecuteTableAsync` actual carga uno solo; implementar lectura interna de DataSet/DTO con `NextResultAsync` y revalidación antes/después. No publicar resultados tras pérdida de autorización.
7. **Usuarios temporales:** nuevo `TemporaryAccessViewModel` + `TemporaryAccessView`, tabla y filtros. Menú debajo de Administrar accesos/Reportes según espacio. Administrador actúa; Operador propone si se habilita esa capacidad y AprobadorEjecutor procesa con las mismas guardas SQL. Todos los botones crean solicitudes o abren su seguimiento.
8. **Resumen:** `DashboardViewModel` consume contadores agregados, fecha de evaluación, último recolectado y enlace al listado. Mostrar badge de vencidos y de frecuencia de contraseñas. Con falla de consulta, conservar último valor marcado como desactualizado; no mostrar cero como si no hubiera alertas.
9. **Refresco:** una instancia de `SecurityAlertRefreshService` por sesión. Arrancar al login y cancelar/disponer al bloquear/cerrar sesión. Publicar colecciones/propiedades en Dispatcher UI; no usar async void salvo manejadores WPF ni sondeo por cada fila. Tras navegar, cancelar o descartar respuestas de contexto anterior.
10. **Reportes:** añadir un datasource central distinto de `IReportsDataSource` directo, comandos específicos y modelos exportables. Las guardas de navegación deben reflejar las de SQL, con vistas de solo lectura para auditor.

El helper conserva `@read_only=0` porque limpia la etiqueta por operación. `read_only=1` no acredita autenticidad y dificulta la reutilización de la conexión lógica. Si la limpieza falla, descarta el pool correspondiente para impedir una etiqueta residual; esa limpieza puede tener costo y debe ser excepcional.

## 8. Rendimiento, seguridad y operación

| Riesgo | Control y medición |
| --- | --- |
| Sobrecargar DML del negocio | Sin triggers DML ni auditoría de accesos SELECT/INSERT/UPDATE/DELETE por objeto; medir CPU/IO/latencia antes y después. |
| Trigger lento o dependiente del pivote | Inserción local y búsquedas por clave; sin red ni cálculo diario dentro del trigger. Medir latencia de GRANT/ALTER LOGIN y bloqueos. |
| Consultas de vencimiento costosas | Índice filtrado por abiertos/fecha, límites por lote; medir con 10k/100k/1M vigencias y revisar plan real/lecturas. |
| Filas grandes en auditoría | JSON/texto fuera de índices de búsqueda; cargar detalle al expandir, paginar, particionar/archivar si el volumen lo exige. |
| Recolección detenida | Mostrar atraso, cola pendiente, disco y estado Audit/trigger. Alertar por brecha de captura, no interpretar ausencia de eventos como ausencia de cambios. |
| Pérdida de archivo Audit | Retención suficiente para la caída máxima del recolector; respaldo externo antes de rollover. El límite de 100 archivos del ejemplo no es una política definitiva. |
| Fallos de disco/permisos | Probar la política FAIL_OPERATION del ejemplo; puede bloquear cambios auditados. No hay garantía de pérdida cero y disponibilidad total simultáneas ante cualquier fallo. |
| Deadlocks/reintentos | Secciones centrales breves, orden estable de locks, reintento acotado por clave idempotente; sin llamadas remotas dentro de esas transacciones. |
| Alteración de evidencia | Roles mínimos y sin DML directo del cliente; solo SP autorizados. Respaldos, separación de administración y exportación de evidencia. La nueva evidencia no hereda automáticamente la cadena hash de AuditEvent. |

No usar NOLOCK para alertas ni contadores. No cambiar opciones globales de aislamiento o trace flags sin revisar el entorno. La zona corporativa debe validarse contra `sys.time_zone_info`; un cambio de zona requiere política de transición y no debe reinterpretar días históricos.

## 9. Orden de implementación y aceptación

1. **Inventariar laboratorio:** versión/edición/compatibilidad, autenticación, HA, permisos, zona, crecimiento y retención. Confirmar instalación hasta 32 y 99 con sus guías. Revisar cómo replicar captura local en failover y evitar dos SourceId para la misma instancia lógica.
2. **Modelo central:** convertir 01/02 en migraciones versionadas, transaccionales e idempotentes según el repositorio; registrar fuentes y roles. Los archivos actuales son instalación inicial de referencia, no una actualización repetible.
3. **Captura piloto:** instalar 03 en un destino de pruebas; firmar, autorizar y habilitar explícitamente el trigger. Instalar/configurar 04 sin secretos de ejemplo ni rutas ficticias.
4. **Recolector:** implementar entrega por lotes, fragmentos Audit, clasificación de resultado, deduplicación, checkpoint confirmado y señal de salud. Restringir por fuente a su identidad de recolección; el rol de ejemplo por sí solo no implementa autorización por instancia.
5. **Captura estructurada:** añadir términos/recibos y ejecutores confiables. Hasta entonces, no habilitar supresión de respaldo. Preservar las guardas de creación/revisión y separación funcional actuales.
6. **Vigencias:** implementar SP de alta/extensión/cierre y conciliación descritos; integrar asistente, edición y copia. No aplicar fechas mediante un UPDATE libre desde WPF.
7. **WPF y reportes:** navegar, refrescar, mostrar atraso/cobertura, exportar; agregar pruebas de autorización y cancelación.
8. **Validación DBA:** ampliar 99 para objetos, índices, guardas, fuentes, firma y salud. Publicar cliente después de sus migraciones. Mantener posibilidad de deshabilitar captura/revertir cliente sin borrar evidencia.

Pruebas mínimas antes de producción:

| Escenario | Resultado esperado |
| --- | --- |
| GRANT/DENY/REVOKE y alta/ALTER/roles desde SSMS | Actor SQL y evento correctos; texto permitido y fuente externa; una fila lógica. |
| Mismas operaciones desde app | Solicitud y paso correlacionados; detalle de cada cambio; recibo válido omite texto duplicado. |
| SSMS imita APP_NAME/SESSION_CONTEXT | No se omite evidencia por la etiqueta; OriginVerified sigue falso. |
| Rollback explícito / fallo posterior al chequeo de permisos | No contar como modificación confirmada. |
| Password propia/admin/sp_password, rápida y simultánea | Captura de cada cambio real; sin secretos; distinguir error, unlock y cambio de configuración. |
| Tres passwords mismo SID/día, app y SSMS mezclados | Un contador de 3 y alerta activa; cuarta incrementa a 4 sin segunda alerta activa. |
| Reentrega de archivo/fragmentos o lote confirmado | Sin doble conteo; detectar conflicto si la misma clave trae otros datos. |
| Dos antes de medianoche y una después, Guatemala | Contadores 2 y 1; no alerta de tres para esos días. |
| Rename / drop y recreación del mismo nombre | Mantener identidad histórica por SID y origen; no mezclar otra cuenta. |
| Vencimiento exacto y app cerrada | Estado derivado vencido, worker persiste alerta en intervalo; permisos siguen operativos. |
| Recargar, reiniciar, cambio de día | Alerta de vencimiento sigue activa hasta acción manual aplicada. |
| Extensión vs detector simultáneos | Una revisión coherente, cierre de alerta anterior, sin alerta activa obsoleta. |
| Cierre fallido / aprobación sin ejecutar | La alerta continúa activa. |
| Pivote caído / entrega fuera de orden de commit | Outbox conserva datos; luego consolida sin perder números menores. |
| Pool reutilizado / cancelación / cambio de sesión | Sin contexto residual ni publicación de datos con autorización perdida. |
| Contraseña con comillas y errores dinámicos | Ningún secreto en outbox, Audit importado, excepciones, UI ni exportaciones. |

## 10. Verificación de esta entrega

Se compiló el proyecto de referencia junto con la aplicación, con cero errores; aparecieron cuatro advertencias CS8981 preexistentes de `viewdemo`. Se ejecutaron correctamente 13 comprobaciones de reglas: límite exacto de vencimiento, persistencia del estado sin cerrar acceso, umbral 2/3/4, medianoche de Guatemala, conversión UTC y rechazo de horas de horario de verano ambiguas/inexistentes. No abren SQL Server.

```powershell
dotnet restore .\docs\propuestas\auditoria-temporales\ReferenciaCSharp\ReferenciaCSharp.csproj
dotnet build .\docs\propuestas\auditoria-temporales\ReferenciaCSharp\ReferenciaCSharp.csproj -c Release --no-restore
dotnet .\docs\propuestas\auditoria-temporales\ReferenciaCSharp\bin\Release\net8.0-windows\ReferenciaCSharp.dll
```

Quedan pendientes: instalación/ejecución SQL, pruebas del trigger y firmas, recolector, clasificación por versión de passwords, SP de integración de solicitudes, UI WPF y medición de carga. Esta referencia no certifica esas capacidades como entregadas al ejecutable.

## Referencias primarias verificadas

- [Eventos DDL](https://learn.microsoft.com/en-us/sql/relational-databases/triggers/ddl-events?view=sql-server-ver17): eventos y procedimientos de sistema que pueden dispararlos.
- [Grupos DDL y cobertura servidor/base](https://learn.microsoft.com/en-us/sql/relational-databases/triggers/ddl-event-groups?view=sql-server-ver17).
- [EVENTDATA](https://learn.microsoft.com/en-us/sql/t-sql/functions/eventdata-transact-sql): campos y ocultamiento de passwords CREATE/ALTER LOGIN.
- [sp_set_session_context](https://learn.microsoft.com/en-us/sql/relational-databases/system-stored-procedures/sp-set-session-context-transact-sql): cualquier usuario puede establecer el contexto de su sesión.
- [SESSION_CONTEXT](https://learn.microsoft.com/en-us/sql/t-sql/functions/session-context-transact-sql): restricciones de MARS y problemas conocidos según versión/CU.
- [Grupos de SQL Server Audit](https://learn.microsoft.com/en-us/sql/relational-databases/security/auditing/sql-server-audit-action-groups-and-actions): grupo específico de cambios de contraseña.
- [fn_get_audit_file](https://learn.microsoft.com/en-us/sql/relational-databases/system-functions/sys-fn-get-audit-file-transact-sql): fragmentos, campos de identificación y alcance de succeeded.
- [Creación de Audit y especificaciones](https://learn.microsoft.com/en-us/sql/relational-databases/security/auditing/create-a-server-audit-and-server-audit-specification?view=sql-server-ver17): permisos y habilitación.

