/* REFERENCIA: requiere 01_ModeloCentral.sql. No otorga permisos automáticamente.
   Los SP de escritura se ejecutan solo por identidades/roles indicados en README.
   No revocan, deshabilitan ni cierran accesos por vencimiento. */
USE [adminDB];
GO
CREATE OR ALTER PROCEDURE access.usp_TemporaryAccess_DetectExpired @BatchSize int=500
AS
BEGIN
    SET NOCOUNT ON; SET XACT_ABORT ON;
    -- Disponible al refrescar Resumen para cualquier identidad autorizada.
    -- Un futuro job usa un wrapper firmado y dedicado, no un usuario sin autorización.
    EXEC access.usp_App_RequirePermission 'READ';
    IF @BatchSize IS NULL OR @BatchSize NOT BETWEEN 1 AND 2000
        THROW 51701,'BatchSize fuera de rango.',1;
    DECLARE @Now datetime2(7)=SYSUTCDATETIME(),@LockResult int;
    BEGIN TRY
        BEGIN TRANSACTION;
        EXEC @LockResult=sys.sp_getapplock @Resource=N'SqlAccessAdmin.DetectExpired',
            @LockMode='Exclusive',@LockOwner='Transaction',@LockTimeout=1000;
        IF @LockResult<0 THROW 51702,'Otro evaluador está trabajando. Reintente.',1;
        INSERT access.SecurityAlert(AlertType,AlertKey,TemporaryAccessId,TemporaryRevision,
                                   Severity,OccurredAtUtc)
        SELECT TOP (@BatchSize) 'TEMPORARY_EXPIRED',k.AlertKey,
               t.TemporaryAccessId,t.Revision,'WARNING',t.ExpiresAtUtc
        FROM access.TemporaryAccess t WITH(UPDLOCK,HOLDLOCK)
        CROSS APPLY(SELECT CONVERT(binary(32),HASHBYTES('SHA2_256',CONCAT(
            'TEMP:',t.TemporaryAccessId,':',t.Revision))) AS AlertKey) k
        WHERE t.IsOpen=1 AND t.ExpiresAtUtc<=@Now
          AND NOT EXISTS(SELECT 1 FROM access.SecurityAlert a
              WHERE a.AlertType='TEMPORARY_EXPIRED' AND a.AlertKey=k.AlertKey AND a.IsActive=1)
        ORDER BY t.ExpiresAtUtc,t.TemporaryAccessId;
        DECLARE @Inserted int=@@ROWCOUNT;
        COMMIT;
        SELECT @Inserted AS CreatedAlerts,@Now AS EvaluatedAtUtc;
    END TRY
    BEGIN CATCH
        IF XACT_STATE()<>0 ROLLBACK;
        THROW;
    END CATCH;
END;
GO
CREATE OR ALTER PROCEDURE access.usp_SecurityAlert_List @Take int=100
AS
BEGIN
    SET NOCOUNT ON;
    EXEC access.usp_App_RequirePermission 'READ';
    IF @Take IS NULL OR @Take NOT BETWEEN 1 AND 500 THROW 51703,'Take fuera de rango.',1;
    -- El resumen devuelve contadores agregados; no expone secretos ni credenciales.
    SELECT AlertType,COUNT_BIG(*) AS ActiveCount FROM access.SecurityAlert
    WHERE IsActive=1 GROUP BY AlertType;
    -- Detalle operativo reservado al administrador; el auditor usa su SP de reporte.
    IF access.ufn_App_HasPermission('ADMIN')=1
        SELECT TOP (@Take) a.AlertId,a.AlertType,a.Severity,a.DetectedAtUtc,a.OccurredAtUtc,
            a.ObservedCount,a.TemporaryAccessId,t.ServerId,t.PrincipalName,t.ExpiresAtUtc,
            a.SourceId,a.BusinessDate,a.RowVersion
        FROM access.SecurityAlert a LEFT JOIN access.TemporaryAccess t ON t.TemporaryAccessId=a.TemporaryAccessId
        WHERE a.IsActive=1 ORDER BY a.DetectedAtUtc DESC,a.AlertId DESC;
END;
GO
-- Solo recolector de confianza. Su identidad requiere pertenecer a este rol dedicado.
-- No agregar los roles generales del cliente a SecurityEvidenceCollector.
IF DATABASE_PRINCIPAL_ID(N'SecurityEvidenceCollector') IS NULL
    CREATE ROLE SecurityEvidenceCollector AUTHORIZATION dbo;
GO
CREATE OR ALTER PROCEDURE access.usp_PasswordChange_AppendConfirmed
    @SourceId uniqueidentifier,@NativeEventKey binary(32),@PrincipalSid varbinary(85),
    @PrincipalName nvarchar(256),@Actor nvarchar(256),@OccurredAtUtc datetime2(7),
    @EvidenceReference nvarchar(2000)
AS
BEGIN
    SET NOCOUNT ON; SET XACT_ABORT ON;
    IF ISNULL(IS_ROLEMEMBER(N'SecurityEvidenceCollector'),0)<>1
        THROW 51704,'Se requiere la identidad del recolector.',1;
    IF @SourceId IS NULL OR @NativeEventKey IS NULL OR @PrincipalSid IS NULL OR DATALENGTH(@PrincipalSid)=0
        OR NULLIF(LTRIM(RTRIM(@PrincipalName)),N'') IS NULL
        OR NULLIF(LTRIM(RTRIM(@Actor)),N'') IS NULL OR @OccurredAtUtc IS NULL
        OR NULLIF(LTRIM(RTRIM(@EvidenceReference)),N'') IS NULL
        THROW 51705,'Evidencia de cambio incompleta.',1;
    DECLARE @Zone sysname=(SELECT BusinessTimeZone FROM access.SecurityEvidenceSource WHERE SourceId=@SourceId AND Active=1);
    IF @Zone IS NULL OR NOT EXISTS(SELECT 1 FROM sys.time_zone_info WHERE name=@Zone)
        THROW 51705,'Origen inactivo o zona horaria inválida.',1;
    DECLARE @Day date=CONVERT(date,(@OccurredAtUtc AT TIME ZONE 'UTC') AT TIME ZONE @Zone),
        @Count bigint,@LockResult int,
        @AlertKey binary(32)=CONVERT(binary(32),HASHBYTES('SHA2_256',CONCAT(
            CONVERT(nvarchar(36),@SourceId),':',CONVERT(varchar(170),@PrincipalSid,2),':',
            CONVERT(char(10),CONVERT(date,(@OccurredAtUtc AT TIME ZONE 'UTC') AT TIME ZONE @Zone),23))));
    DECLARE @Resource nvarchar(255)=CONCAT(N'SqlAccessAdmin.PasswordDay.',CONVERT(varchar(64),@AlertKey,2));
    BEGIN TRY
        BEGIN TRANSACTION;
        EXEC @LockResult=sys.sp_getapplock @Resource=@Resource,@LockMode='Exclusive',
            @LockOwner='Transaction',@LockTimeout=5000;
        IF @LockResult<0 THROW 51706,'No se pudo serializar el contador diario.',1;
        IF EXISTS(SELECT 1 FROM access.PasswordChangeHistory WITH(UPDLOCK,HOLDLOCK)
                  WHERE SourceId=@SourceId AND NativeEventKey=@NativeEventKey)
        BEGIN
            IF NOT EXISTS(SELECT 1 FROM access.PasswordChangeHistory WHERE SourceId=@SourceId
                AND NativeEventKey=@NativeEventKey AND PrincipalSid=@PrincipalSid
                AND OccurredAtUtc=@OccurredAtUtc AND Actor=@Actor AND PrincipalName=@PrincipalName
                AND BusinessDate=@Day AND BusinessTimeZone=@Zone)
                THROW 51707,'La clave de evidencia ya existe con datos distintos.',1;
            IF EXISTS(SELECT 1 FROM access.PasswordChangeHistory WHERE SourceId=@SourceId
                AND NativeEventKey=@NativeEventKey AND Confirmation='CONFIRMED')
            BEGIN
                COMMIT;
                RETURN; -- entrega repetida: no vuelve a contar
            END;
            IF EXISTS(SELECT 1 FROM access.PasswordChangeHistory WHERE SourceId=@SourceId
                AND NativeEventKey=@NativeEventKey AND Confirmation='FAILED')
                THROW 51707,'La evidencia estaba clasificada como fallida; requiere conciliación explícita.',1;
            -- Promover observación pendiente una sola vez; la evidencia nativa debe
            -- conservar el historial de clasificación fuera de este resumen mutable.
            UPDATE access.PasswordChangeHistory SET Confirmation='CONFIRMED',EvidenceReference=@EvidenceReference
            WHERE SourceId=@SourceId AND NativeEventKey=@NativeEventKey;
        END
        ELSE
            INSERT access.PasswordChangeHistory(SourceId,NativeEventKey,PrincipalSid,PrincipalName,Actor,
                OccurredAtUtc,BusinessDate,BusinessTimeZone,EvidenceReference,Confirmation)
            VALUES(@SourceId,@NativeEventKey,@PrincipalSid,@PrincipalName,@Actor,@OccurredAtUtc,@Day,@Zone,@EvidenceReference,'CONFIRMED');
        UPDATE access.PasswordChangeDaily SET ChangeCount=ChangeCount+1,
            PrincipalName=@PrincipalName,LastChangeUtc=CASE WHEN LastChangeUtc>@OccurredAtUtc THEN LastChangeUtc ELSE @OccurredAtUtc END
        WHERE SourceId=@SourceId AND PrincipalSid=@PrincipalSid AND BusinessDate=@Day;
        IF @@ROWCOUNT=0
            INSERT access.PasswordChangeDaily VALUES(@SourceId,@PrincipalSid,@Day,@PrincipalName,1,@OccurredAtUtc);
        SELECT @Count=ChangeCount FROM access.PasswordChangeDaily
        WHERE SourceId=@SourceId AND PrincipalSid=@PrincipalSid AND BusinessDate=@Day;
        IF @Count>=3
        BEGIN
            UPDATE access.SecurityAlert SET ObservedCount=@Count
            WHERE AlertType='PASSWORD_FREQUENCY' AND AlertKey=@AlertKey AND IsActive=1;
            IF @@ROWCOUNT=0
                INSERT access.SecurityAlert(AlertType,AlertKey,SourceId,PrincipalSid,BusinessDate,
                    Severity,OccurredAtUtc,ObservedCount)
                VALUES('PASSWORD_FREQUENCY',@AlertKey,@SourceId,@PrincipalSid,@Day,'HIGH',@OccurredAtUtc,@Count);
        END;
        COMMIT;
        SELECT @Count AS ChangesOnBusinessDate,@Day AS BusinessDate;
    END TRY
    BEGIN CATCH
        IF XACT_STATE()<>0 ROLLBACK;
        THROW;
    END CATCH;
END;
GO
GRANT EXECUTE ON OBJECT::access.usp_PasswordChange_AppendConfirmed TO SecurityEvidenceCollector;
GO
CREATE OR ALTER PROCEDURE access.usp_Report_PasswordChanges @FromDate date,@ToDate date,@Take int=100
AS
BEGIN
    SET NOCOUNT ON;
    EXEC access.usp_App_RequirePermission 'AUDIT';
    IF @FromDate IS NULL OR @ToDate IS NULL OR @FromDate>@ToDate
        OR DATEDIFF(day,@FromDate,@ToDate)>366 OR @Take IS NULL OR @Take NOT BETWEEN 1 AND 1000
        THROW 51708,'Rango de reporte inválido (máximo 367 días inclusivos).',1;
    SELECT TOP (@Take) d.SourceId,s.SourceName,d.PrincipalSid,
        MAX(d.PrincipalName) AS PrincipalName,SUM(d.ChangeCount) AS TotalChanges,
        MAX(d.ChangeCount) AS HighestDailyCount,
        SUM(CASE WHEN d.ChangeCount>=3 THEN CONVERT(bigint,1) ELSE 0 END) AS DaysAtThreshold,
        MAX(d.LastChangeUtc) AS LastChangeUtc
    FROM access.PasswordChangeDaily d JOIN access.SecurityEvidenceSource s ON s.SourceId=d.SourceId
    WHERE d.BusinessDate>=@FromDate AND d.BusinessDate<=@ToDate
    GROUP BY d.SourceId,s.SourceName,d.PrincipalSid
    ORDER BY TotalChanges DESC,HighestDailyCount DESC,d.SourceId,d.PrincipalSid;
END;
GO
-- Conceder EXECUTE de detección/listado al rol técnico del cliente tras revisión DBA.
-- Conceder EXECUTE del reporte al rol técnico de auditoría. Las guardas SQL siguen vigentes.
-- Faltan adrede los SP de alta/extensión/cierre: requieren el contrato aprobado descrito
-- en README; no aceptar un simple @IsClosed enviado por el cliente.
