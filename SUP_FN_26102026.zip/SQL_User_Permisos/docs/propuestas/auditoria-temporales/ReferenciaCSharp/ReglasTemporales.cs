namespace SqlAccessAdmin.DesignReference;

public enum TemporaryReviewState { Active, ExpiredPendingReview, Closed }

public sealed record TemporaryAccessSnapshot(
    long Id, bool IsOpen, DateTimeOffset ExpiresAtUtc, int Revision, byte[] RowVersion);

public static class TemporaryAccessRules
{
    public static TemporaryReviewState State(TemporaryAccessSnapshot access, DateTimeOffset nowUtc)
        => !access.IsOpen ? TemporaryReviewState.Closed
         : access.ExpiresAtUtc <= nowUtc ? TemporaryReviewState.ExpiredPendingReview
         : TemporaryReviewState.Active;

    // DatePicker + campo hora representan la zona corporativa, no necesariamente
    // la zona del equipo WPF. Para horas ambiguas solicitar al usuario el offset.
    public static DateTimeOffset ToUtc(DateTime localDateAndTime, TimeZoneInfo businessZone)
    {
        var local = DateTime.SpecifyKind(localDateAndTime, DateTimeKind.Unspecified);
        if (businessZone.IsInvalidTime(local) || businessZone.IsAmbiguousTime(local))
            throw new ArgumentException("Hora local inexistente o ambigua; seleccione una hora/offset válido.");
        return new DateTimeOffset(TimeZoneInfo.ConvertTimeToUtc(local, businessZone));
    }

    public static DateOnly BusinessDay(DateTimeOffset occurredAtUtc, TimeZoneInfo businessZone)
        => DateOnly.FromDateTime(TimeZoneInfo.ConvertTime(occurredAtUtc, businessZone).DateTime);

    public static bool PasswordAlertRequired(long confirmedChangesOnDay) => confirmedChangesOnDay >= 3;
}

// Contratos de aplicación PROPUESTOS: implementarlos mediante AdminDbGateway.
// No se ofrecen métodos SetClosed(bool) o DismissExpiryAlert desde la interfaz.
public sealed record TemporaryActionDraft(
    long TemporaryAccessId, byte[] ExpectedRowVersion, string Ticket,
    string Action, DateTimeOffset? NewExpiresAtUtc, string Reason);

public sealed record AlertCounts(long ExpiredAccesses, long PasswordFrequency, DateTimeOffset EvaluatedAtUtc);

public interface ITemporaryAccessWorkflow
{
    // Crea solicitud: no aplica ni resuelve todavía. Action es EXTEND o CLOSE.
    Task<long> SubmitActionAsync(TemporaryActionDraft draft, CancellationToken cancellationToken);
    Task<IReadOnlyList<TemporaryAccessSnapshot>> ListAsync(CancellationToken cancellationToken);
}

public interface ISecurityAlertStore
{
    Task<int> DetectExpiredAsync(int batchSize, CancellationToken cancellationToken);
    Task<AlertCounts> ReadCountsAsync(CancellationToken cancellationToken);
}

// Compartir una instancia a nivel de sesión entre Resumen y Usuarios temporales.
// El intervalo lo controla un servicio de sesión; no un timer por fila o ventana.
public sealed class SecurityAlertRefreshService(ISecurityAlertStore store) : IDisposable
{
    private readonly SemaphoreSlim _gate = new(1, 1);

    public async Task<AlertCounts?> RefreshAsync(CancellationToken cancellationToken)
    {
        if (!await _gate.WaitAsync(0, cancellationToken)) return null;
        try
        {
            // Acotar trabajo por refresco: procesar atrasos con un worker independiente.
            await store.DetectExpiredAsync(500, cancellationToken);
            return await store.ReadCountsAsync(cancellationToken);
        }
        finally { _gate.Release(); }
    }

    // Cancelar y esperar tareas activas ANTES de Dispose al cerrar/bloquear la sesión.
    public void Dispose() => _gate.Dispose();
}
