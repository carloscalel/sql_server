using System.Data;
using Microsoft.Data.SqlClient;

namespace SqlAccessAdmin.DesignReference;

// Referencia, fuera del ejecutable WPF. Etiqueta cada conexión real de escritura.
// No valida una aprobación, no genera recibos confiables y no reemplaza las
// guardas de política/autorización de ExecuteApprovedRequestAsync.
public static class SessionAuditScope
{
    public static async Task<T> RunAsync<T>(
        string connectionString, long requestId, Guid operationId, string appActor,
        Func<SqlConnection, CancellationToken, Task<T>> execute,
        CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(execute);
        ArgumentException.ThrowIfNullOrWhiteSpace(appActor);
        if (appActor.Length > 256) throw new ArgumentException("Actor demasiado largo.", nameof(appActor));
        if (requestId <= 0 || operationId == Guid.Empty)
            throw new ArgumentException("Solicitud y operación son obligatorias.");
        var builder = new SqlConnectionStringBuilder(connectionString)
        {
            ApplicationName = "SqlAccessAdmin-Direct",
            MultipleActiveResultSets = false
        };
        await using var connection = new SqlConnection(builder.ConnectionString);
        await connection.OpenAsync(cancellationToken);
        try
        {
            await using var tag = new SqlCommand("""
                EXEC sys.sp_set_session_context @key=N'SAA.Origin',@value=N'SQLAccessAdmin',@read_only=0;
                EXEC sys.sp_set_session_context @key=N'SAA.RequestId',@value=@request,@read_only=0;
                EXEC sys.sp_set_session_context @key=N'SAA.OperationId',@value=@operation,@read_only=0;
                EXEC sys.sp_set_session_context @key=N'SAA.Actor',@value=@actor,@read_only=0;
                """, connection) { CommandTimeout = 10 };
            tag.Parameters.Add("@request", SqlDbType.BigInt).Value = requestId;
            tag.Parameters.Add("@operation", SqlDbType.UniqueIdentifier).Value = operationId;
            tag.Parameters.Add("@actor", SqlDbType.NVarChar, 256).Value = appActor;
            await tag.ExecuteNonQueryAsync(cancellationToken);
            // Debe ejecutar con ESTA conexión; abrir otra pierde SESSION_CONTEXT.
            // El delegado controla transacción, recibo, orden tipada y resultado.
            return await execute(connection, cancellationToken);
        }
        finally
        {
            // Se intenta incluso si se canceló la operación; no usar su token cancelado.
            try
            {
                await using var clear = new SqlCommand("""
                    EXEC sys.sp_set_session_context @key=N'SAA.Origin',@value=NULL;
                    EXEC sys.sp_set_session_context @key=N'SAA.RequestId',@value=NULL;
                    EXEC sys.sp_set_session_context @key=N'SAA.OperationId',@value=NULL;
                    EXEC sys.sp_set_session_context @key=N'SAA.Actor',@value=NULL;
                    """, connection) { CommandTimeout = 5 };
                await clear.ExecuteNonQueryAsync(CancellationToken.None);
            }
            catch
            {
                // No ocultar una excepción anterior ni reutilizar una sesión contaminada.
                // ClearPool marca las conexiones en uso para descartarlas al cerrar.
                SqlConnection.ClearPool(connection);
            }
        }
    }
}
