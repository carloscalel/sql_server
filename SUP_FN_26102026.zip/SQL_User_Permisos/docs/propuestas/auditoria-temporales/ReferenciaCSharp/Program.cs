using SqlAccessAdmin.DesignReference;

// Comprobaciones de reglas puras. No abre conexiones ni prueba triggers/SQL/WPF.
var count = 0;
void Check(bool condition, string message)
{
    if (!condition) throw new InvalidOperationException(message);
    count++;
}

var expires = new DateTimeOffset(2026, 10, 23, 6, 0, 0, TimeSpan.Zero);
var access = new TemporaryAccessSnapshot(1, true, expires, 1, new byte[8]);
Check(TemporaryAccessRules.State(access, expires.AddTicks(-1)) == TemporaryReviewState.Active, "Antes del límite.");
Check(TemporaryAccessRules.State(access, expires) == TemporaryReviewState.ExpiredPendingReview, "Igualdad en el límite.");
Check(TemporaryAccessRules.State(access, expires.AddYears(1)) == TemporaryReviewState.ExpiredPendingReview, "El vencimiento persiste.");
Check(access.IsOpen, "Evaluar vencimiento no cierra el acceso.");
Check(TemporaryAccessRules.State(access with { IsOpen = false }, expires) == TemporaryReviewState.Closed, "Cierre explícito.");
Check(!TemporaryAccessRules.PasswordAlertRequired(2), "Dos cambios no generan alerta.");
Check(TemporaryAccessRules.PasswordAlertRequired(3), "Tres cambios generan alerta.");
Check(TemporaryAccessRules.PasswordAlertRequired(4), "Cuatro cambios mantienen alerta.");
var zone = TimeZoneInfo.FindSystemTimeZoneById("Central America Standard Time");
Check(TemporaryAccessRules.BusinessDay(expires.AddTicks(-1), zone) == new DateOnly(2026, 10, 22), "Antes de medianoche Guatemala.");
Check(TemporaryAccessRules.BusinessDay(expires, zone) == new DateOnly(2026, 10, 23), "Medianoche Guatemala.");
Check(TemporaryAccessRules.ToUtc(new DateTime(2026, 10, 23, 0, 0, 0), zone) == expires, "Convertir captura a UTC.");
var dstZone = TimeZoneInfo.FindSystemTimeZoneById("Eastern Standard Time");
foreach (var local in new[] { new DateTime(2026, 3, 8, 2, 30, 0), new DateTime(2026, 11, 1, 1, 30, 0) })
{
    var rejected = false;
    try { TemporaryAccessRules.ToUtc(local, dstZone); }
    catch (ArgumentException) { rejected = true; }
    Check(rejected, "No interpretar silenciosamente horas DST inexistentes/ambiguas.");
}
Console.WriteLine($"{count} comprobaciones de reglas correctas. No se abrió SQL Server.");
