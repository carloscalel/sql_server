/* REFERENCIA DE DISEÑO; no forma parte de las migraciones de producción.
   Destino: adminDB de laboratorio, después de 32 y 99 vigentes.
   No ejecutar en bloque con InsumosProduccion. No cambia permisos de destinos.
   Instalación inicial: se detiene si el modelo ya existe; no es una migración incremental.
   Consultar README.md para autorización, recolector, confirmación y despliegue. */
USE [adminDB];
GO
SET NOCOUNT ON;
SET XACT_ABORT ON;
IF OBJECT_ID(N'access.usp_App_RequirePermission',N'P') IS NULL
    THROW 51700,'Falta el contrato de autorización múltiple.',1;
IF OBJECT_ID(N'access.SecurityEvidenceSource',N'U') IS NOT NULL
    THROW 51700,'El modelo de referencia ya existe; no reaplicar.',1;
GO
BEGIN TRANSACTION;
CREATE TABLE access.SecurityEvidenceSource
(
    SourceId uniqueidentifier NOT NULL PRIMARY KEY,
    ServerId int NOT NULL REFERENCES access.ManagedServer(ServerId),
    SourceName nvarchar(128) NOT NULL,
    BusinessTimeZone sysname NOT NULL DEFAULT N'Central America Standard Time',
    CoverageStartedUtc datetime2(7) NOT NULL,
    LastSuccessfulCollectionUtc datetime2(7) NULL,
    CollectionCheckpoint nvarchar(2000) NULL,
    Active bit NOT NULL DEFAULT 1,
    CONSTRAINT UQ_SecurityEvidenceSource_Server UNIQUE(ServerId)
);
-- SourceId representa la instancia instalada, no el nombre mutable de su host.
CREATE TABLE access.SecurityChange
(
    SourceId uniqueidentifier NOT NULL REFERENCES access.SecurityEvidenceSource(SourceId),
    EventId uniqueidentifier NOT NULL,
    OccurredAtUtc datetime2(7) NOT NULL,
    ReceivedAtUtc datetime2(7) NOT NULL DEFAULT SYSUTCDATETIME(),
    DatabaseName sysname NULL,
    EngineEventType nvarchar(128) NOT NULL,
    OriginalLogin nvarchar(256) NOT NULL,
    EffectiveLogin nvarchar(256) NULL,
    ClientApplication nvarchar(128) NULL,
    ClientHost nvarchar(128) NULL,
    ClaimedOrigin varchar(16) NOT NULL,
    OriginVerified bit NOT NULL DEFAULT 0,
    OperationId uniqueidentifier NULL,
    RequestId bigint NULL REFERENCES access.AccessRequest(RequestId),
    TargetPrincipal nvarchar(256) NULL,
    TargetSid varbinary(85) NULL,
    CommandText nvarchar(max) NULL,
    ChangesJson nvarchar(max) NULL,
    EvidenceState varchar(20) NOT NULL,
    CONSTRAINT PK_SecurityChange PRIMARY KEY(SourceId,EventId),
    CONSTRAINT CK_SecurityChange_Origin CHECK(ClaimedOrigin IN('APP','SSMS','EXTERNAL')),
    CONSTRAINT CK_SecurityChange_State CHECK(EvidenceState IN('COMMITTED','OBSERVED','UNRESOLVED')),
    CONSTRAINT CK_SecurityChange_Json CHECK(ChangesJson IS NULL OR ISJSON(ChangesJson)=1)
);
CREATE INDEX IX_SecurityChange_Date ON access.SecurityChange(OccurredAtUtc DESC)
    INCLUDE(SourceId,TargetPrincipal,EngineEventType,ClaimedOrigin);
CREATE INDEX IX_SecurityChange_Operation ON access.SecurityChange(OperationId)
    WHERE OperationId IS NOT NULL;
CREATE TABLE access.TemporaryAccess
(
    TemporaryAccessId bigint IDENTITY PRIMARY KEY,
    ServerId int NOT NULL REFERENCES access.ManagedServer(ServerId),
    PrincipalSid varbinary(85) NOT NULL,
    PrincipalName nvarchar(256) NOT NULL,
    AccessKind varchar(20) NOT NULL,
    DatabaseName sysname NULL,
    ScopeType varchar(30) NULL,
    Securable nvarchar(776) NULL,
    PermissionName nvarchar(128) NULL,
    RoleName sysname NULL,
    GrantedAtUtc datetime2(7) NOT NULL,
    ExpiresAtUtc datetime2(7) NOT NULL,
    InputTimeZone sysname NOT NULL,
    IsOpen bit NOT NULL DEFAULT 1,
    Revision int NOT NULL DEFAULT 1,
    CreatedRequestId bigint NOT NULL REFERENCES access.AccessRequest(RequestId),
    LastActionRequestId bigint NOT NULL REFERENCES access.AccessRequest(RequestId),
    LastVerifiedAtUtc datetime2(7) NULL,
    ClosedAtUtc datetime2(7) NULL,
    ClosedBy nvarchar(256) NULL,
    RowVersion rowversion NOT NULL,
    CONSTRAINT CK_TemporaryAccess_Kind CHECK(AccessKind IN('LOGIN','DATABASE_USER','PERMISSION','ROLE_MEMBERSHIP')),
    CONSTRAINT CK_TemporaryAccess_Expiry CHECK(ExpiresAtUtc>GrantedAtUtc),
    CONSTRAINT CK_TemporaryAccess_Revision CHECK(Revision>0),
    CONSTRAINT CK_TemporaryAccess_Closed CHECK(
        (IsOpen=1 AND ClosedAtUtc IS NULL AND ClosedBy IS NULL)
        OR (IsOpen=0 AND ClosedAtUtc IS NOT NULL AND ClosedBy IS NOT NULL)),
    CONSTRAINT CK_TemporaryAccess_Permission CHECK(AccessKind<>'PERMISSION'
        OR (PermissionName IS NOT NULL AND ScopeType IS NOT NULL)),
    CONSTRAINT CK_TemporaryAccess_Role CHECK(AccessKind<>'ROLE_MEMBERSHIP' OR RoleName IS NOT NULL)
);
CREATE INDEX IX_TemporaryAccess_Due ON access.TemporaryAccess(ExpiresAtUtc,TemporaryAccessId)
    INCLUDE(ServerId,PrincipalName,Revision) WHERE IsOpen=1;
-- Parte INMUTABLE de la solicitud revisada. Crear junto a AccessRequest en su
-- transacción; no permitir actualizar una fecha después de aprobarla.
CREATE TABLE access.TemporaryAccessRequestTerm
(
    RequestId bigint NOT NULL REFERENCES access.AccessRequest(RequestId),
    StepOrdinal int NOT NULL,
    TemporaryAccessId bigint NULL REFERENCES access.TemporaryAccess(TemporaryAccessId),
    ActionCode varchar(10) NOT NULL,
    ExpectedRevision int NULL,
    ExpectedRowVersion binary(8) NULL,
    NewExpiresAtUtc datetime2(7) NULL,
    InputTimeZone sysname NULL,
    ResourceJson nvarchar(max) NOT NULL CHECK(ISJSON(ResourceJson)=1),
    AppliedSourceId uniqueidentifier NULL,
    AppliedEventId uniqueidentifier NULL,
    AppliedAtUtc datetime2(7) NULL,
    CONSTRAINT PK_TemporaryAccessRequestTerm PRIMARY KEY(RequestId,StepOrdinal),
    CONSTRAINT CK_TemporaryAccessRequestTerm_Action CHECK(ActionCode IN('CREATE','EXTEND','CLOSE')),
    CONSTRAINT CK_TemporaryAccessRequestTerm_Subject CHECK(
        (ActionCode='CREATE' AND TemporaryAccessId IS NULL)
        OR (ActionCode IN('EXTEND','CLOSE') AND TemporaryAccessId IS NOT NULL
            AND ExpectedRevision IS NOT NULL AND ExpectedRowVersion IS NOT NULL)),
    CONSTRAINT CK_TemporaryAccessRequestTerm_Expiry CHECK(
        ActionCode='CLOSE' OR (NewExpiresAtUtc IS NOT NULL AND InputTimeZone IS NOT NULL)),
    CONSTRAINT FK_TemporaryAccessRequestTerm_Event FOREIGN KEY(AppliedSourceId,AppliedEventId)
        REFERENCES access.SecurityChange(SourceId,EventId)
);
-- Identidad lógica de recurso y deduplicación de vigencias: validar en el SP de alta
-- mediante clave canónica (SID + servidor + base + ámbito + objeto/columna + permiso/rol).
CREATE TABLE access.SecurityAlert
(
    AlertId bigint IDENTITY PRIMARY KEY,
    AlertType varchar(24) NOT NULL,
    AlertKey binary(32) NOT NULL,
    TemporaryAccessId bigint NULL REFERENCES access.TemporaryAccess(TemporaryAccessId),
    TemporaryRevision int NULL,
    SourceId uniqueidentifier NULL REFERENCES access.SecurityEvidenceSource(SourceId),
    PrincipalSid varbinary(85) NULL,
    BusinessDate date NULL,
    Severity varchar(10) NOT NULL,
    DetectedAtUtc datetime2(7) NOT NULL DEFAULT SYSUTCDATETIME(),
    OccurredAtUtc datetime2(7) NOT NULL,
    ObservedCount bigint NULL,
    IsActive bit NOT NULL DEFAULT 1,
    ResolvedAtUtc datetime2(7) NULL,
    ResolvedBy nvarchar(256) NULL,
    ResolutionRequestId bigint NULL REFERENCES access.AccessRequest(RequestId),
    ResolutionReason nvarchar(1000) NULL,
    RowVersion rowversion NOT NULL,
    CONSTRAINT CK_SecurityAlert_Type CHECK(AlertType IN('TEMPORARY_EXPIRED','PASSWORD_FREQUENCY')),
    CONSTRAINT CK_SecurityAlert_Resolved CHECK(
        (IsActive=1 AND ResolvedAtUtc IS NULL AND ResolvedBy IS NULL)
        OR (IsActive=0 AND ResolvedAtUtc IS NOT NULL AND ResolvedBy IS NOT NULL)),
    CONSTRAINT CK_SecurityAlert_Subject CHECK(
        (AlertType='TEMPORARY_EXPIRED' AND TemporaryAccessId IS NOT NULL AND TemporaryRevision IS NOT NULL)
        OR (AlertType='PASSWORD_FREQUENCY' AND SourceId IS NOT NULL AND PrincipalSid IS NOT NULL AND BusinessDate IS NOT NULL))
);
CREATE UNIQUE INDEX UX_SecurityAlert_Active ON access.SecurityAlert(AlertType,AlertKey) WHERE IsActive=1;
CREATE INDEX IX_SecurityAlert_Active ON access.SecurityAlert(DetectedAtUtc DESC)
    INCLUDE(AlertType,TemporaryAccessId,ObservedCount,Severity) WHERE IsActive=1;
CREATE TABLE access.PasswordChangeHistory
(
    SourceId uniqueidentifier NOT NULL REFERENCES access.SecurityEvidenceSource(SourceId),
    NativeEventKey binary(32) NOT NULL,
    PrincipalSid varbinary(85) NOT NULL,
    PrincipalName nvarchar(256) NOT NULL,
    Actor nvarchar(256) NOT NULL,
    OccurredAtUtc datetime2(7) NOT NULL,
    BusinessDate date NOT NULL,
    BusinessTimeZone sysname NOT NULL,
    EvidenceReference nvarchar(2000) NOT NULL,
    Confirmation varchar(12) NOT NULL,
    CONSTRAINT PK_PasswordChangeHistory PRIMARY KEY(SourceId,NativeEventKey),
    CONSTRAINT CK_PasswordChangeHistory_Confirmation CHECK(Confirmation IN('OBSERVED','CONFIRMED','FAILED','UNRESOLVED'))
);
CREATE INDEX IX_PasswordChangeHistory_Principal ON access.PasswordChangeHistory(SourceId,PrincipalSid,BusinessDate)
    INCLUDE(Confirmation,OccurredAtUtc);
CREATE TABLE access.PasswordChangeDaily
(
    SourceId uniqueidentifier NOT NULL REFERENCES access.SecurityEvidenceSource(SourceId),
    PrincipalSid varbinary(85) NOT NULL,
    BusinessDate date NOT NULL,
    PrincipalName nvarchar(256) NOT NULL,
    ChangeCount bigint NOT NULL,
    LastChangeUtc datetime2(7) NOT NULL,
    CONSTRAINT PK_PasswordChangeDaily PRIMARY KEY(SourceId,PrincipalSid,BusinessDate),
    CONSTRAINT CK_PasswordChangeDaily_Count CHECK(ChangeCount>0)
);
CREATE INDEX IX_PasswordChangeDaily_Date ON access.PasswordChangeDaily(BusinessDate,ChangeCount DESC);
COMMIT;
GO
CREATE OR ALTER VIEW access.v_TemporaryAccessState
AS
SELECT t.*,CASE WHEN IsOpen=0 THEN 'CLOSED'
               WHEN ExpiresAtUtc<=SYSUTCDATETIME() THEN 'EXPIRED_REVIEW'
               ELSE 'ACTIVE' END AS ReviewState
FROM access.TemporaryAccess t;
GO
