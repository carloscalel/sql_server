/* PLANTILLA: no ejecutar sin configurar directorio local, permisos del servicio,
   capacidad, retención y política ON_FAILURE. Captura evidencia; no cuenta por sí sola
   cambios CONFIRMED. El recolector y su clasificación se describen en README.md. */
USE [master];
GO
-- REEMPLAZAR por una carpeta preexistente accesible al servicio SQL Server.
CREATE SERVER AUDIT SqlAccessAdmin_PasswordEvidence
TO FILE(FILEPATH=N'__CONFIGURAR_DIRECTORIO_LOCAL__',MAXSIZE=256 MB,MAX_ROLLOVER_FILES=100)
WITH(QUEUE_DELAY=1000,ON_FAILURE=FAIL_OPERATION);
GO
CREATE SERVER AUDIT SPECIFICATION SqlAccessAdmin_PasswordEvidenceSpec
FOR SERVER AUDIT SqlAccessAdmin_PasswordEvidence
ADD(LOGIN_CHANGE_PASSWORD_GROUP),ADD(AUDIT_CHANGE_GROUP)
WITH(STATE=OFF);
GO
-- Activar únicamente tras completar las pruebas de fallos/secretos/retención.
-- ALTER SERVER AUDIT SqlAccessAdmin_PasswordEvidence WITH(STATE=ON);
-- ALTER SERVER AUDIT SPECIFICATION SqlAccessAdmin_PasswordEvidenceSpec WITH(STATE=ON);

-- Descubrir acciones por grupo en la versión real; no asumir todos los ALTER LOGIN.
SELECT action_id,name,class_desc,covering_action_name
FROM sys.dm_audit_actions
WHERE covering_action_name=N'LOGIN_CHANGE_PASSWORD_GROUP';
GO
-- Ejemplo de lectura (la ruta definitiva pertenece al recolector):
-- SELECT event_time,action_id,succeeded,session_id,transaction_id,
--        server_principal_name,target_server_principal_name,target_server_principal_sid,
--        file_name,audit_file_offset,sequence_number,sequence_group_id
-- FROM sys.fn_get_audit_file(N'RUTA_LOCAL\*.sqlaudit',DEFAULT,DEFAULT);
-- No copiar statement, passwords ni hashes al historial de contraseñas.
-- succeeded refleja la comprobación de permisos en eventos distintos de login;
-- no constituye confirmación general del resultado o COMMIT del cambio.
