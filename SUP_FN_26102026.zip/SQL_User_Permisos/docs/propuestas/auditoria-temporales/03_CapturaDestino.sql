/* REFERENCIA PARA LABORATORIO SQL SERVER (no Azure SQL Database).
   Ejecutar en CADA instancia destino después de crear manualmente una base local
   SqlAccessEvidence con respaldo, espacio y permisos revisados. No usar adminDB remoto.
   El trigger se instala DESHABILITADO. Falta aprovisionamiento/firma de módulos.
   No habilitar hasta probar permisos de captura con cada identidad externa.
   Nunca activar TRUSTWORTHY ni cross db ownership chaining para resolver permisos. */
USE [SqlAccessEvidence];
GO
IF SCHEMA_ID(N'capture') IS NULL EXEC(N'CREATE SCHEMA capture AUTHORIZATION dbo;');
GO
CREATE TABLE capture.Configuration
(
    SingletonId tinyint NOT NULL PRIMARY KEY CHECK(SingletonId=1),
    SourceId uniqueidentifier NOT NULL UNIQUE
);
-- Registrar ESTE mismo SourceId en adminDB.access.SecurityEvidenceSource.
INSERT capture.Configuration VALUES(1,NEWID());
CREATE TABLE capture.ExecutionReceipt
(
    OperationId uniqueidentifier NOT NULL PRIMARY KEY,
    RequestId bigint NOT NULL,
    StepOrdinal int NOT NULL,
    SessionId int NOT NULL,
    TransactionId bigint NOT NULL,
    OriginalLoginSid varbinary(85) NOT NULL,
    ExpectedEventType nvarchar(128) NOT NULL,
    DatabaseName sysname NULL,
    ExpectedCommandHash binary(32) NOT NULL,
    StructuredChangesJson nvarchar(max) NOT NULL CHECK(ISJSON(StructuredChangesJson)=1),
    ExpiresAtUtc datetime2(7) NOT NULL,
    ConsumedEventId uniqueidentifier NULL
);
-- La app NO recibe INSERT/UPDATE sobre ExecutionReceipt.
-- Un ejecutor confiable/firma verificada crea el recibo para una orden aprobada,
-- en la MISMA transacción y conexión. No se proporciona un SP que acepte
-- arbitrariamente RequestId/JSON y los dé por autorizados.
CREATE TABLE capture.SecurityOutbox
(
    LocalSequence bigint IDENTITY NOT NULL PRIMARY KEY,
    EventId uniqueidentifier NOT NULL UNIQUE,
    OccurredAtUtc datetime2(7) NOT NULL,
    SessionId int NOT NULL,
    TransactionId bigint NOT NULL,
    EventType nvarchar(128) NOT NULL,
    DatabaseName sysname NULL,
    ObjectName nvarchar(256) NULL,
    OriginalLogin nvarchar(256) NOT NULL,
    EffectiveLogin nvarchar(256) NULL,
    ClientApplication nvarchar(128) NULL,
    ClientHost nvarchar(128) NULL,
    ClaimedOrigin varchar(16) NOT NULL,
    OriginVerified bit NOT NULL,
    OperationId uniqueidentifier NULL,
    RequestId bigint NULL,
    CommandText nvarchar(max) NULL,
    StructuredChangesJson nvarchar(max) NULL,
    DeliveredAtUtc datetime2(7) NULL
);
CREATE INDEX IX_SecurityOutbox_Undelivered ON capture.SecurityOutbox(LocalSequence)
    WHERE DeliveredAtUtc IS NULL;
GO
USE [master];
GO
CREATE OR ALTER TRIGGER tr_SqlAccessAdmin_SecurityCapture
ON ALL SERVER
FOR DDL_SERVER_SECURITY_EVENTS, DDL_DATABASE_SECURITY_EVENTS
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @Data xml=EVENTDATA(),@EventId uniqueidentifier=NEWID(),
        @Now datetime2(7)=SYSUTCDATETIME(),@TransactionId bigint;
    -- DMV de la transacción actual: el módulo firmado requiere los permisos
    -- correspondientes a la versión. No conceder VIEW SERVER STATE a todos.
    SELECT @TransactionId=transaction_id FROM sys.dm_tran_current_transaction;
    DECLARE @Type nvarchar(128)=@Data.value('(/EVENT_INSTANCE/EventType)[1]','nvarchar(128)'),
        @Db sysname=NULLIF(@Data.value('(/EVENT_INSTANCE/DatabaseName)[1]','nvarchar(128)'),N''),
        @Object nvarchar(256)=@Data.value('(/EVENT_INSTANCE/ObjectName)[1]','nvarchar(256)'),
        @Text nvarchar(max)=@Data.value('(/EVENT_INSTANCE/TSQLCommand/CommandText)[1]','nvarchar(max)'),
        @Claim nvarchar(128)=TRY_CONVERT(nvarchar(128),SESSION_CONTEXT(N'SAA.Origin')),
        @Operation uniqueidentifier=TRY_CONVERT(uniqueidentifier,SESSION_CONTEXT(N'SAA.OperationId')),
        @Verified bit=0,@RequestId bigint=NULL,@Changes nvarchar(max)=NULL;
    -- La comparación exacta solo se propone para comandos no sensibles probados.
    -- Nunca omitir el evento únicamente por APP_NAME o SESSION_CONTEXT.
    IF @Claim=N'SQLAccessAdmin' AND @Operation IS NOT NULL
        AND @Type IN(N'GRANT_DATABASE',N'DENY_DATABASE',N'REVOKE_DATABASE',
                     N'GRANT_SERVER',N'DENY_SERVER',N'REVOKE_SERVER',
                     N'ADD_ROLE_MEMBER',N'DROP_ROLE_MEMBER',
                     N'ADD_SERVER_ROLE_MEMBER',N'DROP_SERVER_ROLE_MEMBER')
    BEGIN
        SELECT @RequestId=RequestId,@Changes=StructuredChangesJson,@Verified=1
        FROM SqlAccessEvidence.capture.ExecutionReceipt WITH(UPDLOCK,HOLDLOCK)
        WHERE OperationId=@Operation AND SessionId=@@SPID AND TransactionId=@TransactionId
          AND OriginalLoginSid=SUSER_SID(ORIGINAL_LOGIN()) AND ExpectedEventType=@Type
          AND ISNULL(DatabaseName,N'') COLLATE Latin1_General_100_BIN2=ISNULL(@Db,N'') COLLATE Latin1_General_100_BIN2
          AND ExpectedCommandHash=HASHBYTES('SHA2_256',@Text)
          AND ExpiresAtUtc>@Now AND ConsumedEventId IS NULL;
    END;
    -- Deny por defecto para texto de eventos sensibles (login, credenciales,
    -- certificados, claves y application roles). Conservar tipo/actor/objeto.
    -- EVENTDATA oculta passwords CREATE/ALTER LOGIN, pero no se extrapola esto
    -- a todo secreto posible. No se persiste el XML completo sin sanitizar.
    IF @Verified=1 OR @Type NOT IN(
        N'GRANT_DATABASE',N'DENY_DATABASE',N'REVOKE_DATABASE',
        N'GRANT_SERVER',N'DENY_SERVER',N'REVOKE_SERVER',
        N'ADD_ROLE_MEMBER',N'DROP_ROLE_MEMBER',N'ADD_SERVER_ROLE_MEMBER',N'DROP_SERVER_ROLE_MEMBER',
        N'CREATE_USER',N'DROP_USER')
        SET @Text=NULL;
    INSERT SqlAccessEvidence.capture.SecurityOutbox
    (EventId,OccurredAtUtc,SessionId,TransactionId,EventType,DatabaseName,ObjectName,
     OriginalLogin,EffectiveLogin,ClientApplication,ClientHost,ClaimedOrigin,OriginVerified,
     OperationId,RequestId,CommandText,StructuredChangesJson)
    VALUES(@EventId,@Now,@@SPID,@TransactionId,@Type,@Db,@Object,ORIGINAL_LOGIN(),SUSER_SNAME(),
        APP_NAME(),HOST_NAME(),CASE WHEN @Claim=N'SQLAccessAdmin' THEN 'APP'
            WHEN APP_NAME() LIKE N'Microsoft SQL Server Management Studio%' THEN 'SSMS' ELSE 'EXTERNAL' END,
        @Verified,@Operation,@RequestId,@Text,@Changes);
    IF @Verified=1
        UPDATE SqlAccessEvidence.capture.ExecutionReceipt SET ConsumedEventId=@EventId WHERE OperationId=@Operation;
    -- Sin CATCH que oculte pérdidas. Un fallo de captura puede rechazar el DDL.
    -- Es la política de laboratorio documentada; evaluar disponibilidad antes de producción.
END;
GO
DISABLE TRIGGER tr_SqlAccessAdmin_SecurityCapture ON ALL SERVER;
GO
-- No añadir triggers de base para los mismos eventos: el de servidor ya los cubre.
-- Como alternativa, desplegar triggers ON DATABASE para sus eventos y quitar
-- DDL_DATABASE_SECURITY_EVENTS del de servidor. Elegir una sola cobertura.
-- IMPORTANTE: LocalSequence no es un orden de commit. Recolectar WHERE
-- DeliveredAtUtc IS NULL; no usar MAX(LocalSequence) como único checkpoint.
