# Validación del seguimiento de la app y metadatos

Revisión: **26 de octubre de 2026, Guatemala**. Contrato central **v4**.

## Resultados ejecutados

| Comprobación | Resultado |
| --- | --- |
| SecurityMonitoringChecks, Release | 65 comprobaciones correctas; sin conexión SQL en este modo. Incluye vigencias, tickets, revisión de alertas, exportaciones, sintaxis SQL y enlaces/renders WPF. |
| ReportsChecks, Release | 243 comprobaciones correctas. |
| LoginPasswordChecks, Release | 38 comprobaciones correctas. |
| Cliente y SecurityMonitoringWorker, Release | Compilación correcta. El worker ya no tiene dependencia de ScriptDom. |
| Laboratorio SQL aislado con el 33 v4 real | Vigencias, revisión, cierre fallido, deduplicación, cuatro contraseñas reales ejecutadas desde C#, umbral 3, revisión de alerta y reentrega sin duplicación. |
| Conciliación de metadatos | Primera consulta como referencia; coincidencia de la app; última contraseña externa sin sumarla al contador; separación entre fecha de definición y fecha de contraseña; otro SID con mismo nombre como referencia nueva. |
| Transacciones y permisos | Registro pendiente antes del COMMIT; confirmación posterior; ROLLED_BACK sin contar; intentos inciertos visibles; importación protegida por permisos; rechazo de reejecución del intento. |
| Reaplicación de 33 v4 | Historial, contadores, referencias y vigencias conservados. |
| Sintaxis de scripts PowerShell | Correcta en RunSqlLab y CheckSqlInstallation. |

Total de cliente/regresión ejecutado: **346 comprobaciones**, más escenarios SQL. Se retiraron pruebas de parser/clasificación de eventos DDL que ya no pertenecen al producto; el número no representa una comparación directa de cobertura con el contrato anterior.

El laboratorio crea únicamente una base y un login con GUID reservado, usa sustitutos de identidad/ticket y la instrumentación real de comandos. Los cambios de contraseña usan el SQL parametrizado que genera WPF. La prueba de conservación de una fecha de definición anterior incluye una referencia controlada, porque no todos los cambios de principal modifican modify_date. No instala captura ni Audit. Elimina su base/login al terminar y no instala el contrato en adminDB real.

Las vistas en `artifacts/security-monitoring-previews` son datos simulados. Se mantiene la advertencia preexistente CS8981 de viewdemo al recompilar por completo.

## Conversión a hora de Guatemala

Se contrastó el esquema de adminDB local mediante una consulta de solo lectura: sus 43 columnas datetime/datetime2 están contempladas en la conversión o la normalización de metadatos. No se aplicó la migración a esa base.

El laboratorio parte del contrato UTC anterior y ejecuta 36 y 33 v4. Verifica que 23:05 se almacene como 17:05 en tablas base, vigencias, ejecución y metadatos; conserva los hashes originales, valida eventos nuevos en la misma cadena y detecta alteraciones de la fecha local visible. Verifica que medianoche local separe el contador sin desplazar seis horas adicionales. Reaplicar 36/33 conserva las horas y la integridad.

## Alcance y activación pendiente

La fuente Aplicación acredita una gestión registrada y su resultado. Solo los cambios de contraseña CONFIRMED suman. Una última fecha Externo significa sin registro coincidente en la app, no una prueba de origen ni un historial de SSMS. No se inventan actor, operación ni cantidad de cambios externos.

La primera lectura no genera una modificación externa histórica. Un SID distinto no hereda la referencia de otra identidad. Pérdida de visibilidad o base inaccesible conserva los datos anteriores y produce un aviso; no se deducen bajas. Un comando pendiente/incierto difiere su clasificación externa hasta conciliación.

Para activar: respaldo del pivote, clientes/worker detenidos, **36 → 33 actualizado → 99**, publicar la carpeta completa compatible y preparar permisos reales de conexión/visibilidad. **No se aplicó nada a adminDB real en esta tarea.** No se instala ningún componente en los destinos.

Faltan las pruebas operativas con tickets/roles reales, concurrencia, red, volumen y frecuencia del entorno. Las consultas de catálogos tienen costo; no se certifica impacto cero ni compatibilidad de todas las versiones de destino solo por el laboratorio local en SQL Server 17.

Guía vigente: [MonitoreoSeguridad](MonitoreoSeguridad.md). El contrato anterior y sus resultados están archivados como texto en `docs/archive/monitoring-v2`.
