# Documentación Técnica

**SQL Access Admin — El «Cómo está hecho»**

Fecha de revisión: 17 de octubre de 2026. Documento elaborado a partir del código fuente, los proyectos .NET y los scripts SQL presentes en esta entrega.

**Actualización del 26 de octubre de 2026:** Usuarios temporales, Cambios de accesos y Cambios de contraseña usan el contrato central 36/33 v4/99. Las operaciones de la app se registran antes/después de ejecutarse; los destinos solo reciben operaciones y consultas de metadatos. La última fecha sin registro coincidente se clasifica como Externo, sin actor ni historial inventado. No se requiere captura instalada en destinos ni ScriptDom en el cliente. Esta actualización y la [guía vigente](../../docs/MonitoreoSeguridad.md) prevalecen sobre contratos históricos del documento.

SQL Access Admin es una aplicación de escritorio para administrar accesos en instancias de SQL Server. La base central `adminDB` conserva usuarios autorizados, servidores, políticas, solicitudes y auditoría. El cliente consulta esa base y se conecta directamente a las instancias administradas para consultar y ejecutar cambios aprobados.

El pivote adminDB conserva intentos, comandos, resultados y referencias de metadatos en el esquema access. No se crea adminDB en cada destino para este seguimiento. El worker consulta los catálogos de los destinos y conserva las últimas fechas por instancia, ámbito y SID.

## 1. Stack tecnológico

### 1.1. Tecnologías y versiones declaradas

| Componente | Versión o configuración | Uso y evidencia |
| --- | --- | --- |
| C# | Versión de lenguaje no fijada mediante `LangVersion`; C# 12 es la predeterminada del destino .NET 8 | Lógica de presentación, modelos, acceso a datos y seguridad. El código utiliza, entre otras características, constructores primarios y expresiones de colección. |
| .NET | `net8.0-windows` | Destino de compilación de la aplicación y del ejecutable de comprobaciones. No se fija un parche de runtime en los proyectos. |
| Windows Presentation Foundation (WPF) | Incluido en .NET 8; `UseWPF=true` | Ventanas, controles, enlaces de datos, estilos y comandos. |
| XAML | Formato de interfaz de WPF, sin versión independiente declarada | Vistas y diccionarios de recursos en `Views/` y `Themes/`. |
| Microsoft.Data.SqlClient | **6.1.4** | Única referencia NuGet directa de la aplicación; conexiones a SQL Server, parámetros, procedimientos y transacciones. |
| ADO.NET / System.Data | Bibliotecas de .NET | `DataTable`, lectores de resultados y parámetros tabulares para solicitudes compuestas. |
| System.Text.Json | Biblioteca de .NET 8 | Serialización de roles de aplicación, descubrimiento de políticas y planes de copia. |
| System.Security.Cryptography | Biblioteca de .NET 8 | AES-256-GCM, generación aleatoria, SHA-256 y limpieza de determinados buffers de secretos. |
| SQL Server / T-SQL | Sin versión de servidor fijada en el repositorio | Persistencia, procedimientos almacenados, funciones, tipos de tabla, triggers y catálogos de seguridad. |
| PowerShell y `sqlcmd` | Sin versión fijada | Instalación manual de insumos y comprobaciones SQL. |
| Mermaid | Sintaxis documental; sin dependencia de ejecución | Diagramas de este archivo. Su visualización requiere un visor Markdown compatible. |

Los archivos que definen las dependencias son [SqlAccessAdmin.csproj](../../src/SqlAccessAdmin/SqlAccessAdmin.csproj) y [PermissionCopyChecks.csproj](../../tests/PermissionCopyChecks/PermissionCopyChecks.csproj). Este último referencia al proyecto principal y ejecuta comprobaciones propias con datos simulados.

No existe un `global.json` que fije el SDK ni un archivo `packages.lock.json` que congele todas las dependencias transitivas. La versión 6.1.4 corresponde a la dependencia directa declarada; las dependencias transitivas se resuelven durante `dotnet restore`.

### 1.2. Compatibilidad y herramientas de desarrollo

- El cliente y las comprobaciones WPF se ejecutan en **Windows**, con herramientas capaces de compilar `net8.0-windows`.
- Para desarrollar se necesita el **SDK de .NET 8**, o un SDK posterior compatible que disponga de los recursos necesarios para ese destino. Visual Studio 2022 con soporte para .NET 8 y la carga de trabajo de desarrollo de escritorio con .NET es una opción de IDE.
- La solución utiliza el formato de Visual Studio 17 y compila el proyecto principal en `Debug` o `Release`, con plataforma `Any CPU`.
- Como requisito deducido de los scripts, el pivote necesita un motor que soporte `STRING_AGG`, `CREATE OR ALTER` y JSON mediante `OPENJSON`: una base técnica de **SQL Server 2017 o posterior**, con nivel de compatibilidad de `adminDB` **130 o superior**. Esto no constituye una certificación de todas las versiones; se debe validar la instalación con los insumos de esta entrega.
- Los destinos deben admitir las operaciones solicitadas y exponer sus metadatos a la cuenta de conexión. La disponibilidad de permisos se descubre por instancia con `sys.fn_builtin_permissions`.

## 2. Estructura de archivos y carpetas

El siguiente árbol resume los elementos relevantes para desarrollo y operación. Omite los archivos generados de `bin/`, `obj/` y la configuración local del IDE.

```text
SQL_User_Permisos/
├── SQLUserPermisos.sln                 # Solución del cliente WPF
├── README.md                          # Descripción funcional y ejecución rápida
├── descripcion.txt                    # Material descriptivo del proyecto
├── src/
│   └── SqlAccessAdmin/
│       ├── SqlAccessAdmin.csproj       # net8.0-windows, WPF y SqlClient 6.1.4
│       ├── App.xaml                   # Recursos globales y ventana de inicio
│       ├── App.xaml.cs                # Liberación de pools al terminar
│       ├── BooleanConverter.cs        # Conversión para enlaces de interfaz
│       ├── Views/                     # Ventanas y controles XAML + code-behind
│       ├── ViewModels/                # Estado de pantalla, navegación y comandos
│       ├── Models/                    # Contratos, roles, políticas y planes
│       ├── Data/                      # Acceso al pivote y a los destinos
│       ├── Security/                  # Protección de secretos con AES-GCM
│       ├── Infrastructure/            # INotifyPropertyChanged y comandos WPF
│       └── Themes/                    # Modern.xaml e Icons.xaml
├── InsumosProduccion/
│   ├── README.md                      # Guía de instalación manual para el DBA
│   ├── 00_CrearBaseDatos.sql           # Creación opcional de adminDB
│   ├── 01_CrearEsquema.sql             # Estructura inicial bajo access
│   ├── 02_CrearProcedimientosConsulta.sql
│   ├── 03_CrearProcedimientosOperacion.sql
│   ├── 04_CrearRolesYPermisos.sql
│   ├── 05_DatosIniciales.sql           # Plantilla del administrador inicial
│   ├── 07_CorreccionLoginSysadmin.sql  # Actualización histórica
│   ├── 08_ConfigurarConexionDirectaYCifrado.sql
│   ├── 09_RenombrarRolesSqlAccessAdmin.sql
│   ├── 10_...sql hasta 19_...sql        # Políticas y evolución de solicitudes
│   ├── 20_MigrarObjetosAlEsquemaAccess.sql
│   ├── 21_...sql hasta 28_...sql        # Cambios compuestos, copia y política por destino
│   ├── 29_UsuariosAutorizadosAccesoEstricto.sql
│   ├── 30_RolesMultiplesYSeparacionSolicitudes.sql
│   ├── 31_SeleccionUsuariosAutorizados.sql
│   ├── 99_ValidarInstalacion.sql        # Comprobación final de solo lectura
│   └── Documentación/
│       └── Documentación Técnica.md   # Este documento
├── database/
│   └── README-SP-CONTRACT.md           # Referencia a los insumos vigentes
├── docs/
│   ├── UsuariosAutorizados.md          # Identidad, roles e integración
│   ├── PoliticaAccesoPorDestino.md     # Herencia, descubrimiento y activaciones
│   ├── ViabilidadPermisosMultibase.md  # Análisis de una ampliación no implementada
│   ├── ComprobarIdentidadWindows.sql   # Diagnóstico de identidad de solo lectura
│   └── Previews/                       # Capturas de referencia de la interfaz
├── tests/
│   ├── PermissionCopyChecks/           # Ejecutable de comprobaciones .NET/WPF
│   └── SqlChecks/                     # Scripts PowerShell de comprobación SQL
└── artifacts/                         # Publicaciones y vistas generadas localmente
```

### 2.1. Responsabilidades del código

| Ubicación o componente | Responsabilidad |
| --- | --- |
| `Views/LoginWindow`, `ViewModels/LoginViewModel` | Capturar la conexión al pivote, autenticar y abrir la ventana principal. |
| `Views/MainWindow`, `ViewModels/MainViewModel` | Navegación, visibilidad por rol, bloqueo de sesión y coordinación de servicios. `MainViewModel.cs` también contiene varias clases de pantalla, incluido `AccessViewModel`. |
| `Views/AccessView`, `AccessRequestEditor`, `ConfirmationWindow` | Edición, revisión y presentación de solicitudes y resultados. |
| `CreateUserWizardViewModel`, `PermissionCopyViewModel`, `LoginStateManagementViewModel` | Asistente de alta, copia de accesos y habilitación o deshabilitación de logins. Parte de la lógica de `AccessViewModel` se distribuye mediante clases parciales. |
| `UsersViewModel`, `PolicyViewModel`, `ServerEditorViewModel` | Mantenimiento de usuarios autorizados, políticas y servidores. |
| `Data/AdminDbGateway.cs` | Fachada ADO.NET del pivote; autenticación, catálogos, solicitudes y auditoría. Implementa `IPolicyStore` e `IAuthorizedUserStore`. |
| `Data/ScopedPolicyGateway.cs` | Parte de `AdminDbGateway` dedicada a reglas por instancia/base y descubrimiento persistido. |
| `Data/DirectSqlServerService.cs` | Conexión directa, inventario de accesos y ejecución de solicitudes aprobadas. |
| `Data/PermissionCopyService.cs`, `PolicyDiscoveryService.cs`, `WindowsAccountValidationService.cs` | Partes de `DirectSqlServerService` para copia, descubrimiento y comprobación de cuentas Windows. |
| `Models/DomainModels.cs`, `AppRoleCatalog.cs` | Contratos de sesión, servidores, bases y solicitudes; roles acumulables y su serialización. |
| `Models/PermissionCopyModels.cs`, `PolicyContext.cs`, `PolicyEditorItems.cs` | Planes de copia, huellas de integridad, contexto de destino y validaciones de política. |
| `Security/AesGcmCredentialProtector.cs` | Cifrado y descifrado de sobres de credenciales y contraseñas temporales. |
| `Infrastructure/BindableBase.cs` | Notificación de cambios y clases `RelayCommand` / `AsyncCommand`. |

## 3. Arquitectura y flujo de datos

### 3.1. Organización general

La presentación sigue una organización **MVVM**: las vistas enlazan propiedades y comandos de los ViewModels; estos coordinan modelos y servicios de datos. Se utiliza code-behind para comportamiento propio de las ventanas y controles. Las dependencias se construyen explícitamente, por ejemplo en `LoginViewModel` y `MainViewModel`.

La lógica de negocio se reparte entre el cliente y los procedimientos del pivote. El cliente prepara planes y ejecuta cambios en los destinos; `adminDB` valida identidades, permisos funcionales, políticas, tickets, destinos y transiciones de solicitudes.

```mermaid
flowchart LR
    U[Usuario en Windows] --> V[Vistas WPF / XAML]
    V <--> VM[ViewModels y modelos]
    VM --> G[AdminDbGateway]
    VM --> D[DirectSqlServerService]
    G -->|Procedimientos y parámetros / TLS según configuración| P[(adminDB: esquema access)]
    D -->|Configuración, credenciales y política| G
    D -->|Conexiones directas / TLS según configuración| S[(Instancia SQL Server)]
    S --> B[(Bases administradas)]
    P --> T[dbo.sp_VerificarTicketExiste]
```

El cliente necesita conectividad tanto al pivote como a cada destino. Las operaciones actuales utilizan conexiones directas; no dependen de linked servers. No existe un servicio web intermedio propio en esta solución.

### 3.2. Inicio de sesión y autorización

1. `App.xaml` abre `Views/LoginWindow.xaml`.
2. `LoginViewModel` construye `PivotOptions` con los valores del formulario y crea `AdminDbGateway`.
3. `LoginAsync` llama a `access.usp_App_LoginContext` con la identidad autenticada por SQL Server.
4. El contrato exige una fila con `AuthorizationVersion=2`, `IsAuthorized=true`, principal y roles JSON válidos.
5. SQL resuelve la identidad original mediante `access.ufn_App_Principal()`. Para Windows utiliza el SID original y su nombre canónico, como `DOMINIO\usuario`, incluso cuando el nombre original de conexión es un alias MicrosoftAccount.
6. Solo ingresa una identidad registrada, activa y con membresías válidas. Tener `sysadmin` no sustituye el registro de aplicación.
7. Antes de cada operación a través del gateway se consulta nuevamente el contexto. Si cambia la identidad o el conjunto de roles, se dispara `AuthorizationLost` y `MainViewModel` bloquea la sesión. La detección ocurre al realizar una nueva operación; no utiliza notificaciones en tiempo real.

| Rol visible | Código persistido | Funciones |
| --- | --- | --- |
| Administrador | `Administrator` | Todas las funciones, incluida configuración de usuarios, servidores y políticas. |
| Operador | `Operator` | Crear solicitudes y consultar su seguimiento. |
| AprobadorEjecutor | `ApproverExecutor` | Confirmar, rechazar y ejecutar solicitudes. |
| Auditor | `Auditor` | Consultar resumen y auditoría. |

Las funciones se suman al asignar varios roles. Un Administrador o un usuario con Operador + AprobadorEjecutor puede procesar sus propias solicitudes; el flujo no impone dos personas distintas. Los roles de aplicación determinan funciones dentro del cliente y de sus SP; los permisos SQL de conexión y de ejecución deben prepararse adicionalmente.

### 3.3. Acceso a datos y resolución de destinos

`AdminDbGateway` crea conexiones `SqlConnection` por operación y utiliza `CommandType.StoredProcedure` con parámetros tipados. Los destinos y pasos se envían como parámetros tabulares `access.AccessRequestTargetType` y `access.AccessRequestStepPolicyType`; la copia utiliza además un plan JSON.

`DirectSqlServerService.ResolveAsync` obtiene del pivote el servidor activo y su configuración. Para autenticación SQL, recupera el sobre y el material criptográfico autorizado, descifra la contraseña y construye una cadena con `SqlConnectionStringBuilder`. Para Windows, la conexión integrada utiliza la identidad Windows del proceso cliente.

En los destinos se usan consultas de catálogos, procedimientos de sistema y sentencias T-SQL construidas para las operaciones permitidas. Los valores de consulta se parametrizan; los identificadores de comandos de seguridad se validan y delimitan con `SqlCommandBuilder.QuoteIdentifier`. No todas las operaciones directas son llamadas a procedimientos almacenados.

Cada operación libera su conexión mediante `using`/`await using`. Al cerrar la ventana principal termina la aplicación y `App.OnExit` ejecuta `SqlConnection.ClearAllPools()` para liberar los pools del pivote y los destinos.

### 3.4. Modelo de persistencia central

Los objetos de aplicación residen en el esquema `[access]` de `adminDB`. El procedimiento externo de tickets permanece en `dbo`.

| Grupo | Objetos principales | Información conservada |
| --- | --- | --- |
| Identidad | `AppRole`, `AuthorizedPrincipal`, `AuthorizedPrincipalRole` | Catálogo de roles, identidad, estado y membresías múltiples. `AuthorizedPrincipal.RoleName` se conserva como dato de compatibilidad; las membresías múltiples son la fuente de autorización vigente. |
| Conexiones | `ManagedServer`, `CryptoConfiguration` | Host, instancia, autenticación, opciones TLS, timeout, sobres cifrados y clave envuelta. |
| Solicitudes | `AccessRequest`, `AccessRequestTarget`, `AccessRequestStep` | Cabecera, ticket, actores, estado, destinos, pasos, plan JSON de copia y secreto temporal cifrado cuando corresponde. |
| Política vigente | `PolicyPermissionRule`, `PolicyRoleRule`, `PolicyRoleDiscovery` | Reglas por contexto y roles descubiertos en los destinos. |
| Catálogos | `PolicyPermissionCatalog`, `PolicyScopeCatalog`, `PolicyPermissionAvailability` | Combinaciones permiso/ámbito admitidas y disponibilidad por instancia. |
| Restricciones e historial de política | `SecurityDenyList`, `SecurityPolicyOperation`, `SecurityPolicyPermission`, `SecurityPolicyRole`, `SecurityPolicyOverride` | Bloqueos y operaciones; configuración o excepciones históricas importadas por las migraciones. Desde 27, las reglas por contexto determinan los permisos y roles efectivos. |
| Auditoría | `AuditEvent` | Actor, fecha UTC, acción, destino, éxito, detalle y cadena de integridad. |

`AuthorizedPrincipalRole` relaciona cada usuario autorizado con uno o varios roles. `AccessRequestTarget` y `AccessRequestStep` dependen de la solicitud. Las reglas de política identifican su contexto mediante servidor y base, y la información de auditoría permite reconstruir las gestiones.

### 3.5. Ciclo de una solicitud

```mermaid
sequenceDiagram
    actor O as Operador o Administrador
    participant C as Cliente WPF
    participant P as adminDB
    actor A as AprobadorEjecutor o Administrador
    participant S as SQL Server destino
    O->>C: Preparar cambio y consultar ticket
    C->>P: Validar ticket y política por destino
    P-->>C: Motivo del ticket y decisión
    C->>P: Crear solicitud, destinos, pasos o plan
    P-->>C: RequestId / PENDING
    A->>C: Revisar y confirmar o rechazar
    C->>P: usp_AccessRequest_Approve
    P-->>C: APPROVED o REJECTED
    A->>C: Ejecutar solicitud aprobada
    C->>P: Revalidar autorización, política y detalle
    C->>S: Ejecutar cambios por conexión directa
    S-->>C: Resultado por destino
    C->>P: Registrar resultado y auditoría
    P-->>C: EXECUTED o FAILED
```

Toda solicitud pertenece a **un solo servidor**. El pivote evita duplicados equivalentes que continúen pendientes o aprobados. La creación, revisión y ejecución tienen controles funcionales separados, tanto en el cliente como en los procedimientos.

Los estados del contrato son `PENDING`, `APPROVED`, `REJECTED`, `EXECUTED`, `FAILED` y `CANCELLED`. El flujo principal pasa de pendiente a aprobado o rechazado y, tras ejecutar una aprobación, a ejecutado o fallido. La presencia de `CANCELLED` en el contrato no implica una acción de cancelación expuesta en todas las pantallas.

Se admiten creación de login SQL o Windows, creación de usuarios de base, cambios de membresía, permisos, habilitación/deshabilitación de login y copia de accesos. La política avanzada incluye accesos de instancia mediante permisos y roles autorizados especialmente. Los roles SQL existentes se consultan y se asignan o retiran como membresías; su definición no se modifica desde el cliente.

El alta puede incluir mapeo a varias bases. Si una solicitud incorpora permisos de objeto, esquema o columna, requiere exactamente una base destino. La ampliación para combinar objetos de bases diferentes se analiza en [ViabilidadPermisosMultibase.md](../../docs/ViabilidadPermisosMultibase.md) y no está implementada.

### 3.6. Política efectiva y descubrimiento

La resolución de reglas sigue la prioridad **base de datos → instancia → plantilla general**. Una regla específica sustituye la heredada; restaurar herencia elimina la regla local. La disponibilidad del catálogo del destino y los bloqueos obligatorios también intervienen en la decisión.

El descubrimiento consulta roles y permisos del servidor seleccionado. Si faltan permisos para obtener un catálogo completo, se detiene la sincronización. Los roles personalizados nuevos aparecen pendientes y requieren autorización en su contexto; compartir nombre con un rol de otro destino no los habilita automáticamente.

Los permisos ordinarios de la matriz incluyen `SELECT`, `INSERT`, `UPDATE`, `DELETE`, `EXECUTE` y `REFERENCES`, según el tipo de objeto. La política avanzada utiliza el catálogo de SQL Server para otros permisos y ámbitos compatibles. `GRANT`, `DENY` y `REVOKE` tienen controles independientes.

Las activaciones especiales exigen motivo, reconocimiento del riesgo y escritura del nombre exacto. Esta confirmación se audita y se revalida en solicitudes y ejecución. Bloquear una opción de política impide gestiones posteriores, pero no retira por sí mismo los accesos existentes del destino.

### 3.7. Secretos, copia y consistencia

**Credenciales y contraseñas temporales.** `AesGcmCredentialProtector` utiliza claves de 32 bytes, nonce aleatorio de 12 bytes y etiqueta de autenticación de 16 bytes. El identificador de clave forma parte de los datos autenticados del sobre. La clave central se genera en SQL Server y se almacena envuelta mediante una clave AES-256 protegida por certificado y Database Master Key. El cliente autorizado obtiene material de clave y descifra en memoria cuando necesita conectarse o crear un login SQL. DPAPI, HSM y gestores externos de secretos no forman parte de esta implementación.

Para Windows no se almacena una contraseña SQL del nuevo usuario. La identidad Windows debe existir y se comprueba en el servidor destino mediante `sys.xp_logininfo`; se exige retorno entero `0`, incluso si no devuelve filas. Se repite la comprobación al enviar y al ejecutar.

**Copia de accesos.** Se guarda un plan JSON v2 con usuario origen y accesos por base, incluidas las exclusiones, y una huella SHA-256. Antes de ejecutar se vuelve a consultar el origen y la política: una diferencia invalida el plan. Se copian membresías y permisos directos compatibles de base, objeto, esquema o columna. No se copian roles de servidor; `GRANT WITH GRANT OPTION` se transforma en concesión sin delegación. Si existen `DENY` o excepciones `REVOKE` en los accesos revisados, se bloquea toda la copia.

**Límites transaccionales.** Los cambios compuestos de permisos/membresías de una base se ejecutan en una transacción. En la copia también se agrupan el usuario nuevo y sus accesos por base. La creación del login es independiente; en el alta con accesos iniciales, los pasos se ejecutan en orden y pueden dejar trabajo aplicado si falla un paso posterior. No hay una transacción global que abarque todas las bases y el pivote.

Por ello, una base completada o un login creado pueden permanecer aunque otra base falle. Además, si el destino confirma cambios y luego falla el registro del resultado en `adminDB`, el estado central puede requerir conciliación. Se deben revisar el destino y la auditoría antes de repetir una gestión con resultado incierto.

**Auditoría.** Los procedimientos registran eventos con cadena hash y el trigger `tr_AuditEvent_AppendOnly` bloquea modificaciones y eliminaciones ordinarias. `usp_Audit_ValidateIntegrity` comprueba enlaces y alteraciones. La integridad de esta cadena complementa los controles SQL y los respaldos; depende también de la administración de la base.

### 3.8. Módulo de Reportes

El menú lateral incorpora **Reportes** inmediatamente debajo de **Administrar accesos**, mediante un árbol plegable con las categorías **Permisos y Accesos** y **Seguridad y Auditoría**. `ReportsViewModel` y `ReportsView` presentan los tres reportes; `IReportsDataSource`, `ReportsService` y `ReportsSql` separan la interfaz de las consultas directas de solo lectura.

Se incluyen roles de base y permisos directos por usuario, catálogo dinámico de roles con miembros y antigüedad de contraseñas de logins SQL superior a 45 días. Esta última utiliza `LOGINPROPERTY(name,'PasswordLastSetTime')`; no identifica el último inicio de sesión. Los filtros, resultados vacíos, errores y cancelaciones se administran en el ViewModel, y una respuesta tardía no reemplaza los datos de otro contexto.

Los tres reportes pueden exportarse a PDF, CSV UTF-8 y Excel `.xlsx`. `ReportExportDocument` captura contexto, fecha, filtros, orden y secciones; `ReportExportService` genera los archivos en segundo plano y sustituye el destino solo después de completarse. ClosedXML 0.105.0 genera las hojas de Excel y PDFsharp/MigraDoc WPF 6.2.4 compone los PDF paginados. CSV tiene una estructura rectangular y neutraliza entradas que podrían interpretarse como fórmulas. No se utiliza automatización de Office ni una impresora PDF. La publicación debe incluir las nuevas dependencias NuGet.

**Permisos por usuario** permite seleccionar varias bases para un login SQL/Windows de la instancia. Consulta `sys.server_principals`, `sys.server_role_members` y `sys.server_permissions`, y resuelve el usuario de cada base por SID. Los resultados llevan nivel, base y principal; una sección de cobertura identifica bases sin mapeo y acceso por propiedad o `sysadmin`. La instancia se consulta incluso sin bases seleccionadas y `IS_SRVROLEMEMBER` complementa la detección de `sysadmin` reconocida por el motor. Los principales internos de base no aparecen en el selector. Un fallo de consulta por base invalida el resultado completo. Esta capacidad multibase es de consulta y no modifica las limitaciones multibase de solicitudes operativas.

Reutiliza la autorización vigente de conexiones directas: Administrador, Operador y AprobadorEjecutor. Auditor por sí solo no recibe acceso a las credenciales compartidas. El servicio revalida la sesión antes y después de la consulta. No requiere nuevas migraciones de `adminDB`; la cuenta técnica necesita los permisos de visibilidad de metadatos del destino.

Consulte [alcance y preparación de Reportes](../../docs/Reportes.md) y [comprobaciones de Reportes](../../tests/ReportsChecks/README.md). Las vistas previas utilizan datos simulados; las comprobaciones SQL opcionales no modifican accesos ni instalan objetos.

## 4. Configuración y despliegue

### 4.1. Requisitos previos

| Requisito | Preparación |
| --- | --- |
| Equipo cliente | Windows, SDK para desarrollo y acceso al origen NuGet para la restauración inicial. |
| Pivote | Instancia SQL Server, base `adminDB`, conectividad y cuenta DBA para instalar los insumos. |
| Destinos | Conectividad desde cada equipo cliente y credencial con permisos suficientes para las operaciones autorizadas. |
| TLS | Certificados confiables y nombres de conexión que correspondan al certificado, para trabajar con `Encrypt=true` y `TrustServerCertificate=false`. |
| Autorización inicial | Login válido, usuario de base y registro activo del Administrador inicial. Las migraciones posteriores deben conservar su membresía `Administrator`. |
| Tickets | `dbo.sp_VerificarTicketExiste` instalado en `adminDB` e integrado con la fuente de tickets antes de ejecutar 27. Su implementación no está incluida en los insumos. |
| Herramientas SQL | SSMS o `sqlcmd` capaz de procesar lotes separados por `GO`. |

La cuenta técnica de destino necesita visibilidad de metadatos y capacidad para crear logins/usuarios o asignar los permisos y membresías que vaya a gestionar. El DBA debe preparar esos permisos según el alcance aprobado. Los roles funcionales de la aplicación no conceden automáticamente privilegios en los destinos.

### 4.2. Preparación manual de `adminDB`

La aplicación no crea `adminDB`, no instala objetos ni ejecuta migraciones. El DBA debe revisar y ejecutar los archivos de [InsumosProduccion](../README.md), comprobar cada error y respaldar la base antes de actualizar una instalación existente.

Para una instalación nueva con los archivos actuales:

| Paso | Insumos | Acción |
| --- | --- | --- |
| 1 | `00_CrearBaseDatos.sql` | Ejecutar solo si la base no existe. También configura recuperación FULL y READ_COMMITTED_SNAPSHOT; revisar estas opciones y el plan de respaldos. |
| 2 | `01` → `02` → `03` → `04` | Crear esquema, tablas iniciales, SP y roles técnicos. |
| 3 | `05_DatosIniciales.sql` | Personalizar principal y tipo. Crear/mapear el usuario SQL y sus roles técnicos según los ejemplos del archivo. |
| 4 | `08_ConfigurarConexionDirectaYCifrado.sql` | Configurar la clave central y su protección. Revisar y sustituir la asignación de `@DatabaseMasterKeyPassword` por un secreto propio antes de ejecutar; custodiarlo fuera de la documentación. |
| 5 | `02` → `03` → `04` | Reaplicar inmediatamente después de 08 para restablecer los contratos y permisos base indicados en la guía de conexiones directas. |
| 6 | `10` → `11` → `12` → `13` → `14` → `15` → `16` → `17` → `18` → `19` | Instalar la evolución de políticas, solicitudes, tickets y secretos temporales. |
| 7 | `21` → `22` → `23` → `24` → `25` → `26` | Incorporar cambios compuestos, copia detallada, autenticación SQL/Windows y activaciones especiales. |
| 8 | Procedimiento externo de tickets | Comprobar el contrato descrito en 4.3 antes de continuar. |
| 9 | `27` → `28` → `29 actualizado` → `30` → `31` | Política por destino, catálogo de credenciales, autorización estricta, roles múltiples y selección de cuentas existentes. |
| 10 | `99_ValidarInstalacion.sql` | Revisar existencia y contratos de objetos, autorizaciones y administrador activo. Corregir cualquier faltante antes de abrir el cliente. |

`07` es una corrección histórica de login; `09` migra nombres heredados de roles; `20` mueve objetos desde `dbo` o el esquema transitorio `SqlAccessAdmin` hacia `access`. En una instalación nueva cuyos objetos ya se crean en `access`, estos archivos no son pasos funcionales adicionales. En una instalación heredada, el DBA debe seguir las instrucciones de migración de [la guía de insumos](../README.md), incluida la aplicación de 20 con el cliente detenido cuando corresponda.

Para actualizaciones recientes, una instalación que ya tenga 29 actualizado requiere `30 → 31 → 99`; si ya tiene 30 completo, requiere `31 → 99`. Se debe desplegar después el cliente compatible y reiniciar las sesiones. No reaplicar procedimientos de migraciones antiguas sobre una instalación actualizada: pueden sustituir contratos posteriores. Si se hace, restablecer los contratos vigentes con `30 → 31 → 99` según la guía.

Ejemplo de ejecución individual desde la raíz del proyecto, sustituyendo el servidor por el del entorno:

```powershell
sqlcmd -S 'SERVIDOR\INSTANCIA' -E -b -i '.\InsumosProduccion\01_CrearEsquema.sql'
sqlcmd -S 'SERVIDOR\INSTANCIA' -E -b -i '.\InsumosProduccion\99_ValidarInstalacion.sql'
```

Son ejemplos separados de instalación y validación; entre ambos deben aplicarse los pasos correspondientes de la tabla. `-b` permite detener la ejecución de `sqlcmd` ante errores SQL relevantes. Los scripts 05 y 08 requieren revisión y personalización; no deben incorporarse sin ella a una ejecución automática de todos los archivos.

### 4.3. Dependencia de tickets y cuentas Windows

El script 27 comprueba que exista `dbo.sp_VerificarTicketExiste` y concede su ejecución a `SqlAccessAdmin_Users`. El gateway lo invoca con `@Ticket` de tipo `varchar(50)`. La creación de solicitudes consume su resultado mediante `INSERT ... EXEC`, por lo que necesita las siguientes columnas en este orden y con tipos compatibles:

| Columna | Tipo receptor utilizado por el contrato |
| --- | --- |
| `RESPONSABLE` | `nvarchar(4000)` |
| `CLIENTE` | `nvarchar(4000)` |
| `ID_COMPUESTO` | `varchar(50)` |
| `ASUNTO` | `nvarchar(4000)` |
| `DESCRIPCION` | `nvarchar(max)` |
| `ESTADO` | `nvarchar(4000)` |

La integración debe devolver tickets válidos/activos conforme a su contrato. El SP de solicitud exige que `ID_COMPUESTO` coincida con el ticket consultado y toma como justificación `DESCRIPCION`, o `ASUNTO` si no hay descripción. El motivo resultante debe tener al menos diez caracteres. El sistema externo de tickets y su conexión se preparan fuera de esta solución.

Para comprobar nombres Windows, la cuenta usada en cada destino necesita ejecutar `sys.xp_logininfo` en `master`, además de la conectividad del servidor con el equipo o dominio correspondiente. Ejemplo que el DBA debe adaptar al usuario técnico existente:

```sql
USE [master];
GO
GRANT EXECUTE ON OBJECT::sys.xp_logininfo TO [UsuarioTecnicoEnMaster];
GO
```

Esta concesión se aplica en cada servidor de trabajo que la necesite. La aplicación crea el login SQL asociado a una cuenta Windows existente; la creación de cuentas del dominio o del equipo queda fuera de su alcance.

### 4.4. Restaurar, compilar y ejecutar el entorno de desarrollo

Abrir PowerShell en la raíz del proyecto:

```powershell
dotnet --info
dotnet restore .\SQLUserPermisos.sln
dotnet build .\SQLUserPermisos.sln -c Debug --no-restore
dotnet run --project .\src\SqlAccessAdmin\SqlAccessAdmin.csproj
```

También se puede abrir `SQLUserPermisos.sln` en Visual Studio y seleccionar `SqlAccessAdmin` como proyecto de inicio. El proyecto de comprobaciones se ejecuta por su ruta; no está incluido en la solución.

La conexión al pivote se introduce en la ventana de inicio. No hay un archivo `appsettings.json` de aplicación ni una cadena de conexión de entorno que deba editarse para este flujo.

| Parámetro | Valor inicial en `LoginViewModel` | Uso |
| --- | --- | --- |
| Servidor | `localhost` | Host del pivote. |
| Instancia | Vacía | Opcional; se combina como `servidor\instancia`. |
| Base | `adminDB` | Catálogo central. Los scripts de entrega utilizan ese nombre. |
| Autenticación integrada | Activada | Identidad Windows; puede elegirse autenticación SQL. |
| Usuario y contraseña | Vacíos | Se utilizan si se selecciona autenticación SQL. |
| Cifrar conexión | Activado | `Encrypt=true`. |
| Confiar en certificado | Desactivado | `TrustServerCertificate=false`. |

El gateway configura timeout de conexión de 15 segundos y de comando de 120 segundos. Cada servidor destino conserva su propio timeout; el valor inicial es 30 segundos. Las opciones TLS de los destinos se configuran en el mantenimiento de servidores.

Después de ingresar como Administrador:

1. Registrar o revisar un servidor activo y probar su conexión directa.
2. Comprobar el descubrimiento de bases, roles y permisos, y autorizar la política del contexto necesario.
3. Registrar usuarios autorizados seleccionando logins individuales Windows/SQL ya existentes y habilitados en el pivote; asignar sus roles funcionales.
4. En una instancia de pruebas, validar un ticket y completar el ciclo crear → confirmar → ejecutar con las identidades correspondientes.
5. Revisar resultados, historial y auditoría, incluida la validación de integridad.

### 4.5. Comprobaciones disponibles

El ejecutable de comprobaciones utiliza datos simulados y controles WPF para revisar autorización, roles múltiples, copia, política, asistentes, tipos de objetos y estado de login. No conecta a SQL Server ni demuestra permisos reales de infraestructura.

```powershell
dotnet run --project .\tests\PermissionCopyChecks\PermissionCopyChecks.csproj -c Release
```

La comprobación aislada del cierre de sesión se ejecuta así:

```powershell
dotnet run --project .\tests\PermissionCopyChecks\PermissionCopyChecks.csproj -c Release -- --logout-check
```

Con `sqlcmd` instalado y una identidad que pueda leer los metadatos de `adminDB`, existen comprobaciones de solo lectura:

```powershell
.\tests\SqlChecks\CheckProcedureIdentityUpgrade.ps1 -Server localhost -Database adminDB
.\tests\SqlChecks\CheckMultiRoleMigration.ps1 -Server localhost -Database adminDB
.\tests\SqlChecks\CheckAuthorizedPrincipalSelection.ps1 -Server localhost -Database adminDB
```

Estas verifican transformaciones de procedimientos y predicados mediante capturas o variables de tabla. No aplican migraciones ni sustituyen la prueba integral contra un destino real. Los modos de renderizado y el detalle de cobertura se describen en [PermissionCopyChecks/README.md](../../tests/PermissionCopyChecks/README.md) y [SqlChecks/README.md](../../tests/SqlChecks/README.md).

### 4.6. Publicación y entrega del cliente

Ejemplo de publicación para equipos Windows x64 con **.NET Desktop Runtime 8** instalado:

```powershell
dotnet publish .\src\SqlAccessAdmin\SqlAccessAdmin.csproj -c Release -r win-x64 --self-contained false -o .\artifacts\publish\win-x64
```

Para incluir el runtime en la entrega:

```powershell
dotnet publish .\src\SqlAccessAdmin\SqlAccessAdmin.csproj -c Release -r win-x64 --self-contained true -o .\artifacts\publish\win-x64-self-contained
```

Estos son comandos de publicación propuestos para x64; el repositorio no fija un Runtime Identifier ni un perfil de publicación. Se distribuye **la carpeta completa** generada, incluidas las dependencias y componentes nativos de SqlClient, y se ejecuta `SqlAccessAdmin.exe`. La preparación de `adminDB` continúa siendo un paso manual independiente.

Para actualizar un entorno: detener los clientes, respaldar y aplicar las migraciones pendientes, ejecutar 99, desplegar la carpeta completa compatible y abrir sesiones nuevas. Conservar una entrega anterior del cliente y respaldos de la base permite preparar una recuperación coordinada; sustituir solo el ejecutable no revierte contratos SQL.

### 4.7. Diagnóstico básico

| Síntoma | Revisión técnica |
| --- | --- |
| `adminDB` no preparada o no accesible | Nombre de servidor/base, conexión, permisos y ejecución de los insumos; errores SQL 208, 2812 o 4060 pueden producir este mensaje. |
| Se exige actualizar la autorización | Contrato `AuthorizationVersion=2` y scripts 29 actualizado, 30, 31 y 99. |
| Conecta a SQL pero rechaza la entrada | Principal canónico, `Active=1`, membresías de aplicación y roles técnicos del usuario de base. |
| La sesión se bloquea después de cambiar roles | Comportamiento previsto; cerrar y volver a ingresar para obtener una sesión con el nuevo contexto. |
| Falla la conexión cifrada | Certificado confiable, nombre del servidor, acceso de red y configuración TLS. |
| Falla Comprobar nombres Windows | Existencia de la cuenta, resolución del dominio desde SQL Server y permiso sobre `sys.xp_logininfo`. |
| Descubrimiento incompleto o bloqueado | Permisos de visibilidad de metadatos en el destino. |
| Falla o se rechaza el ticket | Existencia del SP externo, parámetro/resultado compatibles, ticket activo, identificador y motivo válido. |
| No se puede ejecutar una copia aprobada | Huella y detalle guardado, política vigente, accesos actuales del origen, exclusiones y disponibilidad del nombre nuevo. |
| Operación parcialmente aplicada | Revisar login y cada base, resultados y auditoría antes de volver a solicitar cambios. |

### 4.8. Referencias del proyecto

- [Descripción y ejecución del cliente](../../README.md).
- [Orden de instalación e insumos para el DBA](../README.md).
- [Identidad y usuarios autorizados](../../docs/UsuariosAutorizados.md).
- [Política por instancia y base](../../docs/PoliticaAccesoPorDestino.md).
- [Contrato de acceso al pivote](../../src/SqlAccessAdmin/Data/AdminDbGateway.cs).
- [Ejecución directa sobre destinos](../../src/SqlAccessAdmin/Data/DirectSqlServerService.cs).
- [Copia de accesos](../../src/SqlAccessAdmin/Data/PermissionCopyService.cs).
- [Protección criptográfica de sobres](../../src/SqlAccessAdmin/Security/AesGcmCredentialProtector.cs).

Las instrucciones anteriores documentan la preparación y operación del sistema; la elaboración de este archivo no aplica migraciones ni cambia accesos en SQL Server.
