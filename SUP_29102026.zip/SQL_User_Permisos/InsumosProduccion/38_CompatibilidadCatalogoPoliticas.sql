USE [adminDB];
GO
SET NOCOUNT ON;
SET XACT_ABORT ON;
-- Ejecutar en adminDB antes de desplegar el cliente con soporte EXTERNAL_MODEL.
-- Repetible. No modifica reglas, excepciones ni privilegios del destino.
BEGIN TRY
 IF OBJECT_ID(N'access.PolicyScopeCatalog',N'U') IS NULL
  THROW 51870,'Falta el catálogo de políticas. Complete la instalación hasta 27 antes de aplicar 38.',1;
 BEGIN TRAN;
 IF EXISTS(SELECT 1 FROM [access].PolicyScopeCatalog WITH(UPDLOCK,HOLDLOCK) WHERE ScopeType='EXTERNAL_MODEL')
  UPDATE [access].PolicyScopeCatalog SET SqlClass='EXTERNAL MODEL',Parts=1,IsServer=0 WHERE ScopeType='EXTERNAL_MODEL';
 ELSE
  INSERT [access].PolicyScopeCatalog(ScopeType,SqlClass,Parts,IsServer) VALUES('EXTERNAL_MODEL','EXTERNAL MODEL',1,0);
 COMMIT;
END TRY
BEGIN CATCH
 IF XACT_STATE()<>0 ROLLBACK;
 THROW;
END CATCH;
GO
