# Compatibilidad del catálogo de políticas

El descubrimiento consulta `sys.fn_builtin_permissions(DEFAULT)` en cada instancia. SQL Server 2025 incorpora la clase `EXTERNAL MODEL`; el cliente anterior abortaba la carga completa al encontrarla y dejaba vacías ambas pestañas.

## Despliegue

1. Aplicar `InsumosProduccion/38_CompatibilidadCatalogoPoliticas.sql` en `adminDB` con una cuenta de despliegue. Es repetible y requiere el catálogo instalado por 27. No reaplicar 27 en instalaciones existentes con hora de Guatemala.
2. Ejecutar `InsumosProduccion/99_ValidarInstalacion.sql`; verificar `Catálogo EXTERNAL_MODEL (script 38) = OK`.
3. Desplegar el cliente recompilado, reiniciarlo y seleccionar la instancia en Política de acceso → Actualizar. Comprobar también una base de datos.

La instalación nueva incluye el ámbito en 27. El script 38 alinea instalaciones existentes; no habilita permisos, modifica excepciones ni concede accesos en los servidores. Los permisos de modelo externo se descubren con su disponibilidad real y requieren autorización especial como otros permisos avanzados.

## Variantes y comportamiento

| Caso | Resultado |
| --- | --- |
| `EXTERNAL MODEL` | Se reconoce como `EXTERNAL_MODEL`, con un nombre de destino y ámbito de base de datos. |
| Clases con espacios, guiones bajos o minúsculas | Se normalizan para consultar el catálogo compatible. |
| Ámbito futuro desconocido | Se excluyen sus combinaciones de la disponibilidad; se mantiene el catálogo compatible y los roles. Un aviso persistente enumera las exclusiones. No se infiere un ámbito ejecutable. |
| Permiso nuevo con nombre válido en un ámbito conocido | Se registra como combinación descubierta. Las protecciones y aprobaciones siguen vigentes. |
| Filas repetidas | Se deduplican antes de registrar. |
| Nombre inválido, catálogo vacío o sin combinaciones compatibles | Se bloquea la sincronización y la edición. |
| Falta de visibilidad o conexión | Se conserva el rechazo de catálogos incompletos; no se usa una política de otro destino como sustituto. |
| adminDB sin script 38 | El rechazo del registro muestra la instrucción de revisar 38 y 99. |

Las combinaciones excluidas no se envían a `PolicyPermissionAvailability`. La política y la ejecución siguen exigiendo soporte del ámbito en el cliente y disponibilidad en SQL Server. Los cambios no retiran accesos que ya existan fuera de la aplicación.

## Comprobaciones

Desde la raíz del repositorio:

```powershell
dotnet build SQLUserPermisos.sln -c Release
dotnet run --project tests/PolicyCatalogChecks -c Release
dotnet run --project tests/PolicyCatalogChecks -c Release --no-restore -- --sql-smoke
```

La última prueba usa autenticación integrada contra `localhost`, con certificado confiado exclusivamente para el laboratorio. Consulta el catálogo real y ejecuta 38 dos veces contra una tabla temporal; no cambia `adminDB`. Las comprobaciones del modelo de vista cubren carga por destino con exclusiones, aviso, recuperación al actualizar, plantilla general y bloqueo ante errores reales. No sustituyen la validación de conexión y permisos técnicos en cada servidor de producción.

Referencia de sintaxis: [CREATE EXTERNAL MODEL — Microsoft Learn](https://learn.microsoft.com/en-us/sql/t-sql/statements/create-external-model-transact-sql?view=sql-server-ver17).
