namespace SqlAccessAdmin.Models;

public sealed record ReportRoleLink(string Member, string Parent);
public sealed record ReportInheritedRole(string Name, bool IsFixed, bool IsDirect, IReadOnlyList<ReportPermission> Permissions)
{
    public string Assignment => IsDirect ? "Por membresía directa" : "Por roles anidados";
    public string Description => DatabaseRoleDescriptions.Describe(Name, IsFixed);
}

public sealed record ReportRoleTreeNode(string Text, IReadOnlyList<ReportRoleTreeNode> Children)
{
    public bool IsExpanded { get; init; }
    public string Tone { get; init; } = "#24354D";
}

public static class RoleCatalogDetails
{
    public const string ScopeNote = "El detalle muestra asignaciones del rol y de los roles a los que pertenece; no calcula los permisos efectivos de un usuario. Las capacidades incorporadas de roles fijos se describen por separado. Revise también public, otros roles, permisos del usuario y propiedad de objetos. Los miembros listados son usuarios SQL/Windows con login y roles miembros directos; no se expanden grupos.";

    // Walk upward: a role inherits from its parents, never from the roles that are its members.
    // A visited set handles both cycles and multiple routes without duplicating a source role.
    public static IReadOnlyList<ReportRole> Attach(IReadOnlyList<ReportRole> roles, IReadOnlyList<ReportRoleLink> links)
    {
        var byName = roles.ToDictionary(x => x.Name, StringComparer.Ordinal);
        var parents = links.GroupBy(x => x.Member, StringComparer.Ordinal)
            .ToDictionary(x => x.Key, x => x.Select(y => y.Parent).Distinct(StringComparer.Ordinal).ToList(), StringComparer.Ordinal);
        return roles.Select(role =>
        {
            var direct = parents.GetValueOrDefault(role.Name) ?? [];
            var visited = new HashSet<string>(StringComparer.Ordinal) { role.Name };
            var queue = new Queue<string>(direct);
            var inherited = new List<ReportInheritedRole>();
            while (queue.TryDequeue(out var name))
            {
                if (!visited.Add(name) || !byName.TryGetValue(name, out var parent)) continue;
                inherited.Add(new(name, parent.IsFixed, direct.Contains(name, StringComparer.Ordinal), parent.DirectPermissions));
                if (parents.TryGetValue(name, out var next)) foreach (var item in next) queue.Enqueue(item);
            }
            return new ReportRole(role.Name, role.IsFixed, role.Members)
            {
                DirectPermissions = role.DirectPermissions,
                InheritedRoles = inherited.OrderBy(x => x.Name, StringComparer.Ordinal).ToList(),
                NestedMembers = links.Where(x => x.Parent == role.Name).Select(x => x.Member).Distinct(StringComparer.Ordinal).OrderBy(x => x, StringComparer.Ordinal).ToList()
            };
        }).ToList();
    }

    private static string Identifier(string value) => "[" + value.Replace("]", "]]") + "]";
    public static string Resource(ReportPermission p)
    {
        var name = p.Schema.Length > 0 ? Identifier(p.Schema) : "";
        if (p.Object.Length > 0) name += (name.Length > 0 ? "." : "") + Identifier(p.Object);
        if (p.Column.Length > 0) name += "." + Identifier(p.Column);
        return name.Length > 0 ? name : "(base actual)";
    }
    public static string PermissionSearch(ReportPermission p) => $"{p.Scope} {p.Schema} {p.Object} {p.ObjectType} {p.Column} {p.Permission} {p.Action}";
    public static string ActionText(string action) => action switch
    {
        "DENY" => "Denegado",
        "GRANT WITH GRANT OPTION" => "Permitido con opción de conceder",
        "GRANT" => "Permitido",
        _ => action.StartsWith("REVOKE", StringComparison.Ordinal) ? "REVOKE — Excepción de columna" : action
    };

    private static ReportRoleTreeNode Note(string text) => new(text, []);
    private static IReadOnlyList<ReportRoleTreeNode> Permissions(IReadOnlyList<ReportPermission> permissions) => permissions.Count == 0
        ? [Note("Sin permisos explícitos registrados.")]
        : permissions.GroupBy(p => (p.Scope, p.Schema, p.Object, p.ObjectType, p.Column))
            .Select(group => new ReportRoleTreeNode($"{(group.Key.Scope == "Objeto" && group.Key.ObjectType.Length > 0 ? group.Key.ObjectType : group.Key.Scope)}: {Resource(group.First())}",
                group.Select(p => new ReportRoleTreeNode($"{(p.Action == "DENY" ? "✕" : p.Action.StartsWith("GRANT", StringComparison.Ordinal) ? "✓" : "↪")} {p.Permission} — {ActionText(p.Action)}", [])
                { Tone = p.Action == "DENY" ? "#A4262C" : p.Action.StartsWith("GRANT", StringComparison.Ordinal) ? "#16633B" : "#795500" }).ToList())).ToList();

    public static IReadOnlyList<ReportRoleTreeNode> Tree(ReportRole? role)
    {
        if (role is null) return [];
        var nodes = new List<ReportRoleTreeNode>
        {
            new($"Permisos directos ({role.DirectPermissions.Count})", Permissions(role.DirectPermissions)),
            new($"Permisos heredados ({role.InheritedRoles.Count} roles)", role.InheritedRoles.Count == 0
                ? [Note("Sin membresías en otros roles.")]
                : role.InheritedRoles.Select(parent =>
                {
                    var children = Permissions(parent.Permissions).ToList();
                    if (parent.IsFixed) children.Insert(0, Note("Capacidades incorporadas: " + parent.Description));
                    return new ReportRoleTreeNode($"Rol: {parent.Name} · {parent.Assignment}", children);
                }).ToList()),
            new($"Miembros del rol ({role.Members.Count} usuarios · {role.NestedMembers.Count} roles)",
                role.Members.Select(x => Note($"{x.Name} · {x.Type} · {(role.Name == "public" ? "Implícita" : "Directa")}"))
                    .Concat(role.NestedMembers.Select(x => Note($"Rol: {x} · Miembro directo")))
                    .DefaultIfEmpty(Note("Sin miembros de los tipos incluidos en este catálogo.")).ToList())
        };
        if (role.IsFixed) nodes.Insert(0, new("Capacidades incorporadas del rol fijo", [Note(role.Description)]));
        return [new(role.Name, nodes) { IsExpanded = true }];
    }
}
