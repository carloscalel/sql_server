﻿using System.Data;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Threading;
using Microsoft.Data.SqlClient;
using SqlAccessAdmin;
using SqlAccessAdmin.Data;
using SqlAccessAdmin.Infrastructure;
using SqlAccessAdmin.Models;
using SqlAccessAdmin.ViewModels;
using SqlAccessAdmin.Views;

internal static class Program
{
    private static int _checks;
    [STAThread]
    private static int Main(string[] args)
    {
        try
        {
            var app = new App(); app.InitializeComponent();
            SynchronizationContext.SetSynchronizationContext(new DispatcherSynchronizationContext());
            var source = new FakeReports();
            using var user = Create(source, ReportKind.UserPermissions);
            Check(!user.QueryCommand.CanExecute(null), "Se requiere un login SQL o Windows");
            user.SelectedUser = user.Users[0];
            // Exercise ICommand.Execute too: AsyncCommand's own running flag must not suppress the query.
            user.QueryCommand.Execute(null); Pump();
            Check(user.Memberships.Count == 1 && user.Permissions.Count == 4, "Consulta unificada por ICommand sin el rol implícito public");
            user.ActionFilter = "DENY";
            Check(user.Permissions.Count == 1 && user.Permissions[0].Action == "DENY", "Filtro de denegaciones");
            user.ActionFilter = "Todas"; user.Search = "pagos";
            Check(user.Permissions.Count == 1 && user.Memberships.Count == 0, "Búsqueda sin distinguir mayúsculas por objeto");
            user.Search = "";
            Check(user.Permissions.Count == 4 && user.Memberships.Count == 1, "Quitar filtro restaura resultados sin public");
            Check(user.Permissions.Any(x => x.Scope == "Columna" && x.Action.StartsWith("REVOKE")), "No se ocultan excepciones de columna");
            user.SelectedUser = user.Users[1];
            Check(user.Memberships.Count == 0 && user.Permissions.Count == 0, "Cambiar usuario descarta resultados previos");
            Run(user.QueryAsync());
            Check(user.ShowEmpty && user.ResultSummary.Contains("0 de 0"), "Reporte vacío explícito");
            source.Fail = true; Run(user.QueryAsync());
            Check(user.Status.Contains("Sin visibilidad") && user.Permissions.Count == 0, "Error visible sin conservar resultados previos");
            source.Fail = false; user.SelectedUser = user.Users[0]; Run(user.QueryAsync());

            using var roles = Create(source, ReportKind.RoleCatalog); Run(roles.QueryAsync());
            Check(roles.Roles.Count == 3, "Catálogo incluye roles sin miembros y public");
            roles.Search = "ana";
            Check(roles.Roles.Count == 1 && roles.RoleMembers.Single().Name == "ana", "Buscar por miembro localiza el rol");
            roles.Search = ""; roles.RoleKindFilter = "Personalizados";
            Check(roles.Roles.Count == 1 && roles.Roles[0].Name == "ventas_lectura", "public no se clasifica como personalizado");
            roles.RoleKindFilter = "Fijos";
            Check(roles.Roles.Count == 2, "Filtro de roles fijos incluye public implícito");
            roles.RoleKindFilter = "Todos";
            Run(RoleCatalogChecks.RunAsync(roles, Check));
            Check(DatabaseRoleDescriptions.Describe("db_owner", true).Contains("Control total"), "Descripción funcional de administrador");

            using var credentials = Create(source, ReportKind.CredentialAge); Run(credentials.QueryAsync());
            Check(!credentials.NeedsDatabase && credentials.Credentials.Count == 5, "Reporte incluye SQL recientes, antiguos y Windows de la instancia");
            credentials.CredentialStateFilter = "Fecha no disponible";
            Check(credentials.Credentials.Single().Days is null && credentials.Credentials[0].Classification == "Fecha no disponible", "Fecha desconocida separada de credencial antigua");
            credentials.CredentialStateFilter = "Deshabilitados";
            Check(credentials.Credentials.Count == 1 && credentials.Credentials[0].Disabled, "Incluye y filtra logins deshabilitados");
            credentials.CredentialStateFilter = "Hasta 45 días";
            Check(credentials.Credentials.Single().Days == 0 && credentials.Credentials[0].Classification == "Hasta 45 días", "Contraseña recién cambiada permanece visible y no se clasifica antigua");
            credentials.CredentialStateFilter = "WINDOWS_LOGIN";
            Check(credentials.Credentials.Single().Classification == "Gestionada por Windows/AD" && credentials.Credentials[0].Days is null, "Windows aparece sin inventar antigüedad de contraseña");
            credentials.CredentialStateFilter = "Más de 45 días";
            Check(credentials.Credentials.Count == 2, "Filtro de antigüedad conserva cuentas antiguas");
            credentials.CredentialStateFilter = "Todos";

            Check(new SessionContext("op", AppRole.Operator).CanAccessRequests, "Operador conserva acceso directo");
            Check(!new SessionContext("aud", AppRole.Auditor).CanAccessRequests, "Auditor no recibe credenciales compartidas");
            Check(!new SessionContext("revoked", AppRole.None).CanAccessRequests, "Sin autorización no hay acceso directo");
            Check(typeof(DirectSqlServerService).GetMethod("RequireReportsAsync", BindingFlags.NonPublic | BindingFlags.Instance) is not null, "Servicio valida autorización además del menú");

            var reportNow=new DateTime(2026,10,26,18,0,0);
            var unknownPassword=new CredentialAgeRow("auditor",false,null,null,true,true);
            var confirmedPassword=unknownPassword.WithConfirmedPasswordChange(reportNow.AddHours(-1),reportNow.AddDays(-4),reportNow);
            Check(confirmedPassword.Days==0 && confirmedPassword.PasswordLastSet==reportNow.AddHours(-1)
                && confirmedPassword.PasswordDateSourceDisplay=="Cambio confirmado en la aplicación", "Cambio confirmado hoy corrige contraseña sin fecha y muestra cero días");
            Check(unknownPassword.WithConfirmedPasswordChange(reportNow.AddDays(-2),reportNow.AddDays(-1),reportNow)==unknownPassword,
                "No se usa evidencia anterior a la creación de la cuenta");
            Check(unknownPassword.WithConfirmedPasswordChange(reportNow.AddMinutes(1),reportNow.AddDays(-4),reportNow)==unknownPassword,
                "No se usa evidencia futura");
            var newerEnginePassword=unknownPassword with{PasswordLastSet=reportNow.AddMinutes(-10),Days=0};
            Check(newerEnginePassword.WithConfirmedPasswordChange(reportNow.AddHours(-1),reportNow.AddDays(-4),reportNow)==newerEnginePassword,
                "Una contraseña más reciente del servidor prevalece sobre el registro de la aplicación");
            var windowsPassword=unknownPassword with{LoginType="WINDOWS_LOGIN"};
            Check(windowsPassword.WithConfirmedPasswordChange(reportNow.AddHours(-1),reportNow.AddDays(-4),reportNow)==windowsPassword,
                "La evidencia SQL no asigna fechas de contraseña Windows");

            TestLateResponses();
            TestRoleSelection();
            TestLoginSearch();
            TestMultipleDatabases();
            Run(InstanceReportChecks.RunAsync(Check));
            Run(ReportExportChecks.RunAsync(source, user, roles, credentials,
                args.Length > 0 && args[0] != "--sql-smoke" ? Path.Combine(args[0], "exports") : Path.Combine(Path.GetTempPath(), "sql-access-export-checks-" + Guid.NewGuid().ToString("N")), Check));
            var bindingErrors = new StringWriter();
            PresentationTraceSources.DataBindingSource.Listeners.Add(new TextWriterTraceListener(bindingErrors));
            PresentationTraceSources.DataBindingSource.Switch.Level = SourceLevels.Error;
            if (args.Length > 0 && args[0] != "--sql-smoke")
            {
                Directory.CreateDirectory(args[0]);
                foreach (var format in Enum.GetValues<ReportExportFormat>())
                    RenderExportOptions(format, Path.Combine(args[0], $"reportes-exportar-{format}.png"));
                RenderMain(user, Path.Combine(args[0], "reportes-permisos.png"), 1280, 900);
                RenderMain(user, Path.Combine(args[0], "reportes-login-busqueda.png"), 1280, 900, showLoginOptions: true);
                RenderMain(user, Path.Combine(args[0], "reportes-permisos-detalle.png"), 1280, 900, selectedTab: 1);
                RenderMain(user, Path.Combine(args[0], "reportes-bases-seleccion.png"), 1280, 900, showDatabaseOptions: true);
                user.SelectedUser = user.Users.Single(x => x.Name == "administrador_sql"); Run(user.QueryAsync());
                RenderMain(user, Path.Combine(args[0], "reportes-sysadmin.png"), 1280, 800);
                RenderMain(user, Path.Combine(args[0], "reportes-sysadmin-bases.png"), 1280, 800, selectedTab: 2);
                user.SelectedUser = user.Users[0]; Run(user.QueryAsync());
                RenderMain(roles, Path.Combine(args[0], "reportes-roles.png"), 1280, 900);
                roles.SelectedRole = roles.Roles.Single(x => x.Name == "ventas_lectura");
                RenderMain(roles, Path.Combine(args[0], "reportes-roles-arbol.png"), 1280, 900);
                roles.SelectedRole = roles.Roles.First();
                roles.IncludeRoleMembersInExport = true;
                roles.Roles.Single(x => x.Name == "db_datareader").ExportMembers = true;
                roles.Roles.Single(x => x.Name == "public").ExportMembers = true;
                RenderMain(roles, Path.Combine(args[0], "reportes-roles-seleccion.png"), 1280, 800);
                roles.IncludeRoleMembersInExport = false;
                RenderMain(credentials, Path.Combine(args[0], "reportes-credenciales.png"), 1280, 900);
                using var instance = Create(source, ReportKind.InstancePermissions);
                Run(instance.QueryAsync());
                RenderMain(instance, Path.Combine(args[0], "reportes-instancia-logins.png"), 1280, 800, selectedTab: 3);
                RenderMain(instance, Path.Combine(args[0], "reportes-instancia-roles.png"), 1280, 800);
                instance.DatabaseChoices[0].IsSelected = true; Run(instance.QueryAsync());
                RenderMain(instance, Path.Combine(args[0], "reportes-instancia-bases.png"), 1280, 800, selectedTab: 2);
                RenderMain(instance, Path.Combine(args[0], "reportes-instancia-permisos.png"), 1280, 800, selectedTab: 1);
                RenderMain(user, Path.Combine(args[0], "reportes-compacto.png"), 1280, 800);
            }
            else { var view = new ReportsView { DataContext = user }; Layout(view, 966, 720); }
            Pump();
            Check(bindingErrors.ToString().Length == 0, $"Enlaces WPF sin errores: {bindingErrors}");
            var sqlIndex = Array.IndexOf(args, "--sql-smoke");
            if (sqlIndex >= 0) Run(SqlSmokeAsync(args.ElementAtOrDefault(sqlIndex + 1) ?? "localhost"));
            Console.WriteLine($"OK: {_checks} comprobaciones de reportes.");
            return 0;
        }
        catch (Exception error) { Console.Error.WriteLine(error); return 1; }
    }

    private static ReportsViewModel Create(FakeReports source, ReportKind kind)
    {
        var vm = new ReportsViewModel(source, kind); Run(vm.Initialization);
        Check(vm.Servers.Count == 2, "Catálogo de servidores");
        vm.SelectedServer = vm.Servers[0]; Run(vm.ContextLoad);
        if (vm.NeedsDatabase) { vm.SelectedDatabase = vm.Databases[0]; Run(vm.ContextLoad); }
        if (vm.IsUserPermissions) vm.DatabaseChoices[0].IsSelected = true;
        return vm;
    }

    private static void TestRoleSelection()
    {
        using var vm = Create(new FakeReports(), ReportKind.RoleCatalog);
        var view = new ReportsView { DataContext = vm };
        Layout(view, 1280, 900);
        Run(vm.QueryAsync());
        Layout(view, 1280, 900);
        var grid = FindVisuals<DataGrid>(view).Single(x => System.Windows.Automation.AutomationProperties.GetName(x) == "Catálogo de roles");
        CheckSelections("primera consulta sin buscar");
        vm.IncludeRoleMembersInExport = true;
        var exportRole = vm.Roles[0];
        var checkbox = FindVisuals<CheckBox>(grid).Single(x => System.Windows.Automation.AutomationProperties.GetName(x) == "Exportar miembros de " + exportRole.Name);
        checkbox.SetCurrentValue(System.Windows.Controls.Primitives.ToggleButton.IsCheckedProperty, true);
        Check(exportRole.ExportMembers, "La selección de miembros se actualiza desde la casilla WPF");
        CheckSelections("después de marcar miembros");
        vm.Search = "Solicitudes"; Layout(view, 1280, 900);
        Check(vm.Roles.Count == 1 && vm.SelectedRole?.Name == "ventas_lectura", "Buscar un recurso selecciona el único rol coincidente en la vista WPF");
        CheckSelections("con búsqueda");
        vm.Search = ""; Layout(view, 1280, 900);
        CheckSelections("después de borrar búsqueda");
        vm.RoleKindFilter = "Fijos"; Layout(view, 1280, 900);
        CheckSelections("con filtro de tipo");
        vm.RoleKindFilter = "Todos"; Layout(view, 1280, 900);
        vm.Search = "rol_inexistente"; Layout(view, 1280, 900);
        var detail = FindVisuals<TreeView>(view).Single(x => System.Windows.Automation.AutomationProperties.GetName(x) == "Permisos y miembros del rol");
        Check(vm.SelectedRole is null && detail.Items.Count == 0, "Una búsqueda sin coincidencias limpia el detalle del rol");
        vm.Search = "";
        Run(vm.QueryAsync()); Layout(view, 1280, 900);
        CheckSelections("al volver a consultar");

        void CheckSelections(string phase)
        {
            foreach (var role in vm.Roles.Reverse().ToList())
            {
                grid.SetCurrentValue(System.Windows.Controls.Primitives.Selector.SelectedItemProperty, role);
                Pump();
                var tree = FindVisuals<TreeView>(view).Single(x => System.Windows.Automation.AutomationProperties.GetName(x) == "Permisos y miembros del rol");
                Check(ReferenceEquals(vm.SelectedRole, role) && tree.Items.Cast<ReportRoleTreeNode>().Single().Text == role.Name
                    && FindVisuals<TextBlock>(view).Any(x => x.Text == $"{role.Name} · {role.Description}"),
                    $"Selección WPF sincroniza descripción y árbol ({phase}): {role.Name}");
            }
        }
    }

    private static void TestLoginSearch()
    {
        var source = new FakeReports();
        using var vm = Create(source, ReportKind.UserPermissions);
        var names = vm.Users.Select(x => x.Name).ToList();
        Check(vm.Users.Count == 6 && vm.Users.All(x => x.Type is "SQL_LOGIN" or "WINDOWS_LOGIN")
            && names.Contains("DOMINIO\\operador") && names.Contains("NT_operador"), "Selector conserva logins SQL y Windows individuales y no excluye nombres humanos por contener NT");
        Check(!names.Intersect(new[] { "NT AUTHORITY\\SYSTEM", "NT AUTHORITY\\NETWORK SERVICE", "NT Service\\MSSQLSERVER", "nt service\\SQLSERVERAGENT", "grupo_windows", "guest", "##MS_Internal##" }).Any(),
            "Selector excluye cuentas NT, servicios, grupos e internos aunque el proveedor las devuelva");
        vm.SelectedUser = vm.Users[0]; Run(vm.QueryAsync());
        var selected = vm.SelectedUser;
        vm.LoginSearch = " VENTAS ";
        Check(vm.FilteredUsers.Cast<ReportUser>().Single() == selected && vm.SelectedUser == selected && vm.CanExport,
            "Buscar por una parte del nombre ignora mayúsculas y espacios y conserva una selección coincidente");
        vm.LoginSearch = "ADMINISTRADOR";
        Check(vm.FilteredUsers.Cast<ReportUser>().Count() == 2 && vm.SelectedUser is null && !vm.CanExport && !vm.QueryCommand.CanExecute(null),
            "Buscar otro login limpia la selección oculta y su reporte anterior");
        vm.LoginSearch = "no_existe";
        Check(vm.FilteredUsers.IsEmpty && vm.LoginSearchSummary == "Sin coincidencias.", "Búsqueda sin coincidencias se identifica explícitamente");
        vm.LoginSearch = "";
        Check(vm.FilteredUsers.Cast<ReportUser>().Count() == vm.Users.Count && vm.SelectedUser is null, "Borrar búsqueda restaura logins sin seleccionar uno automáticamente");
        vm.LoginSearch = "DOMINIO\\OPER";
        vm.SelectedUser = vm.FilteredUsers.Cast<ReportUser>().Single(); Run(vm.QueryAsync());
        source.Pending = new(); var pending = vm.QueryAsync();
        vm.LoginSearch = "sin_accesos";
        source.Pending.SetResult(new([new("RESPUESTA_ANTIGUA", true, true)], [])); Run(pending);
        Check(vm.Memberships.Count == 0 && !vm.CanExport && vm.SelectedUser is null, "Cambiar búsqueda descarta una consulta pendiente del login que dejó de coincidir");
        source.Pending = null;
        vm.SelectedServer = vm.Servers[1]; Run(vm.ContextLoad);
        Check(vm.LoginSearch == "" && vm.FilteredUsers.Cast<ReportUser>().Count() == vm.Users.Count, "Cambiar servidor reinicia la búsqueda de logins");
    }

    private static void TestMultipleDatabases()
    {
        var source = new FakeReports();
        using var vm = Create(source, ReportKind.UserPermissions);
        Check(vm.Users.Any(x => x.Name == "administrador_sql") && vm.Users.All(x => x.Type is "SQL_LOGIN" or "WINDOWS_LOGIN"), "Selector de instancia incluye sysadmin y solo tipos de login admitidos");
        vm.SelectedUser = vm.Users[0]; vm.DatabaseChoices[1].IsSelected = true; Run(vm.QueryAsync());
        Check(source.LastDatabases.SequenceEqual(new[] { "Operaciones", "Ventas" }) && vm.DatabaseCoverage.Count == 2, "Se consultan varias bases elegidas");
        Check(vm.Memberships.Count == 2 && vm.Memberships.All(x => x.Name == "db_datareader") && vm.Memberships.Select(x => x.Database).Distinct().Count() == 2, "Los roles identifican su base y omiten public de instancia y bases");
        vm.Search = "Operaciones";
        Check(vm.Memberships.All(x => x.Database == "Operaciones") && vm.DatabaseCoverage.Single().Database == "Operaciones", "La búsqueda por base filtra roles, permisos y bases revisadas");
        vm.Search = "";
        var snapshot = vm.CreateExportDocument();
        Check(snapshot.Database == "Operaciones, Ventas" && snapshot.Sections.Count == 3 && snapshot.Sections[0].Columns[0].Header == "Nivel" && snapshot.Sections[0].Rows.Count == 2 && snapshot.Sections[0].Rows.All(x => !string.Equals(x[3]?.ToString(), "public", StringComparison.OrdinalIgnoreCase)), "Exportación conserva bases y niveles de acceso sin public");
        vm.ClearDatabasesCommand.Execute(null); Check(!vm.CanExport && vm.Memberships.Count == 0, "Cambiar bases elimina la consulta anterior");
        Run(vm.QueryAsync());
        Check(source.LastDatabases.Count == 0 && vm.Memberships.All(x => x.Level == "Instancia") && vm.DatabaseCoverage.Count == 0, "Consulta solo instancia sin exigir un mapeo de base");
        vm.SelectedUser = vm.Users.Single(x => x.Name == "administrador_sql"); vm.SelectDatabasesCommand.Execute(null); Run(vm.QueryAsync());
        Check(vm.Memberships.Any(x => x.Name == "sysadmin" && x.Level == "Instancia" && x.Description.Contains("Control total")), "Sysadmin se identifica con descripción de privilegios de instancia");
        Check(vm.DatabaseCoverage.All(x => x.Detail.Contains("sysadmin") && x.User == "Sin usuario mapeado"), "Sysadmin no se presenta sin acceso por carecer de usuario mapeado");
        vm.Search = "Operaciones";
        Check(!vm.ShowEmpty && vm.DatabaseCoverage.Count == 1, "La revisión de una base sigue visible aunque los roles de instancia no coincidan con la búsqueda");
        vm.Search = "";
        vm.SelectedUser = vm.Users.Single(x => x.Name == "administrador_con_permisos"); Run(vm.QueryAsync());
        Check(vm.Permissions.Count == 7 && vm.Permissions.All(x => x.CoveredBySysadmin), "Sysadmin conserva todos sus permisos directos de instancia, objeto y columna");
        Check(vm.Permissions.Where(x => x.Action.StartsWith("GRANT")).All(x => x.OriginStatus == "Redundante (Cubierto por Sysadmin)")
            && vm.Permissions.Where(x => !x.Action.StartsWith("GRANT")).All(x => x.OriginStatus == "Sin efecto (Sysadmin)"), "Se distingue redundancia de concesiones y excepciones sin efecto para sysadmin");
        vm.Search = "Cubierto por Sysadmin";
        Check(vm.Permissions.Count == 3 && vm.Permissions.All(x => x.CoveredBySysadmin), "Buscar por estado conserva el análisis aunque el rol quede oculto");
        vm.Search = ""; vm.ActionFilter = "DENY";
        Check(vm.Permissions.Count == 2 && vm.Permissions.All(x => x.Action == "DENY" && x.CoveredBySysadmin), "Los DENY de sysadmin conservan su acción original al filtrar");
        vm.ActionFilter = "Todas";
        var adminSnapshot = vm.CreateExportDocument();
        Check(adminSnapshot.ScopeNote == "" && adminSnapshot.Sections[1].Columns.Last().Header == "Origen / Estado"
            && adminSnapshot.Sections[1].Rows.Count == 7, "Exportaciones conservan la evidencia de sysadmin y omiten el texto explicativo");
        var instancePermission = vm.Permissions.Single(x => x.Level == "Instancia");
        Check(instancePermission.DatabaseDisplay == "—" && instancePermission.SchemaDisplay == "—" && instancePermission.ObjectDisplay == "—"
            && instancePermission.ObjectTypeDisplay == "—" && instancePermission.ColumnDisplay == "—"
            && adminSnapshot.Sections[0].Rows.Single(x => Equals(x[0], "Instancia"))[1]?.ToString() == "—", "Contexto no aplicable usa em dash en pantalla y exportaciones");
        vm.SelectedUser = vm.Users.Single(x => x.Type == "WINDOWS_LOGIN"); Run(vm.QueryAsync());
        Check(vm.Memberships.Any(x => x.Level == "Base" && x.Principal == "usuario_windows_alias"), "Se conserva el usuario de base distinto del login Windows");
        Check(vm.Permissions.All(x => !x.CoveredBySysadmin && x.OriginStatus == "Asignación directa"), "Cambiar a un login sin sysadmin elimina el contexto de privilegios anterior");
        source.FailDatabase = "Ventas"; Run(vm.QueryAsync());
        Check(!vm.CanExport && vm.Memberships.Count == 0 && vm.Status.Contains("Ventas"), "Un fallo por base no publica ni exporta un reporte parcial");
    }

    private static void TestLateResponses()
    {
        var source = new FakeReports();
        using var vm = Create(source, ReportKind.UserPermissions);
        vm.SelectedUser = vm.Users[0];
        var response = new TaskCompletionSource<UserAccessReport>(); source.Pending = response;
        var query = vm.QueryAsync();
        Check(vm.IsBusy && vm.CancelCommand.CanExecute(null), "Consulta en curso cancelable");
        vm.SelectedUser = vm.Users[1];
        response.SetResult(new([new("NO_DEBE_APARECER", true, true)], [])); Run(query);
        Check(vm.Memberships.Count == 0 && !vm.IsBusy, "Respuesta tardía no contamina otro usuario");
        source.Pending = new(); vm.SelectedUser = vm.Users[0]; query = vm.QueryAsync(); vm.CancelCommand.Execute(null);
        source.Pending.SetResult(new([new("CANCELADO", true, true)], [])); Run(query);
        Check(vm.Memberships.Count == 0 && vm.Status.Contains("cancelada"), "Cancelar descarta incluso proveedor que ignora token");
        source.Pending = new(); query = vm.QueryAsync(); vm.Dispose();
        source.Pending.SetResult(new([new("CERRADO", true, true)], [])); Run(query);
        Check(vm.Memberships.Count == 0 && !vm.QueryCommand.CanExecute(null), "Salir del módulo impide publicar resultados");
        source.Pending = null;
        using (var multi = Create(source, ReportKind.UserPermissions))
        {
            multi.SelectedUser = multi.Users[0]; source.Pending = new(); var stale = multi.QueryAsync();
            multi.DatabaseChoices[1].IsSelected = true;
            source.Pending.SetResult(new([new("BASE_ANTERIOR", true, true)], []) { Databases = [new("Base vieja", "user", "No debe aparecer")] }); Run(stale);
            Check(multi.Memberships.Count == 0 && multi.DatabaseCoverage.Count == 0, "Cambiar bases descarta respuestas tardías de la consulta anterior");
            source.Pending = null;
        }
        using var context = Create(source, ReportKind.UserPermissions);
        source.PendingDatabases = new();
        context.SelectedServer = context.Servers[1]; var load = context.ContextLoad;
        context.SelectedServer = null;
        source.PendingDatabases.SetResult(["BASE_ANTIGUA"]); Run(load);
        Check(context.Databases.Count == 0 && context.Users.Count == 0, "Cambio de servidor descarta catálogos tardíos");
    }

    private static async Task SqlSmokeAsync(string server)
    {
        var builder = new SqlConnectionStringBuilder { DataSource = server, InitialCatalog = "master", IntegratedSecurity = true, Encrypt = true, TrustServerCertificate = true, ConnectTimeout = 5 };
        await using var cn = new SqlConnection(builder.ConnectionString); await cn.OpenAsync();
        var queries = typeof(DirectSqlServerService).Assembly.GetType("SqlAccessAdmin.Data.ReportsSql")!;
        string login; byte[] sid;
        await using (var identity = new SqlCommand("SELECT TOP(1) name,sid FROM sys.server_principals WHERE type IN ('S','U') AND name NOT LIKE N'##%' AND name NOT IN(N'dbo',N'guest',N'INFORMATION_SCHEMA',N'sys') ORDER BY CASE WHEN name=ORIGINAL_LOGIN() THEN 0 ELSE 1 END,name", cn))
        await using (var identityReader = await identity.ExecuteReaderAsync())
        {
            if (!await identityReader.ReadAsync()) throw new InvalidOperationException("No hay un login para las comprobaciones.");
            login = identityReader.GetString(0); sid = (byte[])identityReader[1];
        }
        foreach (var name in new[] { "Databases", "Users", "ServerAccess", "UserAccess", "Roles", "CredentialAge" })
        {
            var sql = (string)queries.GetField(name, BindingFlags.Static | BindingFlags.NonPublic)!.GetRawConstantValue()!;
            await using var command = new SqlCommand(sql, cn) { CommandTimeout = 15 };
            if (name == "UserAccess") command.Parameters.Add(new("@sid", SqlDbType.VarBinary, 85) { Value = sid });
            if (name == "ServerAccess") command.Parameters.Add(new("@user", SqlDbType.NVarChar, 128) { Value = login });
            await using var reader = await command.ExecuteReaderAsync();
            var sets = 0;
            do { while (await reader.ReadAsync()) { } sets++; } while (await reader.NextResultAsync());
            Check(sets == (name is "UserAccess" or "ServerAccess" or "Roles" ? 3 : 1), $"SQL real de solo lectura: {name}");
        }
        var instanceQueries = typeof(DirectSqlServerService).Assembly.GetType("SqlAccessAdmin.Data.InstanceReportsSql")!;
        foreach (var name in new[] { "ServerAccess", "DatabaseAccess" })
        {
            var sql = (string)instanceQueries.GetField(name, BindingFlags.Static | BindingFlags.NonPublic)!.GetRawConstantValue()!;
            await using var command = new SqlCommand(sql, cn) { CommandTimeout = 15 };
            await using var reader = await command.ExecuteReaderAsync();
            var sets = 0;
            do { while (await reader.ReadAsync()) { } sets++; } while (await reader.NextResultAsync());
            Check(sets == 3, $"SQL real de solo lectura para todos los logins: {name}");
        }
        const string age = """
            DECLARE @now datetime='20261022 00:01:00';
            SELECT COUNT(*) FROM (VALUES (DATEADD(day,-45,@now)),(DATEADD(second,-1,DATEADD(day,-45,@now))),
                (DATEADD(second,1,DATEADD(day,-45,@now)))) d(LastSet) WHERE LastSet<DATEADD(day,-45,@now);
            """;
        await using var boundary = new SqlCommand(age, cn);
        Check(Convert.ToInt32(await boundary.ExecuteScalarAsync()) == 1, "SQL real: umbral estricto de 45 días");
        await CredentialFixturesAsync(cn, queries);
        await SqlFixturesAsync(cn, queries);
        if(server=="localhost")
        {
            var gateway=new AdminDbGateway(new PivotOptions(server,"","adminDB",true,null,null,true,true));
            var direct=new DirectSqlServerService(gateway);
            var local=(await direct.GetReportServersAsync(CancellationToken.None))
                .Single(x=>x.Name.Equals(Environment.MachineName,StringComparison.OrdinalIgnoreCase));
            var credentials=await direct.GetCredentialAgeReportAsync(local.Id,CancellationToken.None);
            var auditor=credentials.Single(x=>x.Name=="auditor");
            Check(auditor.PasswordLastSet is not null && auditor.PasswordDateSource=="Cambio confirmado en la aplicación",
                "Integración local: auditor recupera la fecha confirmada por la app a través del servicio real");
            Check(auditor.Days==(int)(AppTime.Now-auditor.PasswordLastSet!.Value).TotalDays,
                "Integración local: antigüedad de auditor calculada desde su cambio confirmado");
            var instance = await direct.GetInstanceAccessReportAsync(local.Id, ["master"], CancellationToken.None);
            var catalog = await direct.GetRoleCatalogReportAsync(local.Id, "adminDB", CancellationToken.None);
            Check(catalog.Any(x => x.Name == "SqlAccessAdmin_Operator" && x.DirectPermissions.Count > 0),
                "Integración local: catálogo real recupera los permisos del rol Operator");
            await using var expectedCommand = new SqlCommand("SELECT COUNT(*) FROM sys.server_principals WHERE type IN ('S','U') AND name NOT LIKE N'#%' AND UPPER(name) NOT LIKE N'NT %'", cn);
            Check(instance.Logins.Count == Convert.ToInt32(await expectedCommand.ExecuteScalarAsync())
                && instance.Databases.Count == instance.Logins.Count, "Integración local: servicio conserva todos los logins y revisa master para cada uno");
            Check(instance.Logins.Any(x => x.IsSysadmin) && instance.Roles.Any(x => x.Name == "sysadmin")
                && instance.Permissions.All(x => x.CoveredBySysadmin == instance.Logins.Single(l => l.Name == x.Login).IsSysadmin),
                "Integración local: lectura en bloque conserva sysadmin y clasifica permisos por login");
        }
    }

    private static async Task CredentialFixturesAsync(SqlConnection cn, Type queries)
    {
        // Execute the production query over read-only fixtures; never alter real logins.
        var sql = (string)queries.GetField("CredentialAge", BindingFlags.Static | BindingFlags.NonPublic)!.GetRawConstantValue()!;
        sql = sql[sql.IndexOf("DECLARE @now", StringComparison.Ordinal)..]
            .Replace("GETDATE()", "CONVERT(datetime,'20261026 18:00:00')")
            .Replace("sys.server_principals", "@logins").Replace("sys.sql_logins", "@policies")
            .Replace("LOGINPROPERTY(l.name,'PasswordLastSetTime')", "l.PasswordDate");
        const string fixture = """
            DECLARE @logins TABLE(principal_id int,name sysname,type char(1),type_desc nvarchar(60),is_disabled bit,create_date datetime,modify_date datetime,PasswordDate datetime,sid varbinary(85));
            INSERT @logins(principal_id,name,type,type_desc,is_disabled,create_date,modify_date,PasswordDate) VALUES
            (1,N'auditor','S','SQL_LOGIN',0,'20261022','20261026 17:00:00','19000101'),
            (2,N'reciente','S','SQL_LOGIN',0,'20261022','20261026 17:00:00','20261026 17:00:00'),
            (3,N'antiguo','S','SQL_LOGIN',1,'20260101','20260102','20260102'),
            (4,N'DOMINIO\usuario','U','WINDOWS_LOGIN',0,'20260101','20261022',NULL),
            (5,N'grupo','G','WINDOWS_GROUP',0,'20260101','20261022',NULL),
            (6,N'##interno','S','SQL_LOGIN',0,'20260101','20261022',NULL),
            (7,N'NT AUTHORITY\SYSTEM','U','WINDOWS_LOGIN',0,'20260101','20261022',NULL),
            (8,N'NT SERVICE\Motor','U','WINDOWS_LOGIN',0,'20260101','20261022',NULL),
            (9,N'futura','S','SQL_LOGIN',0,'20260101','20261022','20990101');
            DECLARE @policies TABLE(principal_id int,is_policy_checked bit,is_expiration_checked bit);
            INSERT @policies VALUES(1,1,1),(2,1,0),(3,0,0),(9,1,1);
            """;
        await using var command = new SqlCommand(fixture + sql, cn);
        await using var reader = await command.ExecuteReaderAsync();
        var table = new DataTable(); table.Load(reader);
        Check(table.Rows.Count == 5, "SQL credenciales: incluye recientes, antiguos y Windows; excluye grupos e internos");
        var auditor = table.Select("name='auditor'").Single();
        Check(auditor.IsNull("LastSet") && auditor.IsNull("DaysElapsed") && auditor.Field<int>("ModificationDays") == 0,
            "SQL credenciales: 1900 no produce 46 mil días; conserva modificación reciente separada");
        Check(table.Select("name='reciente'").Single().Field<int>("DaysElapsed") == 0, "SQL credenciales: contraseña reciente muestra cero días");
        Check(table.Select("name='futura'").Single().IsNull("LastSet"), "SQL credenciales: rechaza fechas futuras");
        var windows = table.Rows.Cast<DataRow>().Single(x => x.Field<string>("LoginType") == "WINDOWS_LOGIN");
        Check(windows.IsNull("LastSet") && windows.IsNull("DaysElapsed") && windows.IsNull("is_policy_checked"), "SQL credenciales: Windows sin fecha ni política SQL inventadas");
    }

    private static async Task SqlFixturesAsync(SqlConnection cn, Type queries)
    {
        // Table variables stand in for system views. This exercises joins, nesting, deduplication,
        // empty roles and direct permission scopes without creating objects or changing any access.
        const string fixture = """
            DECLARE @principals TABLE(principal_id int, name sysname, type char(1), type_desc nvarchar(60), is_fixed_role bit, sid varbinary(85));
            INSERT @principals(principal_id,name,type,type_desc,is_fixed_role) VALUES (1,N'o''brien','S','SQL_USER',0),(2,N'db_datareader','R','DATABASE_ROLE',1),
                (3,N'rol_equipo','R','DATABASE_ROLE',0),(4,N'rol_anidado','R','DATABASE_ROLE',0),
                (5,N'public','R','DATABASE_ROLE',0),(6,N'sin_miembros','R','DATABASE_ROLE',0),(7,N'otro_usuario','U','WINDOWS_USER',0),
                (8,N'dbo','U','WINDOWS_USER',0),(9,N'guest','S','SQL_USER',0),(10,N'INFORMATION_SCHEMA','S','SQL_USER',0),
                (11,N'sys','S','SQL_USER',0),(12,N'grupo_windows','G','WINDOWS_GROUP',0),(13,N'huerfano','S','SQL_USER',0),
                (14,N'certificado','C','CERTIFICATE_MAPPED_USER',0),(15,N'contenido','S','SQL_USER',0);
            UPDATE @principals SET sid=CONVERT(varbinary(85),principal_id);
            DECLARE @logins TABLE(name sysname,sid varbinary(85),type char(1),type_desc nvarchar(60),principal_id int,is_fixed_role bit,is_disabled bit DEFAULT 0);
            INSERT @logins(name,sid,type,type_desc) VALUES (N'login_con_otro_nombre',CONVERT(varbinary(85),1),'S','SQL_LOGIN'),
                (N'DOMINIO\usuario',CONVERT(varbinary(85),7),'U','WINDOWS_LOGIN'),
                (N'propietario',CONVERT(varbinary(85),8),'U','WINDOWS_LOGIN'),
                (N'guest',CONVERT(varbinary(85),9),'S','SQL_LOGIN'),
                (N'INFORMATION_SCHEMA',CONVERT(varbinary(85),10),'S','SQL_LOGIN'),
                (N'sys',CONVERT(varbinary(85),11),'S','SQL_LOGIN'),
                (N'grupo_windows',CONVERT(varbinary(85),12),'G','WINDOWS_GROUP'),
                (N'certificado',CONVERT(varbinary(85),14),'C','CERTIFICATE_MAPPED_LOGIN'),
                (N'NT AUTHORITY\SYSTEM',CONVERT(varbinary(85),50),'U','WINDOWS_LOGIN'),
                (N'NT AUTHORITY\NETWORK SERVICE',CONVERT(varbinary(85),51),'U','WINDOWS_LOGIN'),
                (N'NT Service\MSSQLSERVER',CONVERT(varbinary(85),52),'U','WINDOWS_LOGIN'),
                (N'nt service\SQLSERVERAGENT',CONVERT(varbinary(85),53),'U','WINDOWS_LOGIN'),
                (N'NT_operador',CONVERT(varbinary(85),54),'S','SQL_LOGIN');
            UPDATE @logins SET principal_id=CONVERT(int,sid),is_fixed_role=0;
            INSERT @logins(name,sid,type,type_desc,principal_id,is_fixed_role) VALUES(N'operadores_instancia',0x20,'R','SERVER_ROLE',20,0),(N'sysadmin',0x21,'R','SERVER_ROLE',21,1),
                (N'public',0x22,'R','SERVER_ROLE',22,0),(N'##MS_Internal##',0x23,'S','SQL_LOGIN',23,0),(N'dbo',0x24,'S','SQL_LOGIN',24,0);
            DECLARE @servermembers TABLE(role_principal_id int,member_principal_id int);
            INSERT @servermembers VALUES(20,1),(21,20),(20,21),(21,7);
            DECLARE @serverpermissions TABLE(class int,class_desc nvarchar(60),major_id int,grantee_principal_id int,permission_name nvarchar(128),state char(1));
            INSERT @serverpermissions VALUES(100,N'SERVER',0,1,N'CONTROL SERVER','G'),(101,N'SERVER_PRINCIPAL',7,1,N'IMPERSONATE','D'),
                (105,N'ENDPOINT',3,1,N'CONNECT','W'),(100,N'SERVER',0,7,N'ALTER ANY LOGIN','G');
            DECLARE @endpoints TABLE(endpoint_id int,name sysname); INSERT @endpoints VALUES(3,N'endpoint_local');
            DECLARE @members TABLE(role_principal_id int,member_principal_id int);
            INSERT @members VALUES (2,1),(3,1),(4,2),(4,3),(3,4),(2,7),(2,8),(2,9),(2,10),(2,11),(2,12),(2,13),(2,14),(2,15);
            DECLARE @objects TABLE(object_id int,schema_id int,name sysname,type char(2),is_ms_shipped bit);
            INSERT @objects VALUES (10,1,N'Ventas','U',0),(11,1,N'sin_permiso','U',0);
            DECLARE @schemas TABLE(schema_id int,name sysname); INSERT @schemas VALUES (1,N'dbo');
            DECLARE @columns TABLE(object_id int,column_id int,name sysname); INSERT @columns VALUES (10,1,N'importe');
            DECLARE @permissions TABLE(class int,major_id int,minor_id int,grantee_principal_id int,permission_name nvarchar(128),state char(1),class_desc nvarchar(60));
            INSERT @permissions(class,major_id,minor_id,grantee_principal_id,permission_name,state) VALUES (1,10,0,1,N'SELECT','G'),(1,10,1,1,N'SELECT','R'),
                (1,10,0,1,N'UPDATE','D'),(3,1,0,1,N'EXECUTE','W'),(0,0,0,1,N'CONNECT','G'),
                (1,11,0,2,N'SELECT','G'),(1,10,0,7,N'DELETE','G');
            INSERT @permissions VALUES (3,1,0,3,N'EXECUTE','W',N'SCHEMA'),(1,10,0,3,N'DELETE','D',N'OBJECT_OR_COLUMN'),
                (1,10,1,3,N'SELECT','R',N'OBJECT_OR_COLUMN'),(25,321,0,4,N'CONTROL','G',N'CERTIFICATE');
            DECLARE @databases TABLE(database_id int,owner_sid varbinary(85));
            INSERT @databases VALUES(DB_ID(),CONVERT(varbinary(85),1));
            """;
        var guard = (string)queries.GetField("DatabaseVisibility", BindingFlags.NonPublic | BindingFlags.Static)!.GetRawConstantValue()!;
        var loginGuard = (string)queries.GetField("LoginVisibility", BindingFlags.NonPublic | BindingFlags.Static)!.GetRawConstantValue()!;
        var serverSql = (string)queries.GetField("ServerAccess", BindingFlags.NonPublic | BindingFlags.Static)!.GetRawConstantValue()!;
        var serverGuard = serverSql[..serverSql.IndexOf("DECLARE @id int,", StringComparison.Ordinal)];
        string ForFixture(string name) => TransformQuery((string)queries.GetField(name, BindingFlags.NonPublic | BindingFlags.Static)!.GetRawConstantValue()!);
        string TransformQuery(string sql) => fixture + sql
            .Replace(guard, "")
            .Replace(loginGuard, "")
            .Replace(serverGuard, "")
            .Replace("IS_SRVROLEMEMBER(N'sysadmin',@user)", "0")
            .Replace("DATABASE_PRINCIPAL_ID(@user)", "(SELECT principal_id FROM @principals WHERE name=@user)")
            .Replace("sys.database_principals", "@principals").Replace("sys.database_role_members", "@members")
            .Replace("sys.server_principals", "@logins")
            .Replace("sys.server_role_members", "@servermembers").Replace("sys.server_permissions", "@serverpermissions").Replace("sys.endpoints", "@endpoints")
            .Replace("sys.databases", "@databases")
            .Replace("sys.database_permissions", "@permissions").Replace("sys.objects", "@objects")
            .Replace("sys.schemas", "@schemas").Replace("sys.columns", "@columns");
        var instanceQueries = typeof(DirectSqlServerService).Assembly.GetType("SqlAccessAdmin.Data.InstanceReportsSql")!;
        var instanceGuard = (string)instanceQueries.GetField("ServerVisibility", BindingFlags.NonPublic | BindingFlags.Static)!.GetRawConstantValue()!;
        foreach (var context in new[] { "ServerAccess", "DatabaseAccess" })
        {
            var sql = ((string)instanceQueries.GetField(context, BindingFlags.NonPublic | BindingFlags.Static)!.GetRawConstantValue()!)
                .Replace(instanceGuard, "").Replace("IS_SRVROLEMEMBER(N'sysadmin',l.name)", "0");
            await using var command = new SqlCommand(TransformQuery(sql), cn);
            await using var reader = await command.ExecuteReaderAsync();
            var inventory = new DataTable(); inventory.Load(reader);
            var rolesTable = new DataTable(); rolesTable.Load(reader);
            var permissionsTable = new DataTable(); permissionsTable.Load(reader);
            var nameColumn = context == "ServerAccess" ? "name" : "LoginName";
            var names = inventory.Rows.Cast<DataRow>().Select(x => x.Field<string>(nameColumn)!).ToList();
            Check(names.Contains("login_con_otro_nombre") && names.Contains("DOMINIO\\usuario") && names.Contains("NT_operador")
                && names.All(x => !x.StartsWith("#") && !x.StartsWith("NT ", StringComparison.OrdinalIgnoreCase))
                && !names.Contains("grupo_windows"), "SQL instancia: todos los logins SQL y Windows con exclusiones correctas · " + context);
            Check(rolesTable.Rows.Cast<DataRow>().All(x => x.Field<string>("name") != "public"), "SQL instancia: omite public · " + context);
            if (context == "ServerAccess")
            {
                Check(inventory.Select("name='DOMINIO\\usuario'").Single().Field<bool>("IsSysadmin")
                    && inventory.Select("name='login_con_otro_nombre'").Single().Field<bool>("IsSysadmin"), "SQL instancia: sysadmin directo y anidado incluidos en inventario");
                Check(rolesTable.Select("LoginName='login_con_otro_nombre'").Length == 2, "SQL instancia: roles deduplicados por login con rutas y ciclos");
                Check(permissionsTable.Rows.Count == 4 && permissionsTable.Rows.Cast<DataRow>().Any(x => x.Field<string>("Action") == "GRANT WITH GRANT OPTION"),
                    "SQL instancia: permisos directos de todos los logins conservan acciones");
            }
            else
            {
                Check(inventory.Select("LoginName='login_con_otro_nombre'").Single().Field<string>("MappedUser") == "o'brien",
                    "SQL instancia: mapeo por SID conserva alias y comillas");
                Check(inventory.Select("LoginName='NT_operador'").Single().Field<string>("MappedUser") == "",
                    "SQL instancia: inventario conserva logins sin mapeo");
                Check(permissionsTable.Select("LoginName='login_con_otro_nombre'").Length == 5
                    && permissionsTable.Rows.Cast<DataRow>().Any(x => x.Field<string>("Action")!.StartsWith("REVOKE")), "SQL instancia: permisos directos de base y excepciones de columna");
            }
        }
        await using (var command = new SqlCommand(ForFixture("UserAccess"), cn))
        {
            command.Parameters.Add(new("@sid", SqlDbType.VarBinary, 85) { Value = new byte[] { 0, 0, 0, 1 } });
            await using var reader = await command.ExecuteReaderAsync();
            Check(await reader.ReadAsync() && reader.GetString(0) == "o'brien" && reader.GetBoolean(1), "SQL: resuelve usuario por SID y detecta propietario de base");
            await reader.NextResultAsync();
            var roles = new List<string>(); var assignments = new Dictionary<string, bool>();
            while (await reader.ReadAsync()) { roles.Add(reader.GetString(0)); assignments.Add(reader.GetString(0), reader.GetBoolean(2)); }
            Check(roles.Count == 4 && roles.Distinct().Count() == 4, "SQL: rutas anidadas y ciclos no duplican roles");
            Check(assignments["db_datareader"] && assignments["rol_equipo"] && !assignments["rol_anidado"], "SQL: distingue membresía directa y heredada");
            await reader.NextResultAsync();
            var direct = new List<(string Scope, string Object, string Action)>();
            while (await reader.ReadAsync()) direct.Add((reader.GetString(0), reader.GetString(2), reader.GetString(6)));
            Check(direct.Count == 5 && direct.All(x => x.Object != "sin_permiso"), "SQL: solo permisos directos del usuario, sin expandir roles ni otros usuarios");
            Check(direct.Select(x => x.Scope).Distinct().Count() == 4 && direct.Any(x => x.Action.StartsWith("REVOKE"))
                && direct.Any(x => x.Action == "GRANT WITH GRANT OPTION") && direct.Any(x => x.Action == "DENY"), "SQL: base, esquema, objeto y columna conservan su acción");
        }
        await using (var command = new SqlCommand(ForFixture("UserAccess"), cn))
        {
            command.Parameters.Add(new("@sid", SqlDbType.VarBinary, 85) { Value = new byte[] { 250, 251 } });
            await using var reader = await command.ExecuteReaderAsync();
            Check(await reader.ReadAsync() && reader.GetString(0) == "", "SQL: informa ausencia de usuario mapeado sin usar dbo o guest");
            await reader.NextResultAsync();
            Check(!await reader.ReadAsync(), "SQL: no inventa roles de base para un login sin mapeo");
            await reader.NextResultAsync();
            Check(!await reader.ReadAsync(), "SQL: no inventa permisos de base para un login sin mapeo");
        }
        await using (var command = new SqlCommand(ForFixture("Roles"), cn))
        {
            await using var reader = await command.ExecuteReaderAsync();
            var rows = new List<(string Role, string? Member, string? Type)>();
            while (await reader.ReadAsync()) rows.Add((reader.GetString(0), reader.IsDBNull(2) ? null : reader.GetString(2), reader.IsDBNull(3) ? null : reader.GetString(3)));
            Check(rows.Any(x => x.Role == "sin_miembros" && x.Member is null), "SQL: conserva roles personalizados sin miembros");
            Check(rows.Count(x => x.Role == "public") == 2, "SQL: public muestra usuarios implícitos");
            Check(rows.Where(x => x.Member is not null).All(x => x.Type is "SQL_LOGIN" or "WINDOWS_LOGIN"), "SQL: miembros solo de logins SQL y Windows individuales");
            Check(rows.Where(x => x.Role == "db_datareader" && x.Member is not null).Select(x => x.Member).Order().SequenceEqual(new[] { "o'brien", "otro_usuario" }),
                "SQL: excluye usuarios internos, grupos, roles, certificados, contenidos y huérfanos de la membresía directa");
            Check(rows.Any(x => x.Member == "o'brien" && x.Type == "SQL_LOGIN"), "SQL: resuelve el login por SID aunque tenga otro nombre");
            await reader.NextResultAsync();
            var permissions = new List<(string Role, string Scope, string Resource, string Action)>();
            while (await reader.ReadAsync()) permissions.Add((reader.GetString(0),reader.GetString(1),reader.GetString(3),reader.GetString(7)));
            Check(permissions.Count == 5 && permissions.Any(x => x.Role == "rol_equipo" && x.Action == "DENY")
                && permissions.Any(x => x.Action == "GRANT WITH GRANT OPTION") && permissions.Any(x => x.Action.StartsWith("REVOKE"))
                && permissions.Any(x => x.Scope == "CERTIFICATE" && x.Resource == "Id 321"), "SQL: permisos de roles incluyen DENY, delegación, columnas y clases adicionales");
            await reader.NextResultAsync();
            var links = new List<ReportRoleLink>();
            while (await reader.ReadAsync()) links.Add(new(reader.GetString(0),reader.GetString(1)));
            Check(links.Count == 3 && links.Contains(new("db_datareader","rol_anidado")) && !links.Any(x => x.Member == "o'brien"),
                "SQL: herencia conserva dirección, rutas múltiples y ciclos sin mezclar usuarios");
        }
        await using (var command = new SqlCommand(ForFixture("Users"), cn))
        {
            await using var reader = await command.ExecuteReaderAsync(); var names = new List<string>(); var valid = true;
            while (await reader.ReadAsync()) { names.Add(reader.GetString(0)); valid &= reader.GetString(1) is "SQL_LOGIN" or "WINDOWS_LOGIN"; }
            Check(valid && names.Contains("login_con_otro_nombre") && names.Contains("DOMINIO\\usuario"), "SQL: selector de logins independiente de las bases");
            Check(!names.Intersect(new[] { "dbo", "guest", "INFORMATION_SCHEMA", "sys", "##MS_Internal##", "grupo_windows", "certificado" }).Any(), "SQL: selector excluye internos, grupos y certificados");
            Check(!names.Intersect(new[] { "NT AUTHORITY\\SYSTEM", "NT AUTHORITY\\NETWORK SERVICE", "NT Service\\MSSQLSERVER", "nt service\\SQLSERVERAGENT" }).Any()
                && names.Contains("NT_operador"), "SQL: selector excluye cuentas NT y de servicios sin eliminar logins SQL ordinarios");
        }
        await using (var command = new SqlCommand(ForFixture("ServerAccess"), cn))
        {
            command.Parameters.Add(new("@user", SqlDbType.NVarChar, 128) { Value = "login_con_otro_nombre" });
            await using var reader = await command.ExecuteReaderAsync();
            Check(await reader.ReadAsync() && ((byte[])reader[0]).SequenceEqual(new byte[] { 0, 0, 0, 1 }), "SQL: reporte de instancia conserva el SID del login");
            await reader.NextResultAsync(); var roleRows = new List<(string Name, bool Direct)>();
            while (await reader.ReadAsync()) roleRows.Add((reader.GetString(0), reader.GetBoolean(2)));
            Check(roleRows.Count == 3 && roleRows.Any(x => x.Name == "sysadmin" && !x.Direct) && roleRows.Any(x => x.Name == "operadores_instancia" && x.Direct),
                "SQL: sysadmin heredado y roles de instancia sin duplicados ni ciclos");
            await reader.NextResultAsync(); var permissionRows = new List<(string Name, string Permission, string Action)>();
            while (await reader.ReadAsync()) permissionRows.Add((reader.GetString(2), reader.GetString(5), reader.GetString(6)));
            Check(permissionRows.Count == 3 && permissionRows.Any(x => x.Permission == "CONTROL SERVER") && permissionRows.All(x => x.Permission != "ALTER ANY LOGIN"),
                "SQL: permisos de instancia solo del login elegido");
            Check(permissionRows.Any(x => x.Name == "endpoint_local" && x.Action == "GRANT WITH GRANT OPTION") && permissionRows.Any(x => x.Action == "DENY"),
                "SQL: conserva destinos y acciones de permisos de instancia");
        }
    }

    private static void RenderExportOptions(ReportExportFormat format, string path)
    {
        var dialog = new ReportExportOptionsWindow(format, "Permisos directos");
        Check(dialog.Scope == ReportExportScope.FullReport && ((TextBlock)dialog.FindName("ActiveSectionDescription")).Text == "Permisos directos", "Modal ofrece reporte completo por defecto e identifica la pestaña activa");
        ((RadioButton)dialog.FindName("ActiveSectionOption")).IsChecked = true;
        Check(dialog.Scope == ReportExportScope.ActiveSection && ((RadioButton)dialog.FindName("FullReportOption")).IsChecked == false, "Opciones del modal son excluyentes y permiten elegir la pestaña activa");
        var content = (FrameworkElement)dialog.Content; dialog.Content = null;
        TextElement.SetForeground(content, new SolidColorBrush(Color.FromRgb(18, 32, 51)));
        content.Measure(new(540, double.PositiveInfinity));
        var height = (int)Math.Ceiling(content.DesiredSize.Height);
        Layout(content, 540, height);
        var background = new DrawingVisual();
        using (var drawing = background.RenderOpen()) drawing.DrawRectangle(new SolidColorBrush(Color.FromRgb(244, 247, 252)), null, new(0, 0, 540, height));
        var bitmap = new RenderTargetBitmap(540, height, 96, 96, PixelFormats.Pbgra32); bitmap.Render(background); bitmap.Render(content);
        var png = new PngBitmapEncoder(); png.Frames.Add(BitmapFrame.Create(bitmap));
        using var file = File.Create(path); png.Save(file);
    }

    private static void RenderMain(ReportsViewModel vm, string path, int width, int height, int selectedTab = 0, bool showDatabaseOptions = false, bool showLoginOptions = false)
    {
        var command = new RelayCommand(() => { });
        var window = new MainWindow { DataContext = new
        {
            Current = vm, ActiveReport = (ReportKind?)vm.Kind, Title = "Reportes", Session = new SessionContext("EQUIPO\\operador", AppRole.Operator),
            CanReports = true, CanAnyReports = true, SessionStatus = "", HasSessionError = false,
            DashboardCommand = command, AccessCommand = command, RequestHistoryCommand = command, ServersCommand = command,
            UsersCommand = command, PolicyCommand = command, AuditCommand = command,
            UserPermissionsReportCommand = command, InstancePermissionsReportCommand = command, RoleCatalogReportCommand = command, CredentialAgeReportCommand = command,
            TemporaryAccessCommand = command, AccessChangesReportCommand = new RelayCommand(()=>{},()=>false),PasswordChangesReportCommand = new RelayCommand(()=>{},()=>false)
        } };
        var tree = (TreeView)window.FindName("ReportsNavigation");
        var root = (TreeViewItem)tree.Items[0];
        ((Button)root.Header).RaiseEvent(new RoutedEventArgs(Button.ClickEvent));
        Check(root.IsExpanded, "La cabecera Reportes despliega el árbol");
        ((TreeViewItem)tree.Items[0]).IsExpanded = true;
        var content = (FrameworkElement)window.Content; window.Content = null; content.DataContext = window.DataContext;
        content.Resources = window.Resources;
        TextElement.SetForeground(content, new SolidColorBrush(Color.FromRgb(18,32,51)));
        Layout(content, width, height);
        if (vm.IsUserPermissions)
        {
            var loginSelector = FindVisuals<Expander>(content).Single(x => System.Windows.Automation.AutomationProperties.GetName(x) == "Seleccionar login");
            var databaseSelector = FindVisuals<Expander>(content).Single(x => System.Windows.Automation.AutomationProperties.GetName(x) == "Seleccionar bases");
            Check(!loginSelector.IsExpanded && Math.Abs(loginSelector.ActualHeight - databaseSelector.ActualHeight) < 0.1
                && Equals(loginSelector.Header, vm.SelectedUser?.Name), "Login cerrado muestra la selección y tiene la misma altura que Bases");
            var tabs = FindVisuals<TabControl>(content).First();
            tabs.SetCurrentValue(System.Windows.Controls.Primitives.Selector.SelectedIndexProperty, selectedTab);
            Pump();
            Check(tabs.Items.Cast<TabItem>().Count(x => x.Visibility == Visibility.Visible) == 3 && vm.ActiveSectionIndex == selectedTab && vm.ActiveSectionName == ((TabItem)tabs.SelectedItem).Header.ToString(), "Las tres pestañas conservan sus bloques y comunican la selección a la exportación");
            if (showDatabaseOptions) FindVisuals<Expander>(content).Single(x => System.Windows.Automation.AutomationProperties.GetName(x) == "Seleccionar bases").IsExpanded = true;
            Layout(content, width, height);
            var grid = FindVisuals<DataGrid>(tabs).Single();
            var expectedRows = selectedTab switch { 1 => (object)vm.Permissions, 2 => vm.DatabaseCoverage, _ => vm.Memberships };
            Check(ReferenceEquals(grid.ItemsSource, expectedRows), "La pestaña activa muestra únicamente los datos de su bloque lógico");
            if (showDatabaseOptions)
            {
                loginSelector.IsExpanded = true; Layout(content, width, height);
                var login = vm.SelectedUser;
                var search = FindVisuals<TextBox>(content).Single(x => System.Windows.Automation.AutomationProperties.GetName(x) == "Buscar login SQL o Windows");
                search.SetCurrentValue(TextBox.TextProperty, login!.Name.ToUpperInvariant()); Pump();
                var users = FindVisuals<ListBox>(content).Single(x => System.Windows.Automation.AutomationProperties.GetName(x) == "Usuario del reporte");
                Check(vm.LoginSearch == login.Name.ToUpperInvariant() && users.Items.Count == 1 && vm.SelectedUser == login && vm.CanExport,
                    "Buscador WPF filtra el selector sin perder el login seleccionado ni su reporte");
                search.SetCurrentValue(TextBox.TextProperty, ""); Pump();
                loginSelector.IsExpanded = false;
                var choice = vm.DatabaseChoices[0]; var selected = choice.IsSelected;
                var box = FindVisuals<CheckBox>(content).First(x => ReferenceEquals(x.DataContext, choice));
                box.SetCurrentValue(System.Windows.Controls.Primitives.ToggleButton.IsCheckedProperty, !selected);
                Check(choice.IsSelected != selected, "Selector WPF permite marcar varias bases");
                box.SetCurrentValue(System.Windows.Controls.Primitives.ToggleButton.IsCheckedProperty, selected);
                Run(vm.QueryAsync()); Layout(content, width, height);
            }
            if (showLoginOptions) { loginSelector.IsExpanded = true; Layout(content, width, height); }
        }
        if (vm.IsInstancePermissions)
        {
            var tabs = FindVisuals<TabControl>(content).First();
            tabs.SetCurrentValue(System.Windows.Controls.Primitives.Selector.SelectedIndexProperty, selectedTab);
            Layout(content, width, height);
            Check(vm.ActiveSectionIndex == selectedTab && tabs.Items.Cast<TabItem>().Count(x => x.Visibility == Visibility.Visible) == 4,
                "Reporte por instancia muestra cuatro pestañas y comunica la selección");
            var grid = FindVisuals<DataGrid>(tabs).Single();
            var expected = selectedTab switch { 1 => (object)vm.Permissions, 2 => vm.DatabaseCoverage, 3 => vm.InstanceLogins, _ => vm.Memberships };
            Check(ReferenceEquals(grid.ItemsSource, expected), "Pestaña de instancia enlaza su bloque de resultados");
            Check(!FindVisuals<Expander>(content).Any(x => x.IsVisible && System.Windows.Automation.AutomationProperties.GetName(x) == "Seleccionar login"),
                "Reporte por instancia no solicita elegir un login");
            if (selectedTab != 3) Check(grid.Columns.First().Visibility == Visibility.Visible, "Identidad del login visible junto al usuario mapeado");
        }
        if (vm.IsRoleCatalog)
        {
            var detail = FindVisuals<TreeView>(content).Single(x => System.Windows.Automation.AutomationProperties.GetName(x) == "Permisos y miembros del rol");
            Layout(content, width, height);
            var rootDetail = (TreeViewItem)detail.ItemContainerGenerator.ContainerFromIndex(0);
            Check(rootDetail is not null && rootDetail.IsExpanded, "Árbol del rol seleccionado visible y raíz abierta");
            if (vm.SelectedRole?.Name == "ventas_lectura")
            {
                foreach (var item in FindVisuals<TreeViewItem>(detail).ToList()) item.IsExpanded = true;
                Layout(content, width, height);
                foreach (var item in FindVisuals<TreeViewItem>(detail).ToList()) item.IsExpanded = true;
                Layout(content, width, height);
                Check(FindVisuals<TextBlock>(detail).Any(x => x.Text.Contains("Denegado")), "Árbol WPF despliega denegaciones del rol");
            }
            var grid = FindVisuals<DataGrid>(content).Single(x => System.Windows.Automation.AutomationProperties.GetName(x) == "Catálogo de roles");
            Check(grid.Columns.Single(x => Equals(x.Header, "Usuarios")).Visibility == (vm.IncludeRoleMembersInExport ? Visibility.Visible : Visibility.Collapsed),
                "La columna de usuarios se muestra únicamente al incluir miembros");
            var checkbox = FindVisuals<CheckBox>(content).First(x => System.Windows.Automation.AutomationProperties.GetName(x) == "Exportar miembros de db_datareader");
            Check(checkbox.IsEnabled == vm.IncludeRoleMembersInExport, "Casillas de miembros respetan la opción de exportación");
            if (checkbox.IsEnabled)
            {
                var role = vm.Roles.Single(x => x.Name == "db_datareader");
                var previous = role.ExportMembers;
                checkbox.SetCurrentValue(System.Windows.Controls.Primitives.ToggleButton.IsCheckedProperty, !previous);
                Check(role.ExportMembers != previous, "La casilla WPF cambia la selección del rol incluso en una tabla de solo lectura");
                checkbox.SetCurrentValue(System.Windows.Controls.Primitives.ToggleButton.IsCheckedProperty, previous);
            }
        }
        var otherButton = FindButtons(content).First(x => x.Command == command && x != root.Header);
        var reportButton = (Button)root.Header;
        var reportX = reportButton.TransformToAncestor(content).Transform(new Point()).X;
        var otherX = otherButton.TransformToAncestor(content).Transform(new Point()).X;
        Check(Math.Abs(reportX - otherX) < 0.1 && Math.Abs(reportButton.ActualWidth - otherButton.ActualWidth) < 0.1,
            "Reportes coincide con la posición y anchura de los demás botones");
        Check(((TreeViewItem)tree.Items[0]).Items.Count == 2, "Árbol de reportes con ambas categorías");
        var background = new DrawingVisual();
        using (var drawing = background.RenderOpen()) drawing.DrawRectangle(new SolidColorBrush(Color.FromRgb(244,247,252)), null, new(0,0,width,height));
        var bitmap = new RenderTargetBitmap(width, height, 96, 96, PixelFormats.Pbgra32); bitmap.Render(background); bitmap.Render(content);
        var png = new PngBitmapEncoder(); png.Frames.Add(BitmapFrame.Create(bitmap));
        using var file = File.Create(path); png.Save(file);
    }
    private static void Layout(FrameworkElement view, int width, int height)
    {
        view.Measure(new(width, height)); view.Arrange(new(0, 0, width, height)); view.UpdateLayout(); Pump();
    }
    private static void Pump() => Dispatcher.CurrentDispatcher.Invoke(() => { }, DispatcherPriority.ApplicationIdle);
    private static IEnumerable<Button> FindButtons(DependencyObject parent)
        => FindVisuals<Button>(parent);
    private static IEnumerable<T> FindVisuals<T>(DependencyObject parent) where T : DependencyObject
    {
        for (var i = 0; i < VisualTreeHelper.GetChildrenCount(parent); i++)
        {
            var child = VisualTreeHelper.GetChild(parent, i);
            if (child is T match) yield return match;
            foreach (var nested in FindVisuals<T>(child)) yield return nested;
        }
    }
    private static void Run(Task task)
    {
        if (!task.IsCompleted)
        {
            var frame = new DispatcherFrame();
            var dispatcher = Dispatcher.CurrentDispatcher;
            task.ContinueWith(_ => dispatcher.BeginInvoke(() => frame.Continue = false), TaskScheduler.Default);
            Dispatcher.PushFrame(frame);
        }
        task.GetAwaiter().GetResult();
    }
    private static void Check(bool condition, string message)
    {
        if (!condition) throw new InvalidOperationException("FALLO: " + message);
        _checks++; Console.WriteLine("OK: " + message);
    }
}

internal sealed class FakeReports : IReportsDataSource
{
    public IReadOnlyList<ReportRole>? RoleCatalog { get; set; }
    public IReadOnlyList<string> LastDatabases { get; private set; } = [];
    public string? FailDatabase { get; set; }
    public bool Fail { get; set; }
    public TaskCompletionSource<UserAccessReport>? Pending { get; set; }
    public TaskCompletionSource<InstanceAccessReport>? PendingInstance { get; set; }
    public TaskCompletionSource<IReadOnlyList<string>>? PendingDatabases { get; set; }
    public Task<IReadOnlyList<ServerItem>> GetReportServersAsync(CancellationToken ct) => Task.FromResult<IReadOnlyList<ServerItem>>([
        new() { Id = 1, Name = "SQL Producción", Active = true }, new() { Id = 2, Name = "SQL Pruebas", Active = true }]);
    public Task<IReadOnlyList<string>> GetReportDatabasesAsync(int id, CancellationToken ct) => PendingDatabases?.Task ?? Task.FromResult<IReadOnlyList<string>>(["Operaciones", "Ventas"]);
    public Task<IReadOnlyList<ReportUser>> GetReportUsersAsync(int id, CancellationToken ct) => Task.FromResult<IReadOnlyList<ReportUser>>([
        new("operador_ventas", "SQL_LOGIN"), new("sin_accesos", "SQL_LOGIN"), new("administrador_sql", "SQL_LOGIN"), new("DOMINIO\\operador", "WINDOWS_LOGIN"), new("administrador_con_permisos", "SQL_LOGIN"),
        new("NT AUTHORITY\\SYSTEM", "WINDOWS_LOGIN"), new("NT AUTHORITY\\NETWORK SERVICE", "WINDOWS_LOGIN"), new("NT Service\\MSSQLSERVER", "WINDOWS_LOGIN"), new("nt service\\SQLSERVERAGENT", "WINDOWS_LOGIN"),
        new("grupo_windows", "WINDOWS_GROUP"), new("guest", "SQL_LOGIN"), new("##MS_Internal##", "SQL_LOGIN"), new("NT_operador", "SQL_LOGIN")]);
    public Task<UserAccessReport> GetUserAccessReportAsync(int id, IReadOnlyList<string> databases, string user, CancellationToken ct)
    {
        LastDatabases = databases.ToList();
        if (Fail) throw new InvalidOperationException("Sin visibilidad de metadatos");
        if (FailDatabase is not null && databases.Contains(FailDatabase)) throw new InvalidOperationException("No se pudo revisar la base " + FailDatabase);
        if (Pending is not null) return Pending.Task;
        if (user == "sin_accesos") return Task.FromResult(new UserAccessReport([], []));
        var admin = user is "administrador_sql" or "administrador_con_permisos";
        var unmappedAdmin = user == "administrador_sql";
        var mapped = user.StartsWith("DOMINIO") ? "usuario_windows_alias" : user;
        List<ReportRoleMembership> roles = [new("public", false, false) { Level = "Instancia", Principal = user }];
        List<ReportPermission> permissions = [];
        if (admin) roles.Add(new("sysadmin", true, unmappedAdmin) { Level = "Instancia", Principal = user });
        if (!unmappedAdmin)
        {
            permissions.Add(new("Instancia", "", "(instancia)", "", "", "CONNECT SQL", "GRANT") { Level = "Instancia", Principal = user });
            foreach (var db in databases)
            {
                roles.Add(new("db_datareader", true, true) { Database = db, Principal = mapped });
                roles.Add(new("public", false, false) { Database = db, Principal = mapped });
                permissions.AddRange(new[] {
                    new ReportPermission("Objeto", "dbo", "Ventas", "Tabla", "", "SELECT", "GRANT") { Database = db, Principal = mapped },
                    new ReportPermission("Objeto", "finanzas", "Pagos", "Tabla", "", "UPDATE", "DENY") { Database = db, Principal = mapped },
                    new ReportPermission("Columna", "dbo", "Ventas", "Tabla", "Importe", "SELECT", "REVOKE (excepción de columna)") { Database = db, Principal = mapped }
                });
            }
        }
        return Task.FromResult(new UserAccessReport(roles, permissions) { Databases = databases.Select(db => new ReportDatabaseCoverage(db, unmappedAdmin ? "Sin usuario mapeado" : mapped,
            admin ? "Control por sysadmin; no requiere usuario mapeado." : "Usuario mapeado; consulte sus roles y permisos directos.")).ToList() });
    }
    public Task<IReadOnlyList<ReportRole>> GetRoleCatalogReportAsync(int id, string db, CancellationToken ct) => Task.FromResult(RoleCatalog ?? RoleCatalogDetails.Attach([
        new("db_datareader", true, [new("ana", "SQL_LOGIN")]),
        new("ventas_lectura", false, []) { DirectPermissions = [
            new("Esquema","access","","","","EXECUTE","GRANT WITH GRANT OPTION"),
            new("Objeto","dbo","Solicitudes","Tabla","","SELECT","GRANT"),
            new("Objeto","dbo","Solicitudes","Tabla","","DELETE","DENY"),
            new("Columna","dbo","Solicitudes","Tabla","Importe","SELECT","REVOKE (excepción de columna)")] },
        new("public", false, [new("operador_ventas", "SQL_LOGIN")])], [new("ventas_lectura","db_datareader")]));
    public async Task<InstanceAccessReport> GetInstanceAccessReportAsync(int id, IReadOnlyList<string> databases, CancellationToken ct)
    {
        if (PendingInstance is not null) return await PendingInstance.Task;
        var users = (await GetReportUsersAsync(id, ct)).Where(x => x.Type is "SQL_LOGIN" or "WINDOWS_LOGIN")
            .Where(x => !x.Name.StartsWith("#") && !x.Name.StartsWith("NT ", StringComparison.OrdinalIgnoreCase) && x.Name != "guest").ToList();
        List<ReportRoleMembership> roles = [];
        List<ReportPermission> permissions = [];
        List<ReportDatabaseCoverage> coverage = [];
        foreach (var user in users)
        {
            var result = await GetUserAccessReportAsync(id, databases, user.Name, ct);
            roles.AddRange(result.Roles.Select(x => x with { Login = user.Name }));
            permissions.AddRange(result.Permissions.Select(x => x with { Login = user.Name }));
            coverage.AddRange(result.Databases.Select(x => x with { Login = user.Name }));
        }
        return new(users.Select(x => new ReportInstanceLogin(x.Name,x.Type,x.Name == "sin_accesos",x.Name.StartsWith("administrador"))).ToList(),roles,permissions) { Databases = coverage };
    }
    public Task<IReadOnlyList<CredentialAgeRow>> GetCredentialAgeReportAsync(int id, CancellationToken ct) => Task.FromResult<IReadOnlyList<CredentialAgeRow>>([
        new("integracion_ventas", false, new DateTime(2026, 8, 1, 10, 25, 0), 82, true, true),
        new("servicio_legacy", true, new DateTime(2026, 7, 1), 113, true, false),
        new("fecha_no_disponible", false, null, null, false, false, LastModified: new DateTime(2026, 10, 26), ModificationDays: 0),
        new("recien_cambiada", false, new DateTime(2026, 10, 26), 0, true, true),
        new(@"DOMINIO\usuario", false, null, null, null, null, "WINDOWS_LOGIN", new DateTime(2026, 10, 22), 4)]);
}
