using System.IO;
using System.Reflection;
using Microsoft.Data.SqlClient;
using SqlAccessAdmin.Data;
using SqlAccessAdmin.Models;
using SqlAccessAdmin.ViewModels;

internal static class Program
{
    private static int checks;
    [STAThread]
    private static void Main(string[] args)
    {
        Check(SqlPermissionSafety.DiscoverPermissions("VIEW DEFINITION", "EXTERNAL MODEL").Single().Scope == "EXTERNAL_MODEL", "Modelo externo reconocido");
        foreach (var scope in SqlPermissionSafety.Scopes.Where(s => s.Code != "COLUMN"))
            Check(SqlPermissionSafety.DiscoverPermissions("VIEW DEFINITION", scope.SqlClass.ToLowerInvariant().Replace(' ', '_')).Any(p => p.Scope == scope.Code), "Normalización: " + scope.Code);
        foreach (var name in new[] { "SELECT", "UPDATE", "REFERENCES", "UNMASK" })
            Check(SqlPermissionSafety.DiscoverPermissions(name, "OBJECT_OR_COLUMN").Any(p => p.Scope == "COLUMN"), "Columna: " + name);
        Check(!SqlPermissionSafety.DiscoverPermissions("DELETE", "OBJECT").Any(p => p.Scope == "COLUMN"), "DELETE no se extiende a columnas");
        var rows = new[] { ("SELECT", "OBJECT"), ("SELECT", "OBJECT"), ("EXECUTE", "FUTURE CLASS"), ("VIEW DEFINITION", "EXTERNAL MODEL") };
        var roles = new[] { new DiscoveredPolicyRole("custom_role", "CUSTOM", "DATABASE", "") };
        var catalog = SqlPermissionSafety.DiscoverCatalog(roles, rows);
        Check(catalog.Roles.Count == 1 && catalog.Permissions.Count == 3 && catalog.UnsupportedPermissions.Count == 1, "Conserva roles y permisos conocidos, deduplica y diagnostica el desconocido");
        Check(!SqlPermissionSafety.Supports("EXECUTE", "FUTURE_CLASS"), "Ámbito desconocido no ejecutable");
        Check(PolicyEditorCatalog.PermissionProtection("VIEW DEFINITION", "EXTERNAL_MODEL", []).Length > 0, "Modelo externo requiere autorización especial");
        foreach (var invalid in new[] { "", " select", "SELECT; DROP", "SELECT1", new string('A', 129) })
            Reject(() => SqlPermissionSafety.DiscoverCatalog([], [(invalid, "OBJECT")]), "Nombre inválido bloquea sincronización");
        Reject(() => SqlPermissionSafety.DiscoverCatalog([], []), "Catálogo vacío bloqueado");
        Reject(() => SqlPermissionSafety.DiscoverCatalog([], [("SELECT", "FUTURE CLASS")]), "Catálogo sin compatibles bloqueado");
        var store = new Store(); var discovery = new Discovery { Result = catalog };
        var vm = new PolicyViewModel(store, new("admin", AppRole.Administrator), _ => true, false, discovery);
        vm.RefreshCommand.Execute(null);
        ChangeContext(vm, new(1, "Pruebas"));
        Check(vm.CanEdit && vm.Roles.Count == 1 && store.Registered == catalog, "Destino se carga y registra pese a ámbito desconocido");
        Check(vm.DiscoveryWarning.Contains("EXECUTE / FUTURE CLASS"), "Advertencia específica visible");
        discovery.Result = SqlPermissionSafety.DiscoverCatalog(roles, [("SELECT", "OBJECT")]);
        vm.RefreshCommand.Execute(null);
        Check(vm.CanEdit && vm.DiscoveryWarning == "", "Actualizar catálogo limpio retira advertencia");
        discovery.Fail = true; vm.RefreshCommand.Execute(null);
        Check(!vm.CanEdit && vm.Roles.Count == 0 && vm.Status.Contains("visibilidad"), "Fallo real de descubrimiento impide editar");
        ChangeContext(vm, new(0, "Plantilla general"));
        Check(vm.CanEdit && vm.DiscoveryWarning == "", "Plantilla general recuperable tras fallo");
        if (args.Contains("--sql-smoke")) SqlSmoke();
        Console.WriteLine($"POLICY_CATALOG_CHECKS_OK: {checks}");
    }
    private static void ChangeContext(PolicyViewModel vm, PolicyServerChoice server) =>
        ((Task)typeof(PolicyViewModel).GetMethod("ChangeContextAsync", BindingFlags.Instance | BindingFlags.NonPublic)!
            .Invoke(vm, [server, new PolicyDatabaseChoice("", "Todas")])!).GetAwaiter().GetResult();
    private static void Check(bool value, string message) { if (!value) throw new Exception(message); checks++; }
    private static void Reject(Action action, string message)
    { try { action(); } catch (InvalidOperationException) { checks++; return; } throw new Exception(message); }
    private static void SqlSmoke()
    {
        using var cn = new SqlConnection("Server=localhost;Database=master;Integrated Security=true;Encrypt=true;TrustServerCertificate=true;Connect Timeout=10");
        cn.Open();
        var rows = new List<(string, string)>();
        using (var cmd = new SqlCommand("SELECT permission_name,class_desc FROM sys.fn_builtin_permissions(DEFAULT)", cn))
        using (var reader = cmd.ExecuteReader()) while (reader.Read()) rows.Add((reader.GetString(0), reader.GetString(1)));
        var result = SqlPermissionSafety.DiscoverCatalog([], rows);
        Check(result.Permissions.Count > 100 && result.UnsupportedPermissions.Count == 0, "Catálogo real completo sin ámbitos desconocidos");
        Check(result.Permissions.Any(p => p.Scope == "EXTERNAL_MODEL"), "Modelo externo en SQL real");
        // La migración se prueba dos veces sobre una tabla temporal, sin cambiar adminDB.
        using var create = new SqlCommand("CREATE TABLE #PolicyScopeCatalog(ScopeType varchar(20) PRIMARY KEY,SqlClass varchar(60),Parts int,IsServer bit); INSERT #PolicyScopeCatalog VALUES('OBJECT','OBJECT',2,0);", cn);
        create.ExecuteNonQuery();
        var migration = File.ReadAllText("InsumosProduccion/38_CompatibilidadCatalogoPoliticas.sql")
            .Replace("USE [adminDB];", "").Replace("OBJECT_ID(N'access.PolicyScopeCatalog',N'U')", "OBJECT_ID(N'tempdb..#PolicyScopeCatalog',N'U')")
            .Replace("[access].PolicyScopeCatalog", "#PolicyScopeCatalog");
        for (var i = 0; i < 2; i++)
            foreach (var batch in System.Text.RegularExpressions.Regex.Split(migration, @"(?im)^GO\s*$"))
                if (!string.IsNullOrWhiteSpace(batch)) { using var cmd = new SqlCommand(batch, cn); cmd.ExecuteNonQuery(); }
        using var verify = new SqlCommand("SELECT COUNT(*) FROM #PolicyScopeCatalog WHERE (ScopeType='EXTERNAL_MODEL' AND SqlClass='EXTERNAL MODEL' AND Parts=1 AND IsServer=0) OR (ScopeType='OBJECT' AND Parts=2)", cn);
        Check(Convert.ToInt32(verify.ExecuteScalar()) == 2, "Migración repetible conserva otros ámbitos");
        Console.WriteLine($"SQL_CATALOG: {rows.Count} filas, {result.Permissions.Count} combinaciones compatibles");
    }
    private sealed class Discovery : IPolicyDiscovery
    {
        public PolicyDiscoveryResult Result = new([]);
        public bool Fail;
        public Task<IReadOnlyList<DatabaseItem>> GetPolicyDatabasesAsync(ServerItem server, CancellationToken ct = default) => Task.FromResult<IReadOnlyList<DatabaseItem>>([]);
        public Task<PolicyDiscoveryResult> DiscoverPolicyAsync(PolicyContext context, CancellationToken ct = default) =>
            Fail ? throw new InvalidOperationException("Falta visibilidad del catálogo de roles.") : Task.FromResult(Result);
    }
    private sealed class Store : IPolicyStore
    {
        public PolicyDiscoveryResult? Registered;
        public Task<IReadOnlyList<ServerItem>> GetServersAsync(CancellationToken ct = default) => Task.FromResult<IReadOnlyList<ServerItem>>([new() { Id = 1, Name = "Pruebas", Active = true }]);
        public Task<IReadOnlyList<PolicyPermission>> GetPolicyPermissionsAsync(CancellationToken ct = default) => Task.FromResult<IReadOnlyList<PolicyPermission>>([]);
        public Task<IReadOnlyList<PolicyPermission>> GetPolicyPermissionsAsync(PolicyContext context, CancellationToken ct = default) => GetPolicyPermissionsAsync(ct);
        public Task<IReadOnlyList<PolicyRole>> GetPolicyRolesAsync(CancellationToken ct = default) => Task.FromResult<IReadOnlyList<PolicyRole>>([new("custom_role", "CUSTOM", false, "", default, "")]);
        public Task<IReadOnlyList<PolicyRole>> GetPolicyRolesAsync(PolicyContext context, CancellationToken ct = default) => GetPolicyRolesAsync(ct);
        public Task<IReadOnlyList<DenyRule>> GetDenyRulesAsync(CancellationToken ct = default) => Task.FromResult<IReadOnlyList<DenyRule>>([]);
        public Task RegisterPolicyDiscoveryAsync(PolicyContext context, PolicyDiscoveryResult result, CancellationToken ct = default) { Registered = result; return Task.CompletedTask; }
        public Task UpsertPermissionAsync(PolicyPermission permission, CancellationToken ct = default) => throw new NotSupportedException();
        public Task UpsertRoleAsync(PolicyRole role, CancellationToken ct = default) => throw new NotSupportedException();
        public Task UpsertDenyRuleAsync(string category, string value, string reason, CancellationToken ct = default) => throw new NotSupportedException();
        public Task ActivateSpecialPolicyAsync(PolicySpecialActivation activation, CancellationToken ct = default) => throw new NotSupportedException();
    }
}
