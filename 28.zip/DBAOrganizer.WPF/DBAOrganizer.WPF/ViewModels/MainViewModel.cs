using System.Collections.ObjectModel;
using System.Windows.Input;
using DBAOrganizer.WPF.Models;
using DBAOrganizer.WPF.Services;

namespace DBAOrganizer.WPF.ViewModels
{
    public class RelayCommand : ICommand
    {
        private readonly Action<object?> _execute;
        private readonly Func<object?, bool>? _canExecute;

        public RelayCommand(Action<object?> execute, Func<object?, bool>? canExecute = null)
        {
            _execute = execute;
            _canExecute = canExecute;
        }

        public event EventHandler? CanExecuteChanged
        {
            add => CommandManager.RequerySuggested += value;
            remove => CommandManager.RequerySuggested -= value;
        }

        public bool CanExecute(object? parameter) => _canExecute == null || _canExecute(parameter);
        public void Execute(object? parameter) => _execute(parameter);
    }

    public class MainViewModel : TaskItem
    {
        private readonly JsonDataService _dataService;
        public ObservableCollection<TaskItem> Tasks { get; set; }

        public ObservableCollection<TaskItem> PorHacerTasks { get; } = new();
        public ObservableCollection<TaskItem> EnProcesoTasks { get; } = new();
        public ObservableCollection<TaskItem> ValidacionTasks { get; } = new();
        public ObservableCollection<TaskItem> BloqueadoTasks { get; } = new();
        public ObservableCollection<TaskItem> EnRevisionTasks { get; } = new();
        public ObservableCollection<TaskItem> FinalizadoTasks { get; } = new();

        private TaskItem? _selectedTask;
        public TaskItem? SelectedTask
        {
            get => _selectedTask;
            set 
            { 
                _selectedTask = value; 
                OnPropertyChanged(); 
            }
        }

        public ICommand AddCommand { get; }
        public ICommand DeleteCommand { get; }
        public ICommand SaveCommand { get; }
        public ICommand AdvanceCommand { get; }
        public ICommand RegressCommand { get; }

        public MainViewModel()
        {
            _dataService = new JsonDataService();
            Tasks = _dataService.LoadTasks();

            if (Tasks.Count == 0)
            {
                Tasks.Add(new TaskItem
                {
                    Ticket = "INC-725037",
                    Title = "Error Replica SQL01",
                    Description = "Falla de sincronización en nodo secundario",
                    Priority = "High",
                    Status = "Por Hacer"
                });
            }

            UpdateColumnCollections();
            Tasks.CollectionChanged += (s, e) => UpdateColumnCollections();

            AddCommand = new RelayCommand(_ => AddTask());
            DeleteCommand = new RelayCommand(_ => DeleteTask(), _ => SelectedTask != null);
            SaveCommand = new RelayCommand(_ => SaveData());
            AdvanceCommand = new RelayCommand(_ => MoveStatus(1), _ => SelectedTask != null);
            RegressCommand = new RelayCommand(_ => MoveStatus(-1), _ => SelectedTask != null);
        }

        private void UpdateColumnCollections()
        {
            PorHacerTasks.Clear();
            EnProcesoTasks.Clear();
            ValidacionTasks.Clear();
            BloqueadoTasks.Clear();
            EnRevisionTasks.Clear();
            FinalizadoTasks.Clear();

            foreach (var task in Tasks)
            {
                switch (task.Status)
                {
                    case "Por Hacer": PorHacerTasks.Add(task); break;
                    case "En Proceso": EnProcesoTasks.Add(task); break;
                    case "Validación": ValidacionTasks.Add(task); break;
                    case "Bloqueado": BloqueadoTasks.Add(task); break;
                    case "En Revisión": EnRevisionTasks.Add(task); break;
                    case "Finalizado": FinalizadoTasks.Add(task); break;
                    default: PorHacerTasks.Add(task); break;
                }
            }
        }

        private void AddTask()
        {
            var newTask = new TaskItem
            {
                Ticket = $"INC-{new Random().Next(100000, 999999)}",
                Title = "Nueva Actividad",
                Description = "Descripción del requerimiento",
                Priority = "Normal",
                Status = "Por Hacer"
            };
            Tasks.Add(newTask);
            UpdateColumnCollections();
            SelectedTask = newTask;
            SaveData();
        }

        private void DeleteTask()
        {
            if (SelectedTask != null)
            {
                Tasks.Remove(SelectedTask);
                UpdateColumnCollections();
                SelectedTask = null;
                SaveData();
            }
        }

        private void SaveData()
        {
            UpdateColumnCollections();
            _dataService.SaveTasks(Tasks);
        }

        private void MoveStatus(int direction)
        {
            if (SelectedTask == null) return;

            string[] states = { "Por Hacer", "En Proceso", "Validación", "Bloqueado", "En Revisión", "Finalizado" };
            int currentIndex = Array.IndexOf(states, SelectedTask.Status);

            if (currentIndex == -1) currentIndex = 0;

            int newIndex = currentIndex + direction;
            if (newIndex >= 0 && newIndex < states.Length)
            {
                SelectedTask.Status = states[newIndex];
                SaveData();
                
                // Forzar refresco de selección
                var current = SelectedTask;
                SelectedTask = null;
                SelectedTask = current;
            }
        }
    }
}