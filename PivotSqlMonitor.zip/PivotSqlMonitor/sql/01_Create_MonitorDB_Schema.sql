-- Ejecuta en tu SQL central (MonitorDB)
-- Crea tablas + SPs para el framework PivotSqlMonitor

IF OBJECT_ID('dbo.MonitoredServer','U') IS NULL
BEGIN
    CREATE TABLE dbo.MonitoredServer
    (
        ServerId        INT IDENTITY(1,1) PRIMARY KEY,
        ServerName      NVARCHAR(255) NOT NULL,
        InstanceName    NVARCHAR(128) NULL,
        SqlPort         INT NOT NULL CONSTRAINT DF_MonitoredServer_SqlPort DEFAULT (1433),
        IsEnabled       BIT NOT NULL CONSTRAINT DF_MonitoredServer_IsEnabled DEFAULT (1),
        Environment     NVARCHAR(50) NULL,
        Notes           NVARCHAR(4000) NULL,
        CreatedAtUtc    DATETIME2 NOT NULL CONSTRAINT DF_MonitoredServer_CreatedAtUtc DEFAULT (SYSUTCDATETIME())
    );
    CREATE UNIQUE INDEX IX_MonitoredServer_UQ ON dbo.MonitoredServer(ServerName, ISNULL(InstanceName,''));
END
GO

IF OBJECT_ID('dbo.MonitorCheckType','U') IS NULL
BEGIN
    CREATE TABLE dbo.MonitorCheckType
    (
        CheckTypeId  INT IDENTITY(1,1) PRIMARY KEY,
        CheckCode    NVARCHAR(50) NOT NULL UNIQUE,
        DisplayName  NVARCHAR(200) NOT NULL,
        IsEnabled    BIT NOT NULL CONSTRAINT DF_MonitorCheckType_IsEnabled DEFAULT (1)
    );

    INSERT INTO dbo.MonitorCheckType(CheckCode, DisplayName, IsEnabled) VALUES
    ('PING','Ping ICMP',1),
    ('TCP_PORT','TCP Port Open',1),
    ('SQL_LOGIN','SQL Login Handshake',1),
    ('DATABASE_ONLINE','Database Online Status',1),
    ('SQL_AGENT_RUNNING','SQL Agent Running',1),
    ('DISK_FREE','Disk Free Space (per volume)',1),
    ('CONNECTION_COUNT','Connection Count',1),
    ('BLOCKING_COUNT','Blocking Count',1),
    ('FAILED_JOBS','Failed Jobs (last 24h)',1),
    ('SQL_UPTIME','SQL Uptime',1);
END
GO

IF OBJECT_ID('dbo.MonitorRun','U') IS NULL
BEGIN
    CREATE TABLE dbo.MonitorRun
    (
        RunId          BIGINT IDENTITY(1,1) PRIMARY KEY,
        StartedAtUtc   DATETIME2 NOT NULL CONSTRAINT DF_MonitorRun_StartedAtUtc DEFAULT (SYSUTCDATETIME()),
        FinishedAtUtc  DATETIME2 NULL,
        RunnerHost     NVARCHAR(255) NULL,
        RunnerVersion  NVARCHAR(50) NULL
    );
END
GO

IF OBJECT_ID('dbo.MonitorResult','U') IS NULL
BEGIN
    CREATE TABLE dbo.MonitorResult
    (
        ResultId        BIGINT IDENTITY(1,1) PRIMARY KEY,
        RunId           BIGINT NOT NULL FOREIGN KEY REFERENCES dbo.MonitorRun(RunId),
        ServerId        INT NOT NULL FOREIGN KEY REFERENCES dbo.MonitoredServer(ServerId),
        CheckTypeId     INT NOT NULL FOREIGN KEY REFERENCES dbo.MonitorCheckType(CheckTypeId),

        CheckedAtUtc    DATETIME2 NOT NULL CONSTRAINT DF_MonitorResult_CheckedAtUtc DEFAULT (SYSUTCDATETIME()),
        IsSuccess       BIT NOT NULL,
        ResponseMs      INT NULL,

        ItemName        NVARCHAR(64) NULL,   -- multi-disco, etc.
        MetricInt       BIGINT NULL,         -- counts
        MetricDecimal   DECIMAL(18,2) NULL,  -- % libre u otras métricas

        ErrorCategory   NVARCHAR(100) NULL,
        Message         NVARCHAR(4000) NULL
    );

    CREATE INDEX IX_MonitorResult_Run_Server ON dbo.MonitorResult(RunId, ServerId);
    CREATE INDEX IX_MonitorResult_Server_Time ON dbo.MonitorResult(ServerId, CheckedAtUtc DESC);
END
GO

CREATE OR ALTER PROC dbo.usp_MonitorRun_Start
    @RunnerHost NVARCHAR(255),
    @RunnerVersion NVARCHAR(50),
    @RunId BIGINT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    INSERT dbo.MonitorRun(RunnerHost, RunnerVersion) VALUES (@RunnerHost, @RunnerVersion);
    SET @RunId = SCOPE_IDENTITY();
END
GO

CREATE OR ALTER PROC dbo.usp_MonitorRun_Finish
    @RunId BIGINT
AS
BEGIN
    SET NOCOUNT ON;
    UPDATE dbo.MonitorRun SET FinishedAtUtc = SYSUTCDATETIME() WHERE RunId = @RunId;
END
GO

CREATE OR ALTER PROC dbo.usp_MonitorResult_Insert
    @RunId BIGINT,
    @ServerId INT,
    @CheckCode NVARCHAR(50),
    @IsSuccess BIT,
    @ResponseMs INT = NULL,
    @ItemName NVARCHAR(64) = NULL,
    @MetricInt BIGINT = NULL,
    @MetricDecimal DECIMAL(18,2) = NULL,
    @ErrorCategory NVARCHAR(100) = NULL,
    @Message NVARCHAR(4000) = NULL
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @CheckTypeId INT = (SELECT CheckTypeId FROM dbo.MonitorCheckType WHERE CheckCode = @CheckCode);

    INSERT dbo.MonitorResult
    (RunId, ServerId, CheckTypeId, IsSuccess, ResponseMs, ItemName, MetricInt, MetricDecimal, ErrorCategory, Message)
    VALUES
    (@RunId, @ServerId, @CheckTypeId, @IsSuccess, @ResponseMs, @ItemName, @MetricInt, @MetricDecimal, @ErrorCategory, @Message);
END
GO
