# PivotSqlMonitor (Console App)

## 1) Crear esquema en SQL Central
Ejecuta: `sql/01_Create_MonitorDB_Schema.sql` en tu base `MonitorDB`.

## 2) Agregar servidores a monitorear
Inserta en dbo.MonitoredServer:
- ServerName (hostname o IP)
- InstanceName (NULL default)
- SqlPort (1433 por defecto)
- IsEnabled = 1

## 3) Configurar conexión central
Opción A: Editar `appsettings.json` (se copia junto al exe).
Opción B: Pasar por args:
  PivotSqlMonitor.exe --central "Server=...;Database=MonitorDB;..."

Opción C: Variable de entorno:
  MONITOR_CENTRAL_CS

## 4) Ejecutar
Ejemplo:
  PivotSqlMonitor.exe --central "Server=SQLCENTRAL;Database=MonitorDB;Trusted_Connection=True;Encrypt=True;TrustServerCertificate=True;" --parallel 25 --timeoutMinutes 10

## 5) Permisos necesarios en SQL monitoreados
- Para DISK_FREE: GRANT VIEW SERVER STATE TO [TuLogin];
- Para FAILED_JOBS: al menos lectura en msdb (SQLAgentReaderRole recomendado).

## 6) Job (SQL Agent)
Crea un Job con Step tipo CmdExec:
  "C:\SqlMonitor\PivotSqlMonitor.exe" --central "..." --parallel 25 --timeoutMinutes 10
