using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace PivotSqlMonitor;

public sealed class MonitorOrchestrator
{
    private readonly MonitorRepository _repo;
    private readonly int _maxParallelism;

    public MonitorOrchestrator(MonitorRepository repo, int maxParallelism = 20)
    {
        _repo = repo;
        _maxParallelism = Math.Max(1, maxParallelism);
    }

    public async Task RunOnceAsync(
        IReadOnlyList<IMonitorCheck> allChecks,
        string runnerHost,
        string runnerVersion,
        CancellationToken ct)
    {
        var runId = await _repo.StartRunAsync(runnerHost, runnerVersion, ct);
        try
        {
            var enabledCheckCodes = await _repo.GetEnabledCheckCodesAsync(ct);
            var checksToRun = allChecks.Where(c => enabledCheckCodes.Contains(c.CheckCode)).ToList();

            var servers = await _repo.GetEnabledServersAsync(ct);

            using var sem = new SemaphoreSlim(_maxParallelism);
            var tasks = new List<Task>(servers.Count);

            foreach (var server in servers)
            {
                await sem.WaitAsync(ct);

                tasks.Add(Task.Run(async () =>
                {
                    try
                    {
                        foreach (var check in checksToRun)
                        {
                            var results = await check.ExecuteAsync(server, ct);

                            foreach (var r in results)
                                await _repo.InsertResultAsync(runId, server, r, ct);
                        }
                    }
                    finally
                    {
                        sem.Release();
                    }
                }, ct));
            }

            await Task.WhenAll(tasks);
        }
        finally
        {
            await _repo.FinishRunAsync(runId, ct);
        }
    }
}
