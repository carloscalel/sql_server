using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;

namespace PivotSqlMonitor;

internal static class Program
{
    static async Task<int> Main(string[] args)
    {
        try
        {
            var options = AppOptions.Load(args);

            var repo = new MonitorRepository(options.CentralConnectionString);

            // Factory de conexiones hacia cada SQL monitoreado (Windows Auth por defecto)
            ISqlConnectionFactory sqlFactory = options.SqlAuth is null
                ? new DefaultSqlConnectionFactory(trustedConnection: true)
                : new DefaultSqlConnectionFactory(trustedConnection: false, user: options.SqlAuth.User, pass: options.SqlAuth.Password);

            // Registra todos los checks implementados (la DB decide cuáles corren via IsEnabled)
            var checks = new List<IMonitorCheck>
            {
                new PingCheck(options.PingTimeoutMs),
                new TcpPortCheck(options.TcpTimeoutMs),

                new SqlLoginCheck(sqlFactory),
                new DatabaseOnlineCheck(sqlFactory),
                new SqlAgentRunningCheck(sqlFactory),
                new DiskFreeCheck(sqlFactory, criticalPercentFree: options.DiskCriticalPercentFree),

                new ConnectionCountCheck(sqlFactory),
                new BlockingCountCheck(sqlFactory),
                new FailedJobsCheck(sqlFactory),
                new SqlUptimeCheck(sqlFactory)
            };

            var orchestrator = new MonitorOrchestrator(repo, maxParallelism: options.MaxParallelism);

            using var cts = new CancellationTokenSource(TimeSpan.FromMinutes(options.TimeoutMinutes));

            await orchestrator.RunOnceAsync(
                allChecks: checks,
                runnerHost: Environment.MachineName,
                runnerVersion: options.RunnerVersion,
                ct: cts.Token
            );

            return 0;
        }
        catch (Exception ex)
        {
            Console.Error.WriteLine(ex.ToString());
            return 1;
        }
    }
}

internal sealed record AppOptions(
    string CentralConnectionString,
    int MaxParallelism,
    int TimeoutMinutes,
    int PingTimeoutMs,
    int TcpTimeoutMs,
    decimal DiskCriticalPercentFree,
    string RunnerVersion,
    SqlAuthOptions? SqlAuth
)
{
    public static AppOptions Load(string[] args)
    {
        // Permite configurar por:
        // 1) Args: --central "..." --parallel 25 --timeoutMinutes 10
        // 2) appsettings.json (si existe) con clave CentralConnectionString
        // 3) Variable de entorno: MONITOR_CENTRAL_CS

        string? GetArg(string name)
        {
            var i = Array.FindIndex(args, a => a.Equals(name, StringComparison.OrdinalIgnoreCase));
            return i >= 0 && i + 1 < args.Length ? args[i + 1] : null;
        }

        var fromArgsCentral = GetArg("--central");
        var fromEnvCentral = Environment.GetEnvironmentVariable("MONITOR_CENTRAL_CS");
        var fromJsonCentral = TryLoadFromAppSettings()?.CentralConnectionString;

        var central = fromArgsCentral ?? fromEnvCentral ?? fromJsonCentral
            ?? throw new ArgumentException("Falta cadena central. Usa --central "..." o MONITOR_CENTRAL_CS o appsettings.json.");

        var parallel = int.TryParse(GetArg("--parallel"), out var p) ? p : (TryLoadFromAppSettings()?.MaxParallelism ?? 25);
        var timeoutMinutes = int.TryParse(GetArg("--timeoutMinutes"), out var t) ? t : (TryLoadFromAppSettings()?.TimeoutMinutes ?? 10);

        var pingTimeoutMs = int.TryParse(GetArg("--pingTimeoutMs"), out var pt) ? pt : (TryLoadFromAppSettings()?.PingTimeoutMs ?? 3000);
        var tcpTimeoutMs = int.TryParse(GetArg("--tcpTimeoutMs"), out var tt) ? tt : (TryLoadFromAppSettings()?.TcpTimeoutMs ?? 3000);

        var diskCriticalPct = decimal.TryParse(GetArg("--diskCriticalPercentFree"), out var dcp)
            ? dcp
            : (TryLoadFromAppSettings()?.DiskCriticalPercentFree ?? 5m);

        var runnerVersion = GetArg("--runnerVersion") ?? (TryLoadFromAppSettings()?.RunnerVersion ?? "1.0.0");

        SqlAuthOptions? sqlAuth = TryLoadFromAppSettings()?.SqlAuth;
        // Permite sobreescribir por args si se desea:
        var user = GetArg("--sqlUser");
        var pass = GetArg("--sqlPass");
        if (!string.IsNullOrWhiteSpace(user) && !string.IsNullOrWhiteSpace(pass))
            sqlAuth = new SqlAuthOptions(user!, pass!);

        return new AppOptions(
            CentralConnectionString: central,
            MaxParallelism: Math.Max(1, parallel),
            TimeoutMinutes: Math.Max(1, timeoutMinutes),
            PingTimeoutMs: Math.Max(500, pingTimeoutMs),
            TcpTimeoutMs: Math.Max(500, tcpTimeoutMs),
            DiskCriticalPercentFree: diskCriticalPct,
            RunnerVersion: runnerVersion,
            SqlAuth: sqlAuth
        );
    }

    private static AppSettingsFile? _cached;
    private static AppSettingsFile? TryLoadFromAppSettings()
    {
        if (_cached is not null) return _cached;
        try
        {
            var path = Path.Combine(AppContext.BaseDirectory, "appsettings.json");
            if (!File.Exists(path)) return null;

            var json = File.ReadAllText(path);
            _cached = JsonSerializer.Deserialize<AppSettingsFile>(json, new JsonSerializerOptions { PropertyNameCaseInsensitive = true });
            return _cached;
        }
        catch
        {
            return null;
        }
    }
}

internal sealed record SqlAuthOptions(string User, string Password);

internal sealed record AppSettingsFile
{
    public string? CentralConnectionString { get; init; }
    public int? MaxParallelism { get; init; }
    public int? TimeoutMinutes { get; init; }
    public int? PingTimeoutMs { get; init; }
    public int? TcpTimeoutMs { get; init; }
    public decimal? DiskCriticalPercentFree { get; init; }
    public string? RunnerVersion { get; init; }
    public SqlAuthOptions? SqlAuth { get; init; }
}
