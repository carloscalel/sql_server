using System;
using System.Diagnostics;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Data.SqlClient;

namespace PivotSqlMonitor;

public sealed class FailedJobsCheck : SqlCheckBase, IMonitorCheck
{
    public string CheckCode => "FAILED_JOBS";
    public FailedJobsCheck(ISqlConnectionFactory factory) : base(factory) { }

    public async Task<IReadOnlyList<CheckResult>> ExecuteAsync(MonitoredServer server, CancellationToken ct)
    {
        var sw = Stopwatch.StartNew();
        try
        {
            await using var conn = await OpenMasterAsync(server, ct);

            const string sql = @"
SELECT COUNT(*) 
FROM msdb.dbo.sysjobhistory h
WHERE h.step_id = 0
  AND h.run_status = 0
  AND msdb.dbo.agent_datetime(h.run_date, h.run_time) >= DATEADD(HOUR,-24,GETDATE());";

            await using var cmd = new SqlCommand(sql, conn);
            var failed = Convert.ToInt64(await cmd.ExecuteScalarAsync(ct));

            sw.Stop();

            var ok = failed == 0;
            return new[]
            {
                new CheckResult(CheckCode, ok, (int)sw.ElapsedMilliseconds, MetricInt: failed,
                    Message: ok ? "No failed jobs in last 24h" : $"{failed} failed jobs in last 24h")
            };
        }
        catch (Exception ex)
        {
            sw.Stop();
            var (cat, msg) = ErrorClassifier.Classify(ex);
            return new[] { new CheckResult(CheckCode, false, (int)sw.ElapsedMilliseconds, ErrorCategory: cat, Message: msg) };
        }
    }
}
