using System;
using System.Diagnostics;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Data.SqlClient;

namespace PivotSqlMonitor;

public sealed class SqlAgentRunningCheck : SqlCheckBase, IMonitorCheck
{
    public string CheckCode => "SQL_AGENT_RUNNING";
    public SqlAgentRunningCheck(ISqlConnectionFactory factory) : base(factory) { }

    public async Task<IReadOnlyList<CheckResult>> ExecuteAsync(MonitoredServer server, CancellationToken ct)
    {
        var sw = Stopwatch.StartNew();
        try
        {
            await using var conn = await OpenMasterAsync(server, ct);

            const string sql = @"
SELECT TOP (1) status_desc
FROM sys.dm_server_services
WHERE servicename LIKE 'SQL Server Agent%';";

            await using var cmd = new SqlCommand(sql, conn);
            var status = (string?)await cmd.ExecuteScalarAsync(ct);

            sw.Stop();

            if (status is null)
                return new[] { new CheckResult(CheckCode, false, (int)sw.ElapsedMilliseconds, ErrorCategory: "NOT_FOUND", Message: "SQL Agent service not found") };

            var ok = status.Equals("Running", StringComparison.OrdinalIgnoreCase);
            return new[] { new CheckResult(CheckCode, ok, (int)sw.ElapsedMilliseconds, Message: $"Agent {status}") };
        }
        catch (Exception ex)
        {
            sw.Stop();
            var (cat, msg) = ErrorClassifier.Classify(ex);
            return new[] { new CheckResult(CheckCode, false, (int)sw.ElapsedMilliseconds, ErrorCategory: cat, Message: msg) };
        }
    }
}
