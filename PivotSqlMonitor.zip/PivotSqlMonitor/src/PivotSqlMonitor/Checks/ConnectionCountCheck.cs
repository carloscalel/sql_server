using System;
using System.Diagnostics;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Data.SqlClient;

namespace PivotSqlMonitor;

public sealed class ConnectionCountCheck : SqlCheckBase, IMonitorCheck
{
    public string CheckCode => "CONNECTION_COUNT";
    public ConnectionCountCheck(ISqlConnectionFactory factory) : base(factory) { }

    public async Task<IReadOnlyList<CheckResult>> ExecuteAsync(MonitoredServer server, CancellationToken ct)
    {
        var sw = Stopwatch.StartNew();
        try
        {
            await using var conn = await OpenMasterAsync(server, ct);
            const string sql = "SELECT COUNT(*) FROM sys.dm_exec_sessions WHERE is_user_process = 1;";
            await using var cmd = new SqlCommand(sql, conn);
            var count = Convert.ToInt64(await cmd.ExecuteScalarAsync(ct));

            sw.Stop();
            return new[] { new CheckResult(CheckCode, true, (int)sw.ElapsedMilliseconds, MetricInt: count, Message: $"{count} user sessions") };
        }
        catch (Exception ex)
        {
            sw.Stop();
            var (cat, msg) = ErrorClassifier.Classify(ex);
            return new[] { new CheckResult(CheckCode, false, (int)sw.ElapsedMilliseconds, ErrorCategory: cat, Message: msg) };
        }
    }
}
