using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Data.SqlClient;

namespace PivotSqlMonitor;

/// <summary>
/// Multi-disco: devuelve un resultado por volumen donde SQL tiene archivos (data/log),
/// usando sys.dm_os_volume_stats.
/// Requiere: VIEW SERVER STATE.
/// </summary>
public sealed class DiskFreeCheck : SqlCheckBase, IMonitorCheck
{
    public string CheckCode => "DISK_FREE";
    private readonly decimal _criticalPercentFree;

    public DiskFreeCheck(ISqlConnectionFactory factory, decimal criticalPercentFree = 5m) : base(factory)
        => _criticalPercentFree = criticalPercentFree;

    public async Task<IReadOnlyList<CheckResult>> ExecuteAsync(MonitoredServer server, CancellationToken ct)
    {
        var sw = Stopwatch.StartNew();
        try
        {
            await using var conn = await OpenMasterAsync(server, ct);

            const string sql = @"
;WITH V AS
(
    SELECT DISTINCT
        vs.volume_mount_point AS Volume,
        CAST(vs.total_bytes / 1073741824.0 AS DECIMAL(18,2)) AS TotalGB,
        CAST(vs.available_bytes / 1073741824.0 AS DECIMAL(18,2)) AS FreeGB,
        CAST((vs.available_bytes * 100.0) / NULLIF(vs.total_bytes,0) AS DECIMAL(18,2)) AS PercentFree
    FROM sys.master_files mf
    CROSS APPLY sys.dm_os_volume_stats(mf.database_id, mf.file_id) vs
)
SELECT Volume, TotalGB, FreeGB, PercentFree
FROM V
ORDER BY Volume;";

            await using var cmd = new SqlCommand(sql, conn);
            await using var rdr = await cmd.ExecuteReaderAsync(ct);

            sw.Stop();

            var results = new List<CheckResult>();
            while (await rdr.ReadAsync(ct))
            {
                var volume = rdr.GetString(0);
                var totalGb = rdr.GetDecimal(1);
                var freeGb = rdr.GetDecimal(2);
                var pctFree = rdr.GetDecimal(3);

                var ok = pctFree >= _criticalPercentFree;

                results.Add(new CheckResult(
                    CheckCode: CheckCode,
                    IsSuccess: ok,
                    ResponseMs: (int)sw.ElapsedMilliseconds,
                    ItemName: volume,
                    MetricDecimal: pctFree, // % libre
                    Message: $"{volume} Free {freeGb} GB of {totalGb} GB ({pctFree}%)"
                ));
            }

            if (results.Count == 0)
            {
                results.Add(new CheckResult(CheckCode, false, (int)sw.ElapsedMilliseconds, ErrorCategory: "NO_DATA", Message: "No volumes found via dm_os_volume_stats"));
            }

            return results;
        }
        catch (Exception ex)
        {
            sw.Stop();
            var (cat, msg) = ErrorClassifier.Classify(ex);
            return new[] { new CheckResult(CheckCode, false, (int)sw.ElapsedMilliseconds, ErrorCategory: cat, Message: msg) };
        }
    }
}
