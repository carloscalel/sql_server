using System;
using System.Diagnostics;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Data.SqlClient;

namespace PivotSqlMonitor;

public sealed class BlockingCountCheck : SqlCheckBase, IMonitorCheck
{
    public string CheckCode => "BLOCKING_COUNT";
    public BlockingCountCheck(ISqlConnectionFactory factory) : base(factory) { }

    public async Task<IReadOnlyList<CheckResult>> ExecuteAsync(MonitoredServer server, CancellationToken ct)
    {
        var sw = Stopwatch.StartNew();
        try
        {
            await using var conn = await OpenMasterAsync(server, ct);
            const string sql = "SELECT COUNT(*) FROM sys.dm_exec_requests WHERE blocking_session_id <> 0;";
            await using var cmd = new SqlCommand(sql, conn);
            var count = Convert.ToInt64(await cmd.ExecuteScalarAsync(ct));

            sw.Stop();
            return new[] { new CheckResult(CheckCode, true, (int)sw.ElapsedMilliseconds, MetricInt: count, Message: $"{count} blocking requests") };
        }
        catch (Exception ex)
        {
            sw.Stop();
            var (cat, msg) = ErrorClassifier.Classify(ex);
            return new[] { new CheckResult(CheckCode, false, (int)sw.ElapsedMilliseconds, ErrorCategory: cat, Message: msg) };
        }
    }
}
