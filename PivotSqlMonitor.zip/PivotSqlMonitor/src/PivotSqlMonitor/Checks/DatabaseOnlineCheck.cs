using System;
using System.Diagnostics;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Data.SqlClient;

namespace PivotSqlMonitor;

public sealed class DatabaseOnlineCheck : SqlCheckBase, IMonitorCheck
{
    public string CheckCode => "DATABASE_ONLINE";
    public DatabaseOnlineCheck(ISqlConnectionFactory factory) : base(factory) { }

    public async Task<IReadOnlyList<CheckResult>> ExecuteAsync(MonitoredServer server, CancellationToken ct)
    {
        var sw = Stopwatch.StartNew();
        try
        {
            await using var conn = await OpenMasterAsync(server, ct);
            const string sql = "SELECT COUNT(*) FROM sys.databases WHERE state_desc <> 'ONLINE';";
            await using var cmd = new SqlCommand(sql, conn);
            var notOnline = Convert.ToInt64(await cmd.ExecuteScalarAsync(ct));

            sw.Stop();

            var ok = notOnline == 0;
            return new[]
            {
                new CheckResult(CheckCode, ok, (int)sw.ElapsedMilliseconds,
                    MetricInt: notOnline,
                    Message: ok ? "All databases ONLINE" : $"{notOnline} databases NOT ONLINE")
            };
        }
        catch (Exception ex)
        {
            sw.Stop();
            var (cat, msg) = ErrorClassifier.Classify(ex);
            return new[] { new CheckResult(CheckCode, false, (int)sw.ElapsedMilliseconds, ErrorCategory: cat, Message: msg) };
        }
    }
}
