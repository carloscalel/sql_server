using System;
using System.Diagnostics;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Data.SqlClient;

namespace PivotSqlMonitor;

public sealed class SqlUptimeCheck : SqlCheckBase, IMonitorCheck
{
    public string CheckCode => "SQL_UPTIME";
    public SqlUptimeCheck(ISqlConnectionFactory factory) : base(factory) { }

    public async Task<IReadOnlyList<CheckResult>> ExecuteAsync(MonitoredServer server, CancellationToken ct)
    {
        var sw = Stopwatch.StartNew();
        try
        {
            await using var conn = await OpenMasterAsync(server, ct);
            const string sql = "SELECT sqlserver_start_time FROM sys.dm_os_sys_info;";
            await using var cmd = new SqlCommand(sql, conn);
            var start = (DateTime)await cmd.ExecuteScalarAsync(ct);

            sw.Stop();

            var uptime = DateTime.UtcNow - start.ToUniversalTime();
            return new[]
            {
                new CheckResult(CheckCode, true, (int)sw.ElapsedMilliseconds,
                    MetricInt: (long)uptime.TotalMinutes,
                    Message: $"Running since {start:yyyy-MM-dd HH:mm:ss} (UTC), uptime {uptime.TotalHours:F1}h")
            };
        }
        catch (Exception ex)
        {
            sw.Stop();
            var (cat, msg) = ErrorClassifier.Classify(ex);
            return new[] { new CheckResult(CheckCode, false, (int)sw.ElapsedMilliseconds, ErrorCategory: cat, Message: msg) };
        }
    }
}
