using System.Diagnostics;
using System.Net.Sockets;
using System.Threading;
using System.Threading.Tasks;

namespace PivotSqlMonitor;

public sealed class TcpPortCheck : IMonitorCheck
{
    public string CheckCode => "TCP_PORT";
    private readonly int _timeoutMs;

    public TcpPortCheck(int timeoutMs = 3000) => _timeoutMs = timeoutMs;

    public async Task<IReadOnlyList<CheckResult>> ExecuteAsync(MonitoredServer server, CancellationToken ct)
    {
        var sw = Stopwatch.StartNew();
        try
        {
            using var client = new TcpClient();
            var connectTask = client.ConnectAsync(server.ServerName, server.SqlPort);
            var done = await Task.WhenAny(connectTask, Task.Delay(_timeoutMs, ct));

            sw.Stop();

            if (done != connectTask || !client.Connected)
                return new[] { new CheckResult(CheckCode, false, (int)sw.ElapsedMilliseconds, ErrorCategory: "TIMEOUT", Message: $"No conectó a {server.SqlPort}") };

            return new[] { new CheckResult(CheckCode, true, (int)sw.ElapsedMilliseconds) };
        }
        catch (Exception ex)
        {
            sw.Stop();
            var (cat, msg) = ErrorClassifier.Classify(ex);
            return new[] { new CheckResult(CheckCode, false, (int)sw.ElapsedMilliseconds, ErrorCategory: cat, Message: msg) };
        }
    }
}
