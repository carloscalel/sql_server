using System.Diagnostics;
using System.Threading;
using System.Threading.Tasks;

namespace PivotSqlMonitor;

public sealed class SqlLoginCheck : SqlCheckBase, IMonitorCheck
{
    public string CheckCode => "SQL_LOGIN";
    public SqlLoginCheck(ISqlConnectionFactory factory) : base(factory) { }

    public async Task<IReadOnlyList<CheckResult>> ExecuteAsync(MonitoredServer server, CancellationToken ct)
    {
        var sw = Stopwatch.StartNew();
        try
        {
            await using var conn = await OpenMasterAsync(server, ct);
            sw.Stop();
            return new[] { new CheckResult(CheckCode, true, (int)sw.ElapsedMilliseconds) };
        }
        catch (Exception ex)
        {
            sw.Stop();
            var (cat, msg) = ErrorClassifier.Classify(ex);
            return new[] { new CheckResult(CheckCode, false, (int)sw.ElapsedMilliseconds, ErrorCategory: cat, Message: msg) };
        }
    }
}
