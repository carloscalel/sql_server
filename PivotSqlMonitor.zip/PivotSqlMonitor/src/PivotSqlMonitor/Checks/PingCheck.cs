using System.Diagnostics;
using System.Net.NetworkInformation;
using System.Threading;
using System.Threading.Tasks;

namespace PivotSqlMonitor;

public sealed class PingCheck : IMonitorCheck
{
    public string CheckCode => "PING";
    private readonly int _timeoutMs;

    public PingCheck(int timeoutMs = 3000) => _timeoutMs = timeoutMs;

    public async Task<IReadOnlyList<CheckResult>> ExecuteAsync(MonitoredServer server, CancellationToken ct)
    {
        var sw = Stopwatch.StartNew();
        try
        {
            using var ping = new Ping();
            var reply = await ping.SendPingAsync(server.ServerName, _timeoutMs);
            sw.Stop();

            if (reply.Status == IPStatus.Success)
                return new[] { new CheckResult(CheckCode, true, (int)sw.ElapsedMilliseconds) };

            return new[]
            {
                new CheckResult(CheckCode, false, (int)sw.ElapsedMilliseconds, ErrorCategory: "ICMP", Message: reply.Status.ToString())
            };
        }
        catch (Exception ex)
        {
            sw.Stop();
            var (cat, msg) = ErrorClassifier.Classify(ex);
            return new[] { new CheckResult(CheckCode, false, (int)sw.ElapsedMilliseconds, ErrorCategory: cat, Message: msg) };
        }
    }
}
