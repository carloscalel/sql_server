using System;
using System.Collections.Generic;
using System.Data;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Data.SqlClient;

namespace PivotSqlMonitor;

public sealed class MonitorRepository
{
    private readonly string _centralConnectionString;

    public MonitorRepository(string centralConnectionString)
        => _centralConnectionString = centralConnectionString;

    public async Task<long> StartRunAsync(string runnerHost, string runnerVersion, CancellationToken ct)
    {
        using var conn = new SqlConnection(_centralConnectionString);
        await conn.OpenAsync(ct);

        using var cmd = new SqlCommand("dbo.usp_MonitorRun_Start", conn)
        {
            CommandType = CommandType.StoredProcedure
        };

        cmd.Parameters.AddWithValue("@RunnerHost", runnerHost);
        cmd.Parameters.AddWithValue("@RunnerVersion", runnerVersion);

        var outParam = new SqlParameter("@RunId", SqlDbType.BigInt)
        {
            Direction = ParameterDirection.Output
        };
        cmd.Parameters.Add(outParam);

        await cmd.ExecuteNonQueryAsync(ct);
        return (long)outParam.Value;
    }

    public async Task FinishRunAsync(long runId, CancellationToken ct)
    {
        using var conn = new SqlConnection(_centralConnectionString);
        await conn.OpenAsync(ct);

        using var cmd = new SqlCommand("dbo.usp_MonitorRun_Finish", conn)
        {
            CommandType = CommandType.StoredProcedure
        };
        cmd.Parameters.AddWithValue("@RunId", runId);

        await cmd.ExecuteNonQueryAsync(ct);
    }

    public async Task<IReadOnlyList<MonitoredServer>> GetEnabledServersAsync(CancellationToken ct)
    {
        const string sql = @"
SELECT ServerId, ServerName, InstanceName, SqlPort, IsEnabled
FROM dbo.MonitoredServer
WHERE IsEnabled = 1;";

        var list = new List<MonitoredServer>();

        using var conn = new SqlConnection(_centralConnectionString);
        await conn.OpenAsync(ct);

        using var cmd = new SqlCommand(sql, conn);
        using var rdr = await cmd.ExecuteReaderAsync(ct);

        while (await rdr.ReadAsync(ct))
        {
            list.Add(new MonitoredServer(
                rdr.GetInt32(0),
                rdr.GetString(1),
                rdr.IsDBNull(2) ? null : rdr.GetString(2),
                rdr.GetInt32(3),
                rdr.GetBoolean(4)
            ));
        }

        return list;
    }

    public async Task<HashSet<string>> GetEnabledCheckCodesAsync(CancellationToken ct)
    {
        const string sql = @"
SELECT CheckCode
FROM dbo.MonitorCheckType
WHERE IsEnabled = 1;";

        var set = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

        using var conn = new SqlConnection(_centralConnectionString);
        await conn.OpenAsync(ct);

        using var cmd = new SqlCommand(sql, conn);
        using var rdr = await cmd.ExecuteReaderAsync(ct);

        while (await rdr.ReadAsync(ct))
            set.Add(rdr.GetString(0));

        return set;
    }

    public async Task InsertResultAsync(long runId, MonitoredServer server, CheckResult result, CancellationToken ct)
    {
        using var conn = new SqlConnection(_centralConnectionString);
        await conn.OpenAsync(ct);

        using var cmd = new SqlCommand("dbo.usp_MonitorResult_Insert", conn)
        {
            CommandType = CommandType.StoredProcedure
        };

        cmd.Parameters.AddWithValue("@RunId", runId);
        cmd.Parameters.AddWithValue("@ServerId", server.ServerId);
        cmd.Parameters.AddWithValue("@CheckCode", result.CheckCode);
        cmd.Parameters.AddWithValue("@IsSuccess", result.IsSuccess);
        cmd.Parameters.AddWithValue("@ResponseMs", (object?)result.ResponseMs ?? DBNull.Value);
        cmd.Parameters.AddWithValue("@ItemName", (object?)result.ItemName ?? DBNull.Value);
        cmd.Parameters.AddWithValue("@MetricInt", (object?)result.MetricInt ?? DBNull.Value);
        cmd.Parameters.AddWithValue("@MetricDecimal", (object?)result.MetricDecimal ?? DBNull.Value);
        cmd.Parameters.AddWithValue("@ErrorCategory", (object?)result.ErrorCategory ?? DBNull.Value);
        cmd.Parameters.AddWithValue("@Message", (object?)result.Message ?? DBNull.Value);

        await cmd.ExecuteNonQueryAsync(ct);
    }
}
