namespace PivotSqlMonitor;

public interface ISqlConnectionFactory
{
    string BuildMasterConnectionString(MonitoredServer s);
}

public sealed class DefaultSqlConnectionFactory : ISqlConnectionFactory
{
    private readonly bool _trusted;
    private readonly string? _user;
    private readonly string? _pass;

    public DefaultSqlConnectionFactory(bool trustedConnection = true, string? user = null, string? pass = null)
    {
        _trusted = trustedConnection;
        _user = user;
        _pass = pass;
    }

    public string BuildMasterConnectionString(MonitoredServer s)
    {
        var dataSource = string.IsNullOrWhiteSpace(s.InstanceName)
            ? $"{s.ServerName},{s.SqlPort}"
            : $"{s.ServerName}\{s.InstanceName},{s.SqlPort}";

        var baseCs = $"Server={dataSource};Database=master;Encrypt=True;TrustServerCertificate=True;Connection Timeout=3;";

        if (_trusted)
            return baseCs + "Trusted_Connection=True;";

        return baseCs + $"User ID={_user};Password={_pass};";
    }
}
