using System.Threading;
using System.Threading.Tasks;
using Microsoft.Data.SqlClient;

namespace PivotSqlMonitor;

public abstract class SqlCheckBase
{
    protected readonly ISqlConnectionFactory Factory;

    protected SqlCheckBase(ISqlConnectionFactory factory) => Factory = factory;

    protected async Task<SqlConnection> OpenMasterAsync(MonitoredServer server, CancellationToken ct)
    {
        var cs = Factory.BuildMasterConnectionString(server);
        var conn = new SqlConnection(cs);
        await conn.OpenAsync(ct);
        return conn;
    }
}
