using System;
using System.Net.Sockets;
using Microsoft.Data.SqlClient;

namespace PivotSqlMonitor;

public sealed record MonitoredServer(
    int ServerId,
    string ServerName,
    string? InstanceName,
    int SqlPort,
    bool IsEnabled
);

public sealed record CheckResult(
    string CheckCode,
    bool IsSuccess,
    int? ResponseMs = null,
    string? ItemName = null,
    long? MetricInt = null,
    decimal? MetricDecimal = null,
    string? ErrorCategory = null,
    string? Message = null
);

public interface IMonitorCheck
{
    string CheckCode { get; }
    Task<IReadOnlyList<CheckResult>> ExecuteAsync(MonitoredServer server, CancellationToken ct);
}

internal static class ErrorClassifier
{
    public static (string category, string message) Classify(Exception ex)
    {
        return ex switch
        {
            SocketException se when se.SocketErrorCode == SocketError.TimedOut
                => ("TIMEOUT", se.Message),
            SocketException se when se.SocketErrorCode == SocketError.ConnectionRefused
                => ("REFUSED", se.Message),
            SocketException se when se.SocketErrorCode == SocketError.HostNotFound
                => ("DNS", se.Message),
            SqlException sqlex
                => ("SQL", sqlex.Message),
            TimeoutException tex
                => ("TIMEOUT", tex.Message),
            _ => ("UNKNOWN", ex.Message)
        };
    }
}
