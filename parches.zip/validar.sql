SELECT TOP 5 * FROM Patch.RunLog ORDER BY RunId DESC;
SELECT TOP 20 * FROM Patch.SqlServerPatch ORDER BY PatchId DESC;

-- Asegurar que NO hay duplicados
SELECT Product, Version, KB, COUNT(*) Cnt
FROM Patch.SqlServerPatch
GROUP BY Product, Version, KB
HAVING COUNT(*) > 1;




--TRUNCATE TABLE Patch.HtmlSnapshot
--TRUNCATE TABLE Patch.RunLog
--TRUNCATE TABLE Patch.SqlServerPatch


SELECT * FROM Patch.SqlServerPatch ORDER BY PatchId DESC;

