

IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = 'Patch')
    EXEC('CREATE SCHEMA Patch');
GO

IF OBJECT_ID('Patch.RunLog', 'U') IS NULL
BEGIN
    CREATE TABLE Patch.RunLog
    (
        RunId           bigint IDENTITY(1,1) NOT NULL CONSTRAINT PK_Patch_RunLog PRIMARY KEY,
        SourceUrl       nvarchar(600) NOT NULL,
        PageHash        char(64) NOT NULL,
        StartedAt       datetime2(0) NOT NULL CONSTRAINT DF_Patch_RunLog_StartedAt DEFAULT (sysdatetime()),
        FinishedAt      datetime2(0) NULL,
        Status          varchar(20) NOT NULL CONSTRAINT DF_Patch_RunLog_Status DEFAULT ('Started'),
        PatchesFound    int NULL,
        InsertedCount   int NULL,
        SkippedAsDup    int NULL,
        ErrorMessage    nvarchar(4000) NULL
    );

    CREATE INDEX IX_Patch_RunLog_SourceUrl_StartedAt
    ON Patch.RunLog(SourceUrl, StartedAt DESC);

    CREATE UNIQUE INDEX UX_Patch_RunLog_SourceUrl_PageHash
    ON Patch.RunLog(SourceUrl, PageHash);
END
GO

IF OBJECT_ID('Patch.HtmlSnapshot', 'U') IS NULL
BEGIN
    CREATE TABLE Patch.HtmlSnapshot
    (
        SnapshotId   bigint IDENTITY(1,1) NOT NULL CONSTRAINT PK_Patch_HtmlSnapshot PRIMARY KEY,
        SourceUrl    nvarchar(600) NOT NULL,
        PageHash     char(64) NOT NULL,
        CapturedAt   datetime2(0) NOT NULL CONSTRAINT DF_Patch_HtmlSnapshot_CapturedAt DEFAULT (sysdatetime()),
        HtmlContent  nvarchar(max) NOT NULL
    );

    CREATE UNIQUE INDEX UX_Patch_HtmlSnapshot_SourceUrl_PageHash
    ON Patch.HtmlSnapshot(SourceUrl, PageHash);
END
GO

IF OBJECT_ID('Patch.SqlServerPatch', 'U') IS NULL
BEGIN
    CREATE TABLE Patch.SqlServerPatch
    (
        PatchId        bigint IDENTITY(1,1) NOT NULL CONSTRAINT PK_Patch_SqlServerPatch PRIMARY KEY,
        Product        nvarchar(100) NOT NULL,
        Version        nvarchar(60)  NOT NULL,
        CU             nvarchar(60)  NULL,
        KB             nvarchar(50)  NOT NULL,
        ReleaseDate    date          NULL,
        UrlKB          nvarchar(600) NULL,
        SourceUrl      nvarchar(600) NOT NULL,
        PageHash       char(64)      NOT NULL,
        CreatedAt      datetime2(0)  NOT NULL CONSTRAINT DF_Patch_SqlServerPatch_CreatedAt DEFAULT (sysdatetime())
    );

    CREATE UNIQUE INDEX UX_Patch_SqlServerPatch_UniquePatch
    ON Patch.SqlServerPatch(Product, Version, KB);

    CREATE INDEX IX_Patch_SqlServerPatch_ReleaseDate
    ON Patch.SqlServerPatch(ReleaseDate DESC);
END
GO

IF TYPE_ID('Patch.SqlPatchTvp') IS NULL
BEGIN
    CREATE TYPE Patch.SqlPatchTvp AS TABLE
    (
        Product      nvarchar(100) NOT NULL,
        Version      nvarchar(60)  NOT NULL,
        CU           nvarchar(60)  NULL,
        KB           nvarchar(50)  NOT NULL,
        ReleaseDate  date          NULL,
        UrlKB        nvarchar(600) NULL
    );
END
GO

CREATE OR ALTER PROCEDURE Patch.SaveLearnPatches
    @SourceUrl      nvarchar(600),
    @PageHash       char(64),
    @HtmlContent    nvarchar(max),
    @Patches        Patch.SqlPatchTvp READONLY
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @RunId bigint;
    DECLARE @PatchesFound int = (SELECT COUNT(1) FROM @Patches);

    IF EXISTS (SELECT 1 FROM Patch.RunLog WHERE SourceUrl = @SourceUrl AND PageHash = @PageHash)
    BEGIN
        SELECT
            CAST(0 AS int) AS InsertedCount,
            CAST(@PatchesFound AS int) AS PatchesFound,
            CAST(@PatchesFound AS int) AS SkippedAsDup,
            CAST(1 AS bit) AS AlreadyProcessed;
        RETURN;
    END

    BEGIN TRY
        INSERT INTO Patch.RunLog(SourceUrl, PageHash, PatchesFound, Status)
        VALUES (@SourceUrl, @PageHash, @PatchesFound, 'Started');

        SET @RunId = SCOPE_IDENTITY();

        BEGIN TRY
            INSERT INTO Patch.HtmlSnapshot(SourceUrl, PageHash, HtmlContent)
            VALUES (@SourceUrl, @PageHash, @HtmlContent);
        END TRY
        BEGIN CATCH
            IF ERROR_NUMBER() NOT IN (2601, 2627) THROW;
        END CATCH

        INSERT INTO Patch.SqlServerPatch(Product, Version, CU, KB, ReleaseDate, UrlKB, SourceUrl, PageHash)
        SELECT p.Product, p.Version, p.CU, p.KB, p.ReleaseDate, p.UrlKB, @SourceUrl, @PageHash
        FROM @Patches p
        WHERE NOT EXISTS
        (
            SELECT 1
            FROM Patch.SqlServerPatch t
            WHERE t.Product = p.Product
              AND t.Version  = p.Version
              AND t.KB       = p.KB
        );

        DECLARE @Inserted int = @@ROWCOUNT;
        DECLARE @Skipped int = @PatchesFound - @Inserted;

        UPDATE Patch.RunLog
        SET FinishedAt = sysdatetime(),
            Status = 'Success',
            InsertedCount = @Inserted,
            SkippedAsDup = @Skipped
        WHERE RunId = @RunId;

        SELECT
            @Inserted AS InsertedCount,
            @PatchesFound AS PatchesFound,
            @Skipped AS SkippedAsDup,
            CAST(0 AS bit) AS AlreadyProcessed;
    END TRY
    BEGIN CATCH
        DECLARE @Err nvarchar(4000) = CONCAT(ERROR_NUMBER(), ': ', ERROR_MESSAGE());

        IF @RunId IS NOT NULL
        BEGIN
            UPDATE Patch.RunLog
            SET FinishedAt = sysdatetime(),
                Status = 'Failed',
                ErrorMessage = @Err
            WHERE RunId = @RunId;
        END;

        THROW;
    END CATCH
END
GO
