-- Script de ejemplo para verificación de salud de la instancia
SELECT 
    @@SERVERNAME AS Instancia,
    GETDATE() AS FechaRevision,
    (SELECT cntr_value FROM sys.dm_os_performance_counters WHERE counter_name = 'User Connections') AS ConexionesActivas;
