using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using Microsoft.Data.SqlClient;

class Program
{
    static async Task<int> Main(string[] args)
    {
        // 1. Modo Utilidad para Encriptar Contraseñas vía DPAPI
        if (args.Length >= 2 && (args[0] == "--encrypt" || args[0] == "-e"))
        {
            EncriptarTexto(args[1]);
            return 0;
        }

        if (args.Length == 0)
        {
            Console.WriteLine("Error: Debe especificar el código de la tarea a ejecutar (ej. SqlScriptRunner.exe HEALTH) o usar --encrypt para claves.");
            return 1;
        }

        string nombreTarea = args[0].ToUpper();
        string baseDirectory = AppDomain.CurrentDomain.BaseDirectory;
        string configPath = Path.Combine(baseDirectory, "appsettings.json");

        if (!File.Exists(configPath))
        {
            Console.WriteLine($"Error: No se encontró el archivo de configuración en {configPath}");
            return 1;
        }

        // Limpiar logs antiguos (más de 15 días) al arrancar
        LimpiarLogsAntiguos(baseDirectory);

        try
        {
            string jsonContent = File.ReadAllText(configPath);
            using var doc = JsonDocument.Parse(jsonContent);
            var root = doc.RootElement;

            if (!root.GetProperty("Scripts").TryGetProperty(nombreTarea, out JsonElement scriptConfig))
            {
                RegistrarLog(baseDirectory, nombreTarea, $"ERROR: La tarea '{nombreTarea}' no está configurada en appsettings.json.");
                Console.WriteLine($"La tarea '{nombreTarea}' no existe en la configuración.");
                return 1;
            }

            bool habilitado = scriptConfig.GetProperty("Habilitado").GetBoolean();
            if (!habilitado)
            {
                Console.WriteLine($"La tarea '{nombreTarea}' está deshabilitada en la configuración.");
                return 0;
            }

            string archivoSqlRelativo = scriptConfig.GetProperty("Archivo").GetString()!;
            string archivoSqlPath = Path.Combine(baseDirectory, archivoSqlRelativo);

            if (!File.Exists(archivoSqlPath))
            {
                RegistrarLog(baseDirectory, nombreTarea, $"ERROR: No se encontró el archivo SQL en {archivoSqlPath}");
                return 1;
            }

            string querySql = File.ReadAllText(archivoSqlPath);
            string grupoServidores = scriptConfig.GetProperty("GrupoServidores").GetString()!;
            int paralelismo = scriptConfig.GetProperty("Paralelismo").GetInt32();
            int timeout = scriptConfig.GetProperty("TimeoutSegundos").GetInt32();
            bool guardarResultado = scriptConfig.GetProperty("GuardarResultado").GetBoolean();
            string procDestino = scriptConfig.GetProperty("ProcedimientoDestino").GetString()!;

            var servidores = new List<string>();
            foreach (var s in root.GetProperty("GruposServidores").GetProperty(grupoServidores).EnumerateArray())
            {
                servidores.Add(s.GetString()!);
            }

            string servidorCentral = root.GetProperty("Configuracion").GetProperty("ServidorCentral").GetString()!;
            string bdCentral = root.GetProperty("Configuracion").GetProperty("BaseDatosCentral").GetString()!;

            RegistrarLog(baseDirectory, nombreTarea, $"INICIO de ejecución para {servidores.Count} servidores en paralelo ({paralelismo}).");

            var options = new ParallelOptions { MaxDegreeOfParallelism = paralelismo };

            await Parallel.ForEachAsync(servidores, options, async (servidor, ct) =>
            {
                try
                {
                    string connString = ObtenerCadenaConexiones(root, servidor);
                    
                    using var conn = new SqlConnection(connString);
                    await conn.OpenAsync(ct);

                    using var cmd = new SqlCommand(querySql, conn);
                    cmd.CommandTimeout = timeout;

                    using var reader = await cmd.ExecuteReaderAsync(ct);
                    
                    if (guardarResultado && !string.IsNullOrEmpty(procDestino))
                    {
                        while (await reader.ReadAsync(ct))
                        {
                            // Lógica para centralizar resultados si aplica
                        }
                    }
                    RegistrarLog(baseDirectory, nombreTarea, $"EXITO en servidor: {servidor}");
                }
                catch (Exception ex)
                {
                    RegistrarLog(baseDirectory, nombreTarea, $"FALLO en servidor {servidor}: {ex.Message}");
                }
            });

            RegistrarLog(baseDirectory, nombreTarea, "FIN de la ejecución.");
            return 0;
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error crítico en el motor: {ex.Message}");
            return 1;
        }
    }

    private static string ObtenerCadenaConexiones(JsonElement root, string servidor)
    {
        string userId = string.Empty;
        string passwordCifrado = string.Empty;

        if (root.TryGetProperty("CredencialesServidores", out JsonElement creds) && 
            creds.TryGetProperty(servidor, out JsonElement servCred))
        {
            userId = servCred.GetProperty("Usuario").GetString()!;
            passwordCifrado = servCred.GetProperty("PasswordCifrado").GetString()!;
        }

        if (!string.IsNullOrEmpty(userId) && !string.IsNullOrEmpty(passwordCifrado))
        {
            string passwordPlano = DesencriptarTexto(passwordCifrado);
            return $"Server={servidor};Database=master;User Id={userId};Password={passwordPlano};TrustServerCertificate=True;";
        }
        else
        {
            return $"Server={servidor};Database=master;Integrated Security=true;TrustServerCertificate=True;";
        }
    }

    private static void EncriptarTexto(string textoPlano)
    {
        try
        {
            byte[] bytesPlanos = Encoding.UTF8.GetBytes(textoPlano);
            byte[] bytesCifrados = ProtectedData.Protect(bytesPlanos, null, DataProtectionScope.LocalMachine);
            string resultadoBase64 = Convert.ToBase64String(bytesCifrados);
            Console.WriteLine("Texto cifrado (copiar al appsettings.json):");
            Console.WriteLine(resultadoBase64);
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error al encriptar: {ex.Message}");
        }
    }

    private static string DesencriptarTexto(string textoCifradoBase64)
    {
        byte[] bytesCifrados = Convert.FromBase64String(textoCifradoBase64);
        byte[] bytesPlanos = ProtectedData.Unprotect(bytesCifrados, null, DataProtectionScope.LocalMachine);
        return Encoding.UTF8.GetString(bytesPlanos);
    }

    private static void RegistrarLog(string baseDir, string proceso, string mensaje)
    {
        try
        {
            string carpetaLog = Path.Combine(baseDir, "logs", proceso);
            Directory.CreateDirectory(carpetaLog);

            string nombreArchivo = $"log_{proceso}_{DateTime.Now:yyyyMMdd}.txt";
            string rutaCompleta = Path.Combine(carpetaLog, nombreArchivo);

            string lineaLog = $"{DateTime.Now:yyyy-MM-dd HH:mm:ss} - {mensaje}{Environment.NewLine}";
            File.AppendAllText(rutaCompleta, lineaLog);
        }
        catch 
        {
            // Evitar excepciones fatales si falla el log
        }
    }

    private static void LimpiarLogsAntiguos(string baseDir)
    {
        try
        {
            string carpetaLogsBase = Path.Combine(baseDir, "logs");
            if (!Directory.Exists(carpetaLogsBase)) return;

            var archivos = Directory.GetFiles(carpetaLogsBase, "*.txt", SearchOption.AllDirectories);
            foreach (var archivo in archivos)
            {
                var fi = new FileInfo(archivo);
                if (fi.LastWriteTime < DateTime.Now.AddDays(-15))
                {
                    fi.Delete();
                }
            }
        }
        catch
        {
            // Ignorar errores de limpieza
        }
    }
}
