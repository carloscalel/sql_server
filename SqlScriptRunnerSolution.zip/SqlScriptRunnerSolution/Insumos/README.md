# Guía de Operación y Mantenimiento - SqlScriptRunner

Este motor genérico permite ejecutar scripts de T-SQL en múltiples servidores de forma concurrente, parametrizando todo mediante el archivo `appsettings.json` sin necesidad de recompilar el código en C#.

---

## 1. ¿Cómo agregar un nuevo Servidor?

1. Si el servidor utiliza **Autenticación de Windows** (cuenta de servicio), solo agrégalo dentro del grupo que corresponda en la sección `"GruposServidores"` del archivo `appsettings.json`:
   ```json
   "GruposServidores": {
     "Produccion": [
       "SQL01",
       "SQL02",
       "NUEVOSERV"
     ]
   }
   ```
2. Si el servidor requiere **Credenciales SQL específicas**, además de agregarlo al grupo, añade una entrada en la sección `"CredencialesServidores"` utilizando la contraseña encriptada (ver sección de encriptación):
   ```json
   "CredencialesServidores": {
     "NUEVOSERV": {
       "Usuario": "admin_db",
       "PasswordCifrado": "TU_HASH_CIFRADO_AQUI"
     }
   }
   ```

---

## 2. ¿Cómo agregar un nuevo Script T-SQL?

1. Crea tu archivo físico con la consulta o mantenimiento y guárdalo dentro de la carpeta `Scripts\` (por ejemplo: `Scripts\Bloqueos.sql`).
2. Abre el archivo `appsettings.json` y agrega un nuevo bloque dentro de `"Scripts"` con los parámetros deseados:
   ```json
   "BLOQUEOS": {
     "Habilitado": true,
     "Archivo": "Scripts\\Bloqueos.sql",
     "GrupoServidores": "Produccion",
     "Paralelismo": 5,
     "TimeoutSegundos": 120,
     "ContinuarSiHayError": true,
     "GuardarResultado": true,
     "GuardarErrores": true,
     "ProcedimientoDestino": "dbo.usp_GuardarBloqueos"
   }
   ```
3. Configura tu **SQL Server Agent Job** para que ejecute el comando pasando como argumento el identificador del script:
   ```cmd
   C:\RutaDelEjecutable\SqlScriptRunner.exe BLOQUEOS
   ```

---

## 3. ¿Cómo configurar el Paralelismo y Timeouts?

* **Paralelismo:** Indica cuántos servidores se procesarán simultáneamente mediante hilos asíncronos (`Task`). Si pones `3`, procesará bloques de 3 en 3 instancias a la vez, optimizando el uso de recursos sin saturar la red ni el CPU.
* **TimeoutSegundos:** Define el tiempo límite de espera en segundos por cada comando SQL enviado al servidor antes de generar una cancelación por tiempo excedido.

---

## 4. ¿Cómo encriptar contraseñas?

Para generar el hash seguro mediante DPAPI (protegido para la máquina actual), abre una terminal de comandos en la ruta del ejecutable y utiliza el argumento `--encrypt` seguido de tu contraseña en texto plano:

```bash
SqlScriptRunner.exe --encrypt "MiPasswordSuperSeguro123"
```

El sistema te devolverá una cadena en formato Base64. Copia ese texto resultante y pégalo en el parámetro `"PasswordCifrado"` del servidor correspondiente en el archivo `appsettings.json`.

---

## 5. Política de Logs Automáticos

El sistema genera automáticamente una carpeta `logs/` seccionada por el nombre de la tarea ejecutada:
* Ejemplo: `logs/HEALTH/log_HEALTH_20261008.txt`
* **Retención:** El motor evalúa de forma autónoma cada inicio de ejecución y **borra automáticamente cualquier archivo de log que tenga más de 15 días** de antigüedad, manteniendo limpio el espacio en disco del servidor.
