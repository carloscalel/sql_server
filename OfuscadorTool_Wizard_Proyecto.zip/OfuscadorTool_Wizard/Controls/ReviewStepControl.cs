using OfuscadorTool.Models;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace OfuscadorTool
{
    public class ReviewStepControl : WizardStepBase
    {
        public override string StepTitle => "Revisión";
        private readonly GlobalConfig _config;
        private readonly TextBox _summary = new TextBox();

        public ReviewStepControl(GlobalConfig config)
        {
            _config = config;
            _summary.Dock = DockStyle.Fill;
            _summary.Multiline = true;
            _summary.ReadOnly = true;
            _summary.ScrollBars = ScrollBars.Both;
            _summary.Font = new System.Drawing.Font("Consolas", 10F);
            Controls.Add(_summary);
        }

        public override void OnStepVisible()
        {
            var sb = new StringBuilder();
            var o = _config.DefaultOptions;

            sb.AppendLine("RESUMEN DEL DESPLIEGUE");
            sb.AppendLine("======================");
            sb.AppendLine();
            sb.AppendLine($"DryRun: {o.DryRun}");
            sb.AppendLine($"ApplyDDM: {o.ApplyDDM}");
            sb.AppendLine($"CreateViews: {o.CreateViews}");
            sb.AppendLine($"CreateSynonyms: {o.CreateSynonyms}");
            sb.AppendLine($"ForceReapply: {o.ForceReapply}");
            sb.AppendLine($"MaskingMode: {o.MaskingMode}");
            sb.AppendLine($"ApplySafePolicy: {o.ApplySafePolicy}");
            sb.AppendLine($"ApplyDefaultSchemaPolicy: {o.ApplyDefaultSchemaPolicy}");
            sb.AppendLine($"MirrorObjectPermissions: {o.MirrorObjectPermissions}");
            sb.AppendLine($"CopyDmlPermissions: {o.CopyDmlPermissions}");
            sb.AppendLine($"PermissionMirrorScope: {o.PermissionMirrorScope}");
            sb.AppendLine($"BaseAccessAction: {o.BaseAccessAction}");
            sb.AppendLine($"RunReprocess: {o.RunReprocess}");
            sb.AppendLine($"ReprocessMode: {o.ReprocessMode}");
            sb.AppendLine();

            sb.AppendLine("SERVIDORES:");
            foreach (var server in _config.Servers.Where(s => s.IsEnabled))
            {
                sb.AppendLine($"- {server.DisplayName} ({server.GetDataSource()})");
                if (_config.DatabaseSelections.TryGetValue(server.Id, out var selection))
                {
                    sb.AppendLine($"  Modo: {selection.Mode}");
                    if (selection.Mode == SelectionMode.OnlyThese)
                        sb.AppendLine($"  Solo: {string.Join(", ", selection.SelectedDatabases)}");
                    else if (selection.Mode == SelectionMode.AllExcept)
                        sb.AppendLine($"  Excluir: {string.Join(", ", selection.ExcludedDatabases)}");
                }
                else
                {
                    sb.AppendLine("  Sin selección de bases guardada.");
                }
            }

            sb.AppendLine();
            sb.AppendLine("PRINCIPALES:");
            foreach (var p in _config.PrincipalPolicies.Where(p => !string.IsNullOrWhiteSpace(p.PrincipalName)))
            {
                sb.AppendLine($"- {p.PrincipalName} | Enabled={p.IsEnabled} | DefaultSchema={p.ApplyDefaultSchema} | Mirror={p.MirrorObjectPermissions} | DML={p.IncludeDml} | BlockBase={p.BlockBaseAccess}");
            }

            if (!o.DryRun)
            {
                sb.AppendLine();
                sb.AppendLine("ADVERTENCIA: DryRun está desactivado. El wizard ejecutará cambios reales.");
            }

            _summary.Text = sb.ToString();
        }
    }
}
