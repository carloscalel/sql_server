using System.Windows.Forms;

namespace OfuscadorTool
{
    public class WelcomeStepControl : WizardStepBase
    {
        public override string StepTitle => "Bienvenida";

        public WelcomeStepControl()
        {
            Controls.Add(new TextBox
            {
                Dock = DockStyle.Fill,
                Multiline = true,
                ReadOnly = true,
                BorderStyle = BorderStyle.None,
                Font = new System.Drawing.Font("Segoe UI", 10F),
                Text =
@"Este wizard instala y configura el sistema de ofuscamiento/enmascaramiento para SQL Server.

Flujo recomendado:

1. Agregar servidor SQL Server.
2. Seleccionar bases de datos.
3. Configurar opciones de DDM, vistas masked y reproceso.
4. Agregar usuarios o roles que usarán DEFAULT_SCHEMA = masked.
5. Revisar la configuración.
6. Ejecutar primero en DryRun.

Recomendación:
- Prueba primero en una base de laboratorio.
- Mantén DryRun activado en la primera ejecución.
- Usa BaseAccessAction = REPORT_ONLY hasta validar permisos.
- No apliques DENY automáticamente sin revisar el reporte."
            });
        }
    }
}
