/* ===========================================================
   01_sp_CreateViewWithDml.sql  (v3.4 SQL 2016 FIX Audit)
   - Usa dbo.Masked_Patterns (Pattern, DdmFunction, ViewMaskExpr)
   - Enmascara en la vista usando ViewMaskExpr
   - Crea triggers INSTEAD OF (I/U/D)
   - Registra en dbo.Masked_Audit (sin tocar la columna IDENTITY)
   ===========================================================*/
IF OBJECT_ID('dbo.sp_Masked_CreateViewWithDml','P') IS NOT NULL
  DROP PROCEDURE dbo.sp_Masked_CreateViewWithDml;
GO
CREATE PROCEDURE dbo.sp_Masked_CreateViewWithDml
  @BaseSchema   SYSNAME = N'dbo',
  @TableName    SYSNAME,
  @MaskedSchema SYSNAME = N'masked'
AS
BEGIN
  SET NOCOUNT ON; SET XACT_ABORT ON;

  DECLARE @BaseFull NVARCHAR(300) = QUOTENAME(@BaseSchema)+'.'+QUOTENAME(@TableName);
  DECLARE @ViewFull NVARCHAR(300) = QUOTENAME(@MaskedSchema)+'.'+QUOTENAME(@TableName);

  IF OBJECT_ID(@BaseFull,'U') IS NULL
  BEGIN
    INSERT INTO dbo.Masked_Audit (EventType,SchemaName,ObjectName,ColumnName,Action,Detail)
    VALUES (N'ERROR',@BaseSchema,@TableName,NULL,N'VIEW',N'Tabla base no existe');
    RETURN;
  END

  -- PK (para UPDATE/DELETE)
  DECLARE @PK TABLE(Col SYSNAME PRIMARY KEY);
  INSERT INTO @PK(Col)
  SELECT c.name
  FROM sys.key_constraints kc
  JOIN sys.index_columns ic ON ic.object_id=kc.parent_object_id AND ic.index_id=kc.unique_index_id
  JOIN sys.columns c ON c.object_id=kc.parent_object_id AND c.column_id=ic.column_id
  WHERE kc.[type]='PK' AND kc.parent_object_id=OBJECT_ID(@BaseFull)
  ORDER BY ic.key_ordinal;

  -- SELECT list con ViewMaskExpr
  DECLARE @SelectList NVARCHAR(MAX);

  ;WITH Cols AS (
    SELECT 
      c.name,
      c.is_computed,
      TYPE_NAME(c.user_type_id) AS Tipo,
      (SELECT TOP 1 p.ViewMaskExpr
       FROM dbo.Masked_Patterns p
       WHERE c.name LIKE p.Pattern
       ORDER BY p.Pattern) AS ViewMaskExpr
    FROM sys.columns c
    WHERE c.object_id = OBJECT_ID(@BaseFull)
  ),
  Exprs AS (
    SELECT
      CASE 
        WHEN is_computed=1 THEN QUOTENAME(name)+' AS '+QUOTENAME(name)
        WHEN ViewMaskExpr IS NOT NULL AND Tipo IN ('char','nchar','varchar','nvarchar','text','ntext')
          THEN REPLACE(ViewMaskExpr,'{col}',QUOTENAME(name)) + ' AS ' + QUOTENAME(name)
        ELSE QUOTENAME(name)
      END AS Expr
    FROM Cols
  )
  SELECT @SelectList =
    STUFF((SELECT ','+CHAR(13)+E.Expr FROM Exprs E FOR XML PATH(''), TYPE).value('.','nvarchar(max)'),1,2,'');

  IF OBJECT_ID(@ViewFull,'V') IS NOT NULL EXEC(N'DROP VIEW '+@ViewFull+';');
  DECLARE @sql NVARCHAR(MAX) = N'CREATE VIEW '+@ViewFull+' AS SELECT '+@SelectList+' FROM '+@BaseFull+';';
  BEGIN TRY
    EXEC sp_executesql @sql;
    INSERT INTO dbo.Masked_Audit (EventType,SchemaName,ObjectName,ColumnName,Action,Detail)
    VALUES (N'VIEW',@MaskedSchema,@TableName,NULL,N'CREATE',N'Vista enmascarada');
  END TRY BEGIN CATCH
    INSERT INTO dbo.Masked_Audit (EventType,SchemaName,ObjectName,ColumnName,Action,Detail)
    VALUES (N'ERROR',@MaskedSchema,@TableName,NULL,N'VIEW',ERROR_MESSAGE());
    RETURN;
  END CATCH;

  -- Columnas actualizables (no computed/identity/rowguid)
  DECLARE @Updatable TABLE(Col SYSNAME PRIMARY KEY);
  INSERT INTO @Updatable(Col)
  SELECT c.name FROM sys.columns c
  WHERE c.object_id=OBJECT_ID(@BaseFull) AND c.is_computed=0 AND c.is_identity=0 AND c.is_rowguidcol=0;

  -- Joins por PK
  DECLARE @PKJoin NVARCHAR(MAX)=NULL, @PKJoinVI NVARCHAR(MAX)=NULL;
  IF EXISTS(SELECT 1 FROM @PK)
  BEGIN
    SELECT @PKJoin =
      STUFF((SELECT ' AND B.'+QUOTENAME(Col)+'=I.'+QUOTENAME(Col) FROM @PK FOR XML PATH(''), TYPE).value('.','nvarchar(max)'),1,5,'');

    SET @PKJoinVI = REPLACE(@PKJoin,'B.','V.');
  END

  -- INSERT lists
  DECLARE @InsertColList NVARCHAR(MAX)=NULL, @InsertSelList NVARCHAR(MAX)=NULL;
  SELECT @InsertColList =
    STUFF((SELECT ','+QUOTENAME(Col) FROM @Updatable FOR XML PATH(''), TYPE).value('.','nvarchar(max)'),1,1,'');
  SELECT @InsertSelList =
    STUFF((SELECT ','+'I.'+QUOTENAME(Col) FROM @Updatable FOR XML PATH(''), TYPE).value('.','nvarchar(max)'),1,1,'');

  -- UPDATE set
  DECLARE @UpdateSet NVARCHAR(MAX)=NULL;
  SELECT @UpdateSet =
    STUFF((SELECT ','+'B.'+QUOTENAME(Col)+'=I.'+QUOTENAME(Col)
           FROM @Updatable WHERE Col NOT IN (SELECT Col FROM @PK)
           FOR XML PATH(''), TYPE).value('.','nvarchar(max)'),1,1,'');

  -- Nombres de triggers
  DECLARE @TrigIOI SYSNAME = QUOTENAME(@MaskedSchema)+'.'+QUOTENAME(@TableName+'_IOI');
  DECLARE @TrigIOU SYSNAME = QUOTENAME(@MaskedSchema)+'.'+QUOTENAME(@TableName+'_IOU');
  DECLARE @TrigIOD SYSNAME = QUOTENAME(@MaskedSchema)+'.'+QUOTENAME(@TableName+'_IOD');

  -- INSERT
  IF (@InsertColList IS NOT NULL AND LEN(@InsertColList)>0)
  BEGIN
    IF OBJECT_ID(@TrigIOI,'TR') IS NOT NULL EXEC(N'DROP TRIGGER '+@TrigIOI+';');
    SET @sql = N'CREATE TRIGGER '+@TrigIOI+N' ON '+@ViewFull+N' INSTEAD OF INSERT AS
                BEGIN SET NOCOUNT ON;
                  INSERT INTO '+@BaseFull+N' ('+@InsertColList+N')
                  SELECT '+@InsertSelList+N' FROM inserted I;
                  SELECT V.* FROM '+@ViewFull+N' V '+
                  (CASE WHEN @PKJoinVI IS NOT NULL THEN 'JOIN inserted I ON '+@PKJoinVI ELSE '' END)+N';
                END';
    BEGIN TRY
      EXEC(@sql);
      INSERT INTO dbo.Masked_Audit (EventType,SchemaName,ObjectName,ColumnName,Action,Detail)
      VALUES (N'TRIGGER',@MaskedSchema,@TableName,NULL,N'CREATE',N'INSTEAD OF INSERT');
    END TRY BEGIN CATCH
      INSERT INTO dbo.Masked_Audit (EventType,SchemaName,ObjectName,ColumnName,Action,Detail)
      VALUES (N'ERROR',@MaskedSchema,@TableName,NULL,N'TRIGGER INSERT',ERROR_MESSAGE());
    END CATCH
  END ELSE
    INSERT INTO dbo.Masked_Audit (EventType,SchemaName,ObjectName,ColumnName,Action,Detail)
    VALUES (N'INFO',@MaskedSchema,@TableName,NULL,N'SKIP INSERT TRIGGER',N'Sin columnas insertables');

  -- UPDATE
  IF (@UpdateSet IS NOT NULL AND LEN(@UpdateSet)>0 AND @PKJoin IS NOT NULL)
  BEGIN
    IF OBJECT_ID(@TrigIOU,'TR') IS NOT NULL EXEC(N'DROP TRIGGER '+@TrigIOU+';');
    SET @sql = N'CREATE TRIGGER '+@TrigIOU+N' ON '+@ViewFull+N' INSTEAD OF UPDATE AS
                BEGIN SET NOCOUNT ON;
                  UPDATE B SET '+@UpdateSet+N'
                  FROM '+@BaseFull+N' B JOIN inserted I ON '+@PKJoin+N';
                  SELECT V.* FROM '+@ViewFull+N' V JOIN inserted I ON '+@PKJoinVI+N';
                END';
    BEGIN TRY
      EXEC(@sql);
      INSERT INTO dbo.Masked_Audit (EventType,SchemaName,ObjectName,ColumnName,Action,Detail)
      VALUES (N'TRIGGER',@MaskedSchema,@TableName,NULL,N'CREATE',N'INSTEAD OF UPDATE');
    END TRY BEGIN CATCH
      INSERT INTO dbo.Masked_Audit (EventType,SchemaName,ObjectName,ColumnName,Action,Detail)
      VALUES (N'ERROR',@MaskedSchema,@TableName,NULL,N'TRIGGER UPDATE',ERROR_MESSAGE());
    END CATCH
  END ELSE
    INSERT INTO dbo.Masked_Audit (EventType,SchemaName,ObjectName,ColumnName,Action,Detail)
    VALUES (N'INFO',@MaskedSchema,@TableName,NULL,N'SKIP UPDATE TRIGGER',N'PK ausente o sin columnas');

  -- DELETE
  IF (@PKJoin IS NOT NULL)
  BEGIN
    IF OBJECT_ID(@TrigIOD,'TR') IS NOT NULL EXEC(N'DROP TRIGGER '+@TrigIOD+';');
    SET @sql = N'CREATE TRIGGER '+@TrigIOD+N' ON '+@ViewFull+N' INSTEAD OF DELETE AS
                BEGIN SET NOCOUNT ON;
                  DELETE B FROM '+@BaseFull+N' B
                  JOIN deleted D ON '+REPLACE(@PKJoin,'I.','D.')+N';
                END';
    BEGIN TRY
      EXEC(@sql);
      INSERT INTO dbo.Masked_Audit (EventType,SchemaName,ObjectName,ColumnName,Action,Detail)
      VALUES (N'TRIGGER',@MaskedSchema,@TableName,NULL,N'CREATE',N'INSTEAD OF DELETE');
    END TRY BEGIN CATCH
      INSERT INTO dbo.Masked_Audit (EventType,SchemaName,ObjectName,ColumnName,Action,Detail)
      VALUES (N'ERROR',@MaskedSchema,@TableName,NULL,N'TRIGGER DELETE',ERROR_MESSAGE());
    END CATCH
  END ELSE
    INSERT INTO dbo.Masked_Audit (EventType,SchemaName,ObjectName,ColumnName,Action,Detail)
    VALUES (N'INFO',@MaskedSchema,@TableName,NULL,N'SKIP DELETE TRIGGER',N'PK ausente');

  BEGIN TRY
    EXEC('GRANT SELECT ON '+@ViewFull+' TO [rol_app_lectura];');
  END TRY BEGIN CATCH END CATCH;
END
GO
