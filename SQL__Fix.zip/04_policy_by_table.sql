/* ===========================================================
   04_policy_by_table.sql  (SQL 2016 compatible, sin STRING_AGG)
   - GRANT en dbo.<tabla> solo si tiene DDM
   - DENY en dbo.<tabla> si tiene vista enmascarada
   - Onboarding de usuarios excluyendo sysadmin/db_owner/lista
   ===========================================================*/
SET NOCOUNT ON; SET XACT_ABORT ON;

DECLARE @IncludeDml BIT = 0;
DECLARE @Excluidos TABLE(UserName SYSNAME PRIMARY KEY);
-- agrega especiales a excluir
 INSERT INTO @Excluidos VALUES (N'svc_replicacion');

IF NOT EXISTS (SELECT 1 FROM sys.database_principals WHERE name=N'rol_app_lectura')     CREATE ROLE rol_app_lectura;
IF NOT EXISTS (SELECT 1 FROM sys.database_principals WHERE name=N'rol_app_dml')         CREATE ROLE rol_app_dml;
IF NOT EXISTS (SELECT 1 FROM sys.database_principals WHERE name=N'rol_app_bloqueo_dbo') CREATE ROLE rol_app_bloqueo_dbo;

BEGIN TRY GRANT SELECT ON SCHEMA::app    TO rol_app_lectura; END TRY BEGIN CATCH END CATCH;
BEGIN TRY GRANT SELECT ON SCHEMA::masked TO rol_app_lectura; END TRY BEGIN CATCH END CATCH;
IF @IncludeDml=1 BEGIN TRY GRANT INSERT,UPDATE,DELETE ON SCHEMA::masked TO rol_app_dml; END TRY BEGIN CATCH END CATCH;

IF OBJECT_ID('tempdb..#DDM') IS NOT NULL DROP TABLE #DDM;
IF OBJECT_ID('tempdb..#ConVista') IS NOT NULL DROP TABLE #ConVista;

SELECT DISTINCT o.name AS Tbl INTO #DDM
FROM sys.masked_columns mc
JOIN sys.objects o ON o.object_id=mc.object_id AND o.type='U' AND o.is_ms_shipped=0
JOIN sys.schemas s ON s.schema_id=o.schema_id
WHERE s.name=N'dbo';

SELECT v.name AS Tbl INTO #ConVista
FROM sys.views v JOIN sys.schemas s ON s.schema_id=v.schema_id
WHERE s.name=N'masked'
  AND EXISTS (SELECT 1 FROM sys.objects t JOIN sys.schemas sd ON sd.schema_id=t.schema_id WHERE sd.name=N'dbo' AND t.type='U' AND t.name=v.name);

DECLARE @sql NVARCHAR(MAX);

-- GRANT por tabla (DDM)
SELECT @sql = STUFF((SELECT CHAR(13)+N'BEGIN TRY GRANT SELECT ON dbo.'+QUOTENAME(Tbl)+N' TO rol_app_lectura; END TRY BEGIN CATCH END CATCH;'
                     FROM #DDM FOR XML PATH(''), TYPE).value('.','nvarchar(max)'),1,1,'');
IF @sql IS NOT NULL AND LEN(@sql)>0 EXEC sp_executesql @sql;

-- DENY por tabla (con vista enmascarada)
SELECT @sql = STUFF((SELECT CHAR(13)+N'BEGIN TRY DENY SELECT,INSERT,UPDATE,DELETE ON dbo.'+QUOTENAME(Tbl)+N' TO rol_app_bloqueo_dbo; END TRY BEGIN CATCH END CATCH;'
                     FROM #ConVista FOR XML PATH(''), TYPE).value('.','nvarchar(max)'),1,1,'');
IF @sql IS NOT NULL AND LEN(@sql)>0 EXEC sp_executesql @sql;

-- Usuarios objetivo (no sysadmin, no db_owner, no excluidos)
IF OBJECT_ID('tempdb..#Objetivo') IS NOT NULL DROP TABLE #Objetivo;
CREATE TABLE #Objetivo(UserName SYSNAME PRIMARY KEY);

WITH db_users AS (
  SELECT dp.name, dp.sid, dp.type_desc
  FROM sys.database_principals dp
  WHERE dp.type IN ('S','U','E')
    AND dp.principal_id > 4
    AND dp.name NOT IN (N'dbo',N'guest',N'sys',N'INFORMATION_SCHEMA')
),
owners AS (
  SELECT m.member_principal_id
  FROM sys.database_role_members m
  JOIN sys.database_principals r ON r.principal_id=m.role_principal_id
  WHERE r.name=N'db_owner'
),
srv AS (
  SELECT sp.name, sp.sid
  FROM sys.server_role_members srm
  JOIN sys.server_principals sr ON sr.principal_id=srm.role_principal_id AND sr.name=N'sysadmin'
  JOIN sys.server_principals sp ON sp.principal_id=srm.member_principal_id
)
INSERT INTO #Objetivo(UserName)
SELECT u.name
FROM db_users u
LEFT JOIN owners o ON o.member_principal_id = DATABASE_PRINCIPAL_ID(u.name)
LEFT JOIN srv    s ON s.sid = u.sid
LEFT JOIN @Excluidos ex ON ex.UserName = u.name
WHERE o.member_principal_id IS NULL
  AND s.sid IS NULL
  AND ex.UserName IS NULL;

DECLARE @u SYSNAME;
DECLARE cur CURSOR LOCAL FAST_FORWARD FOR SELECT UserName FROM #Objetivo;
OPEN cur; FETCH NEXT FROM cur INTO @u;
WHILE @@FETCH_STATUS=0
BEGIN
  BEGIN TRY
    IF NOT EXISTS (SELECT 1 FROM sys.database_principals WHERE name=@u)
      EXEC('CREATE USER ['+@u+'] FOR LOGIN ['+@u+'];');
    EXEC('ALTER USER ['+@u+'] WITH DEFAULT_SCHEMA = app;');
    BEGIN TRY EXEC sp_droprolemember 'db_datareader',@u; END TRY BEGIN CATCH END CATCH;
    BEGIN TRY EXEC sp_droprolemember 'db_datawriter',@u; END TRY BEGIN CATCH END CATCH;
    BEGIN TRY EXEC sp_addrolemember 'rol_app_bloqueo_dbo',@u; END TRY BEGIN CATCH END CATCH;
    BEGIN TRY EXEC sp_addrolemember 'rol_app_lectura',@u; END TRY BEGIN CATCH END CATCH;
    IF @IncludeDml=1 BEGIN TRY EXEC sp_addrolemember 'rol_app_dml',@u; END TRY BEGIN CATCH END CATCH;
  END TRY BEGIN CATCH
    PRINT 'ERROR con '+@u+': '+ERROR_MESSAGE();
  END CATCH;
  FETCH NEXT FROM cur INTO @u;
END
CLOSE cur; DEALLOCATE cur;
