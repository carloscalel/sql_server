using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace OfuscadorTool.Services
{
    public class SqlScriptService
    {
        public string ReadEmbeddedScript(string scriptName)
        {
            var assembly = Assembly.GetExecutingAssembly();
            string resourceName = null;

            foreach (var name in assembly.GetManifestResourceNames())
            {
                if (name.EndsWith("Scripts." + scriptName, StringComparison.OrdinalIgnoreCase))
                {
                    resourceName = name;
                    break;
                }
            }

            if (resourceName == null)
                throw new FileNotFoundException($"No se encontro el script embebido: {scriptName}");

            using var stream = assembly.GetManifestResourceStream(resourceName);
            using var reader = new StreamReader(stream);
            return reader.ReadToEnd();
        }

        public async Task ExecuteScriptAsync(string connectionString, string script, int commandTimeout, Action<string> log)
        {
            var batches = SplitSqlBatches(script);

            using var connection = new SqlConnection(connectionString);
            await connection.OpenAsync();

            foreach (var batch in batches)
            {
                if (string.IsNullOrWhiteSpace(batch))
                    continue;

                using var command = connection.CreateCommand();
                command.CommandText = batch;
                command.CommandTimeout = commandTimeout;

                try
                {
                    await command.ExecuteNonQueryAsync();
                }
                catch (Exception ex)
                {
                    log?.Invoke("ERROR EN BATCH SQL:");
                    log?.Invoke(Shorten(batch, 1200));
                    log?.Invoke(ex.Message);
                    throw;
                }
            }
        }

        private static List<string> SplitSqlBatches(string script)
        {
            var batches = new List<string>();
            string pattern = @"^\s*GO\s*;?\s*$";
            string[] parts = Regex.Split(script, pattern, RegexOptions.Multiline | RegexOptions.IgnoreCase);

            foreach (var part in parts)
            {
                if (!string.IsNullOrWhiteSpace(part))
                    batches.Add(part);
            }

            return batches;
        }

        private static string Shorten(string value, int max)
        {
            if (string.IsNullOrEmpty(value) || value.Length <= max) return value;
            return value.Substring(0, max) + Environment.NewLine + "... [batch truncado para log]";
        }
    }
}
