using Newtonsoft.Json;
using OfuscadorTool.Models;
using System;
using System.IO;

namespace OfuscadorTool.Services
{
    public class ConfigService
    {
        private readonly string _configPath;

        public ConfigService()
        {
            string folder = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
                "OfuscadorTool"
            );

            Directory.CreateDirectory(folder);
            _configPath = Path.Combine(folder, "config.json");
        }

        public GlobalConfig Load()
        {
            try
            {
                if (!File.Exists(_configPath))
                    return new GlobalConfig();

                string json = File.ReadAllText(_configPath);
                return JsonConvert.DeserializeObject<GlobalConfig>(json) ?? new GlobalConfig();
            }
            catch
            {
                return new GlobalConfig();
            }
        }

        public void Save(GlobalConfig config)
        {
            string json = JsonConvert.SerializeObject(config, Formatting.Indented);
            File.WriteAllText(_configPath, json);
        }
    }
}
