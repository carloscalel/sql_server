using Microsoft.Data.SqlClient;
using OfuscadorTool.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfuscadorTool.Services
{
    public class DeploymentService
    {
        private readonly SqlScriptService _scriptService = new SqlScriptService();

        public async Task TestConnectionAsync(ServerConnection server)
        {
            using var connection = new SqlConnection(server.GetConnectionString("master"));
            await connection.OpenAsync();
        }

        public async Task<List<string>> GetDatabasesAsync(ServerConnection server)
        {
            var result = new List<string>();

            using var connection = new SqlConnection(server.GetConnectionString("master"));
            await connection.OpenAsync();

            const string sql = @"
SELECT name
FROM sys.databases
WHERE database_id > 4
  AND state_desc = 'ONLINE'
ORDER BY name;";

            using var command = new SqlCommand(sql, connection);
            using var reader = await command.ExecuteReaderAsync();

            while (await reader.ReadAsync())
                result.Add(reader.GetString(0));

            return result;
        }

        public List<string> ResolveSelectedDatabases(ServerConnection server, GlobalConfig config, IEnumerable<string> availableDatabases)
        {
            if (!config.DatabaseSelections.TryGetValue(server.Id, out var selection))
                return availableDatabases.ToList();

            var available = availableDatabases.ToList();

            if (selection.Mode == DatabaseSelectionMode.AllDatabases)
                return available;

            if (selection.Mode == DatabaseSelectionMode.OnlyThese)
                return available.Where(d => selection.SelectedDatabases.Contains(d, StringComparer.OrdinalIgnoreCase)).ToList();

            return available.Where(d => !selection.ExcludedDatabases.Contains(d, StringComparer.OrdinalIgnoreCase)).ToList();
        }

        public async Task<DeploymentResult> DeployDatabaseAsync(
            ServerConnection server,
            string databaseName,
            DeploymentOptions options,
            IEnumerable<PrincipalPolicy> principalPolicies,
            Action<string> log)
        {
            var result = new DeploymentResult
            {
                ServerName = server.DisplayName,
                DatabaseName = databaseName,
                StartTime = DateTime.Now,
                Success = false
            };

            try
            {
                string connectionString = server.GetConnectionString(databaseName);
                int timeout = options.CommandTimeout <= 0 ? 300 : options.CommandTimeout;

                log?.Invoke($"\r\n=== {server.DisplayName} / {databaseName} ===");

                await ExecuteNamedScript(connectionString, "setup.sql", timeout, log);
                result.AppliedChanges.Add("setup.sql");

                await ApplyRuntimeConfigAsync(connectionString, options, timeout, log);
                result.AppliedChanges.Add("Configuracion runtime dbo.Masked_Config");

                await UpsertPrincipalPoliciesAsync(connectionString, principalPolicies, timeout, log);
                result.AppliedChanges.Add("dbo.Masked_PrincipalPolicy");

                await ExecuteNamedScript(connectionString, "sp_ManageColumnRule.sql", timeout, log);
                result.AppliedChanges.Add("sp_ManageColumnRule.sql");

                await ExecuteNamedScript(connectionString, "sp_CreateViewWithDml.sql", timeout, log);
                result.AppliedChanges.Add("sp_CreateViewWithDml.sql");

                if (options.RunReprocess)
                {
                    var script = _scriptService.ReadEmbeddedScript("06_reprocess_all_CONTROLADO.sql");
                    script = PrepareReprocessScript(script, options);
                    await _scriptService.ExecuteScriptAsync(connectionString, script, timeout, log);
                    result.AppliedChanges.Add($"06_reprocess_all_CONTROLADO.sql ({options.ReprocessMode})");
                }

                if (options.ApplyDDM)
                {
                    await ExecuteNamedScript(connectionString, "apply_ddm.sql", timeout, log);
                    result.AppliedChanges.Add("apply_ddm.sql");
                }

                if (options.CreateViews)
                {
                    await ExecuteNamedScript(connectionString, "02_deploy_all.sql", timeout, log);
                    result.AppliedChanges.Add("02_deploy_all.sql");
                }

                if (options.ApplySafePolicy)
                {
                    var policyScript = _scriptService.ReadEmbeddedScript("04_policy_by_table_SAFE.sql");
                    policyScript = PreparePolicyScript(policyScript, options);
                    await _scriptService.ExecuteScriptAsync(connectionString, policyScript, timeout, log);
                    result.AppliedChanges.Add("04_policy_by_table_SAFE.sql");
                }

                result.Success = true;
                result.EndTime = DateTime.Now;
                log?.Invoke($"OK: {server.DisplayName} / {databaseName}");
            }
            catch (Exception ex)
            {
                result.Success = false;
                result.ErrorMessage = ex.Message;
                result.EndTime = DateTime.Now;
                log?.Invoke($"ERROR en {server.DisplayName} / {databaseName}: {ex.Message}");
            }

            return result;
        }

        private async Task ExecuteNamedScript(string connectionString, string scriptName, int timeout, Action<string> log)
        {
            log?.Invoke($"Ejecutando {scriptName}...");
            string script = _scriptService.ReadEmbeddedScript(scriptName);
            await _scriptService.ExecuteScriptAsync(connectionString, script, timeout, log);
        }

        private async Task ApplyRuntimeConfigAsync(string connectionString, DeploymentOptions options, int timeout, Action<string> log)
        {
            const string sql = @"
MERGE dbo.Masked_Config AS tgt
USING (VALUES
    (N'MaskingMode', @MaskingMode),
    (N'MaskForceReapply', @MaskForceReapply),
    (N'MaskDryRun', @MaskDryRun),
    (N'SkipTablesWithComputed', @SkipTablesWithComputed),
    (N'CreateSynonyms', @CreateSynonyms)
) AS src(ConfigKey, ConfigValue)
ON tgt.ConfigKey = src.ConfigKey
WHEN MATCHED THEN UPDATE SET ConfigValue = src.ConfigValue
WHEN NOT MATCHED THEN INSERT(ConfigKey, ConfigValue) VALUES(src.ConfigKey, src.ConfigValue);";

            using var connection = new SqlConnection(connectionString);
            await connection.OpenAsync();
            using var command = new SqlCommand(sql, connection) { CommandTimeout = timeout };
            command.Parameters.AddWithValue("@MaskingMode", options.MaskingMode ?? "both");
            command.Parameters.AddWithValue("@MaskForceReapply", options.ForceReapply ? "1" : "0");
            command.Parameters.AddWithValue("@MaskDryRun", options.DryRun ? "1" : "0");
            command.Parameters.AddWithValue("@SkipTablesWithComputed", options.SkipTablesWithComputed ? "1" : "0");
            command.Parameters.AddWithValue("@CreateSynonyms", options.CreateSynonyms ? "1" : "0");
            await command.ExecuteNonQueryAsync();
            log?.Invoke("Configuracion runtime actualizada.");
        }

        private async Task UpsertPrincipalPoliciesAsync(string connectionString, IEnumerable<PrincipalPolicy> policies, int timeout, Action<string> log)
        {
            var list = policies?.Where(p => !string.IsNullOrWhiteSpace(p.PrincipalName)).ToList() ?? new List<PrincipalPolicy>();
            if (list.Count == 0)
            {
                log?.Invoke("No hay principales configurados para dbo.Masked_PrincipalPolicy.");
                return;
            }

            const string sql = @"
MERGE dbo.Masked_PrincipalPolicy AS tgt
USING (SELECT @PrincipalName AS PrincipalName) AS src
ON tgt.PrincipalName = src.PrincipalName
WHEN MATCHED THEN UPDATE SET
    IsEnabled = @IsEnabled,
    ApplyDefaultSchema = @ApplyDefaultSchema,
    MirrorObjectPermissions = @MirrorObjectPermissions,
    IncludeDml = @IncludeDml,
    AddToReadRole = @AddToReadRole,
    AddToDmlRole = @AddToDmlRole,
    BlockBaseAccess = @BlockBaseAccess,
    Notes = @Notes,
    ModifiedAt = SYSUTCDATETIME()
WHEN NOT MATCHED THEN INSERT
    (PrincipalName, IsEnabled, ApplyDefaultSchema, MirrorObjectPermissions, IncludeDml, AddToReadRole, AddToDmlRole, BlockBaseAccess, Notes, ModifiedAt)
VALUES
    (@PrincipalName, @IsEnabled, @ApplyDefaultSchema, @MirrorObjectPermissions, @IncludeDml, @AddToReadRole, @AddToDmlRole, @BlockBaseAccess, @Notes, SYSUTCDATETIME());";

            using var connection = new SqlConnection(connectionString);
            await connection.OpenAsync();

            foreach (var p in list)
            {
                using var command = new SqlCommand(sql, connection) { CommandTimeout = timeout };
                command.Parameters.AddWithValue("@PrincipalName", p.PrincipalName.Trim());
                command.Parameters.AddWithValue("@IsEnabled", p.IsEnabled);
                command.Parameters.AddWithValue("@ApplyDefaultSchema", p.ApplyDefaultSchema);
                command.Parameters.AddWithValue("@MirrorObjectPermissions", p.MirrorObjectPermissions);
                command.Parameters.AddWithValue("@IncludeDml", p.IncludeDml);
                command.Parameters.AddWithValue("@AddToReadRole", p.AddToReadRole);
                command.Parameters.AddWithValue("@AddToDmlRole", p.AddToDmlRole);
                command.Parameters.AddWithValue("@BlockBaseAccess", p.BlockBaseAccess);
                command.Parameters.AddWithValue("@Notes", (object)p.Notes ?? DBNull.Value);
                await command.ExecuteNonQueryAsync();
            }

            log?.Invoke($"Politicas de principales sincronizadas: {list.Count}");
        }

        private static string PreparePolicyScript(string script, DeploymentOptions options)
        {
            return script
                .Replace("DECLARE @DryRun BIT = 1;", $"DECLARE @DryRun BIT = {Bit(options.DryRun)};")
                .Replace("DECLARE @ApplyDefaultSchemaFromPolicy BIT = 1;", $"DECLARE @ApplyDefaultSchemaFromPolicy BIT = {Bit(options.ApplyDefaultSchemaPolicy)};")
                .Replace("DECLARE @MirrorPermissions BIT = 1;", $"DECLARE @MirrorPermissions BIT = {Bit(options.MirrorObjectPermissions)};")
                .Replace("DECLARE @MirrorScope NVARCHAR(30) = N'POLICY_TABLE';", $"DECLARE @MirrorScope NVARCHAR(30) = N'{Escape(options.PermissionMirrorScope ?? "POLICY_TABLE")}';")
                .Replace("DECLARE @CopyDml BIT = 0;", $"DECLARE @CopyDml BIT = {Bit(options.CopyDmlPermissions)};")
                .Replace("DECLARE @BaseAccessAction NVARCHAR(50) = N'REPORT_ONLY';", $"DECLARE @BaseAccessAction NVARCHAR(50) = N'{Escape(options.BaseAccessAction ?? "REPORT_ONLY")}';");
        }

        private static string PrepareReprocessScript(string script, DeploymentOptions options)
        {
            return script
                .Replace("DECLARE @DryRun BIT = 1;", $"DECLARE @DryRun BIT = {Bit(options.DryRun)};")
                .Replace("DECLARE @ReprocessMode NVARCHAR(30) = N'FORCE_DDM';", $"DECLARE @ReprocessMode NVARCHAR(30) = N'{Escape(options.ReprocessMode ?? "SOFT")}';");
        }

        private static int Bit(bool value) => value ? 1 : 0;
        private static string Escape(string value) => (value ?? string.Empty).Replace("'", "''");
    }
}
