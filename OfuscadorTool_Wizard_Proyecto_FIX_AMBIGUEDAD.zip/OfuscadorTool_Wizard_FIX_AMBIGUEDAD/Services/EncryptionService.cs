using System;
using System.Security.Cryptography;
using System.Text;

namespace OfuscadorTool.Services
{
    public static class EncryptionService
    {
        public static string ProtectForCurrentUser(string plainText)
        {
            if (string.IsNullOrEmpty(plainText)) return null;
            byte[] plainBytes = Encoding.UTF8.GetBytes(plainText);
            byte[] encryptedBytes = ProtectedData.Protect(plainBytes, null, DataProtectionScope.CurrentUser);
            return Convert.ToBase64String(encryptedBytes);
        }

        public static string UnprotectForCurrentUser(string cipherText)
        {
            if (string.IsNullOrEmpty(cipherText)) return null;
            byte[] encryptedBytes = Convert.FromBase64String(cipherText);
            byte[] plainBytes = ProtectedData.Unprotect(encryptedBytes, null, DataProtectionScope.CurrentUser);
            return Encoding.UTF8.GetString(plainBytes);
        }
    }
}
