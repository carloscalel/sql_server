using OfuscadorTool.Models;
using System.ComponentModel;
using System.Linq;
using System.Windows.Forms;

namespace OfuscadorTool
{
    public class PrincipalPolicyStepControl : WizardStepBase
    {
        public override string StepTitle => "Usuarios / políticas";
        private readonly GlobalConfig _config;
        private BindingList<PrincipalPolicy> _binding;
        private readonly DataGridView _grid = new DataGridView();

        public PrincipalPolicyStepControl(GlobalConfig config)
        {
            _config = config;
            BuildUi();
            LoadGrid();
        }

        private void BuildUi()
        {
            var toolbar = new FlowLayoutPanel { Dock = DockStyle.Top, Height = 42, FlowDirection = FlowDirection.LeftToRight };
            var btnAdd = new Button { Text = "Agregar", Width = 100 };
            var btnRemove = new Button { Text = "Quitar", Width = 100 };
            btnAdd.Click += (_, __) => AddPolicy();
            btnRemove.Click += (_, __) => RemovePolicy();
            toolbar.Controls.AddRange(new Control[] { btnAdd, btnRemove });
            Controls.Add(toolbar);

            var info = new Label
            {
                Dock = DockStyle.Bottom,
                Height = 45,
                Text = "Agrega usuarios o roles que deben consultar por masked.Tabla. No agregues db_owner, sysadmin, ETL o cuentas técnicas sin validarlo.",
                Padding = new Padding(5)
            };
            Controls.Add(info);

            _grid.Dock = DockStyle.Fill;
            _grid.AutoGenerateColumns = false;
            _grid.AllowUserToAddRows = true;
            _grid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;

            _grid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "PrincipalName", DataPropertyName = "PrincipalName", Width = 180 });
            _grid.Columns.Add(new DataGridViewCheckBoxColumn { HeaderText = "Activo", DataPropertyName = "IsEnabled", Width = 60 });
            _grid.Columns.Add(new DataGridViewCheckBoxColumn { HeaderText = "DefaultSchema", DataPropertyName = "ApplyDefaultSchema", Width = 105 });
            _grid.Columns.Add(new DataGridViewCheckBoxColumn { HeaderText = "Copiar permisos", DataPropertyName = "MirrorObjectPermissions", Width = 110 });
            _grid.Columns.Add(new DataGridViewCheckBoxColumn { HeaderText = "Incluir DML", DataPropertyName = "IncludeDml", Width = 90 });
            _grid.Columns.Add(new DataGridViewCheckBoxColumn { HeaderText = "Rol lectura", DataPropertyName = "AddToReadRole", Width = 85 });
            _grid.Columns.Add(new DataGridViewCheckBoxColumn { HeaderText = "Rol DML", DataPropertyName = "AddToDmlRole", Width = 75 });
            _grid.Columns.Add(new DataGridViewCheckBoxColumn { HeaderText = "Bloquear dbo", DataPropertyName = "BlockBaseAccess", Width = 95 });
            _grid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Notas", DataPropertyName = "Notes", AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill });

            Controls.Add(_grid);
        }

        private void LoadGrid()
        {
            _binding = new BindingList<PrincipalPolicy>(_config.PrincipalPolicies);
            _grid.DataSource = _binding;
        }

        private void AddPolicy()
        {
            _config.PrincipalPolicies.Add(new PrincipalPolicy { PrincipalName = "Usuario_o_Rol" });
            LoadGrid();
        }

        private void RemovePolicy()
        {
            if (_grid.CurrentRow?.DataBoundItem is PrincipalPolicy policy)
            {
                _config.PrincipalPolicies.Remove(policy);
                LoadGrid();
            }
        }

        public override bool ValidateStep(out string message)
        {
            _grid.EndEdit();

            var duplicates = _config.PrincipalPolicies
                .Where(p => !string.IsNullOrWhiteSpace(p.PrincipalName))
                .GroupBy(p => p.PrincipalName.Trim().ToLowerInvariant())
                .Where(g => g.Count() > 1)
                .Select(g => g.Key)
                .ToList();

            if (duplicates.Any())
            {
                message = "Hay usuarios/roles duplicados en la política.";
                return false;
            }

            message = null;
            return true;
        }
    }
}
