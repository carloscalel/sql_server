using System.Windows.Forms;

namespace OfuscadorTool
{
    public class WizardStepBase : UserControl
    {
        public virtual string StepTitle => "Paso";
        public virtual void OnStepVisible() { }
        public virtual bool ValidateStep(out string message)
        {
            message = null;
            return true;
        }

        protected Label Header(string text)
        {
            return new Label
            {
                Text = text,
                Dock = DockStyle.Top,
                Height = 44,
                Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold),
                Padding = new Padding(8, 8, 8, 4)
            };
        }
    }
}
