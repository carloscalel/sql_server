using OfuscadorTool.Models;
using OfuscadorTool.Services;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace OfuscadorTool
{
    public class MainForm : Form
    {
        private readonly ConfigService _configService = new ConfigService();
        private readonly GlobalConfig _config;
        private readonly List<WizardStepBase> _steps = new List<WizardStepBase>();
        private readonly Panel _leftPanel = new Panel();
        private readonly Panel _contentPanel = new Panel();
        private readonly Label _title = new Label();
        private readonly Button _btnBack = new Button();
        private readonly Button _btnNext = new Button();
        private readonly Button _btnCancel = new Button();
        private int _currentStep = 0;

        public MainForm()
        {
            _config = _configService.Load();
            InitializeLayout();
            BuildSteps();
            ShowStep(0);
        }

        private void InitializeLayout()
        {
            Text = "OfuscadorTool - Wizard de Enmascaramiento SQL Server";
            StartPosition = FormStartPosition.CenterScreen;
            Width = 1100;
            Height = 720;
            MinimumSize = new Size(980, 620);

            _leftPanel.Dock = DockStyle.Left;
            _leftPanel.Width = 230;
            _leftPanel.Padding = new Padding(10);
            _leftPanel.BackColor = Color.FromArgb(245, 245, 245);
            Controls.Add(_leftPanel);

            var bottomPanel = new Panel { Dock = DockStyle.Bottom, Height = 58, Padding = new Padding(10) };
            Controls.Add(bottomPanel);

            _btnCancel.Text = "Cancelar";
            _btnCancel.Width = 110;
            _btnCancel.Dock = DockStyle.Right;
            _btnCancel.Click += (_, __) => Close();
            bottomPanel.Controls.Add(_btnCancel);

            _btnNext.Text = "Siguiente";
            _btnNext.Width = 120;
            _btnNext.Dock = DockStyle.Right;
            _btnNext.Margin = new Padding(6);
            _btnNext.Click += BtnNext_Click;
            bottomPanel.Controls.Add(_btnNext);

            _btnBack.Text = "Atrás";
            _btnBack.Width = 110;
            _btnBack.Dock = DockStyle.Right;
            _btnBack.Click += (_, __) => { if (_currentStep > 0) ShowStep(_currentStep - 1); };
            bottomPanel.Controls.Add(_btnBack);

            _title.Dock = DockStyle.Top;
            _title.Height = 54;
            _title.Font = new Font("Segoe UI", 16F, FontStyle.Bold);
            _title.Padding = new Padding(15, 12, 15, 5);
            Controls.Add(_title);

            _contentPanel.Dock = DockStyle.Fill;
            _contentPanel.Padding = new Padding(12);
            Controls.Add(_contentPanel);
        }

        private void BuildSteps()
        {
            _steps.Add(new WelcomeStepControl());
            _steps.Add(new ServerStepControl(_config));
            _steps.Add(new DatabaseStepControl(_config));
            _steps.Add(new OptionsStepControl(_config));
            _steps.Add(new PrincipalPolicyStepControl(_config));
            _steps.Add(new ReviewStepControl(_config));
            _steps.Add(new ExecuteStepControl(_config));
        }

        private void RefreshStepList()
        {
            _leftPanel.Controls.Clear();

            for (int i = _steps.Count - 1; i >= 0; i--)
            {
                var lbl = new Label
                {
                    Text = $"{i + 1}. {_steps[i].StepTitle}",
                    Height = 34,
                    Dock = DockStyle.Top,
                    Padding = new Padding(8, 8, 8, 4),
                    Font = new Font("Segoe UI", 9F, i == _currentStep ? FontStyle.Bold : FontStyle.Regular),
                    ForeColor = i == _currentStep ? Color.FromArgb(20, 80, 150) : Color.Black
                };
                _leftPanel.Controls.Add(lbl);
            }
        }

        private void ShowStep(int index)
        {
            _configService.Save(_config);
            _currentStep = index;
            _contentPanel.Controls.Clear();

            var step = _steps[index];
            step.Dock = DockStyle.Fill;
            step.OnStepVisible();

            _title.Text = step.StepTitle;
            _contentPanel.Controls.Add(step);

            _btnBack.Enabled = index > 0;
            _btnNext.Text = index == _steps.Count - 1 ? "Finalizar" : index == _steps.Count - 2 ? "Ejecutar" : "Siguiente";
            RefreshStepList();
        }

        private void BtnNext_Click(object sender, EventArgs e)
        {
            var step = _steps[_currentStep];
            if (!step.ValidateStep(out string message))
            {
                MessageBox.Show(message, "Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            _configService.Save(_config);

            if (_currentStep < _steps.Count - 1)
                ShowStep(_currentStep + 1);
            else
                Close();
        }
    }
}
