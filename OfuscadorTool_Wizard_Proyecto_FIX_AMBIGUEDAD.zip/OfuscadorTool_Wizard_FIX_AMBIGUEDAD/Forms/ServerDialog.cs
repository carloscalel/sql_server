using OfuscadorTool.Models;
using System;
using System.Drawing;
using System.Windows.Forms;

namespace OfuscadorTool
{
    public class ServerDialog : Form
    {
        private readonly ServerConnection _server;
        private readonly TextBox _txtName = new TextBox();
        private readonly TextBox _txtHost = new TextBox();
        private readonly TextBox _txtInstance = new TextBox();
        private readonly CheckBox _chkWindows = new CheckBox();
        private readonly TextBox _txtUser = new TextBox();
        private readonly TextBox _txtPassword = new TextBox();
        private readonly CheckBox _chkEncrypt = new CheckBox();
        private readonly CheckBox _chkTrust = new CheckBox();
        private readonly NumericUpDown _numTimeout = new NumericUpDown();
        private readonly CheckBox _chkEnabled = new CheckBox();

        public ServerDialog(ServerConnection server)
        {
            _server = server;
            InitializeLayout();
            LoadValues();
        }

        private void InitializeLayout()
        {
            Text = "Servidor SQL Server";
            StartPosition = FormStartPosition.CenterParent;
            Width = 520;
            Height = 440;
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false;
            MinimizeBox = false;

            var panel = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                ColumnCount = 2,
                RowCount = 0,
                Padding = new Padding(12),
                AutoSize = true
            };
            panel.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 160));
            panel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
            Controls.Add(panel);

            AddRow(panel, "Nombre amigable", _txtName);
            AddRow(panel, "Host/IP", _txtHost);
            AddRow(panel, "Instancia", _txtInstance);

            _chkWindows.Text = "Usar autenticación Windows";
            _chkWindows.CheckedChanged += (_, __) => ToggleSqlAuth();
            AddRow(panel, "Autenticación", _chkWindows);

            AddRow(panel, "Usuario SQL", _txtUser);
            _txtPassword.UseSystemPasswordChar = true;
            AddRow(panel, "Contraseña SQL", _txtPassword);

            _chkEncrypt.Text = "Encrypt connection";
            AddRow(panel, "Cifrado", _chkEncrypt);

            _chkTrust.Text = "Trust server certificate";
            AddRow(panel, "Certificado", _chkTrust);

            _numTimeout.Minimum = 5;
            _numTimeout.Maximum = 600;
            AddRow(panel, "Timeout", _numTimeout);

            _chkEnabled.Text = "Servidor habilitado";
            AddRow(panel, "Estado", _chkEnabled);

            var buttons = new FlowLayoutPanel { Dock = DockStyle.Bottom, Height = 52, FlowDirection = FlowDirection.RightToLeft, Padding = new Padding(10) };
            var btnOk = new Button { Text = "Guardar", DialogResult = DialogResult.OK, Width = 100 };
            var btnCancel = new Button { Text = "Cancelar", DialogResult = DialogResult.Cancel, Width = 100 };
            btnOk.Click += BtnOk_Click;
            buttons.Controls.Add(btnOk);
            buttons.Controls.Add(btnCancel);
            Controls.Add(buttons);

            AcceptButton = btnOk;
            CancelButton = btnCancel;
        }

        private static void AddRow(TableLayoutPanel panel, string label, Control control)
        {
            int row = panel.RowCount++;
            panel.RowStyles.Add(new RowStyle(SizeType.Absolute, 34));
            panel.Controls.Add(new Label { Text = label, TextAlign = ContentAlignment.MiddleLeft, Dock = DockStyle.Fill }, 0, row);
            control.Dock = DockStyle.Fill;
            panel.Controls.Add(control, 1, row);
        }

        private void LoadValues()
        {
            _txtName.Text = _server.Name;
            _txtHost.Text = _server.Host;
            _txtInstance.Text = _server.InstanceName;
            _chkWindows.Checked = _server.UseWindowsAuth;
            _txtUser.Text = _server.Username;
            _txtPassword.Text = string.Empty;
            _chkEncrypt.Checked = _server.EncryptConnection;
            _chkTrust.Checked = _server.TrustServerCertificate;
            _numTimeout.Value = Math.Max(5, Math.Min(600, _server.ConnectTimeout <= 0 ? 30 : _server.ConnectTimeout));
            _chkEnabled.Checked = _server.IsEnabled;
            ToggleSqlAuth();
        }

        private void ToggleSqlAuth()
        {
            bool sqlAuth = !_chkWindows.Checked;
            _txtUser.Enabled = sqlAuth;
            _txtPassword.Enabled = sqlAuth;
        }

        private void BtnOk_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(_txtHost.Text))
            {
                MessageBox.Show("El host es obligatorio.", "Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                DialogResult = DialogResult.None;
                return;
            }

            if (!_chkWindows.Checked && string.IsNullOrWhiteSpace(_txtUser.Text))
            {
                MessageBox.Show("El usuario SQL es obligatorio cuando no usas autenticación Windows.", "Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                DialogResult = DialogResult.None;
                return;
            }

            _server.Name = string.IsNullOrWhiteSpace(_txtName.Text) ? _txtHost.Text.Trim() : _txtName.Text.Trim();
            _server.Host = _txtHost.Text.Trim();
            _server.InstanceName = string.IsNullOrWhiteSpace(_txtInstance.Text) ? null : _txtInstance.Text.Trim();
            _server.UseWindowsAuth = _chkWindows.Checked;
            _server.Username = _txtUser.Text.Trim();
            if (!string.IsNullOrEmpty(_txtPassword.Text))
                _server.Password = _txtPassword.Text;
            _server.EncryptConnection = _chkEncrypt.Checked;
            _server.TrustServerCertificate = _chkTrust.Checked;
            _server.ConnectTimeout = (int)_numTimeout.Value;
            _server.IsEnabled = _chkEnabled.Checked;
            _server.LastModified = DateTime.Now;
        }
    }
}
