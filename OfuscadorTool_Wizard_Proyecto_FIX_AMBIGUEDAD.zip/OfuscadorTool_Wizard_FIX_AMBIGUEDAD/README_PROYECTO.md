# OfuscadorTool Wizard

Proyecto base Windows Forms para probar el sistema de enmascaramiento/ofuscamiento en SQL Server.

## Requisitos

- Visual Studio 2022/2026 con carga de trabajo **.NET desktop development**.
- .NET 8 SDK o superior.
- Acceso a una instancia SQL Server de prueba.
- Usuario con permisos suficientes para crear esquemas, vistas, procedimientos y aplicar DDM.

## Cómo probar

1. Abrir `OfuscadorTool.csproj` en Visual Studio.
2. Restaurar paquetes NuGet.
3. Compilar el proyecto.
4. Ejecutar.
5. Agregar servidor SQL Server.
6. Cargar bases de datos.
7. Seleccionar una base de pruebas.
8. Mantener `DryRun = true` en la primera ejecución.
9. Ejecutar.
10. Revisar el log y `dbo.Masked_Audit`.

## Orden interno de ejecución

El wizard ejecuta:

1. `setup.sql`
2. Sincroniza `dbo.Masked_Config`
3. Sincroniza `dbo.Masked_PrincipalPolicy`
4. `sp_ManageColumnRule.sql`
5. `sp_CreateViewWithDml.sql`
6. Opcional: `06_reprocess_all_CONTROLADO.sql`
7. Opcional: `apply_ddm.sql`
8. Opcional: `02_deploy_all.sql`
9. Opcional: `04_policy_by_table_SAFE.sql`

## Recomendación de seguridad

Primera prueba:

- `DryRun = true`
- `BaseAccessAction = REPORT_ONLY`
- `ApplySafePolicy = false`

Segunda prueba:

- `DryRun = false`
- `BaseAccessAction = REPORT_ONLY`
- `ApplySafePolicy = true` solo si agregaste usuarios/roles en la política.

No uses `DENY_BASE_FOR_POLICY_PRINCIPALS` hasta validar permisos y resultados.
