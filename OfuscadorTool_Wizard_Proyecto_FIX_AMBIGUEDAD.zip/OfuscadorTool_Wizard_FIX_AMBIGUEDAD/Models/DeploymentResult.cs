using System;
using System.Collections.Generic;

namespace OfuscadorTool.Models
{
    public class DeploymentResult
    {
        public string ServerName { get; set; }
        public string DatabaseName { get; set; }
        public bool Success { get; set; }
        public string ErrorMessage { get; set; }
        public DateTime StartTime { get; set; }
        public DateTime EndTime { get; set; }
        public List<string> AppliedChanges { get; set; } = new List<string>();
    }
}
