# OfuscadorTool

Aplicación WPF (.NET 8) para administrar y ejecutar los scripts de ofuscamiento sobre varias instancias y bases SQL Server.

## Instalación administrativa

La aplicación no crea bases, esquemas, tablas, índices, roles ni usuarios administrativos. Un DBA debe ejecutar manualmente [00_instalacion_adminDB.sql](C:/Users/josep/source/repos/SQL_Masking__Fix/Suministros_Produccion/00_instalacion_adminDB.sql) en la base pivote y registrar el primer usuario autorizado. El login solo valida la instalación y la lista blanca.

## Funciones

- Login contra servidor pivote y lista blanca.
- Servidores con contraseña SQL cifrada mediante DPAPI.
- Patrones editables y exclusiones por usuario.
- Simulación sin cambios y despliegue concurrente.
- Auditoría, logs, respaldo de permisos y rollback.
- Inventario en vivo del estado de ofuscamiento por servidor, base, tabla y columna.
- Exportación del inventario filtrado a Excel (`.xlsx`), PDF y CSV.

## Acceso por rol

- `Administrator`: acceso total, incluido el inventario y sus exportaciones.
- `Auditor`: consulta de inventario, servidores, reglas, excepciones y auditoría; no modifica configuración.
- `Operator`: ejecuta ofuscamiento y rollback; no accede al inventario de control.

## Ejecución

```powershell
dotnet restore .\OfuscadorTool\OfuscadorTool.csproj
dotnet run --project .\OfuscadorTool\OfuscadorTool.csproj
```

La cuenta utilizada debe estar registrada en `ofuscador.AuthorizedUsers` y pertenecer al rol de base de datos que el DBA haya definido.
