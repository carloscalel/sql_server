# Suministros de produccion de OfuscadorTool

Estos scripts son ejecutados manualmente por un DBA. La aplicacion no crea ni actualiza los objetos administrativos de `adminDB`.

## Instalacion nueva

1. Cree o respalde la base pivote `adminDB`.
2. Edite el primer administrador en `00_instalacion_adminDB.sql` y ejecutelo.
3. Edite el secreto de la Database Master Key y ejecute `07_cifrado_credenciales.sql`.
4. Ejecute `02_permisos_roles.sql`.
5. Asigne cada usuario de base al rol SQL correspondiente y registre el mismo rol logico en `ofuscador.AuthorizedUsers`:
   - `Administrator` / `OfuscadorTool_Administrator`
   - `Operator` / `OfuscadorTool_Operator`
   - `Auditor` / `OfuscadorTool_Auditor`
6. Para administradores que cargaran logins desde la interfaz, edite y ejecute `04_permisos_servidor_pivote.sql`.
7. Ejecute `03_verificacion_instalacion.sql` y corrija cualquier resultado `FALTA`.

## Actualizacion de una instalacion existente

1. Respalde `adminDB`.
2. Ejecute `01_actualizacion_adminDB.sql`.
3. Ejecute `06_catalogo_patrones_base.sql` para completar reglas base faltantes sin sobrescribir personalizaciones.
4. Edite el secreto y ejecute `07_cifrado_credenciales.sql`.
5. Ejecute nuevamente `02_permisos_roles.sql`.
6. Ejecute `03_verificacion_instalacion.sql`.

La actualizacion no elimina configuracion, servidores, patrones, perfiles, auditoria ni historiales.
El script de permisos retira el acceso amplio del rol heredado `OfuscadorTool_AppRole`; el DBA debe migrar sus miembros a uno de los tres roles actuales.
Los roles reciben `VIEW DEFINITION` exclusivamente sobre el esquema `ofuscador`. Este permiso permite que la validacion inicial distinga objetos existentes sin otorgar `db_owner` ni acceso administrativo a la base.

## Servidores objetivo

Edite y ejecute `05_credencial_servidores_objetivo.sql` en cada servidor registrado. Declare solo las bases que administrara OfuscadorTool. La credencial necesita `db_owner` en esas bases porque el proceso administra DDM, vistas, triggers, sinonimos, esquemas, roles y permisos. No debe ser `sysadmin`.

Las contrasenas se cifran centralmente en `adminDB` con AES-256, una clave simetrica y un certificado administrados por SQL Server. El valor almacenado en `ofuscador.Servers` usa el prefijo `SQL1:` y no depende del usuario Windows ni del equipo cliente. Los tres roles autorizados pueden solicitar el descifrado mediante un procedimiento con `EXECUTE AS OWNER`, porque Operador ejecuta procesos y Auditor consulta el inventario remoto; solo Administrador puede cifrar, registrar o reemplazar credenciales. La conexion al servidor pivote debe usar `Encrypt=True` y un certificado confiable para proteger la contrasena durante el transporte.

El DBA debe incluir la Database Master Key y el certificado `OfuscadorTool_CredentialCertificate` en el procedimiento de respaldo y recuperacion de `adminDB`. Sin estas claves, las credenciales cifradas no se pueden recuperar despues de una restauracion en otra instancia. El secreto usado para crear la Database Master Key debe custodiarse fuera del repositorio.

Las credenciales DPAPI de versiones anteriores se migran al guardar nuevamente el servidor si se ejecuta desde el usuario/equipo capaz de descifrarlas. En cualquier otro caso, un administrador debe editar el registro e ingresar otra vez la contrasena. Despues de migrar, el valor comienza con `SQL1:` y puede utilizarse desde diferentes equipos autorizados.

## Catalogos centrales

- `ofuscador.AuthorizedUsers`: lista blanca y rol logico.
- `ofuscador.Servers`: conexiones registradas y credenciales cifradas.
- `ofuscador.MaskPatterns`: reglas centrales DDM y expresiones para vistas.
- `ofuscador.MaskExceptions`: columnas omitidas y tablas que requieren vista.
- `ofuscador.MaskProfiles`, `MaskProfileColumns`, `MaskProfileUsers`: perfiles especiales.
- `ofuscador.Executions`, `ExecutionTargets`, `PermissionBackup`: despliegues y rollback.
- `ofuscador.Audit`: auditoria funcional del aplicativo.

Las reglas activas se sincronizan durante cada despliegue hacia `dbo.Masked_Patterns` de la base objetivo. Las excepciones se sincronizan hacia `dbo.Masked_Exceptions`.

## Esquemas procesados y excluidos

El ofuscamiento procesa tablas de todos los esquemas funcionales. Siempre se excluyen `sys`, `INFORMATION_SCHEMA`, `ofuscador`, `masked`, `app`, `log`, `logs`, `audit`, `auditoria`, y los objetos internos `Masked_Audit`, `Masked_Patterns` y `Masked_Exceptions`.

Cuando una excepcion exige una vista, `dbo.Tabla` genera `masked.Tabla`; una tabla de otro esquema, por ejemplo `Ventas.Clientes`, genera `masked.Ventas__Clientes`. Esto evita colisiones entre tablas con el mismo nombre.

## Laboratorio

`10_base_ejemplo_ofuscamiento.sql` crea `OfuscadorDemo` con tablas en `dbo` y `Ventas`, columnas calculadas y datos ficticios. Consulte `README_LABORATORIO.md`. No ejecute este archivo en produccion.

`adminDB.sql` es una captura historica y no forma parte de la secuencia de instalacion actual.
