# Laboratorio multi-esquema

Ejecute `10_base_ejemplo_ofuscamiento.sql` como DBA en un servidor de pruebas. Crea `OfuscadorDemo` con:

- `dbo.Clientes`, `dbo.Empleados` y `dbo.Pedidos`.
- `Ventas.ClienteCompleto`, para validar tablas fuera de `dbo`.
- Columnas calculadas `dbo.Pedidos.ImporteTotal` y `Ventas.ClienteCompleto.NombreCompleto`.
- Datos completamente ficticios.

Luego registre el servidor, seleccione `OfuscadorDemo`, cargue usuarios y ejecute primero en modo simulacion. Las reglas se toman del catalogo central `adminDB.ofuscador.MaskPatterns`; el laboratorio no crea reglas locales.

Para probar excepciones:

- Registre `dbo.Pedidos.ImporteTotal` como `NO_OFUSCAR_COLUMNA`.
- Registre una tabla como `CREAR_VISTA_TABLA` y confirme la vista en `masked`.
- Compruebe que `Ventas.ClienteCompleto` recibe DDM o una vista `masked.Ventas__ClienteCompleto`, segun la decision configurada.

Revise el inventario, `dbo.Masked_Audit` y finalmente ejecute rollback.
