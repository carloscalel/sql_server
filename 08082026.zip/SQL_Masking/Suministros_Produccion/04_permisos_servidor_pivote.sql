/*
  Visibilidad de logins para administradores de OfuscadorTool.
  Ejecutar en el servidor pivote como sysadmin y reemplazar el login.
*/
USE [master];
GO
DECLARE @Login sysname=N'DOMINIO\administrador_ofuscador';
IF SUSER_ID(@Login) IS NULL
    THROW 50001,N'El login indicado no existe en el servidor pivote.',1;

DECLARE @sql nvarchar(max)=N'GRANT VIEW ANY DEFINITION TO '+QUOTENAME(@Login)+N';';
EXEC sys.sp_executesql @sql;
PRINT N'Permiso VIEW ANY DEFINITION concedido.';
GO
