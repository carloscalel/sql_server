/* OfuscadorTool - comprobacion de instalacion. Solo lectura. */
USE [adminDB];
GO
SET NOCOUNT ON;

DECLARE @Required TABLE(ObjectName sysname NOT NULL,ObjectType char(2) NOT NULL);
INSERT @Required VALUES
(N'ofuscador.Servers',N'U'),(N'ofuscador.AuthorizedUsers',N'U'),
(N'ofuscador.MaskPatterns',N'U'),(N'ofuscador.MaskExceptions',N'U'),
(N'ofuscador.Executions',N'U'),(N'ofuscador.ExecutionTargets',N'U'),
(N'ofuscador.PermissionBackup',N'U'),(N'ofuscador.Audit',N'U'),
(N'ofuscador.MaskProfiles',N'U'),(N'ofuscador.MaskProfileColumns',N'U'),
(N'ofuscador.MaskProfileUsers',N'U'),
(N'ofuscador.EncryptServerCredential',N'P'),
(N'ofuscador.DecryptServerCredential',N'P');

SELECT ObjectName,
       CASE WHEN OBJECT_ID(ObjectName,ObjectType) IS NULL THEN N'FALTA' ELSE N'OK' END Estado
FROM @Required ORDER BY ObjectName;

SELECT N'Columnas requeridas' Comprobacion,
       CASE WHEN COL_LENGTH(N'ofuscador.Servers',N'TimeoutSeconds') IS NOT NULL
                  AND COL_LENGTH(N'ofuscador.MaskPatterns',N'ViewMaskExpr') IS NOT NULL
                  AND COL_LENGTH(N'ofuscador.MaskPatterns',N'Priority') IS NOT NULL
                  AND COL_LENGTH(N'ofuscador.MaskPatterns',N'IsActive') IS NOT NULL
                  AND COL_LENGTH(N'ofuscador.AuthorizedUsers',N'AppRole') IS NOT NULL
            THEN N'OK' ELSE N'FALTA ALGUNA COLUMNA' END Estado;

SELECT N'Administrador activo' Comprobacion,
       CASE WHEN EXISTS(SELECT 1 FROM ofuscador.AuthorizedUsers WHERE IsActive=1 AND AppRole=N'Administrator')
            THEN N'OK' ELSE N'FALTA ADMINISTRADOR ACTIVO' END Estado;

SELECT N'Patrones activos' Comprobacion,CONVERT(nvarchar(20),COUNT(*)) Estado
FROM ofuscador.MaskPatterns WHERE IsActive=1;

SELECT N'Database Master Key' Comprobacion,
       CASE WHEN EXISTS(SELECT 1 FROM sys.symmetric_keys WHERE name=N'##MS_DatabaseMasterKey##')
            THEN N'OK' ELSE N'FALTA' END Estado
UNION ALL
SELECT N'Certificado de credenciales',
       CASE WHEN EXISTS(SELECT 1 FROM sys.certificates WHERE name=N'OfuscadorTool_CredentialCertificate')
            THEN N'OK' ELSE N'FALTA' END
UNION ALL
SELECT N'Clave AES-256 de credenciales',
       CASE WHEN EXISTS(SELECT 1 FROM sys.symmetric_keys WHERE name=N'OfuscadorTool_CredentialKey')
            THEN N'OK' ELSE N'FALTA' END;

SELECT ServerId,Name,UseWindowsAuth,
       CASE WHEN UseWindowsAuth=1 THEN N'NO APLICA'
            WHEN EncryptedPassword LIKE N'SQL1:%' THEN N'CIFRADO CENTRAL'
            WHEN NULLIF(EncryptedPassword,N'') IS NULL THEN N'FALTA CREDENCIAL'
            ELSE N'REQUIERE MIGRACION DPAPI' END EstadoCredencial
FROM ofuscador.Servers
ORDER BY Name;

SELECT p.name Principal,r.name RolSql
FROM sys.database_role_members drm
JOIN sys.database_principals r ON r.principal_id=drm.role_principal_id
JOIN sys.database_principals p ON p.principal_id=drm.member_principal_id
WHERE r.name IN(N'OfuscadorTool_Administrator',N'OfuscadorTool_Operator',N'OfuscadorTool_Auditor')
ORDER BY r.name,p.name;

SELECT r.name RolSql,
       CASE WHEN EXISTS
       (
           SELECT 1
           FROM sys.database_permissions dp
           WHERE dp.grantee_principal_id=r.principal_id
             AND dp.class_desc=N'SCHEMA'
             AND dp.major_id=SCHEMA_ID(N'ofuscador')
             AND dp.permission_name=N'VIEW DEFINITION'
             AND dp.state IN(N'G',N'W')
       ) THEN N'OK' ELSE N'FALTA VIEW DEFINITION' END ValidacionMetadatos
FROM sys.database_principals r
WHERE r.name IN(N'OfuscadorTool_Administrator',N'OfuscadorTool_Operator',N'OfuscadorTool_Auditor')
ORDER BY r.name;

SELECT au.Principal,au.AppRole,
       CASE au.AppRole WHEN N'Administrator' THEN N'OfuscadorTool_Administrator'
                       WHEN N'Operator' THEN N'OfuscadorTool_Operator'
                       WHEN N'Auditor' THEN N'OfuscadorTool_Auditor' END RolSqlEsperado,
       CASE WHEN EXISTS
       (
           SELECT 1 FROM sys.database_role_members drm
           JOIN sys.database_principals r ON r.principal_id=drm.role_principal_id
           JOIN sys.database_principals p ON p.principal_id=drm.member_principal_id
           WHERE p.name=au.Principal
             AND r.name=CASE au.AppRole WHEN N'Administrator' THEN N'OfuscadorTool_Administrator'
                                        WHEN N'Operator' THEN N'OfuscadorTool_Operator'
                                        WHEN N'Auditor' THEN N'OfuscadorTool_Auditor' END
       ) THEN N'OK' ELSE N'FALTA MEMBRESIA SQL' END Estado
FROM ofuscador.AuthorizedUsers au
WHERE au.IsActive=1
ORDER BY au.Principal;

IF EXISTS(SELECT 1 FROM @Required WHERE OBJECT_ID(ObjectName,ObjectType) IS NULL)
    THROW 50002,N'La instalacion esta incompleta. Revise el primer resultado.',1;

PRINT N'Verificacion finalizada.';
GO
