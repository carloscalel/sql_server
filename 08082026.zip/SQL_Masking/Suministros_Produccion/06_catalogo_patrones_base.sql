/*
  Catalogo base recomendado. Idempotente: agrega reglas faltantes y completa
  solamente expresiones de vista vacias; no reemplaza personalizaciones existentes.
*/
USE [adminDB];
GO
SET NOCOUNT ON;
IF OBJECT_ID(N'ofuscador.MaskPatterns',N'U') IS NULL
    THROW 50001,N'No existe ofuscador.MaskPatterns.',1;
GO

MERGE ofuscador.MaskPatterns AS T
USING (VALUES
 (N'%TARJETA%',N'partial(0,"XXXXXXXXXXXXXXX",4)',N'CASE WHEN {col} IS NULL THEN NULL ELSE REPLICATE(''X'',CASE WHEN LEN({col})>4 THEN LEN({col})-4 ELSE 0 END)+RIGHT({col},CASE WHEN LEN({col})>4 THEN 4 ELSE LEN({col}) END) END',100,CONVERT(bit,1)),
 (N'%CUENTA%',N'partial(0,"XXXXXXXXXXXX",4)',N'CASE WHEN {col} IS NULL THEN NULL ELSE REPLICATE(''X'',CASE WHEN LEN({col})>4 THEN LEN({col})-4 ELSE 0 END)+RIGHT({col},CASE WHEN LEN({col})>4 THEN 4 ELSE LEN({col}) END) END',100,CONVERT(bit,1)),
 (N'%EMAIL%',N'email()',N'CASE WHEN {col} IS NULL THEN NULL ELSE CASE WHEN CHARINDEX(''@'',{col})>1 THEN LEFT({col},1)+REPLICATE(''X'',CHARINDEX(''@'',{col})-2)+SUBSTRING({col},CHARINDEX(''@'',{col}),LEN({col})) ELSE REPLICATE(''X'',LEN({col})) END END',200,CONVERT(bit,1)),
 (N'%NIT%',N'default()',N'CASE WHEN {col} IS NULL THEN NULL ELSE REPLICATE(''X'',LEN({col})) END',200,CONVERT(bit,1)),
 (N'%DIRECCION%',N'default()',N'CASE WHEN {col} IS NULL THEN NULL ELSE REPLICATE(''X'',LEN({col})) END',200,CONVERT(bit,1)),
 (N'%TEL%',N'default()',N'CASE WHEN {col} IS NULL THEN NULL ELSE REPLICATE(''X'',LEN({col})) END',200,CONVERT(bit,1)),
 (N'%TELEFONO%',N'default()',N'CASE WHEN {col} IS NULL THEN NULL ELSE REPLICATE(''X'',LEN({col})) END',200,CONVERT(bit,1)),
 (N'%TOKEN%',N'partial(0,"****************",4)',N'CASE WHEN {col} IS NULL THEN NULL ELSE REPLICATE(''*'',CASE WHEN LEN({col})>4 THEN LEN({col})-4 ELSE 0 END)+RIGHT({col},CASE WHEN LEN({col})>4 THEN 4 ELSE LEN({col}) END) END',100,CONVERT(bit,1)),
 (N'%NOMBRE%',N'partial(1,"XXXXXXXXXX",0)',N'CASE WHEN {col} IS NULL THEN NULL ELSE LEFT({col},1)+REPLICATE(''X'',CASE WHEN LEN({col})>1 THEN LEN({col})-1 ELSE 0 END) END',300,CONVERT(bit,1))
) S(Pattern,DdmFunction,ViewMaskExpr,Priority,IsActive)
ON T.Pattern=S.Pattern
WHEN MATCHED THEN UPDATE SET
 ViewMaskExpr=COALESCE(NULLIF(T.ViewMaskExpr,N''),S.ViewMaskExpr)
WHEN NOT MATCHED THEN INSERT(Pattern,DdmFunction,ViewMaskExpr,Priority,IsActive)
 VALUES(S.Pattern,S.DdmFunction,S.ViewMaskExpr,S.Priority,S.IsActive);
GO
PRINT N'Catalogo base verificado. Las personalizaciones existentes se conservaron.';
GO
