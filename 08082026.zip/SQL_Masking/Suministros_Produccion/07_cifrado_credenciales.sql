/*
  OfuscadorTool - cifrado central de credenciales de servidores destino.

  Ejecutar manualmente por un DBA en adminDB.
  Antes de ejecutar, reemplace el valor de @MasterKeyPassword por una contraseña
  fuerte, única y custodiada en el gestor de secretos de la organización.

  La contraseña solo se usa para crear la Database Master Key cuando adminDB
  todavía no tiene una. SQL Server protege después esa clave con la Service
  Master Key de la instancia. No debe copiarse al código ni a la aplicación.
*/
USE [adminDB];
GO
SET NOCOUNT ON;
SET XACT_ABORT ON;

IF SCHEMA_ID(N'ofuscador') IS NULL
    THROW 50001,N'No existe el esquema ofuscador. Ejecute primero 00_instalacion_adminDB.sql.',1;
GO

DECLARE @MasterKeyPassword nvarchar(256)=N'REEMPLAZAR_POR_SECRETO_FUERTE';

IF NOT EXISTS(SELECT 1 FROM sys.symmetric_keys WHERE name=N'##MS_DatabaseMasterKey##')
BEGIN
    IF @MasterKeyPassword=N'REEMPLAZAR_POR_SECRETO_FUERTE'
        THROW 50020,N'Reemplace @MasterKeyPassword por un secreto fuerte antes de ejecutar el script.',1;

    DECLARE @CreateMasterKey nvarchar(max)=
        N'CREATE MASTER KEY ENCRYPTION BY PASSWORD=N'''+REPLACE(@MasterKeyPassword,N'''',N'''''')+N''';';
    EXEC sys.sp_executesql @CreateMasterKey;
END;
GO

IF NOT EXISTS(SELECT 1 FROM sys.certificates WHERE name=N'OfuscadorTool_CredentialCertificate')
BEGIN
    CREATE CERTIFICATE [OfuscadorTool_CredentialCertificate]
      AUTHORIZATION dbo
      WITH SUBJECT=N'OfuscadorTool - cifrado de credenciales de servidores destino',
           EXPIRY_DATE='20991231';
END;
GO

IF NOT EXISTS(SELECT 1 FROM sys.symmetric_keys WHERE name=N'OfuscadorTool_CredentialKey')
BEGIN
    CREATE SYMMETRIC KEY [OfuscadorTool_CredentialKey]
      AUTHORIZATION dbo
      WITH ALGORITHM=AES_256
      ENCRYPTION BY CERTIFICATE [OfuscadorTool_CredentialCertificate];
END;
GO

CREATE OR ALTER PROCEDURE ofuscador.EncryptServerCredential
    @PlainText nvarchar(4000)
WITH EXECUTE AS OWNER
AS
BEGIN
    SET NOCOUNT ON;
    IF @PlainText IS NULL OR @PlainText=N''
        THROW 50021,N'La contraseña no puede estar vacía.',1;

    OPEN SYMMETRIC KEY [OfuscadorTool_CredentialKey]
      DECRYPTION BY CERTIFICATE [OfuscadorTool_CredentialCertificate];

    DECLARE @Cipher varbinary(max)=EncryptByKey(
        Key_GUID(N'OfuscadorTool_CredentialKey'),CONVERT(varbinary(max),@PlainText));

    CLOSE SYMMETRIC KEY [OfuscadorTool_CredentialKey];

    IF @Cipher IS NULL
        THROW 50022,N'No fue posible cifrar la credencial.',1;

    SELECT N'SQL1:'+CONVERT(nvarchar(max),@Cipher,2) AS EncryptedValue;
END;
GO

CREATE OR ALTER PROCEDURE ofuscador.DecryptServerCredential
    @EncryptedValue nvarchar(max)
WITH EXECUTE AS OWNER
AS
BEGIN
    SET NOCOUNT ON;
    IF @EncryptedValue IS NULL OR LEFT(@EncryptedValue,5)<>N'SQL1:'
        THROW 50023,N'Formato de credencial central no válido.',1;

    DECLARE @Cipher varbinary(max);
    BEGIN TRY
        SET @Cipher=CONVERT(varbinary(max),SUBSTRING(@EncryptedValue,6,LEN(@EncryptedValue)),2);
    END TRY
    BEGIN CATCH
        THROW 50024,N'La credencial cifrada está dañada o tiene un formato no válido.',1;
    END CATCH;

    OPEN SYMMETRIC KEY [OfuscadorTool_CredentialKey]
      DECRYPTION BY CERTIFICATE [OfuscadorTool_CredentialCertificate];

    DECLARE @PlainText nvarchar(4000)=CONVERT(nvarchar(4000),DecryptByKey(@Cipher));

    CLOSE SYMMETRIC KEY [OfuscadorTool_CredentialKey];

    IF @PlainText IS NULL
        THROW 50025,N'No fue posible descifrar la credencial.',1;

    SELECT @PlainText AS PlainText;
END;
GO

IF DATABASE_PRINCIPAL_ID(N'OfuscadorTool_Administrator') IS NOT NULL
BEGIN
    GRANT EXECUTE ON OBJECT::ofuscador.EncryptServerCredential TO [OfuscadorTool_Administrator];
    GRANT EXECUTE ON OBJECT::ofuscador.DecryptServerCredential TO [OfuscadorTool_Administrator];
END;

IF DATABASE_PRINCIPAL_ID(N'OfuscadorTool_Operator') IS NOT NULL
    GRANT EXECUTE ON OBJECT::ofuscador.DecryptServerCredential TO [OfuscadorTool_Operator];

IF DATABASE_PRINCIPAL_ID(N'OfuscadorTool_Auditor') IS NOT NULL
BEGIN
    REVOKE EXECUTE ON OBJECT::ofuscador.DecryptServerCredential FROM [OfuscadorTool_Auditor];
    GRANT EXECUTE ON OBJECT::ofuscador.DecryptServerCredential TO [OfuscadorTool_Auditor];
END;
GO

PRINT N'Cifrado central de credenciales configurado correctamente.';
GO
