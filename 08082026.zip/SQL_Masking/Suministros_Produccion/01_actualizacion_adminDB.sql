/*
  OfuscadorTool - actualizacion idempotente de una instalacion existente.
  Ejecutar manualmente como DBA en adminDB despues de respaldar la base.
  No elimina datos, servidores, patrones, perfiles, auditoria ni historiales.
*/
USE [adminDB];
GO
SET XACT_ABORT ON;
SET NOCOUNT ON;

IF SCHEMA_ID(N'ofuscador') IS NULL
    THROW 50001,N'No existe el esquema ofuscador. Ejecute 00_instalacion_adminDB.sql.',1;
GO

IF OBJECT_ID(N'ofuscador.Servers',N'U') IS NULL
 OR OBJECT_ID(N'ofuscador.AuthorizedUsers',N'U') IS NULL
 OR OBJECT_ID(N'ofuscador.MaskPatterns',N'U') IS NULL
 OR OBJECT_ID(N'ofuscador.Executions',N'U') IS NULL
 OR OBJECT_ID(N'ofuscador.ExecutionTargets',N'U') IS NULL
 OR OBJECT_ID(N'ofuscador.PermissionBackup',N'U') IS NULL
 OR OBJECT_ID(N'ofuscador.Audit',N'U') IS NULL
    THROW 50002,N'Faltan tablas base. Use 00_instalacion_adminDB.sql para completar la instalacion.',1;
GO

/* Objetos incorporados en versiones posteriores. */
IF OBJECT_ID(N'ofuscador.MaskExceptions',N'U') IS NULL
BEGIN
    CREATE TABLE ofuscador.MaskExceptions
    (
        ExceptionId int IDENTITY(1,1) NOT NULL CONSTRAINT PK_Ofuscador_MaskExceptions PRIMARY KEY,
        ServerName nvarchar(100) NOT NULL,
        DatabaseName sysname NOT NULL,
        SchemaName sysname NOT NULL CONSTRAINT DF_Ofuscador_MaskExceptions_Schema DEFAULT(N'dbo'),
        TableName sysname NOT NULL,
        ColumnName sysname NULL,
        ActionName nvarchar(40) NOT NULL,
        IsActive bit NOT NULL CONSTRAINT DF_Ofuscador_MaskExceptions_Active DEFAULT(1),
        Notes nvarchar(500) NULL,
        CreatedAt datetime2(0) NOT NULL CONSTRAINT DF_Ofuscador_MaskExceptions_Created DEFAULT SYSUTCDATETIME(),
        ModifiedAt datetime2(0) NOT NULL CONSTRAINT DF_Ofuscador_MaskExceptions_Modified DEFAULT SYSUTCDATETIME(),
        CONSTRAINT CK_Ofuscador_MaskExceptions_Action CHECK
        ((ActionName=N'NO_OFUSCAR_COLUMNA' AND ColumnName IS NOT NULL) OR
         (ActionName=N'CREAR_VISTA_TABLA' AND ColumnName IS NULL)),
        CONSTRAINT UQ_Ofuscador_MaskExceptions
          UNIQUE(ServerName,DatabaseName,SchemaName,TableName,ColumnName,ActionName)
    );
END;

IF OBJECT_ID(N'ofuscador.MaskProfiles',N'U') IS NULL
BEGIN
    CREATE TABLE ofuscador.MaskProfiles
    (
        ProfileId int IDENTITY(1,1) NOT NULL CONSTRAINT PK_Ofuscador_MaskProfiles PRIMARY KEY,
        ProfileName nvarchar(128) NOT NULL CONSTRAINT UQ_Ofuscador_MaskProfiles_Name UNIQUE,
        ServerName nvarchar(128) NOT NULL,DatabaseName sysname NOT NULL,TargetSchema sysname NOT NULL,
        IsActive bit NOT NULL CONSTRAINT DF_Ofuscador_MaskProfiles_Active DEFAULT(1),
        CreatedAt datetime2(0) NOT NULL CONSTRAINT DF_Ofuscador_MaskProfiles_Created DEFAULT SYSUTCDATETIME(),
        ModifiedAt datetime2(0) NOT NULL CONSTRAINT DF_Ofuscador_MaskProfiles_Modified DEFAULT SYSUTCDATETIME()
    );
END;

IF OBJECT_ID(N'ofuscador.MaskProfileColumns',N'U') IS NULL
BEGIN
    CREATE TABLE ofuscador.MaskProfileColumns
    (
        ProfileId int NOT NULL,SchemaName sysname NOT NULL,TableName sysname NOT NULL,
        ColumnName sysname NOT NULL,RulePattern nvarchar(128) NOT NULL,
        CONSTRAINT PK_Ofuscador_MaskProfileColumns PRIMARY KEY(ProfileId,SchemaName,TableName,ColumnName),
        CONSTRAINT FK_Ofuscador_MaskProfileColumns_Profile FOREIGN KEY(ProfileId)
          REFERENCES ofuscador.MaskProfiles(ProfileId) ON DELETE CASCADE
    );
END;

IF OBJECT_ID(N'ofuscador.MaskProfileUsers',N'U') IS NULL
BEGIN
    CREATE TABLE ofuscador.MaskProfileUsers
    (
        ProfileId int NOT NULL,PrincipalName sysname NOT NULL,
        CONSTRAINT PK_Ofuscador_MaskProfileUsers PRIMARY KEY(ProfileId,PrincipalName),
        CONSTRAINT FK_Ofuscador_MaskProfileUsers_Profile FOREIGN KEY(ProfileId)
          REFERENCES ofuscador.MaskProfiles(ProfileId) ON DELETE CASCADE
    );
END;
GO

/* Columnas compatibles con instalaciones iniciales. */
IF COL_LENGTH(N'ofuscador.Servers',N'TimeoutSeconds') IS NULL
    ALTER TABLE ofuscador.Servers ADD TimeoutSeconds int NOT NULL
      CONSTRAINT DF_Ofuscador_Servers_Timeout_Upgrade DEFAULT(30) WITH VALUES;

IF COL_LENGTH(N'ofuscador.MaskPatterns',N'Priority') IS NULL
    ALTER TABLE ofuscador.MaskPatterns ADD Priority int NOT NULL
      CONSTRAINT DF_Ofuscador_MaskPatterns_Priority_Upgrade DEFAULT(200) WITH VALUES;
IF COL_LENGTH(N'ofuscador.MaskPatterns',N'IsActive') IS NULL
    ALTER TABLE ofuscador.MaskPatterns ADD IsActive bit NOT NULL
      CONSTRAINT DF_Ofuscador_MaskPatterns_Active_Upgrade DEFAULT(1) WITH VALUES;
IF COL_LENGTH(N'ofuscador.MaskPatterns',N'ViewMaskExpr') IS NULL
    ALTER TABLE ofuscador.MaskPatterns ADD ViewMaskExpr nvarchar(1000) NULL;

IF COL_LENGTH(N'ofuscador.AuthorizedUsers',N'UpdatedAt') IS NULL
    ALTER TABLE ofuscador.AuthorizedUsers ADD UpdatedAt datetime2(0) NOT NULL
      CONSTRAINT DF_Ofuscador_AuthorizedUsers_Updated_Upgrade DEFAULT SYSUTCDATETIME() WITH VALUES;
GO

/* Normalizar prioridades antiguas antes de cerrar el dominio. */
UPDATE ofuscador.MaskPatterns
SET Priority=CASE WHEN Priority<150 THEN 100 WHEN Priority>=250 THEN 300 ELSE 200 END
WHERE Priority NOT IN(100,200,300);

UPDATE ofuscador.AuthorizedUsers
SET AppRole=CASE
 WHEN AppRole IN(N'Administrador',N'Admin') THEN N'Administrator'
 WHEN AppRole IN(N'Operador') THEN N'Operator'
 WHEN AppRole IN(N'Auditor') THEN N'Auditor'
 ELSE AppRole END
WHERE AppRole NOT IN(N'Administrator',N'Operator',N'Auditor');

IF EXISTS(SELECT 1 FROM ofuscador.AuthorizedUsers WHERE AppRole NOT IN(N'Administrator',N'Operator',N'Auditor'))
    THROW 50003,N'Existen AppRole no reconocidos en ofuscador.AuthorizedUsers. Corrijalos antes de continuar.',1;

IF NOT EXISTS(SELECT 1 FROM sys.check_constraints WHERE parent_object_id=OBJECT_ID(N'ofuscador.MaskPatterns') AND name=N'CK_Ofuscador_MaskPatterns_Priority')
    ALTER TABLE ofuscador.MaskPatterns WITH CHECK ADD CONSTRAINT CK_Ofuscador_MaskPatterns_Priority CHECK(Priority IN(100,200,300));

IF NOT EXISTS(SELECT 1 FROM sys.check_constraints WHERE parent_object_id=OBJECT_ID(N'ofuscador.AuthorizedUsers') AND name=N'CK_Ofuscador_AuthorizedUsers_AppRole')
    ALTER TABLE ofuscador.AuthorizedUsers WITH CHECK ADD CONSTRAINT CK_Ofuscador_AuthorizedUsers_AppRole CHECK(AppRole IN(N'Administrator',N'Operator',N'Auditor'));
GO

/* Indices operativos. */
IF NOT EXISTS(SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID(N'ofuscador.Audit') AND name=N'IX_Ofuscador_Audit_EventAt')
    CREATE INDEX IX_Ofuscador_Audit_EventAt ON ofuscador.Audit(EventAt DESC);
IF NOT EXISTS(SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID(N'ofuscador.Audit') AND name=N'IX_Ofuscador_Audit_Principal_EventAt')
    CREATE INDEX IX_Ofuscador_Audit_Principal_EventAt ON ofuscador.Audit(Principal,EventAt DESC);
IF NOT EXISTS(SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID(N'ofuscador.Executions') AND name=N'IX_Ofuscador_Executions_StartedAt')
    CREATE INDEX IX_Ofuscador_Executions_StartedAt ON ofuscador.Executions(StartedAt DESC);
IF NOT EXISTS(SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID(N'ofuscador.ExecutionTargets') AND name=N'IX_Ofuscador_ExecutionTargets_Status')
    CREATE INDEX IX_Ofuscador_ExecutionTargets_Status ON ofuscador.ExecutionTargets(Status);
IF NOT EXISTS(SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID(N'ofuscador.MaskExceptions') AND name=N'IX_Ofuscador_MaskExceptions_Target')
    CREATE INDEX IX_Ofuscador_MaskExceptions_Target ON ofuscador.MaskExceptions(ServerName,DatabaseName,SchemaName,TableName);
GO

PRINT N'Actualizacion administrativa de OfuscadorTool completada.';
GO
