/*
  OfuscadorTool - instalación administrativa controlada por DBA
  Ejecutar manualmente en la base pivote ya creada (por defecto: adminDB).
  Este script crea únicamente el esquema y objetos administrativos del aplicativo.
  La aplicación NO crea ni modifica estos objetos.
*/
USE [adminDB];
GO
SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
SET NOCOUNT ON;

IF SCHEMA_ID(N'ofuscador') IS NULL EXEC(N'CREATE SCHEMA [ofuscador] AUTHORIZATION [dbo]');
GO
IF OBJECT_ID(N'ofuscador.Servers',N'U') IS NULL
CREATE TABLE ofuscador.Servers(
 ServerId int IDENTITY(1,1) CONSTRAINT PK_Ofuscador_Servers PRIMARY KEY,
 IsActive bit NOT NULL CONSTRAINT DF_Ofuscador_Servers_IsActive DEFAULT(1),
 Name nvarchar(100) NOT NULL CONSTRAINT UQ_Ofuscador_Servers_Name UNIQUE,
 Host nvarchar(256) NOT NULL, Instance nvarchar(128) NULL,
 UseWindowsAuth bit NOT NULL, SqlUser nvarchar(256) NULL, EncryptedPassword nvarchar(max) NULL,
 Encrypt bit NOT NULL CONSTRAINT DF_Ofuscador_Servers_Encrypt DEFAULT(1),
 TrustServerCertificate bit NOT NULL CONSTRAINT DF_Ofuscador_Servers_Trust DEFAULT(0),
 TimeoutSeconds int NOT NULL CONSTRAINT DF_Ofuscador_Servers_Timeout DEFAULT(30),
 CreatedAt datetime2(0) NOT NULL CONSTRAINT DF_Ofuscador_Servers_Created DEFAULT SYSUTCDATETIME(),
 CONSTRAINT CK_Ofuscador_Servers_Timeout CHECK(TimeoutSeconds BETWEEN 5 AND 300),
 CONSTRAINT CK_Ofuscador_Servers_Authentication CHECK
   (UseWindowsAuth=1 OR (NULLIF(LTRIM(RTRIM(SqlUser)),N'') IS NOT NULL AND EncryptedPassword IS NOT NULL)));
GO
IF OBJECT_ID(N'ofuscador.AuthorizedUsers',N'U') IS NULL
CREATE TABLE ofuscador.AuthorizedUsers(
 Principal nvarchar(256) NOT NULL CONSTRAINT PK_Ofuscador_AuthorizedUsers PRIMARY KEY,
 PrincipalType nvarchar(30) NOT NULL, AppRole nvarchar(20) NOT NULL,
 IsActive bit NOT NULL CONSTRAINT DF_Ofuscador_AuthorizedUsers_Active DEFAULT(1),
 Notes nvarchar(500) NULL, UpdatedAt datetime2(0) NOT NULL CONSTRAINT DF_Ofuscador_AuthorizedUsers_Updated DEFAULT SYSUTCDATETIME(),
 CONSTRAINT CK_Ofuscador_AuthorizedUsers_AppRole CHECK(AppRole IN(N'Administrator',N'Operator',N'Auditor')));
GO
IF OBJECT_ID(N'ofuscador.MaskPatterns',N'U') IS NULL
CREATE TABLE ofuscador.MaskPatterns(
 Pattern nvarchar(128) NOT NULL CONSTRAINT PK_Ofuscador_MaskPatterns PRIMARY KEY,
 DdmFunction nvarchar(200) NOT NULL, ViewMaskExpr nvarchar(1000) NULL,
 Priority int NOT NULL CONSTRAINT DF_Ofuscador_MaskPatterns_Priority DEFAULT(200),
 IsActive bit NOT NULL CONSTRAINT DF_Ofuscador_MaskPatterns_Active DEFAULT(1),
 CONSTRAINT CK_Ofuscador_MaskPatterns_Priority CHECK(Priority IN(100,200,300)));
GO
/*
  Decisiones explicitas de clasificacion. No se deducen por columnas calculadas.
  NO_OFUSCAR_COLUMNA requiere ColumnName.
  CREAR_VISTA_TABLA aplica a toda la tabla y ColumnName debe ser NULL.
*/
IF OBJECT_ID(N'ofuscador.MaskExceptions',N'U') IS NULL
CREATE TABLE ofuscador.MaskExceptions(
 ExceptionId int IDENTITY(1,1) NOT NULL CONSTRAINT PK_Ofuscador_MaskExceptions PRIMARY KEY,
 ServerName nvarchar(100) NOT NULL, DatabaseName sysname NOT NULL,
 SchemaName sysname NOT NULL CONSTRAINT DF_Ofuscador_MaskExceptions_Schema DEFAULT(N'dbo'),
 TableName sysname NOT NULL, ColumnName sysname NULL,
 ActionName nvarchar(40) NOT NULL, IsActive bit NOT NULL CONSTRAINT DF_Ofuscador_MaskExceptions_Active DEFAULT(1),
 Notes nvarchar(500) NULL,
 CreatedAt datetime2(0) NOT NULL CONSTRAINT DF_Ofuscador_MaskExceptions_Created DEFAULT SYSUTCDATETIME(),
 ModifiedAt datetime2(0) NOT NULL CONSTRAINT DF_Ofuscador_MaskExceptions_Modified DEFAULT SYSUTCDATETIME(),
 CONSTRAINT CK_Ofuscador_MaskExceptions_Action CHECK(
   (ActionName=N'NO_OFUSCAR_COLUMNA' AND ColumnName IS NOT NULL) OR
   (ActionName=N'CREAR_VISTA_TABLA' AND ColumnName IS NULL)),
 CONSTRAINT UQ_Ofuscador_MaskExceptions UNIQUE(ServerName,DatabaseName,SchemaName,TableName,ColumnName,ActionName));
GO
IF OBJECT_ID(N'ofuscador.Executions',N'U') IS NULL
CREATE TABLE ofuscador.Executions(
 ExecutionId uniqueidentifier NOT NULL CONSTRAINT PK_Ofuscador_Executions PRIMARY KEY,
 Mode nvarchar(20) NOT NULL, Status nvarchar(30) NOT NULL, RequestedBy nvarchar(256) NOT NULL,
 StartedAt datetime2(0) NOT NULL, FinishedAt datetime2(0) NULL, Summary nvarchar(max) NULL);
GO
IF OBJECT_ID(N'ofuscador.ExecutionTargets',N'U') IS NULL
CREATE TABLE ofuscador.ExecutionTargets(
 ExecutionId uniqueidentifier NOT NULL, ServerName nvarchar(100) NOT NULL, DatabaseName sysname NOT NULL,
 Status nvarchar(30) NOT NULL, Detail nvarchar(max) NULL,
 CONSTRAINT PK_Ofuscador_ExecutionTargets PRIMARY KEY(ExecutionId,ServerName,DatabaseName),
 CONSTRAINT FK_Ofuscador_ExecutionTargets_Execution FOREIGN KEY(ExecutionId) REFERENCES ofuscador.Executions(ExecutionId));
GO
IF OBJECT_ID(N'ofuscador.PermissionBackup',N'U') IS NULL
CREATE TABLE ofuscador.PermissionBackup(
 ExecutionId uniqueidentifier NOT NULL, ServerName nvarchar(100) NOT NULL, DatabaseName sysname NOT NULL,
 PrincipalName sysname NOT NULL, SnapshotJson nvarchar(max) NOT NULL,
 CONSTRAINT PK_Ofuscador_PermissionBackup PRIMARY KEY(ExecutionId,ServerName,DatabaseName,PrincipalName));
GO
IF OBJECT_ID(N'ofuscador.Audit',N'U') IS NULL
CREATE TABLE ofuscador.Audit(
 AuditId bigint IDENTITY(1,1) CONSTRAINT PK_Ofuscador_Audit PRIMARY KEY,
 EventAt datetime2(0) NOT NULL CONSTRAINT DF_Ofuscador_Audit_Event DEFAULT SYSUTCDATETIME(),
 Principal nvarchar(256) NOT NULL, FormName nvarchar(100) NOT NULL, ActionName nvarchar(100) NOT NULL,
 ServerName nvarchar(100) NULL, DatabaseName sysname NULL, Success bit NOT NULL, Detail nvarchar(max) NULL);
GO
/* Perfiles de ofuscamiento: objetos creados manualmente por el DBA. */
IF OBJECT_ID(N'ofuscador.MaskProfiles',N'U') IS NULL
CREATE TABLE ofuscador.MaskProfiles(
 ProfileId int IDENTITY(1,1) NOT NULL CONSTRAINT PK_Ofuscador_MaskProfiles PRIMARY KEY,
 ProfileName nvarchar(128) NOT NULL CONSTRAINT UQ_Ofuscador_MaskProfiles_Name UNIQUE,
 ServerName nvarchar(128) NOT NULL, DatabaseName sysname NOT NULL, TargetSchema sysname NOT NULL,
 IsActive bit NOT NULL CONSTRAINT DF_Ofuscador_MaskProfiles_Active DEFAULT(1),
 CreatedAt datetime2(0) NOT NULL CONSTRAINT DF_Ofuscador_MaskProfiles_Created DEFAULT SYSUTCDATETIME(),
 ModifiedAt datetime2(0) NOT NULL CONSTRAINT DF_Ofuscador_MaskProfiles_Modified DEFAULT SYSUTCDATETIME());
IF OBJECT_ID(N'ofuscador.MaskProfileColumns',N'U') IS NULL
CREATE TABLE ofuscador.MaskProfileColumns(
 ProfileId int NOT NULL, SchemaName sysname NOT NULL, TableName sysname NOT NULL, ColumnName sysname NOT NULL,
 RulePattern nvarchar(128) NOT NULL,
 CONSTRAINT PK_Ofuscador_MaskProfileColumns PRIMARY KEY(ProfileId,SchemaName,TableName,ColumnName),
 CONSTRAINT FK_Ofuscador_MaskProfileColumns_Profile FOREIGN KEY(ProfileId) REFERENCES ofuscador.MaskProfiles(ProfileId) ON DELETE CASCADE);
IF OBJECT_ID(N'ofuscador.MaskProfileUsers',N'U') IS NULL
CREATE TABLE ofuscador.MaskProfileUsers(
 ProfileId int NOT NULL, PrincipalName sysname NOT NULL,
 CONSTRAINT PK_Ofuscador_MaskProfileUsers PRIMARY KEY(ProfileId,PrincipalName),
 CONSTRAINT FK_Ofuscador_MaskProfileUsers_Profile FOREIGN KEY(ProfileId) REFERENCES ofuscador.MaskProfiles(ProfileId) ON DELETE CASCADE);
GO
IF NOT EXISTS(SELECT 1 FROM sys.indexes WHERE name=N'IX_Ofuscador_Audit_EventAt' AND object_id=OBJECT_ID(N'ofuscador.Audit'))
  CREATE INDEX IX_Ofuscador_Audit_EventAt ON ofuscador.Audit(EventAt DESC);
IF NOT EXISTS(SELECT 1 FROM sys.indexes WHERE name=N'IX_Ofuscador_ExecutionTargets_Status' AND object_id=OBJECT_ID(N'ofuscador.ExecutionTargets'))
  CREATE INDEX IX_Ofuscador_ExecutionTargets_Status ON ofuscador.ExecutionTargets(Status);
IF NOT EXISTS(SELECT 1 FROM sys.indexes WHERE name=N'IX_Ofuscador_Audit_Principal_EventAt' AND object_id=OBJECT_ID(N'ofuscador.Audit'))
  CREATE INDEX IX_Ofuscador_Audit_Principal_EventAt ON ofuscador.Audit(Principal,EventAt DESC);
IF NOT EXISTS(SELECT 1 FROM sys.indexes WHERE name=N'IX_Ofuscador_Executions_StartedAt' AND object_id=OBJECT_ID(N'ofuscador.Executions'))
  CREATE INDEX IX_Ofuscador_Executions_StartedAt ON ofuscador.Executions(StartedAt DESC);
IF NOT EXISTS(SELECT 1 FROM sys.indexes WHERE name=N'IX_Ofuscador_MaskExceptions_Target' AND object_id=OBJECT_ID(N'ofuscador.MaskExceptions'))
  CREATE INDEX IX_Ofuscador_MaskExceptions_Target ON ofuscador.MaskExceptions(ServerName,DatabaseName,SchemaName,TableName);
GO

/* Patrones iniciales: solo se insertan si todavía no existen. */
MERGE ofuscador.MaskPatterns AS T
USING (VALUES
 (N'%TARJETA%',N'partial(0,"XXXXXXXXXXXXXXX",4)',N'CASE WHEN {col} IS NULL THEN NULL ELSE REPLICATE(''X'',CASE WHEN LEN({col})>4 THEN LEN({col})-4 ELSE 0 END)+RIGHT({col},CASE WHEN LEN({col})>4 THEN 4 ELSE LEN({col}) END) END',100,CONVERT(bit,1)),
 (N'%CUENTA%',N'partial(0,"XXXXXXXXXXXX",4)',N'CASE WHEN {col} IS NULL THEN NULL ELSE REPLICATE(''X'',CASE WHEN LEN({col})>4 THEN LEN({col})-4 ELSE 0 END)+RIGHT({col},CASE WHEN LEN({col})>4 THEN 4 ELSE LEN({col}) END) END',100,CONVERT(bit,1)),
 (N'%EMAIL%',N'email()',N'CASE WHEN {col} IS NULL THEN NULL ELSE CASE WHEN CHARINDEX(''@'',{col})>1 THEN LEFT({col},1)+REPLICATE(''X'',CHARINDEX(''@'',{col})-2)+SUBSTRING({col},CHARINDEX(''@'',{col}),LEN({col})) ELSE REPLICATE(''X'',LEN({col})) END END',200,CONVERT(bit,1)),
 (N'%NIT%',N'default()',N'CASE WHEN {col} IS NULL THEN NULL ELSE REPLICATE(''X'',LEN({col})) END',200,CONVERT(bit,1)),
 (N'%DIRECCION%',N'default()',N'CASE WHEN {col} IS NULL THEN NULL ELSE REPLICATE(''X'',LEN({col})) END',200,CONVERT(bit,1)),
 (N'%TEL%',N'default()',N'CASE WHEN {col} IS NULL THEN NULL ELSE REPLICATE(''X'',LEN({col})) END',200,CONVERT(bit,1)),
 (N'%TELEFONO%',N'default()',N'CASE WHEN {col} IS NULL THEN NULL ELSE REPLICATE(''X'',LEN({col})) END',200,CONVERT(bit,1)),
 (N'%TOKEN%',N'partial(0,"****************",4)',N'CASE WHEN {col} IS NULL THEN NULL ELSE REPLICATE(''*'',CASE WHEN LEN({col})>4 THEN LEN({col})-4 ELSE 0 END)+RIGHT({col},CASE WHEN LEN({col})>4 THEN 4 ELSE LEN({col}) END) END',100,CONVERT(bit,1)),
 (N'%NOMBRE%',N'partial(1,"XXXXXXXXXX",0)',N'CASE WHEN {col} IS NULL THEN NULL ELSE LEFT({col},1)+REPLICATE(''X'',CASE WHEN LEN({col})>1 THEN LEN({col})-1 ELSE 0 END) END',300,CONVERT(bit,1))
) AS S(Pattern,DdmFunction,ViewMaskExpr,Priority,IsActive) ON S.Pattern=T.Pattern
WHEN NOT MATCHED THEN INSERT(Pattern,DdmFunction,ViewMaskExpr,Priority,IsActive)
VALUES(S.Pattern,S.DdmFunction,S.ViewMaskExpr,S.Priority,S.IsActive);
GO

/* Reemplace el valor y ejecute este bloque para registrar al primer administrador. */
DECLARE @PrimerAdministrador nvarchar(256)=N'DOMINIO\usuario1';
DECLARE @TipoAdministrador nvarchar(30)=N'WINDOWS_LOGIN'; -- o SQL_LOGIN
IF @PrimerAdministrador=N'DOMINIO\usuario1'
    THROW 50010,N'Reemplace DOMINIO\usuario1 por el primer administrador real y vuelva a ejecutar.',1;
IF @TipoAdministrador NOT IN(N'WINDOWS_LOGIN',N'SQL_LOGIN',N'WINDOWS_GROUP',N'EXTERNAL_LOGIN',N'EXTERNAL_GROUP')
    THROW 50011,N'Tipo de administrador no valido.',1;
MERGE ofuscador.AuthorizedUsers AS T
USING (SELECT @PrimerAdministrador Principal) AS S ON S.Principal=T.Principal
WHEN MATCHED THEN UPDATE SET IsActive=1,AppRole=N'Administrator',PrincipalType=@TipoAdministrador,UpdatedAt=SYSUTCDATETIME()
WHEN NOT MATCHED THEN INSERT(Principal,PrincipalType,AppRole,IsActive,Notes)
 VALUES(S.Principal,@TipoAdministrador,N'Administrator',1,N'Administrador inicial');
GO

/* Los permisos por rol se instalan con 02_permisos_roles.sql. */
GO
