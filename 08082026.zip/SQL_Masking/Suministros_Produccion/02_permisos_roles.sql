/*
  OfuscadorTool - roles de acceso a adminDB.
  La asignacion de usuarios a estos roles la realiza manualmente el DBA.
  El valor AppRole de ofuscador.AuthorizedUsers debe coincidir con el rol SQL.
*/
USE [adminDB];
GO
SET NOCOUNT ON;
SET XACT_ABORT ON;

IF SCHEMA_ID(N'ofuscador') IS NULL
    THROW 50001,N'No existe el esquema ofuscador.',1;
GO

IF DATABASE_PRINCIPAL_ID(N'OfuscadorTool_Administrator') IS NULL CREATE ROLE [OfuscadorTool_Administrator] AUTHORIZATION dbo;
IF DATABASE_PRINCIPAL_ID(N'OfuscadorTool_Operator') IS NULL CREATE ROLE [OfuscadorTool_Operator] AUTHORIZATION dbo;
IF DATABASE_PRINCIPAL_ID(N'OfuscadorTool_Auditor') IS NULL CREATE ROLE [OfuscadorTool_Auditor] AUTHORIZATION dbo;
GO

/* Retirar el acceso amplio del rol heredado de versiones anteriores. */
IF DATABASE_PRINCIPAL_ID(N'OfuscadorTool_AppRole') IS NOT NULL
    REVOKE SELECT,INSERT,UPDATE,DELETE ON SCHEMA::ofuscador FROM [OfuscadorTool_AppRole];
GO

/* Administrador: configuracion y operacion completa del aplicativo. */
GRANT VIEW DEFINITION ON SCHEMA::ofuscador TO [OfuscadorTool_Administrator];
GRANT SELECT,INSERT,UPDATE,DELETE ON SCHEMA::ofuscador TO [OfuscadorTool_Administrator];
IF OBJECT_ID(N'ofuscador.EncryptServerCredential',N'P') IS NOT NULL
    GRANT EXECUTE ON OBJECT::ofuscador.EncryptServerCredential TO [OfuscadorTool_Administrator];
IF OBJECT_ID(N'ofuscador.DecryptServerCredential',N'P') IS NOT NULL
    GRANT EXECUTE ON OBJECT::ofuscador.DecryptServerCredential TO [OfuscadorTool_Administrator];

/* Auditor: consulta todos los catalogos e inventarios y registra su propia auditoria. */
GRANT VIEW DEFINITION ON SCHEMA::ofuscador TO [OfuscadorTool_Auditor];
GRANT SELECT ON SCHEMA::ofuscador TO [OfuscadorTool_Auditor];
GRANT INSERT ON OBJECT::ofuscador.Audit TO [OfuscadorTool_Auditor];
IF OBJECT_ID(N'ofuscador.DecryptServerCredential',N'P') IS NOT NULL
BEGIN
    REVOKE EXECUTE ON OBJECT::ofuscador.DecryptServerCredential FROM [OfuscadorTool_Auditor];
    GRANT EXECUTE ON OBJECT::ofuscador.DecryptServerCredential TO [OfuscadorTool_Auditor];
END;

/* Operador: despliegue y rollback, sin administrar servidores, reglas ni usuarios. */
GRANT VIEW DEFINITION ON SCHEMA::ofuscador TO [OfuscadorTool_Operator];
GRANT SELECT ON OBJECT::ofuscador.AuthorizedUsers TO [OfuscadorTool_Operator];
GRANT SELECT ON OBJECT::ofuscador.Servers TO [OfuscadorTool_Operator];
GRANT SELECT ON OBJECT::ofuscador.MaskPatterns TO [OfuscadorTool_Operator];
GRANT SELECT ON OBJECT::ofuscador.MaskExceptions TO [OfuscadorTool_Operator];
GRANT SELECT,INSERT,UPDATE ON OBJECT::ofuscador.Executions TO [OfuscadorTool_Operator];
GRANT SELECT,INSERT,UPDATE ON OBJECT::ofuscador.ExecutionTargets TO [OfuscadorTool_Operator];
GRANT SELECT,INSERT ON OBJECT::ofuscador.PermissionBackup TO [OfuscadorTool_Operator];
GRANT INSERT ON OBJECT::ofuscador.Audit TO [OfuscadorTool_Operator];
IF OBJECT_ID(N'ofuscador.DecryptServerCredential',N'P') IS NOT NULL
    GRANT EXECUTE ON OBJECT::ofuscador.DecryptServerCredential TO [OfuscadorTool_Operator];
GO

/*
  Ejemplos de asignacion (descomentar y reemplazar por usuarios reales):

  CREATE USER [DOMINIO\admin] FOR LOGIN [DOMINIO\admin];
  ALTER ROLE [OfuscadorTool_Administrator] ADD MEMBER [DOMINIO\admin];

  CREATE USER [operador_sql] FOR LOGIN [operador_sql];
  ALTER ROLE [OfuscadorTool_Operator] ADD MEMBER [operador_sql];

  CREATE USER [DOMINIO\auditor] FOR LOGIN [DOMINIO\auditor];
  ALTER ROLE [OfuscadorTool_Auditor] ADD MEMBER [DOMINIO\auditor];
*/
PRINT N'Roles y permisos de OfuscadorTool aplicados.';
GO
