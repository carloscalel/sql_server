/*
  Laboratorio OfuscadorTool. Crea datos ficticios en dbo y Ventas.
  Ejecutar manualmente como DBA. No usar sobre una base real.
*/
USE [master];
GO
IF DB_ID(N'OfuscadorDemo') IS NULL CREATE DATABASE [OfuscadorDemo];
GO
USE [OfuscadorDemo];
GO
SET NOCOUNT ON;
IF SCHEMA_ID(N'Ventas') IS NULL EXEC(N'CREATE SCHEMA [Ventas] AUTHORIZATION [dbo]');
GO

IF OBJECT_ID(N'Ventas.ClienteCompleto',N'U') IS NOT NULL DROP TABLE Ventas.ClienteCompleto;
IF OBJECT_ID(N'dbo.Pedidos',N'U') IS NOT NULL DROP TABLE dbo.Pedidos;
IF OBJECT_ID(N'dbo.Clientes',N'U') IS NOT NULL DROP TABLE dbo.Clientes;
IF OBJECT_ID(N'dbo.Empleados',N'U') IS NOT NULL DROP TABLE dbo.Empleados;
GO

CREATE TABLE dbo.Clientes
(
 ClienteId int IDENTITY(1,1) CONSTRAINT PK_Demo_Clientes PRIMARY KEY,
 NombreCompleto nvarchar(120) NOT NULL,NumeroTarjeta varchar(19) NULL,
 CuentaBancaria varchar(24) NULL,CorreoEmail varchar(150) NULL,NIT varchar(20) NULL,
 Direccion nvarchar(250) NULL,Telefono varchar(25) NULL,FechaNacimiento date NULL,
 ComentarioSensible nvarchar(500) NULL
);
CREATE TABLE dbo.Empleados
(
 EmpleadoId int IDENTITY(1,1) CONSTRAINT PK_Demo_Empleados PRIMARY KEY,
 NombreEmpleado nvarchar(120) NOT NULL,SalarioMensual decimal(12,2) NOT NULL,
 TokenAcceso varchar(80) NULL,TelefonoEmpleado varchar(25) NULL,DireccionEmpleado nvarchar(250) NULL
);
CREATE TABLE dbo.Pedidos
(
 PedidoId int IDENTITY(1,1) CONSTRAINT PK_Demo_Pedidos PRIMARY KEY,
 ClienteId int NOT NULL,Importe decimal(12,2) NOT NULL,Impuesto decimal(12,2) NOT NULL,
 ImporteTotal AS (Importe+Impuesto) PERSISTED,
 CONSTRAINT FK_Demo_Pedidos_Clientes FOREIGN KEY(ClienteId) REFERENCES dbo.Clientes(ClienteId)
);
CREATE TABLE Ventas.ClienteCompleto
(
 ClienteId int IDENTITY(1,1) CONSTRAINT PK_Demo_Ventas_ClienteCompleto PRIMARY KEY,
 Nombres varchar(50) NOT NULL,Apellidos varchar(50) NOT NULL,
 NombreCompleto AS (Nombres+' '+Apellidos) PERSISTED,
 NumeroTarjeta varchar(16) NULL,CuentaBancaria varchar(20) NULL,CorreoEmail varchar(100) NULL,
 NIT varchar(15) NULL,Direccion varchar(150) NULL,Telefono varchar(15) NULL,
 FechaNacimiento date NULL,ComentarioSensible varchar(250) NULL
);
GO

INSERT dbo.Clientes(NombreCompleto,NumeroTarjeta,CuentaBancaria,CorreoEmail,NIT,Direccion,Telefono,FechaNacimiento,ComentarioSensible)
VALUES
(N'Ana Martinez Lopez','4111111111111111','001234567890123456789012','ana.martinez@example.test','1234567-8',N'Zona 10, Ciudad de Guatemala','5555-0101','1988-04-12',N'Cliente preferente'),
(N'Carlos Ramirez Soto','5500000000000004','009876543210987654321098','carlos.ramirez@example.test','9876543-2',N'Zona 14, Ciudad de Guatemala','5555-0102','1979-11-28',N'No llamar por la tarde');
INSERT dbo.Empleados(NombreEmpleado,SalarioMensual,TokenAcceso,TelefonoEmpleado,DireccionEmpleado)
VALUES(N'Roberto Castillo',18500,'tok-demo-001','5555-1001',N'Zona 1, Guatemala');
INSERT dbo.Pedidos(ClienteId,Importe,Impuesto) VALUES(1,1200,144),(2,850,102);
INSERT Ventas.ClienteCompleto
 (Nombres,Apellidos,NumeroTarjeta,CuentaBancaria,CorreoEmail,NIT,Direccion,Telefono,FechaNacimiento,ComentarioSensible)
VALUES
 ('Ana','Martinez Lopez','4111111111111111','00123456789012345678','ana.martinez@example.test','1234567-8','Zona 10, Guatemala','5555-0101','1988-04-12','Cliente preferente'),
 ('Roberto','Castillo','5500000000000002','00987654321098765432','roberto.castillo@example.test','8765432-1','Zona 1, Guatemala','5555-1001','1995-08-23','Credito pendiente');
GO

/* Las reglas se sincronizan desde adminDB.ofuscador.MaskPatterns al desplegar. */
SELECT * FROM dbo.Clientes;
SELECT * FROM dbo.Empleados;
SELECT * FROM dbo.Pedidos;
SELECT * FROM Ventas.ClienteCompleto;
GO
