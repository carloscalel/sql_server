/*
  Plantilla para habilitar la credencial tecnica en bases objetivo.
  Ejecutar manualmente como DBA en CADA servidor registrado.

  El proceso crea y elimina DDM, vistas, triggers, sinonimos, esquemas y roles,
  y reconcilia permisos. Requiere db_owner solo en cada base autorizada.
  No se recomienda sysadmin ni conceder acceso a todas las bases.
*/
USE [master];
GO
DECLARE @Login sysname=N'DOMINIO\svc_ofuscador';
IF SUSER_ID(@Login) IS NULL
    THROW 50001,N'El login tecnico no existe. Creelo segun la politica corporativa.',1;

DECLARE @Bases TABLE(DatabaseName sysname PRIMARY KEY);
/* Reemplace exclusivamente por las bases administradas por la herramienta. */
INSERT @Bases VALUES(N'BaseProduccion1'),(N'BaseProduccion2');

DECLARE @DatabaseName sysname,@sql nvarchar(max);
DECLARE c CURSOR LOCAL FAST_FORWARD FOR SELECT DatabaseName FROM @Bases;
OPEN c;
FETCH NEXT FROM c INTO @DatabaseName;
WHILE @@FETCH_STATUS=0
BEGIN
    IF DB_ID(@DatabaseName) IS NULL
        THROW 50002,N'Una base indicada no existe en este servidor.',1;

    SET @sql=N'USE '+QUOTENAME(@DatabaseName)+N';
      IF USER_ID(N'''+REPLACE(@Login,N'''',N'''''')+N''') IS NULL
        CREATE USER '+QUOTENAME(@Login)+N' FOR LOGIN '+QUOTENAME(@Login)+N';
      IF NOT EXISTS
      (
        SELECT 1 FROM sys.database_role_members drm
        JOIN sys.database_principals r ON r.principal_id=drm.role_principal_id
        JOIN sys.database_principals u ON u.principal_id=drm.member_principal_id
        WHERE r.name=N''db_owner'' AND u.name=N'''+REPLACE(@Login,N'''',N'''''')+N'''
      ) ALTER ROLE [db_owner] ADD MEMBER '+QUOTENAME(@Login)+N';';
    EXEC sys.sp_executesql @sql;
    FETCH NEXT FROM c INTO @DatabaseName;
END
CLOSE c;
DEALLOCATE c;
PRINT N'Credencial tecnica habilitada en las bases declaradas.';
GO
