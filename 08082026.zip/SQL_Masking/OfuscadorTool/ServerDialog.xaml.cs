using System.Windows;

namespace OfuscadorTool;

public partial class ServerDialog : Window
{
    public ServerProfile Server { get; private set; }

    public ServerDialog(ServerProfile server)
    {
        InitializeComponent();
        Server = server;
        NameBox.Text = server.Name; HostBox.Text = server.Host; InstanceBox.Text = server.Instance;
        WindowsBox.IsChecked = server.UseWindowsAuth; UserBox.Text = server.SqlUser;
        EncryptBox.IsChecked = server.Encrypt; TrustBox.IsChecked = server.TrustServerCertificate;
        TimeoutBox.Text = server.TimeoutSeconds.ToString(); ActiveBox.IsChecked = server.IsActive;
        AuthChanged(this, new RoutedEventArgs());
    }

    private void AuthChanged(object sender, RoutedEventArgs e)
    {
        var enabled = WindowsBox.IsChecked != true;
        UserBox.IsEnabled = enabled; PasswordBox.IsEnabled = enabled;
    }

    private void SaveClick(object sender, RoutedEventArgs e)
    {
        if (string.IsNullOrWhiteSpace(NameBox.Text) || string.IsNullOrWhiteSpace(HostBox.Text))
        { MessageBox.Show("El nombre amigable y el host son obligatorios.", "Validación", MessageBoxButton.OK, MessageBoxImage.Warning); return; }
        if (!int.TryParse(TimeoutBox.Text, out var timeout) || timeout < 5 || timeout > 300)
        { MessageBox.Show("El timeout debe estar entre 5 y 300 segundos.", "Validación", MessageBoxButton.OK, MessageBoxImage.Warning); return; }
        if (WindowsBox.IsChecked != true && string.IsNullOrWhiteSpace(UserBox.Text))
        { MessageBox.Show("Indica el usuario SQL o selecciona autenticación Windows.", "Validación", MessageBoxButton.OK, MessageBoxImage.Warning); return; }
        if (WindowsBox.IsChecked != true && Server.Id == 0 && string.IsNullOrWhiteSpace(PasswordBox.Password))
        { MessageBox.Show("Indica la contraseña SQL para registrar un servidor nuevo.", "Validación", MessageBoxButton.OK, MessageBoxImage.Warning); return; }
        Server.Name = NameBox.Text.Trim(); Server.Host = HostBox.Text.Trim(); Server.Instance = InstanceBox.Text.Trim();
        Server.UseWindowsAuth = WindowsBox.IsChecked == true; Server.SqlUser = UserBox.Text.Trim();
        Server.PlainPassword = PasswordBox.Password; Server.Encrypt = EncryptBox.IsChecked == true;
        Server.TrustServerCertificate = TrustBox.IsChecked == true; Server.TimeoutSeconds = timeout; Server.IsActive = ActiveBox.IsChecked == true;
        DialogResult = true; Close();
    }

    private void CancelClick(object sender, RoutedEventArgs e) { DialogResult = false; Close(); }
}
