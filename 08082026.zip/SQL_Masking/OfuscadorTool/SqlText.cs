using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;
using System.IO;

namespace OfuscadorTool;

public static class SqlText
{
    public static string Resource(string file)
    {
        var assembly = Assembly.GetExecutingAssembly();
        var name = assembly.GetManifestResourceNames().Single(n => n.EndsWith(file, StringComparison.OrdinalIgnoreCase));
        using var stream = assembly.GetManifestResourceStream(name)!;
        using var reader = new StreamReader(stream, Encoding.UTF8, true);
        return reader.ReadToEnd();
    }

    public static IEnumerable<string> Batches(string sql) =>
        Regex.Split(sql, @"^\s*GO\s*(?:--.*)?$", RegexOptions.Multiline | RegexOptions.IgnoreCase)
             .Where(x => !string.IsNullOrWhiteSpace(x));

    public static string Quote(string value) => "N'" + value.Replace("'", "''") + "'";
}
