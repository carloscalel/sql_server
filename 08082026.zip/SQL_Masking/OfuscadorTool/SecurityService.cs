using System.Security.Cryptography;
using System.Text;

namespace OfuscadorTool;

public static class SecurityService
{
    private static readonly byte[] Entropy = Encoding.UTF8.GetBytes("OfuscadorTool.ServerCredential.v1");
    private const string MachinePrefix = "DPM1:";
    private const string UserPrefix = "DPU1:";

    // Solo se conserva para migrar credenciales DPAPI creadas por versiones anteriores.
    // Las credenciales nuevas se cifran centralmente en SQL Server.
    public static string UnprotectLegacy(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return "";

        try
        {
            if (value.StartsWith(MachinePrefix, StringComparison.Ordinal))
                return UnprotectPayload(value[MachinePrefix.Length..], DataProtectionScope.LocalMachine);

            if (value.StartsWith(UserPrefix, StringComparison.Ordinal))
                return UnprotectPayload(value[UserPrefix.Length..], DataProtectionScope.CurrentUser);

            // Compatibilidad con registros anteriores, que no incluían versión
            // y se protegían con el perfil Windows que guardó la contraseña.
            try
            {
                return UnprotectPayload(value, DataProtectionScope.CurrentUser);
            }
            catch (CryptographicException)
            {
                // También admite datos LocalMachine creados durante una actualización
                // previa que todavía no utilizara el prefijo DPM1.
                return UnprotectPayload(value, DataProtectionScope.LocalMachine);
            }
        }
        catch (Exception ex) when (ex is CryptographicException or FormatException)
        {
            throw new InvalidOperationException(
                "No se pudo migrar la contraseña heredada porque fue protegida para otro usuario " +
                "Windows o para otro equipo. Un administrador debe editar el servidor, volver a " +
                "ingresar la contraseña y guardarla con el cifrado central de SQL Server.", ex);
        }
    }

    private static string UnprotectPayload(string payload, DataProtectionScope scope)
    {
        var bytes = ProtectedData.Unprotect(Convert.FromBase64String(payload), Entropy, scope);
        return Encoding.UTF8.GetString(bytes);
    }
}
