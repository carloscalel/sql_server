using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Windows;
using System.Windows.Data;

namespace OfuscadorTool;

public sealed class ProfileUserChoice { public string Name { get; set; } = ""; public string Type { get; set; } = ""; public bool IsProtected { get; set; } public bool IsSelected { get; set; } }

public partial class ProfileWindow : Window
{
    private readonly DatabaseService _db; private readonly DeploymentService _deployment; private readonly ObservableCollection<ServerProfile> _servers; private readonly ObservableCollection<MaskPattern> _patterns;
    private ObservableCollection<ProfileColumnRule> _columns = [];
    private List<ProfileUserChoice> _profileUsers = [];
    private ICollectionView? _columnsView;
    private ICollectionView? _usersView;
    public ProfileWindow(DatabaseService db, DeploymentService deployment, ObservableCollection<ServerProfile> servers, ObservableCollection<MaskPattern> patterns)
    { InitializeComponent(); _db=db; _deployment=deployment; _servers=servers; _patterns=patterns; ServerBox.ItemsSource=servers; RuleColumn.ItemsSource=new[] { "(predeterminado)" }.Concat(patterns.Where(p=>p.IsActive).Select(p=>p.Pattern)).ToList(); }
    private async void ServerChanged(object s, System.Windows.Controls.SelectionChangedEventArgs e) { if (ServerBox.SelectedItem is ServerProfile server) try { DatabaseBox.ItemsSource=await _db.LoadDatabasesAsync(server); } catch(Exception ex){ MessageBox.Show(ex.Message,"Perfiles"); } }
    private void DatabaseChanged(object s, System.Windows.Controls.SelectionChangedEventArgs e) { }
    private async void LoadColumnsClick(object s, RoutedEventArgs e) { if(ServerBox.SelectedItem is not ServerProfile server || DatabaseBox.SelectedItem is not string db){MessageBox.Show("Selecciona servidor y base.");return;} try{_columns=await _db.LoadProfileColumnsAsync(server,db); _columnsView=CollectionViewSource.GetDefaultView(_columns); ColumnsGrid.ItemsSource=_columnsView; ApplyColumnFilter();}catch(Exception ex){MessageBox.Show(ex.Message,"Perfiles");} }
    private async void LoadUsersClick(object s, RoutedEventArgs e) { if(ServerBox.SelectedItem is not ServerProfile server || DatabaseBox.SelectedItem is not string db){MessageBox.Show("Selecciona servidor y base.");return;} try{_profileUsers=(await _db.LoadPrincipalsAsync(server,db)).Select(x=>new ProfileUserChoice{Name=x.Name,Type=x.Type,IsProtected=x.IsProtected,IsSelected=false}).ToList(); _usersView=CollectionViewSource.GetDefaultView(_profileUsers); UsersGrid.ItemsSource=_usersView; ApplyUserFilter();}catch(Exception ex){MessageBox.Show(ex.Message,"Perfiles");} }
    private async void ApplyClick(object s, RoutedEventArgs e) { if(ServerBox.SelectedItem is not ServerProfile server || DatabaseBox.SelectedItem is not string db){MessageBox.Show("Selecciona servidor y base.");return;} if(string.IsNullOrWhiteSpace(ProfileNameBox.Text)||string.IsNullOrWhiteSpace(SchemaBox.Text)){MessageBox.Show("Indica nombre y esquema.");return;} var p=new MaskProfile{ProfileName=ProfileNameBox.Text.Trim(),TargetSchema=SchemaBox.Text.Trim(),ServerName=server.Name,DatabaseName=db}; foreach(var c in _columns)p.Rules.Add(c); foreach(var u in _profileUsers.Where(x=>x.IsSelected&&!x.IsProtected))p.Users.Add(u.Name); try{await _db.SaveMaskProfileAsync(p); await _deployment.ApplyProfileAsync(p,server,_patterns); await _db.AuditAsync("Perfiles","Aplicar",true,p.ProfileName,server.Name,db); MessageBox.Show("Perfil aplicado correctamente."); DialogResult=true;}catch(Exception ex){await _db.AuditAsync("Perfiles","Aplicar",false,ex.Message,server.Name,db);MessageBox.Show(ex.Message,"Perfiles");} }
    private void ColumnFilterChanged(object sender, System.Windows.Controls.TextChangedEventArgs e) => ApplyColumnFilter();
    private void UserFilterChanged(object sender, System.Windows.Controls.TextChangedEventArgs e) => ApplyUserFilter();
    private void ApplyColumnFilter()
    {
        if (_columnsView is null) return;
        _columnsView.Filter = item => item is ProfileColumnRule row
            && Contains(row.Schema, SchemaFilterBox.Text)
            && Contains(row.Table, TableFilterBox.Text)
            && Contains(row.Column, ColumnFilterBox.Text);
        _columnsView.Refresh();
    }
    private void ApplyUserFilter()
    {
        if (_usersView is null) return;
        var filter = UserFilterBox.Text;
        _usersView.Filter = item => item is ProfileUserChoice row
            && (Contains(row.Name, filter) || Contains(row.Type, filter));
        _usersView.Refresh();
    }
    private static bool Contains(string value, string filter) =>
        string.IsNullOrWhiteSpace(filter) || value.Contains(filter.Trim(), StringComparison.OrdinalIgnoreCase);
    private void CloseClick(object s, RoutedEventArgs e)=>Close();
}
