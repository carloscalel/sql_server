using System.ComponentModel;
using System.Windows;

namespace OfuscadorTool;

public partial class ProgressDialog : Window
{
    private readonly CancellationTokenSource _cancellation = new();
    private bool _allowClose;

    public CancellationToken CancellationToken => _cancellation.Token;

    public ProgressDialog(string stage)
    {
        InitializeComponent(); StageText.Text = stage;
    }

    public void UpdateProgress(int current, int total, string detail)
    {
        if (!Dispatcher.CheckAccess())
        {
            Dispatcher.Invoke(() => UpdateProgress(current, total, detail));
            return;
        }

        var percent = total <= 0 ? 0 : Math.Clamp((int)Math.Round(current * 100d / total), 0, 100);
        Progress.Value = percent;
        PercentText.Text = $"{percent}%";
        DetailText.Text = detail;
    }

    private void CancelClick(object sender, RoutedEventArgs e) => RequestCancellation();

    private void RequestCancellation()
    {
        if (_cancellation.IsCancellationRequested) return;
        _cancellation.Cancel();
        DetailText.Text = "Cancelando consultas pendientes...";
        CancelButton.IsEnabled = false;
        CancelButton.Content = "Cancelando...";
    }

    protected override void OnClosing(CancelEventArgs e)
    {
        if (!_allowClose)
        {
            e.Cancel = true;
            RequestCancellation();
            return;
        }

        base.OnClosing(e);
    }

    public void CompleteAndClose()
    {
        _allowClose = true;
        Close();
        _cancellation.Dispose();
    }
}
