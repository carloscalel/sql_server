using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Controls;

namespace OfuscadorTool;

public partial class MaskExceptionDialog : Window
{
    private readonly DatabaseService _db;
    private readonly IReadOnlyCollection<ServerProfile> _servers;
    private readonly ObservableCollection<ExceptionColumnChoice> _columns = [];
    private List<DatabaseObjectColumn> _metadata = [];
    private bool _suppressSelection;
    private int _loadVersion;

    public IReadOnlyList<MaskException> Results { get; private set; } = [];

    public MaskExceptionDialog(DatabaseService db, IReadOnlyCollection<ServerProfile> servers)
    {
        InitializeComponent();
        _db = db;
        _servers = servers.Where(x => x.IsActive).ToList();
        ServerBox.ItemsSource = _servers;
        ColumnsGrid.ItemsSource = _columns;
        Loaded += (_, _) =>
        {
            if (ServerBox.Items.Count > 0) ServerBox.SelectedIndex = 0;
            else MetadataStatusText.Text = "No hay servidores activos registrados.";
        };
    }

    private async void ServerChanged(object sender, SelectionChangedEventArgs e)
    {
        if (_suppressSelection || ServerBox.SelectedItem is not ServerProfile server) return;
        var request = ++_loadVersion;
        ClearMetadata("Cargando bases de datos...");
        _suppressSelection = true;
        DatabaseBox.ItemsSource = null;
        DatabaseBox.IsEnabled = false;
        _suppressSelection = false;
        try
        {
            var databases = await _db.LoadDatabasesAsync(server);
            if (request != _loadVersion) return;
            _suppressSelection = true;
            DatabaseBox.ItemsSource = databases;
            DatabaseBox.SelectedIndex = databases.Count > 0 ? 0 : -1;
            DatabaseBox.IsEnabled = true;
            _suppressSelection = false;
            if (DatabaseBox.SelectedItem is string database)
                await LoadMetadataAsync(server, database, request);
            else MetadataStatusText.Text = "El servidor no devolvió bases de datos disponibles.";
        }
        catch (Exception ex)
        {
            if (request == _loadVersion) MetadataStatusText.Text = "No se pudieron cargar las bases.";
            MessageBox.Show(ex.Message, "Error", MessageBoxButton.OK, MessageBoxImage.Error);
        }
        finally
        {
            _suppressSelection = false;
            if (request == _loadVersion) DatabaseBox.IsEnabled = true;
        }
    }

    private async void DatabaseChanged(object sender, SelectionChangedEventArgs e)
    {
        if (_suppressSelection || ServerBox.SelectedItem is not ServerProfile server
            || DatabaseBox.SelectedItem is not string database) return;
        var request = ++_loadVersion;
        await LoadMetadataAsync(server, database, request);
    }

    private async Task LoadMetadataAsync(ServerProfile server, string database, int request)
    {
        ClearMetadata($"Cargando tablas de {database}...");
        try
        {
            var metadata = await _db.LoadDatabaseObjectColumnsAsync(server, database);
            if (request != _loadVersion
                || ServerBox.SelectedItem is not ServerProfile currentServer
                || !currentServer.Name.Equals(server.Name, StringComparison.OrdinalIgnoreCase)
                || !string.Equals(DatabaseBox.SelectedItem as string, database, StringComparison.OrdinalIgnoreCase)) return;

            _metadata = metadata;
            var schemas = metadata.Select(x => x.SchemaName).Distinct(StringComparer.OrdinalIgnoreCase).ToList();
            _suppressSelection = true;
            SchemaBox.ItemsSource = schemas;
            SchemaBox.SelectedIndex = schemas.Count > 0 ? 0 : -1;
            _suppressSelection = false;
            PopulateTables();
            var tableCount = metadata.Select(x => $"{x.SchemaName}.{x.TableName}").Distinct(StringComparer.OrdinalIgnoreCase).Count();
            MetadataStatusText.Text = $"{tableCount} tabla(s) cargadas desde {server.Name}/{database}.";
        }
        catch (Exception ex)
        {
            if (request == _loadVersion) MetadataStatusText.Text = "No se pudieron cargar tablas y columnas.";
            MessageBox.Show(ex.Message, "Error", MessageBoxButton.OK, MessageBoxImage.Error);
        }
        finally { _suppressSelection = false; }
    }

    private void ClearMetadata(string status)
    {
        _metadata = [];
        _suppressSelection = true;
        SchemaBox.ItemsSource = null;
        TableBox.ItemsSource = null;
        _columns.Clear();
        _suppressSelection = false;
        MetadataStatusText.Text = status;
    }

    private void SchemaChanged(object sender, SelectionChangedEventArgs e)
    {
        if (!_suppressSelection) PopulateTables();
    }

    private void PopulateTables()
    {
        if (SchemaBox.SelectedItem is not string schema)
        {
            TableBox.ItemsSource = null;
            _columns.Clear();
            return;
        }
        var tables = _metadata.Where(x => x.SchemaName.Equals(schema, StringComparison.OrdinalIgnoreCase))
            .Select(x => x.TableName).Distinct(StringComparer.OrdinalIgnoreCase).ToList();
        _suppressSelection = true;
        TableBox.ItemsSource = tables;
        TableBox.SelectedIndex = tables.Count > 0 ? 0 : -1;
        _suppressSelection = false;
        PopulateColumns();
    }

    private void TableChanged(object sender, SelectionChangedEventArgs e)
    {
        if (!_suppressSelection) PopulateColumns();
    }

    private void PopulateColumns()
    {
        _columns.Clear();
        if (SchemaBox.SelectedItem is not string schema || TableBox.SelectedItem is not string table) return;
        foreach (var item in _metadata.Where(x => x.SchemaName.Equals(schema, StringComparison.OrdinalIgnoreCase)
                     && x.TableName.Equals(table, StringComparison.OrdinalIgnoreCase)))
            _columns.Add(new()
            {
                ColumnName = item.ColumnName,
                DataType = item.DataType,
                IsComputed = item.IsComputed
            });
    }

    private void ActionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (ColumnsGroup is null || HelpText is null) return;
        var createView = CurrentAction() == "CREAR_VISTA_TABLA";
        ColumnsGroup.IsEnabled = !createView;
        HelpText.Text = createView
            ? "Crear vista de toda la tabla: se aplicarán expresiones de vista según las reglas. Para omitir columnas, agrega además una excepción de columna."
            : "No ofuscar columnas: marca una o varias columnas. Las demás columnas sensibles continúan con DDM.";
    }

    private void SelectAllColumnsClick(object sender, RoutedEventArgs e)
    {
        foreach (var item in _columns) item.IsSelected = true;
        ColumnsGrid.Items.Refresh();
    }

    private void ClearColumnsClick(object sender, RoutedEventArgs e)
    {
        foreach (var item in _columns) item.IsSelected = false;
        ColumnsGrid.Items.Refresh();
    }

    private string CurrentAction() =>
        (ActionBox.SelectedItem as ComboBoxItem)?.Tag?.ToString() ?? "NO_OFUSCAR_COLUMNA";

    private void SaveClick(object sender, RoutedEventArgs e)
    {
        ColumnsGrid.CommitEdit(DataGridEditingUnit.Cell, true);
        ColumnsGrid.CommitEdit(DataGridEditingUnit.Row, true);
        if (ServerBox.SelectedItem is not ServerProfile server || DatabaseBox.SelectedItem is not string database
            || SchemaBox.SelectedItem is not string schema || TableBox.SelectedItem is not string table)
        { MessageBox.Show("Selecciona servidor, base, esquema y tabla."); return; }

        var action = CurrentAction();
        var selectedColumns = _columns.Where(x => x.IsSelected).ToList();
        if (action == "NO_OFUSCAR_COLUMNA" && selectedColumns.Count == 0)
        { MessageBox.Show("Marca al menos una columna que no se ofuscará."); return; }

        Results = action == "CREAR_VISTA_TABLA"
            ? [CreateResult(server, database, schema, table, null, action)]
            : selectedColumns.Select(x => CreateResult(server, database, schema, table, x.ColumnName, action)).ToList();
        DialogResult = true;
    }

    private MaskException CreateResult(ServerProfile server, string database, string schema,
        string table, string? column, string action) => new()
    {
        ServerName = server.Name, DatabaseName = database, SchemaName = schema,
        TableName = table, ColumnName = column, ActionName = action, IsActive = true,
        Notes = NotesBox.Text.Trim()
    };

    private void CancelClick(object sender, RoutedEventArgs e) => DialogResult = false;
}
