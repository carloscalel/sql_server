using System.Windows;

namespace OfuscadorTool;

public partial class PasswordDialog : Window
{
    public string Password => ValueBox.Password;
    public PasswordDialog() => InitializeComponent();
    private void OkClick(object sender, RoutedEventArgs e) { DialogResult = true; Close(); }
    private void CancelClick(object sender, RoutedEventArgs e) { DialogResult = false; Close(); }
}
