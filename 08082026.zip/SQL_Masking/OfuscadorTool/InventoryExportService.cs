using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Text;
using System.Xml;

namespace OfuscadorTool;

public static class InventoryExportService
{
    private static readonly string[] Headers =
    [
        "Servidor", "Base de datos", "Esquema", "Tabla", "Columna",
        "Protección", "Regla aplicada", "Estado", "Verificado"
    ];

    public static void ExportCsv(string path, IReadOnlyList<MaskingInventoryRow> rows)
    {
        using var writer = new StreamWriter(path, false, new UTF8Encoding(true));
        writer.WriteLine(string.Join(';', Headers.Select(Csv)));
        foreach (var row in rows)
            writer.WriteLine(string.Join(';', Values(row).Select(Csv)));
    }

    public static void ExportXlsx(string path, IReadOnlyList<MaskingInventoryRow> rows)
    {
        using var file = new FileStream(path, FileMode.Create, FileAccess.Write, FileShare.None);
        using var zip = new ZipArchive(file, ZipArchiveMode.Create);
        WriteText(zip, "[Content_Types].xml", """
            <?xml version="1.0" encoding="UTF-8" standalone="yes"?>
            <Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
              <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
              <Default Extension="xml" ContentType="application/xml"/>
              <Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>
              <Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>
              <Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>
              <Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/>
              <Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/>
            </Types>
            """);
        WriteText(zip, "_rels/.rels", """
            <?xml version="1.0" encoding="UTF-8" standalone="yes"?>
            <Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
              <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>
              <Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/>
              <Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties" Target="docProps/app.xml"/>
            </Relationships>
            """);
        WriteText(zip, "xl/workbook.xml", """
            <?xml version="1.0" encoding="UTF-8" standalone="yes"?>
            <workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
              <sheets><sheet name="Inventario" sheetId="1" r:id="rId1"/></sheets>
            </workbook>
            """);
        WriteText(zip, "xl/_rels/workbook.xml.rels", """
            <?xml version="1.0" encoding="UTF-8" standalone="yes"?>
            <Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
              <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>
              <Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>
            </Relationships>
            """);
        WriteText(zip, "xl/styles.xml", """
            <?xml version="1.0" encoding="UTF-8" standalone="yes"?>
            <styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
              <fonts count="2"><font><sz val="10"/><name val="Calibri"/></font><font><b/><color rgb="FFFFFFFF"/><sz val="10"/><name val="Calibri"/></font></fonts>
              <fills count="3"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FF2563EB"/><bgColor indexed="64"/></patternFill></fill></fills>
              <borders count="2"><border/><border><left style="thin"><color rgb="FFDDE3EC"/></left><right style="thin"><color rgb="FFDDE3EC"/></right><top style="thin"><color rgb="FFDDE3EC"/></top><bottom style="thin"><color rgb="FFDDE3EC"/></bottom></border></borders>
              <cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>
              <cellXfs count="3"><xf numFmtId="0" fontId="0" fillId="0" borderId="1" xfId="0" applyBorder="1"/><xf numFmtId="0" fontId="1" fillId="2" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1"/><xf numFmtId="0" fontId="0" fillId="0" borderId="1" xfId="0" applyBorder="1"><alignment wrapText="1" vertical="top"/></xf></cellXfs>
              <cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>
            </styleSheet>
            """);
        WriteText(zip, "docProps/app.xml", """
            <?xml version="1.0" encoding="UTF-8" standalone="yes"?>
            <Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties"><Application>OfuscadorTool</Application></Properties>
            """);
        var now = DateTime.UtcNow.ToString("yyyy-MM-dd'T'HH:mm:ss'Z'", CultureInfo.InvariantCulture);
        WriteText(zip, "docProps/core.xml", $"""
            <?xml version="1.0" encoding="UTF-8" standalone="yes"?>
            <cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"><dc:creator>OfuscadorTool</dc:creator><dc:title>Inventario de ofuscamiento</dc:title><dcterms:created xsi:type="dcterms:W3CDTF">{now}</dcterms:created></cp:coreProperties>
            """);

        var entry = zip.CreateEntry("xl/worksheets/sheet1.xml", CompressionLevel.Optimal);
        using var stream = entry.Open();
        using var xml = XmlWriter.Create(stream, new XmlWriterSettings { Encoding = new UTF8Encoding(false), Indent = false });
        xml.WriteStartDocument(true);
        xml.WriteStartElement("worksheet", "http://schemas.openxmlformats.org/spreadsheetml/2006/main");
        xml.WriteStartElement("sheetViews");
        xml.WriteStartElement("sheetView"); xml.WriteAttributeString("workbookViewId", "0");
        xml.WriteStartElement("pane"); xml.WriteAttributeString("ySplit", "1"); xml.WriteAttributeString("topLeftCell", "A2"); xml.WriteAttributeString("state", "frozen"); xml.WriteEndElement();
        xml.WriteEndElement(); xml.WriteEndElement();
        xml.WriteStartElement("cols");
        var widths = new[] { 18d, 22d, 14d, 22d, 24d, 20d, 36d, 20d, 21d };
        for (var i = 0; i < widths.Length; i++)
        {
            xml.WriteStartElement("col"); xml.WriteAttributeString("min", (i + 1).ToString());
            xml.WriteAttributeString("max", (i + 1).ToString()); xml.WriteAttributeString("width", widths[i].ToString(CultureInfo.InvariantCulture));
            xml.WriteAttributeString("customWidth", "1"); xml.WriteEndElement();
        }
        xml.WriteEndElement();
        xml.WriteStartElement("sheetData");
        WriteXlsxRow(xml, 1, Headers, 1);
        for (var i = 0; i < rows.Count; i++) WriteXlsxRow(xml, i + 2, Values(rows[i]), 2);
        xml.WriteEndElement();
        xml.WriteStartElement("autoFilter"); xml.WriteAttributeString("ref", $"A1:I{Math.Max(1, rows.Count + 1)}"); xml.WriteEndElement();
        xml.WriteEndElement();
        xml.WriteEndDocument();
    }

    public static void ExportPdf(string path, IReadOnlyList<MaskingInventoryRow> rows)
    {
        const int rowsPerPage = 27;
        var pages = Math.Max(1, (int)Math.Ceiling(rows.Count / (double)rowsPerPage));
        var objects = new List<byte[]>
        {
            Array.Empty<byte>(), Array.Empty<byte>(),
            Encoding.Latin1.GetBytes("<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>")
        };
        var pageIds = new List<int>();
        for (var page = 0; page < pages; page++)
        {
            var content = BuildPdfPage(rows.Skip(page * rowsPerPage).Take(rowsPerPage).ToList(), page + 1, pages);
            var pageId = objects.Count + 1;
            var contentId = pageId + 1;
            pageIds.Add(pageId);
            objects.Add(Encoding.Latin1.GetBytes($"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 842 595] /Resources << /Font << /F1 3 0 R >> >> /Contents {contentId} 0 R >>"));
            var contentBytes = Encoding.Latin1.GetBytes(content);
            objects.Add(Combine(Encoding.ASCII.GetBytes($"<< /Length {contentBytes.Length} >>\nstream\n"), contentBytes, Encoding.ASCII.GetBytes("\nendstream")));
        }
        objects[0] = Encoding.ASCII.GetBytes("<< /Type /Catalog /Pages 2 0 R >>");
        objects[1] = Encoding.ASCII.GetBytes($"<< /Type /Pages /Kids [{string.Join(' ', pageIds.Select(x => $"{x} 0 R"))}] /Count {pageIds.Count} >>");

        using var output = new MemoryStream();
        WriteBytes(output, Encoding.Latin1.GetBytes("%PDF-1.4\n%âãÏÓ\n"));
        var offsets = new List<long> { 0 };
        for (var i = 0; i < objects.Count; i++)
        {
            offsets.Add(output.Position);
            WriteBytes(output, Encoding.ASCII.GetBytes($"{i + 1} 0 obj\n"));
            WriteBytes(output, objects[i]);
            WriteBytes(output, Encoding.ASCII.GetBytes("\nendobj\n"));
        }
        var xref = output.Position;
        WriteBytes(output, Encoding.ASCII.GetBytes($"xref\n0 {objects.Count + 1}\n0000000000 65535 f \n"));
        foreach (var offset in offsets.Skip(1)) WriteBytes(output, Encoding.ASCII.GetBytes($"{offset:0000000000} 00000 n \n"));
        WriteBytes(output, Encoding.ASCII.GetBytes($"trailer\n<< /Size {objects.Count + 1} /Root 1 0 R >>\nstartxref\n{xref}\n%%EOF"));
        File.WriteAllBytes(path, output.ToArray());
    }

    private static string BuildPdfPage(IReadOnlyList<MaskingInventoryRow> rows, int page, int totalPages)
    {
        var sb = new StringBuilder();
        sb.AppendLine("0.15 0.27 0.60 rg BT /F1 17 Tf 28 558 Td (Inventario de ofuscamiento) Tj ET");
        sb.AppendLine($"0.25 0.30 0.38 rg BT /F1 8 Tf 28 541 Td ({Pdf($"Generado: {DateTime.Now:g}   Página {page} de {totalPages}")}) Tj ET");
        var widths = new[] { 75d, 85d, 55d, 75d, 95d, 75d, 150d, 75d };
        var headers = Headers.Take(8).ToArray();
        var x = 28d; var y = 516d; const double height = 17;
        sb.AppendLine($"0.15 0.39 0.92 rg {x} {y} {widths.Sum()} {height} re f");
        for (var i = 0; i < headers.Length; i++)
        {
            sb.AppendLine($"1 1 1 rg BT /F1 7 Tf {x + 3:0.##} {y + 5:0.##} Td ({Pdf(Truncate(headers[i], widths[i]))}) Tj ET");
            x += widths[i];
        }
        y -= height;
        foreach (var row in rows)
        {
            x = 28;
            sb.AppendLine($"0.86 0.89 0.93 RG 0.4 w {x} {y} {widths.Sum()} {height} re S");
            var values = Values(row).Take(8).ToArray();
            for (var i = 0; i < values.Length; i++)
            {
                sb.AppendLine($"0.12 0.16 0.23 rg BT /F1 6.7 Tf {x + 3:0.##} {y + 5:0.##} Td ({Pdf(Truncate(values[i], widths[i]))}) Tj ET");
                x += widths[i];
            }
            y -= height;
        }
        return sb.ToString();
    }

    private static IEnumerable<string> Values(MaskingInventoryRow row) =>
    [row.Server, row.Database, row.Schema, row.Table, row.Column, row.ProtectionType,
     row.MaskingRule, row.State, row.CheckedAt.ToString("g")];

    private static string Csv(string? value)
    {
        value ??= "";
        return $"\"{value.Replace("\"", "\"\"")}\"";
    }

    private static void WriteText(ZipArchive zip, string name, string value)
    {
        var entry = zip.CreateEntry(name, CompressionLevel.Optimal);
        using var writer = new StreamWriter(entry.Open(), new UTF8Encoding(false));
        writer.Write(value);
    }

    private static void WriteXlsxRow(XmlWriter xml, int number, IEnumerable<string> values, int style)
    {
        xml.WriteStartElement("row"); xml.WriteAttributeString("r", number.ToString());
        var column = 0;
        foreach (var value in values)
        {
            column++;
            xml.WriteStartElement("c"); xml.WriteAttributeString("r", $"{ColumnName(column)}{number}");
            xml.WriteAttributeString("t", "inlineStr"); xml.WriteAttributeString("s", style.ToString());
            xml.WriteStartElement("is"); xml.WriteStartElement("t"); xml.WriteAttributeString("xml", "space", null, "preserve");
            xml.WriteString(value ?? ""); xml.WriteEndElement(); xml.WriteEndElement(); xml.WriteEndElement();
        }
        xml.WriteEndElement();
    }

    private static string ColumnName(int index)
    {
        var result = "";
        while (index > 0) { index--; result = (char)('A' + index % 26) + result; index /= 26; }
        return result;
    }

    private static string Truncate(string value, double width)
    {
        var max = Math.Max(4, (int)(width / 4.2));
        return value.Length <= max ? value : value[..Math.Max(1, max - 1)] + "…";
    }

    private static string Pdf(string value) => value.Replace("\\", "\\\\").Replace("(", "\\(").Replace(")", "\\)")
        .Replace('\r', ' ').Replace('\n', ' ');
    private static byte[] Combine(params byte[][] arrays)
    {
        var result = new byte[arrays.Sum(x => x.Length)]; var offset = 0;
        foreach (var array in arrays) { Buffer.BlockCopy(array, 0, result, offset, array.Length); offset += array.Length; }
        return result;
    }
    private static void WriteBytes(Stream stream, byte[] bytes) => stream.Write(bytes, 0, bytes.Length);
}
