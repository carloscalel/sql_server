using Microsoft.Data.SqlClient;
using System.Windows;
using System.Windows.Media;

namespace OfuscadorTool;

public partial class LoginWindow : Window
{
    private CancellationTokenSource? _loginCancellation;

    public LoginWindow() => InitializeComponent();

    private void AuthChanged(object sender, RoutedEventArgs e)
    {
        if (UserBox is null || PasswordBox is null) return;
        var sql = WindowsBox.IsChecked != true;
        UserBox.IsEnabled = sql;
        PasswordBox.IsEnabled = sql;
        if (!sql)
        {
            UserBox.Clear();
            PasswordBox.Clear();
        }
    }

    private async void LoginClick(object sender, RoutedEventArgs e)
    {
        if (_loginCancellation is not null) return;
        using var cancellation = new CancellationTokenSource();
        _loginCancellation = cancellation;
        SetConnectingState(true);
        StatusText.Text = "";
        StatusBorder.Visibility = Visibility.Collapsed;

        try
        {
            var token = cancellation.Token;
            var source = string.IsNullOrWhiteSpace(InstanceBox.Text)
                ? HostBox.Text.Trim()
                : $@"{HostBox.Text.Trim()}\{InstanceBox.Text.Trim()}";
            var useWindows = WindowsBox.IsChecked == true;
            var master = DatabaseService.BuildConnection(source, "master", useWindows,
                UserBox.Text.Trim(), PasswordBox.Password, EncryptBox.IsChecked == true,
                TrustBox.IsChecked == true);

            await using (var cn = new SqlConnection(master))
                await cn.OpenAsync(token);

            var admin = DatabaseBox.Text.Trim();
            var adminCs = DatabaseService.BuildConnection(source, admin, useWindows,
                UserBox.Text.Trim(), PasswordBox.Password, EncryptBox.IsChecked == true,
                TrustBox.IsChecked == true);
            var principal = useWindows
                ? Environment.UserDomainName + "\\" + Environment.UserName
                : UserBox.Text.Trim();
            var contextBase = new LoginContext(adminCs, principal, admin, "");
            var db = new DatabaseService(contextBase);

            await db.ValidateInstallationAsync(token);
            var role = await db.GetUserRoleAsync(token);
            if (role is null)
                throw new UnauthorizedAccessException("La identidad no está activa en Usuarios autorizados.");

            var context = contextBase with { Role = role };
            await db.AuditAsync("Login", "Ingresar", true, $"Rol={role}", cancellationToken: token);
            token.ThrowIfCancellationRequested();
            new MainWindow(context).Show();
            Close();
        }
        catch (OperationCanceledException)
        {
            ShowStatus("Conexión cancelada. Corrige los datos e inténtalo nuevamente.", false);
        }
        catch (Exception ex)
        {
            ShowStatus(ex.Message, true);
        }
        finally
        {
            if (ReferenceEquals(_loginCancellation, cancellation)) _loginCancellation = null;
            SetConnectingState(false);
        }
    }

    private void CancelConnectionClick(object sender, RoutedEventArgs e)
    {
        if (_loginCancellation is null) return;
        CancelConnectionButton.IsEnabled = false;
        ShowStatus("Cancelando la conexión...", false);
        _loginCancellation.Cancel();
    }

    private void SetConnectingState(bool connecting)
    {
        LoginButton.IsEnabled = !connecting;
        LoginButton.Content = connecting ? "Conectando..." : "Ingresar";
        CancelConnectionButton.Visibility = connecting ? Visibility.Visible : Visibility.Collapsed;
        CancelConnectionButton.IsEnabled = connecting;
        CancelConnectionButton.IsCancel = connecting;
        ExitButton.IsEnabled = !connecting;
        ExitButton.IsCancel = !connecting;
        ServerSettingsGroup.IsEnabled = !connecting;
        AuthSettingsGroup.IsEnabled = !connecting;
        TransportSettingsBorder.IsEnabled = !connecting;
    }

    private void ShowStatus(string message, bool error)
    {
        StatusText.Text = message;
        StatusText.Foreground = error ? Brushes.Firebrick : new SolidColorBrush(Color.FromRgb(29, 78, 216));
        StatusBorder.Background = error
            ? new SolidColorBrush(Color.FromRgb(254, 242, 242))
            : new SolidColorBrush(Color.FromRgb(239, 246, 255));
        StatusBorder.BorderBrush = error
            ? new SolidColorBrush(Color.FromRgb(254, 202, 202))
            : new SolidColorBrush(Color.FromRgb(191, 219, 254));
        StatusBorder.Visibility = Visibility.Visible;
    }

    private void ExitClick(object sender, RoutedEventArgs e)
    {
        _loginCancellation?.Cancel();
        Close();
    }
}
