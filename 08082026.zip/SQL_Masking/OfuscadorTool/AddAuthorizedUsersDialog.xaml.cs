using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Windows;
using System.Windows.Data;

namespace OfuscadorTool;

public partial class AddAuthorizedUsersDialog : Window
{
    private readonly DatabaseService _db;
    private readonly HashSet<string> _existing;
    private ICollectionView? _view;
    public ObservableCollection<PivotLoginOption> Logins { get; } = [];
    public string[] Roles { get; } = ["Administrator", "Operator", "Auditor"];
    public List<PivotLoginOption> SelectedUsers { get; private set; } = [];

    public AddAuthorizedUsersDialog(DatabaseService db, HashSet<string> existing)
    {
        InitializeComponent(); _db = db; _existing = existing; RoleColumn.ItemsSource = Roles; DataContext = this;
        Loaded += async (_, _) => await LoadAsync();
    }

    private async Task LoadAsync()
    {
        try
        {
            Logins.Clear();
            foreach (var login in await _db.LoadPivotLoginsAsync())
                if (!_existing.Contains(login.Login)) Logins.Add(login);
            _view = CollectionViewSource.GetDefaultView(Logins);
            _view.Filter = Filter;
            UpdateCount();
        }
        catch (Exception ex) { MessageBox.Show(ex.Message, "No se pudieron cargar los logins", MessageBoxButton.OK, MessageBoxImage.Error); }
    }

    private bool Filter(object item)
    {
        var text = FilterBox?.Text?.Trim();
        return string.IsNullOrEmpty(text) || ((PivotLoginOption)item).Login.Contains(text, StringComparison.OrdinalIgnoreCase);
    }

    private void FilterChanged(object sender, System.Windows.Controls.TextChangedEventArgs e) { _view?.Refresh(); UpdateCount(); }
    private void UpdateCount() => CountText.Text = $"Disponibles: {_view?.Cast<object>().Count() ?? Logins.Count}";
    private async void LoadClick(object sender, RoutedEventArgs e) => await LoadAsync();

    private void AddClick(object sender, RoutedEventArgs e)
    {
        SelectedUsers = Logins.Where(x => x.IsSelected && !_existing.Contains(x.Login)).ToList();
        if (SelectedUsers.Count == 0) { MessageBox.Show("Selecciona al menos un login."); return; }
        DialogResult = true; Close();
    }

    private void CancelClick(object sender, RoutedEventArgs e) { DialogResult = false; Close(); }
}
