# SQL Access Admin

Cliente WPF moderno en C# / .NET 8 para administrar accesos en múltiples instancias SQL Server desde un servidor pivote `adminDB`.

## Ejecutar

```powershell
dotnet restore
dotnet run --project src/SqlAccessAdmin/SqlAccessAdmin.csproj
```

La aplicación requiere que un DBA prepare previamente `adminDB` con los scripts de [InsumosProduccion](InsumosProduccion/README.md). El cliente no crea bases, tablas, tipos, roles ni procedimientos y no aplica migraciones automáticas. La UI implementa autenticación con el pivote, roles acumulables Administrador/Operador/AprobadorEjecutor/Auditor, alta y edición de servidores, prueba de conexión, selección de servidores y bases, asignación de login/rol, resultados por destino y auditoría.

## Conexiones directas

El botón **Cerrar sesión**, al pie del menú lateral, cierra todas las ventanas y termina la aplicación, liberando sus conexiones SQL y los pools del pivote y los destinos. Si hay cambios pendientes en Política de acceso o Usuarios autorizados, conserva la confirmación de descarte; cancelar mantiene la aplicación abierta.

En **1. Modificar accesos**, la cabecera conserva un único par de botones para enviar los cambios de permisos y cambiar de usuario. Junto al login se muestra su estado actual y una sola acción: **Deshabilitar login** si está habilitado, o **Habilitar login** si está deshabilitado. Esta acción exige ticket validado, pide confirmar el envío y genera una solicitud independiente para **Confirmar y ejecutar**, con destino exclusivo a la instancia seleccionada. Si había cambios de permisos en el borrador, el diálogo indica que se descartarán al enviar la solicitud de estado.

La baja bloquea los nuevos inicios de sesión mediante `ALTER LOGIN ... DISABLE`; conserva la cuenta y sus permisos y no cierra sesiones existentes. Los logins deshabilitados pueden cargarse para solicitar su habilitación, pero sus permisos de base no se pueden enviar mientras sigan deshabilitados. Se consulta el estado real al cargar y al solicitar el cambio; la ejecución vuelve a comprobarlo y rechaza habilitar un login ya habilitado o deshabilitar uno ya deshabilitado. Este cambio reutiliza las operaciones y solicitudes existentes y no necesita un script SQL nuevo.

`adminDB` funciona como catálogo y registro de auditoría. El cliente recupera únicamente los servidores autorizados y abre conexiones TLS directas a cada destino; no requiere linked servers. Para migrar una instalación anterior, el DBA debe ejecutar `08_ConfigurarConexionDirectaYCifrado.sql` y después volver a ejecutar los scripts `02`, `03`, `04` y `99`.

El flujo de administración de accesos requiere además [10_PoliticaSolicitudesEIntegridad.sql](InsumosProduccion/10_PoliticaSolicitudesEIntegridad.sql). Este insumo instala la allowlist, la denylist permanente, solicitudes y aprobaciones, y la cadena hash append-only de auditoría. Ninguno de estos objetos se crea automáticamente desde el cliente.

## Seguridad

La entrada exige una identidad registrada, activa y con roles explícitos, incluso para sysadmin. Windows reconoce DOMINIO\\usuario o EQUIPO\\usuario mediante el SID original, conservando el registro Windows cuando la conexión informa MicrosoftAccount. **Usuarios autorizados** permite seleccionar uno o varios roles: **Administrador** incluye todas las funciones; **Operador** crea solicitudes; **AprobadorEjecutor** confirma, rechaza y ejecuta; **Auditor** consulta resumen y auditoría. Sus permisos se suman, y las modificaciones de usuarios son exclusivas de Administrador. Las sesiones se bloquean al revocar acceso o cambiar una membresía. Aplique manualmente **30 → 31 → 99** después de 29 actualizado, despliegue el cliente de cuatro roles y reinicie todas las sesiones. Los Operator existentes no reciben aprobación automáticamente. Consulte [la guía de usuarios autorizados](docs/UsuariosAutorizados.md).

**Agregar usuario autorizado** permite seleccionar un login Windows individual o SQL existente y habilitado en la instancia de `adminDB`, sin escritura libre. El tipo se asigna automáticamente y se revalida la cuenta al guardar. Las cuentas ya registradas se modifican o reactivan desde la tabla. Para instalaciones con 30 completo, aplique manualmente [31_SeleccionUsuariosAutorizados.sql](InsumosProduccion/31_SeleccionUsuariosAutorizados.sql) y después 99 antes de desplegar el cliente actualizado.

La pantalla **Política de seguridad** permite habilitar o bloquear permisos y roles directamente en sus tablas, con búsqueda y filtros por estado. Los cambios de ambas pestañas se guardan juntos después de revisar una confirmación; **Descartar** restaura lo guardado. Los cambios pendientes también se advierten al actualizar, navegar o cerrar la ventana. Bloquear una opción impide usarla en solicitudes nuevas y pendientes; no retira los accesos existentes en SQL Server.

**Detalles avanzados** muestra las acciones **Asignar** y **Retirar**, el último cambio, la edición de descripciones de roles y opciones para registrar roles personalizados o consultar y agregar bloqueos obligatorios. Ambas pestañas utilizan el mismo botón **Habilitar…** y el mismo formulario: el Administrator indica un motivo, reconoce el riesgo y escribe el nombre exacto. **Autorizar y habilitar** registra la excepción inmediatamente, con identidad, fecha y auditoría. Es una doble confirmación, no un segundo factor de autenticación. Volver a bloquear y guardar retira la excepción; habilitar después exige autorizar nuevamente. Los roles de servidor, `public` y las combinaciones SQL no admitidas siguen fuera del contrato.

Se admiten SELECT, INSERT, UPDATE, DELETE, EXECUTE y REFERENCES en DATABASE/OBJECT/SCHEMA; en COLUMN únicamente SELECT, UPDATE y REFERENCES. SCHEMA, COLUMN y REFERENCES requieren autorización especial por combinación exacta de permiso y alcance. La edición de accesos mantiene la matriz por objeto y añade una sección plegable para permisos de base, esquema o columna. La copia conserva esos alcances y nunca agrega delegación. Un permiso de columna puede prevalecer sobre una denegación de objeto: el formulario advierte este riesgo ([documentación de SQL Server](https://learn.microsoft.com/en-us/sql/t-sql/statements/grant-object-permissions-transact-sql)).

Las excepciones se revalidan en las solicitudes, copia y ejecución. Si el guardado falla parcialmente, conserva los cambios pendientes e informa cuántos se guardaron. Aplique manualmente `25` después de `24` y después [26_ValidacionCompartidaPermisosRoles.sql](InsumosProduccion/26_ValidacionCompartidaPermisosRoles.sql), ejecute `99` y reinicie. La migración registra las combinaciones nuevas deshabilitadas: no habilita accesos ni excepciones automáticamente. La aplicación no instala estos scripts por sí sola.

El formulario **2. Crear usuario** se organiza en un asistente: **General y cuenta**, **Mapeo de bases** y **Permisos a objetos**. Ticket y justificación permanecen obligatorios en el primer paso. Mapeo y permisos a objetos son opciones independientes: puede elegir cualquiera, ambas o ninguna. Al elegir solo objetos, pasa directamente al paso 2 de objetos y selecciona la base allí; el usuario de esa base se crea automáticamente, sin asignar roles o permisos generales. Anterior vuelve al paso anterior habilitado y conserva el borrador; Cancelar lo descarta. El envío genera una sola solicitud y mantiene la confirmación y ejecución separadas.

Los roles y permisos generales se aplican a todas las bases marcadas. Los permisos por objeto requieren exactamente una base, como exige el contrato actual de solicitudes en `adminDB`. Si combina ambas opciones, la única base mapeada se usa también para objetos. Cambiar la base de objetos descarta sus selecciones anteriores; desactivar el mapeo conserva la opción de objetos y permite elegir su base de forma independiente. Este asistente reutiliza los scripts existentes y no requiere una migración nueva.

El selector incluye funciones definidas por el usuario SQL/CLR y un filtro por tipo de objeto. Las funciones escalares permiten elegir `EXECUTE` y las tabulares `SELECT`, sujetos a la política central, tanto en Crear usuario como en Modificar accesos. El [análisis de viabilidad multibase](docs/ViabilidadPermisosMultibase.md) detalla los cambios necesarios para combinar roles y objetos de bases diferentes; esa ampliación todavía no está habilitada.

Los formularios **2. Crear usuario** y **3. Copiar permisos** permiten elegir **SQL authentication** o **Windows authentication**, un solo tipo por solicitud. SQL requiere contraseña temporal cifrada; Windows usa una identidad existente como `DOMINIO\usuario` o `EQUIPO\usuario` y no solicita contraseña SQL. Windows exige pulsar **Comprobar nombres**, que consulta `xp_logininfo` en el servidor seleccionado: muestra ✓ verde o ✕ roja y bloquea el envío si no hay una comprobación válida. Cambiar la identidad o el servidor invalida el resultado. La identidad se comprueba nuevamente al enviar y ejecutar. Aplique `24_AutenticacionSqlWindows.sql` después de `23`, ejecute `99` y reinicie. La conexión técnica requiere permiso de ejecución de `xp_logininfo` en `master`; consulte las instrucciones de infraestructura. El aplicativo registra el login en SQL Server; la cuenta Windows debe existir previamente.

- `Encrypt=True` por defecto en la conexión.
- No se requieren linked servers. El cliente abre conexiones TLS directas y las credenciales SQL se almacenan como sobres AES-256-GCM en `adminDB`.
- La clave AES-GCM aleatoria se guarda envuelta mediante una clave AES-256 protegida por certificado y Database Master Key de SQL Server.
- La contraseña del servidor nunca aparece en el listado y, al editar, puede dejarse vacía para conservar el sobre existente.
- Comandos parametrizados y `CommandType.StoredProcedure` exclusivamente.
- Si se habilita almacenamiento de credenciales, la clave de producción debe proceder de DPAPI/HSM/gestor de secretos; nunca debe almacenarse en el repositorio.

