using System.ComponentModel;
using System.Windows;
using SqlAccessAdmin.ViewModels;

namespace SqlAccessAdmin.Views;

public partial class MainWindow : Window
{
    public MainWindow() => InitializeComponent();
    private void Logout_Click(object sender, RoutedEventArgs e) => Close();

    protected override void OnClosing(CancelEventArgs e)
    {
        if (DataContext is MainViewModel { Current: PolicyViewModel policy } && !policy.ConfirmLeave()) e.Cancel = true;
        if (DataContext is MainViewModel { Current: UsersViewModel users } && !users.ConfirmLeave()) e.Cancel = true;
        base.OnClosing(e);
    }

    protected override void OnClosed(EventArgs e)
    {
        base.OnClosed(e);
        // Close() first honors pending-edit checks; accepted closure ends every window.
        Application.Current?.Shutdown();
    }
}
