using System.Windows;

namespace SqlAccessAdmin.Views;

public partial class ConfirmationWindow : Window
{
    public string Heading {get;}
    public string Message {get;}
    public string AcceptLabel {get;}

    public ConfirmationWindow(string heading,string message,string acceptLabel)
    {
        Heading=heading;Message=message;AcceptLabel=acceptLabel;
        InitializeComponent();DataContext=this;
    }

    public static bool Confirm(string heading,string message,string acceptLabel)
    {
        var window=new ConfirmationWindow(heading,message,acceptLabel);
        var owner=Application.Current?.Windows.OfType<Window>().FirstOrDefault(x=>x.IsActive)
            ??Application.Current?.MainWindow;
        if(owner is {IsVisible:true})window.Owner=owner;
        else window.WindowStartupLocation=WindowStartupLocation.CenterScreen;
        return window.ShowDialog()==true;
    }

    private void Accept_Click(object sender,RoutedEventArgs e)=>DialogResult=true;
    private void Cancel_Click(object sender,RoutedEventArgs e)=>DialogResult=false;
}
