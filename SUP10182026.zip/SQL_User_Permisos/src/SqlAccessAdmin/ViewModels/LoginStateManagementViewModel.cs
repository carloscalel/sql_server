using System.Windows;
using SqlAccessAdmin.Infrastructure;
using SqlAccessAdmin.Models;

namespace SqlAccessAdmin.ViewModels;

public sealed partial class AccessViewModel
{
    private bool _isSubmittingLoginStateChange;
    private bool _isSubmittingAccessRequest;
    private AsyncCommand? _changeManagedLoginStateCommand;
    public AsyncCommand ChangeManagedLoginStateCommand=>_changeManagedLoginStateCommand??=new(
        SubmitManagedLoginStateChangeAsync,()=>CanRequestManagedLoginStateChange);
    public string ManagedLoginStateText=>SelectedServerLogin?.Status??"Sin login seleccionado";
    public string ManagedLoginStateActionText=>SelectedServerLogin?.Enabled==false?"Habilitar login":"Deshabilitar login";
    public bool IsManagedLoginDisabled=>IsExistingAccessOperation&&SelectedServerLogin?.Enabled==false;
    public bool CanManageExistingLoginDatabaseAccess=>!IsManagedLoginDisabled;
    public string ManagedLoginStateHint=>SelectedServerLogin?.Enabled==false
        ? "Habilitar permitirá nuevos inicios de sesión. Requiere ticket, confirmación y ejecución."
        : "Deshabilitar impedirá nuevos inicios de sesión; conserva la cuenta y sus permisos. Requiere ticket, confirmación y ejecución.";
    public bool CanRequestManagedLoginStateChange=>CanCreateRequests&&IsExistingAccessOperation&&SelectedWorkingServer is not null
        &&Same(TargetPrincipal,SelectedServerLogin?.Name)&&!IsInternalOrServicePrincipal(TargetPrincipal)
        &&IsExternalTicketValid&&!IsVerifyingExternalTicket&&Justification.Trim().Length>=10&&!_requestSubmitted
        &&!_isStartingAccessManagement&&!_isSubmittingLoginStateChange&&!_isSubmittingAccessRequest
        &&Operations.Any(x=>x.Enabled&&x.Code==(SelectedServerLogin!.Enabled?"DISABLE_LOGIN":"ENABLE_LOGIN"));

    private void RefreshManagedLoginState()
    {
        Raise(nameof(ManagedLoginStateText));Raise(nameof(ManagedLoginStateActionText));Raise(nameof(ManagedLoginStateHint));
        Raise(nameof(CanRequestManagedLoginStateChange));
        Raise(nameof(IsManagedLoginDisabled));Raise(nameof(CanManageExistingLoginDatabaseAccess));
        _changeManagedLoginStateCommand?.Refresh();
    }

    private async Task SubmitManagedLoginStateChangeAsync()
    {
        if(!CanRequestManagedLoginStateChange)return;
        var server=SelectedWorkingServer!;
        var login=SelectedServerLogin!;
        var enable=!login.Enabled;
        var action=enable?"habilitar":"deshabilitar";
        var draft=new AccessRequestDraft(enable?"ENABLE_LOGIN":"DISABLE_LOGIN",login.Name,
            null,null,null,null,null,null,null,ExternalTicketNumber,Justification.Trim());
        var hasAccessChanges=DatabaseRoleChoices.Any(x=>x.HasChange)||ObjectPermissionRows.Any(x=>x.HasChange)
            ||PermissionChoices.Any(x=>x.IsSelected);
        var consequence=enable?"El login podrá volver a iniciar sesión con sus accesos asignados."
            :"Se bloquearán los nuevos inicios de sesión. La cuenta y sus permisos se conservarán; las sesiones abiertas no se cerrarán.";
        if(MessageBox.Show($"¿Enviar a confirmación la solicitud para {action} '{login.Name}' en {server.Name}?\n\n{consequence}\n\nTicket: {draft.ExternalTicketNumber}."
            +(hasAccessChanges?"\n\nLos cambios de permisos de este borrador no se incluirán y se descartarán al enviar esta solicitud.":""),
            $"Solicitar {action} login",MessageBoxButton.YesNo,MessageBoxImage.Warning,MessageBoxResult.No)!=MessageBoxResult.Yes)return;
        _isSubmittingLoginStateChange=true;RefreshManagedLoginState();SubmitCommand.Refresh();
        try
        {
            Status=$"Comprobando el estado actual de {login.Name}…";
            var enabled=await _direct.IsLoginEnabledAsync(server.Id,login.Name);
            EnsureCurrentContext();
            if(enabled!=login.Enabled)
            {
                UpdateManagedLoginState(login,enabled);
                throw new InvalidOperationException("El estado del login cambió en SQL Server. Revise la acción disponible y vuelva a solicitarla.");
            }
            IReadOnlyList<DatabaseItem> targets=[new(){ServerId=server.Id,Server=server.Name,Name="master",IsSelected=true}];
            var duplicate=await FindActiveDuplicateAsync(draft,targets,[]);
            if(duplicate is not null)throw new InvalidOperationException($"Ya existe la solicitud activa #{duplicate} para este cambio. Revísela en 'Confirmar y ejecutar'.");
            var decision=await _db.PreviewRequestTargetsAsync(draft,targets);
            if(!decision.Allowed)throw new InvalidOperationException(decision.Reason);
            EnsureCurrentContext();
            var id=await _db.CreateRequestAsync(draft,targets,[],null);
            // No se altera el estado mostrado hasta ejecutar realmente la solicitud.
            if(ReferenceEquals(SelectedWorkingServer,server)&&ReferenceEquals(SelectedServerLogin,login))
            {
                _requestSubmitted=true;SubmitCommand.Refresh();IsManagingAccess=false;SelectedAccessStep=3;
            }
            Status=$"Solicitud #{id} para {action} {login.Name} enviada. Confírmela y ejecútela en 'Confirmar y ejecutar'.";
        }
        catch(Exception error){Status=error.Message;}
        finally{_isSubmittingLoginStateChange=false;RefreshManagedLoginState();SubmitCommand.Refresh();}

        void EnsureCurrentContext()
        {
            if(!ReferenceEquals(SelectedWorkingServer,server)||!ReferenceEquals(SelectedServerLogin,login)
                ||!IsExistingAccessOperation||!IsExternalTicketValid||ExternalTicketNumber!=draft.ExternalTicketNumber
                ||Justification.Trim()!=draft.Justification||!Same(TargetPrincipal,login.Name))
                throw new InvalidOperationException("El usuario, servidor o ticket cambió durante la comprobación. Revise los datos y vuelva a solicitar el cambio.");
        }
    }

    private void UpdateManagedLoginState(ServerLoginItem login,bool enabled)
    {
        var updated=login with{Enabled=enabled};
        var index=ServerLogins.IndexOf(login);
        if(index>=0)ServerLogins[index]=updated;
        index=FilteredServerLogins.IndexOf(login);
        if(index>=0)FilteredServerLogins[index]=updated;
        SelectedServerLogin=updated;
        if(IsSelectedLogin&&SelectedSecurityNode!.Principal.Equals(login.Name,StringComparison.OrdinalIgnoreCase))SetSelectedLoginEnabled(enabled);
    }
}
