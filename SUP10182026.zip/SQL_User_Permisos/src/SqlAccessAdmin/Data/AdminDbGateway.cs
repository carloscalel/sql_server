using System.Data;
using Microsoft.Data.SqlClient;
using SqlAccessAdmin.Models;

namespace SqlAccessAdmin.Data;

public sealed partial class AdminDbGateway(PivotOptions options) : IPolicyStore, IAuthorizedUserStore
{
    private SessionContext? _session;
    public event Action<string>? AuthorizationLost;
    private string ConnectionString => new SqlConnectionStringBuilder { DataSource=options.DataSource, InitialCatalog=options.Database, IntegratedSecurity=options.IntegratedSecurity, UserID=options.User??"", Password=options.Password??"", Encrypt=options.Encrypt, TrustServerCertificate=options.TrustCertificate, ConnectTimeout=15, ApplicationName="SqlAccessAdmin" }.ConnectionString;
    public async Task<DataTable> ExecuteTableAsync(string procedure, IEnumerable<SqlParameter>? parameters=null, CancellationToken ct=default)
    {
        // Cada operación verifica el acceso vigente, incluso con una sesión ya abierta.
        await LoginAsync(ct);
        if(procedure=="access.usp_App_LoginContext")
            throw new InvalidOperationException("Use LoginAsync para consultar la autorización de la sesión.");
        return await ExecuteCoreAsync(procedure,parameters,ct);
    }
    private async Task<DataTable> ExecuteCoreAsync(string procedure, IEnumerable<SqlParameter>? parameters, CancellationToken ct)
    {
        await using var cn=new SqlConnection(ConnectionString); await using var cmd=new SqlCommand(procedure,cn){CommandType=CommandType.StoredProcedure,CommandTimeout=120};
        if(parameters!=null) cmd.Parameters.AddRange(parameters.ToArray()); await cn.OpenAsync(ct); await using var reader=await cmd.ExecuteReaderAsync(ct); var table=new DataTable(); table.Load(reader); return table;
    }
    public async Task TestAsync(CancellationToken ct=default)=>await LoginAsync(ct);
    public async Task<SessionContext> LoginAsync(CancellationToken ct=default)
    {
        try
        {
            var current=ReadLoginContext(await ExecuteCoreAsync("access.usp_App_LoginContext",null,ct));
            ValidateSession(_session,current);
            _session??=current;
            return current;
        }
        catch(UnauthorizedAccessException error){AuthorizationLost?.Invoke(error.Message);throw;}
    }
    private static void ValidateSession(SessionContext? original,SessionContext current)
    {
        if(original is not null&&original!=current)
            throw new UnauthorizedAccessException("Su identidad o rol de aplicación cambió. Cierre la aplicación e inicie sesión nuevamente.");
    }
    private static SessionContext ReadLoginContext(DataTable table)
    {
        const string installation="La autorización de adminDB debe actualizarse. Solicite al DBA aplicar 30_RolesMultiplesYSeparacionSolicitudes.sql y validar con 99.";
        if(table.Rows.Count!=1||!table.Columns.Contains("IsAuthorized")||!table.Columns.Contains("AuthorizationVersion")
            ||!table.Columns.Contains("Principal")||!table.Columns.Contains("Roles"))
            throw new UnauthorizedAccessException(installation);
        var row=table.Rows[0];
        if(row["AuthorizationVersion"] is not int version||version!=2)
            throw new UnauthorizedAccessException(installation);
        if(row["IsAuthorized"] is not true)
            throw new UnauthorizedAccessException(table.Columns.Contains("Detail")&&row["Detail"] is string detail
                ?detail:"El usuario no tiene acceso activo a la aplicación.");
        if(row["Principal"] is not string principal||string.IsNullOrWhiteSpace(principal)
            ||row["Roles"] is not string rolesJson)
            throw new UnauthorizedAccessException("El principal o rol autorizado en adminDB no es válido.");
        return new(principal,AppRoleCatalog.FromJson(rolesJson));
    }
    public async Task RequireCreateRequestsAsync(CancellationToken ct=default)
    {if(!(await LoginAsync(ct)).CanCreateRequests)throw new UnauthorizedAccessException("Se requiere Operador o Administrador para crear solicitudes.");}
    public async Task RequireReviewRequestsAsync(CancellationToken ct=default)
    {if(!(await LoginAsync(ct)).CanReviewRequests)throw new UnauthorizedAccessException("Se requiere AprobadorEjecutor o Administrador para confirmar, rechazar o ejecutar solicitudes.");}
    public async Task<IReadOnlyList<ServerItem>> GetServersAsync(CancellationToken ct=default)
    {
        var t=await ExecuteTableAsync("access.usp_Server_List",null,ct);
        return t.Rows.Cast<DataRow>().Select(r=>new ServerItem
        {
            Id=r.Field<int>("ServerId"),Active=r.Field<bool>("Active"),Name=r.Field<string>("Name")??"",
            Host=r.Field<string>("Host")??"",Instance=r.Field<string>("Instance")??"",WindowsAuth=r.Field<bool>("WindowsAuth"),
            SqlUser=r.Field<string>("SqlUser")??"",Encrypt=r.Field<bool>("Encrypt"),
            TrustCertificate=t.Columns.Contains("TrustCertificate")?r.Field<bool>("TrustCertificate"):t.Columns.Contains("TrustServerCertificate")&&r.Field<bool>("TrustServerCertificate"),
            TimeoutSeconds=t.Columns.Contains("TimeoutSeconds")?r.Field<int>("TimeoutSeconds"):30
        }).ToList();
    }

    public async Task<CryptoMaterial> GetCryptoMaterialAsync(CancellationToken ct=default)
    { var t=await ExecuteTableAsync("access.usp_Crypto_GetKey",null,ct);if(t.Rows.Count!=1||t.Rows[0]["MasterKey"] is DBNull)throw new InvalidOperationException("La clave central AES-GCM no está configurada.");return new(t.Rows[0].Field<Guid>("KeyId"),(byte[])t.Rows[0]["MasterKey"]); }

    public async Task<ServerConnectionInfo> GetServerConnectionAsync(int serverId,CancellationToken ct=default)
    { var t=await ExecuteTableAsync("access.usp_Server_GetConnection",[new("@ServerId",SqlDbType.Int){Value=serverId}],ct);if(t.Rows.Count==0)throw new InvalidOperationException("El servidor no existe o está deshabilitado.");var r=t.Rows[0];CredentialEnvelope? e=null;if(r["CredentialCiphertext"] is byte[] c)e=new(c,(byte[])r["CredentialNonce"],(byte[])r["CredentialTag"],Guid.Parse(r.Field<string>("CredentialKeyId")!));return new(r.Field<int>("ServerId"),r.Field<string>("Name")??"",r.Field<string>("Host")??"",r.Field<string>("Instance")??"",r.Field<bool>("WindowsAuth"),r.Field<string>("SqlUser")??"",e,r.Field<bool>("Encrypt"),r.Field<bool>("TrustServerCertificate"),r.Field<int>("TimeoutSeconds")); }

    public async Task SaveServerAsync(ServerEditData server,CredentialEnvelope? envelope,CancellationToken ct=default)
    { var p=new[]{new SqlParameter("@ServerId",SqlDbType.Int){Value=(object?)server.Id??DBNull.Value},new SqlParameter("@Name",SqlDbType.NVarChar,128){Value=server.Name},new SqlParameter("@Host",SqlDbType.NVarChar,255){Value=server.Host},new SqlParameter("@Instance",SqlDbType.NVarChar,128){Value=string.IsNullOrWhiteSpace(server.Instance)?DBNull.Value:server.Instance},new SqlParameter("@WindowsAuth",SqlDbType.Bit){Value=server.WindowsAuth},new SqlParameter("@SqlUser",SqlDbType.NVarChar,256){Value=string.IsNullOrWhiteSpace(server.SqlUser)?DBNull.Value:server.SqlUser},new SqlParameter("@CredentialCiphertext",SqlDbType.VarBinary,-1){Value=(object?)envelope?.Ciphertext??DBNull.Value},new SqlParameter("@CredentialNonce",SqlDbType.VarBinary,12){Value=(object?)envelope?.Nonce??DBNull.Value},new SqlParameter("@CredentialTag",SqlDbType.VarBinary,16){Value=(object?)envelope?.Tag??DBNull.Value},new SqlParameter("@CredentialKeyId",SqlDbType.NVarChar,200){Value=(object?)envelope?.KeyId.ToString()??DBNull.Value},new SqlParameter("@Encrypt",SqlDbType.Bit){Value=server.Encrypt},new SqlParameter("@TrustServerCertificate",SqlDbType.Bit){Value=server.TrustCertificate},new SqlParameter("@TimeoutSeconds",SqlDbType.Int){Value=server.TimeoutSeconds},new SqlParameter("@Active",SqlDbType.Bit){Value=server.Active}};await ExecuteTableAsync("access.usp_Server_Upsert",p,ct); }

    public async Task SetServerActiveAsync(int serverId,bool active,CancellationToken ct=default)=>await ExecuteTableAsync("access.usp_Server_SetActive",[new("@ServerId",SqlDbType.Int){Value=serverId},new("@Active",SqlDbType.Bit){Value=active}],ct);

    public async Task WriteAuditAsync(string action,string? server,string? database,bool success,string detail,CancellationToken ct=default)
    { await ExecuteTableAsync("access.usp_Audit_Write",[new("@Form",SqlDbType.NVarChar,100){Value="Administrar accesos"},new("@Action",SqlDbType.NVarChar,100){Value=action},new("@ServerName",SqlDbType.NVarChar,128){Value=(object?)server??DBNull.Value},new("@DatabaseName",SqlDbType.NVarChar,128){Value=(object?)database??DBNull.Value},new("@Success",SqlDbType.Bit){Value=success},new("@Detail",SqlDbType.NVarChar,2000){Value=detail}],ct); }
    public async Task<IReadOnlyList<AuthorizedUser>> GetUsersAsync(CancellationToken ct=default)
    { var t=await ExecuteTableAsync("access.usp_AuthorizedUser_List",null,ct); return t.Rows.Cast<DataRow>().Select(r=>new AuthorizedUser(r.Field<int>("UserId"),r.Field<string>("Principal")??"",r.Field<string>("PrincipalType")??"",AppRoleCatalog.FromJson(r.Field<string>("Roles")??"[]",allowEmpty:true),r.Field<bool>("Active"),r.Field<string>("Notes")??""){RowVersion=t.Columns.Contains("RowVersion")&&r["RowVersion"] is byte[] version?version:[]}).ToList(); }
    public async Task<IReadOnlyList<AuthorizedPrincipalOption>> GetAvailablePrincipalsAsync(CancellationToken ct=default)
    {
        var table=await ExecuteTableAsync("access.usp_AuthorizedUser_AvailablePrincipals",null,ct);
        return table.Rows.Cast<DataRow>().Select(row=>new AuthorizedPrincipalOption(row.Field<string>("Principal")??"",row.Field<string>("PrincipalType")??"")).ToList();
    }
    public async Task SaveAuthorizedUserAsync(AuthorizedUserEditData user,CancellationToken ct=default)
    {
        if(!(await LoginAsync(ct)).IsAdministrator)
            throw new UnauthorizedAccessException("Solo un administrador activo puede mantener los usuarios autorizados.");
        await ExecuteTableAsync("access.usp_AuthorizedUser_Upsert",
        [new("@UserId",SqlDbType.Int){Value=(object?)user.Id??DBNull.Value},
         new("@Principal",SqlDbType.NVarChar,256){Value=user.Principal},
         new("@PrincipalType",SqlDbType.VarChar,20){Value=user.Type},
         new("@RolesJson",SqlDbType.NVarChar,500){Value=AppRoleCatalog.ToJson(user.Role)},
         new("@Active",SqlDbType.Bit){Value=user.Active},
         new("@Notes",SqlDbType.NVarChar,500){Value=user.Notes},
         new("@ExpectedRowVersion",SqlDbType.Binary,8){Value=user.RowVersion.Length==8?user.RowVersion:DBNull.Value}],ct);
    }
    public async Task<IReadOnlyList<AuditEvent>> GetAuditAsync(string? filter,CancellationToken ct=default)
    { var t=await ExecuteTableAsync("access.usp_Audit_List",[new("@Filter",SqlDbType.NVarChar,200){Value=(object?)filter??DBNull.Value}],ct); return t.Rows.Cast<DataRow>().Select(r=>new AuditEvent(r.Field<DateTime>("EventDate"),r.Field<string>("Principal")??"",r.Field<string>("Form")??"",r.Field<string>("Action")??"",r.Field<string>("Server")??"",r.Field<string>("Database")??"",r.Field<bool>("Success"),r.Field<string>("Detail")??"")).ToList(); }

    public async Task<IReadOnlyList<PolicyOperation>> GetPolicyOperationsAsync(CancellationToken ct=default)
    {var t=await ExecuteTableAsync("access.usp_Policy_OperationList",null,ct);return t.Rows.Cast<DataRow>().Select(r=>new PolicyOperation(r.Field<string>("OperationCode")??"",r.Field<string>("DisplayName")??"",r.Field<bool>("Enabled"),r.Field<bool>("RequiresApproval"),r.Field<string>("RiskLevel")??"HIGH",r.Field<string>("Description")??"")).ToList();}
    public Task<IReadOnlyList<PolicyPermission>> GetPolicyPermissionsAsync(CancellationToken ct=default)
        =>GetPolicyPermissionsAsync(PolicyContext.General,ct);
    public Task<IReadOnlyList<PolicyRole>> GetPolicyRolesAsync(CancellationToken ct=default)
        =>GetPolicyRolesAsync(PolicyContext.General,ct);
    public async Task<IReadOnlyList<DenyRule>> GetDenyRulesAsync(CancellationToken ct=default)
    {var t=await ExecuteTableAsync("access.usp_Policy_DenyList",null,ct);return t.Rows.Cast<DataRow>().Select(r=>new DenyRule(r.Field<int>("DenyId"),r.Field<string>("Category")??"",r.Field<string>("DeniedValue")??"",r.Field<string>("Reason")??"",r.Field<bool>("IsSystem"),r.Field<bool>("Active"),r.Field<string>("CreatedBy")??"",r.Field<DateTime>("CreatedAt"))).ToList();}
    public async Task<ExternalTicketDetails?> VerifyExternalTicketAsync(string ticket,CancellationToken ct=default)
    {
        var t=await ExecuteTableAsync("dbo.sp_VerificarTicketExiste",[new("@Ticket",SqlDbType.VarChar,50){Value=ticket.Trim()}],ct);
        if(t.Rows.Count==0)return null;
        var r=t.Rows[0];
        return new(r.Field<string>("RESPONSABLE")??"",r.Field<string>("CLIENTE")??"",r.Field<string>("ID_COMPUESTO")??ticket.Trim(),
            r.Field<string>("ASUNTO")??"",r.Field<string>("DESCRIPCION")??"",r.Field<string>("ESTADO")??"");
    }
    public async Task<PolicyDecision> PreviewRequestAsync(AccessRequestDraft d,CancellationToken ct=default)
    {var t=await ExecuteTableAsync("access.usp_AccessRequest_Preview",RequestParameters(d,false),ct);var r=t.Rows[0];return new(r.Field<bool>("Allowed"),r.Field<bool>("RequiresApproval"),r.Field<string>("RiskLevel")??"HIGH",r.Field<string>("Reason")??"");}
    public async Task<long> CreateRequestAsync(AccessRequestDraft d,IEnumerable<DatabaseItem> targets,IEnumerable<AccessRequestStepDraft>? steps=null,RequestSecretData? secret=null,CancellationToken ct=default)
    {
        await RequireCreateRequestsAsync(ct);
        if(LoginAuthentication.CreatesLogin(d.Operation))
            LoginAuthentication.ValidateSecret(d.Operation,d.TargetPrincipal,d.AuthenticationType,secret is not null);
        var targetTable=new DataTable();targetTable.Columns.Add("ServerId",typeof(int));targetTable.Columns.Add("DatabaseName",typeof(string));
        foreach(var x in targets.Where(x=>x.IsSelected))targetTable.Rows.Add(x.ServerId,x.Name);
        var stepTable=new DataTable();stepTable.Columns.Add("StepOrder",typeof(int));stepTable.Columns.Add("OperationCode",typeof(string));stepTable.Columns.Add("PermissionAction",typeof(string));stepTable.Columns.Add("PermissionName",typeof(string));stepTable.Columns.Add("ScopeType",typeof(string));stepTable.Columns.Add("Securable",typeof(string));stepTable.Columns.Add("RoleName",typeof(string));
        foreach(var x in steps??[])stepTable.Rows.Add(x.Order,x.Operation,(object?)x.PermissionAction??DBNull.Value,(object?)x.Permission??DBNull.Value,(object?)x.Scope??DBNull.Value,(object?)x.Securable??DBNull.Value,(object?)x.Role??DBNull.Value);
        var p=RequestParameters(d,true).ToList();
        if(d.Operation=="CLONE_PERMISSIONS")p.Add(new("@CopyPlanJson",SqlDbType.NVarChar,-1){Value=(object?)d.CopyPlan?.ToJson()??DBNull.Value});
        p.Add(new("@Targets",SqlDbType.Structured){TypeName="access.AccessRequestTargetType",Value=targetTable});
        p.Add(new("@Steps",SqlDbType.Structured){TypeName="access.AccessRequestStepPolicyType",Value=stepTable});
        p.Add(new("@SecretCiphertext",SqlDbType.VarBinary,-1){Value=(object?)secret?.Envelope.Ciphertext??DBNull.Value});
        p.Add(new("@SecretNonce",SqlDbType.VarBinary,12){Value=(object?)secret?.Envelope.Nonce??DBNull.Value});
        p.Add(new("@SecretTag",SqlDbType.VarBinary,16){Value=(object?)secret?.Envelope.Tag??DBNull.Value});
        p.Add(new("@SecretKeyId",SqlDbType.UniqueIdentifier){Value=(object?)secret?.Envelope.KeyId??DBNull.Value});
        p.Add(new("@PasswordPolicy",SqlDbType.Bit){Value=secret?.PasswordPolicy??false});
        p.Add(new("@PasswordExpiration",SqlDbType.Bit){Value=secret?.PasswordExpiration??false});
        p.Add(new("@MustChangePassword",SqlDbType.Bit){Value=secret?.MustChangePassword??false});
        var t=await ExecuteTableAsync("access.usp_AccessRequest_Create",p,ct);return t.Rows[0].Field<long>("RequestId");
    }
    private static IEnumerable<SqlParameter> RequestParameters(AccessRequestDraft d,bool includeRequestFields)
    {yield return new("@OperationCode",SqlDbType.VarChar,40){Value=d.Operation};if(includeRequestFields){yield return new("@TargetPrincipal",SqlDbType.NVarChar,256){Value=d.TargetPrincipal};yield return new("@SourcePrincipal",SqlDbType.NVarChar,256){Value=(object?)d.SourcePrincipal??DBNull.Value};yield return new("@AuthenticationType",SqlDbType.VarChar,20){Value=(object?)d.AuthenticationType??DBNull.Value};}yield return new("@PermissionAction",SqlDbType.VarChar,10){Value=(object?)d.PermissionAction??DBNull.Value};yield return new("@PermissionName",SqlDbType.VarChar,128){Value=(object?)d.Permission??DBNull.Value};yield return new("@ScopeType",SqlDbType.VarChar,20){Value=(object?)d.Scope??DBNull.Value};if(includeRequestFields)yield return new("@Securable",SqlDbType.NVarChar,776){Value=(object?)d.Securable??DBNull.Value};yield return new("@RoleName",SqlDbType.NVarChar,128){Value=(object?)d.Role??DBNull.Value};if(includeRequestFields){yield return new("@ExternalTicketNumber",SqlDbType.VarChar,50){Value=d.ExternalTicketNumber};yield return new("@Justification",SqlDbType.NVarChar,1000){Value=d.Justification};}}
    public async Task<IReadOnlyList<AccessRequestItem>> GetRequestsAsync(string? status=null,int? serverId=null,CancellationToken ct=default)
    {
        DataTable table;
        try
        {
            table=await ExecuteTableAsync("access.usp_AccessRequest_List",
            [
                new("@Status",SqlDbType.VarChar,20){Value=(object?)status??DBNull.Value},
                new("@ServerId",SqlDbType.Int){Value=(object?)serverId??DBNull.Value}
            ],ct);
        }
        catch(SqlException ex) when(serverId.HasValue&&ex.Number==8144)
        {
            // Compatibilidad temporal con adminDB donde el DBA todavía no ha aplicado
            // 13_RestringirServidorUnico.sql. El ViewModel valida los destinos localmente.
            table=await ExecuteTableAsync("access.usp_AccessRequest_List",
            [
                new("@Status",SqlDbType.VarChar,20){Value=(object?)status??DBNull.Value}
            ],ct);
        }

        var requests=table.Rows.Cast<DataRow>().Select(MapAccessRequest).ToList();
        for(var index=0;index<requests.Count;index++)
            if(requests[index].StepCount>0)
            {
                var steps=await GetRequestStepsAsync(requests[index].Id,ct);
                if(steps.Count!=requests[index].StepCount)throw new InvalidOperationException($"El listado de cambios de la solicitud #{requests[index].Id} está incompleto.");
                requests[index]=requests[index] with{Steps=steps};
            }
        return requests;
    }

    private static AccessRequestItem MapAccessRequest(DataRow row)=>new(
        row.Field<long>("RequestId"),row.Field<string>("OperationCode")??"",row.Field<string>("TargetPrincipal")??"",
        row.Field<string>("SourcePrincipal")??"",row.Field<string>("AuthenticationType")??"",row.Field<string>("PermissionAction")??"",
        row.Field<string>("PermissionName")??"",row.Field<string>("ScopeType")??"",row.Field<string>("Securable")??"",
        row.Field<string>("RoleName")??"",row.Table.Columns.Contains("ExternalTicketNumber")?row.Field<string>("ExternalTicketNumber")??"":"",row.Field<string>("Justification")??"",row.Field<string>("Status")??"",
        row.Field<string>("RequestedBy")??"",row.Field<DateTime>("RequestedAt"),row.Field<string>("ApprovedBy")??"",
        row.IsNull("ApprovedAt")?null:row.Field<DateTime>("ApprovedAt"),row.Field<int>("TargetCount"),row.Table.Columns.Contains("StepCount")?row.Field<int>("StepCount"):0)
        {CopyPlan=row.Table.Columns.Contains("CopyPlanJson")&&!row.IsNull("CopyPlanJson")?PermissionCopyPlan.FromJson(row.Field<string>("CopyPlanJson")!):null};
    public async Task<PermissionCopyPlan?> GetRequestCopyPlanAsync(long id,CancellationToken ct=default)
    {
        DataTable table;
        try{table=await ExecuteTableAsync("access.usp_AccessRequest_CopyPlanGet",[new("@RequestId",SqlDbType.BigInt){Value=id}],ct);}
        catch(SqlException error)when(error.Number==2812){throw new InvalidOperationException("El DBA debe aplicar 23_DetalleCopiaPermisosPorBase.sql para revisar y ejecutar el desglose de copia por base.",error);}
        return table.Rows.Count==0||table.Rows[0].IsNull("CopyPlanJson")?null:PermissionCopyPlan.FromJson(table.Rows[0].Field<string>("CopyPlanJson")!);
    }
    public async Task<IReadOnlyList<DatabaseItem>> GetRequestTargetsAsync(long id,CancellationToken ct=default)
    {var t=await ExecuteTableAsync("access.usp_AccessRequest_TargetList",[new("@RequestId",SqlDbType.BigInt){Value=id}],ct);return t.Rows.Cast<DataRow>().Select(r=>new DatabaseItem{ServerId=r.Field<int>("ServerId"),Server=r.Field<string>("Server")??"",Name=r.Field<string>("Database")??"",IsSelected=true}).ToList();}
    public async Task<IReadOnlyList<AccessRequestStepItem>> GetRequestStepsAsync(long id,CancellationToken ct=default)
    {var t=await ExecuteTableAsync("access.usp_AccessRequest_StepList",[new("@RequestId",SqlDbType.BigInt){Value=id}],ct);return t.Rows.Cast<DataRow>().Select(r=>new AccessRequestStepItem(r.Field<long>("StepId"),r.Field<int>("StepOrder"),r.Field<string>("OperationCode")??"",r.Field<string>("PermissionAction")??"",r.Field<string>("PermissionName")??"",r.Field<string>("ScopeType")??"",r.Field<string>("Securable")??"",r.Field<string>("RoleName")??"")).ToList();}
    public async Task<RequestSecretData?> GetRequestSecretAsync(long id,CancellationToken ct=default)
    {var t=await ExecuteTableAsync("access.usp_AccessRequest_SecretGet",[new("@RequestId",SqlDbType.BigInt){Value=id}],ct);if(t.Rows.Count==0||t.Rows[0]["SecretCiphertext"] is not byte[] cipher)return null;var r=t.Rows[0];return new(new(cipher,(byte[])r["SecretNonce"],(byte[])r["SecretTag"],r.Field<Guid>("SecretKeyId")),r.Field<bool>("PasswordPolicy"),r.Field<bool>("PasswordExpiration"),r.Field<bool>("MustChangePassword"));}
    public async Task MarkRequestExecutedAsync(long id,bool success,string detail,CancellationToken ct=default){await RequireReviewRequestsAsync(ct);await ExecuteTableAsync("access.usp_AccessRequest_MarkExecuted",[new("@RequestId",SqlDbType.BigInt){Value=id},new("@Success",SqlDbType.Bit){Value=success},new("@Detail",SqlDbType.NVarChar,2000){Value=detail}],ct);}
    public async Task ApproveRequestAsync(long id,bool approve,string comment,CancellationToken ct=default)
    {await RequireReviewRequestsAsync(ct);await ExecuteTableAsync("access.usp_AccessRequest_Approve",[new("@RequestId",SqlDbType.BigInt){Value=id},new("@Approve",SqlDbType.Bit){Value=approve},new("@Comment",SqlDbType.NVarChar,1000){Value=comment}],ct);if(!approve)await ExecuteTableAsync("access.usp_AccessRequest_SecretDiscard",[new("@RequestId",SqlDbType.BigInt){Value=id}],ct);}
    public async Task UpsertPermissionAsync(PolicyPermission p,CancellationToken ct=default)=>await ExecuteTableAsync("access.usp_Policy_PermissionUpsert",[new("@PermissionName",SqlDbType.VarChar,128){Value=p.Permission},new("@ScopeType",SqlDbType.VarChar,20){Value=p.Scope},new("@AllowGrant",SqlDbType.Bit){Value=p.AllowGrant},new("@AllowDeny",SqlDbType.Bit){Value=p.AllowDeny},new("@AllowRevoke",SqlDbType.Bit){Value=p.AllowRevoke},new("@Enabled",SqlDbType.Bit){Value=p.Enabled}],ct);
    public async Task UpsertRoleAsync(PolicyRole role,CancellationToken ct=default)=>await ExecuteTableAsync("access.usp_Policy_RoleUpsert",[new("@RoleName",SqlDbType.NVarChar,128){Value=role.Name},new("@RoleKind",SqlDbType.VarChar,10){Value=role.Kind},new("@Enabled",SqlDbType.Bit){Value=role.Enabled},new("@Notes",SqlDbType.NVarChar,500){Value=string.IsNullOrWhiteSpace(role.Notes)?DBNull.Value:role.Notes}],ct);
    public async Task UpsertDenyRuleAsync(string category,string value,string reason,CancellationToken ct=default)=>await ExecuteTableAsync("access.usp_Policy_DenyUpsert",[new("@Category",SqlDbType.VarChar,30){Value=category},new("@DeniedValue",SqlDbType.NVarChar,256){Value=value},new("@Reason",SqlDbType.NVarChar,1000){Value=reason},new("@Active",SqlDbType.Bit){Value=true}],ct);
    public async Task ActivateSpecialPolicyAsync(PolicySpecialActivation activation,CancellationToken ct=default)
    {
        activation.Validate();
        await ExecuteTableAsync("access.usp_Policy_SpecialActivate",
        [new("@Category",SqlDbType.VarChar,30){Value=activation.Category},new("@Value",SqlDbType.NVarChar,256){Value=activation.Value},
         new("@ScopeType",SqlDbType.VarChar,20){Value=activation.Scope},new("@Reason",SqlDbType.NVarChar,1000){Value=activation.Reason.Trim()},
         new("@ConfirmedName",SqlDbType.NVarChar,256){Value=activation.ConfirmedName},new("@RiskAcknowledged",SqlDbType.Bit){Value=activation.RiskAcknowledged}],ct);
    }
    public async Task<AuditIntegrity> ValidateAuditIntegrityAsync(CancellationToken ct=default){var t=await ExecuteTableAsync("access.usp_Audit_ValidateIntegrity",null,ct);var r=t.Rows[0];return new(r.Field<long>("HashedEvents"),r.Field<int>("BrokenLinks"),r.Field<int>("AlteredEvents"),r.Field<bool>("IsValid"));}
}

