# Cliente con cuatro roles acumulables

Copiar esta carpeta completa al destino, incluyendo DLL, runtimes y subcarpetas. Requiere .NET 8 Desktop Runtime para WPF.

1. Cerrar las sesiones de la aplicación y respaldar adminDB.
2. Aplicar 30_RolesMultiplesYSeparacionSolicitudes.sql después de 29 actualizado y validar con 99_ValidarInstalacion.sql.
3. Sustituir el cliente por esta carpeta completa y abrir SqlAccessAdmin.exe.

Administrador mantiene todas las funciones. Operador crea solicitudes. AprobadorEjecutor confirma, rechaza y ejecuta. Auditor consulta resumen y auditoría. Los roles se seleccionan con casillas en Usuarios autorizados y sus permisos se suman.

Los Operator existentes conservan solo Operador: un Administrador debe añadirles AprobadorEjecutor si necesitan procesar solicitudes. El cliente exige el contrato de roles múltiples de adminDB; no ejecuta migraciones.

Verificación local: 1059 comprobaciones de la aplicación superadas, 448 casos del predicado SQL y transformación de 32 procedimientos comprobados sin ejecutar DDL. Sintaxis de 30 y 99 validada para SQL Server 2022. Permanecen las cuatro advertencias anteriores de viewdemo. La migración no se aplicó a adminDB y falta probar el ciclo completo con cuentas reales después del despliegue.
