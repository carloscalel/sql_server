param([string]$Configuration = 'Release')
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName PresentationFramework, PresentationCore, WindowsBase
$repoPath = Split-Path (Split-Path $PSScriptRoot -Parent) -Parent
$assemblyPath = Join-Path $repoPath "src/SqlAccessAdmin/bin/$Configuration/net8.0-windows/SqlAccessAdmin.dll"
[System.Reflection.Assembly]::LoadFrom($assemblyPath) | Out-Null
$app = [SqlAccessAdmin.App]::new()
$app.InitializeComponent()
$session = [SqlAccessAdmin.Models.SessionContext]::new('CAEL\josep', [SqlAccessAdmin.Models.AppRole]::Administrator)
$refresh = [SqlAccessAdmin.Infrastructure.AsyncCommand]::new([Func[System.Threading.Tasks.Task]]{ [System.Threading.Tasks.Task]::CompletedTask })
$data = [pscustomobject]@{ Session = $session; Servers = 2; Users = 2; Status = ''; RefreshCommand = $refresh }
$view = [SqlAccessAdmin.Views.DashboardView]::new()
$view.DataContext = $data
$window = [SqlAccessAdmin.Views.MainWindow]::new()
$window.DataContext = [pscustomobject]@{ Session = $session; Title = 'Resumen'; HasSessionError = $false }
$content = $window.Content.Children[1].Children | Where-Object { $_ -is [System.Windows.Controls.ContentControl] }
$content.Content = $view
$shell = $window.Content
$shell.DataContext = $window.DataContext
$window.Content = $null
$hostPanel = [System.Windows.Controls.Border]::new()
$hostPanel.Background = $app.FindResource('CanvasBrush')
[System.Windows.Documents.TextElement]::SetForeground($hostPanel, $app.FindResource('NavyBrush'))
[System.Windows.Documents.TextElement]::SetFontFamily($hostPanel, [System.Windows.Media.FontFamily]::new('Segoe UI'))
$hostPanel.Child = $shell

function Save-Preview([System.Windows.UIElement]$Element, [string]$Name, [int]$Width, [int]$Height) {
    $Element.Dispatcher.Invoke([Action]{}, [System.Windows.Threading.DispatcherPriority]::Background)
    $Element.Measure([System.Windows.Size]::new($Width, $Height))
    $Element.Arrange([System.Windows.Rect]::new(0, 0, $Width, $Height))
    $Element.UpdateLayout()
    $bitmap = [System.Windows.Media.Imaging.RenderTargetBitmap]::new($Width, $Height, 96, 96, [System.Windows.Media.PixelFormats]::Pbgra32)
    $bitmap.Render($Element)
    $encoder = [System.Windows.Media.Imaging.PngBitmapEncoder]::new()
    $encoder.Frames.Add([System.Windows.Media.Imaging.BitmapFrame]::Create($bitmap))
    $output = [System.IO.File]::Create((Join-Path $PSScriptRoot $Name))
    try { $encoder.Save($output) } finally { $output.Dispose() }
}

Save-Preview $hostPanel 'resumen.png' 1280 760
if ($view.DataContext.RefreshCommand -ne $refresh) { throw 'El comando de actualización no se conserva.' }
$content.Content = $null
$view = [SqlAccessAdmin.Views.DashboardView]::new()
$view.DataContext = [pscustomobject]@{
    Session = [SqlAccessAdmin.Models.SessionContext]::new('CAEL\nombre_de_usuario_largo_para_verificar_la_distribucion', [SqlAccessAdmin.Models.AppRole]14)
    Servers = 120; Users = 3456; Status = ''; RefreshCommand = $refresh
}
Save-Preview $view 'resumen-compacto.png' 620 490
$view = [SqlAccessAdmin.Views.DashboardView]::new()
$view.DataContext = [pscustomobject]@{
    Session = $session; Servers = 0; Users = 0
    Status = 'No fue posible consultar el catálogo. Compruebe la conexión con el servidor e intente actualizar el resumen nuevamente.'
    RefreshCommand = $refresh
}
Save-Preview $view 'resumen-error.png' 950 660
$window.Close()
'Vistas de resumen renderizadas con datos simulados, sin conexiones SQL.'
