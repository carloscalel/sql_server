/* Aplicar manualmente después de 29 actualizado y antes de 99.
   Respaldar adminDB. Desplegar el cliente de roles múltiples y reiniciar.
   Los Operator existentes conservan solo creación; no se concede aprobación automáticamente.
   No crea logins ni cambia permisos de las instancias administradas. */
USE [adminDB];
GO
SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
SET XACT_ABORT ON;
GO
IF OBJECT_ID(N'[access].ufn_App_Principal',N'FN') IS NULL
 THROW 51500,'Aplique primero 29_UsuariosAutorizadosAccesoEstricto.sql actualizado.',1;
BEGIN TRY
BEGIN TRANSACTION;
IF NOT EXISTS(SELECT 1 FROM [access].AppRole WHERE RoleName='ApproverExecutor')
 INSERT [access].AppRole(RoleName,Description) VALUES('ApproverExecutor',N'Confirma, rechaza y ejecuta solicitudes de acceso');
UPDATE [access].AppRole SET Description=N'Crea solicitudes de acceso' WHERE RoleName='Operator';
IF OBJECT_ID(N'[access].AuthorizedPrincipalRole',N'U') IS NULL
BEGIN
 CREATE TABLE [access].AuthorizedPrincipalRole
 (
  UserId int NOT NULL,
  RoleName varchar(20) NOT NULL,
  CONSTRAINT PK_AuthorizedPrincipalRole PRIMARY KEY(UserId,RoleName),
  CONSTRAINT FK_AuthorizedPrincipalRole_User FOREIGN KEY(UserId) REFERENCES [access].AuthorizedPrincipal(UserId),
  CONSTRAINT FK_AuthorizedPrincipalRole_Role FOREIGN KEY(RoleName) REFERENCES [access].AppRole(RoleName),
  CONSTRAINT CK_AuthorizedPrincipalRole_Known CHECK(RoleName COLLATE Latin1_General_100_BIN2 IN('Administrator','Operator','ApproverExecutor','Auditor') AND DATALENGTH(RoleName)=LEN(RoleName))
 );
 -- Solo al crear la tabla: repetir la migración no restaura roles retirados.
 INSERT [access].AuthorizedPrincipalRole(UserId,RoleName)
 SELECT UserId,CASE RoleName WHEN 'Administrator' THEN 'Administrator' WHEN 'Operator' THEN 'Operator' WHEN 'Auditor' THEN 'Auditor' WHEN 'ApproverExecutor' THEN 'ApproverExecutor' ELSE RoleName END
 FROM [access].AuthorizedPrincipal;
END;
COMMIT TRANSACTION;
END TRY
BEGIN CATCH
 IF XACT_STATE()<>0 ROLLBACK TRANSACTION;
 THROW;
END CATCH;
GO

CREATE OR ALTER FUNCTION [access].ufn_App_HasPermission(@Permission varchar(30))
RETURNS bit
AS
BEGIN
 -- SqlAccessAdmin.MultiRolePermissions.v1: roles de SQL Server no conceden autorización de aplicación.
 DECLARE @Principal nvarchar(256)=[access].ufn_App_Principal();
 RETURN CONVERT(bit,CASE WHEN EXISTS
 (SELECT 1 FROM [access].AuthorizedPrincipal p JOIN [access].AuthorizedPrincipalRole r ON r.UserId=p.UserId
  WHERE p.Principal=@Principal AND p.Active=1 AND
   (@Permission IN('READ','ADMIN','CREATE_REQUEST','REVIEW_REQUEST','ACCESS_REQUESTS','AUDIT') AND r.RoleName='Administrator'
    OR @Permission='READ' AND r.RoleName IN('Operator','ApproverExecutor','Auditor')
    OR @Permission='CREATE_REQUEST' AND r.RoleName='Operator'
    OR @Permission='REVIEW_REQUEST' AND r.RoleName='ApproverExecutor'
    OR @Permission='ACCESS_REQUESTS' AND r.RoleName IN('Operator','ApproverExecutor')
    OR @Permission='AUDIT' AND r.RoleName='Auditor')) THEN 1 ELSE 0 END);
END;
GO
CREATE OR ALTER FUNCTION [access].ufn_App_UserRolesJson(@UserId int)
RETURNS nvarchar(500)
AS
BEGIN
 DECLARE @Roles nvarchar(500);
 SELECT @Roles=N'['+STRING_AGG(CONVERT(nvarchar(max),N'"'+RoleName+N'"'),N',')
  WITHIN GROUP(ORDER BY CASE RoleName WHEN 'Administrator' THEN 1 WHEN 'Operator' THEN 2 WHEN 'ApproverExecutor' THEN 3 ELSE 4 END)+N']'
 FROM [access].AuthorizedPrincipalRole WHERE UserId=@UserId;
 RETURN COALESCE(@Roles,N'[]');
END;
GO
CREATE OR ALTER PROCEDURE [access].usp_App_RequirePermission @Permission varchar(30)
AS
BEGIN
 SET NOCOUNT ON;
 IF [access].ufn_App_HasPermission(@Permission)=0
 BEGIN
  DECLARE @Message nvarchar(2048)=CASE @Permission
   WHEN 'ADMIN' THEN N'Se requiere Administrador activo.'
   WHEN 'CREATE_REQUEST' THEN N'Se requiere Operador o Administrador para crear solicitudes.'
   WHEN 'REVIEW_REQUEST' THEN N'Se requiere AprobadorEjecutor o Administrador para confirmar, rechazar o ejecutar solicitudes.'
   WHEN 'AUDIT' THEN N'Se requiere Auditor o Administrador para consultar auditoría.'
   ELSE N'El usuario no tiene autorización activa para esta operación.' END;
  THROW 51501,@Message,1;
 END;
END;
GO
CREATE OR ALTER TRIGGER [access].tr_AuthorizedPrincipalRole_Revision ON [access].AuthorizedPrincipalRole
AFTER INSERT,UPDATE,DELETE
AS
BEGIN
 SET NOCOUNT ON;
 -- También los cambios de membresías invalidan el RowVersion del usuario.
 UPDATE p SET Notes=p.Notes FROM [access].AuthorizedPrincipal p
 WHERE p.UserId IN(SELECT UserId FROM inserted UNION SELECT UserId FROM deleted);
END;
GO
CREATE OR ALTER PROCEDURE [access].usp_App_LoginContext
AS
BEGIN
 SET NOCOUNT ON;
 -- SqlAccessAdmin.ExplicitAuthorization.v1 / SqlAccessAdmin.MultiRoleLogin.v1
 DECLARE @Principal nvarchar(256)=[access].ufn_App_Principal();
 SELECT @Principal AS Principal,p.RoleName AS [Role],[access].ufn_App_UserRolesJson(p.UserId) AS Roles,
  CONVERT(bit,CASE WHEN p.UserId IS NULL THEN 0 ELSE 1 END) AS IsAuthorized,
  CONVERT(int,2) AS AuthorizationVersion,ORIGINAL_LOGIN() AS OriginalPrincipal,
  CASE WHEN p.UserId IS NULL THEN N'El principal ['+@Principal+N'] no tiene un registro activo con roles de aplicación autorizados.'
       ELSE N'Principal autorizado con roles de aplicación explícitos.' END AS Detail
 FROM (VALUES(1)) singleRow(Id) LEFT JOIN [access].AuthorizedPrincipal p ON p.Principal=@Principal AND p.Active=1
  AND EXISTS(SELECT 1 FROM [access].AuthorizedPrincipalRole r WHERE r.UserId=p.UserId);
END;
GO
CREATE OR ALTER PROCEDURE [access].usp_AuthorizedUser_List
AS
BEGIN
 SET NOCOUNT ON;
 EXEC [access].usp_App_RequirePermission 'READ';
 SELECT UserId,Principal,PrincipalType,RoleName AS [Role],[access].ufn_App_UserRolesJson(UserId) AS Roles,
  Active,ISNULL(Notes,N'') AS Notes,RowVersion FROM [access].AuthorizedPrincipal ORDER BY Principal;
END;
GO

CREATE OR ALTER PROCEDURE [access].usp_AuthorizedUser_Upsert
    @UserId int=NULL, @Principal nvarchar(256), @PrincipalType varchar(20),
    @RolesJson nvarchar(500), @Active bit, @Notes nvarchar(500)=NULL,
    @ExpectedRowVersion binary(8)=NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    -- SqlAccessAdmin.AuthorizedUserMaintenance.v1 / SqlAccessAdmin.MultiRoleMaintenance.v1
    DECLARE @PrimaryRole varchar(20), @OldRolesJson nvarchar(500), @Actor nvarchar(256), @CanonicalActor nvarchar(256), @LockResult int, @SavedId int,
            @OldPrincipal nvarchar(256), @OldType varchar(20), @OldRole varchar(20),
            @OldActive bit, @Version binary(8), @AdminCount int, @Detail nvarchar(2000);
    SET @Principal=LTRIM(RTRIM(@Principal));
    SET @Notes=NULLIF(LTRIM(RTRIM(@Notes)),N'');
    IF @Principal IS NULL OR @Principal=N''
        THROW 51002, 'Indique el principal que inicia sesión en adminDB.', 1;
    IF @RolesJson IS NULL OR ISJSON(@RolesJson)<>1 OR LEFT(LTRIM(@RolesJson),1)<>N'['
        THROW 51002,'Seleccione al menos un rol de aplicación válido.',1;
    IF NOT EXISTS(SELECT 1 FROM OPENJSON(@RolesJson))
       OR EXISTS(SELECT 1 FROM OPENJSON(@RolesJson) WHERE [type]<>1
          OR DATALENGTH([value])<>DATALENGTH(LTRIM(RTRIM([value])))
          OR [value] COLLATE Latin1_General_100_BIN2 NOT IN(N'Administrator',N'Operator',N'ApproverExecutor',N'Auditor'))
       OR EXISTS(SELECT [value] FROM OPENJSON(@RolesJson) GROUP BY [value] HAVING COUNT(*)>1)
        THROW 51002,'La lista de roles contiene valores inválidos o duplicados.',1;
    DECLARE @NewRoles table(RoleName varchar(20) PRIMARY KEY);
    INSERT @NewRoles SELECT CONVERT(varchar(20),[value]) FROM OPENJSON(@RolesJson);
    SELECT TOP(1) @PrimaryRole=RoleName FROM @NewRoles ORDER BY CASE RoleName WHEN 'Administrator' THEN 1 WHEN 'Operator' THEN 2 WHEN 'ApproverExecutor' THEN 3 ELSE 4 END;
    IF @PrincipalType IS NULL OR @PrincipalType NOT IN ('WINDOWS','SQL_LOGIN','BOOTSTRAP') OR @Active IS NULL
        THROW 51002, 'Tipo de principal o estado no válido.', 1;
    IF @UserId IS NULL AND @PrincipalType='BOOTSTRAP'
        THROW 51002, 'Los nuevos usuarios deben ser WINDOWS o SQL_LOGIN.', 1;
    IF @UserId IS NULL AND @PrincipalType='WINDOWS'
       AND (CHARINDEX(N'\',@Principal)<=1 OR CHARINDEX(N'\',@Principal)>=LEN(@Principal)
            OR CHARINDEX(N'\',@Principal,CHARINDEX(N'\',@Principal)+1)>0)
        THROW 51002, 'Para Windows indique DOMINIO\usuario o EQUIPO\usuario.', 1;

    BEGIN TRY
        BEGIN TRANSACTION;
        EXEC @LockResult=sys.sp_getapplock @Resource=N'SqlAccessAdmin.AuthorizedUserMaintenance',
             @LockMode='Exclusive',@LockOwner='Transaction',@LockTimeout=15000;
        IF @LockResult<0 THROW 51003, 'Hay otro mantenimiento en curso. Actualice y reintente.', 1;
        -- Bloqueos de datos protegen también ante cambios externos durante esta operación.
        SELECT @AdminCount=COUNT(*) FROM [access].AuthorizedPrincipal p WITH (UPDLOCK,HOLDLOCK)
        JOIN [access].AuthorizedPrincipalRole r WITH (UPDLOCK,HOLDLOCK) ON r.UserId=p.UserId
        WHERE p.Active=1 AND r.RoleName='Administrator';
        SET @Actor=[access].ufn_App_Principal();
        SELECT @CanonicalActor=SUSER_SNAME(original_security_id) FROM sys.dm_exec_sessions WHERE session_id=@@SPID;
        IF [access].ufn_App_HasPermission('ADMIN')=0
            THROW 51001, 'Solo un administrador activo de la aplicación puede mantener usuarios autorizados.', 1;
        -- Proteger también la cuenta propia si se intenta registrar su otro alias.
        IF (@Principal=@Actor OR @Principal=@CanonicalActor OR @Principal=ORIGINAL_LOGIN()) AND (@Active=0 OR @PrimaryRole<>'Administrator')
            THROW 51007, 'No puede quitar su propio acceso ni reducir su propio rol. Solicite el cambio a otro administrador.', 1;

        IF @UserId IS NOT NULL
        BEGIN
            SELECT @OldPrincipal=Principal,@OldType=PrincipalType,@OldRole=RoleName,@OldActive=Active,@Version=RowVersion
            FROM [access].AuthorizedPrincipal WITH (UPDLOCK,HOLDLOCK) WHERE UserId=@UserId;
            IF @OldPrincipal IS NULL THROW 51004, 'El usuario ya no existe. Actualice el listado.', 1;
            IF @ExpectedRowVersion IS NULL OR @ExpectedRowVersion<>@Version
                THROW 51005, 'Otro administrador modificó este usuario. Actualice antes de guardar.', 1;
            IF @OldPrincipal<>@Principal OR @OldType<>@PrincipalType
                THROW 51006, 'La identidad de un usuario registrado no se puede cambiar. Agregue otra identidad.', 1;
            SET @OldRolesJson=[access].ufn_App_UserRolesJson(@UserId);
            IF EXISTS(SELECT 1 FROM [access].AuthorizedPrincipalRole WHERE UserId=@UserId AND RoleName='Administrator') AND @OldActive=1 AND (@Active=0 OR @PrimaryRole<>'Administrator') AND @AdminCount<=1
                THROW 51008, 'Debe conservar al menos un administrador activo.', 1;
        END;
        IF EXISTS(SELECT 1 FROM [access].AuthorizedPrincipal WITH (UPDLOCK,HOLDLOCK)
                  WHERE Principal=@Principal AND (@UserId IS NULL OR UserId<>@UserId))
            THROW 51009, 'Ese principal ya está registrado. Modifique o reactive el registro existente.', 1;

        IF @UserId IS NULL
        BEGIN
            INSERT [access].AuthorizedPrincipal(Principal,PrincipalType,RoleName,Active,Notes)
            VALUES(@Principal,@PrincipalType,@PrimaryRole,@Active,@Notes);
            SET @SavedId=CONVERT(int,SCOPE_IDENTITY());
        END
        ELSE
        BEGIN
            UPDATE [access].AuthorizedPrincipal SET RoleName=@PrimaryRole,Active=@Active,Notes=@Notes WHERE UserId=@UserId;
            SET @SavedId=@UserId;
        END;
        DELETE [access].AuthorizedPrincipalRole WHERE UserId=@SavedId;
        INSERT [access].AuthorizedPrincipalRole(UserId,RoleName) SELECT @SavedId,RoleName FROM @NewRoles;
        SET @Detail=CONCAT(N'UserId=',@SavedId,N'; Principal=',@Principal,N'; Tipo=',@PrincipalType,
                          N'; Roles anteriores=',COALESCE(@OldRolesJson,N'(nuevo)'),N'; Roles nuevos=',[access].ufn_App_UserRolesJson(@SavedId),
                          N'; Activo anterior=',COALESCE(CONVERT(nvarchar(1),@OldActive),N'(nuevo)'),N'; Activo nuevo=',@Active,
                          N'; Administrador=',@Actor,N'; Login original=',ORIGINAL_LOGIN());
        EXEC [access].usp_Audit_Write @Form=N'Usuarios autorizados',@Action=N'Guardar usuario',
             @Success=1,@Detail=@Detail;
        COMMIT TRANSACTION;
        SELECT UserId,RowVersion FROM [access].AuthorizedPrincipal WHERE UserId=@SavedId;
    END TRY
    BEGIN CATCH
        IF XACT_STATE()<>0 ROLLBACK TRANSACTION;
        THROW;
    END CATCH;
END;
GO

/* SqlAccessAdmin.MultiRoleProcedureUpgrade.v1
   Conservar los cuerpos instalados, incluyendo tickets, políticas y planes.
   Insertar la autorización al inicio del cuerpo; no evaluar definiciones como datos de usuario. */
DECLARE @ProtectedProcedures table(Id int IDENTITY(1,1),ProcedureName sysname,PermissionCode varchar(30),Definition nvarchar(max));
INSERT @ProtectedProcedures(ProcedureName,PermissionCode,Definition)
SELECT p.name,v.PermissionCode,m.definition FROM
 (VALUES
  (N'usp_Server_List','READ'),(N'usp_Server_GetConnection','ACCESS_REQUESTS'),
  (N'usp_Server_Upsert','ADMIN'),(N'usp_Server_SetActive','ADMIN'),(N'usp_Crypto_GetKey','ACCESS_REQUESTS'),
  (N'usp_Audit_List','AUDIT'),(N'usp_Audit_ValidateIntegrity','AUDIT'),(N'usp_Audit_Write','ACCESS_REQUESTS'),
  (N'usp_Policy_OperationList','READ'),(N'usp_Policy_PermissionList','READ'),(N'usp_Policy_RoleList','READ'),(N'usp_Policy_DenyList','READ'),
  (N'usp_Policy_PermissionUpsert','ADMIN'),(N'usp_Policy_RoleUpsert','ADMIN'),(N'usp_Policy_DenyUpsert','ADMIN'),
  (N'usp_Policy_SpecialActivate','ADMIN'),(N'usp_Policy_RestoreInheritance','ADMIN'),(N'usp_Policy_DiscoverRoles','ADMIN'),
  (N'usp_Policy_ContextValidate','READ'),
  (N'usp_AccessRequest_Preview','ACCESS_REQUESTS'),(N'usp_AccessRequest_Create','CREATE_REQUEST'),
  (N'usp_AccessRequest_List','ACCESS_REQUESTS'),(N'usp_AccessRequest_TargetList','ACCESS_REQUESTS'),
  (N'usp_AccessRequest_StepList','ACCESS_REQUESTS'),(N'usp_AccessRequest_CopyPlanGet','ACCESS_REQUESTS'),
  (N'usp_AccessRequest_TargetPolicyValidate','ACCESS_REQUESTS'),(N'usp_AccessRequest_CopyPlanValidate','ACCESS_REQUESTS'),
  (N'usp_AccessRequest_AuthenticationValidate','ACCESS_REQUESTS'),
  (N'usp_AccessRequest_Approve','REVIEW_REQUEST'),(N'usp_AccessRequest_MarkExecuted','REVIEW_REQUEST'),
  (N'usp_AccessRequest_SecretGet','REVIEW_REQUEST'),(N'usp_AccessRequest_SecretDiscard','REVIEW_REQUEST')
 )v(ProcedureName,PermissionCode)
 JOIN sys.procedures p ON p.schema_id=SCHEMA_ID(N'access') AND p.name=v.ProcedureName
 JOIN sys.sql_modules m ON m.object_id=p.object_id;
DECLARE @Index int=1,@Count int=(SELECT COUNT(*) FROM @ProtectedProcedures),@Definition nvarchar(max),
 @ProcedureName sysname,@PermissionCode varchar(30),@NormalizedHeader nvarchar(512),@Message nvarchar(2048),
 @Position int,@Length int,@BeginPosition int,@AsPosition int,@NoBeginPosition int,@TokenStart int,@Depth int,@Character nchar(1),@Token nvarchar(128),@Guard nvarchar(300);
BEGIN TRY
 BEGIN TRANSACTION;
 WHILE @Index<=@Count
 BEGIN
  SELECT @Definition=Definition,@ProcedureName=ProcedureName,@PermissionCode=PermissionCode FROM @ProtectedProcedures WHERE Id=@Index;
  SET @Guard=N'-- SqlAccessAdmin.MultiRoleGuard.v1 '+@PermissionCode+NCHAR(10)
            +N' EXEC [access].usp_App_RequirePermission '''+@PermissionCode+N''';';
  IF @Definition IS NULL
  BEGIN
   SET @Message=CONCAT(N'No se puede revisar [access].',QUOTENAME(@ProcedureName),N'. Solicite revisión al DBA.');
   THROW 51502,@Message,1;
  END;
  IF CHARINDEX(@Guard,REPLACE(@Definition,NCHAR(13),N''))=0
  BEGIN
   IF CHARINDEX(N'SqlAccessAdmin.MultiRoleGuard.v1',@Definition)>0
    THROW 51502,'Un procedimiento tiene una autorización diferente de la esperada. Solicite revisión al DBA.',1;
   -- Los tres procedimientos heredados de aprobación/ejecución deben aceptar
   -- la membresía AprobadorEjecutor incluso cuando el rol principal sea otro.
   IF @PermissionCode='REVIEW_REQUEST'
   BEGIN
    SET @Definition=REPLACE(@Definition,N'RoleName IN(''Administrator'',''Operator'')',N'[access].ufn_App_HasPermission(''REVIEW_REQUEST'')=1');
    SET @Definition=REPLACE(@Definition,N'RoleName IN (''Administrator'',''Operator'')',N'[access].ufn_App_HasPermission(''REVIEW_REQUEST'')=1');
    SET @Definition=REPLACE(@Definition,N'RoleName IN (''Administrator'', ''Operator'')',N'[access].ufn_App_HasPermission(''REVIEW_REQUEST'')=1');
   END;
   IF @PermissionCode='ADMIN' OR @ProcedureName=N'usp_Policy_ContextValidate'
   BEGIN
    SET @Definition=REPLACE(@Definition,N'RoleName=''Administrator''',N'[access].ufn_App_HasPermission(''ADMIN'')=1');
    SET @Definition=REPLACE(@Definition,N'RoleName = ''Administrator''',N'[access].ufn_App_HasPermission(''ADMIN'')=1');
   END;
   WHILE LEFT(@Definition,1) IN(N' ',NCHAR(9),NCHAR(10),NCHAR(13)) SET @Definition=SUBSTRING(@Definition,2,LEN(@Definition));
   SET @NormalizedHeader=UPPER(LEFT(@Definition,512));
   SET @NormalizedHeader=REPLACE(REPLACE(REPLACE(@NormalizedHeader,NCHAR(9),N' '),NCHAR(10),N' '),NCHAR(13),N' ');
   WHILE CHARINDEX(N'  ',@NormalizedHeader)>0 SET @NormalizedHeader=REPLACE(@NormalizedHeader,N'  ',N' ');
   IF @NormalizedHeader LIKE N'CREATE PROCEDURE %' OR @NormalizedHeader LIKE N'CREATE PROC %'
    SET @Definition=STUFF(@Definition,1,6,N'ALTER');
   ELSE IF @NormalizedHeader LIKE N'CREATE OR ALTER PROCEDURE %' OR @NormalizedHeader LIKE N'CREATE OR ALTER PROC %'
    SET @Definition=SUBSTRING(@Definition,CHARINDEX(N'ALTER',UPPER(@Definition)),LEN(@Definition));
   ELSE IF @NormalizedHeader NOT LIKE N'ALTER PROCEDURE %' AND @NormalizedHeader NOT LIKE N'ALTER PROC %'
    THROW 51502,'No se reconoce el encabezado de un procedimiento. Solicite revisión al DBA.',1;

   -- Localizar el BEGIN real, omitiendo comentarios, literales e identificadores.
   SET @Position=1;SET @Length=DATALENGTH(@Definition)/2;SET @BeginPosition=0;SET @AsPosition=0;SET @NoBeginPosition=0;
   WHILE @Position<=@Length AND @BeginPosition=0 AND @NoBeginPosition=0
   BEGIN
    SET @Character=SUBSTRING(@Definition,@Position,1);
    IF SUBSTRING(@Definition,@Position,2)=N'--'
    BEGIN
     SET @Position=@Position+2;
     WHILE @Position<=@Length AND SUBSTRING(@Definition,@Position,1) NOT IN(NCHAR(10),NCHAR(13)) SET @Position+=1;
    END
    ELSE IF SUBSTRING(@Definition,@Position,2)=N'/*'
    BEGIN
     SET @Depth=1;SET @Position+=2;
     WHILE @Position<=@Length AND @Depth>0
     BEGIN
      IF SUBSTRING(@Definition,@Position,2)=N'/*' BEGIN SET @Depth+=1;SET @Position+=2;END
      ELSE IF SUBSTRING(@Definition,@Position,2)=N'*/' BEGIN SET @Depth-=1;SET @Position+=2;END
      ELSE SET @Position+=1;
     END;
    END
    ELSE IF @Character IN(N'''',N'"',N'[')
    BEGIN
     SET @AsPosition=0;
     IF @Character=N'[' SET @Character=N']';
     SET @Position+=1;
     WHILE @Position<=@Length
     BEGIN
      IF SUBSTRING(@Definition,@Position,1)=@Character
      BEGIN
       IF SUBSTRING(@Definition,@Position+1,1)=@Character SET @Position+=2;
       ELSE BEGIN SET @Position+=1;BREAK;END;
      END
      ELSE SET @Position+=1;
     END;
    END
    ELSE IF @Character COLLATE Latin1_General_100_BIN2 LIKE N'[A-Za-z_@#]'
    BEGIN
     SET @TokenStart=@Position;SET @Position+=1;
     WHILE @Position<=@Length AND SUBSTRING(@Definition,@Position,1) COLLATE Latin1_General_100_BIN2 LIKE N'[A-Za-z0-9_@#$]' SET @Position+=1;
     SET @Token=UPPER(SUBSTRING(@Definition,@TokenStart,@Position-@TokenStart));
     IF @Token=N'AS' SET @AsPosition=@TokenStart;
     ELSE IF @AsPosition>0 AND @Token=N'BEGIN' SET @BeginPosition=@TokenStart;
     ELSE IF @AsPosition>0 AND @Token IN(N'SELECT',N'SET',N'DECLARE',N'EXEC',N'EXECUTE',N'INSERT',N'UPDATE',N'DELETE',N'MERGE',N'RETURN',N'IF',N'WHILE',N'THROW',N'RAISERROR',N'WITH',N'WAITFOR',N'PRINT')
      SET @NoBeginPosition=@AsPosition+2;
     ELSE SET @AsPosition=0;
    END
    ELSE SET @Position+=1;
   END;
   IF @BeginPosition>0
    SET @Definition=STUFF(@Definition,@BeginPosition+5,0,NCHAR(10)+N' '+@Guard+NCHAR(10));
   ELSE IF @NoBeginPosition>0
    SET @Definition=STUFF(@Definition,@NoBeginPosition,0,NCHAR(10)+N'BEGIN'+NCHAR(10)+N' '+@Guard+NCHAR(10))+NCHAR(10)+N'END;';
   ELSE
   BEGIN
    SET @Message=CONCAT(N'No se localizó el cuerpo de [access].',QUOTENAME(@ProcedureName),N'. Solicite revisión al DBA.');
    THROW 51502,@Message,1;
   END;
   EXEC sys.sp_executesql @Definition;
   PRINT N'Permiso '+@PermissionCode+N' aplicado a [access].'+QUOTENAME(@ProcedureName);
  END;
  SET @Index+=1;
 END;
 COMMIT TRANSACTION;
END TRY
BEGIN CATCH
 IF XACT_STATE()<>0 ROLLBACK TRANSACTION;
 THROW;
END CATCH;
GO

IF DATABASE_PRINCIPAL_ID(N'SqlAccessAdmin_ApproverExecutor') IS NULL
 CREATE ROLE [SqlAccessAdmin_ApproverExecutor] AUTHORIZATION [dbo];
GO
/* Los roles SQL permiten conectar y ejecutar SP; la autorización efectiva
   se determina por los roles activos de aplicación dentro de cada SP. */
DECLARE @Grants table(ProcedureName sysname);
INSERT @Grants SELECT p.name FROM sys.procedures p WHERE p.schema_id=SCHEMA_ID(N'access') AND
 (p.name IN(N'usp_App_LoginContext',N'usp_AuthorizedUser_List',N'usp_AuthorizedUser_Upsert',N'usp_App_RequirePermission')
  OR OBJECT_DEFINITION(p.object_id) LIKE N'%SqlAccessAdmin.MultiRoleGuard.v1%');
DECLARE @SqlRole sysname,@ProcedureName sysname,@GrantSql nvarchar(max);
DECLARE RoleGrants CURSOR LOCAL FAST_FORWARD FOR
 SELECT r.RoleName,p.ProcedureName FROM @Grants p CROSS JOIN
  (VALUES(N'SqlAccessAdmin_Users'),(N'SqlAccessAdmin_Administrator'),(N'SqlAccessAdmin_Operator'),(N'SqlAccessAdmin_ApproverExecutor'),(N'SqlAccessAdmin_Auditor'))r(RoleName);
OPEN RoleGrants;FETCH NEXT FROM RoleGrants INTO @SqlRole,@ProcedureName;
WHILE @@FETCH_STATUS=0
BEGIN
 SET @GrantSql=N'GRANT EXECUTE ON [access].'+QUOTENAME(@ProcedureName)+N' TO '+QUOTENAME(@SqlRole)+N';';
 EXEC sys.sp_executesql @GrantSql;
 FETCH NEXT FROM RoleGrants INTO @SqlRole,@ProcedureName;
END;
CLOSE RoleGrants;DEALLOCATE RoleGrants;
DENY SELECT,INSERT,UPDATE,DELETE ON [access].AuthorizedPrincipalRole TO [SqlAccessAdmin_Users];
DENY INSERT,UPDATE,DELETE ON [access].AppRole TO [SqlAccessAdmin_Users];
PRINT N'Roles múltiples instalados. Operator crea; ApproverExecutor confirma/rechaza/ejecuta; Administrator conserva todas las funciones.';
GO
