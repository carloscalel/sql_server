/*
  Corrección histórica actualizada: sysadmin también exige registro activo.
  Para esta versión aplique 29_UsuariosAutorizadosAccesoEstricto.sql.
  También está incorporada en 02_CrearProcedimientosConsulta.sql.
*/
USE [adminDB];
GO
SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
GO

CREATE OR ALTER FUNCTION [access].ufn_App_Principal()
RETURNS nvarchar(256)
AS
BEGIN
    -- SqlAccessAdmin.CanonicalWindowsIdentity.v1
    -- El SID original no cambia con EXECUTE AS. No usar el contexto suplantado.
    DECLARE @OriginalSid varbinary(85), @Original nvarchar(256)=ORIGINAL_LOGIN(), @Canonical nvarchar(256);
    SELECT @OriginalSid=original_security_id FROM sys.dm_exec_sessions WHERE session_id=@@SPID;
    IF @OriginalSid IS NULL RETURN NULL;
    SET @Canonical=SUSER_SNAME(@OriginalSid);
    IF @Canonical IS NULL RETURN @Original;
    -- Prioridad al nombre DOMINIO\\usuario registrado, incluso si está inactivo.
    -- Un alias alternativo activo no puede eludir la baja del registro canónico.
    IF EXISTS(SELECT 1 FROM [access].AuthorizedPrincipal WHERE Principal=@Canonical) RETURN @Canonical;
    IF EXISTS(SELECT 1 FROM [access].AuthorizedPrincipal WHERE Principal=@Original) RETURN @Original;
    RETURN @Canonical;
END;
GO

CREATE OR ALTER PROCEDURE [access].usp_App_LoginContext
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @Principal nvarchar(256)=[access].ufn_App_Principal();

    IF EXISTS(SELECT 1 FROM [access].AuthorizedPrincipal WHERE Active=1 AND Principal=@Principal)
    BEGIN
        SELECT TOP (1) Principal,RoleName AS [Role],CAST(1 AS bit) AS IsAuthorized,CAST(1 AS int) AS AuthorizationVersion,
               N'Principal autorizado mediante la lista blanca.' AS Detail
        FROM [access].AuthorizedPrincipal WHERE Active=1 AND Principal=@Principal;
        RETURN;
    END;

    -- SqlAccessAdmin.ExplicitAuthorization.v1: roles SQL no autorizan acceso a la aplicación.
    SELECT @Principal AS Principal,CAST(NULL AS varchar(20)) AS [Role],CAST(0 AS bit) AS IsAuthorized,CAST(1 AS int) AS AuthorizationVersion,
           N'El principal detectado por SQL Server ['+@Principal+N'] no está activo en [access].AuthorizedPrincipal.' AS Detail;
END;
GO

/* Diagnóstico visible para el DBA que ejecuta el parche. */
SELECT ORIGINAL_LOGIN() AS OriginalLogin,SUSER_SNAME() AS ExecutionLogin,
       IS_SRVROLEMEMBER(N'sysadmin') AS IsSysadmin;
EXEC [access].usp_App_LoginContext;
GO

