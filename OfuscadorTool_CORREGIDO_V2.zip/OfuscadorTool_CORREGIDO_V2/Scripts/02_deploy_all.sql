/* ===========================================================
   02_deploy_all.sql - orquestador corregido
   Compatible SQL Server 2016+

   Ejecuta:
   - apply_ddm.sql debe correrse por separado desde la herramienta o SSMS.
   - Este script crea vistas/sinonimos para tablas que requieren vista.

   Nota: si tu DeploymentService ya ejecuta scripts por separado,
   orden recomendado:
   1. setup.sql
   2. sp_ManageColumnRule.sql
   3. sp_CreateViewWithDml.sql
   4. apply_ddm.sql
   5. 02_deploy_all.sql, si deseas vistas/sinonimos
   6. 04_policy_by_table_SAFE.sql con DryRun primero
   ===========================================================*/
SET NOCOUNT ON;
SET XACT_ABORT ON;

DECLARE @CreateViews BIT = 1;
DECLARE @CreateSynonyms BIT = 1;
DECLARE @BaseSchema SYSNAME = N'dbo';
DECLARE @MaskedSchema SYSNAME = N'masked';
DECLARE @AppSchema SYSNAME = N'app';
DECLARE @MaskingMode NVARCHAR(20);

SELECT @MaskingMode = ConfigValue FROM dbo.Masked_Config WHERE ConfigKey = N'MaskingMode';
IF @MaskingMode IS NULL SET @MaskingMode = N'both';

IF OBJECT_ID(N'tempdb..#TablesForViews') IS NOT NULL DROP TABLE #TablesForViews;
CREATE TABLE #TablesForViews
(
    Id INT IDENTITY(1,1) PRIMARY KEY,
    SchemaName SYSNAME,
    TableName SYSNAME,
    HasComputed BIT,
    HasMaskedCandidate BIT
);

INSERT INTO #TablesForViews(SchemaName, TableName, HasComputed, HasMaskedCandidate)
SELECT s.name,
       t.name,
       CASE WHEN EXISTS(SELECT 1 FROM sys.computed_columns cc WHERE cc.object_id = t.object_id) THEN 1 ELSE 0 END,
       CASE WHEN EXISTS
       (
           SELECT 1
           FROM sys.columns c
           LEFT JOIN dbo.Masked_ColumnRules r ON r.SchemaName=s.name AND r.TableName=t.name AND r.ColumnName=c.name AND r.IsEnabled=1
           LEFT JOIN dbo.Masked_ManualSelection ms ON ms.SchemaName=s.name AND ms.TableName=t.name AND ms.ColumnName=c.name AND ms.IsSelected=1
           LEFT JOIN dbo.Masked_Exceptions ex ON ex.SchemaName=s.name AND ex.TableName=t.name AND (ex.ColumnName=c.name OR ex.ColumnName IS NULL) AND ex.IsEnabled=1
           OUTER APPLY (SELECT TOP 1 p.ViewMaskExpr FROM dbo.Masked_Patterns p WHERE p.IsEnabled=1 AND c.name LIKE p.Pattern ORDER BY p.Priority DESC, LEN(p.Pattern) DESC, p.Pattern) p
           WHERE c.object_id = t.object_id
             AND ex.ExceptionId IS NULL
             AND (
                    r.RuleId IS NOT NULL
                 OR (@MaskingMode IN (N'manual', N'both') AND ms.SelectionId IS NOT NULL)
                 OR (@MaskingMode IN (N'patterns', N'both') AND p.ViewMaskExpr IS NOT NULL)
             )
       ) THEN 1 ELSE 0 END
FROM sys.tables t
JOIN sys.schemas s ON s.schema_id = t.schema_id
WHERE t.is_ms_shipped = 0
  AND s.name = @BaseSchema
  AND t.name NOT IN (N'Masked_Audit', N'Masked_Patterns', N'Masked_Config', N'Masked_ColumnRules', N'Masked_Exceptions', N'Masked_ManualSelection', N'Masked_PrincipalPolicy');

DECLARE @i INT = 1, @imax INT = (SELECT ISNULL(MAX(Id),0) FROM #TablesForViews);
DECLARE @sch SYSNAME, @tbl SYSNAME, @hasComputed BIT, @hasMask BIT, @sql NVARCHAR(MAX);

WHILE @i <= @imax
BEGIN
    SELECT @sch = SchemaName, @tbl = TableName, @hasComputed = HasComputed, @hasMask = HasMaskedCandidate
    FROM #TablesForViews WHERE Id = @i;

    IF @CreateViews = 1 AND @hasMask = 1 AND @hasComputed = 1
    BEGIN
        BEGIN TRY
            EXEC dbo.sp_Masked_CreateViewWithDml @BaseSchema = @sch, @TableName = @tbl, @MaskedSchema = @MaskedSchema;
        END TRY
        BEGIN CATCH
            INSERT INTO dbo.Masked_Audit(EventType, SchemaName, ObjectName, ColumnName, Action, Detail)
            VALUES(N'ERROR', @sch, @tbl, NULL, N'VIEW/TRIGGERS', ERROR_MESSAGE());
        END CATCH;

        IF @CreateSynonyms = 1
        BEGIN
            IF EXISTS (SELECT 1 FROM sys.views v JOIN sys.schemas s ON s.schema_id = v.schema_id WHERE s.name = @MaskedSchema AND v.name = @tbl)
            BEGIN
                BEGIN TRY
                    IF EXISTS (SELECT 1 FROM sys.synonyms syn WHERE syn.name = @tbl AND SCHEMA_NAME(syn.schema_id) = @AppSchema)
                    BEGIN
                        SET @sql = N'DROP SYNONYM ' + QUOTENAME(@AppSchema) + N'.' + QUOTENAME(@tbl) + N';';
                        EXEC sp_executesql @sql;
                    END;

                    SET @sql = N'CREATE SYNONYM ' + QUOTENAME(@AppSchema) + N'.' + QUOTENAME(@tbl) +
                               N' FOR ' + QUOTENAME(@MaskedSchema) + N'.' + QUOTENAME(@tbl) + N';';
                    EXEC sp_executesql @sql;

                    INSERT INTO dbo.Masked_Audit(EventType, SchemaName, ObjectName, ColumnName, Action, Detail)
                    VALUES(N'SYNONYM', @AppSchema, @tbl, NULL, N'CREATE', @AppSchema + N'.' + @tbl + N' -> ' + @MaskedSchema + N'.' + @tbl);
                END TRY
                BEGIN CATCH
                    INSERT INTO dbo.Masked_Audit(EventType, SchemaName, ObjectName, ColumnName, Action, Detail)
                    VALUES(N'ERROR', @AppSchema, @tbl, NULL, N'SYNONYM', ERROR_MESSAGE());
                END CATCH;
            END;
        END;
    END
    ELSE
    BEGIN
        INSERT INTO dbo.Masked_Audit(EventType, SchemaName, ObjectName, ColumnName, Action, Detail)
        VALUES(N'SKIP', @sch, @tbl, NULL, N'VIEW', N'No requiere vista: HasMask=' + CONVERT(NVARCHAR(1),@hasMask) + N', HasComputed=' + CONVERT(NVARCHAR(1),@hasComputed));
    END;

    SET @i += 1;
END;

PRINT N'Deploy de vistas/sinonimos finalizado.';
