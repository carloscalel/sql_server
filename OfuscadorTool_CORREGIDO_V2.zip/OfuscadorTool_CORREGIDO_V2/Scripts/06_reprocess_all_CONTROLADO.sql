/* ===========================================================
   06_reprocess_all_CONTROLADO.sql - utilitario de reproceso
   Compatible SQL Server 2016+

   Este script NO borra reglas manuales, excepciones ni seleccion manual por defecto.

   Modos:
   - SOFT:
       Reprocesa sin quitar mascaras existentes. Actualiza config para ejecucion normal.
   - FORCE_DDM:
       Activa MaskForceReapply=1 para que apply_ddm.sql quite y reaplique mascaras DDM.
   - FULL_REBUILD:
       Elimina vistas masked, sinonimos app hacia masked y mascaras DDM existentes.
       Luego debes ejecutar nuevamente setup/procedimientos/apply/deploy/policy.

   Orden recomendado despues de FULL_REBUILD:
   1. setup.sql
   2. sp_ManageColumnRule.sql
   3. sp_CreateViewWithDml.sql
   4. apply_ddm.sql
   5. 02_deploy_all.sql
   6. 04_policy_by_table_SAFE.sql primero con DryRun
   ===========================================================*/
SET NOCOUNT ON;
SET XACT_ABORT ON;

DECLARE @DryRun BIT = 1;
DECLARE @ReprocessMode NVARCHAR(30) = N'FORCE_DDM'; -- SOFT | FORCE_DDM | FULL_REBUILD
DECLARE @BaseSchema SYSNAME = N'dbo';
DECLARE @MaskedSchema SYSNAME = N'masked';
DECLARE @AppSchema SYSNAME = N'app';

IF @ReprocessMode NOT IN (N'SOFT', N'FORCE_DDM', N'FULL_REBUILD')
    THROW 51020, N'@ReprocessMode invalido. Use SOFT, FORCE_DDM o FULL_REBUILD.', 1;

IF OBJECT_ID(N'dbo.Masked_Config', N'U') IS NULL
BEGIN
    RAISERROR(N'No existe dbo.Masked_Config. Ejecuta setup.sql primero.', 16, 1);
    RETURN;
END;

IF OBJECT_ID(N'dbo.Masked_Audit', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.Masked_Audit (
        AuditId     INT IDENTITY(1,1) PRIMARY KEY,
        EventType   NVARCHAR(30) NULL,
        SchemaName  SYSNAME NULL,
        ObjectName  SYSNAME NULL,
        ColumnName  SYSNAME NULL,
        Action      NVARCHAR(80) NULL,
        Detail      NVARCHAR(4000) NULL,
        CreatedAt   DATETIME2(0) NOT NULL DEFAULT SYSUTCDATETIME()
    );
END;

IF OBJECT_ID(N'tempdb..#Commands') IS NOT NULL DROP TABLE #Commands;
CREATE TABLE #Commands
(
    Id INT IDENTITY(1,1) PRIMARY KEY,
    CommandText NVARCHAR(MAX) NOT NULL,
    Reason NVARCHAR(4000) NULL
);

/* Ajuste de configuracion para el siguiente procesamiento. */
MERGE dbo.Masked_Config AS tgt
USING (VALUES
    (N'MaskDryRun', CASE WHEN @DryRun = 1 THEN N'1' ELSE N'0' END),
    (N'MaskForceReapply', CASE WHEN @ReprocessMode IN (N'FORCE_DDM', N'FULL_REBUILD') THEN N'1' ELSE N'0' END)
) AS src(ConfigKey, ConfigValue)
ON tgt.ConfigKey = src.ConfigKey
WHEN MATCHED THEN
    UPDATE SET ConfigValue = src.ConfigValue, UpdatedAt = SYSUTCDATETIME()
WHEN NOT MATCHED THEN
    INSERT(ConfigKey, ConfigValue) VALUES(src.ConfigKey, src.ConfigValue);

INSERT INTO dbo.Masked_Audit(EventType, SchemaName, ObjectName, ColumnName, Action, Detail)
VALUES(N'INFO', N'dbo', N'06_reprocess_all_CONTROLADO', NULL, N'CONFIG',
       N'ReprocessMode=' + @ReprocessMode + N', DryRun=' + CONVERT(NVARCHAR(1), @DryRun));

IF @ReprocessMode = N'FULL_REBUILD'
BEGIN
    /* 1) Drop sinonimos app que apunten a masked. */
    INSERT INTO #Commands(CommandText, Reason)
    SELECT N'DROP SYNONYM ' + QUOTENAME(SCHEMA_NAME(s.schema_id)) + N'.' + QUOTENAME(s.name) + N';',
           N'Drop sinonimo app hacia masked.'
    FROM sys.synonyms s
    WHERE SCHEMA_NAME(s.schema_id) = @AppSchema
      AND s.base_object_name LIKE N'%' + @MaskedSchema + N'%';

    /* 2) Drop vistas masked que tengan tabla base equivalente. */
    INSERT INTO #Commands(CommandText, Reason)
    SELECT N'DROP VIEW ' + QUOTENAME(ms.name) + N'.' + QUOTENAME(v.name) + N';',
           N'Drop vista masked para reconstruccion.'
    FROM sys.views v
    JOIN sys.schemas ms ON ms.schema_id = v.schema_id
    WHERE ms.name = @MaskedSchema
      AND EXISTS
      (
          SELECT 1
          FROM sys.tables t
          JOIN sys.schemas bs ON bs.schema_id = t.schema_id
          WHERE bs.name = @BaseSchema
            AND t.name = v.name
      );

    /* 3) Drop mascaras DDM existentes en tablas base. */
    INSERT INTO #Commands(CommandText, Reason)
    SELECT N'ALTER TABLE ' + QUOTENAME(s.name) + N'.' + QUOTENAME(t.name) +
           N' ALTER COLUMN ' + QUOTENAME(c.name) + N' DROP MASKED;',
           N'Drop DDM existente para reconstruccion completa.'
    FROM sys.masked_columns mc
    JOIN sys.columns c ON c.object_id = mc.object_id AND c.column_id = mc.column_id
    JOIN sys.tables t ON t.object_id = mc.object_id
    JOIN sys.schemas s ON s.schema_id = t.schema_id
    WHERE s.name = @BaseSchema
      AND t.is_ms_shipped = 0;
END;

DECLARE @Id INT = 1, @MaxId INT = (SELECT ISNULL(MAX(Id),0) FROM #Commands);
DECLARE @cmd NVARCHAR(MAX), @reason NVARCHAR(4000);

WHILE @Id <= @MaxId
BEGIN
    SELECT @cmd = CommandText, @reason = Reason FROM #Commands WHERE Id = @Id;

    IF @DryRun = 1
    BEGIN
        PRINT N'DRYRUN: ' + @cmd + N' -- ' + ISNULL(@reason, N'');
        INSERT INTO dbo.Masked_Audit(EventType, SchemaName, ObjectName, ColumnName, Action, Detail)
        VALUES(N'DRYRUN', NULL, NULL, NULL, N'REPROCESS', @cmd);
    END
    ELSE
    BEGIN
        BEGIN TRY
            EXEC sp_executesql @cmd;
            INSERT INTO dbo.Masked_Audit(EventType, SchemaName, ObjectName, ColumnName, Action, Detail)
            VALUES(N'REPROCESS', NULL, NULL, NULL, N'APPLY', @cmd);
        END TRY
        BEGIN CATCH
            INSERT INTO dbo.Masked_Audit(EventType, SchemaName, ObjectName, ColumnName, Action, Detail)
            VALUES(N'ERROR', NULL, NULL, NULL, N'REPROCESS', ERROR_MESSAGE() + N' | ' + @cmd);
            PRINT N'ERROR: ' + ERROR_MESSAGE() + N' | ' + @cmd;
        END CATCH;
    END;

    SET @Id += 1;
END;

PRINT N'Reproceso preparado: ' + @ReprocessMode + N'.';
PRINT N'Si usaste SOFT o FORCE_DDM, ejecuta apply_ddm.sql y luego 02_deploy_all.sql.';
PRINT N'Si usaste FULL_REBUILD, ejecuta el orden completo recomendado indicado arriba.';
