/* ===========================================================
   sp_CreateViewWithDml.sql - corregido / endurecido
   Compatible SQL Server 2016+

   Cambios clave:
   - Toma en cuenta patrones, reglas por columna, seleccion manual y excepciones.
   - Excluye columnas enmascaradas del trigger UPDATE para no guardar XXXX/NULL en tabla real.
   - INSERT no devuelve SELECT V.* para evitar fugas o retornos masivos sin PK.
   - CAST(NULL AS tipo_real) cuando la mascara de vista es NULL.
   ===========================================================*/
IF OBJECT_ID(N'dbo.sp_Masked_CreateViewWithDml', N'P') IS NOT NULL
    DROP PROCEDURE dbo.sp_Masked_CreateViewWithDml;
GO
CREATE PROCEDURE dbo.sp_Masked_CreateViewWithDml
    @BaseSchema   SYSNAME = N'dbo',
    @TableName    SYSNAME,
    @MaskedSchema SYSNAME = N'masked'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @BaseFull NVARCHAR(517) = QUOTENAME(@BaseSchema) + N'.' + QUOTENAME(@TableName);
    DECLARE @ViewFull NVARCHAR(517) = QUOTENAME(@MaskedSchema) + N'.' + QUOTENAME(@TableName);
    DECLARE @MaskingMode NVARCHAR(20);
    DECLARE @sql NVARCHAR(MAX);

    SELECT @MaskingMode = ConfigValue FROM dbo.Masked_Config WHERE ConfigKey = N'MaskingMode';
    IF @MaskingMode IS NULL SET @MaskingMode = N'both';

    IF OBJECT_ID(@BaseFull, N'U') IS NULL
    BEGIN
        INSERT INTO dbo.Masked_Audit(EventType, SchemaName, ObjectName, ColumnName, Action, Detail)
        VALUES(N'ERROR', @BaseSchema, @TableName, NULL, N'VIEW', N'Tabla base no existe.');
        RETURN;
    END;

    IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = @MaskedSchema)
    BEGIN
        SET @sql = N'CREATE SCHEMA ' + QUOTENAME(@MaskedSchema) + N' AUTHORIZATION dbo;';
        EXEC sp_executesql @sql;
    END;

    IF OBJECT_ID(N'tempdb..#PK') IS NOT NULL DROP TABLE #PK;
    CREATE TABLE #PK(Col SYSNAME NOT NULL PRIMARY KEY);

    INSERT INTO #PK(Col)
    SELECT c.name
    FROM sys.key_constraints kc
    JOIN sys.index_columns ic
      ON ic.object_id = kc.parent_object_id
     AND ic.index_id = kc.unique_index_id
    JOIN sys.columns c
      ON c.object_id = kc.parent_object_id
     AND c.column_id = ic.column_id
    WHERE kc.[type] = N'PK'
      AND kc.parent_object_id = OBJECT_ID(@BaseFull)
    ORDER BY ic.key_ordinal;

    IF OBJECT_ID(N'tempdb..#Cols') IS NOT NULL DROP TABLE #Cols;
    CREATE TABLE #Cols
    (
        ColumnId INT NOT NULL PRIMARY KEY,
        Col SYSNAME NOT NULL,
        IsComputed BIT NOT NULL,
        IsIdentity BIT NOT NULL,
        IsRowGuid BIT NOT NULL,
        TypeName SYSNAME NOT NULL,
        TypeDecl NVARCHAR(200) NOT NULL,
        MaskExpr NVARCHAR(1000) NULL,
        IsMasked BIT NOT NULL
    );

    INSERT INTO #Cols(ColumnId, Col, IsComputed, IsIdentity, IsRowGuid, TypeName, TypeDecl, MaskExpr, IsMasked)
    SELECT
        c.column_id,
        c.name,
        c.is_computed,
        c.is_identity,
        c.is_rowguidcol,
        TYPE_NAME(c.user_type_id) AS TypeName,
        CASE
            WHEN ty.name IN (N'varchar', N'char', N'varbinary', N'binary')
                THEN ty.name + N'(' + CASE WHEN c.max_length = -1 THEN N'MAX' ELSE CONVERT(NVARCHAR(10), c.max_length) END + N')'
            WHEN ty.name IN (N'nvarchar', N'nchar')
                THEN ty.name + N'(' + CASE WHEN c.max_length = -1 THEN N'MAX' ELSE CONVERT(NVARCHAR(10), c.max_length / 2) END + N')'
            WHEN ty.name IN (N'decimal', N'numeric')
                THEN ty.name + N'(' + CONVERT(NVARCHAR(10), c.[precision]) + N',' + CONVERT(NVARCHAR(10), c.scale) + N')'
            WHEN ty.name IN (N'datetime2', N'datetimeoffset', N'time')
                THEN ty.name + N'(' + CONVERT(NVARCHAR(10), c.scale) + N')'
            WHEN ty.name IN (N'text') THEN N'varchar(max)'
            WHEN ty.name IN (N'ntext') THEN N'nvarchar(max)'
            WHEN ty.name IN (N'image') THEN N'varbinary(max)'
            ELSE ty.name
        END AS TypeDecl,
        CASE
            WHEN ex.ExceptionId IS NOT NULL THEN NULL
            WHEN r.ViewMaskExpr IS NOT NULL THEN r.ViewMaskExpr
            WHEN @MaskingMode IN (N'manual', N'both') AND ms.IsSelected = 1 THEN
                CASE
                    WHEN ms.MaskOverride = N'default()' THEN N'NULL'
                    WHEN ms.MaskOverride = N'email()' THEN N'CASE WHEN {col} IS NULL THEN NULL ELSE CASE WHEN CHARINDEX(''@'',{col})>1 THEN LEFT({col},1)+''*****''+SUBSTRING({col},CHARINDEX(''@'',{col}),LEN({col})-CHARINDEX(''@'',{col})+1) ELSE ''*****'' END END'
                    ELSE COALESCE(p.ViewMaskExpr, N'NULL')
                END
            WHEN @MaskingMode IN (N'patterns', N'both') THEN p.ViewMaskExpr
            ELSE NULL
        END AS MaskExpr,
        CONVERT(BIT, CASE
            WHEN ex.ExceptionId IS NOT NULL THEN 0
            WHEN r.ViewMaskExpr IS NOT NULL THEN 1
            WHEN @MaskingMode IN (N'manual', N'both') AND ms.IsSelected = 1 THEN 1
            WHEN @MaskingMode IN (N'patterns', N'both') AND p.ViewMaskExpr IS NOT NULL THEN 1
            ELSE 0
        END) AS IsMasked
    FROM sys.columns c
    JOIN sys.types ty
      ON ty.user_type_id = c.user_type_id
    LEFT JOIN dbo.Masked_ColumnRules r
      ON r.SchemaName = @BaseSchema
     AND r.TableName = @TableName
     AND r.ColumnName = c.name
     AND r.IsEnabled = 1
    LEFT JOIN dbo.Masked_ManualSelection ms
      ON ms.SchemaName = @BaseSchema
     AND ms.TableName = @TableName
     AND ms.ColumnName = c.name
     AND ms.IsSelected = 1
    LEFT JOIN dbo.Masked_Exceptions ex
      ON ex.SchemaName = @BaseSchema
     AND ex.TableName = @TableName
     AND (ex.ColumnName = c.name OR ex.ColumnName IS NULL)
     AND ex.IsEnabled = 1
    OUTER APPLY
    (
        SELECT TOP 1 p.ViewMaskExpr
        FROM dbo.Masked_Patterns p
        WHERE p.IsEnabled = 1
          AND c.name LIKE p.Pattern
        ORDER BY p.Priority DESC, LEN(p.Pattern) DESC, p.Pattern
    ) p
    WHERE c.object_id = OBJECT_ID(@BaseFull);

    DECLARE @SelectList NVARCHAR(MAX);

    ;WITH Exprs AS
    (
        SELECT
            ColumnId,
            CASE
                WHEN IsComputed = 1 THEN QUOTENAME(Col) + N' AS ' + QUOTENAME(Col)
                WHEN IsMasked = 1 AND MaskExpr IS NOT NULL AND UPPER(LTRIM(RTRIM(MaskExpr))) = N'NULL'
                    THEN N'CAST(NULL AS ' + TypeDecl + N') AS ' + QUOTENAME(Col)
                WHEN IsMasked = 1 AND MaskExpr IS NOT NULL
                    THEN REPLACE(MaskExpr, N'{col}', QUOTENAME(Col)) + N' AS ' + QUOTENAME(Col)
                ELSE QUOTENAME(Col)
            END AS Expr
        FROM #Cols
    )
    SELECT @SelectList =
        STUFF((SELECT N',' + CHAR(13) + Expr
               FROM Exprs
               ORDER BY ColumnId
               FOR XML PATH(N''), TYPE).value(N'.', N'nvarchar(max)'), 1, 2, N'');

    /* Dropear triggers antes de recrear vista */
    DECLARE @TrigIOI NVARCHAR(517) = QUOTENAME(@MaskedSchema) + N'.' + QUOTENAME(@TableName + N'_IOI');
    DECLARE @TrigIOU NVARCHAR(517) = QUOTENAME(@MaskedSchema) + N'.' + QUOTENAME(@TableName + N'_IOU');
    DECLARE @TrigIOD NVARCHAR(517) = QUOTENAME(@MaskedSchema) + N'.' + QUOTENAME(@TableName + N'_IOD');

    IF OBJECT_ID(@TrigIOI, N'TR') IS NOT NULL EXEC(N'DROP TRIGGER ' + @TrigIOI + N';');
    IF OBJECT_ID(@TrigIOU, N'TR') IS NOT NULL EXEC(N'DROP TRIGGER ' + @TrigIOU + N';');
    IF OBJECT_ID(@TrigIOD, N'TR') IS NOT NULL EXEC(N'DROP TRIGGER ' + @TrigIOD + N';');
    IF OBJECT_ID(@ViewFull, N'V') IS NOT NULL EXEC(N'DROP VIEW ' + @ViewFull + N';');

    SET @sql = N'CREATE VIEW ' + @ViewFull + N' AS SELECT ' + @SelectList + N' FROM ' + @BaseFull + N';';

    BEGIN TRY
        EXEC sp_executesql @sql;
        INSERT INTO dbo.Masked_Audit(EventType, SchemaName, ObjectName, ColumnName, Action, Detail)
        VALUES(N'VIEW', @MaskedSchema, @TableName, NULL, N'CREATE', N'Vista enmascarada creada.');
    END TRY
    BEGIN CATCH
        INSERT INTO dbo.Masked_Audit(EventType, SchemaName, ObjectName, ColumnName, Action, Detail)
        VALUES(N'ERROR', @MaskedSchema, @TableName, NULL, N'VIEW', ERROR_MESSAGE());
        RETURN;
    END CATCH;

    IF OBJECT_ID(N'tempdb..#Updatable') IS NOT NULL DROP TABLE #Updatable;
    CREATE TABLE #Updatable(Col SYSNAME NOT NULL PRIMARY KEY, IsMasked BIT NOT NULL);

    INSERT INTO #Updatable(Col, IsMasked)
    SELECT Col, IsMasked
    FROM #Cols
    WHERE IsComputed = 0
      AND IsIdentity = 0
      AND IsRowGuid = 0;

    DECLARE @InsertColList NVARCHAR(MAX), @InsertSelList NVARCHAR(MAX), @UpdateSet NVARCHAR(MAX);
    DECLARE @PKJoin NVARCHAR(MAX), @PKJoinDeleted NVARCHAR(MAX);

    SELECT @InsertColList = STUFF((SELECT N',' + QUOTENAME(Col)
                                   FROM #Updatable
                                   ORDER BY Col
                                   FOR XML PATH(N''), TYPE).value(N'.', N'nvarchar(max)'), 1, 1, N'');

    SELECT @InsertSelList = STUFF((SELECT N',I.' + QUOTENAME(Col)
                                   FROM #Updatable
                                   ORDER BY Col
                                   FOR XML PATH(N''), TYPE).value(N'.', N'nvarchar(max)'), 1, 1, N'');

    SELECT @UpdateSet = STUFF((SELECT N',B.' + QUOTENAME(u.Col) + N'=I.' + QUOTENAME(u.Col)
                               FROM #Updatable u
                               WHERE u.IsMasked = 0
                                 AND NOT EXISTS (SELECT 1 FROM #PK pk WHERE pk.Col = u.Col)
                               ORDER BY u.Col
                               FOR XML PATH(N''), TYPE).value(N'.', N'nvarchar(max)'), 1, 1, N'');

    SELECT @PKJoin = STUFF((SELECT N' AND B.' + QUOTENAME(Col) + N'=I.' + QUOTENAME(Col)
                            FROM #PK
                            ORDER BY Col
                            FOR XML PATH(N''), TYPE).value(N'.', N'nvarchar(max)'), 1, 5, N'');

    SELECT @PKJoinDeleted = STUFF((SELECT N' AND B.' + QUOTENAME(Col) + N'=D.' + QUOTENAME(Col)
                                   FROM #PK
                                   ORDER BY Col
                                   FOR XML PATH(N''), TYPE).value(N'.', N'nvarchar(max)'), 1, 5, N'');

    /* INSERT: se permite insertar valores reales. No devuelve V.* para evitar fugas/retornos masivos. */
    IF @InsertColList IS NOT NULL AND LEN(@InsertColList) > 0
    BEGIN
        SET @sql = N'CREATE TRIGGER ' + @TrigIOI + N' ON ' + @ViewFull + N' INSTEAD OF INSERT AS
BEGIN
    SET NOCOUNT ON;
    INSERT INTO ' + @BaseFull + N' (' + @InsertColList + N')
    SELECT ' + @InsertSelList + N' FROM inserted I;
END;';
        BEGIN TRY
            EXEC sp_executesql @sql;
            INSERT INTO dbo.Masked_Audit(EventType, SchemaName, ObjectName, ColumnName, Action, Detail)
            VALUES(N'TRIGGER', @MaskedSchema, @TableName, NULL, N'CREATE', N'INSTEAD OF INSERT');
        END TRY
        BEGIN CATCH
            INSERT INTO dbo.Masked_Audit(EventType, SchemaName, ObjectName, ColumnName, Action, Detail)
            VALUES(N'ERROR', @MaskedSchema, @TableName, NULL, N'TRIGGER INSERT', ERROR_MESSAGE());
        END CATCH;
    END;

    /* UPDATE: solo columnas NO enmascaradas para evitar sobrescribir datos reales con XXXX/NULL. */
    IF @UpdateSet IS NOT NULL AND LEN(@UpdateSet) > 0 AND @PKJoin IS NOT NULL
    BEGIN
        SET @sql = N'CREATE TRIGGER ' + @TrigIOU + N' ON ' + @ViewFull + N' INSTEAD OF UPDATE AS
BEGIN
    SET NOCOUNT ON;
    UPDATE B SET ' + @UpdateSet + N'
    FROM ' + @BaseFull + N' B
    JOIN inserted I ON ' + @PKJoin + N';
END;';
        BEGIN TRY
            EXEC sp_executesql @sql;
            INSERT INTO dbo.Masked_Audit(EventType, SchemaName, ObjectName, ColumnName, Action, Detail)
            VALUES(N'TRIGGER', @MaskedSchema, @TableName, NULL, N'CREATE', N'INSTEAD OF UPDATE. Columnas enmascaradas excluidas.');
        END TRY
        BEGIN CATCH
            INSERT INTO dbo.Masked_Audit(EventType, SchemaName, ObjectName, ColumnName, Action, Detail)
            VALUES(N'ERROR', @MaskedSchema, @TableName, NULL, N'TRIGGER UPDATE', ERROR_MESSAGE());
        END CATCH;
    END
    ELSE
    BEGIN
        INSERT INTO dbo.Masked_Audit(EventType, SchemaName, ObjectName, ColumnName, Action, Detail)
        VALUES(N'SKIP', @MaskedSchema, @TableName, NULL, N'UPDATE TRIGGER', N'Sin PK o sin columnas no enmascaradas actualizables.');
    END;

    /* DELETE: solo si hay PK. */
    IF @PKJoinDeleted IS NOT NULL
    BEGIN
        SET @sql = N'CREATE TRIGGER ' + @TrigIOD + N' ON ' + @ViewFull + N' INSTEAD OF DELETE AS
BEGIN
    SET NOCOUNT ON;
    DELETE B
    FROM ' + @BaseFull + N' B
    JOIN deleted D ON ' + @PKJoinDeleted + N';
END;';
        BEGIN TRY
            EXEC sp_executesql @sql;
            INSERT INTO dbo.Masked_Audit(EventType, SchemaName, ObjectName, ColumnName, Action, Detail)
            VALUES(N'TRIGGER', @MaskedSchema, @TableName, NULL, N'CREATE', N'INSTEAD OF DELETE');
        END TRY
        BEGIN CATCH
            INSERT INTO dbo.Masked_Audit(EventType, SchemaName, ObjectName, ColumnName, Action, Detail)
            VALUES(N'ERROR', @MaskedSchema, @TableName, NULL, N'TRIGGER DELETE', ERROR_MESSAGE());
        END CATCH;
    END
    ELSE
    BEGIN
        INSERT INTO dbo.Masked_Audit(EventType, SchemaName, ObjectName, ColumnName, Action, Detail)
        VALUES(N'SKIP', @MaskedSchema, @TableName, NULL, N'DELETE TRIGGER', N'Sin PK.');
    END;

    BEGIN TRY
        EXEC(N'GRANT SELECT ON ' + @ViewFull + N' TO [rol_app_lectura];');
        EXEC(N'GRANT INSERT, UPDATE, DELETE ON ' + @ViewFull + N' TO [rol_app_dml];');
    END TRY
    BEGIN CATCH
        INSERT INTO dbo.Masked_Audit(EventType, SchemaName, ObjectName, ColumnName, Action, Detail)
        VALUES(N'ERROR', @MaskedSchema, @TableName, NULL, N'GRANT VIEW', ERROR_MESSAGE());
    END CATCH;
END;
GO
