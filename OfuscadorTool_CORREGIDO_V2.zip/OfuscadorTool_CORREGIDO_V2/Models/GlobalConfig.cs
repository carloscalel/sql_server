using System.Collections.Generic;

namespace OfuscadorTool.Models
{
    public enum SelectionMode
    {
        AllDatabases,
        AllExcept,
        OnlyThese
    }

    public class DatabaseSelection
    {
        public string ServerId { get; set; }
        public SelectionMode Mode { get; set; } = SelectionMode.AllExcept;
        public List<string> SelectedDatabases { get; set; } = new List<string>();
        public List<string> ExcludedDatabases { get; set; } = new List<string>() { "master", "tempdb", "msdb", "model" };
    }

    public class DeploymentOptions
    {
        public bool ApplyDDM { get; set; } = true;
        public bool CreateViews { get; set; } = true;
        public bool ForceReapply { get; set; } = false;
        public bool CreateSynonyms { get; set; } = true;
        public bool DryRun { get; set; } = false;
        public bool SkipTablesWithComputed { get; set; } = true;
        public bool ApplySafePolicy { get; set; } = false;
        public bool ApplyDefaultSchemaPolicy { get; set; } = true;
        public bool MirrorObjectPermissions { get; set; } = true;
        public bool CopyDmlPermissions { get; set; } = false;
        public string PermissionMirrorScope { get; set; } = "POLICY_TABLE"; // POLICY_TABLE | ALL_EXISTING_GRANTEES
        public string BaseAccessAction { get; set; } = "REPORT_ONLY"; // REPORT_ONLY | REVOKE_EXPLICIT_OBJECT_PERMISSIONS | DENY_BASE_FOR_POLICY_PRINCIPALS
        public int CommandTimeout { get; set; } = 300;
        public string MaskingMode { get; set; } = "both"; // patterns | manual | both
    }

    public class GlobalConfig
    {
        public List<ServerConnection> Servers { get; set; } = new List<ServerConnection>();
        public Dictionary<string, DatabaseSelection> DatabaseSelections { get; set; } = new Dictionary<string, DatabaseSelection>();
        public DeploymentOptions DefaultOptions { get; set; } = new DeploymentOptions();
        public string LogPath { get; set; } = "Logs";
        public bool EnableDetailedLogging { get; set; } = true;
    }
}
