using System;
using System.Data.SqlClient;
using System.Security.Cryptography;
using System.Text;
using Newtonsoft.Json;

namespace OfuscadorTool.Models
{
    public class ServerConnection
    {
        public string Id { get; set; } = Guid.NewGuid().ToString();
        public string Name { get; set; }
        public string Host { get; set; }
        public string InstanceName { get; set; }
        public bool UseWindowsAuth { get; set; } = true;
        public string Username { get; set; }
        public string EncryptedPassword { get; set; }
        public bool IsEnabled { get; set; } = true;
        public DateTime LastModified { get; set; } = DateTime.Now;

        // Seguridad de conexion: configurable por servidor.
        // Para produccion se recomienda EncryptConnection=true y TrustServerCertificate=false.
        public bool EncryptConnection { get; set; } = true;
        public bool TrustServerCertificate { get; set; } = false;
        public int ConnectTimeout { get; set; } = 30;
        public string ApplicationName { get; set; } = "OfuscadorTool";

        [JsonIgnore]
        public string Password
        {
            get => string.IsNullOrEmpty(EncryptedPassword) ? null : Decrypt(EncryptedPassword);
            set => EncryptedPassword = string.IsNullOrEmpty(value) ? null : Encrypt(value);
        }

        public string GetDataSource()
        {
            if (string.IsNullOrWhiteSpace(Host))
                throw new InvalidOperationException("Host es obligatorio para crear la cadena de conexion.");

            return string.IsNullOrWhiteSpace(InstanceName) ? Host : $"{Host}\\{InstanceName}";
        }

        public string GetConnectionString(string databaseName = null)
        {
            var builder = new SqlConnectionStringBuilder
            {
                DataSource = GetDataSource(),
                IntegratedSecurity = UseWindowsAuth,
                ConnectTimeout = ConnectTimeout <= 0 ? 30 : ConnectTimeout,
                Encrypt = EncryptConnection,
                TrustServerCertificate = TrustServerCertificate,
                ApplicationName = ApplicationName
            };

            if (!string.IsNullOrWhiteSpace(databaseName))
            {
                builder.InitialCatalog = databaseName;
            }

            if (!UseWindowsAuth)
            {
                if (string.IsNullOrWhiteSpace(Username))
                    throw new InvalidOperationException("Username es obligatorio cuando UseWindowsAuth=false.");

                if (string.IsNullOrEmpty(Password))
                    throw new InvalidOperationException("Password es obligatorio cuando UseWindowsAuth=false.");

                builder.UserID = Username;
                builder.Password = Password;
            }

            return builder.ToString();
        }

        private static string Encrypt(string plainText)
        {
            byte[] plainBytes = Encoding.UTF8.GetBytes(plainText);
            byte[] encryptedBytes = ProtectedData.Protect(plainBytes, null, DataProtectionScope.CurrentUser);
            return Convert.ToBase64String(encryptedBytes);
        }

        private static string Decrypt(string encryptedText)
        {
            try
            {
                byte[] encryptedBytes = Convert.FromBase64String(encryptedText);
                byte[] plainBytes = ProtectedData.Unprotect(encryptedBytes, null, DataProtectionScope.CurrentUser);
                return Encoding.UTF8.GetString(plainBytes);
            }
            catch (Exception ex) when (ex is CryptographicException || ex is FormatException)
            {
                throw new InvalidOperationException("No se pudo descifrar la contraseña. Puede haber sido creada por otro usuario de Windows o en otra maquina.", ex);
            }
        }
    }
}
