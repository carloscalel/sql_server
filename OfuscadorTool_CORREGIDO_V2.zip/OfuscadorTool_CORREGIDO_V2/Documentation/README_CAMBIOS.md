# OfuscadorTool corregido V2

## Cambios principales de esta versión

### 1. DEFAULT_SCHEMA controlado
Se agregó la tabla:

```sql
dbo.Masked_PrincipalPolicy
```

Esta tabla permite decidir qué usuarios/principales se migran a la capa enmascarada.

Ejemplo:

```sql
INSERT INTO dbo.Masked_PrincipalPolicy
(PrincipalName, ApplyDefaultSchema, MirrorObjectPermissions, IncludeDml, AddToReadRole, AddToDmlRole, BlockBaseAccess, Notes)
VALUES
(N'UsuarioAplicacion', 1, 1, 0, 0, 0, 0, N'Migrar a vistas masked sin tocar permisos originales.');
```

Con eso, el script `04_policy_by_table_SAFE.sql` puede ejecutar:

```sql
ALTER USER [UsuarioAplicacion] WITH DEFAULT_SCHEMA = [masked];
```

De esa forma, si el usuario ejecuta:

```sql
SELECT * FROM Clientes;
```

SQL Server buscará primero `masked.Clientes`, no `dbo.Clientes`.

---

### 2. Copia de permisos puntuales hacia vistas

El script `04_policy_by_table_SAFE.sql` ahora puede copiar permisos existentes desde:

```sql
dbo.Tabla
```

hacia:

```sql
masked.Tabla
```

Ejemplo:

```sql
GRANT SELECT ON OBJECT::dbo.Clientes TO UsuarioA;
```

se replica como:

```sql
GRANT SELECT ON OBJECT::masked.Clientes TO UsuarioA;
```

Si el permiso era por columna, también intenta copiarlo a la columna equivalente de la vista.

Esto evita regalar permisos generales como:

```sql
GRANT SELECT ON SCHEMA::masked TO UsuarioA;
```

---

### 3. No se tocan permisos originales por defecto

Por defecto, `04_policy_by_table_SAFE.sql` usa:

```sql
@BaseAccessAction = 'REPORT_ONLY'
```

Eso significa:

- No quita permisos sobre `dbo`.
- No aplica `DENY`.
- No quita `db_datareader`.
- No quita `db_datawriter`.
- Solo reporta quién todavía tiene acceso directo a las tablas base.

Para bloquear acceso directo a `dbo`, debe hacerse en una segunda fase y solo con usuarios marcados:

```sql
BlockBaseAccess = 1
```

Opciones disponibles:

```sql
@BaseAccessAction = 'REVOKE_EXPLICIT_OBJECT_PERMISSIONS'
@BaseAccessAction = 'DENY_BASE_FOR_POLICY_PRINCIPALS'
```

---

### 4. Reproceso controlado

Se agregó:

```sql
06_reprocess_all_CONTROLADO.sql
```

Modos disponibles:

```sql
@ReprocessMode = 'SOFT'
@ReprocessMode = 'FORCE_DDM'
@ReprocessMode = 'FULL_REBUILD'
```

Uso recomendado para reprocesar máscaras DDM:

```sql
@ReprocessMode = 'FORCE_DDM'
@DryRun = 1
```

Luego revisar y cambiar:

```sql
@DryRun = 0
```

Después ejecutar:

```text
1. apply_ddm.sql
2. 02_deploy_all.sql
3. 04_policy_by_table_SAFE.sql
```

---

## Orden recomendado de ejecución

```text
1. setup.sql
2. sp_ManageColumnRule.sql
3. sp_CreateViewWithDml.sql
4. apply_ddm.sql
5. 02_deploy_all.sql
6. 04_policy_by_table_SAFE.sql primero con @DryRun = 1
```

Si quieres reconstruir completamente:

```text
1. 06_reprocess_all_CONTROLADO.sql con @ReprocessMode = 'FULL_REBUILD' y @DryRun = 1
2. Revisar salida
3. Ejecutar con @DryRun = 0
4. setup.sql
5. sp_ManageColumnRule.sql
6. sp_CreateViewWithDml.sql
7. apply_ddm.sql
8. 02_deploy_all.sql
9. 04_policy_by_table_SAFE.sql
```

## Recomendación de seguridad

La estrategia recomendada es:

```text
Primero: crear vistas masked.
Segundo: copiar permisos puntuales equivalentes hacia masked.
Tercero: aplicar DEFAULT_SCHEMA = masked solo a usuarios controlados.
Cuarto: auditar quién todavía puede entrar a dbo.
Quinto: revocar o denegar acceso directo a dbo solo con lista explícita.
```

