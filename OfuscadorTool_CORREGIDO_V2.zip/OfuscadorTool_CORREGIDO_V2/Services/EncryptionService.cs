using System;
using System.Security.Cryptography;
using System.Text;

namespace OfuscadorTool.Services
{
    /// <summary>
    /// Wrapper simple sobre DPAPI. Para contrasenas locales de la herramienta
    /// es mas seguro que AES con Salt/IV fijos, porque queda ligado al usuario
    /// actual de Windows.
    /// </summary>
    public static class EncryptionService
    {
        public static string ProtectForCurrentUser(string plainText)
        {
            if (string.IsNullOrEmpty(plainText)) return null;

            byte[] plainBytes = Encoding.UTF8.GetBytes(plainText);
            byte[] encryptedBytes = ProtectedData.Protect(plainBytes, null, DataProtectionScope.CurrentUser);
            return Convert.ToBase64String(encryptedBytes);
        }

        public static string UnprotectForCurrentUser(string protectedText)
        {
            if (string.IsNullOrEmpty(protectedText)) return null;

            byte[] encryptedBytes = Convert.FromBase64String(protectedText);
            byte[] plainBytes = ProtectedData.Unprotect(encryptedBytes, null, DataProtectionScope.CurrentUser);
            return Encoding.UTF8.GetString(plainBytes);
        }
    }
}
