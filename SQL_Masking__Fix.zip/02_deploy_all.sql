/* ===========================================================
   02_deploy_all.sql (SQL 2016+)
   - Aplica DDM (solo tipos carácter, excluye Id_%)
   - Crea vistas + triggers + sinónimos para tablas con calculadas
   - FIX: todas las inserciones a Masked_Audit con lista de columnas
   ===========================================================*/
SET NOCOUNT ON; SET XACT_ABORT ON;

DECLARE @ApplyDDM BIT = 1, @CreateViews BIT = 1;

IF OBJECT_ID('tempdb..#Tablas') IS NOT NULL DROP TABLE #Tablas;
CREATE TABLE #Tablas(Id INT IDENTITY, Sch SYSNAME, Tbl SYSNAME, HasComputed BIT);

INSERT INTO #Tablas(Sch,Tbl,HasComputed)
SELECT s.name, t.name,
       CASE WHEN EXISTS(SELECT 1 FROM sys.computed_columns cc WHERE cc.object_id=t.object_id)
            THEN 1 ELSE 0 END
FROM sys.tables t
JOIN sys.schemas s ON s.schema_id=t.schema_id
WHERE t.is_ms_shipped=0
  AND s.name=N'dbo'
  AND t.name NOT IN (N'Masked_Audit',N'Masked_Patterns');

/* ====== DDM directo para tablas SIN calculadas ====== */
IF (@ApplyDDM=1)
BEGIN
  DECLARE @sch SYSNAME, @tbl SYSNAME, @sql NVARCHAR(MAX);
  DECLARE @i INT=1, @imax INT=(SELECT MAX(Id) FROM #Tablas);
  WHILE @i<=@imax
  BEGIN
    SELECT @sch=Sch, @tbl=Tbl FROM #Tablas WHERE Id=@i;
    IF (SELECT HasComputed FROM #Tablas WHERE Id=@i)=0
    BEGIN
      DECLARE @j INT=1, @jmax INT;
      IF OBJECT_ID('tempdb..#Cols') IS NOT NULL DROP TABLE #Cols;
      CREATE TABLE #Cols(Id INT IDENTITY, Col SYSNAME, Ddm NVARCHAR(200));
      INSERT INTO #Cols(Col,Ddm)
      SELECT c.name, p.DdmFunction
      FROM sys.columns c
      OUTER APPLY (SELECT TOP 1 p.DdmFunction
                   FROM dbo.Masked_Patterns p
                   WHERE c.name LIKE p.Pattern
                   ORDER BY p.Pattern) p
      WHERE c.object_id=OBJECT_ID(QUOTENAME(@sch)+'.'+QUOTENAME(@tbl))
        AND c.is_computed=0
        AND c.name NOT LIKE 'Id\_%' ESCAPE '\'
        AND (
           (TYPE_NAME(c.user_type_id) IN ('char','nchar','varchar','nvarchar','text','ntext')
            AND p.DdmFunction IS NOT NULL AND (p.DdmFunction LIKE 'partial(%' OR p.DdmFunction LIKE 'email%'))
           OR (p.DdmFunction LIKE 'default%')
        );

      SET @jmax = (SELECT ISNULL(MAX(Id),0) FROM #Cols);
      WHILE @j<=@jmax
      BEGIN
        DECLARE @col SYSNAME, @mf NVARCHAR(200);
        SELECT @col=Col, @mf=Ddm FROM #Cols WHERE Id=@j;
        BEGIN TRY
          SET @sql = N'ALTER TABLE '+QUOTENAME(@sch)+'.'+QUOTENAME(@tbl)+
                     N' ALTER COLUMN '+QUOTENAME(@col)+
                     N' ADD MASKED WITH (FUNCTION='+QUOTENAME(@mf,'''')+N');';
          EXEC sp_executesql @sql;

          INSERT INTO dbo.Masked_Audit (EventType,SchemaName,ObjectName,ColumnName,Action,Detail)
          VALUES (N'DDM',@sch,@tbl,@col,N'ADD MASKED',@mf);
        END TRY
        BEGIN CATCH
          INSERT INTO dbo.Masked_Audit (EventType,SchemaName,ObjectName,ColumnName,Action,Detail)
          VALUES (N'ERROR',@sch,@tbl,@col,N'DDM',ERROR_MESSAGE());
        END CATCH
        SET @j+=1;
      END
    END
    SET @i+=1;
  END
END

/* ====== Vistas + triggers + sinónimos para tablas CON calculadas ====== */
IF (@CreateViews=1)
BEGIN
  DECLARE @k INT=1, @kmax INT=(SELECT MAX(Id) FROM #Tablas);
  DECLARE @tbl2 SYSNAME, @sch2 SYSNAME, @sql2 NVARCHAR(MAX);

  WHILE @k<=@kmax
  BEGIN
    SELECT @sch2=Sch, @tbl2=Tbl FROM #Tablas WHERE Id=@k;
    IF (SELECT HasComputed FROM #Tablas WHERE Id=@k)=1
    BEGIN
      BEGIN TRY
        EXEC dbo.sp_Masked_CreateViewWithDml @BaseSchema=@sch2, @TableName=@tbl2, @MaskedSchema=N'masked';
      END TRY
      BEGIN CATCH
        INSERT INTO dbo.Masked_Audit (EventType,SchemaName,ObjectName,ColumnName,Action,Detail)
        VALUES (N'ERROR',@sch2,@tbl2,NULL,N'VIEW/TRIGGERS',ERROR_MESSAGE());
      END CATCH;

      -- Sinónimo app.<tabla> -> masked.<tabla>
      IF EXISTS (SELECT 1 FROM sys.views v JOIN sys.schemas s ON s.schema_id=v.schema_id
                 WHERE s.name=N'masked' AND v.name=@tbl2)
      BEGIN
        BEGIN TRY
          IF EXISTS (SELECT 1 FROM sys.synonyms syn
                     WHERE syn.name=@tbl2 AND SCHEMA_NAME(syn.schema_id)=N'app')
            --EXEC(N'DROP SYNONYM '+QUOTENAME(N'app')+'.'+QUOTENAME(@tbl2)+';');
          BEGIN
              SET @sql = N'DROP SYNONYM ' + QUOTENAME('app') + '.' + QUOTENAME(@tbl2) + ';';
              EXEC sp_executesql @sql;
          END;

          SET @sql2 = N'CREATE SYNONYM '+QUOTENAME(N'app')+'.'+QUOTENAME(@tbl2)+
                      N' FOR '+QUOTENAME(N'masked')+'.'+QUOTENAME(@tbl2)+N';';
          EXEC sp_executesql @sql2;

          INSERT INTO dbo.Masked_Audit (EventType,SchemaName,ObjectName,ColumnName,Action,Detail)
          VALUES (N'SYNONYM',N'app',@tbl2,NULL,N'CREATE',N'app.'+@tbl2+N' -> masked.'+@tbl2);
        END TRY
        BEGIN CATCH
          INSERT INTO dbo.Masked_Audit (EventType,SchemaName,ObjectName,ColumnName,Action,Detail)
          VALUES (N'ERROR',N'app',@tbl2,NULL,N'SYNONYM',ERROR_MESSAGE());
        END CATCH
      END
      ELSE
        INSERT INTO dbo.Masked_Audit (EventType,SchemaName,ObjectName,ColumnName,Action,Detail)
        VALUES (N'ERROR',@sch2,@tbl2,NULL,N'SYNONYM',N'Vista masked.'+@tbl2+N' no existe');
    END
    SET @k+=1;
  END
END
