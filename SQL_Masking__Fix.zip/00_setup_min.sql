/* ===========================================================
   00_setup_min.sql  (estructura correcta de Masked_Patterns)
   - Schemas, roles, tablas base y patrones (DDM + ViewMaskExpr)
   - Compatible SQL Server 2016+
   ===========================================================*/
SET NOCOUNT ON;

IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = N'masked') EXEC('CREATE SCHEMA masked AUTHORIZATION dbo;');
IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = N'app')    EXEC('CREATE SCHEMA app AUTHORIZATION dbo;');

IF NOT EXISTS (SELECT 1 FROM sys.database_principals WHERE name = N'rol_app_lectura')       CREATE ROLE [rol_app_lectura];
IF NOT EXISTS (SELECT 1 FROM sys.database_principals WHERE name = N'rol_app_dml')           CREATE ROLE [rol_app_dml];
IF NOT EXISTS (SELECT 1 FROM sys.database_principals WHERE name = N'rol_app_bloqueo_dbo')   CREATE ROLE [rol_app_bloqueo_dbo];

IF OBJECT_ID('dbo.Masked_Patterns','U') IS NOT NULL DROP TABLE dbo.Masked_Patterns;
CREATE TABLE dbo.Masked_Patterns (
  Pattern       NVARCHAR(128) NOT NULL PRIMARY KEY,  -- usado con c.name LIKE Pattern
  DdmFunction   NVARCHAR(200) NOT NULL,              -- función DDM para ALTER COLUMN ... ADD MASKED
  ViewMaskExpr  NVARCHAR(1000) NULL                  -- expresión para vista, usar {col} como placeholder
);
/* Notas ViewMaskExpr:
   - Usar {col} como placeholder del nombre de columna con corchetes incluidos.
   - Todas las expresiones protegen NULLs.
*/

/* Carga de patrones solicitados */
INSERT INTO dbo.Masked_Patterns (Pattern, DdmFunction, ViewMaskExpr) VALUES
 (N'%TARJETA%', N'partial(0,"XXXXXXXXXXXXXXX",4)',
  N'CASE WHEN {col} IS NULL THEN NULL 
         ELSE REPLICATE(''X'', CASE WHEN LEN({col})>4 THEN LEN({col})-4 ELSE 0 END) 
              + RIGHT({col}, CASE WHEN LEN({col})>4 THEN 4 ELSE LEN({col}) END) END'),

 (N'%CUENTA%',  N'partial(0,"XXXXXXXXXXXX",4)',
  N'CASE WHEN {col} IS NULL THEN NULL 
         ELSE REPLICATE(''X'', CASE WHEN LEN({col})>4 THEN LEN({col})-4 ELSE 0 END) 
              + RIGHT({col}, CASE WHEN LEN({col})>4 THEN 4 ELSE LEN({col}) END) END'),

 (N'%CODIGO%',  N'partial(6,"XXXXXX",4)',
  N'CASE WHEN {col} IS NULL THEN NULL 
         ELSE LEFT({col}, CASE WHEN LEN({col})>6 THEN 6 ELSE LEN({col}) END)
              + REPLICATE(''X'', CASE WHEN LEN({col})>10 THEN LEN({col})-10 ELSE 0 END)
              + RIGHT({col}, CASE WHEN LEN({col})>10 THEN 4 ELSE 0 END) END'),

 (N'%AUTENTICACION%', N'partial(6,"XXXXXX",4)',
  N'CASE WHEN {col} IS NULL THEN NULL 
         ELSE LEFT({col}, CASE WHEN LEN({col})>6 THEN 6 ELSE LEN({col}) END)
              + REPLICATE(''X'', CASE WHEN LEN({col})>10 THEN LEN({col})-10 ELSE 0 END)
              + RIGHT({col}, CASE WHEN LEN({col})>10 THEN 4 ELSE 0 END) END'),

 (N'%MAGNETICA%', N'partial(6,"XXXXXX",4)',
  N'CASE WHEN {col} IS NULL THEN NULL 
         ELSE LEFT({col}, CASE WHEN LEN({col})>6 THEN 6 ELSE LEN({col}) END)
              + REPLICATE(''X'', CASE WHEN LEN({col})>10 THEN LEN({col})-10 ELSE 0 END)
              + RIGHT({col}, CASE WHEN LEN({col})>10 THEN 4 ELSE 0 END) END'),

 (N'%CV2%', N'partial(6,"XXXXXX",4)',
  N'CASE WHEN {col} IS NULL THEN NULL 
         ELSE LEFT({col}, CASE WHEN LEN({col})>6 THEN 6 ELSE LEN({col}) END)
              + REPLICATE(''X'', CASE WHEN LEN({col})>10 THEN LEN({col})-10 ELSE 0 END)
              + RIGHT({col}, CASE WHEN LEN({col})>10 THEN 4 ELSE 0 END) END'),

 (N'%CVV2%', N'partial(6,"XXXXXX",4)',
  N'CASE WHEN {col} IS NULL THEN NULL 
         ELSE LEFT({col}, CASE WHEN LEN({col})>6 THEN 6 ELSE LEN({col}) END)
              + REPLICATE(''X'', CASE WHEN LEN({col})>10 THEN LEN({col})-10 ELSE 0 END)
              + RIGHT({col}, CASE WHEN LEN({col})>10 THEN 4 ELSE 0 END) END'),

 (N'%BIN%', N'partial(6,"XXXXXX",4)',
  N'CASE WHEN {col} IS NULL THEN NULL 
         ELSE LEFT({col}, CASE WHEN LEN({col})>6 THEN 6 ELSE LEN({col}) END)
              + REPLICATE(''X'', CASE WHEN LEN({col})>6 THEN LEN({col})-6 ELSE 0 END) END'),

 (N'%FECHA_V%', N'default()',
  N'NULL'),

 (N'NOM_%', N'partial(10,"XXXXXXXXXXXXXXXXXXXX",0)',
  N'CASE WHEN {col} IS NULL THEN NULL 
         ELSE LEFT({col}, CASE WHEN LEN({col})>10 THEN 10 ELSE LEN({col}) END)
              + REPLICATE(''X'', CASE WHEN LEN({col})>10 THEN LEN({col})-10 ELSE 0 END) END'),

 (N'%EMAIL%', N'email()',
  N'CASE WHEN {col} IS NULL THEN NULL 
         ELSE CASE WHEN CHARINDEX(''@'',{col})>1 
                   THEN LEFT({col},1)+''*****''+SUBSTRING({col},CHARINDEX(''@'',{col}),LEN({col})-CHARINDEX(''@'',{col})+1)
                   ELSE ''*****'' END END'),

 (N'%NACIMIENTO%', N'default()', N'NULL'),
 (N'%BLOQUEO%',    N'default()', N'NULL'),
 (N'%TOKEN%',      N'default()', N'NULL'),
 (N'%NIT%',        N'default()', N'NULL'),
 (N'%DIRECCION%',  N'default()', N'NULL'),
 (N'DIR_%',        N'default()', N'NULL'),
 (N'%TEL%',        N'default()', N'NULL'),
 (N'%TELEFONO%',   N'default()', N'NULL');

IF OBJECT_ID('dbo.Masked_Audit','U') IS NULL
CREATE TABLE dbo.Masked_Audit (
  AuditId     INT IDENTITY(1,1) PRIMARY KEY,
  EventType   NVARCHAR(20),      -- VIEW/TRIGGER/DDM/SYNONYM/ERROR/INFO
  SchemaName  SYSNAME NULL,
  ObjectName  SYSNAME NULL,
  ColumnName  SYSNAME NULL,
  Action      NVARCHAR(50) NULL,
  Detail      NVARCHAR(4000) NULL,
  CreatedAt   DATETIME2(0) NOT NULL DEFAULT SYSUTCDATETIME()
);

BEGIN TRY GRANT SELECT ON SCHEMA::app    TO [rol_app_lectura]; END TRY BEGIN CATCH END CATCH;
BEGIN TRY GRANT SELECT ON SCHEMA::masked TO [rol_app_lectura]; END TRY BEGIN CATCH END CATCH;
BEGIN TRY GRANT INSERT, UPDATE, DELETE ON SCHEMA::masked TO [rol_app_dml]; END TRY BEGIN CATCH END CATCH;
