-- �Vistas OK?
SELECT s.name, v.name 
FROM sys.views v JOIN sys.schemas s ON s.schema_id=v.schema_id
WHERE s.name='masked';

-- �Triggers existen?
SELECT s2.name AS SchemaName, o.name AS ViewName, tr.name AS TriggerName
FROM sys.triggers tr
JOIN sys.objects o ON tr.parent_id=o.object_id AND o.type='V'
JOIN sys.schemas s2 ON s2.schema_id=o.schema_id
WHERE s2.name='masked';

-- �Qu� dijo la bit�cora para esa tabla?
SELECT TOP 50 * 
FROM dbo.Masked_Audit 
WHERE ObjectName = 'Cuentas' 
ORDER BY AuditId DESC;

-- �Detect� PK?
SELECT kc.name AS PKName, ic.key_ordinal, c.name AS PKCol
FROM sys.key_constraints kc
JOIN sys.index_columns ic ON ic.object_id=kc.parent_object_id AND ic.index_id=kc.unique_index_id
JOIN sys.columns c ON c.object_id=kc.parent_object_id AND c.column_id=ic.column_id
WHERE kc.[type]='PK' AND kc.parent_object_id=OBJECT_ID('dbo.Cuentas')
ORDER BY ic.key_ordinal;





SELECT s2.name AS SchemaName, o.name AS ViewName, tr.name AS TriggerName
FROM sys.triggers tr
JOIN sys.objects o ON tr.parent_id=o.object_id AND o.type='V'
JOIN sys.schemas s2 ON o.schema_id=s2.schema_id
WHERE s2.name='masked' AND o.name='Cuentas';

SELECT TOP 20 * FROM dbo.Masked_Audit WHERE ObjectName='Cuentas' ORDER BY AuditId DESC;
