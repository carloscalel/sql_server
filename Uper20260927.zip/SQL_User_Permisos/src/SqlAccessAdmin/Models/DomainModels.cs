using System.Collections.ObjectModel;
using SqlAccessAdmin.Infrastructure;

namespace SqlAccessAdmin.Models;

public enum AppRole { Administrator, Operator, Auditor }
public sealed record SessionContext(string Principal, AppRole Role);
public sealed record PivotOptions(string Server, string Instance, string Database, bool IntegratedSecurity, string? User, string? Password, bool Encrypt, bool TrustCertificate)
{ public string DataSource => string.IsNullOrWhiteSpace(Instance) ? Server : $"{Server}\\{Instance}"; }

public sealed class ServerItem : BindableBase
{
    private bool _selected,_active;
    public int Id { get; init; } public bool IsSelected { get => _selected; set => Set(ref _selected, value); }
    public bool Active { get=>_active; set=>Set(ref _active,value); } public string Name { get; init; } = ""; public string Host { get; init; } = ""; public string Instance { get; init; } = "";
    public bool WindowsAuth { get; init; } public string SqlUser { get; init; } = ""; public bool Encrypt { get; init; } public bool TrustCertificate { get; init; } public int TimeoutSeconds { get; init; } = 30;
}
public sealed class DatabaseItem : BindableBase { private bool _selected; public int ServerId { get; init; } public string Server { get; init; }=""; public string Name { get; init; }=""; public bool IsSelected { get=>_selected; set=>Set(ref _selected,value); } }
public sealed record DatabaseObjectItem(int ServerId,string Server,string Database,string Schema,string Name,string Kind)
{
    public string QualifiedName=>$"{Schema}.{Name}";
    public string DisplayName=>$"{Schema}.{Name}  ·  {Kind}";
}
public sealed class DatabaseObjectSelectionItem(DatabaseObjectItem item,bool selected=false) : BindableBase
{
    private bool _selected=selected;
    public DatabaseObjectItem Item {get;}=item;
    public string Schema=>Item.Schema;
    public string Name=>Item.Name;
    public string Kind=>Item.Kind;
    public string QualifiedName=>Item.QualifiedName;
    public bool IsSelected {get=>_selected;set=>Set(ref _selected,value);}
}
public sealed record ServerLoginItem(string Name,string Type,bool Enabled)
{
    public string Status=>Enabled?"Habilitado":"Deshabilitado";
    public string StatusForeground=>Enabled?"#15803D":"#B42318";
    public string StatusBackground=>Enabled?"#DCFCE7":"#FEE2E2";
}
public sealed class ObjectPermissionRow(DatabaseObjectItem item,ISet<string> allowedPermissions) : BindableBase
{
    private bool _select,_insert,_update,_delete,_execute;
    public DatabaseObjectItem Item {get;}=item;
    public string Schema=>Item.Schema;
    public string Name=>Item.Name;
    public string Kind=>Item.Kind;
    public string QualifiedName=>Item.QualifiedName;
    public bool CanSelect=>allowedPermissions.Contains("SELECT")&&Kind is "TABLE" or "VIEW" or "FUNCTION";
    public bool CanInsert=>allowedPermissions.Contains("INSERT")&&Kind is "TABLE" or "VIEW";
    public bool CanUpdate=>allowedPermissions.Contains("UPDATE")&&Kind is "TABLE" or "VIEW";
    public bool CanDelete=>allowedPermissions.Contains("DELETE")&&Kind is "TABLE" or "VIEW";
    public bool CanExecute=>allowedPermissions.Contains("EXECUTE")&&Kind is "PROCEDURE" or "FUNCTION";
    public bool GrantSelect {get=>_select;set{if(CanSelect)Set(ref _select,value);}}
    public bool GrantInsert {get=>_insert;set{if(CanInsert)Set(ref _insert,value);}}
    public bool GrantUpdate {get=>_update;set{if(CanUpdate)Set(ref _update,value);}}
    public bool GrantDelete {get=>_delete;set{if(CanDelete)Set(ref _delete,value);}}
    public bool GrantExecute {get=>_execute;set{if(CanExecute)Set(ref _execute,value);}}
    public IEnumerable<string> SelectedPermissions
    {
        get
        {
            if(GrantSelect)yield return "SELECT";
            if(GrantInsert)yield return "INSERT";
            if(GrantUpdate)yield return "UPDATE";
            if(GrantDelete)yield return "DELETE";
            if(GrantExecute)yield return "EXECUTE";
        }
    }
}
public sealed record AuthorizedUser(int Id, string Principal, string Type, AppRole Role, bool Active, string Notes);
public sealed record AuditEvent(DateTime Date, string User, string Form, string Action, string Server, string Database, bool Success, string Detail);
public sealed record OperationResult(string Server, string Database, bool Success, string Message);
public sealed record CryptoMaterial(Guid KeyId, byte[] MasterKey);
public sealed record CredentialEnvelope(byte[] Ciphertext, byte[] Nonce, byte[] Tag, Guid KeyId);
public sealed record ServerConnectionInfo(int Id,string Name,string Host,string Instance,bool WindowsAuth,string SqlUser,CredentialEnvelope? Credential,bool Encrypt,bool TrustCertificate,int TimeoutSeconds);
public sealed record ServerEditData(int? Id,string Name,string Host,string Instance,bool WindowsAuth,string SqlUser,string? Password,bool Encrypt,bool TrustCertificate,int TimeoutSeconds,bool Active);
public sealed record PolicyOperation(string Code,string Name,bool Enabled,bool RequiresApproval,string Risk,string Description);
public sealed record PolicyPermission(string Permission,string Scope,bool AllowGrant,bool AllowDeny,bool AllowRevoke,bool Enabled,string ApprovedBy,DateTime ApprovedAt);
public sealed record PolicyRole(string Name,string Kind,bool Enabled,string ApprovedBy,DateTime ApprovedAt,string Notes);
public sealed class RoleSelectionItem(PolicyRole role) : BindableBase
{
    private bool _selected;
    public PolicyRole Role { get; }=role;
    public string Name=>Role.Name;
    public string Kind=>Role.Kind;
    public bool IsSelected {get=>_selected;set=>Set(ref _selected,value);}
}
public sealed class DatabaseRoleSelectionItem : BindableBase
{
    private bool _isSelected;
    public DatabaseRoleSelectionItem(string name,string kind,bool isAllowed,bool isAssigned)
    {
        Name=name;
        Kind=kind;
        IsAllowed=isAllowed;
        InitiallyAssigned=isAssigned;
        _isSelected=isAssigned;
    }
    public string Name {get;}
    public string Kind {get;}
    public bool IsAllowed {get;}
    public bool InitiallyAssigned {get;}
    public bool IsSelected
    {
        get=>_isSelected;
        set
        {
            if(!IsAllowed)return;
            if(Set(ref _isSelected,value))Raise(nameof(HasChange));
        }
    }
    public bool HasChange=>IsAllowed&&IsSelected!=InitiallyAssigned;
    public string MembershipStatus=>InitiallyAssigned?"Asignado actualmente":"No asignado";
    public string PolicyStatus=>IsAllowed?"Autorizado por política":"Solo consulta · no autorizado";
    public string SecurityIcon=>IsAllowed?"✓":"🔒";
    public string SecurityHint=>IsAllowed
        ? "Este rol fue habilitado por la política central."
        : "Rol bloqueado: un administrador debe autorizarlo en Política de seguridad y no puede pertenecer a la denylist.";
}
public sealed class PermissionSelectionItem(PolicyPermission permission) : BindableBase
{
    private bool _selected;
    public PolicyPermission PermissionRule { get; }=permission;
    public string Name=>PermissionRule.Permission;
    public string Description=>Name.ToUpperInvariant() switch
    {
        "SELECT"=>"Consultar y leer datos",
        "INSERT"=>"Agregar nuevos registros",
        "UPDATE"=>"Modificar registros existentes",
        "DELETE"=>"Eliminar registros",
        "EXECUTE"=>"Ejecutar procedimientos y funciones",
        _=>"Aplicar esta acción autorizada"
    };
    public bool IsSelected {get=>_selected;set=>Set(ref _selected,value);}
}
public sealed record DenyRule(int Id,string Category,string Value,string Reason,bool IsSystem,bool Active,string CreatedBy,DateTime CreatedAt);
public sealed record PolicyDecision(bool Allowed,bool RequiresApproval,string Risk,string Reason);
public sealed record AccessRequestItem(long Id,string Operation,string TargetPrincipal,string SourcePrincipal,string AuthenticationType,string PermissionAction,string Permission,string Scope,string Securable,string Role,string ExternalTicketNumber,string Justification,string Status,string RequestedBy,DateTime RequestedAt,string ApprovedBy,DateTime? ApprovedAt,int TargetCount,int StepCount)
{
    public string TicketDisplay=>string.IsNullOrWhiteSpace(ExternalTicketNumber)?"Sin ticket histórico":ExternalTicketNumber;
    public string RequestTitle=>$"Solicitud #{Id} · {Operation}{(StepCount>0?$" + {StepCount} pasos internos":"")}";
}
public sealed record AccessRequestDraft(string Operation,string TargetPrincipal,string? SourcePrincipal,string? AuthenticationType,string? PermissionAction,string? Permission,string? Scope,string? Securable,string? Role,string ExternalTicketNumber,string Justification);
public sealed record AccessRequestStepDraft(int Order,string Operation,string? PermissionAction,string? Permission,string? Scope,string? Securable,string? Role);
public sealed record AccessRequestStepItem(long Id,int Order,string Operation,string PermissionAction,string Permission,string Scope,string Securable,string Role);
public sealed record RequestSecretData(CredentialEnvelope Envelope,bool PasswordPolicy,bool PasswordExpiration,bool MustChangePassword);
public sealed record AuditIntegrity(long HashedEvents,int BrokenLinks,int AlteredEvents,bool IsValid);

public enum SecurityNodeKind
{
    Server,
    LoginGroup,
    Login,
    DatabaseGroup,
    Database,
    UserGroup,
    User,
    Loading,
    Error
}

public sealed class SecurityTreeNode : BindableBase
{
    private bool _isLoaded;
    private bool _isVisible=true;
    private bool _isExpanded;

    public SecurityTreeNode(
        string name,
        SecurityNodeKind kind,
        int serverId,
        string serverName,
        string database = "",
        string principal = "",
        bool loadOnExpand = false,
        bool? loginEnabled = null)
    {
        Name = name;
        Kind = kind;
        ServerId = serverId;
        ServerName = serverName;
        Database = database;
        Principal = principal;
        LoadOnExpand = loadOnExpand;
        LoginEnabled = loginEnabled;
        if (loadOnExpand)
            Children.Add(new SecurityTreeNode("Cargando…", SecurityNodeKind.Loading, serverId, serverName));
    }

    public string Name { get; }
    public SecurityNodeKind Kind { get; }
    public int ServerId { get; }
    public string ServerName { get; }
    public string Database { get; }
    public string Principal { get; }
    public bool LoadOnExpand { get; }
    public bool? LoginEnabled { get; }
    public bool HasLoginState => Kind == SecurityNodeKind.Login && LoginEnabled.HasValue;
    public string LoginStateLabel => LoginEnabled switch { true => "Habilitado", false => "Deshabilitado", _ => "" };
    public string LoginStateColor => LoginEnabled switch { true => "#15803D", false => "#B42318", _ => "#60789F" };
    public string LoginStateBackground => LoginEnabled switch { true => "#EAF8EF", false => "#FFF0EE", _ => "#F2F6FD" };
    public ObservableCollection<SecurityTreeNode> Children { get; } = [];
    public bool IsPrincipal => Kind is SecurityNodeKind.Login or SecurityNodeKind.User;
    public bool IsLoaded { get => _isLoaded; set => Set(ref _isLoaded, value); }
    public bool IsVisible { get => _isVisible; set => Set(ref _isVisible, value); }
    public bool IsExpanded { get => _isExpanded; set => Set(ref _isExpanded, value); }
    public string Icon => Kind switch
    {
        SecurityNodeKind.Server => "▣",
        SecurityNodeKind.LoginGroup => "♟",
        SecurityNodeKind.Login => LoginEnabled==false ? "⊘" : "●",
        SecurityNodeKind.DatabaseGroup => "▰",
        SecurityNodeKind.Database => "●",
        SecurityNodeKind.UserGroup => "♟",
        SecurityNodeKind.User => "●",
        SecurityNodeKind.Error => "!",
        _ => "·"
    };
}

public sealed record SecurityPermissionItem(string State, string Permission, string Scope, string Securable, string Grantor);
public sealed record SecurityMembershipItem(string Type, string Name, string Context);
public sealed record MappedLoginState(string Login, bool Enabled);

public sealed class SecurityPrincipalDetails
{
    public List<SecurityPermissionItem> Permissions { get; } = [];
    public List<SecurityMembershipItem> Memberships { get; } = [];
}
