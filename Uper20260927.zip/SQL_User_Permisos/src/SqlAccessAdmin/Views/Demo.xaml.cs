﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace SqlAccessAdmin.Views
{
    public partial class Demo : Page
    {
        // Modelo para representar un usuario de la lista simulada
        public class LoginSimulado
        {
            public string Nombre { get; set; } = string.Empty;
            public string Tipo { get; set; } = string.Empty;
            public string Estado { get; set; } = string.Empty;
            public string ColorFondoEstado => Estado == "Habilitado" ? "#DCFCE7" : "#FEE2E2";
            public string ColorTextoEstado => Estado == "Habilitado" ? "#15803D" : "#B91C1C";
            public string RolServidor { get; set; } = string.Empty;
            public string FechaCreacion { get; set; } = string.Empty;
        }

        // Modelo para representar un objeto (Securable) de la BD
        // 1. Añade la propiedad BaseDatos a tu modelo existente
        public class ObjetoSeguridadSimulado
        {
            public string BaseDatos { get; set; } = string.Empty;
            public string Esquema { get; set; } = string.Empty;
            public string NombreObjeto { get; set; } = string.Empty;
            public string TipoObjeto { get; set; } = string.Empty;
            public bool GrantSelect { get; set; }
            public bool GrantInsert { get; set; }
            public bool GrantUpdate { get; set; }
            public bool GrantDelete { get; set; }
            public bool GrantExecute { get; set; }
            public bool GrantControl { get; set; }

            public bool EsEjecutable => TipoObjeto == "Stored Procedure" || TipoObjeto == "Función (Scalar)";
            public bool EsDatos => !EsEjecutable;
        }

        // 2. Asigna la BD correspondiente en CargarObjetosSimulados()
        private void CargarObjetosSimulados()
        {
            _listaObjetosBase = new List<ObjetoSeguridadSimulado>
    {
        // adminDB
        new ObjetoSeguridadSimulado { BaseDatos = "adminDB", Esquema = "dbo", NombreObjeto = "Clientes", TipoObjeto = "Tabla", GrantSelect = true },
        new ObjetoSeguridadSimulado { BaseDatos = "adminDB", Esquema = "dbo", NombreObjeto = "UsuariosApp", TipoObjeto = "Tabla" },
        new ObjetoSeguridadSimulado { BaseDatos = "adminDB", Esquema = "dbo", NombreObjeto = "vw_ResumenVentasDiarias", TipoObjeto = "Vista", GrantSelect = true },
        new ObjetoSeguridadSimulado { BaseDatos = "adminDB", Esquema = "dbo", NombreObjeto = "sp_ProcesarPago", TipoObjeto = "Stored Procedure", GrantExecute = true },
        new ObjetoSeguridadSimulado { BaseDatos = "adminDB", Esquema = "dbo", NombreObjeto = "fn_CalcularImpuesto", TipoObjeto = "Función (Scalar)", GrantExecute = true },

        // AdventureWorks2022
        new ObjetoSeguridadSimulado { BaseDatos = "AdventureWorks2022", Esquema = "sales", NombreObjeto = "FacturasEncabezado", TipoObjeto = "Tabla", GrantSelect = true, GrantInsert = true },
        new ObjetoSeguridadSimulado { BaseDatos = "AdventureWorks2022", Esquema = "sales", NombreObjeto = "FacturasDetalle", TipoObjeto = "Tabla", GrantSelect = true, GrantInsert = true },
        new ObjetoSeguridadSimulado { BaseDatos = "AdventureWorks2022", Esquema = "person", NombreObjeto = "Direcciones", TipoObjeto = "Tabla" },
        new ObjetoSeguridadSimulado { BaseDatos = "AdventureWorks2022", Esquema = "sales", NombreObjeto = "vw_ClientesMorosos", TipoObjeto = "Vista" },
        new ObjetoSeguridadSimulado { BaseDatos = "AdventureWorks2022", Esquema = "sales", NombreObjeto = "sp_RegistrarVenta", TipoObjeto = "Stored Procedure", GrantExecute = true },

        // clasesql
        new ObjetoSeguridadSimulado { BaseDatos = "clasesql", Esquema = "dbo", NombreObjeto = "Estudiantes", TipoObjeto = "Tabla", GrantSelect = true },
        new ObjetoSeguridadSimulado { BaseDatos = "clasesql", Esquema = "dbo", NombreObjeto = "Cursos", TipoObjeto = "Tabla", GrantSelect = true },
        new ObjetoSeguridadSimulado { BaseDatos = "clasesql", Esquema = "dbo", NombreObjeto = "sp_InscribirAlumno", TipoObjeto = "Stored Procedure" }
    };

            FiltrarObjetosPorBase("adminDB");
        }

        // 3. Evento que se dispara al cambiar de BD en el ComboBox
        private void CmbBaseDatosObj_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (CmbBaseDatosObj.SelectedItem is ComboBoxItem item)
            {
                string bdSeleccionada = item.Content.ToString();

                // Sincroniza la etiqueta de la cabecera superior azul
                if (TxtBaseSeleccionada != null)
                    TxtBaseSeleccionada.Text = bdSeleccionada;

                FiltrarObjetosPorBase(bdSeleccionada);
            }
        }

        private void FiltrarObjetosPorBase(string nombreBD)
        {
            if (_listaObjetosBase == null) return;

            var objetosFiltrados = _listaObjetosBase
                .Where(o => o.BaseDatos.Equals(nombreBD, StringComparison.OrdinalIgnoreCase))
                .ToList();

            GridObjetosSeguridad.ItemsSource = objetosFiltrados;
        }

        private List<LoginSimulado> _listaLogins;
        private List<ObjetoSeguridadSimulado> _listaObjetosBase;

        public Demo()
        {
            InitializeComponent();

            // Cargar datos al iniciar el componente
            CargarLoginsSimulados();
            CargarObjetosSimulados(); // <- ¡AQUÍ SE AGREGA LA LLAMADA OBLIGATORIA!
        }

        private void CargarLoginsSimulados()
        {
            _listaLogins = new List<LoginSimulado>
            {
                new LoginSimulado { Nombre = "calel", Tipo = "SQL_LOGIN", Estado = "Habilitado", RolServidor = "sysadmin", FechaCreacion = "10/01/2024" },
                new LoginSimulado { Nombre = "calel_test02", Tipo = "SQL_LOGIN", Estado = "Habilitado", RolServidor = "public", FechaCreacion = "15/03/2024" },
                new LoginSimulado { Nombre = "calel_test05", Tipo = "SQL_LOGIN", Estado = "Habilitado", RolServidor = "dbcreator", FechaCreacion = "22/04/2024" },
                new LoginSimulado { Nombre = "CALEL\\josep", Tipo = "WINDOWS_LOGIN", Estado = "Habilitado", RolServidor = "sysadmin", FechaCreacion = "01/02/2023" },
                new LoginSimulado { Nombre = "calelAuditor", Tipo = "SQL_LOGIN", Estado = "Habilitado", RolServidor = "securityadmin", FechaCreacion = "11/05/2024" },
                new LoginSimulado { Nombre = "calelOperador", Tipo = "SQL_LOGIN", Estado = "Habilitado", RolServidor = "processadmin", FechaCreacion = "02/06/2024" },
                new LoginSimulado { Nombre = "MaskedCalel", Tipo = "SQL_LOGIN", Estado = "Habilitado", RolServidor = "public", FechaCreacion = "18/07/2024" },
                new LoginSimulado { Nombre = "ServerCalele", Tipo = "SQL_LOGIN", Estado = "Deshabilitado", RolServidor = "public", FechaCreacion = "05/08/2024" },
                new LoginSimulado { Nombre = "svc_replicacion", Tipo = "SQL_LOGIN", Estado = "Habilitado", RolServidor = "sysadmin", FechaCreacion = "12/09/2023" }
            };

            GridUsuariosServidor.ItemsSource = _listaLogins;
        }

        // Selección de fila en el DataGrid de usuarios
        private void GridUsuariosServidor_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (GridUsuariosServidor.SelectedItem is LoginSimulado usuario)
            {
                TxtUsuarioPrevio.Text = usuario.Nombre;
                BtnCargarUsuario.IsEnabled = true;
            }
            else
            {
                TxtUsuarioPrevio.Text = "Ninguno (Haga clic en la lista)";
                BtnCargarUsuario.IsEnabled = false;
            }
        }

        private void BtnCargarUsuario_Click(object sender, RoutedEventArgs e)
        {
            EjecutarDesbloqueo();
        }

        private void GridUsuariosServidor_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            if (GridUsuariosServidor.SelectedItem != null)
            {
                EjecutarDesbloqueo();
            }
        }

        private void EjecutarDesbloqueo()
        {
            if (GridUsuariosServidor.SelectedItem is LoginSimulado usuario)
            {
                TxtLoginActivo.Text = usuario.Nombre;
                PanelEstadoBloqueado.Visibility = Visibility.Collapsed;
                PanelEstadoDesbloqueado.Visibility = Visibility.Visible;
            }
        }

        private void TxtBuscarLogin_TextChanged(object sender, TextChangedEventArgs e)
        {
            FiltrarLista();
        }

        private void CmbTipoLogin_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            FiltrarLista();
        }

        private void FiltrarLista()
        {
            if (_listaLogins == null) return;

            string filtroTexto = TxtBuscarLogin.Text?.ToLower() ?? "";
            string tipoSeleccionado = (CmbTipoLogin.SelectedItem as ComboBoxItem)?.Content.ToString();

            var resultado = _listaLogins.Where(u =>
                (string.IsNullOrEmpty(filtroTexto) || u.Nombre.ToLower().Contains(filtroTexto)) &&
                (tipoSeleccionado == "Todos los tipos" || u.Tipo == tipoSeleccionado)
            ).ToList();

            GridUsuariosServidor.ItemsSource = resultado;
        }

        private void BtnBuscarUsuario_Click(object sender, RoutedEventArgs e)
        {
            PanelEstadoDesbloqueado.Visibility = Visibility.Collapsed;
            PanelEstadoBloqueado.Visibility = Visibility.Visible;
        }

        private void LstBasesDatos_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (e.AddedItems.Count > 0 && TxtBaseSeleccionada != null)
            {
                ListBoxItem item = e.AddedItems[0] as ListBoxItem;
                if (item != null)
                {
                    string nombreBD = item.Content.ToString().Replace("🗄️ ", "").Trim();
                    TxtBaseSeleccionada.Text = nombreBD;
                }
            }
        }

        private void OnPermisoCambiado(object sender, RoutedEventArgs e) { }
        private void BtnVistaPrevia_Click(object sender, RoutedEventArgs e) { }
        private void BtnEnviarConfirmacion_Click(object sender, RoutedEventArgs e) { }
        // Evento único para el cambio en cualquier ComboBox de filtro
        private void OnFiltroObjetoCambiado(object sender, SelectionChangedEventArgs e)
        {
            AplicarFiltrosCombinadosObjetos();
        }

        // Evento para cuando el usuario escribe en la caja de texto
        private void TxtBuscarObjeto_TextChanged(object sender, TextChangedEventArgs e)
        {
            AplicarFiltrosCombinadosObjetos();
        }

        // Botón para reiniciar filtros
        private void BtnResetFiltrosObj_Click(object sender, RoutedEventArgs e)
        {
            if (CmbEsquemaObj != null) CmbEsquemaObj.SelectedIndex = 0;
            if (CmbTipoObjeto != null) CmbTipoObjeto.SelectedIndex = 0;
            if (TxtBuscarObjeto != null) TxtBuscarObjeto.Text = string.Empty;
        }

        private void AplicarFiltrosCombinadosObjetos()
        {
            if (_listaObjetosBase == null || CmbBaseDatosObj == null) return;

            // 1. Obtener valores de los filtros
            string bdSeleccionada = (CmbBaseDatosObj.SelectedItem as ComboBoxItem)?.Content.ToString() ?? "";
            string esquemaSeleccionado = (CmbEsquemaObj?.SelectedItem as ComboBoxItem)?.Content.ToString() ?? "[Todos]";
            string tipoSeleccionado = (CmbTipoObjeto?.SelectedItem as ComboBoxItem)?.Content.ToString() ?? "[Todos]";
            string textoBusqueda = TxtBuscarObjeto?.Text.Trim().ToLower() ?? "";

            // 2. Sincronizar etiqueta superior de BD
            if (TxtBaseSeleccionada != null && !string.IsNullOrEmpty(bdSeleccionada))
            {
                TxtBaseSeleccionada.Text = bdSeleccionada;
            }

            // 3. Aplicar consulta de filtrado combinada
            var resultado = _listaObjetosBase.Where(obj =>
                obj.BaseDatos.Equals(bdSeleccionada, StringComparison.OrdinalIgnoreCase) &&
                (esquemaSeleccionado == "[Todos]" || obj.Esquema.Equals(esquemaSeleccionado, StringComparison.OrdinalIgnoreCase)) &&
                (tipoSeleccionado == "[Todos]" || obj.TipoObjeto.StartsWith(tipoSeleccionado, StringComparison.OrdinalIgnoreCase)) &&
                (string.IsNullOrEmpty(textoBusqueda) || obj.NombreObjeto.ToLower().Contains(textoBusqueda))
            ).ToList();

            GridObjetosSeguridad.ItemsSource = resultado;
        }
    }
}