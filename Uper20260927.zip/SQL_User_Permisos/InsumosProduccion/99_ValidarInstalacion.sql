USE [adminDB];
GO
SET NOCOUNT ON;
GO

DECLARE @Expected table(ObjectType varchar(10),ObjectName sysname);
INSERT @Expected VALUES
 ('TABLE','AppRole'),('TABLE','AuthorizedPrincipal'),('TABLE','ManagedServer'),('TABLE','AuditEvent'),('TABLE','CryptoConfiguration'),
 ('TABLE','SecurityPolicyOperation'),('TABLE','SecurityPolicyPermission'),('TABLE','SecurityPolicyRole'),('TABLE','SecurityDenyList'),('TABLE','AccessRequest'),('TABLE','AccessRequestTarget'),
 ('TABLE','AccessRequestStep'),
 ('TYPE','AccessRequestTargetType'),('TYPE','AccessRequestStepType'),
 ('PROC','usp_App_LoginContext'),('PROC','usp_Server_List'),
 ('PROC','usp_AuthorizedUser_List'),('PROC','usp_Audit_List'),('PROC','usp_Server_GetConnection'),
 ('PROC','usp_Audit_Write'),('PROC','usp_AuthorizedUser_Upsert'),('PROC','usp_Server_Upsert'),
 ('PROC','usp_Server_SetActive'),('PROC','usp_Crypto_GetKey'),('PROC','usp_AccessRequest_Preview'),('PROC','usp_AccessRequest_Create'),
 ('PROC','usp_AccessRequest_List'),('PROC','usp_AccessRequest_TargetList'),('PROC','usp_AccessRequest_Approve'),
 ('PROC','usp_AccessRequest_MarkExecuted'),('PROC','usp_AccessRequest_StepList'),('PROC','usp_AccessRequest_SecretGet'),
 ('PROC','usp_AccessRequest_SecretDiscard'),('PROC','usp_Audit_ValidateIntegrity'),
 ('PROC','usp_Policy_OperationList'),('PROC','usp_Policy_PermissionList'),('PROC','usp_Policy_RoleList'),
 ('PROC','usp_Policy_DenyList'),('PROC','usp_Policy_PermissionUpsert'),('PROC','usp_Policy_RoleUpsert'),
 ('PROC','usp_Policy_DenyUpsert'),('TRIGGER','tr_AuditEvent_AppendOnly');

SELECT e.ObjectType,e.ObjectName,
 CASE e.ObjectType WHEN 'TYPE' THEN IIF(TYPE_ID(N'[access].'+e.ObjectName) IS NULL,'FALTA','OK')
                   ELSE IIF(OBJECT_ID(N'[access].'+e.ObjectName) IS NULL,'FALTA','OK') END AS [Status]
FROM @Expected e ORDER BY e.ObjectType,e.ObjectName;

SELECT RoleName,Description FROM [access].AppRole ORDER BY RoleName;
SELECT name AS DatabaseRole,
       IIF(name IN (N'SqlAccessAdmin_Administrator',N'SqlAccessAdmin_Operator',N'SqlAccessAdmin_Auditor',N'SqlAccessAdmin_Users'),N'OK',N'REVISAR') AS [Status]
FROM sys.database_principals
WHERE type='R' AND name LIKE N'SqlAccessAdmin[_]%'
ORDER BY name;
SELECT UserId,Principal,RoleName,Active FROM [access].AuthorizedPrincipal ORDER BY Principal;
SELECT ServerId,Name,Host,Instance,Active,Encrypt,TrustServerCertificate,TimeoutSeconds FROM [access].ManagedServer ORDER BY Name;
SELECT RoleName,RoleKind,Enabled,Notes FROM [access].SecurityPolicyRole ORDER BY RoleKind,RoleName;

IF OBJECT_ID(N'[access].usp_Policy_RoleUpsert',N'P') IS NULL
    THROW 51111, 'Falta la administración controlada de roles. Ejecute 17_AdministrarPoliticaPermisosRoles.sql.', 1;

IF NOT EXISTS(SELECT 1 FROM [access].SecurityPolicyOperation WHERE OperationCode='CREATE_WINDOWS_LOGIN' AND Enabled=1)
   OR NOT EXISTS(SELECT 1 FROM [access].SecurityPolicyOperation WHERE OperationCode='MODIFY_LOGIN' AND Enabled=1)
    THROW 51112, 'Falta la política simplificada. Ejecute 12_SimplificarGestionAccesos.sql.', 1;

IF EXISTS
(
    SELECT 1
    FROM [access].SecurityPolicyPermission
    WHERE Enabled=1
      AND (PermissionName NOT IN('SELECT','INSERT','UPDATE','DELETE','EXECUTE')
           OR ScopeType NOT IN('DATABASE','OBJECT')
           OR AllowDeny=1)
)
    THROW 51113, 'Existen permisos activos fuera del modelo simplificado.', 1;

IF NOT EXISTS
(
    SELECT 1 FROM sys.parameters
    WHERE object_id=OBJECT_ID(N'[access].usp_AccessRequest_List',N'P')
      AND name=N'@ServerId'
)
    THROW 51114, 'Falta el control de servidor único. Ejecute 13_RestringirServidorUnico.sql.', 1;

IF NOT EXISTS
(
    SELECT 1
    FROM [access].SecurityPolicyOperation
    WHERE OperationCode='MODIFY_LOGIN'
      AND Enabled=1
      AND DisplayName=N'Modificar acceso del login'
)
    THROW 51115, 'Falta el rediseño de mapeo de login. Ejecute 14_RedisenarMapeoLogin.sql.', 1;

IF OBJECT_DEFINITION(OBJECT_ID(N'[access].usp_AccessRequest_Create',N'P')) NOT LIKE N'%SqlAccessAdmin.AccessRequestCreate%'
   OR OBJECT_DEFINITION(OBJECT_ID(N'[access].usp_AccessRequest_Approve',N'P')) NOT LIKE N'%SqlAccessAdmin.AccessRequestApprove%'
    THROW 51116, 'Falta el control de solicitudes duplicadas. Ejecute 15_PrevenirSolicitudesDuplicadas.sql.', 1;

IF OBJECT_DEFINITION(OBJECT_ID(N'[access].usp_AccessRequest_Approve',N'P')) NOT LIKE N'%SqlAccessAdmin.SelfConfirmation%'
   OR OBJECT_DEFINITION(OBJECT_ID(N'[access].usp_AccessRequest_MarkExecuted',N'P')) NOT LIKE N'%SqlAccessAdmin.SelfConfirmationExecution%'
    THROW 51117, 'Falta la autoconfirmación. Ejecute 16_HabilitarAutoconfirmacion.sql.', 1;

IF COL_LENGTH(N'[access].AccessRequest',N'ExternalTicketNumber') IS NULL
   OR NOT EXISTS
   (
       SELECT 1 FROM sys.parameters
       WHERE object_id=OBJECT_ID(N'[access].usp_AccessRequest_Create',N'P')
         AND name=N'@ExternalTicketNumber'
   )
    THROW 51118, 'Falta el ticket externo obligatorio. Ejecute 18_TicketExternoSolicitudes.sql.', 1;

IF OBJECT_ID(N'[access].AccessRequestStep',N'U') IS NULL
   OR TYPE_ID(N'[access].AccessRequestStepType') IS NULL
   OR COL_LENGTH(N'[access].AccessRequest',N'SecretCiphertext') IS NULL
   OR OBJECT_ID(N'[access].usp_AccessRequest_SecretGet',N'P') IS NULL
    THROW 51119, 'Falta la solicitud compuesta y contraseña temporal. Ejecute 19_SolicitudCompuestaYContrasenaTemporal.sql.', 1;

IF EXISTS
(
 SELECT 1 FROM @Expected e WHERE
   (e.ObjectType='TYPE' AND TYPE_ID(N'[access].'+e.ObjectName) IS NULL)
   OR (e.ObjectType<>'TYPE' AND OBJECT_ID(N'[access].'+e.ObjectName) IS NULL)
)
    THROW 51110, 'La instalación está incompleta. Revise los objetos marcados como FALTA.', 1;

IF EXISTS
(
    SELECT 1
    FROM @Expected e
    WHERE e.ObjectType<>'TYPE'
      AND OBJECT_ID(N'[dbo].'+QUOTENAME(e.ObjectName)) IS NOT NULL
)
    THROW 51120, 'Aún existen objetos propios de la aplicación en dbo. Ejecute 20_MigrarObjetosAlEsquemaAccess.sql.', 1;

IF EXISTS
(
    SELECT 1
    FROM @Expected e
    WHERE e.ObjectType='TYPE'
      AND TYPE_ID(N'[dbo].'+QUOTENAME(e.ObjectName)) IS NOT NULL
)
    THROW 51121, 'Aún existen tipos propios de la aplicación en dbo. Ejecute 20_MigrarObjetosAlEsquemaAccess.sql.', 1;

IF EXISTS
(
    SELECT 1
    FROM @Expected e
    WHERE e.ObjectType<>'TYPE'
      AND OBJECT_ID(N'[SqlAccessAdmin].'+QUOTENAME(e.ObjectName)) IS NOT NULL
)
    THROW 51122, 'Aún existen objetos propios de la aplicación en el esquema anterior SqlAccessAdmin. Ejecute 20_MigrarObjetosAlEsquemaAccess.sql.', 1;

IF EXISTS
(
    SELECT 1
    FROM @Expected e
    WHERE e.ObjectType='TYPE'
      AND TYPE_ID(N'[SqlAccessAdmin].'+QUOTENAME(e.ObjectName)) IS NOT NULL
)
    THROW 51123, 'Aún existen tipos propios de la aplicación en el esquema anterior SqlAccessAdmin. Ejecute 20_MigrarObjetosAlEsquemaAccess.sql.', 1;

PRINT N'Validación de objetos completada correctamente.';
GO

