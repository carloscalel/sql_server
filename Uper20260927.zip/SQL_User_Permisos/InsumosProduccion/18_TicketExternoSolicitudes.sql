USE [adminDB];
GO
SET NOCOUNT ON;
SET XACT_ABORT ON;
GO

/*
  Agrega el ticket externo estandarizado a las solicitudes. Las filas históricas
  permanecen con NULL; todas las solicitudes nuevas requieren TIC-RF-<dígitos>.
*/

IF COL_LENGTH(N'[access].AccessRequest',N'ExternalTicketNumber') IS NULL
    ALTER TABLE [access].AccessRequest ADD ExternalTicketNumber varchar(40) NULL;
GO

IF NOT EXISTS(SELECT 1 FROM sys.check_constraints WHERE name=N'CK_AccessRequest_ExternalTicket')
    ALTER TABLE [access].AccessRequest ADD CONSTRAINT CK_AccessRequest_ExternalTicket CHECK
    (
        ExternalTicketNumber IS NULL OR
        (
            ExternalTicketNumber LIKE 'TIC-RF-%'
            AND LEN(ExternalTicketNumber)>7
            AND SUBSTRING(ExternalTicketNumber,8,40) NOT LIKE '%[^0-9]%'
        )
    );
GO

IF NOT EXISTS(SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID(N'[access].AccessRequest') AND name=N'IX_AccessRequest_ExternalTicket')
    CREATE INDEX IX_AccessRequest_ExternalTicket ON [access].AccessRequest(ExternalTicketNumber,RequestedAt DESC);
GO

CREATE OR ALTER PROCEDURE [access].usp_AccessRequest_List
    @Status varchar(20)=NULL,
    @ServerId int=NULL
AS
BEGIN
    SET NOCOUNT ON;
    SELECT
        r.RequestId,r.OperationCode,r.TargetPrincipal,
        ISNULL(r.SourcePrincipal,N'') SourcePrincipal,
        ISNULL(r.AuthenticationType,'') AuthenticationType,
        ISNULL(r.PermissionAction,'') PermissionAction,
        ISNULL(r.PermissionName,'') PermissionName,
        ISNULL(r.ScopeType,'') ScopeType,
        ISNULL(r.Securable,N'') Securable,
        ISNULL(r.RoleName,N'') RoleName,
        ISNULL(r.ExternalTicketNumber,'') ExternalTicketNumber,
        r.Justification,r.Status,r.RequestedBy,r.RequestedAt,
        ISNULL(r.ApprovedBy,N'') ApprovedBy,r.ApprovedAt,
        (SELECT COUNT(*) FROM [access].AccessRequestTarget t WHERE t.RequestId=r.RequestId) TargetCount
    FROM [access].AccessRequest r
    WHERE (@Status IS NULL OR r.Status=@Status)
      AND (@ServerId IS NULL OR
          (EXISTS(SELECT 1 FROM [access].AccessRequestTarget st WHERE st.RequestId=r.RequestId AND st.ServerId=@ServerId)
           AND NOT EXISTS(SELECT 1 FROM [access].AccessRequestTarget other WHERE other.RequestId=r.RequestId AND other.ServerId<>@ServerId)))
    ORDER BY r.RequestedAt DESC;
END;
GO

CREATE OR ALTER PROCEDURE [access].usp_AccessRequest_Create
    @OperationCode varchar(40),
    @TargetPrincipal nvarchar(256),
    @SourcePrincipal nvarchar(256)=NULL,
    @AuthenticationType varchar(20)=NULL,
    @PermissionAction varchar(10)=NULL,
    @PermissionName varchar(40)=NULL,
    @ScopeType varchar(20)=NULL,
    @Securable nvarchar(776)=NULL,
    @RoleName sysname=NULL,
    @ExternalTicketNumber varchar(40),
    @Justification nvarchar(1000),
    @Targets [access].AccessRequestTargetType READONLY
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    -- SqlAccessAdmin.AccessRequestCreate: conserva el bloqueo transaccional de duplicados.

    SET @ExternalTicketNumber=UPPER(LTRIM(RTRIM(@ExternalTicketNumber)));
    IF @ExternalTicketNumber NOT LIKE 'TIC-RF-%'
       OR LEN(@ExternalTicketNumber)<=7
       OR SUBSTRING(@ExternalTicketNumber,8,40) LIKE '%[^0-9]%'
        THROW 51320,'El ticket externo debe usar el formato TIC-RF- seguido únicamente por dígitos.',1;
    IF NOT EXISTS(SELECT 1 FROM @Targets)
        THROW 51310,'Debe seleccionar destinos.',1;
    IF (SELECT COUNT(DISTINCT ServerId) FROM @Targets)<>1
        THROW 51314,'Cada solicitud debe pertenecer a un único servidor.',1;
    IF LEN(LTRIM(RTRIM(@Justification)))<10
        THROW 51311,'La justificación debe contener al menos 10 caracteres.',1;

    DECLARE @Check table(Allowed bit,RequiresApproval bit,RiskLevel varchar(10),Reason nvarchar(2000));
    INSERT @Check EXEC [access].usp_AccessRequest_Preview @OperationCode,@PermissionAction,@PermissionName,@ScopeType,@RoleName;
    IF NOT EXISTS(SELECT 1 FROM @Check WHERE Allowed=1)
        THROW 51312,'Solicitud rechazada por la política central.',1;

    BEGIN TRAN;
    DECLARE @LockResult int;
    EXEC @LockResult=sys.sp_getapplock
        @Resource=N'SqlAccessAdmin.AccessRequestCreate',@LockMode='Exclusive',@LockOwner='Transaction',@LockTimeout=10000;
    IF @LockResult<0 THROW 51317,'No fue posible bloquear el registro de solicitudes.',1;

    DECLARE @ExistingRequestId bigint;
    SELECT TOP(1) @ExistingRequestId=r.RequestId
    FROM [access].AccessRequest r WITH(UPDLOCK,HOLDLOCK)
    WHERE r.Status IN('PENDING','APPROVED')
      AND r.OperationCode=@OperationCode
      AND UPPER(LTRIM(RTRIM(r.TargetPrincipal)))=UPPER(LTRIM(RTRIM(@TargetPrincipal)))
      AND ISNULL(UPPER(LTRIM(RTRIM(r.SourcePrincipal))),N'')=ISNULL(UPPER(LTRIM(RTRIM(@SourcePrincipal))),N'')
      AND ISNULL(UPPER(r.AuthenticationType),'')=ISNULL(UPPER(@AuthenticationType),'')
      AND ISNULL(UPPER(r.PermissionAction),'')=ISNULL(UPPER(@PermissionAction),'')
      AND ISNULL(UPPER(r.PermissionName),'')=ISNULL(UPPER(@PermissionName),'')
      AND ISNULL(UPPER(r.ScopeType),'')=ISNULL(UPPER(@ScopeType),'')
      AND ISNULL(UPPER(LTRIM(RTRIM(r.Securable))),N'')=ISNULL(UPPER(LTRIM(RTRIM(@Securable))),N'')
      AND ISNULL(UPPER(LTRIM(RTRIM(r.RoleName))),N'')=ISNULL(UPPER(LTRIM(RTRIM(@RoleName))),N'')
      AND NOT EXISTS(SELECT ServerId,DatabaseName FROM @Targets EXCEPT SELECT ServerId,DatabaseName FROM [access].AccessRequestTarget WHERE RequestId=r.RequestId)
      AND NOT EXISTS(SELECT ServerId,DatabaseName FROM [access].AccessRequestTarget WHERE RequestId=r.RequestId EXCEPT SELECT ServerId,DatabaseName FROM @Targets)
    ORDER BY r.RequestId DESC;

    IF @ExistingRequestId IS NOT NULL
    BEGIN
        ROLLBACK;
        DECLARE @DuplicateMessage nvarchar(2048)=CONCAT(N'Ya existe la solicitud activa #',@ExistingRequestId,N' con la misma operación, principal y destinos.');
        THROW 51316,@DuplicateMessage,1;
    END;

    INSERT [access].AccessRequest
    (
        OperationCode,TargetPrincipal,SourcePrincipal,AuthenticationType,
        PermissionAction,PermissionName,ScopeType,Securable,RoleName,
        ExternalTicketNumber,Justification
    )
    VALUES
    (
        @OperationCode,@TargetPrincipal,@SourcePrincipal,@AuthenticationType,
        @PermissionAction,@PermissionName,@ScopeType,@Securable,@RoleName,
        @ExternalTicketNumber,@Justification
    );

    DECLARE @Id bigint=SCOPE_IDENTITY();
    INSERT [access].AccessRequestTarget(RequestId,ServerId,DatabaseName)
        SELECT @Id,ServerId,DatabaseName FROM @Targets;
    COMMIT;

    DECLARE @AuditDetail nvarchar(max)=CONCAT(N'Solicitud #',@Id,N' · ',@ExternalTicketNumber,N' · ',@OperationCode);
    EXEC [access].usp_Audit_Write N'Solicitudes',N'Crear',NULL,NULL,1,@AuditDetail;
    SELECT @Id RequestId,'PENDING' [Status];
END;
GO

GRANT EXECUTE ON [access].usp_AccessRequest_List TO [SqlAccessAdmin_Users];
GRANT EXECUTE ON [access].usp_AccessRequest_Create TO [SqlAccessAdmin_Users];
GO

PRINT N'Ticket externo obligatorio instalado.';
GO

