USE [adminDB];
GO
SET NOCOUNT ON;
SET XACT_ABORT ON;
GO

/*
  Migración para instalaciones existentes.

  Mueve los objetos propios de la aplicación desde dbo o desde el nombre
  transitorio SqlAccessAdmin hacia el esquema definitivo access,
  conserva los datos, identificadores y relaciones, y restaura explícitamente
  los permisos de objeto que SQL Server retira durante ALTER SCHEMA,
  y recompila los módulos para actualizar sus referencias calificadas.

  Es idempotente: si un objeto ya está en access no vuelve a moverlo. Si encuentra
  el mismo objeto en más de un esquema se detiene para no elegir silenciosamente
  entre dos fuentes de datos.
*/

IF SCHEMA_ID(N'access') IS NULL
    EXEC(N'CREATE SCHEMA [access] AUTHORIZATION [dbo];');
GO

BEGIN TRY
    BEGIN TRAN;

    DECLARE @Tables table(ObjectName sysname NOT NULL PRIMARY KEY);
    INSERT @Tables(ObjectName) VALUES
      (N'AppRole'),(N'AuthorizedPrincipal'),(N'ManagedServer'),(N'CryptoConfiguration'),(N'AuditEvent'),
      (N'SecurityPolicyOperation'),(N'SecurityPolicyPermission'),(N'SecurityPolicyRole'),(N'SecurityDenyList'),
      (N'AccessRequest'),(N'AccessRequestTarget'),(N'AccessRequestStep');

    DECLARE @Procedures table(ObjectName sysname NOT NULL PRIMARY KEY);
    INSERT @Procedures(ObjectName) VALUES
      (N'usp_App_LoginContext'),(N'usp_Server_List'),(N'usp_Server_GetConnection'),
      (N'usp_AuthorizedUser_List'),(N'usp_Audit_List'),(N'usp_Audit_Write'),
      (N'usp_AuthorizedUser_Upsert'),(N'usp_Server_Upsert'),(N'usp_Server_SetActive'),
      (N'usp_Crypto_GetKey'),(N'usp_Policy_OperationList'),(N'usp_Policy_PermissionList'),
      (N'usp_Policy_RoleList'),(N'usp_Policy_DenyList'),(N'usp_Policy_PermissionUpsert'),
      (N'usp_Policy_RoleUpsert'),(N'usp_Policy_DenyUpsert'),(N'usp_AccessRequest_Preview'),
      (N'usp_AccessRequest_Create'),(N'usp_AccessRequest_List'),(N'usp_AccessRequest_TargetList'),
      (N'usp_AccessRequest_Approve'),(N'usp_AccessRequest_MarkExecuted'),
      (N'usp_AccessRequest_StepList'),(N'usp_AccessRequest_SecretGet'),
      (N'usp_AccessRequest_SecretDiscard'),(N'usp_Audit_ValidateIntegrity');

    DECLARE @Types table(ObjectName sysname NOT NULL PRIMARY KEY);
    INSERT @Types(ObjectName) VALUES (N'AccessRequestTargetType'),(N'AccessRequestStepType');

    DECLARE @Permissions table
    (
        SecurableType varchar(10) NOT NULL,ObjectName sysname NOT NULL,ColumnName sysname NULL,
        PrincipalName sysname NOT NULL,PermissionName sysname NOT NULL,PermissionState char(1) NOT NULL
    );

    INSERT @Permissions(SecurableType,ObjectName,ColumnName,PrincipalName,PermissionName,PermissionState)
    SELECT 'OBJECT',o.name,COL_NAME(dp.major_id,dp.minor_id),USER_NAME(dp.grantee_principal_id),dp.permission_name,dp.state
    FROM sys.database_permissions dp
    JOIN sys.objects o ON o.object_id=dp.major_id
    JOIN sys.schemas s ON s.schema_id=o.schema_id AND s.name IN(N'dbo',N'SqlAccessAdmin')
    WHERE dp.class=1
      AND
      (
          EXISTS(SELECT 1 FROM @Tables x WHERE x.ObjectName=o.name)
          OR EXISTS(SELECT 1 FROM @Procedures x WHERE x.ObjectName=o.name)
          OR o.name=N'tr_AuditEvent_AppendOnly'
      );

    INSERT @Permissions(SecurableType,ObjectName,ColumnName,PrincipalName,PermissionName,PermissionState)
    SELECT 'TYPE',t.name,NULL,USER_NAME(dp.grantee_principal_id),dp.permission_name,dp.state
    FROM sys.database_permissions dp
    JOIN sys.types t ON t.user_type_id=dp.major_id
    JOIN sys.schemas s ON s.schema_id=t.schema_id AND s.name IN(N'dbo',N'SqlAccessAdmin')
    WHERE dp.class=6 AND EXISTS(SELECT 1 FROM @Types x WHERE x.ObjectName=t.name);

    IF EXISTS
    (
        SELECT 1 FROM @Tables x
        WHERE (CASE WHEN OBJECT_ID(N'dbo.'+x.ObjectName,N'U') IS NULL THEN 0 ELSE 1 END
             + CASE WHEN OBJECT_ID(N'SqlAccessAdmin.'+x.ObjectName,N'U') IS NULL THEN 0 ELSE 1 END
             + CASE WHEN OBJECT_ID(N'access.'+x.ObjectName,N'U') IS NULL THEN 0 ELSE 1 END)>1
    )
        THROW 51400,'Hay tablas de la aplicación duplicadas entre dbo, SqlAccessAdmin y access. Resuelva el conflicto antes de migrar.',1;

    IF EXISTS
    (
        SELECT 1 FROM @Procedures x
        WHERE (CASE WHEN OBJECT_ID(N'dbo.'+x.ObjectName,N'P') IS NULL THEN 0 ELSE 1 END
             + CASE WHEN OBJECT_ID(N'SqlAccessAdmin.'+x.ObjectName,N'P') IS NULL THEN 0 ELSE 1 END
             + CASE WHEN OBJECT_ID(N'access.'+x.ObjectName,N'P') IS NULL THEN 0 ELSE 1 END)>1
    )
        THROW 51401,'Hay procedimientos de la aplicación duplicados entre dbo, SqlAccessAdmin y access. Resuelva el conflicto antes de migrar.',1;

    IF EXISTS
    (
        SELECT 1 FROM @Types x
        WHERE (CASE WHEN TYPE_ID(N'dbo.'+x.ObjectName) IS NULL THEN 0 ELSE 1 END
             + CASE WHEN TYPE_ID(N'SqlAccessAdmin.'+x.ObjectName) IS NULL THEN 0 ELSE 1 END
             + CASE WHEN TYPE_ID(N'access.'+x.ObjectName) IS NULL THEN 0 ELSE 1 END)>1
    )
        THROW 51402,'Hay tipos de la aplicación duplicados entre dbo, SqlAccessAdmin y access. Resuelva el conflicto antes de migrar.',1;

    IF (CASE WHEN OBJECT_ID(N'dbo.tr_AuditEvent_AppendOnly',N'TR') IS NULL THEN 0 ELSE 1 END
      + CASE WHEN OBJECT_ID(N'SqlAccessAdmin.tr_AuditEvent_AppendOnly',N'TR') IS NULL THEN 0 ELSE 1 END
      + CASE WHEN OBJECT_ID(N'access.tr_AuditEvent_AppendOnly',N'TR') IS NULL THEN 0 ELSE 1 END)>1
        THROW 51403,'El trigger de auditoría está duplicado entre dbo, SqlAccessAdmin y access. Resuelva el conflicto antes de migrar.',1;

    DECLARE @Modules table(ObjectName sysname NOT NULL PRIMARY KEY,ModuleType char(2) NOT NULL,Definition nvarchar(max) NOT NULL);
    INSERT @Modules(ObjectName,ModuleType,Definition)
    SELECT p.ObjectName,'P',OBJECT_DEFINITION(COALESCE(
        OBJECT_ID(N'dbo.'+p.ObjectName,N'P'),
        OBJECT_ID(N'SqlAccessAdmin.'+p.ObjectName,N'P'),
        OBJECT_ID(N'access.'+p.ObjectName,N'P')))
    FROM @Procedures p
    WHERE COALESCE(
        OBJECT_ID(N'dbo.'+p.ObjectName,N'P'),
        OBJECT_ID(N'SqlAccessAdmin.'+p.ObjectName,N'P'),
        OBJECT_ID(N'access.'+p.ObjectName,N'P')) IS NOT NULL;

    IF COALESCE(
        OBJECT_ID(N'dbo.tr_AuditEvent_AppendOnly',N'TR'),
        OBJECT_ID(N'SqlAccessAdmin.tr_AuditEvent_AppendOnly',N'TR'),
        OBJECT_ID(N'access.tr_AuditEvent_AppendOnly',N'TR')) IS NOT NULL
        INSERT @Modules(ObjectName,ModuleType,Definition)
        VALUES(N'tr_AuditEvent_AppendOnly','TR',OBJECT_DEFINITION(COALESCE(
            OBJECT_ID(N'dbo.tr_AuditEvent_AppendOnly',N'TR'),
            OBJECT_ID(N'SqlAccessAdmin.tr_AuditEvent_AppendOnly',N'TR'),
            OBJECT_ID(N'access.tr_AuditEvent_AppendOnly',N'TR'))));

    DECLARE @Name sysname,@SourceSchema sysname,@Sql nvarchar(max);
    DECLARE TableCursor CURSOR LOCAL FAST_FORWARD FOR SELECT ObjectName FROM @Tables ORDER BY ObjectName;
    OPEN TableCursor;FETCH NEXT FROM TableCursor INTO @Name;
    WHILE @@FETCH_STATUS=0
    BEGIN
        SET @SourceSchema=CASE WHEN OBJECT_ID(N'dbo.'+@Name,N'U') IS NOT NULL THEN N'dbo'
                               WHEN OBJECT_ID(N'SqlAccessAdmin.'+@Name,N'U') IS NOT NULL THEN N'SqlAccessAdmin' END;
        IF @SourceSchema IS NOT NULL
        BEGIN
            SET @Sql=N'ALTER SCHEMA [access] TRANSFER OBJECT::'+QUOTENAME(@SourceSchema)+N'.'+QUOTENAME(@Name)+N';';
            EXEC sys.sp_executesql @Sql;
        END;
        FETCH NEXT FROM TableCursor INTO @Name;
    END;
    CLOSE TableCursor;DEALLOCATE TableCursor;

    DECLARE ProcedureCursor CURSOR LOCAL FAST_FORWARD FOR SELECT ObjectName FROM @Procedures ORDER BY ObjectName;
    OPEN ProcedureCursor;FETCH NEXT FROM ProcedureCursor INTO @Name;
    WHILE @@FETCH_STATUS=0
    BEGIN
        SET @SourceSchema=CASE WHEN OBJECT_ID(N'dbo.'+@Name,N'P') IS NOT NULL THEN N'dbo'
                               WHEN OBJECT_ID(N'SqlAccessAdmin.'+@Name,N'P') IS NOT NULL THEN N'SqlAccessAdmin' END;
        IF @SourceSchema IS NOT NULL
        BEGIN
            SET @Sql=N'ALTER SCHEMA [access] TRANSFER OBJECT::'+QUOTENAME(@SourceSchema)+N'.'+QUOTENAME(@Name)+N';';
            EXEC sys.sp_executesql @Sql;
        END;
        FETCH NEXT FROM ProcedureCursor INTO @Name;
    END;
    CLOSE ProcedureCursor;DEALLOCATE ProcedureCursor;

    SET @SourceSchema=CASE WHEN OBJECT_ID(N'dbo.tr_AuditEvent_AppendOnly',N'TR') IS NOT NULL THEN N'dbo'
                           WHEN OBJECT_ID(N'SqlAccessAdmin.tr_AuditEvent_AppendOnly',N'TR') IS NOT NULL THEN N'SqlAccessAdmin' END;
    IF @SourceSchema IS NOT NULL
    BEGIN
        SET @Sql=N'ALTER SCHEMA [access] TRANSFER OBJECT::'+QUOTENAME(@SourceSchema)+N'.[tr_AuditEvent_AppendOnly];';
        EXEC sys.sp_executesql @Sql;
    END;

    DECLARE TypeCursor CURSOR LOCAL FAST_FORWARD FOR SELECT ObjectName FROM @Types ORDER BY ObjectName;
    OPEN TypeCursor;FETCH NEXT FROM TypeCursor INTO @Name;
    WHILE @@FETCH_STATUS=0
    BEGIN
        SET @SourceSchema=CASE WHEN TYPE_ID(N'dbo.'+@Name) IS NOT NULL THEN N'dbo'
                               WHEN TYPE_ID(N'SqlAccessAdmin.'+@Name) IS NOT NULL THEN N'SqlAccessAdmin' END;
        IF @SourceSchema IS NOT NULL
        BEGIN
            SET @Sql=N'ALTER SCHEMA [access] TRANSFER TYPE::'+QUOTENAME(@SourceSchema)+N'.'+QUOTENAME(@Name)+N';';
            EXEC sys.sp_executesql @Sql;
        END;
        FETCH NEXT FROM TypeCursor INTO @Name;
    END;
    CLOSE TypeCursor;DEALLOCATE TypeCursor;

    DECLARE @Definition nvarchar(max),@ModuleType char(2),@UpperDefinition nvarchar(max),
            @CreatePosition int,@KeywordPosition int,@KeywordLength int,@AlterHeader nvarchar(30);
    DECLARE ModuleCursor CURSOR LOCAL FAST_FORWARD FOR SELECT ObjectName,ModuleType,Definition FROM @Modules ORDER BY ModuleType,ObjectName;
    OPEN ModuleCursor;FETCH NEXT FROM ModuleCursor INTO @Name,@ModuleType,@Definition;
    WHILE @@FETCH_STATUS=0
    BEGIN
        SET @Definition=REPLACE(@Definition,N'[dbo].',N'[access].');
        SET @Definition=REPLACE(@Definition,N'dbo.',N'[access].');
        SET @Definition=REPLACE(@Definition,N'[SqlAccessAdmin].',N'[access].');

        -- OBJECT_DEFINITION devuelve CREATE incluso si el script original usó
        -- CREATE OR ALTER. Se analiza la cabecera en vez de reemplazar una frase
        -- literal, porque SQL Server puede conservar tabulaciones, saltos de línea
        -- o varios espacios entre CREATE, OR ALTER y PROCEDURE/TRIGGER.
        SET @UpperDefinition=UPPER(@Definition);
        SET @CreatePosition=CHARINDEX(N'CREATE',@UpperDefinition);
        SET @KeywordPosition=CASE WHEN @ModuleType='TR'
            THEN CHARINDEX(N'TRIGGER',@UpperDefinition)
            ELSE CHARINDEX(N'PROC',@UpperDefinition) END;
        SET @KeywordLength=CASE WHEN @ModuleType='TR' THEN 7
            WHEN SUBSTRING(@UpperDefinition,@KeywordPosition,9)=N'PROCEDURE' THEN 9
            ELSE 4 END;
        SET @AlterHeader=CASE WHEN @ModuleType='TR' THEN N'ALTER TRIGGER'
            WHEN @KeywordLength=9 THEN N'ALTER PROCEDURE'
            ELSE N'ALTER PROC' END;

        IF @CreatePosition=0 OR @KeywordPosition=0 OR @CreatePosition>@KeywordPosition
            THROW 51405,'No fue posible identificar la cabecera CREATE del módulo que se debe recompilar.',1;

        SET @Definition=STUFF(
            @Definition,
            @CreatePosition,
            @KeywordPosition+@KeywordLength-@CreatePosition,
            @AlterHeader);

        EXEC sys.sp_executesql @Definition;
        FETCH NEXT FROM ModuleCursor INTO @Name,@ModuleType,@Definition;
    END;
    CLOSE ModuleCursor;DEALLOCATE ModuleCursor;

    IF EXISTS
    (
        SELECT 1
        FROM @Modules m
        CROSS APPLY(VALUES(OBJECT_DEFINITION(CASE WHEN m.ModuleType='TR'
            THEN OBJECT_ID(N'access.'+m.ObjectName,N'TR')
            ELSE OBJECT_ID(N'access.'+m.ObjectName,N'P') END))) d(Definition)
        WHERE d.Definition IS NULL
           OR CHARINDEX(N'[dbo].',d.Definition)>0
           OR CHARINDEX(N'dbo.',d.Definition)>0
           OR CHARINDEX(N'[SqlAccessAdmin].',d.Definition)>0
    )
        THROW 51404,'Uno o más módulos no pudieron recompilarse completamente bajo el esquema access.',1;

    DECLARE @SecurableType varchar(10),@ColumnName sysname,@PrincipalName sysname,@PermissionName sysname,@PermissionState char(1);
    DECLARE PermissionCursor CURSOR LOCAL FAST_FORWARD FOR
        SELECT SecurableType,ObjectName,ColumnName,PrincipalName,PermissionName,PermissionState FROM @Permissions;
    OPEN PermissionCursor;
    FETCH NEXT FROM PermissionCursor INTO @SecurableType,@Name,@ColumnName,@PrincipalName,@PermissionName,@PermissionState;
    WHILE @@FETCH_STATUS=0
    BEGIN
        SET @Sql=CASE @PermissionState WHEN 'D' THEN N'DENY ' ELSE N'GRANT ' END+@PermissionName+N' ON '
            +CASE WHEN @SecurableType='TYPE' THEN N'TYPE::' ELSE N'OBJECT::' END
            +N'[access].'+QUOTENAME(@Name)
            +CASE WHEN @ColumnName IS NULL THEN N'' ELSE N' ('+QUOTENAME(@ColumnName)+N')' END
            +N' TO '+QUOTENAME(@PrincipalName)
            +CASE WHEN @PermissionState='W' THEN N' WITH GRANT OPTION' ELSE N'' END+N';';
        EXEC sys.sp_executesql @Sql;
        FETCH NEXT FROM PermissionCursor INTO @SecurableType,@Name,@ColumnName,@PrincipalName,@PermissionName,@PermissionState;
    END;
    CLOSE PermissionCursor;DEALLOCATE PermissionCursor;

    IF SCHEMA_ID(N'SqlAccessAdmin') IS NOT NULL
       AND NOT EXISTS(SELECT 1 FROM sys.objects WHERE schema_id=SCHEMA_ID(N'SqlAccessAdmin'))
       AND NOT EXISTS(SELECT 1 FROM sys.types WHERE schema_id=SCHEMA_ID(N'SqlAccessAdmin') AND is_user_defined=1)
       AND NOT EXISTS(SELECT 1 FROM sys.xml_schema_collections WHERE schema_id=SCHEMA_ID(N'SqlAccessAdmin'))
        EXEC(N'DROP SCHEMA [SqlAccessAdmin];');

    COMMIT;
END TRY
BEGIN CATCH
    IF XACT_STATE()<>0 ROLLBACK;
    THROW;
END CATCH;

IF OBJECT_ID(N'[access].usp_Audit_Write',N'P') IS NOT NULL
    EXEC [access].usp_Audit_Write
        N'Infraestructura',N'Migrar esquema',NULL,NULL,1,
        N'Objetos propios de la aplicación migrados desde dbo o SqlAccessAdmin hacia access.';

SELECT s.name AS [Esquema],o.type_desc AS [Tipo],o.name AS [Objeto]
FROM sys.objects o
JOIN sys.schemas s ON s.schema_id=o.schema_id
WHERE s.name=N'access'
ORDER BY o.type_desc,o.name;

SELECT s.name AS [Esquema],N'TABLE_TYPE' AS [Tipo],t.name AS [Objeto]
FROM sys.table_types t
JOIN sys.schemas s ON s.schema_id=t.schema_id
WHERE s.name=N'access'
ORDER BY t.name;

PRINT N'Migración al esquema access completada.';
GO
