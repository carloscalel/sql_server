-- Script para crear tabla de bitácora y patrones
CREATE TABLE masked.Bitacora (...);
CREATE TABLE masked.Patrones (...);