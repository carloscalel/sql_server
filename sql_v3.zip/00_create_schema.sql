-- Script para crear esquemas masked y app
CREATE SCHEMA masked;
CREATE SCHEMA app;