using System.Collections.ObjectModel;
using System.Data;
using System.Windows;
using SqlAccessAdmin.Data;
using SqlAccessAdmin.Infrastructure;
using SqlAccessAdmin.Models;
using SqlAccessAdmin.Views;

namespace SqlAccessAdmin.ViewModels;

public sealed class MainViewModel : BindableBase
{
    private readonly AdminDbGateway _db;
    private readonly DirectSqlServerService _direct;
    private object? _current;
    private string _title="Resumen";
    public SessionContext Session {get;}
    public object? Current {get=>_current;private set=>Set(ref _current,value);}
    public string Title {get=>_title;private set=>Set(ref _title,value);}
    public RelayCommand DashboardCommand {get;}
    public RelayCommand ServersCommand {get;}
    public RelayCommand AccessCommand {get;}
    public RelayCommand UsersCommand {get;}
    public RelayCommand AuditCommand {get;}
    public RelayCommand PolicyCommand {get;}
    public bool CanAdmin=>Session.Role==AppRole.Administrator;
    public bool CanOperate=>Session.Role!=AppRole.Auditor;

    public MainViewModel(AdminDbGateway db,SessionContext session)
    {
        _db=db;_direct=new(db);Session=session;
        DashboardCommand=new(()=>Navigate("Resumen",new DashboardViewModel(db,session)));
        ServersCommand=new(()=>Navigate("Servidores",new ServersViewModel(db,_direct)),()=>CanAdmin);
        AccessCommand=new(()=>Navigate("Administrar accesos",new AccessViewModel(db,_direct)),()=>CanOperate);
        UsersCommand=new(()=>Navigate("Usuarios autorizados",new UsersViewModel(db)),()=>CanAdmin);
        AuditCommand=new(()=>Navigate("Auditoría",new AuditViewModel(db)));
        PolicyCommand=new(()=>Navigate("Política central",new PolicyViewModel(db)),()=>CanAdmin);
        DashboardCommand.Execute(null);
    }
    private void Navigate(string title,object vm){Title=title;Current=vm;}
}

public sealed class DashboardViewModel : BindableBase
{
    private int _servers,_users;
    public int Servers {get=>_servers;private set=>Set(ref _servers,value);}
    public int Users {get=>_users;private set=>Set(ref _users,value);}
    public SessionContext Session {get;}
    public AsyncCommand RefreshCommand {get;}
    public DashboardViewModel(AdminDbGateway db,SessionContext session){Session=session;RefreshCommand=new(async()=>{Servers=(await db.GetServersAsync()).Count;Users=(await db.GetUsersAsync()).Count;});RefreshCommand.Execute(null);}
}

public sealed class ServersViewModel : BindableBase
{
    private readonly AdminDbGateway _db;
    private readonly DirectSqlServerService _direct;
    private string _filter="",_status="";
    private ServerItem? _selected;
    public ObservableCollection<ServerItem> Servers {get;}=[];
    public string Filter {get=>_filter;set{if(Set(ref _filter,value))Raise(nameof(Filtered));}}
    public string Status {get=>_status;set=>Set(ref _status,value);}
    public ServerItem? Selected
    {
        get=>_selected;
        set
        {
            if(!Set(ref _selected,value))return;
            EditCommand.Refresh();TestCommand.Refresh();RemoveCommand.Refresh();
        }
    }
    public IEnumerable<ServerItem> Filtered=>Servers.Where(x=>string.IsNullOrWhiteSpace(Filter)||x.Name.Contains(Filter,StringComparison.OrdinalIgnoreCase)||x.Host.Contains(Filter,StringComparison.OrdinalIgnoreCase)||x.Instance.Contains(Filter,StringComparison.OrdinalIgnoreCase)||x.SqlUser.Contains(Filter,StringComparison.OrdinalIgnoreCase));
    public AsyncCommand RefreshCommand {get;}
    public RelayCommand AddCommand {get;}
    public RelayCommand EditCommand {get;}
    public AsyncCommand TestCommand {get;}
    public AsyncCommand RemoveCommand {get;}

    public ServersViewModel(AdminDbGateway db,DirectSqlServerService direct)
    {
        _db=db;_direct=direct;
        RefreshCommand=new(LoadAsync);
        AddCommand=new(()=>OpenEditor(null));
        EditCommand=new(()=>OpenEditor(Selected),()=>Selected is not null);
        TestCommand=new(TestAsync,()=>Selected is not null);
        RemoveCommand=new(RemoveAsync,()=>Selected is not null);
        RefreshCommand.Execute(null);
    }
    private async Task LoadAsync()
    {
        try{var items=await _db.GetServersAsync();Servers.Clear();foreach(var x in items)Servers.Add(x);Raise(nameof(Filtered));Status=$"{Servers.Count} servidor(es) registrado(s).";}
        catch(Exception ex){Status=$"No fue posible actualizar el listado: {ex.Message}";}
    }
    private void OpenEditor(ServerItem? item){var window=new ServerEditorWindow(_db,_direct,item){Owner=Application.Current.Windows.OfType<MainWindow>().FirstOrDefault()};if(window.ShowDialog()==true)RefreshCommand.Execute(null);}
    private async Task TestAsync(){try{Status="Probando conexión directa…";await _direct.TestAsync(Selected!.Id);Status=$"Conexión correcta con {Selected.Name}.";}catch(Exception ex){Status=$"Error de conexión: {ex.Message}";}}
    private async Task RemoveAsync(){if(MessageBox.Show($"¿Deshabilitar el servidor {Selected!.Name}?","Confirmar",MessageBoxButton.YesNo,MessageBoxImage.Question)!=MessageBoxResult.Yes)return;await _db.SetServerActiveAsync(Selected.Id,false);await LoadAsync();}
    public async Task ChangeActiveAsync(ServerItem server)
    {
        var requested=server.Active;
        try{Status=$"{(requested?"Habilitando":"Deshabilitando")} {server.Name}…";await _db.SetServerActiveAsync(server.Id,requested);Status=$"Servidor {server.Name} {(requested?"habilitado":"deshabilitado")}.";}
        catch(Exception ex){server.Active=!requested;Status=$"No fue posible cambiar el estado: {ex.Message}";}
    }
}

public sealed class UsersViewModel : BindableBase
{
    private readonly AdminDbGateway _db;public ObservableCollection<AuthorizedUser> Users {get;}=[];public AsyncCommand RefreshCommand {get;}
    public UsersViewModel(AdminDbGateway db){_db=db;RefreshCommand=new(LoadAsync);RefreshCommand.Execute(null);}
    private async Task LoadAsync(){Users.Clear();foreach(var x in await _db.GetUsersAsync())Users.Add(x);}
}

public sealed class AuditViewModel : BindableBase
{
    private readonly AdminDbGateway _db;private string _filter="",_integrityStatus="Integridad no validada.";public ObservableCollection<AuditEvent> Events {get;}=[];public string Filter {get=>_filter;set=>Set(ref _filter,value);}public string IntegrityStatus{get=>_integrityStatus;set=>Set(ref _integrityStatus,value);}public AsyncCommand RefreshCommand {get;}public AsyncCommand ValidateIntegrityCommand{get;}
    public AuditViewModel(AdminDbGateway db){_db=db;RefreshCommand=new(LoadAsync);ValidateIntegrityCommand=new(ValidateAsync);RefreshCommand.Execute(null);}
    private async Task LoadAsync(){Events.Clear();foreach(var x in await _db.GetAuditAsync(Filter))Events.Add(x);}
    private async Task ValidateAsync(){try{var x=await _db.ValidateAuditIntegrityAsync();IntegrityStatus=x.IsValid?$"Cadena íntegra: {x.HashedEvents} eventos verificados.":$"ALERTA: {x.BrokenLinks} enlaces rotos y {x.AlteredEvents} eventos alterados.";}catch(Exception ex){IntegrityStatus=ex.Message;}}
}

public sealed class AccessViewModel : BindableBase
{
    private static readonly HashSet<string> SupportedRequestOperations=new(StringComparer.OrdinalIgnoreCase)
    {
        "CREATE_SQL_LOGIN","CREATE_WINDOWS_LOGIN","MODIFY_LOGIN","ENABLE_LOGIN","DISABLE_LOGIN",
        "CREATE_DB_USER","PERMISSION_CHANGE","ADD_ROLE_MEMBER","REMOVE_ROLE_MEMBER"
    };
    private static readonly HashSet<string> ManagedDataPermissions=new(StringComparer.OrdinalIgnoreCase)
    {"SELECT","INSERT","UPDATE","DELETE","EXECUTE"};
    private readonly AdminDbGateway _db;
    private readonly DirectSqlServerService _direct;
    private string _status="Seleccione servidores y cargue sus bases.",_targetPrincipal="",_sourcePrincipal="",_authenticationType="WINDOWS",_permissionAction="GRANT",_scope="OBJECT",_securable="",_justification="",_approvalComment="",_executionPassword="";
    private ServerItem? _inventoryServer;
    private ServerItem? _selectedWorkingServer;
    private string? _inventoryDatabase,_inventoryType="LOGINS";
    private DataView? _inventory;
    private PolicyOperation? _operation;
    private PolicyPermission? _permission;
    private PolicyRole? _role;
    private DatabaseItem? _selectedMappingDatabase;
    private DatabaseObjectItem? _selectedDatabaseObject;
    private PolicyDecision? _decision;
    private AccessRequestItem? _selectedRequest;
    private SecurityTreeNode? _selectedSecurityNode;
    private bool _isManagingAccess;
    private bool _requestSubmitted;
    private bool _includeInitialAccess;
    private string _securitySelectionTitle="Seleccione un login o usuario";
    private string _securitySelectionSubtitle="Expanda un servidor para consultar su seguridad.";
    private string _securitySelectionType="SIN SELECCIÓN";
    private string _securitySummary="Los permisos y las membresías aparecerán en este panel.";
    private string _securityFilter="";
    private string _securityFilterHint="Sin filtro · la consulta es de solo lectura.";
    private string _roleChoicesHint="Seleccione una base de datos para consultar sus roles permitidos.";
    public ObservableCollection<ServerItem> Servers {get;}=[];
    public ObservableCollection<DatabaseItem> Databases {get;}=[];
    public ObservableCollection<string> InventoryDatabases {get;}=[];
    public ObservableCollection<PolicyOperation> Operations {get;}=[];
    public ObservableCollection<PolicyPermission> Permissions {get;}=[];
    public ObservableCollection<PolicyPermission> AvailablePermissions {get;}=[];
    public ObservableCollection<DatabaseObjectItem> DatabaseObjects {get;}=[];
    public ObservableCollection<DatabaseObjectItem> SelectedDatabaseObjects {get;}=[];
    public ObservableCollection<PolicyRole> Roles {get;}=[];
    public ObservableCollection<RoleSelectionItem> RoleChoices {get;}=[];
    public ObservableCollection<RoleSelectionItem> InitialAccessRoleChoices {get;}=[];
    public ObservableCollection<PermissionSelectionItem> PermissionChoices {get;}=[];
    public ObservableCollection<PermissionSelectionItem> InitialAccessPermissionChoices {get;}=[];
    public ObservableCollection<AccessRequestItem> Requests {get;}=[];
    public ObservableCollection<AccessRequestItem> HistoryRequests {get;}=[];
    public ObservableCollection<OperationResult> Results {get;}=[];
    public ObservableCollection<SecurityTreeNode> SecurityRoots {get;}=[];
    public ObservableCollection<SecurityPermissionItem> SecurityPermissions {get;}=[];
    public ObservableCollection<SecurityMembershipItem> SecurityMemberships {get;}=[];
    public string[] InventoryTypes {get;}=["LOGINS","USERS","PERMISSIONS"];
    public string[] AuthenticationTypes {get;}=["WINDOWS","SQL"];
    public string[] PermissionActions {get;}=["GRANT","REVOKE"];
    public string[] Scopes {get;}=["DATABASE","OBJECT"];
    public string Status {get=>_status;set=>Set(ref _status,value);}
    public ServerItem? SelectedWorkingServer
    {
        get=>_selectedWorkingServer;
        set{if(Set(ref _selectedWorkingServer,value))OnWorkingServerChanged();}
    }
    public bool HasWorkingServer=>SelectedWorkingServer is not null;
    public string WorkingServerSummary=>SelectedWorkingServer is null
        ? "Ningún servidor seleccionado"
        : $"{SelectedWorkingServer.Name} · {SelectedWorkingServer.Host}{(string.IsNullOrWhiteSpace(SelectedWorkingServer.Instance)?"":$"\\{SelectedWorkingServer.Instance}")}";
    public ServerItem? InventoryServer {get=>_inventoryServer;set{if(Set(ref _inventoryServer,value))_=LoadInventoryDatabasesAsync();}}
    public string? InventoryDatabase {get=>_inventoryDatabase;set=>Set(ref _inventoryDatabase,value);}
    public string? InventoryType {get=>_inventoryType;set=>Set(ref _inventoryType,value);}
    public DataView? Inventory {get=>_inventory;set=>Set(ref _inventory,value);}
    public PolicyOperation? SelectedOperation {get=>_operation;set{if(Set(ref _operation,value))OnOperationChanged();}}
    public PolicyPermission? SelectedPermission {get=>_permission;set{if(Set(ref _permission,value))Decision=null;}}
    public PolicyRole? SelectedRole {get=>_role;set{if(Set(ref _role,value))Decision=null;}}
    public DatabaseItem? SelectedMappingDatabase
    {
        get=>_selectedMappingDatabase;
        set
        {
            if(!Set(ref _selectedMappingDatabase,value))return;
            foreach(var database in Databases)database.IsSelected=ReferenceEquals(database,value);
            RoleChoices.Clear();
            Decision=null;
            Raise(nameof(HasSelectedMappingDatabase));
            _=LoadRoleChoicesForDatabaseAsync(value);
        }
    }
    public bool HasSelectedMappingDatabase=>SelectedMappingDatabase is not null;
    public string RoleChoicesHint {get=>_roleChoicesHint;private set=>Set(ref _roleChoicesHint,value);}
    public DatabaseObjectItem? SelectedDatabaseObject {get=>_selectedDatabaseObject;set{if(Set(ref _selectedDatabaseObject,value)){Securable=value?.QualifiedName??"";RefreshAvailablePermissions();}}}
    public string SelectedObjectsSummary=>SelectedDatabaseObjects.Count==0
        ? "Ningún objeto seleccionado"
        : SelectedDatabaseObjects.Count==1?SelectedDatabaseObjects[0].DisplayName:$"{SelectedDatabaseObjects.Count} objetos seleccionados";
    public bool IsObjectScope=>IsPermissionMatrixOperation&&Scope.Equals("OBJECT",StringComparison.OrdinalIgnoreCase);
    public string PermissionStepTitle=>IsObjectScope?"2. Marque los permisos que recibirán los objetos":"1. Marque los permisos que recibirá la base de datos";
    public string PlannedChangesSummary
    {
        get
        {
            var permissionCount=PermissionChoices.Count(x=>x.IsSelected);
            if(IsObjectScope)
                return SelectedDatabaseObjects.Count==0
                    ? "Primero seleccione uno o varios objetos."
                    : permissionCount==0
                        ? $"{SelectedDatabaseObjects.Count} objeto(s) seleccionado(s). Ahora marque al menos un permiso."
                        : $"{SelectedDatabaseObjects.Count} objeto(s) × {permissionCount} permiso(s) = {SelectedDatabaseObjects.Count*permissionCount} solicitud(es) auditable(s).";
            return permissionCount==0?"Marque al menos un permiso.":$"{permissionCount} permiso(s) se solicitará(n) para la base de datos.";
        }
    }
    public string TargetPrincipal {get=>_targetPrincipal;set{if(Set(ref _targetPrincipal,value))Decision=null;}}
    public string SourcePrincipal {get=>_sourcePrincipal;set{if(Set(ref _sourcePrincipal,value))Decision=null;}}
    public string AuthenticationType {get=>_authenticationType;set{if(Set(ref _authenticationType,value))Decision=null;}}
    public string PermissionAction {get=>_permissionAction;set{if(Set(ref _permissionAction,value)){RefreshAvailablePermissions();Decision=null;}}}
    public string Scope {get=>_scope;set{if(Set(ref _scope,value)){if(!value.Equals("OBJECT",StringComparison.OrdinalIgnoreCase)){SelectedDatabaseObject=null;SelectedDatabaseObjects.Clear();DatabaseObjects.Clear();Raise(nameof(SelectedObjectsSummary));}RefreshAvailablePermissions();Raise(nameof(IsObjectScope));Raise(nameof(PermissionStepTitle));Raise(nameof(PlannedChangesSummary));Raise(nameof(RequiresSecurable));Raise(nameof(SecurableLabel));Raise(nameof(SecurableHelp));Raise(nameof(OperationBadge));Decision=null;}}}
    public string Securable {get=>_securable;set{if(Set(ref _securable,value))Decision=null;}}
    public string Justification {get=>_justification;set{if(Set(ref _justification,value))Decision=null;}}
    public PolicyDecision? Decision {get=>_decision;set=>Set(ref _decision,value);}
    public AccessRequestItem? SelectedRequest {get=>_selectedRequest;set=>Set(ref _selectedRequest,value);}
    public string ApprovalComment {get=>_approvalComment;set=>Set(ref _approvalComment,value);}
    public string ExecutionPassword {get=>_executionPassword;set=>Set(ref _executionPassword,value);}
    public SecurityTreeNode? SelectedSecurityNode {get=>_selectedSecurityNode;private set=>Set(ref _selectedSecurityNode,value);}
    public bool IsManagingAccess {get=>_isManagingAccess;private set{if(Set(ref _isManagingAccess,value))Raise(nameof(IsBrowsingAccess));}}
    public bool IsBrowsingAccess=>!IsManagingAccess;
    public string SecuritySelectionTitle {get=>_securitySelectionTitle;private set=>Set(ref _securitySelectionTitle,value);}
    public string SecuritySelectionSubtitle {get=>_securitySelectionSubtitle;private set=>Set(ref _securitySelectionSubtitle,value);}
    public string SecuritySelectionType {get=>_securitySelectionType;private set=>Set(ref _securitySelectionType,value);}
    public string SecuritySummary {get=>_securitySummary;private set=>Set(ref _securitySummary,value);}
    public string SecurityFilter {get=>_securityFilter;set{if(Set(ref _securityFilter,value))ApplySecurityFilter();}}
    public string SecurityFilterHint {get=>_securityFilterHint;private set=>Set(ref _securityFilterHint,value);}
    public bool IsLoginMappingOperation=>SelectedOperation?.Code=="MODIFY_LOGIN";
    public bool IsPermissionMatrixOperation=>SelectedOperation?.Code=="PERMISSION_CHANGE";
    public bool IsCreateLoginOperation=>SelectedOperation?.Code is "CREATE_SQL_LOGIN" or "CREATE_WINDOWS_LOGIN";
    public bool IncludeInitialAccess
    {
        get=>_includeInitialAccess;
        set
        {
            if(!Set(ref _includeInitialAccess,value))return;
            foreach(var database in Databases)database.IsSelected=false;
            foreach(var permission in InitialAccessPermissionChoices)permission.IsSelected=false;
            foreach(var role in InitialAccessRoleChoices)role.IsSelected=false;
            Decision=null;
            if(value)_=LoadDatabasesAsync();
        }
    }
    public bool RequiresBasicAccessData=>!IsLoginMappingOperation&&!IsPermissionMatrixOperation;
    public bool NeedsPolicyConfiguration=>SelectedOperation is not null&&!SelectedOperation.Enabled;
    public string PolicyConfigurationWarning=>NeedsPolicyConfiguration
        ? $"La pantalla está disponible para consulta, pero {SelectedOperation!.Code} no está habilitada en adminDB. El DBA debe ejecutar 14_RedisenarMapeoLogin.sql antes de enviar solicitudes."
        : "";
    public bool IsServerOperation=>SelectedOperation?.Code is "CREATE_SQL_LOGIN" or "CREATE_WINDOWS_LOGIN" or "ENABLE_LOGIN" or "DISABLE_LOGIN";
    public bool IsDatabaseOperation=>SelectedOperation is not null&&!IsServerOperation;
    public bool IsStandardDatabaseOperation=>IsDatabaseOperation&&!IsLoginMappingOperation&&!IsPermissionMatrixOperation;
    public bool RequiresSourcePrincipal=>false;
    public bool RequiresRole=>SelectedOperation?.Code is "MODIFY_LOGIN" or "ADD_ROLE_MEMBER" or "REMOVE_ROLE_MEMBER";
    public bool RequiresRoleInDetails=>RequiresRole&&!IsLoginMappingOperation;
    public bool RequiresPermission=>SelectedOperation?.Code=="PERMISSION_CHANGE";
    public bool RequiresSecurable=>RequiresPermission&&!Scope.Equals("DATABASE",StringComparison.OrdinalIgnoreCase);
    public bool RequiresAuthenticationType=>false;
    public bool RequiresDefaultDatabase=>false;
    public string OperationBadge=>$"{(IsServerOperation?"INSTANCIA":RequiresPermission&&Scope=="OBJECT"?"OBJETO":"BASE DE DATOS")} · RIESGO {SelectedOperation?.Risk??"-"}";
    public string TargetPrincipalLabel=>SelectedOperation?.Code switch
    {
        "CREATE_SQL_LOGIN"=>"Nombre del nuevo login SQL",
        "CREATE_WINDOWS_LOGIN"=>"Cuenta Windows (DOMINIO\\usuario o EQUIPO\\usuario)",
        "MODIFY_LOGIN"=>"Login que se modificará",
        "CREATE_DB_USER"=>"Login existente que se convertirá en usuario",
        "ENABLE_LOGIN" or "DISABLE_LOGIN"=>"Login que se modificará",
        "PERMISSION_CHANGE"=>"Usuario destino (los roles no están permitidos)",
        _=>"Usuario o principal destino"
    };
    public string TargetPrincipalHelp=>SelectedOperation?.Code switch
    {
        "CREATE_SQL_LOGIN"=>"La contraseña se proporciona únicamente al ejecutar la solicitud confirmada.",
        "CREATE_WINDOWS_LOGIN"=>"SQL Server validará la identidad Windows al ejecutar la solicitud confirmada.",
        "MODIFY_LOGIN"=>"Seleccione una base de datos y uno de los roles aprobados para mapear el login como usuario.",
        "CREATE_DB_USER"=>"El login debe existir previamente en cada servidor seleccionado.",
        "ENABLE_LOGIN"=>"No se cambiarán roles ni permisos del login.",
        "DISABLE_LOGIN"=>"El login no se elimina y sus permisos se conservan.",
        "PERMISSION_CHANGE"=>"Solo puede ser un usuario de base de datos; nunca un rol fijo o personalizado.",
        _=>"Principal que recibirá la operación solicitada."
    };
    public string OperationGuidance=>SelectedOperation?.Code switch
    {
        "CREATE_SQL_LOGIN"=>"Indique el login nuevo. Opcionalmente seleccione bases y permisos iniciales para crear también sus usuarios de base.",
        "CREATE_WINDOWS_LOGIN"=>"Crea un login para una identidad Windows existente y permite preparar sus usuarios y permisos iniciales.",
        "MODIFY_LOGIN"=>"Muestra todas las bases del servidor. Al seleccionar una se habilitan únicamente los roles aprobados por la política central.",
        "CREATE_DB_USER"=>"Seleccione las bases donde se creará el usuario asociado al login existente.",
        "ADD_ROLE_MEMBER"=>"Seleccione el usuario, el rol aprobado y las bases donde se agregará la membresía.",
        "REMOVE_ROLE_MEMBER"=>"Seleccione el usuario, el rol y las bases de las que se retirará la membresía.",
        "PERMISSION_CHANGE"=>"Defina acción, permiso, ámbito y elemento protegible. La política rechazará combinaciones no aprobadas.",
        "ENABLE_LOGIN"=>"Seleccione los servidores donde se habilitará el login.",
        "DISABLE_LOGIN"=>"Seleccione los servidores donde se deshabilitará el login.",
        _=>"Seleccione una operación para ver los datos necesarios."
    };
    public string DestinationInstruction=>IsLoginMappingOperation
        ? "Seleccione una base de datos. Después podrá elegir el rol permitido que se asignará al usuario mapeado."
        : IsPermissionMatrixOperation
            ? "Marque los permisos GRANT permitidos para la base seleccionada o cambie el nivel a un objeto puntual."
        : IsServerOperation
            ? "Operación de instancia: se ejecutará únicamente en el servidor de trabajo seleccionado."
            : "Operación de base de datos: cargue las bases del servidor de trabajo y marque una o varias bases de ese mismo servidor.";
    public string SecurableLabel=>Scope switch
    {
        "SCHEMA"=>"Esquema",
        "OBJECT"=>"Objeto",
        "COLUMN"=>"Columna",
        _=>"Base de datos completa"
    };
    public string SecurableHelp=>Scope switch
    {
        "SCHEMA"=>"Ejemplo: ventas",
        "OBJECT"=>"Ejemplo: ventas.Factura",
        "COLUMN"=>"Ejemplo: ventas.Factura.Total",
        _=>"No se requiere nombre de objeto para el ámbito DATABASE."
    };
    public AsyncCommand LoadDatabasesCommand {get;}
    public AsyncCommand LoadDatabaseObjectsCommand {get;}
    public AsyncCommand LoadInventoryCommand {get;}
    public AsyncCommand PreviewCommand {get;}
    public AsyncCommand SubmitCommand {get;}
    public AsyncCommand RefreshRequestsCommand {get;}
    public AsyncCommand ApproveCommand {get;}
    public AsyncCommand RejectCommand {get;}
    public AsyncCommand ExecuteApprovedCommand {get;}
    public RelayCommand ClearSecurityFilterCommand {get;}
    public RelayCommand BeginAccessManagementCommand {get;}
    public RelayCommand CancelAccessManagementCommand {get;}

    public AccessViewModel(AdminDbGateway db,DirectSqlServerService direct)
    {
        _db=db;_direct=direct;LoadDatabasesCommand=new(LoadDatabasesAsync);LoadDatabaseObjectsCommand=new(LoadDatabaseObjectsAsync);LoadInventoryCommand=new(LoadInventoryAsync);PreviewCommand=new(PreviewAsync);SubmitCommand=new(SubmitAsync,()=>!_requestSubmitted);RefreshRequestsCommand=new(LoadRequestsAsync);ApproveCommand=new(()=>ApproveAsync(true));RejectCommand=new(()=>ApproveAsync(false));ExecuteApprovedCommand=new(ExecuteApprovedAsync);ClearSecurityFilterCommand=new(()=>SecurityFilter="");BeginAccessManagementCommand=new(()=>BeginAccessManagement());CancelAccessManagementCommand=new(()=>IsManagingAccess=false);_=InitializeAsync();
    }
    private async Task InitializeAsync()
    {
        try
        {
            foreach(var x in await _db.GetServersAsync())if(x.Active)Servers.Add(x);
            BuildSecurityTree();
            foreach(var source in await _db.GetPolicyOperationsAsync())
            {
                if(!source.Enabled||!SupportedRequestOperations.Contains(source.Code))continue;
                var operation=source.Code switch
                {
                    "MODIFY_LOGIN"=>source with{Name="Mapear login a base y roles",Description="Seleccione una base y los roles aprobados que recibirá el usuario mapeado."},
                    "PERMISSION_CHANGE"=>source with{Name="Conceder permisos de datos",Description="Seleccione mediante casillas los permisos GRANT permitidos para una base u objeto."},
                    _=>source
                };
                Operations.Add(operation);
            }
            foreach(var x in await _db.GetPolicyPermissionsAsync())if(x.Enabled)Permissions.Add(x);
            RefreshInitialAccessPermissions();
            foreach(var x in await _db.GetPolicyRolesAsync())if(x.Enabled)Roles.Add(x);
            RefreshInitialAccessRoles();
            RefreshRoleChoices();
            SelectedOperation=Operations.FirstOrDefault();
            SelectedRole=Roles.FirstOrDefault();
            RefreshAvailablePermissions();
            await LoadRequestsAsync();
        }
        catch(Exception ex){Status=$"Debe ejecutar 10_PoliticaSolicitudesEIntegridad.sql: {ex.Message}";}
    }

    private void OnWorkingServerChanged()
    {
        foreach(var server in Servers)server.IsSelected=ReferenceEquals(server,SelectedWorkingServer);
        Databases.Clear();DatabaseObjects.Clear();SelectedDatabaseObjects.Clear();SelectedDatabaseObject=null;Raise(nameof(SelectedObjectsSummary));
        InventoryDatabases.Clear();InventoryDatabase=null;_inventoryServer=SelectedWorkingServer;Raise(nameof(InventoryServer));
        SecurityFilter="";
        BuildSecurityTree();
        Requests.Clear();HistoryRequests.Clear();SelectedRequest=null;Results.Clear();
        Raise(nameof(HasWorkingServer));Raise(nameof(WorkingServerSummary));
        Status=SelectedWorkingServer is null
            ? "Paso previo: seleccione un servidor de trabajo."
            : $"Servidor de trabajo fijado: {WorkingServerSummary}. Todas las acciones se limitarán a este servidor.";
        if(SelectedWorkingServer is not null)_=LoadRequestsAsync();
    }

    public Task RefreshSecurityTreeAsync()
    {
        BuildSecurityTree();
        Status=$"Explorador actualizado: {SecurityRoots.Count} servidor(es) disponible(s).";
        return Task.CompletedTask;
    }

    public async Task BeginAccessManagementAsync(string? operationCode=null,SecurityTreeNode? node=null)
    {
        _requestSubmitted=false;
        SubmitCommand.Refresh();
        node??=SelectedSecurityNode;
        var inferredCode=operationCode??(node?.Kind switch
        {
            SecurityNodeKind.Login=>"MODIFY_LOGIN",
            SecurityNodeKind.User=>"PERMISSION_CHANGE",
            _=>null
        });
        if(!string.IsNullOrWhiteSpace(inferredCode))
        {
            var operation=Operations.FirstOrDefault(x=>x.Code.Equals(inferredCode,StringComparison.OrdinalIgnoreCase));
            if(operation is null)
            {
                operation=inferredCode switch
                {
                    "MODIFY_LOGIN"=>new("MODIFY_LOGIN","Mapear login a base y roles",false,true,"HIGH","Configuración pendiente en la política central."),
                    _=>null
                };
                if(operation is null)
                {
                    IsManagingAccess=false;
                    Status=$"La operación {inferredCode} no está habilitada en la política central.";
                    return;
                }
            }
            SelectedOperation=operation;
        }
        TargetPrincipal=node?.IsPrincipal==true?node.Principal:"";
        if(IsLoginMappingOperation)
        {
            SelectedRole=null;
            RoleChoices.Clear();
            RoleChoicesHint="Seleccione una base de datos para consultar sus roles permitidos.";
        }
        if(IsPermissionMatrixOperation){Scope="DATABASE";PermissionAction="GRANT";RefreshAvailablePermissions();}

        IsManagingAccess=true;
        if(IsLoginMappingOperation)
        {
            await LoadDatabasesAsync();
        }
        else if(!IsServerOperation&&!string.IsNullOrWhiteSpace(node?.Database))
        {
            await LoadDatabasesAsync();
            foreach(var database in Databases)database.IsSelected=database.Name.Equals(node.Database,StringComparison.OrdinalIgnoreCase);
        }
        Status=node?.IsPrincipal==true
            ? $"Gestionando acceso de {node.Principal}. Revise los datos y genere una solicitud."
            : "Nueva solicitud de acceso. Complete los pasos visibles.";
    }

    public void BeginAccessManagement()=>_=BeginAccessManagementAsync();

    private void OnOperationChanged()
    {
        Decision=null;
        if(IsPermissionMatrixOperation)PermissionAction="GRANT";
        _includeInitialAccess=false;Raise(nameof(IncludeInitialAccess));
        SelectedDatabaseObject=null;
        SelectedDatabaseObjects.Clear();Raise(nameof(SelectedObjectsSummary));
        SelectedMappingDatabase=null;
        if(IsLoginMappingOperation)SelectedRole=null;
        DatabaseObjects.Clear();
        Securable="";
        AuthenticationType=SelectedOperation?.Code switch
        {
            "CREATE_SQL_LOGIN"=>"SQL",
            "CREATE_WINDOWS_LOGIN"=>"WINDOWS",
            _=>""
        };
        RefreshRoleChoices();
        Raise(nameof(IsLoginMappingOperation));Raise(nameof(IsPermissionMatrixOperation));Raise(nameof(IsCreateLoginOperation));Raise(nameof(RequiresBasicAccessData));Raise(nameof(IsServerOperation));Raise(nameof(IsDatabaseOperation));Raise(nameof(IsStandardDatabaseOperation));Raise(nameof(RequiresSourcePrincipal));
        Raise(nameof(IsObjectScope));Raise(nameof(PermissionStepTitle));Raise(nameof(PlannedChangesSummary));
        Raise(nameof(NeedsPolicyConfiguration));Raise(nameof(PolicyConfigurationWarning));
        Raise(nameof(RequiresRole));Raise(nameof(RequiresRoleInDetails));Raise(nameof(RequiresPermission));Raise(nameof(RequiresSecurable));
        Raise(nameof(RequiresAuthenticationType));Raise(nameof(RequiresDefaultDatabase));
        Raise(nameof(OperationBadge));
        Raise(nameof(TargetPrincipalLabel));Raise(nameof(TargetPrincipalHelp));Raise(nameof(OperationGuidance));
        Raise(nameof(DestinationInstruction));Raise(nameof(SecurableLabel));Raise(nameof(SecurableHelp));
        Status=SelectedOperation is null?"Seleccione una operación.":$"Operación seleccionada: {SelectedOperation.Name}. Complete únicamente los campos visibles.";
    }

    private void RefreshAvailablePermissions()
    {
        var previous=SelectedPermission?.Permission;
        AvailablePermissions.Clear();
        foreach(var permission in Permissions
                    .Where(x=>ManagedDataPermissions.Contains(x.Permission))
                    .Where(x=>x.Scope.Equals(Scope,StringComparison.OrdinalIgnoreCase))
                    .Where(x=>!Scope.Equals("OBJECT",StringComparison.OrdinalIgnoreCase)
                        ||SelectedDatabaseObjects.Count==0
                        ||SelectedDatabaseObjects.All(item=>SupportsPermission(item.Kind,x.Permission)))
                    .Where(x=>PermissionAction switch{"GRANT"=>x.AllowGrant,"DENY"=>x.AllowDeny,"REVOKE"=>x.AllowRevoke,_=>false})
                    .GroupBy(x=>x.Permission,StringComparer.OrdinalIgnoreCase)
                    .Select(x=>x.First())
                    .OrderBy(x=>x.Permission))
            AvailablePermissions.Add(permission);
        SelectedPermission=AvailablePermissions.FirstOrDefault(x=>x.Permission.Equals(previous,StringComparison.OrdinalIgnoreCase))
            ??AvailablePermissions.FirstOrDefault();
        PermissionChoices.Clear();
        foreach(var permission in AvailablePermissions)
        {
            var choice=new PermissionSelectionItem(permission);
            choice.PropertyChanged+=(_,args)=>
            {
                if(args.PropertyName!=nameof(PermissionSelectionItem.IsSelected))return;
                Decision=null;
                Raise(nameof(PlannedChangesSummary));
            };
            PermissionChoices.Add(choice);
        }
        Raise(nameof(PlannedChangesSummary));
    }

    private void RefreshInitialAccessPermissions()
    {
        InitialAccessPermissionChoices.Clear();
        foreach(var permission in Permissions
                    .Where(x=>x.Scope.Equals("DATABASE",StringComparison.OrdinalIgnoreCase)&&x.AllowGrant)
                    .Where(x=>ManagedDataPermissions.Contains(x.Permission))
                    .GroupBy(x=>x.Permission,StringComparer.OrdinalIgnoreCase)
                    .Select(x=>x.First())
                    .OrderBy(x=>x.Permission))
            InitialAccessPermissionChoices.Add(new(permission));
    }

    private void RefreshInitialAccessRoles()
    {
        InitialAccessRoleChoices.Clear();
        foreach(var role in Roles.OrderBy(x=>x.Name))InitialAccessRoleChoices.Add(new(role));
    }

    private static bool SupportsPermission(string kind,string permission)=>kind switch
    {
        "PROCEDURE"=>permission.Equals("EXECUTE",StringComparison.OrdinalIgnoreCase),
        "FUNCTION"=>permission is "SELECT" or "EXECUTE",
        "TABLE" or "VIEW"=>permission is "SELECT" or "INSERT" or "UPDATE" or "DELETE",
        _=>false
    };

    private void RefreshRoleChoices()
    {
        RoleChoices.Clear();
        if(!IsLoginMappingOperation)
            foreach(var role in Roles.OrderBy(x=>x.Name,StringComparer.CurrentCultureIgnoreCase))RoleChoices.Add(new(role));
    }

    private async Task LoadRoleChoicesForDatabaseAsync(DatabaseItem? database)
    {
        if(database is null)
        {
            RoleChoicesHint="Seleccione una base de datos para consultar sus roles permitidos.";
            return;
        }
        try
        {
            RoleChoicesHint=$"Consultando roles de {database.Name}…";
            var table=await _direct.GetSecurityInventoryAsync(database.ServerId,database.Name,"ROLES");
            if(!ReferenceEquals(SelectedMappingDatabase,database))return;
            var existing=table.Rows.Cast<DataRow>()
                .Select(row=>TableCell(row,"RoleName","Name"))
                .Where(name=>!string.IsNullOrWhiteSpace(name))
                .ToHashSet(StringComparer.OrdinalIgnoreCase);
            RoleChoices.Clear();
            foreach(var role in Roles.Where(x=>existing.Contains(x.Name)).OrderBy(x=>x.Name,StringComparer.CurrentCultureIgnoreCase))
                RoleChoices.Add(new(role));
            RoleChoicesHint=RoleChoices.Count==0
                ? $"{database.Name} no contiene roles aprobados por la política central."
                : $"{RoleChoices.Count} rol(es) existente(s) y permitido(s) en {database.Name}.";
            Status=RoleChoicesHint;
        }
        catch(Exception ex)
        {
            if(!ReferenceEquals(SelectedMappingDatabase,database))return;
            RoleChoices.Clear();
            RoleChoicesHint=$"No se pudieron consultar los roles de {database.Name}: {ex.Message}";
            Status=RoleChoicesHint;
        }
    }

    public async Task ExpandSecurityNodeAsync(SecurityTreeNode node)
    {
        if(!node.LoadOnExpand||node.IsLoaded)return;
        node.Children.Clear();
        try
        {
            Status=$"Cargando {node.Name.ToLowerInvariant()}…";
            switch(node.Kind)
            {
                case SecurityNodeKind.LoginGroup:
                    AddPrincipalNodes(node,await _direct.GetSecurityInventoryAsync(node.ServerId,"master","LOGINS"),SecurityNodeKind.Login,"LoginName","Name");
                    break;
                case SecurityNodeKind.DatabaseGroup:
                    var server=Servers.First(x=>x.Id==node.ServerId);
                    var selected=CopySelected(server);
                    foreach(var database in await _direct.GetDatabasesAsync([selected]))
                    {
                        var databaseNode=new SecurityTreeNode(database.Name,SecurityNodeKind.Database,node.ServerId,node.ServerName,database.Name);
                        databaseNode.Children.Add(new SecurityTreeNode("Usuarios",SecurityNodeKind.UserGroup,node.ServerId,node.ServerName,database.Name,loadOnExpand:true));
                        node.Children.Add(databaseNode);
                    }
                    break;
                case SecurityNodeKind.UserGroup:
                    AddPrincipalNodes(node,await _direct.GetSecurityInventoryAsync(node.ServerId,node.Database,"USERS"),SecurityNodeKind.User,"UserName","Name");
                    break;
            }
            if(node.Children.Count==0)
                node.Children.Add(new SecurityTreeNode("Sin elementos",SecurityNodeKind.Loading,node.ServerId,node.ServerName,node.Database));
            node.IsLoaded=true;
            ApplySecurityFilter();
            Status=$"{node.Name}: {node.Children.Count} elemento(s).";
        }
        catch(Exception ex)
        {
            node.Children.Add(new SecurityTreeNode($"No disponible: {ex.Message}",SecurityNodeKind.Error,node.ServerId,node.ServerName,node.Database));
            node.IsLoaded=true;
            Status=$"No se pudo cargar {node.Name}: {ex.Message}";
        }
    }

    public async Task SelectSecurityNodeAsync(SecurityTreeNode node)
    {
        SelectedSecurityNode=node;
        SecurityPermissions.Clear();
        SecurityMemberships.Clear();
        SecuritySelectionTitle=node.Name;
        SecuritySelectionSubtitle=string.IsNullOrWhiteSpace(node.Database)
            ? node.ServerName
            : $"{node.ServerName}  ·  {node.Database}";
        SecuritySelectionType=node.Kind switch
        {
            SecurityNodeKind.Login=>"LOGIN DE SERVIDOR",
            SecurityNodeKind.User=>"USUARIO DE BASE",
            SecurityNodeKind.Database=>"BASE DE DATOS",
            SecurityNodeKind.Server=>"SERVIDOR",
            _=>"CARPETA"
        };

        if(!node.IsPrincipal)
        {
            SecuritySummary="Expanda esta rama y seleccione un login o usuario para ver sus accesos.";
            return;
        }

        try
        {
            SecuritySummary="Consultando permisos y membresías…";
            Status=$"Consultando seguridad de {node.Principal}…";
            var details=await _direct.GetSecurityPrincipalDetailsAsync(node.ServerId,node.Database,node.Principal,node.Kind);
            if(!ReferenceEquals(SelectedSecurityNode,node))return;
            foreach(var item in details.Permissions)SecurityPermissions.Add(item);
            foreach(var item in details.Memberships.Distinct())SecurityMemberships.Add(item);
            SecuritySummary=$"{SecurityPermissions.Count} permiso(s) explícito(s) · {SecurityMemberships.Count} rol(es) asignado(s) o mapeo(s).";
            Status=$"Seguridad de {node.Principal} consultada correctamente.";
        }
        catch(Exception ex)
        {
            if(!ReferenceEquals(SelectedSecurityNode,node))return;
            SecuritySummary=$"No se pudo consultar el principal: {ex.Message}";
            Status=SecuritySummary;
        }
    }

    private void BuildSecurityTree()
    {
        SecurityRoots.Clear();
        foreach(var server in Servers.Where(x=>ReferenceEquals(x,SelectedWorkingServer)).OrderBy(x=>x.Name))
        {
            var root=new SecurityTreeNode(server.Name,SecurityNodeKind.Server,server.Id,server.Name);
            root.Children.Add(new SecurityTreeNode("Logins",SecurityNodeKind.LoginGroup,server.Id,server.Name,loadOnExpand:true));
            root.Children.Add(new SecurityTreeNode("Bases de datos",SecurityNodeKind.DatabaseGroup,server.Id,server.Name,loadOnExpand:true));
            SecurityRoots.Add(root);
        }
        SelectedSecurityNode=null;
        SecurityPermissions.Clear();SecurityMemberships.Clear();
        SecuritySelectionTitle="Seleccione un login o usuario";
        SecuritySelectionSubtitle="Expanda un servidor para consultar su seguridad.";
        SecuritySelectionType="SIN SELECCIÓN";
        SecuritySummary="Los permisos y las membresías aparecerán en este panel.";
        ApplySecurityFilter();
    }

    private void ApplySecurityFilter()
    {
        var filter=SecurityFilter.Trim();
        if(string.IsNullOrWhiteSpace(filter))
        {
            foreach(var root in SecurityRoots)SetTreeVisibility(root,true);
            SecurityFilterHint="Sin filtro · la consulta es de solo lectura.";
            return;
        }

        var matches=0;
        foreach(var root in SecurityRoots)FilterTreeNode(root,filter,ref matches);
        SecurityFilterHint=$"{matches} coincidencia(s) en ramas cargadas · expanda otras carpetas para incluirlas.";
    }

    private static bool FilterTreeNode(SecurityTreeNode node,string filter,ref int matches)
    {
        var ownMatch=node.Kind is not (SecurityNodeKind.Loading or SecurityNodeKind.Error)
            &&node.Name.Contains(filter,StringComparison.CurrentCultureIgnoreCase);
        if(ownMatch)matches++;

        var descendantVisible=false;
        foreach(var child in node.Children)
            descendantVisible|=FilterTreeNode(child,filter,ref matches);

        var pendingBranch=node.LoadOnExpand&&!node.IsLoaded;
        node.IsVisible=ownMatch||descendantVisible||pendingBranch;
        if(descendantVisible)node.IsExpanded=true;
        return node.IsVisible;
    }

    private static void SetTreeVisibility(SecurityTreeNode node,bool visible)
    {
        node.IsVisible=visible;
        foreach(var child in node.Children)SetTreeVisibility(child,visible);
    }

    private static ServerItem CopySelected(ServerItem server)=>new()
    {
        Id=server.Id,Name=server.Name,Host=server.Host,Instance=server.Instance,
        WindowsAuth=server.WindowsAuth,SqlUser=server.SqlUser,Encrypt=server.Encrypt,
        TrustCertificate=server.TrustCertificate,TimeoutSeconds=server.TimeoutSeconds,
        Active=server.Active,IsSelected=true
    };

    private static void AddPrincipalNodes(SecurityTreeNode parent,DataTable table,SecurityNodeKind kind,params string[] candidateColumns)
    {
        var names=table.Rows.Cast<DataRow>()
            .Select(row=>TableCell(row,candidateColumns))
            .Where(name=>!string.IsNullOrWhiteSpace(name))
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .OrderBy(name=>name,StringComparer.CurrentCultureIgnoreCase);
        foreach(var name in names)
            parent.Children.Add(new SecurityTreeNode(name,kind,parent.ServerId,parent.ServerName,parent.Database,name));
    }

    private static string TableCell(DataRow row,params string[] names)
    {
        var column=names.Select(name=>row.Table.Columns.Cast<DataColumn>().FirstOrDefault(x=>x.ColumnName.Equals(name,StringComparison.OrdinalIgnoreCase))).FirstOrDefault(x=>x is not null)
            ??row.Table.Columns.Cast<DataColumn>().FirstOrDefault();
        return column is null||row.IsNull(column)?"":Convert.ToString(row[column])?.Trim()??"";
    }
    private async Task LoadDatabasesAsync(){try{if(SelectedWorkingServer is null)throw new InvalidOperationException("Seleccione primero un servidor de trabajo.");Status=$"Cargando bases de {SelectedWorkingServer.Name}…";SelectedMappingDatabase=null;Databases.Clear();foreach(var x in await _direct.GetDatabasesAsync([SelectedWorkingServer]))Databases.Add(x);Status=$"{Databases.Count} bases disponibles en {SelectedWorkingServer.Name}.";}catch(Exception ex){Status=ex.Message;}}
    private async Task LoadDatabaseObjectsAsync()
    {
        await LoadDatabaseObjectsForSelectionAsync();
        SelectedDatabaseObject=DatabaseObjects.FirstOrDefault();
    }
    public async Task LoadDatabaseObjectsForSelectionAsync()
    {
        DatabaseObjects.Clear();
        try
        {
            var selected=Databases.Where(x=>x.IsSelected).ToList();
            if(selected.Count!=1)throw new InvalidOperationException("Para seleccionar un objeto puntual, marque exactamente una base de datos.");
            Status=$"Cargando tablas, vistas, funciones y procedimientos de {selected[0].Name}…";
            foreach(var item in await _direct.GetDatabaseObjectsAsync(selected[0]))DatabaseObjects.Add(item);
            Status=$"{DatabaseObjects.Count} objeto(s) disponible(s) en {selected[0].Server} · {selected[0].Name}.";
        }
        catch(Exception ex){Status=ex.Message;}
    }
    public void ApplySelectedDatabaseObjects(IEnumerable<DatabaseObjectItem> selected)
    {
        SelectedDatabaseObjects.Clear();
        foreach(var item in selected.OrderBy(x=>x.Schema).ThenBy(x=>x.Name))SelectedDatabaseObjects.Add(item);
        SelectedDatabaseObject=SelectedDatabaseObjects.Count==1?SelectedDatabaseObjects[0]:null;
        Securable=SelectedDatabaseObjects.Count==1?SelectedDatabaseObjects[0].QualifiedName:"";
        Raise(nameof(SelectedObjectsSummary));
        RefreshAvailablePermissions();
        Raise(nameof(PlannedChangesSummary));
        Decision=null;
        Status=$"{SelectedDatabaseObjects.Count} objeto(s) seleccionado(s). Marque los permisos GRANT que se aplicarán a todos.";
    }
    private async Task LoadInventoryDatabasesAsync(){InventoryDatabases.Clear();if(InventoryServer is null)return;try{var item=new ServerItem{Id=InventoryServer.Id,Name=InventoryServer.Name,Host=InventoryServer.Host,Instance=InventoryServer.Instance,WindowsAuth=InventoryServer.WindowsAuth,SqlUser=InventoryServer.SqlUser,Encrypt=InventoryServer.Encrypt,TrustCertificate=InventoryServer.TrustCertificate,TimeoutSeconds=InventoryServer.TimeoutSeconds,Active=true,IsSelected=true};foreach(var x in await _direct.GetDatabasesAsync([item]))InventoryDatabases.Add(x.Name);InventoryDatabase=InventoryDatabases.FirstOrDefault()??"master";}catch(Exception ex){Status=ex.Message;}}
    private async Task LoadInventoryAsync(){try{if(InventoryServer is null)throw new InvalidOperationException("Seleccione un servidor.");Status="Consultando inventario de seguridad…";Inventory=(await _direct.GetSecurityInventoryAsync(InventoryServer.Id,InventoryDatabase??"master",InventoryType??"LOGINS")).DefaultView;Status=$"Consulta {InventoryType} finalizada: {Inventory.Count} registros.";}catch(Exception ex){Status=ex.Message;}}
    private AccessRequestDraft Draft(string? roleOverride=null,string? permissionOverride=null,string? securableOverride=null)
    {
        var code=SelectedOperation?.Code??"";
        return new(
            code,
            TargetPrincipal.Trim(),
            RequiresSourcePrincipal?Null(SourcePrincipal):null,
            code switch{"CREATE_SQL_LOGIN"=>"SQL","CREATE_WINDOWS_LOGIN"=>"WINDOWS",_=>null},
            RequiresPermission?PermissionAction:null,
            RequiresPermission?(permissionOverride??SelectedPermission?.Permission):null,
            RequiresPermission?Scope:null,
            RequiresSecurable?(securableOverride??Null(Securable)):null,
            RequiresRole?(roleOverride??SelectedRole?.Name):null,
            Justification.Trim());
    }
    private IReadOnlyList<AccessRequestDraft> Drafts()
    {
        if(IsLoginMappingOperation)
            return RoleChoices.Where(x=>x.IsSelected).Select(x=>Draft(roleOverride:x.Name)).ToList();
        if(IsPermissionMatrixOperation)
        {
            var permissions=PermissionChoices.Where(x=>x.IsSelected).ToList();
            if(Scope.Equals("OBJECT",StringComparison.OrdinalIgnoreCase))
                return SelectedDatabaseObjects.SelectMany(item=>permissions.Select(permission=>Draft(permissionOverride:permission.Name,securableOverride:item.QualifiedName))).ToList();
            return permissions.Select(x=>Draft(permissionOverride:x.Name)).ToList();
        }
        return [Draft()];
    }
    private sealed record SubmissionPlan(AccessRequestDraft Draft,IReadOnlyList<DatabaseItem> Targets);
    private IReadOnlyList<SubmissionPlan> BuildSubmissionPlans(IReadOnlyList<DatabaseItem> defaultTargets)
    {
        if(!IsCreateLoginOperation||!IncludeInitialAccess)
            return Drafts().Select(x=>new SubmissionPlan(x,defaultTargets)).ToList();

        var databaseTargets=Databases.Where(x=>x.IsSelected).ToList();
        var principal=TargetPrincipal.Trim();
        var justification=Justification.Trim();
        var plans=new List<SubmissionPlan>
        {
            new(Draft(),defaultTargets),
            new(new("CREATE_DB_USER",principal,null,null,null,null,null,null,null,justification),databaseTargets)
        };
        plans.AddRange(InitialAccessRoleChoices
            .Where(x=>x.IsSelected)
            .Select(x=>new SubmissionPlan(
                new("ADD_ROLE_MEMBER",principal,null,null,null,null,null,null,x.Name,justification),
                databaseTargets)));
        plans.AddRange(InitialAccessPermissionChoices
            .Where(x=>x.IsSelected)
            .Select(x=>new SubmissionPlan(
                new("PERMISSION_CHANGE",principal,null,null,"GRANT",x.Name,"DATABASE",null,null,justification),
                databaseTargets)));
        return plans;
    }
    private static string? Null(string value)=>string.IsNullOrWhiteSpace(value)?null:value.Trim();
    private async Task PreviewAsync()
    {
        try
        {
            var targets=ValidateRequest();
            var plans=BuildSubmissionPlans(targets);
            var decisions=new List<PolicyDecision>();
            foreach(var plan in plans)decisions.Add(await _db.PreviewRequestAsync(plan.Draft));
            var denied=decisions.FirstOrDefault(x=>!x.Allowed);
            if(denied is not null)throw new InvalidOperationException(denied.Reason);
            Decision=decisions.First();
            Status=$"{plans.Count} cambio(s) permitido(s) · Riesgo {Decision.Risk} · requiere(n) confirmación.";
        }
        catch(Exception ex){Decision=null;Status=ex.Message;}
    }
    private async Task SubmitAsync()
    {
        try
        {
            var targets=ValidateRequest();
            var plans=BuildSubmissionPlans(targets);
            foreach(var plan in plans)
            {
                var duplicateId=await FindActiveDuplicateAsync(plan.Draft,plan.Targets);
                if(duplicateId is not null)
                    throw new InvalidOperationException($"Ya existe la solicitud activa #{duplicateId} con la misma operación, principal y destino. Revísela en 'Confirmar y ejecutar'.");
            }
            var ids=new List<long>();
            foreach(var plan in plans)
            {
                Decision=await _db.PreviewRequestAsync(plan.Draft);
                if(!Decision.Allowed)throw new InvalidOperationException(Decision.Reason);
                ids.Add(await _db.CreateRequestAsync(plan.Draft,plan.Targets));
            }
            _requestSubmitted=true;
            SubmitCommand.Refresh();
            IsManagingAccess=false;
            await LoadRequestsAsync();
            Status=$"{ids.Count} solicitud(es) enviada(s) una sola vez: {string.Join(", ",ids.Select(x=>$"#{x}"))}. Haga el doble check en 'Confirmar y ejecutar'.";
        }
        catch(Exception ex){Status=ex.Message;}
    }

    private async Task<long?> FindActiveDuplicateAsync(AccessRequestDraft draft,IReadOnlyList<DatabaseItem> targets)
    {
        if(SelectedWorkingServer is null)return null;
        var requestedTargets=targets
            .Select(x=>$"{x.ServerId}|{x.Name}")
            .ToHashSet(StringComparer.OrdinalIgnoreCase);
        var candidates=(await _db.GetRequestsAsync(serverId:SelectedWorkingServer.Id))
            .Where(x=>x.Status is "PENDING" or "APPROVED")
            .Where(x=>Same(x.Operation,draft.Operation)&&Same(x.TargetPrincipal,draft.TargetPrincipal))
            .Where(x=>Same(x.SourcePrincipal,draft.SourcePrincipal)&&Same(x.AuthenticationType,draft.AuthenticationType))
            .Where(x=>Same(x.PermissionAction,draft.PermissionAction)&&Same(x.Permission,draft.Permission))
            .Where(x=>Same(x.Scope,draft.Scope)&&Same(x.Securable,draft.Securable)&&Same(x.Role,draft.Role));
        foreach(var candidate in candidates)
        {
            var existingTargets=(await _db.GetRequestTargetsAsync(candidate.Id))
                .Select(x=>$"{x.ServerId}|{x.Name}")
                .ToHashSet(StringComparer.OrdinalIgnoreCase);
            if(requestedTargets.SetEquals(existingTargets))return candidate.Id;
        }
        return null;
    }

    private static bool Same(string? left,string? right)=>string.Equals(left?.Trim()??"",right?.Trim()??"",StringComparison.OrdinalIgnoreCase);

    private IReadOnlyList<DatabaseItem> ValidateRequest()
    {
        if(SelectedWorkingServer is null)throw new InvalidOperationException("Seleccione primero un servidor de trabajo.");
        if(SelectedOperation is null)throw new InvalidOperationException("Seleccione una operación desde el árbol de seguridad.");
        if(NeedsPolicyConfiguration)throw new InvalidOperationException("El DBA debe ejecutar 14_RedisenarMapeoLogin.sql en adminDB antes de generar esta solicitud.");
        if(string.IsNullOrWhiteSpace(TargetPrincipal))throw new InvalidOperationException($"Complete '{TargetPrincipalLabel}'.");
        if(RequiresSourcePrincipal&&string.IsNullOrWhiteSpace(SourcePrincipal))throw new InvalidOperationException("Indique el principal origen que se clonará.");
        if(IsLoginMappingOperation&&!RoleChoices.Any(x=>x.IsSelected))throw new InvalidOperationException("Seleccione al menos un rol permitido para la base de datos.");
        if(IsPermissionMatrixOperation&&!PermissionChoices.Any(x=>x.IsSelected))throw new InvalidOperationException("Seleccione al menos un permiso para conceder.");
        if(RequiresRole&&!IsLoginMappingOperation&&SelectedRole is null)throw new InvalidOperationException("Seleccione un rol aprobado.");
        if(RequiresPermission&&!IsPermissionMatrixOperation&&SelectedPermission is null)throw new InvalidOperationException("No existe un permiso permitido para la acción y el ámbito seleccionados.");
        if(RequiresSecurable&&IsPermissionMatrixOperation&&SelectedDatabaseObjects.Count==0)throw new InvalidOperationException("Seleccione al menos un objeto de la base de datos.");
        if(RequiresSecurable&&!IsPermissionMatrixOperation&&string.IsNullOrWhiteSpace(Securable))throw new InvalidOperationException($"Seleccione '{SecurableLabel}' ({SecurableHelp}).");
        if(RequiresDefaultDatabase&&string.IsNullOrWhiteSpace(Securable))throw new InvalidOperationException("Indique la base de datos predeterminada del login.");
        if(Justification.Trim().Length<10)throw new InvalidOperationException("Escriba una justificación de al menos 10 caracteres.");

        if(IsCreateLoginOperation&&IncludeInitialAccess)
        {
            if(!Databases.Any(x=>x.IsSelected))throw new InvalidOperationException("Seleccione al menos una base de datos para crear el usuario inicial.");
            if(!InitialAccessPermissionChoices.Any(x=>x.IsSelected)&&!InitialAccessRoleChoices.Any(x=>x.IsSelected))
                throw new InvalidOperationException("Seleccione al menos un rol autorizado o un permiso inicial para el usuario.");
        }

        if(IsServerOperation)
        {
            return [new DatabaseItem
            {
                ServerId=SelectedWorkingServer.Id,Server=SelectedWorkingServer.Name,Name="master",IsSelected=true
            }];
        }

        var databaseTargets=Databases.Where(x=>x.IsSelected&&x.ServerId==SelectedWorkingServer.Id).ToList();
        if(databaseTargets.Count==0)throw new InvalidOperationException("Seleccione al menos una base de datos destino.");
        if(IsLoginMappingOperation&&databaseTargets.Count!=1)throw new InvalidOperationException("Seleccione exactamente una base de datos para modificar el acceso del login.");
        if(RequiresPermission&&Scope=="OBJECT"&&databaseTargets.Count!=1)throw new InvalidOperationException("Los permisos sobre un objeto puntual requieren exactamente una base de datos destino.");
        if(RequiresPermission&&Scope=="OBJECT"&&SelectedDatabaseObjects.Any(x=>x.ServerId!=databaseTargets[0].ServerId||!x.Database.Equals(databaseTargets[0].Name,StringComparison.OrdinalIgnoreCase)))
            throw new InvalidOperationException("La base de datos destino cambió. Vuelva a seleccionar los objetos protegibles.");
        return databaseTargets;
    }
    private async Task LoadRequestsAsync()
    {
        try
        {
            Requests.Clear();
            HistoryRequests.Clear();
            if(SelectedWorkingServer is null)return;

            var serverId=SelectedWorkingServer.Id;
            var active=new List<AccessRequestItem>();
            var history=new List<AccessRequestItem>();
            foreach(var request in await _db.GetRequestsAsync(serverId:serverId))
            {
                // También verifica el filtro cuando adminDB conserva la firma anterior
                // del procedimiento y el gateway debe usar el modo de compatibilidad.
                var targets=await _db.GetRequestTargetsAsync(request.Id);
                var targetServers=targets.Select(x=>x.ServerId).Distinct().ToList();
                if(targetServers.Count!=1||targetServers[0]!=serverId)continue;
                if(request.Status is "PENDING" or "APPROVED")active.Add(request);
                else history.Add(request);
            }
            foreach(var request in active.OrderBy(x=>x.Id))Requests.Add(request);
            foreach(var request in history.OrderByDescending(x=>x.Id))HistoryRequests.Add(request);
        }
        catch(Exception ex){Status=ex.Message;}
    }
    private async Task ApproveAsync(bool approve)
    {
        try
        {
            if(SelectedRequest is null)throw new InvalidOperationException("Seleccione una solicitud.");
            var requestId=SelectedRequest.Id;
            await _db.ApproveRequestAsync(requestId,approve,ApprovalComment);
            await LoadRequestsAsync();
            SelectedRequest=Requests.FirstOrDefault(x=>x.Id==requestId);
            ApprovalComment="";
            Status=approve
                ? $"Solicitud #{requestId} confirmada. Revise la fila seleccionada y presione 'Ejecutar confirmada'."
                : $"Solicitud #{requestId} rechazada.";
        }
        catch(Exception ex){Status=ex.Message;}
    }
    private async Task ExecuteApprovedAsync()
    {
        try
        {
            if(SelectedRequest is null)throw new InvalidOperationException("Seleccione una solicitud confirmada.");if(SelectedRequest.Status!="APPROVED")throw new InvalidOperationException("La solicitud no está confirmada.");
            var check=await _db.PreviewRequestAsync(new(SelectedRequest.Operation,SelectedRequest.TargetPrincipal,Null(SelectedRequest.SourcePrincipal),Null(SelectedRequest.AuthenticationType),Null(SelectedRequest.PermissionAction),Null(SelectedRequest.Permission),Null(SelectedRequest.Scope),Null(SelectedRequest.Securable),Null(SelectedRequest.Role),SelectedRequest.Justification));
            if(!check.Allowed)throw new InvalidOperationException($"La política cambió y ahora bloquea la solicitud: {check.Reason}");
            var targets=await _db.GetRequestTargetsAsync(SelectedRequest.Id);if(SelectedWorkingServer is null||targets.Any(x=>x.ServerId!=SelectedWorkingServer.Id))throw new InvalidOperationException("La solicitud no pertenece exclusivamente al servidor de trabajo seleccionado.");Results.Clear();foreach(var x in await _direct.ExecuteApprovedRequestAsync(SelectedRequest,targets,ExecutionPassword))Results.Add(x);var success=Results.All(x=>x.Success);var detail=$"{Results.Count(x=>x.Success)} correctos; {Results.Count(x=>!x.Success)} fallidos.";await _db.MarkRequestExecutedAsync(SelectedRequest.Id,success,detail);Status=$"Solicitud #{SelectedRequest.Id}: {detail}";await LoadRequestsAsync();
        }
        catch(Exception ex){Status=ex.Message;}
        finally{ExecutionPassword="";}
    }
}

public sealed class PolicyViewModel : BindableBase
{
    private readonly AdminDbGateway _db;private string _status="Política deny-by-default.",_permission="SELECT",_scope="OBJECT",_denyCategory="PERMISSION",_denyValue="",_denyReason="";private bool _allowGrant=true,_allowDeny=false,_allowRevoke=true;
    public ObservableCollection<PolicyOperation> Operations {get;}=[];public ObservableCollection<PolicyPermission> Permissions {get;}=[];public ObservableCollection<PolicyRole> Roles {get;}=[];public ObservableCollection<DenyRule> DenyRules {get;}=[];
    public string[] AllowedPermissionNames {get;}=["SELECT","INSERT","UPDATE","DELETE","EXECUTE"];public string[] Scopes {get;}=["DATABASE","OBJECT"];public string[] DenyCategories {get;}=["PERMISSION","DATABASE_ROLE","SERVER_ROLE","OPERATION","CLAUSE"];
    public string Permission {get=>_permission;set=>Set(ref _permission,value);}public string Scope {get=>_scope;set=>Set(ref _scope,value);}public bool AllowGrant {get=>_allowGrant;set=>Set(ref _allowGrant,value);}public bool AllowDeny {get=>_allowDeny;set=>Set(ref _allowDeny,value);}public bool AllowRevoke {get=>_allowRevoke;set=>Set(ref _allowRevoke,value);}
    public string DenyCategory {get=>_denyCategory;set=>Set(ref _denyCategory,value);}public string DenyValue {get=>_denyValue;set=>Set(ref _denyValue,value);}public string DenyReason {get=>_denyReason;set=>Set(ref _denyReason,value);}public string Status {get=>_status;set=>Set(ref _status,value);}
    public AsyncCommand RefreshCommand {get;}public AsyncCommand AddPermissionCommand {get;}public AsyncCommand AddDenyCommand {get;}
    public PolicyViewModel(AdminDbGateway db){_db=db;RefreshCommand=new(LoadAsync);AddPermissionCommand=new(AddPermissionAsync);AddDenyCommand=new(AddDenyAsync);RefreshCommand.Execute(null);}
    private async Task LoadAsync(){try{Operations.Clear();Permissions.Clear();Roles.Clear();DenyRules.Clear();foreach(var x in await _db.GetPolicyOperationsAsync())Operations.Add(x);foreach(var x in await _db.GetPolicyPermissionsAsync())Permissions.Add(x);foreach(var x in await _db.GetPolicyRolesAsync())Roles.Add(x);foreach(var x in await _db.GetDenyRulesAsync())DenyRules.Add(x);Status=$"{Permissions.Count} reglas permitidas y {DenyRules.Count} bloqueos.";}catch(Exception ex){Status=ex.Message;}}
    private async Task AddPermissionAsync(){try{await _db.UpsertPermissionAsync(new(Permission,Scope,AllowGrant,AllowDeny,AllowRevoke,true,"",DateTime.UtcNow));await LoadAsync();}catch(Exception ex){Status=ex.Message;}}
    private async Task AddDenyAsync(){try{if(string.IsNullOrWhiteSpace(DenyValue)||string.IsNullOrWhiteSpace(DenyReason))throw new InvalidOperationException("Indique valor y motivo.");await _db.UpsertDenyRuleAsync(DenyCategory,DenyValue,DenyReason);await LoadAsync();}catch(Exception ex){Status=ex.Message;}}
}
