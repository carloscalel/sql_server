using System.Collections.ObjectModel;
using SqlAccessAdmin.Infrastructure;

namespace SqlAccessAdmin.Models;

public enum AppRole { Administrator, Operator, Auditor }
public sealed record SessionContext(string Principal, AppRole Role);
public sealed record PivotOptions(string Server, string Instance, string Database, bool IntegratedSecurity, string? User, string? Password, bool Encrypt, bool TrustCertificate)
{ public string DataSource => string.IsNullOrWhiteSpace(Instance) ? Server : $"{Server}\\{Instance}"; }

public sealed class ServerItem : BindableBase
{
    private bool _selected,_active;
    public int Id { get; init; } public bool IsSelected { get => _selected; set => Set(ref _selected, value); }
    public bool Active { get=>_active; set=>Set(ref _active,value); } public string Name { get; init; } = ""; public string Host { get; init; } = ""; public string Instance { get; init; } = "";
    public bool WindowsAuth { get; init; } public string SqlUser { get; init; } = ""; public bool Encrypt { get; init; } public bool TrustCertificate { get; init; } public int TimeoutSeconds { get; init; } = 30;
}
public sealed class DatabaseItem : BindableBase { private bool _selected; public int ServerId { get; init; } public string Server { get; init; }=""; public string Name { get; init; }=""; public bool IsSelected { get=>_selected; set=>Set(ref _selected,value); } }
public sealed record DatabaseObjectItem(int ServerId,string Server,string Database,string Schema,string Name,string Kind)
{
    public string QualifiedName=>$"{Schema}.{Name}";
    public string DisplayName=>$"{Schema}.{Name}  ·  {Kind}";
}
public sealed class DatabaseObjectSelectionItem(DatabaseObjectItem item,bool selected=false) : BindableBase
{
    private bool _selected=selected;
    public DatabaseObjectItem Item {get;}=item;
    public string Schema=>Item.Schema;
    public string Name=>Item.Name;
    public string Kind=>Item.Kind;
    public string QualifiedName=>Item.QualifiedName;
    public bool IsSelected {get=>_selected;set=>Set(ref _selected,value);}
}
public sealed record AuthorizedUser(int Id, string Principal, string Type, AppRole Role, bool Active, string Notes);
public sealed record AuditEvent(DateTime Date, string User, string Form, string Action, string Server, string Database, bool Success, string Detail);
public sealed record OperationResult(string Server, string Database, bool Success, string Message);
public sealed record CryptoMaterial(Guid KeyId, byte[] MasterKey);
public sealed record CredentialEnvelope(byte[] Ciphertext, byte[] Nonce, byte[] Tag, Guid KeyId);
public sealed record ServerConnectionInfo(int Id,string Name,string Host,string Instance,bool WindowsAuth,string SqlUser,CredentialEnvelope? Credential,bool Encrypt,bool TrustCertificate,int TimeoutSeconds);
public sealed record ServerEditData(int? Id,string Name,string Host,string Instance,bool WindowsAuth,string SqlUser,string? Password,bool Encrypt,bool TrustCertificate,int TimeoutSeconds,bool Active);
public sealed record PolicyOperation(string Code,string Name,bool Enabled,bool RequiresApproval,string Risk,string Description);
public sealed record PolicyPermission(string Permission,string Scope,bool AllowGrant,bool AllowDeny,bool AllowRevoke,bool Enabled,string ApprovedBy,DateTime ApprovedAt);
public sealed record PolicyRole(string Name,string Kind,bool Enabled,string ApprovedBy,DateTime ApprovedAt,string Notes);
public sealed class RoleSelectionItem(PolicyRole role) : BindableBase
{
    private bool _selected;
    public PolicyRole Role { get; }=role;
    public string Name=>Role.Name;
    public string Kind=>Role.Kind;
    public bool IsSelected {get=>_selected;set=>Set(ref _selected,value);}
}
public sealed class PermissionSelectionItem(PolicyPermission permission) : BindableBase
{
    private bool _selected;
    public PolicyPermission PermissionRule { get; }=permission;
    public string Name=>PermissionRule.Permission;
    public bool IsSelected {get=>_selected;set=>Set(ref _selected,value);}
}
public sealed record DenyRule(int Id,string Category,string Value,string Reason,bool IsSystem,bool Active,string CreatedBy,DateTime CreatedAt);
public sealed record PolicyDecision(bool Allowed,bool RequiresApproval,string Risk,string Reason);
public sealed record AccessRequestItem(long Id,string Operation,string TargetPrincipal,string SourcePrincipal,string AuthenticationType,string PermissionAction,string Permission,string Scope,string Securable,string Role,string Justification,string Status,string RequestedBy,DateTime RequestedAt,string ApprovedBy,DateTime? ApprovedAt,int TargetCount);
public sealed record AccessRequestDraft(string Operation,string TargetPrincipal,string? SourcePrincipal,string? AuthenticationType,string? PermissionAction,string? Permission,string? Scope,string? Securable,string? Role,string Justification);
public sealed record AuditIntegrity(long HashedEvents,int BrokenLinks,int AlteredEvents,bool IsValid);

public enum SecurityNodeKind
{
    Server,
    LoginGroup,
    Login,
    DatabaseGroup,
    Database,
    UserGroup,
    User,
    Loading,
    Error
}

public sealed class SecurityTreeNode : BindableBase
{
    private bool _isLoaded;
    private bool _isVisible=true;
    private bool _isExpanded;

    public SecurityTreeNode(
        string name,
        SecurityNodeKind kind,
        int serverId,
        string serverName,
        string database = "",
        string principal = "",
        bool loadOnExpand = false)
    {
        Name = name;
        Kind = kind;
        ServerId = serverId;
        ServerName = serverName;
        Database = database;
        Principal = principal;
        LoadOnExpand = loadOnExpand;
        if (loadOnExpand)
            Children.Add(new SecurityTreeNode("Cargando…", SecurityNodeKind.Loading, serverId, serverName));
    }

    public string Name { get; }
    public SecurityNodeKind Kind { get; }
    public int ServerId { get; }
    public string ServerName { get; }
    public string Database { get; }
    public string Principal { get; }
    public bool LoadOnExpand { get; }
    public ObservableCollection<SecurityTreeNode> Children { get; } = [];
    public bool IsPrincipal => Kind is SecurityNodeKind.Login or SecurityNodeKind.User;
    public bool IsLoaded { get => _isLoaded; set => Set(ref _isLoaded, value); }
    public bool IsVisible { get => _isVisible; set => Set(ref _isVisible, value); }
    public bool IsExpanded { get => _isExpanded; set => Set(ref _isExpanded, value); }
    public string Icon => Kind switch
    {
        SecurityNodeKind.Server => "▣",
        SecurityNodeKind.LoginGroup => "♟",
        SecurityNodeKind.Login => "●",
        SecurityNodeKind.DatabaseGroup => "▰",
        SecurityNodeKind.Database => "●",
        SecurityNodeKind.UserGroup => "♟",
        SecurityNodeKind.User => "●",
        SecurityNodeKind.Error => "!",
        _ => "·"
    };
}

public sealed record SecurityPermissionItem(string State, string Permission, string Scope, string Securable, string Grantor);
public sealed record SecurityMembershipItem(string Type, string Name, string Context);

public sealed class SecurityPrincipalDetails
{
    public List<SecurityPermissionItem> Permissions { get; } = [];
    public List<SecurityMembershipItem> Memberships { get; } = [];
}
