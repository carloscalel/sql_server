using Microsoft.Data.SqlClient;
using System.Collections.ObjectModel;
using System.Data;
using System.Text;

namespace OfuscadorTool;

public sealed class DatabaseService(LoginContext context)
{
    internal const string MaskableTableSqlPredicate =
        "t.is_ms_shipped=0 " +
        "AND s.name NOT IN(N'sys',N'INFORMATION_SCHEMA',N'ofuscador',N'masked',N'app',N'log',N'logs',N'audit',N'auditoria',N'auditoría') " +
        "AND t.name NOT IN(N'Masked_Audit',N'Masked_Patterns',N'Masked_Exceptions')";

    public LoginContext Context { get; } = context;

    private static SqlConnection Connection(string cs) => new(cs);

    public static string BuildConnection(string source, string database, bool windows, string user, string password,
        bool encrypt, bool trust, int timeout = 30) =>
        new SqlConnectionStringBuilder
        {
            DataSource = source,
            InitialCatalog = database,
            IntegratedSecurity = windows,
            UserID = windows ? "" : user,
            Password = windows ? "" : password,
            Encrypt = encrypt,
            TrustServerCertificate = trust,
            ConnectTimeout = Math.Clamp(timeout, 5, 300),
            ApplicationName = "OfuscadorTool"
        }.ConnectionString;

    public string TargetConnection(ServerProfile server, string database = "master") =>
        BuildConnection(server.DataSource, database, server.UseWindowsAuth, server.SqlUser,
            server.UseWindowsAuth ? "" : DecryptServerCredential(server.EncryptedPassword),
            server.Encrypt, server.TrustServerCertificate, server.TimeoutSeconds);

    public static bool IsCentralCredential(string value) =>
        value.StartsWith("SQL1:", StringComparison.Ordinal);

    public async Task<string> EncryptServerCredentialAsync(string plainText)
    {
        if (string.IsNullOrEmpty(plainText)) return "";
        await using var cn = Connection(Context.PivotConnectionString);
        await cn.OpenAsync();
        await using var cmd = new SqlCommand("ofuscador.EncryptServerCredential", cn)
        {
            CommandType = CommandType.StoredProcedure
        };
        cmd.Parameters.Add(new SqlParameter("@PlainText", SqlDbType.NVarChar, 4000) { Value = plainText });
        var result = await cmd.ExecuteScalarAsync();
        return Convert.ToString(result) is { Length: > 5 } encrypted
            ? encrypted
            : throw new InvalidOperationException("SQL Server no devolvió una credencial cifrada.");
    }

    private string DecryptServerCredential(string encryptedValue)
    {
        if (string.IsNullOrWhiteSpace(encryptedValue)) return "";
        if (!IsCentralCredential(encryptedValue))
            return SecurityService.UnprotectLegacy(encryptedValue);

        using var cn = Connection(Context.PivotConnectionString);
        cn.Open();
        using var cmd = new SqlCommand("ofuscador.DecryptServerCredential", cn)
        {
            CommandType = CommandType.StoredProcedure
        };
        cmd.Parameters.Add(new SqlParameter("@EncryptedValue", SqlDbType.NVarChar, -1) { Value = encryptedValue });
        var result = cmd.ExecuteScalar();
        return Convert.ToString(result) is { } plainText
            ? plainText
            : throw new InvalidOperationException("SQL Server no pudo descifrar la credencial del servidor destino.");
    }

    public async Task ValidateInstallationAsync(CancellationToken cancellationToken = default)
    {
        const string sql = """
        SELECT CASE WHEN SCHEMA_ID(N'ofuscador') IS NULL THEN 0 ELSE 1 END,
               HAS_PERMS_BY_NAME(N'ofuscador',N'SCHEMA',N'VIEW DEFINITION');
        SELECT COUNT(*) FROM (VALUES
          (OBJECT_ID(N'ofuscador.Servers',N'U')),(OBJECT_ID(N'ofuscador.AuthorizedUsers',N'U')),
          (OBJECT_ID(N'ofuscador.MaskPatterns',N'U')),(OBJECT_ID(N'ofuscador.Executions',N'U')),
          (OBJECT_ID(N'ofuscador.ExecutionTargets',N'U')),(OBJECT_ID(N'ofuscador.PermissionBackup',N'U')),
          (OBJECT_ID(N'ofuscador.Audit',N'U')),(OBJECT_ID(N'ofuscador.MaskProfiles',N'U')),
          (OBJECT_ID(N'ofuscador.MaskProfileColumns',N'U')),(OBJECT_ID(N'ofuscador.MaskProfileUsers',N'U')),
          (OBJECT_ID(N'ofuscador.MaskExceptions',N'U'))
        ) RequiredObjects(ObjectId) WHERE ObjectId IS NOT NULL;
        """;
        await using var cn = Connection(Context.PivotConnectionString);
        await cn.OpenAsync(cancellationToken);
        await using var cmd = new SqlCommand(sql, cn);
        await using var reader = await cmd.ExecuteReaderAsync(cancellationToken);
        if (!await reader.ReadAsync())
            throw new InvalidOperationException("No se pudo validar la instalación administrativa.");
        if (reader.GetInt32(1) != 1)
            throw new UnauthorizedAccessException(
                "El usuario no tiene permiso para validar los objetos de [ofuscador]. Un DBA debe ejecutar Suministros_Produccion/02_permisos_roles.sql y asignar el rol SQL correspondiente.");
        if (reader.GetInt32(0) != 1)
            throw new InvalidOperationException("No existe el esquema [ofuscador]. Un DBA debe ejecutar Suministros_Produccion/00_instalacion_adminDB.sql.");
        await reader.NextResultAsync();
        if (!await reader.ReadAsync() || reader.GetInt32(0) != 11)
            throw new InvalidOperationException("Faltan tablas administrativas visibles en [ofuscador]. Un DBA debe ejecutar 03_verificacion_instalacion.sql y completar la instalación.");

        await reader.CloseAsync();
        await using var cryptoCmd = new SqlCommand("""
            SELECT COUNT(*) FROM (VALUES
              (OBJECT_ID(N'ofuscador.EncryptServerCredential',N'P')),
              (OBJECT_ID(N'ofuscador.DecryptServerCredential',N'P'))
            ) RequiredObjects(ObjectId) WHERE ObjectId IS NOT NULL;
            """, cn);
        if (Convert.ToInt32(await cryptoCmd.ExecuteScalarAsync(cancellationToken)) != 2)
            throw new InvalidOperationException(
                "No está configurado el cifrado central de credenciales. Un DBA debe ejecutar Suministros_Produccion/07_cifrado_credenciales.sql y luego 02_permisos_roles.sql.");
    }

    public async Task<bool> IsAuthorizedAsync()
    {
        var result = await ScalarAsync(Context.PivotConnectionString,
            "SELECT COUNT(*) FROM ofuscador.AuthorizedUsers WHERE Principal=@p AND IsActive=1",
            new SqlParameter("@p", Context.Principal));
        return Convert.ToInt32(result) > 0;
    }

    public async Task<string?> GetUserRoleAsync(CancellationToken cancellationToken = default)
    {
        var result = await ScalarCancelableAsync(Context.PivotConnectionString,
            "SELECT TOP(1) AppRole FROM ofuscador.AuthorizedUsers WHERE Principal=@p AND IsActive=1",
            cancellationToken, new SqlParameter("@p", Context.Principal));
        return result == null || result == DBNull.Value ? null : Convert.ToString(result);
    }

    public async Task AuditAsync(string form, string action, bool success, string? detail = null,
        string? server = null, string? database = null, CancellationToken cancellationToken = default)
    {
        await ExecuteCancelableAsync(Context.PivotConnectionString, """
            INSERT ofuscador.Audit(Principal,FormName,ActionName,ServerName,DatabaseName,Success,Detail)
            VALUES(@p,@f,@a,@s,@d,@ok,@x)
            """, cancellationToken, new("@p", Context.Principal), new("@f", form), new("@a", action),
            new("@s", (object?)server ?? DBNull.Value), new("@d", (object?)database ?? DBNull.Value),
            new("@ok", success), new("@x", (object?)detail ?? DBNull.Value));
    }

    public async Task<ObservableCollection<ServerProfile>> LoadServersAsync()
    {
        var result = new ObservableCollection<ServerProfile>();
        await using var cn = Connection(Context.PivotConnectionString);
        await cn.OpenAsync();
        await using var cmd = new SqlCommand("""
            SELECT ServerId,IsActive,Name,Host,ISNULL(Instance,''),UseWindowsAuth,ISNULL(SqlUser,''),
                   ISNULL(EncryptedPassword,''),Encrypt,TrustServerCertificate,TimeoutSeconds FROM ofuscador.Servers ORDER BY Name
            """, cn);
        await using var rd = await cmd.ExecuteReaderAsync();
        while (await rd.ReadAsync())
            result.Add(new()
            {
                Id = rd.GetInt32(0), IsActive = rd.GetBoolean(1), Name = rd.GetString(2), Host = rd.GetString(3),
                Instance = rd.GetString(4), UseWindowsAuth = rd.GetBoolean(5), SqlUser = rd.GetString(6),
                EncryptedPassword = rd.GetString(7), Encrypt = rd.GetBoolean(8), TrustServerCertificate = rd.GetBoolean(9), TimeoutSeconds = rd.GetInt32(10)
            });
        return result;
    }

    public Task SaveServerAsync(ServerProfile s) => ExecuteAsync(Context.PivotConnectionString, """
        MERGE ofuscador.Servers AS t
        USING (SELECT @id ServerId) s ON t.ServerId=s.ServerId
        WHEN MATCHED THEN UPDATE SET IsActive=@active,Name=@name,Host=@host,Instance=@instance,
          UseWindowsAuth=@windows,SqlUser=@user,EncryptedPassword=@password,Encrypt=@encrypt,TrustServerCertificate=@trust,TimeoutSeconds=@timeout
        WHEN NOT MATCHED THEN INSERT(IsActive,Name,Host,Instance,UseWindowsAuth,SqlUser,EncryptedPassword,Encrypt,TrustServerCertificate,TimeoutSeconds)
          VALUES(@active,@name,@host,@instance,@windows,@user,@password,@encrypt,@trust,@timeout);
        """, new("@id", s.Id), new("@active", s.IsActive), new("@name", s.Name), new("@host", s.Host),
        new("@instance", (object?)s.Instance ?? DBNull.Value), new("@windows", s.UseWindowsAuth),
        new("@user", (object?)s.SqlUser ?? DBNull.Value), new("@password", (object?)s.EncryptedPassword ?? DBNull.Value),
        new("@encrypt", s.Encrypt), new("@trust", s.TrustServerCertificate), new("@timeout", s.TimeoutSeconds));

    public Task DeleteServerAsync(int id) => ExecuteAsync(Context.PivotConnectionString,
        "DELETE ofuscador.Servers WHERE ServerId=@id", new SqlParameter("@id", id));

    public async Task<List<string>> LoadDatabasesAsync(ServerProfile server,
        CancellationToken cancellationToken = default)
    {
        var result = new List<string>();
        await using var cn = Connection(TargetConnection(server));
        await cn.OpenAsync(cancellationToken);
        await using var cmd = new SqlCommand("""
            SELECT name FROM sys.databases WHERE state=0 AND database_id>4 AND source_database_id IS NULL ORDER BY name
            """, cn);
        await using var rd = await cmd.ExecuteReaderAsync(cancellationToken);
        while (await rd.ReadAsync(cancellationToken)) result.Add(rd.GetString(0));
        return result;
    }

    public async Task<List<MaskingInventoryRow>> LoadMaskingInventoryAsync(ServerProfile server, string database,
        CancellationToken cancellationToken = default)
    {
        const string sql = """
        SET NOCOUNT ON;

        /* Las tablas temporales usan siempre el collation de la base inspeccionada. */
        CREATE TABLE #Patterns
        (
            Pattern nvarchar(128) COLLATE DATABASE_DEFAULT NOT NULL,
            ViewMaskExpr nvarchar(1000) COLLATE DATABASE_DEFAULT NULL,
            Priority int NOT NULL
        );

        /* Compatibilidad con versiones antiguas que no tenían Priority o usaban
           ViewMaskExpression en lugar de ViewMaskExpr. El SQL dinámico evita que
           el compilador intente resolver columnas inexistentes. */
        IF OBJECT_ID(N'dbo.Masked_Patterns', N'U') IS NOT NULL
           AND COL_LENGTH(N'dbo.Masked_Patterns',N'Pattern') IS NOT NULL
        BEGIN
            IF COL_LENGTH(N'dbo.Masked_Patterns',N'ViewMaskExpr') IS NOT NULL
            BEGIN
                IF COL_LENGTH(N'dbo.Masked_Patterns',N'Priority') IS NOT NULL
                    EXEC(N'INSERT #Patterns(Pattern,ViewMaskExpr,Priority)
                           SELECT Pattern COLLATE DATABASE_DEFAULT,
                                  ViewMaskExpr COLLATE DATABASE_DEFAULT,Priority
                           FROM dbo.Masked_Patterns;');
                ELSE
                    EXEC(N'INSERT #Patterns(Pattern,ViewMaskExpr,Priority)
                           SELECT Pattern COLLATE DATABASE_DEFAULT,
                                  ViewMaskExpr COLLATE DATABASE_DEFAULT,200
                           FROM dbo.Masked_Patterns;');
            END
            ELSE IF COL_LENGTH(N'dbo.Masked_Patterns',N'ViewMaskExpression') IS NOT NULL
            BEGIN
                IF COL_LENGTH(N'dbo.Masked_Patterns',N'Priority') IS NOT NULL
                    EXEC(N'INSERT #Patterns(Pattern,ViewMaskExpr,Priority)
                           SELECT Pattern COLLATE DATABASE_DEFAULT,
                                  ViewMaskExpression COLLATE DATABASE_DEFAULT,Priority
                           FROM dbo.Masked_Patterns;');
                ELSE
                    EXEC(N'INSERT #Patterns(Pattern,ViewMaskExpr,Priority)
                           SELECT Pattern COLLATE DATABASE_DEFAULT,
                                  ViewMaskExpression COLLATE DATABASE_DEFAULT,200
                           FROM dbo.Masked_Patterns;');
            END
        END;

        CREATE TABLE #Exceptions
        (
            SchemaName sysname COLLATE DATABASE_DEFAULT NOT NULL,
            TableName sysname COLLATE DATABASE_DEFAULT NOT NULL,
            ColumnName sysname COLLATE DATABASE_DEFAULT NULL,
            ActionName nvarchar(40) COLLATE DATABASE_DEFAULT NOT NULL
        );

        IF OBJECT_ID(N'dbo.Masked_Exceptions', N'U') IS NOT NULL
           AND COL_LENGTH(N'dbo.Masked_Exceptions',N'SchemaName') IS NOT NULL
           AND COL_LENGTH(N'dbo.Masked_Exceptions',N'TableName') IS NOT NULL
           AND COL_LENGTH(N'dbo.Masked_Exceptions',N'ColumnName') IS NOT NULL
        BEGIN
            IF COL_LENGTH(N'dbo.Masked_Exceptions',N'ActionName') IS NOT NULL
                EXEC(N'INSERT #Exceptions(SchemaName,TableName,ColumnName,ActionName)
                       SELECT SchemaName COLLATE DATABASE_DEFAULT,
                              TableName COLLATE DATABASE_DEFAULT,
                              ColumnName COLLATE DATABASE_DEFAULT,
                              ActionName COLLATE DATABASE_DEFAULT
                       FROM dbo.Masked_Exceptions;');
            ELSE
                EXEC(N'INSERT #Exceptions(SchemaName,TableName,ColumnName,ActionName)
                       SELECT SchemaName COLLATE DATABASE_DEFAULT,
                              TableName COLLATE DATABASE_DEFAULT,
                              ColumnName COLLATE DATABASE_DEFAULT,N''NO_OFUSCAR_COLUMNA''
                       FROM dbo.Masked_Exceptions WHERE ColumnName IS NOT NULL;');
        END;

        CREATE TABLE #Inventory
        (
            SchemaName sysname COLLATE DATABASE_DEFAULT NOT NULL,
            TableName sysname COLLATE DATABASE_DEFAULT NOT NULL,
            ColumnName sysname COLLATE DATABASE_DEFAULT NOT NULL,
            ProtectionType nvarchar(40) COLLATE DATABASE_DEFAULT NOT NULL,
            MaskingRule nvarchar(1000) COLLATE DATABASE_DEFAULT NOT NULL
        );

        /* Se insertan los dos orígenes por separado para no comparar collations
           incompatibles mediante UNION ALL. */
        INSERT #Inventory(SchemaName,TableName,ColumnName,ProtectionType,MaskingRule)
        SELECT s.name COLLATE DATABASE_DEFAULT,t.name COLLATE DATABASE_DEFAULT,
               c.name COLLATE DATABASE_DEFAULT,N'DDM',
               ISNULL(mc.masking_function,N'') COLLATE DATABASE_DEFAULT
        FROM sys.masked_columns mc
        JOIN sys.columns c ON c.object_id=mc.object_id AND c.column_id=mc.column_id
        JOIN sys.tables t ON t.object_id=c.object_id
        JOIN sys.schemas s ON s.schema_id=t.schema_id
        WHERE mc.is_masked=1
          AND s.name NOT IN(N'sys',N'INFORMATION_SCHEMA',N'ofuscador',N'masked',N'app',N'log',N'logs',N'audit',N'auditoria',N'auditoría')
          AND t.name NOT IN(N'Masked_Audit',N'Masked_Patterns',N'Masked_Exceptions');

        INSERT #Inventory(SchemaName,TableName,ColumnName,ProtectionType,MaskingRule)
        SELECT bs.name COLLATE DATABASE_DEFAULT,bt.name COLLATE DATABASE_DEFAULT,
               bc.name COLLATE DATABASE_DEFAULT,
               CASE WHEN p.Pattern IS NULL OR x.ColumnName IS NOT NULL
                    THEN N'Visible en vista' ELSE N'Vista masked' END,
               CASE WHEN p.Pattern IS NULL OR x.ColumnName IS NOT NULL
                    THEN N'Sin transformación' ELSE p.Pattern END
        FROM sys.tables bt
        JOIN sys.schemas bs ON bs.schema_id=bt.schema_id
        JOIN sys.views v ON v.name COLLATE DATABASE_DEFAULT=
            (CASE WHEN bs.name=N'dbo' THEN bt.name ELSE bs.name+N'__'+bt.name END) COLLATE DATABASE_DEFAULT
        JOIN sys.schemas vs ON vs.schema_id=v.schema_id AND vs.name COLLATE DATABASE_DEFAULT=N'masked'
        JOIN sys.columns bc ON bc.object_id=bt.object_id
        OUTER APPLY
        (
            SELECT TOP(1) Pattern
            FROM #Patterns p0
            WHERE bc.name COLLATE DATABASE_DEFAULT LIKE p0.Pattern
              AND NULLIF(p0.ViewMaskExpr,N'') IS NOT NULL
            ORDER BY p0.Priority,p0.Pattern
        ) p
        OUTER APPLY
        (
            SELECT TOP(1) e.ColumnName
            FROM #Exceptions e
            WHERE e.SchemaName=bs.name COLLATE DATABASE_DEFAULT
              AND e.TableName=bt.name COLLATE DATABASE_DEFAULT
              AND e.ColumnName=bc.name COLLATE DATABASE_DEFAULT
              AND e.ActionName=N'NO_OFUSCAR_COLUMNA'
        ) x
        WHERE bt.is_ms_shipped=0
          AND bs.name NOT IN(N'sys',N'INFORMATION_SCHEMA',N'ofuscador',N'masked',N'app',N'log',N'logs',N'audit',N'auditoria',N'auditoría')
          AND bt.name NOT IN(N'Masked_Audit',N'Masked_Patterns',N'Masked_Exceptions')
          AND NOT EXISTS
        (
            SELECT 1 FROM sys.masked_columns mc
            WHERE mc.object_id=bc.object_id AND mc.column_id=bc.column_id AND mc.is_masked=1
        );

        SELECT SchemaName,TableName,ColumnName,ProtectionType,MaskingRule
        FROM #Inventory ORDER BY SchemaName,TableName,ColumnName;
        """;

        var result = new List<MaskingInventoryRow>();
        await using var cn = Connection(TargetConnection(server, database));
        await cn.OpenAsync(cancellationToken);
        await using var cmd = new SqlCommand(sql, cn) { CommandTimeout = Math.Max(60, server.TimeoutSeconds) };
        await using var rd = await cmd.ExecuteReaderAsync(cancellationToken);
        while (await rd.ReadAsync(cancellationToken))
            result.Add(new MaskingInventoryRow
            {
                Server = server.Name,
                Database = database,
                Schema = rd.GetString(0),
                Table = rd.GetString(1),
                Column = rd.GetString(2),
                ProtectionType = rd.GetString(3),
                MaskingRule = rd.GetString(4),
                State = "Ofuscada"
            });
        return result;
    }

    public async Task<HashSet<string>> LoadRolledBackTargetsAsync()
    {
        var result = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        await using var cn = Connection(Context.PivotConnectionString);
        await cn.OpenAsync();
        await using var cmd = new SqlCommand("""
            WITH Operations AS
            (
                /* Auditoría granular generada por las versiones actuales. */
                SELECT ServerName,DatabaseName,FormName,EventAt,AuditId
                FROM ofuscador.Audit
                WHERE Success=1 AND ServerName IS NOT NULL AND DatabaseName IS NOT NULL
                  AND ((FormName=N'Rollback' AND ActionName=N'Destino revertido')
                    OR (FormName=N'Ofuscamiento' AND ActionName=N'Destino desplegado'))

                UNION ALL

                /* Compatibilidad: rollbacks antiguos solo guardaban SourceExecutionId en Detail. */
                SELECT et.ServerName,et.DatabaseName,N'Rollback',a.EventAt,a.AuditId
                FROM ofuscador.Audit a
                CROSS APPLY
                (
                    SELECT TRY_CONVERT(uniqueidentifier,
                        SUBSTRING(a.Detail,CHARINDEX(N'SourceExecutionId=',a.Detail)+18,36)) SourceExecutionId
                ) parsed
                JOIN ofuscador.ExecutionTargets et ON et.ExecutionId=parsed.SourceExecutionId
                WHERE a.Success=1 AND a.FormName=N'Rollback' AND a.ActionName=N'Ejecutar'
                  AND a.Detail LIKE N'%SourceExecutionId=%'

                UNION ALL

                /* Historial de despliegues anterior a la auditoría granular. */
                SELECT et.ServerName,et.DatabaseName,N'Ofuscamiento',
                       ISNULL(e.FinishedAt,e.StartedAt),CONVERT(bigint,0)
                FROM ofuscador.Executions e
                JOIN ofuscador.ExecutionTargets et ON et.ExecutionId=e.ExecutionId
                WHERE e.Mode=N'Deploy' AND et.Status=N'OK'
            ),
            LastOperation AS
            (
                SELECT ServerName,DatabaseName,FormName,
                       ROW_NUMBER() OVER(PARTITION BY ServerName,DatabaseName ORDER BY EventAt DESC,AuditId DESC) rn
                FROM Operations
            )
            SELECT ServerName,DatabaseName FROM LastOperation
            WHERE rn=1 AND FormName=N'Rollback';
            """, cn);
        await using var rd = await cmd.ExecuteReaderAsync();
        while (await rd.ReadAsync()) result.Add($"{rd.GetString(0)}|{rd.GetString(1)}");
        return result;
    }

    public async Task<ObservableCollection<PrincipalChoice>> LoadPrincipalsAsync(ServerProfile server, string database,
        CancellationToken cancellationToken = default)
    {
        var result = new ObservableCollection<PrincipalChoice>();
        await using var cn = Connection(TargetConnection(server, database));
        await cn.OpenAsync(cancellationToken);
        await using var cmd = new SqlCommand("""
            SELECT dp.name,dp.type_desc,
              CONVERT(bit,CASE WHEN IS_SRVROLEMEMBER(N'sysadmin',SUSER_SNAME(dp.sid))=1
                OR IS_ROLEMEMBER(N'db_owner',dp.name)=1 OR dp.name=N'dbo' THEN 1 ELSE 0 END),
              CASE WHEN IS_SRVROLEMEMBER(N'sysadmin',SUSER_SNAME(dp.sid))=1 THEN N'sysadmin'
                   WHEN IS_ROLEMEMBER(N'db_owner',dp.name)=1 OR dp.name=N'dbo' THEN N'db_owner/owner' ELSE N'' END
            FROM sys.database_principals dp
            WHERE dp.type IN('S','U','G','E','X') AND dp.principal_id>4
              AND dp.name NOT IN(N'guest',N'INFORMATION_SCHEMA',N'sys') ORDER BY dp.name
            """, cn);
        await using var rd = await cmd.ExecuteReaderAsync(cancellationToken);
        while (await rd.ReadAsync(cancellationToken))
        {
            var protectedUser = rd.GetBoolean(2);
            result.Add(new()
            {
                Name = rd.GetString(0), Type = rd.GetString(1), IsProtected = protectedUser,
                IsExcluded = protectedUser, ProtectionReason = rd.GetString(3)
            });
        }
        return result;
    }

    public async Task<ObservableCollection<MaskPattern>> LoadPatternsAsync()
    {
        var result = new ObservableCollection<MaskPattern>();
        await using var cn = Connection(Context.PivotConnectionString); await cn.OpenAsync();
        await using var cmd = new SqlCommand("SELECT Pattern,DdmFunction,ViewMaskExpr,CASE Priority WHEN 100 THEN N'Alto' WHEN 300 THEN N'Bajo' ELSE N'Medio' END,IsActive FROM ofuscador.MaskPatterns ORDER BY Priority,Pattern", cn);
        await using var rd = await cmd.ExecuteReaderAsync();
        while (await rd.ReadAsync()) result.Add(new()
        {
            Pattern = rd.GetString(0), DdmFunction = rd.GetString(1), ViewMaskExpr = rd.IsDBNull(2) ? null : rd.GetString(2),
            Priority = rd.GetString(3), IsActive = rd.GetBoolean(4)
        });
        return result;
    }

    public async Task<ObservableCollection<MaskException>> LoadMaskExceptionsAsync()
    {
        var result = new ObservableCollection<MaskException>();
        await using var cn = Connection(Context.PivotConnectionString);
        await cn.OpenAsync();
        await using var cmd = new SqlCommand("""
            SELECT ExceptionId,ServerName,DatabaseName,SchemaName,TableName,ColumnName,
                   ActionName,IsActive,ISNULL(Notes,N'')
            FROM ofuscador.MaskExceptions
            ORDER BY ServerName,DatabaseName,SchemaName,TableName,ColumnName;
            """, cn);
        await using var rd = await cmd.ExecuteReaderAsync();
        while (await rd.ReadAsync()) result.Add(new()
        {
            ExceptionId = rd.GetInt32(0), ServerName = rd.GetString(1), DatabaseName = rd.GetString(2),
            SchemaName = rd.GetString(3), TableName = rd.GetString(4),
            ColumnName = rd.IsDBNull(5) ? null : rd.GetString(5), ActionName = rd.GetString(6),
            IsActive = rd.GetBoolean(7), Notes = rd.GetString(8)
        });
        return result;
    }

    public async Task SaveMaskExceptionsAsync(IEnumerable<MaskException> exceptions)
    {
        var rows = exceptions.Where(x => !string.IsNullOrWhiteSpace(x.ServerName)
            && !string.IsNullOrWhiteSpace(x.DatabaseName) && !string.IsNullOrWhiteSpace(x.TableName)).ToList();
        await using var cn = Connection(Context.PivotConnectionString);
        await cn.OpenAsync();
        await using var tx = await cn.BeginTransactionAsync();
        await new SqlCommand("DELETE ofuscador.MaskExceptions", cn, (SqlTransaction)tx).ExecuteNonQueryAsync();
        foreach (var item in rows)
        {
            await using var cmd = new SqlCommand("""
                INSERT ofuscador.MaskExceptions
                    (ServerName,DatabaseName,SchemaName,TableName,ColumnName,ActionName,IsActive,Notes)
                VALUES(@server,@database,@schema,@table,@column,@action,@active,@notes);
                """, cn, (SqlTransaction)tx);
            cmd.Parameters.AddRange([
                new("@server", item.ServerName), new("@database", item.DatabaseName),
                new("@schema", item.SchemaName), new("@table", item.TableName),
                new("@column", (object?)item.ColumnName ?? DBNull.Value), new("@action", item.ActionName),
                new("@active", item.IsActive), new("@notes", (object?)item.Notes ?? DBNull.Value)
            ]);
            await cmd.ExecuteNonQueryAsync();
        }
        await tx.CommitAsync();
    }

    public async Task<List<DatabaseObjectColumn>> LoadDatabaseObjectColumnsAsync(ServerProfile server, string database)
    {
        var result = new List<DatabaseObjectColumn>();
        await using var cn = Connection(TargetConnection(server, database));
        await cn.OpenAsync();
        await using var cmd = new SqlCommand("""
            SELECT s.name,t.name,c.name,TYPE_NAME(c.user_type_id),c.is_computed
            FROM sys.tables t
            JOIN sys.schemas s ON s.schema_id=t.schema_id
            JOIN sys.columns c ON c.object_id=t.object_id
            WHERE t.is_ms_shipped=0
              AND s.name NOT IN(N'sys',N'INFORMATION_SCHEMA',N'ofuscador',N'masked',N'app',N'log',N'logs',N'audit',N'auditoria',N'auditoría')
              AND t.name NOT IN(N'Masked_Audit',N'Masked_Patterns',N'Masked_Exceptions')
            ORDER BY s.name,t.name,c.column_id;
            """, cn);
        await using var rd = await cmd.ExecuteReaderAsync();
        while (await rd.ReadAsync()) result.Add(new(rd.GetString(0), rd.GetString(1), rd.GetString(2), rd.GetString(3), rd.GetBoolean(4)));
        return result;
    }

    public async Task<ObservableCollection<ProfileColumnRule>> LoadProfileColumnsAsync(ServerProfile server, string database)
    {
        var result = new ObservableCollection<ProfileColumnRule>();
        await using var cn = Connection(TargetConnection(server, database)); await cn.OpenAsync();
        await using var cmd = new SqlCommand("""
            SELECT s.name,t.name,c.name,TYPE_NAME(c.user_type_id)
            FROM sys.tables t JOIN sys.schemas s ON s.schema_id=t.schema_id
            JOIN sys.columns c ON c.object_id=t.object_id
            WHERE t.is_ms_shipped=0
              AND s.name NOT IN(N'sys',N'INFORMATION_SCHEMA',N'ofuscador',N'masked',N'app',N'log',N'logs',N'audit',N'auditoria',N'auditoría')
              AND t.name NOT IN(N'Masked_Audit',N'Masked_Patterns',N'Masked_Exceptions')
            ORDER BY s.name,t.name,c.column_id
            """, cn);
        await using var rd = await cmd.ExecuteReaderAsync();
        while (await rd.ReadAsync()) result.Add(new() { Schema=rd.GetString(0), Table=rd.GetString(1), Column=rd.GetString(2), DataType=rd.GetString(3) });
        return result;
    }

    public async Task SaveMaskProfileAsync(MaskProfile profile)
    {
        if (string.IsNullOrWhiteSpace(profile.ProfileName) || string.IsNullOrWhiteSpace(profile.TargetSchema))
            throw new InvalidOperationException("El perfil y el esquema son obligatorios.");
        await using var cn = Connection(Context.PivotConnectionString); await cn.OpenAsync();
        await using var tx = await cn.BeginTransactionAsync();
        await using var cmd = new SqlCommand("""
            DECLARE @id int = (SELECT ProfileId FROM ofuscador.MaskProfiles WHERE ProfileName=@n);
            IF @id IS NULL
            BEGIN
                INSERT ofuscador.MaskProfiles(ProfileName,ServerName,DatabaseName,TargetSchema,IsActive)
                VALUES(@n,@s,@d,@schema,@a);
                SET @id = CONVERT(int,SCOPE_IDENTITY());
            END
            ELSE
                UPDATE ofuscador.MaskProfiles SET ServerName=@s,DatabaseName=@d,TargetSchema=@schema,IsActive=@a,ModifiedAt=SYSUTCDATETIME() WHERE ProfileId=@id;
            SELECT @id;
            """, cn, (SqlTransaction)tx);
        cmd.Parameters.AddRange([new("@n",profile.ProfileName),new("@s",profile.ServerName),new("@d",profile.DatabaseName),new("@schema",profile.TargetSchema),new("@a",profile.IsActive)]);
        profile.ProfileId = Convert.ToInt32(await cmd.ExecuteScalarAsync());
        await ExecuteAsync(cn, (SqlTransaction)tx, "DELETE ofuscador.MaskProfileColumns WHERE ProfileId=@id; DELETE ofuscador.MaskProfileUsers WHERE ProfileId=@id", new SqlParameter("@id", profile.ProfileId));
        foreach (var r in profile.Rules.Where(x => !string.IsNullOrWhiteSpace(x.RulePattern) && x.RulePattern != "(predeterminado)"))
            await ExecuteAsync(cn, (SqlTransaction)tx, "INSERT ofuscador.MaskProfileColumns VALUES(@id,@s,@t,@c,@r)", new("@id",profile.ProfileId),new("@s",r.Schema),new("@t",r.Table),new("@c",r.Column),new("@r",r.RulePattern));
        foreach (var u in profile.Users.Where(x => !string.IsNullOrWhiteSpace(x)))
            await ExecuteAsync(cn, (SqlTransaction)tx, "INSERT ofuscador.MaskProfileUsers VALUES(@id,@u)", new("@id",profile.ProfileId),new("@u",u));
        await tx.CommitAsync();
    }

    private static async Task ExecuteAsync(SqlConnection cn, SqlTransaction tx, string sql, params SqlParameter[] parameters)
    {
        await using var cmd = new SqlCommand(sql, cn, tx); cmd.Parameters.AddRange(parameters); await cmd.ExecuteNonQueryAsync();
    }

    public async Task SavePatternsAsync(IEnumerable<MaskPattern> patterns)
    {
        await using var cn = Connection(Context.PivotConnectionString); await cn.OpenAsync();
        await using var tx = await cn.BeginTransactionAsync();
        await new SqlCommand("DELETE ofuscador.MaskPatterns", cn, (SqlTransaction)tx).ExecuteNonQueryAsync();
        foreach (var p in patterns.Where(x => !string.IsNullOrWhiteSpace(x.Pattern)))
        {
            await using var cmd = new SqlCommand("""
                INSERT ofuscador.MaskPatterns(Pattern,DdmFunction,ViewMaskExpr,Priority,IsActive) VALUES(@p,@d,@v,@o,@a)
                """, cn, (SqlTransaction)tx);
            cmd.Parameters.AddRange([new("@p",p.Pattern),new("@d",p.DdmFunction),new("@v",(object?)p.ViewMaskExpr??DBNull.Value),
                new("@o",PriorityRank(p.Priority)),new("@a",p.IsActive)]);
            await cmd.ExecuteNonQueryAsync();
        }
        await tx.CommitAsync();
    }

    public static int PriorityRank(string? priority) => priority switch
    {
        "Alto" => 100,
        "Bajo" => 300,
        _ => 200
    };

    public async Task<ObservableCollection<AuthorizedUser>> LoadUsersAsync()
    {
        var result = new ObservableCollection<AuthorizedUser>();
        await using var cn = Connection(Context.PivotConnectionString); await cn.OpenAsync();
        await using var cmd = new SqlCommand("SELECT Principal,PrincipalType,AppRole,IsActive,ISNULL(Notes,'') FROM ofuscador.AuthorizedUsers ORDER BY Principal",cn);
        await using var rd=await cmd.ExecuteReaderAsync();
        while(await rd.ReadAsync()) result.Add(new(){Principal=rd.GetString(0),PrincipalType=rd.GetString(1),Role=rd.GetString(2),IsActive=rd.GetBoolean(3),Notes=rd.GetString(4)});
        return result;
    }

    public async Task<List<PivotLoginOption>> LoadPivotLoginsAsync()
    {
        var result = new List<PivotLoginOption>();
        await using var cn = Connection(Context.PivotConnectionString);
        await cn.OpenAsync();
        await using var cmd = new SqlCommand("""
            SELECT sp.name,
              CASE sp.type WHEN 'S' THEN N'SQL_LOGIN' WHEN 'U' THEN N'WINDOWS_LOGIN'
                           WHEN 'G' THEN N'WINDOWS_GROUP' WHEN 'E' THEN N'EXTERNAL_LOGIN'
                           WHEN 'X' THEN N'EXTERNAL_GROUP' ELSE sp.type_desc END,
              CONVERT(bit,ISNULL(sp.is_disabled,0))
            FROM sys.server_principals sp
            WHERE sp.type IN('S','U','G','E','X') AND sp.name NOT LIKE N'##%'
            ORDER BY sp.name
            """, cn);
        await using var rd = await cmd.ExecuteReaderAsync();
        while (await rd.ReadAsync()) result.Add(new() { Login = rd.GetString(0), LoginType = rd.GetString(1), IsDisabled = rd.GetBoolean(2) });
        return result;
    }

    public async Task SaveUsersAsync(IEnumerable<AuthorizedUser> users)
    {
        await using var cn=Connection(Context.PivotConnectionString); await cn.OpenAsync();
        await using var tx=await cn.BeginTransactionAsync();
        await new SqlCommand("DELETE ofuscador.AuthorizedUsers",cn,(SqlTransaction)tx).ExecuteNonQueryAsync();
        foreach(var u in users.Where(x=>!string.IsNullOrWhiteSpace(x.Principal)))
        {
            await using var cmd=new SqlCommand("INSERT ofuscador.AuthorizedUsers(Principal,PrincipalType,AppRole,IsActive,Notes) VALUES(@p,@t,@r,@a,@n)",cn,(SqlTransaction)tx);
            cmd.Parameters.AddRange([new("@p",u.Principal),new("@t",u.PrincipalType),new("@r",u.Role),new("@a",u.IsActive),new("@n",u.Notes)]);
            await cmd.ExecuteNonQueryAsync();
        }
        await tx.CommitAsync();
    }

    public async Task<Guid> BeginExecutionAsync(string mode, IEnumerable<DatabaseTarget> targets)
    {
        var id=Guid.NewGuid();
        await ExecuteAsync(Context.PivotConnectionString,"INSERT ofuscador.Executions VALUES(@id,@m,N'Running',@p,SYSUTCDATETIME(),NULL,NULL)",
            new("@id",id),new("@m",mode),new("@p",Context.Principal));
        foreach(var t in targets) await ExecuteAsync(Context.PivotConnectionString,
            "INSERT ofuscador.ExecutionTargets VALUES(@id,@s,@d,N'Pending',NULL)",new("@id",id),new("@s",t.Server.Name),new("@d",t.Database));
        return id;
    }

    public Task UpdateTargetAsync(Guid id,DatabaseTarget target,string status,string detail)=>ExecuteAsync(Context.PivotConnectionString,
        "UPDATE ofuscador.ExecutionTargets SET Status=@x,Detail=@z WHERE ExecutionId=@id AND ServerName=@s AND DatabaseName=@d",
        new("@x",status),new("@z",detail),new("@id",id),new("@s",target.Server.Name),new("@d",target.Database));

    public Task FinishExecutionAsync(Guid id,string status,string summary)=>ExecuteAsync(Context.PivotConnectionString,
        "UPDATE ofuscador.Executions SET Status=@s,FinishedAt=SYSUTCDATETIME(),Summary=@x WHERE ExecutionId=@id",
        new("@s",status),new("@x",summary),new("@id",id));

    public async Task<DataTable> LoadAuditAsync()
    {
        var table=new DataTable();
        await using var cn=Connection(Context.PivotConnectionString); await cn.OpenAsync();
        await using var cmd=new SqlCommand("SELECT TOP(500) EventAt,Principal,FormName,ActionName,ServerName,DatabaseName,Success,Detail FROM ofuscador.Audit ORDER BY AuditId DESC",cn);
        await using var rd=await cmd.ExecuteReaderAsync(); table.Load(rd);
        LocalizeUtcColumns(table, "EventAt");
        return table;
    }

    public async Task<DataTable> LoadDeploymentsAsync()
    {
        var table=new DataTable();
        await using var cn=Connection(Context.PivotConnectionString); await cn.OpenAsync();
        await using var cmd=new SqlCommand("SELECT TOP(100) ExecutionId,Mode,Status,RequestedBy,StartedAt,FinishedAt FROM ofuscador.Executions WHERE Mode=N'Deploy' AND Status IN(N'Completed',N'Partial') ORDER BY StartedAt DESC",cn);
        await using var rd=await cmd.ExecuteReaderAsync(); table.Load(rd);
        LocalizeUtcColumns(table, "StartedAt", "FinishedAt");
        return table;
    }

    private static void LocalizeUtcColumns(DataTable table, params string[] columnNames)
    {
        foreach (DataRow row in table.Rows)
        foreach (var columnName in columnNames)
        {
            if (!table.Columns.Contains(columnName) || row[columnName] is not DateTime value) continue;
            row[columnName] = DateTime.SpecifyKind(value, DateTimeKind.Utc).ToLocalTime();
        }
    }

    public async Task<List<(string Server,string Database)>> LoadExecutionTargetsAsync(Guid id)
    {
        var result=new List<(string,string)>();
        await using var cn=Connection(Context.PivotConnectionString); await cn.OpenAsync();
        await using var cmd=new SqlCommand("SELECT ServerName,DatabaseName FROM ofuscador.ExecutionTargets WHERE ExecutionId=@id",cn);
        cmd.Parameters.AddWithValue("@id",id);
        await using var rd=await cmd.ExecuteReaderAsync();
        while(await rd.ReadAsync()) result.Add((rd.GetString(0),rd.GetString(1)));
        return result;
    }

    public static async Task ExecuteAsync(string cs, string sql, params SqlParameter[] parameters)
    {
        await using var cn = Connection(cs);
        await cn.OpenAsync();
        await using var cmd = new SqlCommand(sql, cn) { CommandTimeout = 180 };
        if (parameters.Length > 0) cmd.Parameters.AddRange(parameters);
        await cmd.ExecuteNonQueryAsync();
    }

    private static async Task ExecuteCancelableAsync(string cs, string sql,
        CancellationToken cancellationToken, params SqlParameter[] parameters)
    {
        await using var cn = Connection(cs);
        await cn.OpenAsync(cancellationToken);
        await using var cmd = new SqlCommand(sql, cn) { CommandTimeout = 180 };
        if (parameters.Length > 0) cmd.Parameters.AddRange(parameters);
        await cmd.ExecuteNonQueryAsync(cancellationToken);
    }

    public static async Task<object?> ScalarAsync(string cs, string sql, params SqlParameter[] parameters)
    {
        await using var cn = Connection(cs);
        await cn.OpenAsync();
        await using var cmd = new SqlCommand(sql, cn);
        if (parameters.Length > 0) cmd.Parameters.AddRange(parameters);
        return await cmd.ExecuteScalarAsync();
    }

    private static async Task<object?> ScalarCancelableAsync(string cs, string sql,
        CancellationToken cancellationToken, params SqlParameter[] parameters)
    {
        await using var cn = Connection(cs);
        await cn.OpenAsync(cancellationToken);
        await using var cmd = new SqlCommand(sql, cn);
        if (parameters.Length > 0) cmd.Parameters.AddRange(parameters);
        return await cmd.ExecuteScalarAsync(cancellationToken);
    }
}
