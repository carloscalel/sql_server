using System.Collections.ObjectModel;
using System.Windows.Input;
using DBAOrganizer.WPF.Models;
using DBAOrganizer.WPF.Services;

namespace DBAOrganizer.WPF.ViewModels
{
    public class RelayCommand : ICommand
    {
        private readonly Action<object?> _execute;
        private readonly Func<object?, bool>? _canExecute;

        public RelayCommand(Action<object?> execute, Func<object?, bool>? canExecute = null)
        {
            _execute = execute;
            _canExecute = canExecute;
        }

        public event EventHandler? CanExecuteChanged
        {
            add => CommandManager.RequerySuggested += value;
            remove => CommandManager.RequerySuggested -= value;
        }

        public bool CanExecute(object? parameter) => _canExecute == null || _canExecute(parameter);
        public void Execute(object? parameter) => _execute(parameter);
    }

    public class MainViewModel : TaskItem
    {
        private readonly JsonDataService _dataService;
        public ObservableCollection<TaskItem> Tasks { get; set; }

        private TaskItem? _selectedTask;
        public TaskItem? SelectedTask
        {
            get => _selectedTask;
            set { _selectedTask = value; OnPropertyChanged(); }
        }

        public ICommand AddCommand { get; }
        public ICommand DeleteCommand { get; }
        public ICommand SaveCommand { get; }
        public ICommand AdvanceCommand { get; }
        public ICommand RegressCommand { get; }

        public MainViewModel()
        {
            _dataService = new JsonDataService();
            Tasks = _dataService.LoadTasks();

            AddCommand = new RelayCommand(_ => AddTask());
            DeleteCommand = new RelayCommand(_ => DeleteTask(), _ => SelectedTask != null);
            SaveCommand = new RelayCommand(_ => SaveData());
            AdvanceCommand = new RelayCommand(_ => MoveStatus(1), _ => SelectedTask != null);
            RegressCommand = new RelayCommand(_ => MoveStatus(-1), _ => SelectedTask != null);
        }

        private void AddTask()
        {
            var newTask = new TaskItem
            {
                Ticket = $"INC-{new Random().Next(100000, 999999)}",
                Title = "Nueva tarea",
                Status = "Todo"
            };
            Tasks.Add(newTask);
            SelectedTask = newTask;
        }

        private void DeleteTask()
        {
            if (SelectedTask != null)
            {
                Tasks.Remove(SelectedTask);
                SelectedTask = null;
            }
        }

        private void SaveData()
        {
            _dataService.SaveTasks(Tasks);
        }

        private void MoveStatus(int direction)
        {
            if (SelectedTask == null) return;

            string[] states = { "Todo", "EnProceso", "Validacion" };
            int currentIndex = Array.IndexOf(states, SelectedTask.Status);

            int newIndex = currentIndex + direction;
            if (newIndex >= 0 && newIndex < states.Length)
            {
                SelectedTask.Status = states[newIndex];
                var currentSelected = SelectedTask;
                SelectedTask = null;
                SelectedTask = currentSelected;
            }
        }
    }
}