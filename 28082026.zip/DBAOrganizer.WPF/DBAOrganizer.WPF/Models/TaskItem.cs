using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace DBAOrganizer.WPF.Models
{
    public class TaskItem : INotifyPropertyChanged
    {
        private string _id = Guid.NewGuid().ToString();
        private string _ticket = string.Empty;
        private string _title = string.Empty;
        private string _status = "Todo"; // Todo, EnProceso, Validacion

        public string Id
        {
            get => _id;
            set { _id = value; OnPropertyChanged(); }
        }

        public string Ticket
        {
            get => _ticket;
            set { _ticket = value; OnPropertyChanged(); }
        }

        public string Title
        {
            get => _title;
            set { _title = value; OnPropertyChanged(); }
        }

        public string Status
        {
            get => _status;
            set { _status = value; OnPropertyChanged(); }
        }

        public event PropertyChangedEventHandler? PropertyChanged;
        protected void OnPropertyChanged([CallerMemberName] string? propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}