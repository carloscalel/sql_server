
/* =========================================
  Reversión global (v2 con sinónimos)
  - Elimina todos los SINÓNIMOS en app
  - Elimina todas las vistas y triggers en masked
  - Quita todas las máscaras DDM
  - Restaura permisos básicos
=========================================*/
SET NOCOUNT ON; SET XACT_ABORT ON;

-- A) Eliminar SINÓNIMOS en app
IF OBJECT_ID('tempdb..#SN','U') IS NOT NULL DROP TABLE #SN;
SELECT ROW_NUMBER() OVER(ORDER BY o.name) AS Idx,
       QUOTENAME(s.name)+'.'+QUOTENAME(o.name) AS SynFull
INTO #SN
FROM sys.objects o
JOIN sys.schemas s ON s.schema_id = o.schema_id
WHERE s.name = N'app' AND o.[type] = 'SN';

DECLARE @idx INT=1, @imax INT=(SELECT MAX(Idx) FROM #SN), @syn NVARCHAR(400);
WHILE @idx<=@imax
BEGIN
  SELECT @syn=SynFull FROM #SN WHERE Idx=@idx;
  BEGIN TRY EXEC(N'DROP SYNONYM '+@syn+';'); END TRY BEGIN CATCH END CATCH;
  SET @idx+=1;
END

-- B) Eliminar triggers y vistas en masked
IF OBJECT_ID('tempdb..#V') IS NOT NULL DROP TABLE #V;
SELECT ROW_NUMBER() OVER(ORDER BY v.name) AS Idx,
       QUOTENAME(s.name)+'.'+QUOTENAME(v.name) AS ViewFull
INTO #V
FROM sys.views v
JOIN sys.schemas s ON s.schema_id = v.schema_id
WHERE s.name = N'masked';

DECLARE @vf NVARCHAR(400), @sql NVARCHAR(MAX), @j INT, @jmax INT, @drop NVARCHAR(400);

SET @idx=1; SET @imax=(SELECT MAX(Idx) FROM #V);
WHILE @idx<=@imax
BEGIN
  SELECT @vf=ViewFull FROM #V WHERE Idx=@idx;

  IF OBJECT_ID(@vf,'V') IS NOT NULL
  BEGIN
    -- Drop triggers
    IF OBJECT_ID('tempdb..#Tr') IS NOT NULL DROP TABLE #Tr;
    SELECT ROW_NUMBER() OVER(ORDER BY tr.name) AS Id2,
           QUOTENAME(s2.name)+'.'+QUOTENAME(tr.name) AS DropStmt
    INTO #Tr
    FROM sys.triggers tr
    JOIN sys.objects  o  ON o.object_id = tr.parent_id AND o.type='V'
    JOIN sys.schemas  s2 ON s2.schema_id = o.schema_id
    WHERE QUOTENAME(s2.name)+'.'+QUOTENAME(o.name)=@vf;

    SET @j=1; SET @jmax=(SELECT MAX(Id2) FROM #Tr);
    WHILE @j<=@jmax
    BEGIN
      SELECT @drop='DROP TRIGGER '+DropStmt FROM #Tr WHERE Id2=@j;
      BEGIN TRY EXEC(@drop); END TRY BEGIN CATCH END CATCH;
      SET @j+=1;
    END

    BEGIN TRY EXEC(N'DROP VIEW '+@vf+';'); END TRY BEGIN CATCH END CATCH;
  END

  SET @idx+=1;
END

-- C) Quitar TODAS las máscaras DDM
IF OBJECT_ID('tempdb..#MC') IS NOT NULL DROP TABLE #MC;
SELECT ROW_NUMBER() OVER(ORDER BY o.name, mc.column_id) AS Idx,
       QUOTENAME(s.name)+'.'+QUOTENAME(o.name) AS Tbl,
       QUOTENAME(c.name) AS Col
INTO #MC
FROM sys.masked_columns mc
JOIN sys.objects o ON o.object_id=mc.object_id AND o.type='U' AND o.is_ms_shipped=0
JOIN sys.schemas s ON s.schema_id=o.schema_id
JOIN sys.columns c ON c.object_id=mc.object_id AND c.column_id=mc.column_id;

DECLARE @m INT=1, @mmax INT=(SELECT MAX(Idx) FROM #MC), @tbl NVARCHAR(300), @col NVARCHAR(300);
WHILE @m<=@mmax
BEGIN
  SELECT @tbl=Tbl, @col=Col FROM #MC WHERE Idx=@m;
  BEGIN TRY
    SET @sql = N'ALTER TABLE '+@tbl+N' ALTER COLUMN '+@col+N' DROP MASKED;';
    EXEC sp_executesql @sql;
  END TRY BEGIN CATCH END CATCH;
  SET @m+=1;
END

-- D) Revertir endurecimiento de dbo para PUBLIC
BEGIN TRY REVOKE VIEW DEFINITION ON SCHEMA::dbo TO PUBLIC; END TRY BEGIN CATCH END CATCH;
BEGIN TRY REVOKE SELECT          ON SCHEMA::dbo TO PUBLIC; END TRY BEGIN CATCH END CATCH;

-- E) (Opcional) devolver DEFAULT_SCHEMA a dbo para usuarios que estaban en app/masked
-- ALTER USER [tu_usuario] WITH DEFAULT_SCHEMA = dbo;

-- F) (Opcional) revocar GRANT sobre app/masked al rol lector
-- REVOKE SELECT ON SCHEMA::app    TO [rol_app_lectura];
-- REVOKE SELECT ON SCHEMA::masked TO [rol_app_lectura];

-- (Opcional) Drop esquemas/roles si ya no se usan
-- DROP SCHEMA [app];    -- solo si está vacío
-- DROP SCHEMA [masked]; -- solo si está vacío
-- DROP ROLE [rol_app_lectura];
-- DROP ROLE [rol_admin_datos];
