
/* =========================================
  Asignación rápida de permisos y default_schema (v2 con sinónimos)
  - Lectores: DEFAULT_SCHEMA = app (sinónimos -> vistas en masked)
  - Escritores (ETL/Admin): permisos DML en dbo
=========================================*/

/* Lectores (ven enmascarado a través de SINÓNIMOS) */
-- CREATE USER [usuario_app] FOR LOGIN [usuario_app];
EXEC sp_addrolemember 'rol_app_lectura', 'usuario_app';
ALTER USER [usuario_app] WITH DEFAULT_SCHEMA = app;

/* Escritores (DML directo tabla base) */
-- CREATE USER [usuario_etl] FOR LOGIN [usuario_etl];
EXEC sp_addrolemember 'rol_admin_datos', 'usuario_etl';
GRANT SELECT, INSERT, UPDATE, DELETE ON SCHEMA::dbo TO [rol_admin_datos];

/* Variante: escritores usando la vista (DML redirigido por triggers) */
-- GRANT SELECT, INSERT, UPDATE, DELETE ON app.<TU_TABLA> TO [rol_admin_datos]; -- apunta a masked.<TU_TABLA>
