
/* =========================================
  sp_Masked_CreateViewWithDml
  - Crea/actualiza vista en masked.<Tabla>
  - Aplica enmascarado por nombre (dbo.Masked_Patterns)
  - Crea triggers INSTEAD OF (INSERT/UPDATE/DELETE) que redirigen a dbo.<Tabla>
  Requiere PK en la tabla base.
  Compatibilidad: SQL Server 2016+
=========================================*/
GO
CREATE OR ALTER PROCEDURE dbo.sp_Masked_CreateViewWithDml
  @BaseSchema   SYSNAME = N'dbo',
  @TableName    SYSNAME,              -- nombre de la tabla base
  @MaskedSchema SYSNAME = N'masked'
AS
BEGIN
  SET NOCOUNT ON; SET XACT_ABORT ON;

  DECLARE @BaseFull NVARCHAR(300) = QUOTENAME(@BaseSchema)+'.'+QUOTENAME(@TableName);
  DECLARE @ViewFull NVARCHAR(300) = QUOTENAME(@MaskedSchema)+'.'+QUOTENAME(@TableName);

  IF OBJECT_ID(@BaseFull,'U') IS NULL
    THROW 50000, 'Tabla base no existe.', 1;

  /* PK */
  DECLARE @PK TABLE(Col SYSNAME PRIMARY KEY);
  INSERT INTO @PK(Col)
  SELECT c.name
  FROM sys.key_constraints kc
  JOIN sys.index_columns ic ON ic.object_id = kc.parent_object_id AND ic.index_id = kc.unique_index_id
  JOIN sys.columns c       ON c.object_id   = kc.parent_object_id AND c.column_id = ic.column_id
  WHERE kc.[type]='PK' AND kc.parent_object_id = OBJECT_ID(@BaseFull)
  ORDER BY ic.key_ordinal;

  IF NOT EXISTS (SELECT 1 FROM @PK)
    THROW 50001, 'La tabla requiere PK para triggers de UPDATE/DELETE.', 1;

  /* SELECT list con enmascarado por nombre */
  DECLARE @SelectList NVARCHAR(MAX) = N'';
  SELECT @SelectList = STRING_AGG(
    CASE 
      WHEN c.is_computed = 1 THEN QUOTENAME(c.name) + ' AS ' + QUOTENAME(c.name)
      ELSE ISNULL((
          SELECT TOP(1) REPLACE(p.ViewMaskExpr,'{col}',QUOTENAME(c.name))
          FROM dbo.Masked_Patterns p
          WHERE c.name LIKE p.Pattern
          ORDER BY p.Pattern
      ), QUOTENAME(c.name))
    END, ','+CHAR(13))
  FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(@BaseFull);

  IF @SelectList IS NULL OR LEN(@SelectList)=0
    SELECT @SelectList = STRING_AGG(QUOTENAME(name),','+CHAR(13))
    FROM sys.columns WHERE object_id = OBJECT_ID(@BaseFull);

  /* Crear/alterar vista */
  DECLARE @sql NVARCHAR(MAX) =
    N'CREATE OR ALTER VIEW '+@ViewFull+N' AS
      SELECT '+@SelectList+'
      FROM '+@BaseFull+';';
  EXEC sp_executesql @sql;

  INSERT INTO dbo.Masked_Audit VALUES (DEFAULT,'VIEW',@MaskedSchema,@TableName,NULL,'CREATE/ALTER','Vista enmascarada con DML');

  /* Columnas updatables (sin computed/identity/rowguid) */
  DECLARE @Updatable TABLE(Col SYSNAME PRIMARY KEY);
  INSERT INTO @Updatable(Col)
  SELECT c.name
  FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(@BaseFull)
    AND c.is_computed = 0
    AND c.is_identity = 0
    AND c.is_rowguidcol = 0;

  DECLARE @InsertCols TABLE(Col SYSNAME PRIMARY KEY);
  INSERT INTO @InsertCols SELECT Col FROM @Updatable;

  /* Cláusulas para triggers */
  DECLARE @PKJoin NVARCHAR(MAX) = (
    SELECT STRING_AGG('B.'+QUOTENAME(Col)+'=I.'+QUOTENAME(Col),' AND ') FROM @PK
  );
  DECLARE @PKJoinVI NVARCHAR(MAX) = REPLACE(@PKJoin,'B.','V.');

  DECLARE @InsertColList NVARCHAR(MAX) = (SELECT STRING_AGG(QUOTENAME(Col),',') FROM @InsertCols);
  DECLARE @InsertSelList NVARCHAR(MAX) = (SELECT STRING_AGG('I.'+QUOTENAME(Col),',') FROM @InsertCols);

  DECLARE @UpdateSet NVARCHAR(MAX) = (
    SELECT STRING_AGG('B.'+QUOTENAME(Col)+'=I.'+QUOTENAME(Col),',')
    FROM @Updatable WHERE Col NOT IN (SELECT Col FROM @PK)
  );

  /* Triggers INSTEAD OF */
  -- INSERT
  SET @sql = N'CREATE OR ALTER TRIGGER '+@ViewFull+'_IOI ON '+@ViewFull+'
  INSTEAD OF INSERT
  AS
  BEGIN
    SET NOCOUNT ON;
    INSERT INTO '+@BaseFull+' ('+@InsertColList+')
    SELECT '+@InsertSelList+' FROM inserted I;

    SELECT V.* FROM '+@ViewFull+' V
    JOIN inserted I ON '+@PKJoinVI+';
  END';
  EXEC sp_executesql @sql;
  INSERT INTO dbo.Masked_Audit VALUES (DEFAULT,'TRIGGER',@MaskedSchema,@TableName,NULL,'CREATE/ALTER','INSTEAD OF INSERT');

  -- UPDATE
  SET @sql = N'CREATE OR ALTER TRIGGER '+@ViewFull+'_IOU ON '+@ViewFull+'
  INSTEAD OF UPDATE
  AS
  BEGIN
    SET NOCOUNT ON;
    UPDATE B
       SET '+@UpdateSet+'
    FROM '+@BaseFull+' B
    JOIN inserted I ON '+@PKJoin+';

    SELECT V.* FROM '+@ViewFull+' V
    JOIN inserted I ON '+@PKJoinVI+';
  END';
  EXEC sp_executesql @sql;
  INSERT INTO dbo.Masked_Audit VALUES (DEFAULT,'TRIGGER',@MaskedSchema,@TableName,NULL,'CREATE/ALTER','INSTEAD OF UPDATE');

  -- DELETE
  SET @sql = N'CREATE OR ALTER TRIGGER '+@ViewFull+'_IOD ON '+@ViewFull+'
  INSTEAD OF DELETE
  AS
  BEGIN
    SET NOCOUNT ON;
    DELETE B
    FROM '+@BaseFull+' B
    JOIN deleted D ON '+REPLACE(@PKJoin,'I.','D.')+';
  END';
  EXEC sp_executesql @sql;
  INSERT INTO dbo.Masked_Audit VALUES (DEFAULT,'TRIGGER',@MaskedSchema,@TableName,NULL,'CREATE/ALTER','INSTEAD OF DELETE');

  -- Permisos de lectura sobre la vista
  BEGIN TRY
    EXEC('GRANT SELECT ON '+@ViewFull+' TO [rol_app_lectura];');
  END TRY BEGIN CATCH END CATCH;
END
GO
