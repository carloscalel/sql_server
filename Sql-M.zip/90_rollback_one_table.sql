
/* =========================================
  Revertir UNA tabla (v2 con sinónimos)
  - Elimina sinónimo app.<Tabla>
  - Elimina triggers y vista en masked.<Tabla>
  - Quita DDM en dbo.<Tabla>
=========================================*/
DECLARE @BaseSchema SYSNAME = N'dbo';
DECLARE @MaskedSchema SYSNAME = N'masked';
DECLARE @SynSchema  SYSNAME = N'app';
DECLARE @TableName  SYSNAME = N'Clientes';  -- << CAMBIA

DECLARE @ViewFull NVARCHAR(300) = QUOTENAME(@MaskedSchema)+'.'+QUOTENAME(@TableName);
DECLARE @SynFull  NVARCHAR(300) = QUOTENAME(@SynSchema)+'.'+QUOTENAME(@TableName);
DECLARE @BaseFull NVARCHAR(300) = QUOTENAME(@BaseSchema)+'.'+QUOTENAME(@TableName);
DECLARE @sql NVARCHAR(MAX);

-- Drop sinónimo
IF OBJECT_ID(@SynFull,'SN') IS NOT NULL
BEGIN TRY
  EXEC(N'DROP SYNONYM '+@SynFull+';');
END TRY BEGIN CATCH END CATCH;

-- Drop triggers sobre vista y la vista
IF OBJECT_ID(@ViewFull,'V') IS NOT NULL
BEGIN
  DECLARE @drops TABLE(Id INT IDENTITY, Stmt NVARCHAR(4000));
  INSERT INTO @drops(Stmt)
  SELECT 'DROP TRIGGER '+QUOTENAME(s2.name)+'.'+QUOTENAME(tr.name)
  FROM sys.triggers tr
  JOIN sys.objects  o  ON o.object_id = tr.parent_id AND o.type='V'
  JOIN sys.schemas  s2 ON s2.schema_id = o.schema_id
  WHERE QUOTENAME(s2.name)+'.'+QUOTENAME(o.name)=@ViewFull;

  DECLARE @i INT=1, @imax INT=(SELECT MAX(Id) FROM @drops);
  WHILE @i<=@imax
  BEGIN
    SELECT @sql=Stmt FROM @drops WHERE Id=@i;
    BEGIN TRY EXEC(@sql); END TRY BEGIN CATCH END CATCH;
    SET @i+=1;
  END

  BEGIN TRY EXEC(N'DROP VIEW '+@ViewFull+';'); END TRY BEGIN CATCH END CATCH;
END

-- Quitar DDM de la tabla
IF OBJECT_ID('tempdb..#mc') IS NOT NULL DROP TABLE #mc;
SELECT ROW_NUMBER() OVER(ORDER BY mc.column_id) AS Idx, QUOTENAME(c.name) AS Col
INTO #mc
FROM sys.masked_columns mc
JOIN sys.columns c ON c.object_id=mc.object_id AND c.column_id=mc.column_id
WHERE mc.object_id = OBJECT_ID(@BaseFull);

DECLARE @k INT=1, @kmax INT=(SELECT MAX(Idx) FROM #mc), @col SYSNAME;
WHILE @k<=@kmax
BEGIN
  SELECT @col=Col FROM #mc WHERE Idx=@k;
  BEGIN TRY
    SET @sql = N'ALTER TABLE '+@BaseFull+N' ALTER COLUMN '+@col+N' DROP MASKED;';
    EXEC sp_executesql @sql;
  END TRY BEGIN CATCH END CATCH;
  SET @k+=1;
END

-- (Opcional) devolver lectura directa al rol lector
-- GRANT SELECT ON dbo.<TU_TABLA> TO [rol_app_lectura];
