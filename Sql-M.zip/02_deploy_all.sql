
/* =========================================
  Despliegue masivo (v2 con SINÓNIMOS en esquema app)
  - Tablas SIN columnas calculadas -> DDM por nombre (dbo.Masked_Patterns)
  - Tablas CON columnas calculadas -> vista en masked + triggers DML
  - Crea/actualiza SINÓNIMO app.<Tabla> -> masked.<Tabla>
  Compatibilidad: SQL Server 2016+
=========================================*/
SET NOCOUNT ON; SET XACT_ABORT ON;

DECLARE @ApplyDDM BIT = 1;      -- 1 para aplicar DDM a tablas simples
DECLARE @CreateViews BIT = 1;   -- 1 para crear vistas+triggers en complejas
DECLARE @sch SYSNAME, @tbl SYSNAME, @has BIT, @sql NVARCHAR(MAX);

IF OBJECT_ID('tempdb..#Tablas') IS NOT NULL DROP TABLE #Tablas;
CREATE TABLE #Tablas(Id INT IDENTITY(1,1) PRIMARY KEY, Sch SYSNAME, Tbl SYSNAME, HasComputed BIT);

INSERT INTO #Tablas(Sch,Tbl,HasComputed)
SELECT s.name, t.name,
       CASE WHEN EXISTS(SELECT 1 FROM sys.computed_columns cc WHERE cc.object_id=t.object_id) THEN 1 ELSE 0 END
FROM sys.tables t
JOIN sys.schemas s ON s.schema_id=t.schema_id
WHERE t.is_ms_shipped=0;

DECLARE @i INT=1, @imax INT=(SELECT MAX(Id) FROM #Tablas);
WHILE @i <= @imax
BEGIN
  SELECT @sch=Sch, @tbl=Tbl, @has=HasComputed FROM #Tablas WHERE Id=@i;

  IF (@has = 0 AND @ApplyDDM = 1)
  BEGIN
    -- Aplicar DDM por nombre a columnas sin computed
    IF OBJECT_ID('tempdb..#Cols') IS NOT NULL DROP TABLE #Cols;
    CREATE TABLE #Cols(Id INT IDENTITY(1,1), Col SYSNAME, Mask SYSNAME);

    INSERT INTO #Cols(Col,Mask)
    SELECT c.name, p.DdmFunction
    FROM sys.columns c
    JOIN dbo.Masked_Patterns p ON c.name LIKE p.Pattern
    WHERE c.object_id = OBJECT_ID(QUOTENAME(@sch)+'.'+QUOTENAME(@tbl))
      AND c.is_computed = 0
      AND NOT EXISTS (SELECT 1 FROM sys.masked_columns mc WHERE mc.object_id=c.object_id AND mc.column_id=c.column_id);

    DECLARE @j INT=1, @jmax INT=(SELECT MAX(Id) FROM #Cols);
    WHILE @j <= @jmax
    BEGIN
      DECLARE @col SYSNAME, @mf SYSNAME;
      SELECT @col=Col, @mf=Mask FROM #Cols WHERE Id=@j;

      BEGIN TRY
        SET @sql = N'ALTER TABLE '+QUOTENAME(@sch)+'.'+QUOTENAME(@tbl)+
                   N' ALTER COLUMN '+QUOTENAME(@col)+
                   N' ADD MASKED WITH (FUNCTION = '+QUOTENAME(@mf,'''')+N');';
        EXEC sp_executesql @sql;

        INSERT INTO dbo.Masked_Audit VALUES (DEFAULT,'DDM',@sch,@tbl,@col,'ADD MASKED',@mf);
      END TRY
      BEGIN CATCH
        INSERT INTO dbo.Masked_Audit VALUES (DEFAULT,'ERROR',@sch,@tbl,@col,'DDM',ERROR_MESSAGE());
      END CATCH;

      SET @j += 1;
    END
  END
  ELSE IF (@has = 1 AND @CreateViews = 1)
  BEGIN
    BEGIN TRY
      EXEC dbo.sp_Masked_CreateViewWithDml @BaseSchema=N'dbo', @TableName=@tbl, @MaskedSchema=N'masked';
      -- Crear/actualizar SINÓNIMO en esquema app, apuntando a la vista en masked
      IF OBJECT_ID(QUOTENAME('app') + '.' + QUOTENAME(@tbl), 'SN') IS NOT NULL
      BEGIN
        SET @sql = N'DROP SYNONYM ' + QUOTENAME('app') + '.' + QUOTENAME(@tbl) + ';';
        EXEC sp_executesql @sql;
      END;
      SET @sql = N'CREATE SYNONYM ' + QUOTENAME('app') + '.' + QUOTENAME(@tbl) +
                 N' FOR ' + QUOTENAME('masked') + '.' + QUOTENAME(@tbl) + N';';
      EXEC sp_executesql @sql;
      INSERT INTO dbo.Masked_Audit VALUES (DEFAULT,'SYNONYM','app',@tbl,NULL,'CREATE','app.'+@tbl+' -> masked.'+@tbl);
    END TRY
    BEGIN CATCH
      INSERT INTO dbo.Masked_Audit VALUES (DEFAULT,'ERROR',@sch,@tbl,NULL,'VIEW/TRIGGERS/SYNONYM',ERROR_MESSAGE());
    END CATCH
  END

  SET @i += 1;
END
