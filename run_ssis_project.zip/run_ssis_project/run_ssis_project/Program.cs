﻿using Microsoft.SqlServer.Management.IntegrationServices;
using System;
using System.Data.SqlClient;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Net;

namespace ExportarSSIS
{
    //C:\Windows\assembly\GAC_MSIL\Microsoft.SqlServer.Smo\13.0.0.0__89845dcd8080cc91
    class Program
    {
        static bool descomprimir = false;

        static void Main(string[] args)
        {
            Console.Write("Ingresa el nombre del servidor SQL: ");
            string targetServerName = Console.ReadLine()?.Trim();

            Console.Write("Ingresa la ruta base donde se exportará (ej. C:\\ExportadosSSIS): ");
            string baseOutputDir = Console.ReadLine()?.Trim();

            if (string.IsNullOrEmpty(targetServerName) || string.IsNullOrEmpty(baseOutputDir))
            {
                Console.WriteLine("Error: Parámetros requeridos.");
                return;
            }

            Console.WriteLine("\n¿Qué deseas exportar?");
            Console.WriteLine("1. Un solo proyecto");
            Console.WriteLine("2. Todos los proyectos de una carpeta");
            Console.WriteLine("3. Todo el catálogo SSISDB (ISPAC)");
            Console.WriteLine("4. Solo archivos .dtsx (de todo el catálogo)");
            Console.Write("Opción (1/2/3/4): ");
            string opcion = Console.ReadLine()?.Trim();

            // Solo preguntar por descomprimir si NO es la opción 4
            if (opcion != "4")
            {
                Console.Write("¿Deseas descomprimir los archivos .ispac exportados? (s/n): ");
                descomprimir = Console.ReadLine()?.Trim().ToLower() == "s";
            }

            try
            {
                string sqlConnectionString = $"Data Source={targetServerName};Initial Catalog=master;Integrated Security=SSPI;";
                using (SqlConnection sqlConnection = new SqlConnection(sqlConnectionString))
                {
                    IntegrationServices integrationServices = new IntegrationServices(sqlConnection);
                    Catalog catalog = integrationServices.Catalogs["SSISDB"];

                    if (opcion == "1")
                    {
                        Console.Write("Nombre de la carpeta SSISDB: ");
                        string folderName = Console.ReadLine()?.Trim();

                        Console.Write("Nombre del proyecto: ");
                        string projectName = Console.ReadLine()?.Trim();

                        ProjectInfo project = catalog.Folders[folderName].Projects[projectName];
                        ExportarProyecto(project, baseOutputDir, folderName);
                    }
                    else if (opcion == "2")
                    {
                        Console.Write("Nombre de la carpeta SSISDB: ");
                        string folderName = Console.ReadLine()?.Trim();

                        CatalogFolder folder = catalog.Folders[folderName];
                        foreach (ProjectInfo project in folder.Projects)
                        {
                            ExportarProyecto(project, baseOutputDir, folderName);
                        }
                    }
                    else if (opcion == "3")
                    {
                        foreach (CatalogFolder folder in catalog.Folders)
                        {
                            foreach (ProjectInfo project in folder.Projects)
                            {
                                ExportarProyecto(project, baseOutputDir, folder.Name);
                            }
                        }
                    }
                    else if (opcion == "4")
                    {
                        foreach (CatalogFolder folder in catalog.Folders)
                        {
                            foreach (ProjectInfo project in folder.Projects)
                            {
                                ExportarSoloDtsx(project, baseOutputDir, folder.Name);
                            }
                        }
                    }
                    else
                    {
                        Console.WriteLine("Opción no válida.");
                    }
                }

                Console.WriteLine("\nProceso finalizado.");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex.Message);
            }

            Console.WriteLine("Presiona una tecla para salir...");
            Console.ReadKey();
        }


        static void ExportarProyecto(ProjectInfo project, string baseOutputDir, string folderName)
        {
            string outputDir = Path.Combine(baseOutputDir, "SSISDB", folderName, project.Name);
            Directory.CreateDirectory(outputDir);

            string outputPath = Path.Combine(outputDir, $"{project.Name}.ispac");
            File.WriteAllBytes(outputPath, project.GetProjectBytes());

            Console.WriteLine($"Proyecto exportado: {outputPath}");

            if (descomprimir)
            {
                string extractPath = Path.Combine(outputDir, "Descomprimido");

                if (Directory.Exists(extractPath))
                    Directory.Delete(extractPath, true);

                ZipFile.ExtractToDirectory(outputPath, extractPath);
                Console.WriteLine($"Descomprimido en: {extractPath}");

                // Renombrar archivos con nombres codificados
                var archivos = Directory.GetFiles(extractPath, "*", SearchOption.AllDirectories);
                foreach (var archivo in archivos)
                {
                    string decodedName = WebUtility.UrlDecode(Path.GetFileName(archivo));
                    string directorio = Path.GetDirectoryName(archivo);
                    if (directorio == null)
                        continue;

                    string nuevoPath = Path.Combine(directorio, decodedName);

                    if (archivo != nuevoPath)
                    {
                        if (File.Exists(nuevoPath))
                            File.Delete(nuevoPath);

                        File.Move(archivo, nuevoPath);
                    }
                }

                // Renombrar carpetas con nombres codificados (de más profundo a más superficial)
                var carpetas = Directory.GetDirectories(extractPath, "*", SearchOption.AllDirectories)
                                        .OrderByDescending(p => p.Length).ToList();

                foreach (var carpeta in carpetas)
                {
                    string decodedName = WebUtility.UrlDecode(Path.GetFileName(carpeta));
                    string directorioPadre = Path.GetDirectoryName(carpeta);
                    if (directorioPadre == null)
                        continue;

                    string nuevoPath = Path.Combine(directorioPadre, decodedName);

                    if (carpeta != nuevoPath)
                    {
                        if (Directory.Exists(nuevoPath))
                            Directory.Delete(nuevoPath, true);

                        Directory.Move(carpeta, nuevoPath);
                    }
                }
            }
        }
        static void ExportarSoloDtsx(ProjectInfo project, string baseOutputDir, string folderName)
        {
            string carpetaRaizDestino = Path.Combine(baseOutputDir, "SoloDTXS", folderName, project.Name);
            string tempPath = Path.Combine(Path.GetTempPath(), Guid.NewGuid().ToString());
            Directory.CreateDirectory(tempPath);

            try
            {
                string tempIspac = Path.Combine(tempPath, $"{project.Name}.ispac");
                File.WriteAllBytes(tempIspac, project.GetProjectBytes());

                string extractPath = Path.Combine(tempPath, "Descomprimido");
                ZipFile.ExtractToDirectory(tempIspac, extractPath);

                // Renombrar carpetas con nombres codificados
                var carpetas = Directory.GetDirectories(extractPath, "*", SearchOption.AllDirectories)
                                        .OrderByDescending(p => p.Length)
                                        .ToList();

                foreach (var carpeta in carpetas)
                {
                    string decodedName = WebUtility.UrlDecode(Path.GetFileName(carpeta));
                    string directorioPadre = Path.GetDirectoryName(carpeta);
                    if (directorioPadre == null) continue;

                    string nuevoPath = Path.Combine(directorioPadre, decodedName);
                    if (carpeta != nuevoPath)
                    {
                        if (Directory.Exists(nuevoPath))
                            Directory.Delete(nuevoPath, true);

                        Directory.Move(carpeta, nuevoPath);
                    }
                }

                // Renombrar archivos con nombres codificados
                var archivos = Directory.GetFiles(extractPath, "*", SearchOption.AllDirectories);
                foreach (var archivo in archivos)
                {
                    string decodedName = WebUtility.UrlDecode(Path.GetFileName(archivo));
                    string directorio = Path.GetDirectoryName(archivo);
                    if (directorio == null) continue;

                    string nuevoPath = Path.Combine(directorio, decodedName);
                    if (archivo != nuevoPath)
                    {
                        if (File.Exists(nuevoPath))
                            File.Delete(nuevoPath);

                        File.Move(archivo, nuevoPath);
                    }
                }

                // Copiar solo archivos .dtsx manteniendo estructura relativa
                var archivosDtsx = Directory.GetFiles(extractPath, "*.dtsx", SearchOption.AllDirectories);
                foreach (var archivo in archivosDtsx)
                {
                    string rutaRelativa = GetRelativePathCompat(extractPath, archivo);
                    string destinoFinal = Path.Combine(carpetaRaizDestino, rutaRelativa);

                    var directorioDestino = Path.GetDirectoryName(destinoFinal);
                    if (directorioDestino == null)
                    {
                        throw new InvalidOperationException("No se pudo determinar el directorio del archivo de destino.");
                    }
                    Directory.CreateDirectory(directorioDestino);

                    File.Copy(archivo, destinoFinal, true);

                    Console.WriteLine($"Archivo exportado: {destinoFinal}");
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error exportando {project.Name}: {ex.Message}");
            }
            finally
            {
                if (Directory.Exists(tempPath))
                    Directory.Delete(tempPath, true);
            }
        }
        static string GetRelativePathCompat(string basePath, string fullPath)
        {
            Uri baseUri = new Uri(AppendDirectorySeparator(basePath));
            Uri fullUri = new Uri(fullPath);

            return Uri.UnescapeDataString(baseUri.MakeRelativeUri(fullUri).ToString().Replace('/', Path.DirectorySeparatorChar));
        }

        static string AppendDirectorySeparator(string path)
        {
            if (!path.EndsWith(Path.DirectorySeparatorChar.ToString()))
                return path + Path.DirectorySeparatorChar;
            return path;
        }
    }
}
