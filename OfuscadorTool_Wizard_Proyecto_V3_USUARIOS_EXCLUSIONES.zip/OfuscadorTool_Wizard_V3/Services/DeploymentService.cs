using Microsoft.Data.SqlClient;
using OfuscadorTool.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfuscadorTool.Services
{
    public class DeploymentService
    {
        private readonly SqlScriptService _scriptService = new SqlScriptService();

        public async Task TestConnectionAsync(ServerConnection server)
        {
            using var connection = new SqlConnection(server.GetConnectionString("master"));
            await connection.OpenAsync();
        }

        public async Task<List<string>> GetDatabasesAsync(ServerConnection server)
        {
            var result = new List<string>();

            using var connection = new SqlConnection(server.GetConnectionString("master"));
            await connection.OpenAsync();

            const string sql = @"
SELECT name
FROM sys.databases
WHERE database_id > 4
  AND state_desc = 'ONLINE'
ORDER BY name;";

            using var command = new SqlCommand(sql, connection);
            using var reader = await command.ExecuteReaderAsync();

            while (await reader.ReadAsync())
                result.Add(reader.GetString(0));

            return result;
        }



        public async Task<List<PrincipalCandidate>> GetPrincipalCandidatesAsync(ServerConnection server, string databaseName, bool onlyWithObjectPermissions)
        {
            var result = new List<PrincipalCandidate>();

            using var connection = new SqlConnection(server.GetConnectionString(databaseName));
            await connection.OpenAsync();

            string sql = onlyWithObjectPermissions ? @"
IF OBJECT_ID(N'tempdb..#ServerSysAdmins') IS NOT NULL DROP TABLE #ServerSysAdmins;
CREATE TABLE #ServerSysAdmins (sid VARBINARY(85) NULL, name SYSNAME NULL);

BEGIN TRY
    INSERT INTO #ServerSysAdmins(sid, name)
    SELECT sp.sid, sp.name
    FROM sys.server_role_members srm
    JOIN sys.server_principals sr ON sr.principal_id = srm.role_principal_id
    JOIN sys.server_principals sp ON sp.principal_id = srm.member_principal_id
    WHERE sr.name = N'sysadmin';
END TRY
BEGIN CATCH
    -- Si el login no puede ver roles de servidor, se continúa con validaciones de base.
END CATCH;

;WITH ExplicitPerms AS
(
    SELECT DISTINCT grantee_principal_id
    FROM sys.database_permissions
    WHERE class = 1
      AND major_id > 0
      AND permission_name IN (N'SELECT', N'INSERT', N'UPDATE', N'DELETE')
), DbOwnerMembers AS
(
    SELECT drm.member_principal_id
    FROM sys.database_role_members drm
    JOIN sys.database_principals r ON r.principal_id = drm.role_principal_id
    WHERE r.name = N'db_owner'
)
SELECT
    dp.name AS PrincipalName,
    dp.type_desc AS PrincipalType,
    CAST(1 AS bit) AS HasObjectPermissions,
    CAST(CASE WHEN dom.member_principal_id IS NULL THEN 0 ELSE 1 END AS bit) AS IsDbOwnerMember,
    CAST(CASE WHEN ssa.sid IS NULL THEN 0 ELSE 1 END AS bit) AS IsSysAdminLogin,
    N'PERMISOS_EXPLICITOS' AS Source
FROM ExplicitPerms ep
JOIN sys.database_principals dp ON dp.principal_id = ep.grantee_principal_id
LEFT JOIN DbOwnerMembers dom ON dom.member_principal_id = dp.principal_id
LEFT JOIN #ServerSysAdmins ssa ON ssa.sid = dp.sid
WHERE dp.type IN ('S','U','G','R','E','X')
  AND dp.name NOT IN
  (
    N'dbo', N'guest', N'INFORMATION_SCHEMA', N'sys', N'public',
    N'db_owner', N'db_accessadmin', N'db_securityadmin', N'db_ddladmin',
    N'db_backupoperator', N'db_datareader', N'db_datawriter',
    N'db_denydatareader', N'db_denydatawriter'
  )
  AND ISNULL(dp.is_fixed_role, 0) = 0
  AND dom.member_principal_id IS NULL
  AND ssa.sid IS NULL
ORDER BY dp.name;" : @"
IF OBJECT_ID(N'tempdb..#ServerSysAdmins') IS NOT NULL DROP TABLE #ServerSysAdmins;
CREATE TABLE #ServerSysAdmins (sid VARBINARY(85) NULL, name SYSNAME NULL);

BEGIN TRY
    INSERT INTO #ServerSysAdmins(sid, name)
    SELECT sp.sid, sp.name
    FROM sys.server_role_members srm
    JOIN sys.server_principals sr ON sr.principal_id = srm.role_principal_id
    JOIN sys.server_principals sp ON sp.principal_id = srm.member_principal_id
    WHERE sr.name = N'sysadmin';
END TRY
BEGIN CATCH
    -- Si el login no puede ver roles de servidor, se continúa con validaciones de base.
END CATCH;

;WITH ExplicitPerms AS
(
    SELECT DISTINCT grantee_principal_id
    FROM sys.database_permissions
    WHERE class = 1
      AND major_id > 0
      AND permission_name IN (N'SELECT', N'INSERT', N'UPDATE', N'DELETE')
), DbOwnerMembers AS
(
    SELECT drm.member_principal_id
    FROM sys.database_role_members drm
    JOIN sys.database_principals r ON r.principal_id = drm.role_principal_id
    WHERE r.name = N'db_owner'
)
SELECT
    dp.name AS PrincipalName,
    dp.type_desc AS PrincipalType,
    CAST(CASE WHEN ep.grantee_principal_id IS NULL THEN 0 ELSE 1 END AS bit) AS HasObjectPermissions,
    CAST(CASE WHEN dom.member_principal_id IS NULL THEN 0 ELSE 1 END AS bit) AS IsDbOwnerMember,
    CAST(CASE WHEN ssa.sid IS NULL THEN 0 ELSE 1 END AS bit) AS IsSysAdminLogin,
    N'USUARIOS_ROLES' AS Source
FROM sys.database_principals dp
LEFT JOIN ExplicitPerms ep ON ep.grantee_principal_id = dp.principal_id
LEFT JOIN DbOwnerMembers dom ON dom.member_principal_id = dp.principal_id
LEFT JOIN #ServerSysAdmins ssa ON ssa.sid = dp.sid
WHERE dp.type IN ('S','U','G','R','E','X')
  AND dp.name NOT IN
  (
    N'dbo', N'guest', N'INFORMATION_SCHEMA', N'sys', N'public',
    N'db_owner', N'db_accessadmin', N'db_securityadmin', N'db_ddladmin',
    N'db_backupoperator', N'db_datareader', N'db_datawriter',
    N'db_denydatareader', N'db_denydatawriter'
  )
  AND ISNULL(dp.is_fixed_role, 0) = 0
  AND dom.member_principal_id IS NULL
  AND ssa.sid IS NULL
ORDER BY dp.type_desc, dp.name;";

            using var command = new SqlCommand(sql, connection);
            using var reader = await command.ExecuteReaderAsync();
            while (await reader.ReadAsync())
            {
                result.Add(new PrincipalCandidate
                {
                    PrincipalName = reader.GetString(0),
                    PrincipalType = reader.GetString(1),
                    HasObjectPermissions = reader.GetBoolean(2),
                    IsDbOwnerMember = reader.GetBoolean(3),
                    IsSysAdminLogin = reader.GetBoolean(4),
                    Source = reader.GetString(5)
                });
            }

            return result;
        }

        public List<string> ResolveSelectedDatabases(ServerConnection server, GlobalConfig config, IEnumerable<string> availableDatabases)
        {
            if (!config.DatabaseSelections.TryGetValue(server.Id, out var selection))
                return availableDatabases.ToList();

            var available = availableDatabases.ToList();

            if (selection.Mode == DatabaseSelectionMode.AllDatabases)
                return available;

            if (selection.Mode == DatabaseSelectionMode.OnlyThese)
                return available.Where(d => selection.SelectedDatabases.Contains(d, StringComparer.OrdinalIgnoreCase)).ToList();

            return available.Where(d => !selection.ExcludedDatabases.Contains(d, StringComparer.OrdinalIgnoreCase)).ToList();
        }

        public async Task<DeploymentResult> DeployDatabaseAsync(
            ServerConnection server,
            string databaseName,
            DeploymentOptions options,
            IEnumerable<PrincipalPolicy> principalPolicies,
            Action<string> log)
        {
            var result = new DeploymentResult
            {
                ServerName = server.DisplayName,
                DatabaseName = databaseName,
                StartTime = DateTime.Now,
                Success = false
            };

            try
            {
                string connectionString = server.GetConnectionString(databaseName);
                int timeout = options.CommandTimeout <= 0 ? 300 : options.CommandTimeout;

                log?.Invoke($"\r\n=== {server.DisplayName} / {databaseName} ===");

                await ExecuteNamedScript(connectionString, "setup.sql", timeout, log);
                result.AppliedChanges.Add("setup.sql");

                await ApplyRuntimeConfigAsync(connectionString, options, timeout, log);
                result.AppliedChanges.Add("Configuracion runtime dbo.Masked_Config");

                await UpsertPrincipalPoliciesAndExclusionsAsync(connectionString, principalPolicies, timeout, log);
                result.AppliedChanges.Add("dbo.Masked_PrincipalPolicy / dbo.Masked_PrincipalExclusions");

                await ExecuteNamedScript(connectionString, "sp_ManageColumnRule.sql", timeout, log);
                result.AppliedChanges.Add("sp_ManageColumnRule.sql");

                await ExecuteNamedScript(connectionString, "sp_CreateViewWithDml.sql", timeout, log);
                result.AppliedChanges.Add("sp_CreateViewWithDml.sql");

                if (options.RunReprocess)
                {
                    var script = _scriptService.ReadEmbeddedScript("06_reprocess_all_CONTROLADO.sql");
                    script = PrepareReprocessScript(script, options);
                    await _scriptService.ExecuteScriptAsync(connectionString, script, timeout, log);
                    result.AppliedChanges.Add($"06_reprocess_all_CONTROLADO.sql ({options.ReprocessMode})");
                }

                if (options.ApplyDDM)
                {
                    await ExecuteNamedScript(connectionString, "apply_ddm.sql", timeout, log);
                    result.AppliedChanges.Add("apply_ddm.sql");
                }

                if (options.CreateViews)
                {
                    await ExecuteNamedScript(connectionString, "02_deploy_all.sql", timeout, log);
                    result.AppliedChanges.Add("02_deploy_all.sql");
                }

                if (options.ApplySafePolicy)
                {
                    var policyScript = _scriptService.ReadEmbeddedScript("04_policy_by_table_SAFE.sql");
                    policyScript = PreparePolicyScript(policyScript, options);
                    await _scriptService.ExecuteScriptAsync(connectionString, policyScript, timeout, log);
                    result.AppliedChanges.Add("04_policy_by_table_SAFE.sql");
                }

                result.Success = true;
                result.EndTime = DateTime.Now;
                log?.Invoke($"OK: {server.DisplayName} / {databaseName}");
            }
            catch (Exception ex)
            {
                result.Success = false;
                result.ErrorMessage = ex.Message;
                result.EndTime = DateTime.Now;
                log?.Invoke($"ERROR en {server.DisplayName} / {databaseName}: {ex.Message}");
            }

            return result;
        }

        private async Task ExecuteNamedScript(string connectionString, string scriptName, int timeout, Action<string> log)
        {
            log?.Invoke($"Ejecutando {scriptName}...");
            string script = _scriptService.ReadEmbeddedScript(scriptName);
            await _scriptService.ExecuteScriptAsync(connectionString, script, timeout, log);
        }

        private async Task ApplyRuntimeConfigAsync(string connectionString, DeploymentOptions options, int timeout, Action<string> log)
        {
            const string sql = @"
MERGE dbo.Masked_Config AS tgt
USING (VALUES
    (N'MaskingMode', @MaskingMode),
    (N'MaskForceReapply', @MaskForceReapply),
    (N'MaskDryRun', @MaskDryRun),
    (N'SkipTablesWithComputed', @SkipTablesWithComputed),
    (N'CreateSynonyms', @CreateSynonyms)
) AS src(ConfigKey, ConfigValue)
ON tgt.ConfigKey = src.ConfigKey
WHEN MATCHED THEN UPDATE SET ConfigValue = src.ConfigValue
WHEN NOT MATCHED THEN INSERT(ConfigKey, ConfigValue) VALUES(src.ConfigKey, src.ConfigValue);";

            using var connection = new SqlConnection(connectionString);
            await connection.OpenAsync();
            using var command = new SqlCommand(sql, connection) { CommandTimeout = timeout };
            command.Parameters.AddWithValue("@MaskingMode", options.MaskingMode ?? "both");
            command.Parameters.AddWithValue("@MaskForceReapply", options.ForceReapply ? "1" : "0");
            command.Parameters.AddWithValue("@MaskDryRun", options.DryRun ? "1" : "0");
            command.Parameters.AddWithValue("@SkipTablesWithComputed", options.SkipTablesWithComputed ? "1" : "0");
            command.Parameters.AddWithValue("@CreateSynonyms", options.CreateSynonyms ? "1" : "0");
            await command.ExecuteNonQueryAsync();
            log?.Invoke("Configuracion runtime actualizada.");
        }

        private async Task UpsertPrincipalPoliciesAndExclusionsAsync(string connectionString, IEnumerable<PrincipalPolicy> policies, int timeout, Action<string> log)
        {
            var list = policies?.Where(p => !string.IsNullOrWhiteSpace(p.PrincipalName)).ToList() ?? new List<PrincipalPolicy>();
            if (list.Count == 0)
            {
                log?.Invoke("No hay principales configurados para dbo.Masked_PrincipalPolicy ni exclusiones.");
                return;
            }

            const string ensureExclusionTableSql = @"
IF OBJECT_ID(N'dbo.Masked_PrincipalExclusions', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.Masked_PrincipalExclusions
    (
        ExclusionId INT IDENTITY(1,1) PRIMARY KEY,
        PrincipalName SYSNAME NOT NULL UNIQUE,
        IsEnabled BIT NOT NULL DEFAULT 1,
        Reason NVARCHAR(500) NULL,
        CreatedAt DATETIME2(0) NOT NULL DEFAULT SYSUTCDATETIME(),
        ModifiedAt DATETIME2(0) NOT NULL DEFAULT SYSUTCDATETIME()
    );
END;";

            const string upsertPolicySql = @"
MERGE dbo.Masked_PrincipalPolicy AS tgt
USING (SELECT @PrincipalName AS PrincipalName) AS src
ON tgt.PrincipalName = src.PrincipalName
WHEN MATCHED THEN UPDATE SET
    IsEnabled = @IsEnabled,
    ApplyDefaultSchema = @ApplyDefaultSchema,
    MirrorObjectPermissions = @MirrorObjectPermissions,
    IncludeDml = @IncludeDml,
    AddToReadRole = @AddToReadRole,
    AddToDmlRole = @AddToDmlRole,
    BlockBaseAccess = @BlockBaseAccess,
    Notes = @Notes,
    ModifiedAt = SYSUTCDATETIME()
WHEN NOT MATCHED THEN INSERT
    (PrincipalName, IsEnabled, ApplyDefaultSchema, MirrorObjectPermissions, IncludeDml, AddToReadRole, AddToDmlRole, BlockBaseAccess, Notes, ModifiedAt)
VALUES
    (@PrincipalName, @IsEnabled, @ApplyDefaultSchema, @MirrorObjectPermissions, @IncludeDml, @AddToReadRole, @AddToDmlRole, @BlockBaseAccess, @Notes, SYSUTCDATETIME());";

            const string upsertExclusionSql = @"
MERGE dbo.Masked_PrincipalExclusions AS tgt
USING (SELECT @PrincipalName AS PrincipalName) AS src
ON tgt.PrincipalName = src.PrincipalName
WHEN MATCHED THEN UPDATE SET
    IsEnabled = @IsExcluded,
    Reason = @Reason,
    ModifiedAt = SYSUTCDATETIME()
WHEN NOT MATCHED THEN INSERT
    (PrincipalName, IsEnabled, Reason, ModifiedAt)
VALUES
    (@PrincipalName, @IsExcluded, @Reason, SYSUTCDATETIME());";

            using var connection = new SqlConnection(connectionString);
            await connection.OpenAsync();

            using (var ensure = new SqlCommand(ensureExclusionTableSql, connection) { CommandTimeout = timeout })
            {
                await ensure.ExecuteNonQueryAsync();
            }

            int policyCount = 0;
            int exclusionCount = 0;

            foreach (var p in list)
            {
                string principalName = p.PrincipalName.Trim();
                string notes = p.Notes;

                using (var exclusionCommand = new SqlCommand(upsertExclusionSql, connection) { CommandTimeout = timeout })
                {
                    exclusionCommand.Parameters.AddWithValue("@PrincipalName", principalName);
                    exclusionCommand.Parameters.AddWithValue("@IsExcluded", p.IsExcluded);
                    exclusionCommand.Parameters.AddWithValue("@Reason", (object)(p.IsExcluded ? (notes ?? "Excluido desde OfuscadorTool") : notes) ?? DBNull.Value);
                    await exclusionCommand.ExecuteNonQueryAsync();
                }

                if (p.IsExcluded)
                {
                    exclusionCount++;
                    continue;
                }

                using var command = new SqlCommand(upsertPolicySql, connection) { CommandTimeout = timeout };
                command.Parameters.AddWithValue("@PrincipalName", principalName);
                command.Parameters.AddWithValue("@IsEnabled", p.IsEnabled);
                command.Parameters.AddWithValue("@ApplyDefaultSchema", p.ApplyDefaultSchema);
                command.Parameters.AddWithValue("@MirrorObjectPermissions", p.MirrorObjectPermissions);
                command.Parameters.AddWithValue("@IncludeDml", p.IncludeDml);
                command.Parameters.AddWithValue("@AddToReadRole", p.AddToReadRole);
                command.Parameters.AddWithValue("@AddToDmlRole", p.AddToDmlRole);
                command.Parameters.AddWithValue("@BlockBaseAccess", p.BlockBaseAccess);
                command.Parameters.AddWithValue("@Notes", (object)notes ?? DBNull.Value);
                await command.ExecuteNonQueryAsync();
                policyCount++;
            }

            log?.Invoke($"Politicas sincronizadas: {policyCount}. Exclusiones activas: {exclusionCount}.");
        }

        private static string PreparePolicyScript(string script, DeploymentOptions options)
        {
            return script
                .Replace("DECLARE @DryRun BIT = 1;", $"DECLARE @DryRun BIT = {Bit(options.DryRun)};")
                .Replace("DECLARE @ApplyDefaultSchemaFromPolicy BIT = 1;", $"DECLARE @ApplyDefaultSchemaFromPolicy BIT = {Bit(options.ApplyDefaultSchemaPolicy)};")
                .Replace("DECLARE @MirrorPermissions BIT = 1;", $"DECLARE @MirrorPermissions BIT = {Bit(options.MirrorObjectPermissions)};")
                .Replace("DECLARE @MirrorScope NVARCHAR(30) = N'POLICY_TABLE';", $"DECLARE @MirrorScope NVARCHAR(30) = N'{Escape(options.PermissionMirrorScope ?? "POLICY_TABLE")}';")
                .Replace("DECLARE @CopyDml BIT = 0;", $"DECLARE @CopyDml BIT = {Bit(options.CopyDmlPermissions)};")
                .Replace("DECLARE @BaseAccessAction NVARCHAR(50) = N'REPORT_ONLY';", $"DECLARE @BaseAccessAction NVARCHAR(50) = N'{Escape(options.BaseAccessAction ?? "REPORT_ONLY")}';");
        }

        private static string PrepareReprocessScript(string script, DeploymentOptions options)
        {
            return script
                .Replace("DECLARE @DryRun BIT = 1;", $"DECLARE @DryRun BIT = {Bit(options.DryRun)};")
                .Replace("DECLARE @ReprocessMode NVARCHAR(30) = N'FORCE_DDM';", $"DECLARE @ReprocessMode NVARCHAR(30) = N'{Escape(options.ReprocessMode ?? "SOFT")}';");
        }

        private static int Bit(bool value) => value ? 1 : 0;
        private static string Escape(string value) => (value ?? string.Empty).Replace("'", "''");
    }
}
