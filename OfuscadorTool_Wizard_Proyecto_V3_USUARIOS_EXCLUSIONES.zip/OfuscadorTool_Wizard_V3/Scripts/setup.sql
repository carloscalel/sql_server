/* ===========================================================
   setup.sql - OfuscadorTool corregido / endurecido
   Compatible SQL Server 2016+

   Cambios clave:
   - Idempotente: NO borra dbo.Masked_Patterns; usa MERGE.
   - Conserva reglas y excepciones existentes.
   - Agrega configuración para DryRun, ForceReapply y SkipTablesWithComputed.
   - Prepara roles, pero NO asigna usuarios automáticamente.
   ===========================================================*/
SET NOCOUNT ON;
SET XACT_ABORT ON;

/* Schemas */
IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = N'masked') EXEC(N'CREATE SCHEMA masked AUTHORIZATION dbo;');
IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = N'app')    EXEC(N'CREATE SCHEMA app AUTHORIZATION dbo;');

/* Roles base */
IF NOT EXISTS (SELECT 1 FROM sys.database_principals WHERE name = N'rol_app_lectura' AND type = 'R')
    CREATE ROLE [rol_app_lectura];
IF NOT EXISTS (SELECT 1 FROM sys.database_principals WHERE name = N'rol_app_dml' AND type = 'R')
    CREATE ROLE [rol_app_dml];
IF NOT EXISTS (SELECT 1 FROM sys.database_principals WHERE name = N'rol_app_bloqueo_dbo' AND type = 'R')
    CREATE ROLE [rol_app_bloqueo_dbo];

/* Auditoria */
IF OBJECT_ID(N'dbo.Masked_Audit', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.Masked_Audit (
        AuditId     INT IDENTITY(1,1) PRIMARY KEY,
        EventType   NVARCHAR(30) NULL,      -- VIEW/TRIGGER/DDM/SYNONYM/POLICY/ERROR/INFO/SKIP/DRYRUN
        SchemaName  SYSNAME NULL,
        ObjectName  SYSNAME NULL,
        ColumnName  SYSNAME NULL,
        Action      NVARCHAR(80) NULL,
        Detail      NVARCHAR(4000) NULL,
        CreatedAt   DATETIME2(0) NOT NULL DEFAULT SYSUTCDATETIME()
    );
END;

/* Configuracion */
IF OBJECT_ID(N'dbo.Masked_Config', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.Masked_Config (
        ConfigKey   NVARCHAR(128) NOT NULL PRIMARY KEY,
        ConfigValue NVARCHAR(4000) NULL,
        UpdatedAt   DATETIME2(0) NOT NULL DEFAULT SYSUTCDATETIME()
    );
END;

MERGE dbo.Masked_Config AS tgt
USING (VALUES
    (N'SchemaVersion',           N'4'),
    (N'MaskingMode',             N'both'),     -- patterns | manual | both
    (N'MaskForceReapply',        N'0'),        -- 1 = DROP MASKED y reaplica
    (N'MaskDryRun',              N'0'),        -- 1 = solo imprime/audita, no ejecuta ALTER
    (N'SkipTablesWithComputed',  N'1'),        -- 1 = DDM no se aplica en tablas con columnas calculadas
    (N'DefaultMaskedSchema',     N'masked'),
    (N'DefaultAppSchema',        N'app'),
    (N'PermissionMirrorScope',   N'POLICY_TABLE'), -- POLICY_TABLE | ALL_EXISTING_GRANTEES
    (N'BaseAccessAction',        N'REPORT_ONLY'),  -- REPORT_ONLY | REVOKE_EXPLICIT_OBJECT_PERMISSIONS | DENY_BASE_FOR_POLICY_PRINCIPALS
    (N'EnableDefaultSchemaPolicy', N'1')
) AS src(ConfigKey, ConfigValue)
ON tgt.ConfigKey = src.ConfigKey
WHEN MATCHED AND src.ConfigKey = N'SchemaVersion' THEN
    UPDATE SET ConfigValue = src.ConfigValue, UpdatedAt = SYSUTCDATETIME()
WHEN NOT MATCHED THEN
    INSERT (ConfigKey, ConfigValue) VALUES (src.ConfigKey, src.ConfigValue);

/* Patrones */
IF OBJECT_ID(N'dbo.Masked_Patterns', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.Masked_Patterns (
        Pattern       NVARCHAR(128) NOT NULL PRIMARY KEY,
        DdmFunction   NVARCHAR(200) NOT NULL,
        ViewMaskExpr  NVARCHAR(1000) NULL,
        Priority      INT NOT NULL DEFAULT 10,
        IsEnabled     BIT NOT NULL DEFAULT 1,
        ModifiedAt    DATETIME2(0) NOT NULL DEFAULT SYSUTCDATETIME()
    );
END;

IF COL_LENGTH(N'dbo.Masked_Patterns', N'Priority') IS NULL
    ALTER TABLE dbo.Masked_Patterns ADD Priority INT NOT NULL CONSTRAINT DF_Masked_Patterns_Priority DEFAULT(10);
IF COL_LENGTH(N'dbo.Masked_Patterns', N'IsEnabled') IS NULL
    ALTER TABLE dbo.Masked_Patterns ADD IsEnabled BIT NOT NULL CONSTRAINT DF_Masked_Patterns_IsEnabled DEFAULT(1);
IF COL_LENGTH(N'dbo.Masked_Patterns', N'ModifiedAt') IS NULL
    ALTER TABLE dbo.Masked_Patterns ADD ModifiedAt DATETIME2(0) NOT NULL CONSTRAINT DF_Masked_Patterns_ModifiedAt DEFAULT SYSUTCDATETIME();

MERGE dbo.Masked_Patterns AS tgt
USING (VALUES
 (N'%TARJETA%', N'partial(0,"XXXXXXXXXXXXXXX",4)',
  N'CASE WHEN {col} IS NULL THEN NULL ELSE REPLICATE(''X'', CASE WHEN LEN({col})>4 THEN LEN({col})-4 ELSE 0 END) + RIGHT({col}, CASE WHEN LEN({col})>4 THEN 4 ELSE LEN({col}) END) END', 100, 1),
 (N'%CUENTA%', N'partial(0,"XXXXXXXXXXXX",4)',
  N'CASE WHEN {col} IS NULL THEN NULL ELSE REPLICATE(''X'', CASE WHEN LEN({col})>4 THEN LEN({col})-4 ELSE 0 END) + RIGHT({col}, CASE WHEN LEN({col})>4 THEN 4 ELSE LEN({col}) END) END', 90, 1),
 (N'%CODIGO%', N'partial(6,"XXXXXX",4)',
  N'CASE WHEN {col} IS NULL THEN NULL ELSE LEFT({col}, CASE WHEN LEN({col})>6 THEN 6 ELSE LEN({col}) END) + REPLICATE(''X'', CASE WHEN LEN({col})>10 THEN LEN({col})-10 ELSE 0 END) + RIGHT({col}, CASE WHEN LEN({col})>10 THEN 4 ELSE 0 END) END', 80, 1),
 (N'%AUTENTICACION%', N'partial(6,"XXXXXX",4)',
  N'CASE WHEN {col} IS NULL THEN NULL ELSE LEFT({col}, CASE WHEN LEN({col})>6 THEN 6 ELSE LEN({col}) END) + REPLICATE(''X'', CASE WHEN LEN({col})>10 THEN LEN({col})-10 ELSE 0 END) + RIGHT({col}, CASE WHEN LEN({col})>10 THEN 4 ELSE 0 END) END', 80, 1),
 (N'%MAGNETICA%', N'partial(6,"XXXXXX",4)',
  N'CASE WHEN {col} IS NULL THEN NULL ELSE LEFT({col}, CASE WHEN LEN({col})>6 THEN 6 ELSE LEN({col}) END) + REPLICATE(''X'', CASE WHEN LEN({col})>10 THEN LEN({col})-10 ELSE 0 END) + RIGHT({col}, CASE WHEN LEN({col})>10 THEN 4 ELSE 0 END) END', 80, 1),
 (N'%CVV2%', N'partial(0,"XXX",0)',
  N'CASE WHEN {col} IS NULL THEN NULL ELSE REPLICATE(''X'', LEN({col})) END', 95, 1),
 (N'%CV2%', N'partial(0,"XXX",0)',
  N'CASE WHEN {col} IS NULL THEN NULL ELSE REPLICATE(''X'', LEN({col})) END', 90, 1),
 (N'%BIN%', N'partial(6,"XXXXXX",0)',
  N'CASE WHEN {col} IS NULL THEN NULL ELSE LEFT({col}, CASE WHEN LEN({col})>6 THEN 6 ELSE LEN({col}) END) + REPLICATE(''X'', CASE WHEN LEN({col})>6 THEN LEN({col})-6 ELSE 0 END) END', 70, 1),
 (N'%FECHA_V%', N'default()', N'NULL', 70, 1),
 (N'NOM_%', N'partial(10,"XXXXXXXXXXXXXXXXXXXX",0)',
  N'CASE WHEN {col} IS NULL THEN NULL ELSE LEFT({col}, CASE WHEN LEN({col})>10 THEN 10 ELSE LEN({col}) END) + REPLICATE(''X'', CASE WHEN LEN({col})>10 THEN LEN({col})-10 ELSE 0 END) END', 60, 1),
 (N'%NOMBRE%', N'partial(10,"XXXXXXXXXXXXXXXXXXXX",0)',
  N'CASE WHEN {col} IS NULL THEN NULL ELSE LEFT({col}, CASE WHEN LEN({col})>10 THEN 10 ELSE LEN({col}) END) + REPLICATE(''X'', CASE WHEN LEN({col})>10 THEN LEN({col})-10 ELSE 0 END) END', 60, 1),
 (N'%EMAIL%', N'email()',
  N'CASE WHEN {col} IS NULL THEN NULL ELSE CASE WHEN CHARINDEX(''@'',{col})>1 THEN LEFT({col},1)+''*****''+SUBSTRING({col},CHARINDEX(''@'',{col}),LEN({col})-CHARINDEX(''@'',{col})+1) ELSE ''*****'' END END', 100, 1),
 (N'%CORREO%', N'email()',
  N'CASE WHEN {col} IS NULL THEN NULL ELSE CASE WHEN CHARINDEX(''@'',{col})>1 THEN LEFT({col},1)+''*****''+SUBSTRING({col},CHARINDEX(''@'',{col}),LEN({col})-CHARINDEX(''@'',{col})+1) ELSE ''*****'' END END', 95, 1),
 (N'%NACIMIENTO%', N'default()', N'NULL', 70, 1),
 (N'%BLOQUEO%', N'default()', N'NULL', 40, 1),
 (N'%TOKEN%', N'default()', N'NULL', 100, 1),
 (N'%NIT%', N'default()', N'NULL', 90, 1),
 (N'%DPI%', N'default()', N'NULL', 90, 1),
 (N'%DIRECCION%', N'default()', N'NULL', 80, 1),
 (N'DIR_%', N'default()', N'NULL', 75, 1),
 (N'%TEL%', N'default()', N'NULL', 80, 1),
 (N'%TELEFONO%', N'default()', N'NULL', 80, 1)
) AS src(Pattern, DdmFunction, ViewMaskExpr, Priority, IsEnabled)
ON tgt.Pattern = src.Pattern
WHEN MATCHED THEN
    UPDATE SET DdmFunction = src.DdmFunction,
               ViewMaskExpr = src.ViewMaskExpr,
               Priority = src.Priority,
               IsEnabled = CASE WHEN tgt.IsEnabled IS NULL THEN src.IsEnabled ELSE tgt.IsEnabled END,
               ModifiedAt = SYSUTCDATETIME()
WHEN NOT MATCHED THEN
    INSERT (Pattern, DdmFunction, ViewMaskExpr, Priority, IsEnabled)
    VALUES (src.Pattern, src.DdmFunction, src.ViewMaskExpr, src.Priority, src.IsEnabled);

/* Reglas puntuales por columna */
IF OBJECT_ID(N'dbo.Masked_ColumnRules', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.Masked_ColumnRules (
        RuleId          INT IDENTITY(1,1) PRIMARY KEY,
        SchemaName      SYSNAME NOT NULL DEFAULT N'dbo',
        TableName       SYSNAME NOT NULL,
        ColumnName      SYSNAME NOT NULL,
        IsEnabled       BIT NOT NULL DEFAULT 1,
        MaskType        NVARCHAR(50) NOT NULL,
        MaskParams      NVARCHAR(200) NULL,
        CustomFunction  NVARCHAR(1000) NULL,
        DdmFunction     NVARCHAR(200) NULL,
        ViewMaskExpr    NVARCHAR(1000) NULL,
        Priority        INT NOT NULL DEFAULT 10,
        CreatedAt       DATETIME2(0) NOT NULL DEFAULT SYSUTCDATETIME(),
        ModifiedAt      DATETIME2(0) NOT NULL DEFAULT SYSUTCDATETIME(),
        CONSTRAINT UQ_Masked_ColumnRules UNIQUE (SchemaName, TableName, ColumnName)
    );
END;

/* Excepciones por tabla o columna */
IF OBJECT_ID(N'dbo.Masked_Exceptions', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.Masked_Exceptions (
        ExceptionId     INT IDENTITY(1,1) PRIMARY KEY,
        SchemaName      SYSNAME NOT NULL DEFAULT N'dbo',
        TableName       SYSNAME NOT NULL,
        ColumnName      SYSNAME NULL,
        Reason          NVARCHAR(500) NULL,
        IsEnabled       BIT NOT NULL DEFAULT 1,
        CreatedAt       DATETIME2(0) NOT NULL DEFAULT SYSUTCDATETIME()
    );
END;

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'dbo.Masked_Exceptions') AND name = N'UX_Masked_Exceptions_Table')
    CREATE UNIQUE INDEX UX_Masked_Exceptions_Table
    ON dbo.Masked_Exceptions(SchemaName, TableName)
    WHERE ColumnName IS NULL;

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'dbo.Masked_Exceptions') AND name = N'UX_Masked_Exceptions_Column')
    CREATE UNIQUE INDEX UX_Masked_Exceptions_Column
    ON dbo.Masked_Exceptions(SchemaName, TableName, ColumnName)
    WHERE ColumnName IS NOT NULL;

/* Seleccion manual */
IF OBJECT_ID(N'dbo.Masked_ManualSelection', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.Masked_ManualSelection (
        SelectionId     INT IDENTITY(1,1) PRIMARY KEY,
        SchemaName      SYSNAME NOT NULL DEFAULT N'dbo',
        TableName       SYSNAME NOT NULL,
        ColumnName      SYSNAME NOT NULL,
        IsSelected      BIT NOT NULL DEFAULT 1,
        MaskOverride    NVARCHAR(200) NULL, -- DDM function: default(), email(), partial(...), random(...)
        SelectedAt      DATETIME2(0) NOT NULL DEFAULT SYSUTCDATETIME(),
        CONSTRAINT UQ_Masked_ManualSelection UNIQUE (SchemaName, TableName, ColumnName)
    );
END;


/* Politica controlada por principal/usuario/rol
   Esta tabla permite migrar usuarios concretos sin cambiar permisos masivamente.
   - ApplyDefaultSchema: cambia DEFAULT_SCHEMA a masked solo para ese usuario/principal.
   - MirrorObjectPermissions: copia permisos puntuales desde dbo.Tabla hacia masked.Tabla.
   - BlockBaseAccess: solo se usa si el script de politica se ejecuta con DENY_BASE_FOR_POLICY_PRINCIPALS.
   - AddToReadRole/AddToDmlRole: opcional, para roles de apoyo. Por defecto se recomienda NO usarlos si se copian permisos puntuales.
*/
IF OBJECT_ID(N'dbo.Masked_PrincipalPolicy', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.Masked_PrincipalPolicy (
        PolicyId                INT IDENTITY(1,1) PRIMARY KEY,
        PrincipalName           SYSNAME NOT NULL UNIQUE,
        IsEnabled               BIT NOT NULL DEFAULT 1,
        ApplyDefaultSchema      BIT NOT NULL DEFAULT 1,
        MirrorObjectPermissions BIT NOT NULL DEFAULT 1,
        IncludeDml              BIT NOT NULL DEFAULT 0,
        AddToReadRole           BIT NOT NULL DEFAULT 0,
        AddToDmlRole            BIT NOT NULL DEFAULT 0,
        BlockBaseAccess         BIT NOT NULL DEFAULT 0,
        Notes                   NVARCHAR(500) NULL,
        CreatedAt               DATETIME2(0) NOT NULL DEFAULT SYSUTCDATETIME(),
        ModifiedAt              DATETIME2(0) NOT NULL DEFAULT SYSUTCDATETIME()
    );
END;

IF COL_LENGTH(N'dbo.Masked_PrincipalPolicy', N'IncludeDml') IS NULL
    ALTER TABLE dbo.Masked_PrincipalPolicy ADD IncludeDml BIT NOT NULL CONSTRAINT DF_Masked_PrincipalPolicy_IncludeDml DEFAULT(0);
IF COL_LENGTH(N'dbo.Masked_PrincipalPolicy', N'AddToReadRole') IS NULL
    ALTER TABLE dbo.Masked_PrincipalPolicy ADD AddToReadRole BIT NOT NULL CONSTRAINT DF_Masked_PrincipalPolicy_AddToReadRole DEFAULT(0);
IF COL_LENGTH(N'dbo.Masked_PrincipalPolicy', N'AddToDmlRole') IS NULL
    ALTER TABLE dbo.Masked_PrincipalPolicy ADD AddToDmlRole BIT NOT NULL CONSTRAINT DF_Masked_PrincipalPolicy_AddToDmlRole DEFAULT(0);
IF COL_LENGTH(N'dbo.Masked_PrincipalPolicy', N'BlockBaseAccess') IS NULL
    ALTER TABLE dbo.Masked_PrincipalPolicy ADD BlockBaseAccess BIT NOT NULL CONSTRAINT DF_Masked_PrincipalPolicy_BlockBaseAccess DEFAULT(0);



/* Exclusiones de principales
   Cualquier usuario/rol agregado aquí con IsEnabled=1 no será modificado por la política,
   aunque exista en dbo.Masked_PrincipalPolicy o aunque tenga permisos explícitos y se use ALL_EXISTING_GRANTEES.
   Útil para cuentas técnicas, ETL, aplicaciones críticas, administradores o usuarios que deben quedar intactos.
*/
IF OBJECT_ID(N'dbo.Masked_PrincipalExclusions', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.Masked_PrincipalExclusions (
        ExclusionId   INT IDENTITY(1,1) PRIMARY KEY,
        PrincipalName SYSNAME NOT NULL UNIQUE,
        IsEnabled     BIT NOT NULL DEFAULT 1,
        Reason        NVARCHAR(500) NULL,
        CreatedAt     DATETIME2(0) NOT NULL DEFAULT SYSUTCDATETIME(),
        ModifiedAt    DATETIME2(0) NOT NULL DEFAULT SYSUTCDATETIME()
    );
END;

IF COL_LENGTH(N'dbo.Masked_PrincipalExclusions', N'IsEnabled') IS NULL
    ALTER TABLE dbo.Masked_PrincipalExclusions ADD IsEnabled BIT NOT NULL CONSTRAINT DF_Masked_PrincipalExclusions_IsEnabled DEFAULT(1);
IF COL_LENGTH(N'dbo.Masked_PrincipalExclusions', N'Reason') IS NULL
    ALTER TABLE dbo.Masked_PrincipalExclusions ADD Reason NVARCHAR(500) NULL;
IF COL_LENGTH(N'dbo.Masked_PrincipalExclusions', N'ModifiedAt') IS NULL
    ALTER TABLE dbo.Masked_PrincipalExclusions ADD ModifiedAt DATETIME2(0) NOT NULL CONSTRAINT DF_Masked_PrincipalExclusions_ModifiedAt DEFAULT SYSUTCDATETIME();

/*
Ejemplo de migracion controlada:

INSERT INTO dbo.Masked_PrincipalPolicy
(PrincipalName, ApplyDefaultSchema, MirrorObjectPermissions, IncludeDml, AddToReadRole, AddToDmlRole, BlockBaseAccess, Notes)
VALUES
(N'UsuarioAplicacion', 1, 1, 0, 0, 0, 0, N'Migrar a vistas masked sin tocar permisos originales.');

Luego ejecutar 04_policy_by_table_SAFE.sql primero con @DryRun = 1.
*/


/* Permisos a roles solamente. No se asignan usuarios aqui. */
BEGIN TRY GRANT SELECT ON SCHEMA::app    TO [rol_app_lectura]; END TRY BEGIN CATCH END CATCH;
BEGIN TRY GRANT SELECT ON SCHEMA::masked TO [rol_app_lectura]; END TRY BEGIN CATCH END CATCH;
BEGIN TRY GRANT INSERT, UPDATE, DELETE ON SCHEMA::masked TO [rol_app_dml]; END TRY BEGIN CATCH END CATCH;

INSERT INTO dbo.Masked_Audit(EventType, SchemaName, ObjectName, ColumnName, Action, Detail)
VALUES(N'INFO', N'dbo', N'setup', NULL, N'COMPLETE', N'Setup corregido aplicado. No se asignaron usuarios automaticamente.');

PRINT N'Setup corregido completado correctamente.';
