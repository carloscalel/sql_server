document.addEventListener('DOMContentLoaded', () => {
    // Lista base de responsables por defecto
    const defaultOwners = [
        "DBA",
        "Infraestructura",
        "Telecom",
        "Ciberseguridad",
        "Operaciones",
        "Tesorería",
        "Usuarios Clave",
        "Continuidad"
    ];

    let owners = [...defaultOwners];
    let activities = (typeof initialPlanData !== 'undefined') ? JSON.parse(JSON.stringify(initialPlanData)) : [];

    // Normalizar datos de actividades
    function sanitizeActivities(list) {
        if (!Array.isArray(list)) return [];
        list.forEach(item => {
            if (item.dependsOn === undefined) {
                const defaultItem = (typeof initialPlanData !== 'undefined') ? initialPlanData.find(d => d.id === item.id) : null;
                item.dependsOn = defaultItem ? defaultItem.dependsOn : null;
            }
            if (item.start && item.start.includes('-')) item.start = ''; // Limpiar fechas viejas si las hubiera
            if (item.end && item.end.includes('-')) item.end = '';
            if (item.obs === undefined) item.obs = '';
        });
        return list;
    }

    sanitizeActivities(activities);

    // Variables de sincronización y API
    let apiEndpoint = null; // 'api.ashx', 'api.php', o 'local'
    let isFetching = false;
    let isSaving = false;
    let hasPendingRemoteUpdate = false;
    let pendingRemoteData = null;
    let pollingInterval = null;
    let obsDebounceTimer = null;

    let pendingStatusChange = null;

    let statusChartInstance = null;
    let modulesBarChartInstance = null;

    // Referencias al DOM
    const navItems = document.querySelectorAll('.nav-item');
    const sections = document.querySelectorAll('.content-section');
    const tbody = document.getElementById('activities-tbody');
    const modulesTbody = document.getElementById('modules-tbody');
    const ownersTbody = document.getElementById('owners-tbody');
    const filterModule = document.getElementById('filter-module');
    const searchActivity = document.getElementById('search-activity');
    const resetBtn = document.getElementById('reset-storage');
    const manualSyncBtn = document.getElementById('manual-sync-btn');

    const kpiTotal = document.getElementById('kpi-total');
    const kpiOk = document.getElementById('kpi-ok');
    const kpiRun = document.getElementById('kpi-run');
    const kpiError = document.getElementById('kpi-error');
    const kpiPercent = document.getElementById('kpi-percent');

    // ==========================================
    // UTILIDADES & ESCAPADO SEGURO
    // ==========================================
    function escapeHtml(str) {
        if (!str) return '';
        return str.toString()
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#39;');
    }

    function formatTime(val) {
        if (!val) return '';
        if (/^\d{2}:\d{2}$/.test(val)) return val;
        if (/^\d{2}:\d{2}:\d{2}$/.test(val)) return val.substring(0, 5);
        return '';
    }

    // ==========================================
    // REGLAS DE DEPENDENCIA ENTRE ACTIVIDADES
    // ==========================================
    function isActivityBlocked(act) {
        if (!act.dependsOn) return false;
        const parent = activities.find(a => a.id == act.dependsOn);
        if (!parent) return false;
        return parent.status !== 'Completado';
    }

    function getParentActivity(act) {
        if (!act.dependsOn) return null;
        return activities.find(a => a.id == act.dependsOn) || null;
    }

    function causesCircularDependency(actId, targetParentId) {
        if (!targetParentId) return false;
        let current = targetParentId;
        const visited = new Set();
        while (current) {
            if (current == actId) return true;
            if (visited.has(current)) break;
            visited.add(current);
            const parent = activities.find(a => a.id == current);
            current = parent ? parent.dependsOn : null;
        }
        return false;
    }

    // ==========================================
    // NAVEGACIÓN ENTRE SECCIONES
    // ==========================================
    navItems.forEach(item => {
        item.addEventListener('click', (e) => {
            e.preventDefault();
            navItems.forEach(nav => nav.classList.remove('active'));
            sections.forEach(sec => sec.classList.remove('active'));

            item.classList.add('active');
            const targetId = item.getAttribute('data-section');
            const targetSec = document.getElementById(targetId);
            if (targetSec) targetSec.classList.add('active');
        });
    });

    // ==========================================
    // NOTIFICACIONES TOAST & INDICADOR DE ESTADO
    // ==========================================
    function showToast(message, type = 'info', duration = 3500) {
        const container = document.getElementById('toast-container');
        if (!container) return;

        const toast = document.createElement('div');
        toast.className = `toast-msg toast-${type}`;
        
        let icon = 'fa-circle-info';
        if (type === 'success') icon = 'fa-circle-check';
        if (type === 'error') icon = 'fa-triangle-exclamation';

        toast.innerHTML = `<i class="fa-solid ${icon}"></i> <span>${message}</span>`;
        container.appendChild(toast);

        setTimeout(() => {
            toast.style.opacity = '0';
            setTimeout(() => toast.remove(), 300);
        }, duration);
    }

    function setSyncStatus(state, message) {
        const statusEl = document.getElementById('sync-status');
        const textEl = document.getElementById('sync-text');
        const timeEl = document.getElementById('sync-time');
        if (!statusEl || !textEl) return;

        statusEl.className = `status-indicator ${state}`;
        textEl.textContent = message;

        if (state === 'online') {
            const now = new Date();
            const timeStr = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
            if (timeEl) timeEl.textContent = `(${timeStr})`;
        } else if (state === 'saving') {
            if (timeEl) timeEl.textContent = '';
        }
    }

    function isUserEditing() {
        const active = document.activeElement;
        if (!active) return false;
        const tag = active.tagName.toLowerCase();
        return tag === 'input' || tag === 'textarea' || tag === 'select';
    }

    // ==========================================
    // DETECCIÓN DE BACKEND (IIS ASHX / PHP / LOCAL)
    // ==========================================
    async function detectEndpoint() {
        if (window.location.protocol === 'file:') {
            console.warn('Ejecutándose en local (file://).');
            setSyncStatus('offline', 'Modo Local');
            return 'local';
        }

        // 1. Probar ASP.NET Handler en IIS (api.ashx)
        try {
            const res = await fetch('api.ashx?t=' + Date.now(), { method: 'GET', cache: 'no-store' });
            if (res.ok) {
                const data = await res.json();
                if (data && (Array.isArray(data) || data.activities)) {
                    apiEndpoint = 'api.ashx';
                    return 'api.ashx';
                }
            }
        } catch (e) {}

        // 2. Probar PHP (api.php)
        try {
            const res = await fetch('api.php?t=' + Date.now(), { method: 'GET', cache: 'no-store' });
            if (res.ok) {
                const data = await res.json();
                if (data && (Array.isArray(data) || data.activities)) {
                    apiEndpoint = 'api.php';
                    return 'api.php';
                }
            }
        } catch (e) {}

        // 3. Probar lectura estática
        try {
            const res = await fetch('data.json?t=' + Date.now(), { method: 'GET', cache: 'no-store' });
            if (res.ok) {
                const data = await res.json();
                if (data && (Array.isArray(data) || data.activities)) {
                    apiEndpoint = 'data.json';
                    return 'data.json';
                }
            }
        } catch (e) {}

        apiEndpoint = 'local';
        return 'local';
    }

    function applyDataPayload(data) {
        if (Array.isArray(data)) {
            activities = sanitizeActivities(data);
            const derived = [...new Set(activities.map(a => a.owner).filter(Boolean))];
            owners = [...new Set([...defaultOwners, ...derived])];
        } else if (data && typeof data === 'object') {
            activities = sanitizeActivities(data.activities || []);
            if (Array.isArray(data.owners) && data.owners.length > 0) {
                owners = data.owners;
            } else {
                const derived = [...new Set(activities.map(a => a.owner).filter(Boolean))];
                owners = [...new Set([...defaultOwners, ...derived])];
            }
        }
    }

    function getPayloadToSave() {
        return {
            owners: owners,
            activities: activities
        };
    }

    // ==========================================
    // CARGA DE DATOS & SINCRONIZACIÓN EN TIEMPO REAL
    // ==========================================
    async function fetchData(isSilent = false) {
        if (isFetching || isSaving) return;

        if (!apiEndpoint) {
            apiEndpoint = await detectEndpoint();
        }

        if (apiEndpoint === 'local') {
            const stored = localStorage.getItem('alwayson_data_v2') || localStorage.getItem('alwayson_activities');
            if (stored) {
                try {
                    const parsed = JSON.parse(stored);
                    applyDataPayload(parsed);
                } catch(e) {}
            }
            if (!isSilent) {
                populateModulesFilter();
                populateOwnersSelects();
                updateDashboard();
                renderTable();
                renderModulesTable();
                renderOwnersTable();
            }
            return;
        }

        const url = (apiEndpoint === 'data.json') ? `data.json?t=${Date.now()}` : `${apiEndpoint}?t=${Date.now()}`;
        isFetching = true;

        try {
            const res = await fetch(url, { cache: 'no-store' });
            if (res.ok) {
                const serverData = await res.json();
                const serverJson = JSON.stringify(serverData);
                const localJson = JSON.stringify(getPayloadToSave());

                if (serverJson !== localJson) {
                    if (isUserEditing()) {
                        hasPendingRemoteUpdate = true;
                        pendingRemoteData = serverData;
                    } else {
                        applyDataPayload(serverData);
                        localStorage.setItem('alwayson_data_v2', JSON.stringify(getPayloadToSave()));
                        populateModulesFilter();
                        populateOwnersSelects();
                        updateDashboard();
                        renderTable();
                        renderModulesTable();
                        renderOwnersTable();

                        if (isSilent) {
                            showToast('Se sincronizaron cambios realizados por otro usuario', 'info', 3000);
                        }
                    }
                }
                setSyncStatus('online', 'En Línea (Sincronizado)');
            } else {
                if (!isSilent) setSyncStatus('error', 'Error al leer datos');
            }
        } catch (err) {
            if (!isSilent) setSyncStatus('error', 'Sin conexión con IIS');
        } finally {
            isFetching = false;
        }
    }

    document.addEventListener('focusout', () => {
        setTimeout(() => {
            if (!isUserEditing() && hasPendingRemoteUpdate && pendingRemoteData) {
                applyDataPayload(pendingRemoteData);
                hasPendingRemoteUpdate = false;
                pendingRemoteData = null;
                localStorage.setItem('alwayson_data_v2', JSON.stringify(getPayloadToSave()));
                populateModulesFilter();
                populateOwnersSelects();
                updateDashboard();
                renderTable();
                renderModulesTable();
                renderOwnersTable();
                showToast('Actualizado con cambios remotos recientes', 'info', 2500);
            }
        }, 150);
    });

    // ==========================================
    // GUARDADO COMPARTIDO (POST AL SERVIDOR IIS)
    // ==========================================
    async function saveData(showToastFeedback = false) {
        isSaving = true;

        updateDashboard();
        renderModulesTable();
        renderOwnersTable();

        const payload = getPayloadToSave();
        const payloadJson = JSON.stringify(payload);

        if (apiEndpoint === 'api.ashx' || apiEndpoint === 'api.php') {
            setSyncStatus('saving', 'Guardando...');
            try {
                const res = await fetch(apiEndpoint, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json; charset=utf-8' },
                    body: payloadJson
                });

                if (res.ok) {
                    localStorage.setItem('alwayson_data_v2', payloadJson);
                    setSyncStatus('online', 'En Línea (Sincronizado)');
                    if (showToastFeedback) {
                        showToast('Cambios guardados y compartidos correctamente', 'success', 2500);
                    }
                } else {
                    const errData = await res.json().catch(() => ({}));
                    const errMsg = errData.error || `HTTP ${res.status}`;
                    setSyncStatus('error', 'Error de guardado');
                    showToast(`Error al guardar en IIS: ${errMsg}`, 'error', 6000);
                }
            } catch (err) {
                setSyncStatus('error', 'Fallo de conexión');
                showToast('No se pudo conectar con el servidor IIS para guardar.', 'error', 5000);
            }
        } else {
            localStorage.setItem('alwayson_data_v2', payloadJson);
            setSyncStatus('offline', 'Modo Local');
            if (showToastFeedback) {
                showToast('Guardado en almacenamiento local', 'info');
            }
        }

        isSaving = false;
    }

    // ==========================================
    // GESTIÓN DE MÓDULOS, RESPONSABLES Y FILTROS
    // ==========================================
    function getUniqueModules() {
        return [...new Set(activities.map(item => item.module))];
    }

    function populateModulesFilter() {
        if (!filterModule) return;
        const currentSelected = filterModule.value;
        const modules = getUniqueModules();
        filterModule.innerHTML = '<option value="all">Todos los Módulos</option>';
        modules.forEach(mod => {
            const opt = document.createElement('option');
            opt.value = mod;
            opt.textContent = mod;
            if (mod === currentSelected) opt.selected = true;
            filterModule.appendChild(opt);
        });

        // Select del modal de nueva actividad
        const modalModuleSelect = document.getElementById('new-module');
        if (modalModuleSelect) {
            modalModuleSelect.innerHTML = '';
            modules.forEach(mod => {
                const opt = document.createElement('option');
                opt.value = mod;
                opt.textContent = mod;
                modalModuleSelect.appendChild(opt);
            });
        }

        // Select de dependencias en el modal de nueva actividad
        const modalDepSelect = document.getElementById('new-depends');
        if (modalDepSelect) {
            modalDepSelect.innerHTML = '<option value="">(Ninguna)</option>';
            activities.forEach(a => {
                const opt = document.createElement('option');
                opt.value = a.id;
                opt.textContent = `#${a.id} - ${a.name}`;
                modalDepSelect.appendChild(opt);
            });
        }
    }

    function populateOwnersSelects() {
        const newOwnerSelect = document.getElementById('new-owner');
        if (newOwnerSelect) {
            const currentVal = newOwnerSelect.value;
            newOwnerSelect.innerHTML = '';
            owners.forEach(owner => {
                const opt = document.createElement('option');
                opt.value = owner;
                opt.textContent = owner;
                if (owner === currentVal) opt.selected = true;
                newOwnerSelect.appendChild(opt);
            });
        }
    }

    // ==========================================
    // RENDERIZADO DE TABLA DE ACTIVIDADES
    // ==========================================
    function renderTable() {
        if (!tbody) return;
        const selectedModule = filterModule ? filterModule.value : 'all';
        const searchTerm = searchActivity ? searchActivity.value.toLowerCase().trim() : '';

        tbody.innerHTML = '';

        const filtered = activities.filter(item => {
            const matchMod = selectedModule === 'all' || item.module === selectedModule;
            const matchSearch = item.name.toLowerCase().includes(searchTerm) || 
                                (item.owner && item.owner.toLowerCase().includes(searchTerm)) ||
                                (item.obs && item.obs.toLowerCase().includes(searchTerm));
            return matchMod && matchSearch;
        });

        if (filtered.length === 0) {
            tbody.innerHTML = `<tr><td colspan="10" style="text-align: center; padding: 25px; color: var(--text-muted); font-size: 13px;">No se encontraron actividades registradas</td></tr>`;
            return;
        }

        filtered.forEach(item => {
            const isBlocked = isActivityBlocked(item);
            const parent = getParentActivity(item);

            let depBadgeHtml = '';
            if (parent) {
                if (parent.status === 'Completado') {
                    depBadgeHtml = `<div class="badge-dep ok" title="Requisito cumplido: #${parent.id} está completado"><i class="fa-solid fa-lock-open"></i> Listo (#${parent.id})</div>`;
                } else {
                    depBadgeHtml = `<div class="badge-dep blocked" title="Bloqueado por: #${parent.id} ${escapeHtml(parent.name)} (Estado: ${parent.status})"><i class="fa-solid fa-lock"></i> Esperando #${parent.id}</div>`;
                }
            }

            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td style="text-align: center;"><span class="badge-id">#${item.id}</span></td>
                <td><strong>${escapeHtml(item.module)}</strong></td>
                <td>
                    <div style="font-weight: 500;">${escapeHtml(item.name)}</div>
                </td>
                <td>
                    <div class="dep-cell">
                        <select class="table-select dep-select" data-id="${item.id}" title="Seleccionar actividad de la que depende">
                            <option value="">(Ninguna)</option>
                            ${activities.filter(a => a.id !== item.id).map(a => `
                                <option value="${a.id}" ${item.dependsOn == a.id ? 'selected' : ''}>
                                    #${a.id} - ${escapeHtml(a.name.length > 28 ? a.name.substring(0, 26) + '...' : a.name)}
                                </option>
                            `).join('')}
                        </select>
                        ${depBadgeHtml}
                    </div>
                </td>
                <td>
                    <div class="status-wrapper">
                        <select class="status-select ${item.status}" data-id="${item.id}" ${isBlocked ? 'disabled' : ''} title="${isBlocked ? `Bloqueada hasta que finalice #${parent.id} (${escapeHtml(parent.name)})` : 'Cambiar estado'}">
                            <option value="Pendiente" ${item.status === 'Pendiente' ? 'selected' : ''}>Pendiente</option>
                            <option value="Ejecucion" ${item.status === 'Ejecucion' ? 'selected' : ''}>En Ejecución</option>
                            <option value="Completado" ${item.status === 'Completado' ? 'selected' : ''}>Completado</option>
                            <option value="Fallido" ${item.status === 'Fallido' ? 'selected' : ''}>Fallido</option>
                        </select>
                        ${isBlocked ? `<span class="lock-indicator" title="Bloqueada por #${parent.id} - Debe completarse primero"><i class="fa-solid fa-lock"></i></span>` : ''}
                    </div>
                </td>
                <td>
                    <select class="table-select owner-select" data-id="${item.id}" title="Cambiar responsable de la actividad">
                        ${owners.map(o => `
                            <option value="${escapeHtml(o)}" ${item.owner === o ? 'selected' : ''}>${escapeHtml(o)}</option>
                        `).join('')}
                        ${!owners.includes(item.owner) && item.owner ? `<option value="${escapeHtml(item.owner)}" selected>${escapeHtml(item.owner)}</option>` : ''}
                    </select>
                </td>
                <td><input type="time" class="table-input time-start" data-id="${item.id}" value="${formatTime(item.start)}" title="Hora de inicio de la prueba"></td>
                <td><input type="time" class="table-input time-end" data-id="${item.id}" value="${formatTime(item.end)}" title="Hora de finalización de la prueba"></td>
                <td>
                    <input type="text" class="table-input obs-text ${!item.obs ? 'is-empty' : ''}" data-id="${item.id}" value="${escapeHtml(item.obs || '')}" placeholder="* Observación obligatoria..." title="Observación requerida para seguimiento">
                </td>
                <td style="text-align: center;">
                    <button class="btn-icon-danger delete-act-btn" data-id="${item.id}" title="Eliminar actividad">
                        <i class="fa-solid fa-trash"></i>
                    </button>
                </td>
            `;
            tbody.appendChild(tr);
        });

        attachTableListeners();
    }

    function renderModulesTable() {
        if (!modulesTbody) return;
        modulesTbody.innerHTML = '';
        const modules = getUniqueModules();

        modules.forEach(mod => {
            const modItems = activities.filter(a => a.module === mod);
            const total = modItems.length;
            const completed = modItems.filter(a => a.status === 'Completado').length;

            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td><strong><i class="fa-solid fa-folder"></i> ${escapeHtml(mod)}</strong></td>
                <td>${total} actividades</td>
                <td>${completed} / ${total} (${total > 0 ? Math.round((completed/total)*100) : 0}%)</td>
                <td>
                    <button class="btn-icon-danger delete-mod-btn" data-module="${escapeHtml(mod)}" title="Eliminar Módulo y sus actividades">
                        <i class="fa-solid fa-trash"></i> Eliminar
                    </button>
                </td>
            `;
            modulesTbody.appendChild(tr);
        });

        attachModuleListeners();
    }

    // ==========================================
    // RENDERIZADO DE TABLA DE RESPONSABLES
    // ==========================================
    function renderOwnersTable() {
        if (!ownersTbody) return;
        ownersTbody.innerHTML = '';

        if (owners.length === 0) {
            ownersTbody.innerHTML = `<tr><td colspan="4" style="text-align: center; padding: 25px; color: var(--text-muted); font-size: 13px;">No hay responsables registrados</td></tr>`;
            return;
        }

        owners.forEach(owner => {
            const assigned = activities.filter(a => a.owner === owner);
            const total = assigned.length;
            const completed = assigned.filter(a => a.status === 'Completado').length;
            const percent = total > 0 ? Math.round((completed / total) * 100) : 0;

            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td>
                    <strong><i class="fa-solid fa-user-tag" style="color: var(--accent); margin-right: 6px;"></i> ${escapeHtml(owner)}</strong>
                </td>
                <td>${total} actividades</td>
                <td>${completed} / ${total} (${percent}%)</td>
                <td style="text-align: center;">
                    <button class="btn-icon-secondary edit-owner-btn" data-owner="${escapeHtml(owner)}" title="Editar / Renombrar Responsable">
                        <i class="fa-solid fa-pen-to-square"></i>
                    </button>
                    <button class="btn-icon-danger delete-owner-btn" data-owner="${escapeHtml(owner)}" title="Eliminar Responsable">
                        <i class="fa-solid fa-trash"></i>
                    </button>
                </td>
            `;
            ownersTbody.appendChild(tr);
        });

        attachOwnersListeners();
    }

    // ==========================================
    // LISTENERS DE INTERACCIÓN EN LA TABLA
    // ==========================================
    function attachTableListeners() {
        // 1. Cambio de Estado
        document.querySelectorAll('.status-select').forEach(select => {
            select.addEventListener('change', (e) => {
                const id = parseInt(e.target.getAttribute('data-id'));
                const newStatus = e.target.value;
                const act = activities.find(a => a.id === id);

                if (!act) return;

                if (isActivityBlocked(act)) {
                    const parent = getParentActivity(act);
                    e.target.value = act.status;
                    e.target.className = `status-select ${act.status}`;
                    showToast(`⚠️ Actividad Bloqueada: Requiere que finalice primero la actividad #${parent.id} "${parent.name}".`, 'error', 4500);
                    return;
                }

                openObsModal(act, newStatus, e.target);
            });
        });

        // 2. Cambio de Dependencia
        document.querySelectorAll('.dep-select').forEach(select => {
            select.addEventListener('change', (e) => {
                const id = parseInt(e.target.getAttribute('data-id'));
                const targetParentId = e.target.value ? parseInt(e.target.value) : null;
                const act = activities.find(a => a.id === id);

                if (!act) return;

                if (targetParentId && causesCircularDependency(id, targetParentId)) {
                    alert('No es posible seleccionar esta dependencia porque generaría una dependencia circular entre actividades.');
                    e.target.value = act.dependsOn || '';
                    return;
                }

                act.dependsOn = targetParentId;
                renderTable();
                saveData(false);
                showToast(`Dependencia actualizada para la actividad #${act.id}`, 'info', 2000);
            });
        });

        // 3. Cambio de Responsable directamente desde la fila
        document.querySelectorAll('.owner-select').forEach(select => {
            select.addEventListener('change', (e) => {
                const id = parseInt(e.target.getAttribute('data-id'));
                const act = activities.find(a => a.id === id);
                if (act) {
                    act.owner = e.target.value;
                    renderOwnersTable();
                    saveData(false);
                    showToast(`Responsable de #${act.id} cambiado a "${act.owner}"`, 'info', 2000);
                }
            });
        });

        // 4. Hora Inicio
        document.querySelectorAll('.time-start').forEach(input => {
            input.addEventListener('change', (e) => {
                const id = parseInt(e.target.getAttribute('data-id'));
                const act = activities.find(a => a.id === id);
                if (act) {
                    act.start = e.target.value;
                    saveData(false);
                }
            });
        });

        // 5. Hora Fin
        document.querySelectorAll('.time-end').forEach(input => {
            input.addEventListener('change', (e) => {
                const id = parseInt(e.target.getAttribute('data-id'));
                const act = activities.find(a => a.id === id);
                if (act) {
                    act.end = e.target.value;
                    saveData(false);
                }
            });
        });

        // 6. Observación Directa en Fila (Obligatoria)
        document.querySelectorAll('.obs-text').forEach(input => {
            input.addEventListener('input', (e) => {
                const id = parseInt(e.target.getAttribute('data-id'));
                const act = activities.find(a => a.id === id);
                const val = e.target.value.trim();

                if (val === '') {
                    input.classList.add('is-empty');
                } else {
                    input.classList.remove('is-empty');
                }

                if (act) {
                    act.obs = e.target.value;
                    clearTimeout(obsDebounceTimer);
                    obsDebounceTimer = setTimeout(() => {
                        saveData(false);
                    }, 800);
                }
            });

            input.addEventListener('blur', (e) => {
                clearTimeout(obsDebounceTimer);
                const val = e.target.value.trim();
                if (val === '') {
                    input.classList.add('is-empty');
                    showToast('⚠️ La observación es obligatoria. No olvide registrar las notas de la prueba.', 'error', 3500);
                } else {
                    input.classList.remove('is-empty');
                }
                saveData(false);
            });
        });

        // 7. Eliminar Actividad
        document.querySelectorAll('.delete-act-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const id = parseInt(e.currentTarget.getAttribute('data-id'));
                if (confirm('¿Estás seguro de eliminar esta actividad?')) {
                    activities.forEach(a => {
                        if (a.dependsOn === id) a.dependsOn = null;
                    });
                    activities = activities.filter(a => a.id !== id);
                    renderTable();
                    renderOwnersTable();
                    saveData(true);
                }
            });
        });
    }

    function attachModuleListeners() {
        document.querySelectorAll('.delete-mod-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const modName = e.currentTarget.getAttribute('data-module');
                if (confirm(`¿Estás seguro de eliminar el módulo "${modName}" y todas sus actividades asociadas?`)) {
                    const idsToRemove = activities.filter(a => a.module === modName).map(a => a.id);
                    activities.forEach(a => {
                        if (idsToRemove.includes(a.dependsOn)) a.dependsOn = null;
                    });
                    activities = activities.filter(a => a.module !== modName);
                    populateModulesFilter();
                    renderTable();
                    renderModulesTable();
                    renderOwnersTable();
                    saveData(true);
                }
            });
        });
    }

    function attachOwnersListeners() {
        // Editar / Renombrar Responsable
        document.querySelectorAll('.edit-owner-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const currentOwner = e.currentTarget.getAttribute('data-owner');
                openOwnerModalForEdit(currentOwner);
            });
        });

        // Eliminar Responsable
        document.querySelectorAll('.delete-owner-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const ownerToDelete = e.currentTarget.getAttribute('data-owner');
                const assigned = activities.filter(a => a.owner === ownerToDelete);

                if (assigned.length > 0) {
                    alert(`No se puede eliminar el responsable "${ownerToDelete}" porque tiene ${assigned.length} actividad(es) asignada(s). Reasigne esas actividades a otro responsable antes de eliminarlo.`);
                    return;
                }

                if (confirm(`¿Estás seguro de eliminar el responsable "${ownerToDelete}" del catálogo?`)) {
                    owners = owners.filter(o => o !== ownerToDelete);
                    renderOwnersTable();
                    populateOwnersSelects();
                    renderTable();
                    saveData(true);
                    showToast(`Responsable "${ownerToDelete}" eliminado correctamente.`, 'info');
                }
            });
        });
    }

    // ==========================================
    // MODAL DE RESPONSABLES (CREAR / EDITAR)
    // ==========================================
    const ownerModal = document.getElementById('owner-modal');
    const ownerForm = document.getElementById('add-owner-form');
    const ownerModalTitle = document.getElementById('owner-modal-title');
    const editOwnerOriginalInput = document.getElementById('edit-owner-original-name');
    const newOwnerNameInput = document.getElementById('new-owner-name');
    const closeOwnerModalBtn = document.getElementById('close-owner-modal-btn');
    const cancelOwnerModalBtn = document.getElementById('cancel-owner-modal-btn');
    const openOwnerModalBtn = document.getElementById('open-owner-modal-btn');
    const quickAddOwnerBtn = document.getElementById('quick-add-owner-btn');
    const saveOwnerBtn = document.getElementById('save-owner-btn');

    function openOwnerModalForCreate() {
        if (!ownerModal) return;
        ownerModalTitle.innerHTML = '<i class="fa-solid fa-user-plus"></i> Agregar Nuevo Responsable';
        editOwnerOriginalInput.value = '';
        newOwnerNameInput.value = '';
        if (saveOwnerBtn) saveOwnerBtn.textContent = 'Guardar Responsable';
        ownerModal.classList.add('active');
        setTimeout(() => newOwnerNameInput.focus(), 100);
    }

    function openOwnerModalForEdit(ownerName) {
        if (!ownerModal) return;
        ownerModalTitle.innerHTML = '<i class="fa-solid fa-pen-to-square"></i> Editar Responsable';
        editOwnerOriginalInput.value = ownerName;
        newOwnerNameInput.value = ownerName;
        if (saveOwnerBtn) saveOwnerBtn.textContent = 'Actualizar Responsable';
        ownerModal.classList.add('active');
        setTimeout(() => newOwnerNameInput.focus(), 100);
    }

    function closeOwnerModal() {
        if (ownerModal) ownerModal.classList.remove('active');
        if (ownerForm) ownerForm.reset();
        editOwnerOriginalInput.value = '';
    }

    if (openOwnerModalBtn) openOwnerModalBtn.addEventListener('click', openOwnerModalForCreate);
    if (quickAddOwnerBtn) quickAddOwnerBtn.addEventListener('click', openOwnerModalForCreate);
    if (closeOwnerModalBtn) closeOwnerModalBtn.addEventListener('click', closeOwnerModal);
    if (cancelOwnerModalBtn) cancelOwnerModalBtn.addEventListener('click', closeOwnerModal);

    if (ownerForm) {
        ownerForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const originalName = editOwnerOriginalInput.value.trim();
            const newName = newOwnerNameInput.value.trim();

            if (!newName) return;

            if (originalName) {
                // Modo Edición
                if (newName !== originalName) {
                    if (owners.some(o => o.toLowerCase() === newName.toLowerCase())) {
                        alert('Ya existe un responsable con ese nombre.');
                        return;
                    }
                    const idx = owners.indexOf(originalName);
                    if (idx !== -1) owners[idx] = newName;

                    // Actualizar en cascada todas las actividades que tenían este responsable
                    activities.forEach(a => {
                        if (a.owner === originalName) a.owner = newName;
                    });

                    showToast(`Responsable "${originalName}" actualizado a "${newName}".`, 'success');
                }
            } else {
                // Modo Creación
                if (owners.some(o => o.toLowerCase() === newName.toLowerCase())) {
                    alert('Este responsable ya se encuentra registrado.');
                    return;
                }
                owners.push(newName);
                showToast(`Responsable "${newName}" registrado exitosamente.`, 'success');
            }

            renderOwnersTable();
            populateOwnersSelects();
            renderTable();
            saveData(true);

            // Si se creó desde el modal de agregar actividad, seleccionarlo automáticamente
            const newOwnerSelect = document.getElementById('new-owner');
            if (newOwnerSelect) newOwnerSelect.value = newName;

            closeOwnerModal();
        });
    }

    // ==========================================
    // MODAL DE OBSERVACIÓN OBLIGATORIA
    // ==========================================
    const obsModal = document.getElementById('obs-modal');
    const obsForm = document.getElementById('obs-form');
    const obsTargetStatus = document.getElementById('obs-target-status');
    const obsActivityName = document.getElementById('obs-activity-name');
    const obsActivityOwner = document.getElementById('obs-activity-owner');
    const requiredObsInput = document.getElementById('required-obs-input');
    const closeObsModalBtn = document.getElementById('close-obs-modal-btn');
    const cancelObsModalBtn = document.getElementById('cancel-obs-modal-btn');

    function openObsModal(act, targetStatus, selectElement) {
        pendingStatusChange = {
            act: act,
            targetStatus: targetStatus,
            selectElement: selectElement,
            oldStatus: act.status
        };

        if (obsTargetStatus) {
            obsTargetStatus.textContent = targetStatus;
            obsTargetStatus.className = `obs-status-pill status-select ${targetStatus}`;
        }
        if (obsActivityName) obsActivityName.textContent = `#${act.id} - ${act.name}`;
        if (obsActivityOwner) obsActivityOwner.textContent = act.owner;

        if (requiredObsInput) {
            requiredObsInput.value = act.obs || '';
            setTimeout(() => requiredObsInput.focus(), 100);
        }

        if (obsModal) obsModal.classList.add('active');
    }

    function closeAndRevertObsModal() {
        if (pendingStatusChange && pendingStatusChange.selectElement) {
            pendingStatusChange.selectElement.value = pendingStatusChange.oldStatus;
            pendingStatusChange.selectElement.className = `status-select ${pendingStatusChange.oldStatus}`;
        }
        pendingStatusChange = null;
        if (obsModal) obsModal.classList.remove('active');
    }

    if (closeObsModalBtn) closeObsModalBtn.addEventListener('click', closeAndRevertObsModal);
    if (cancelObsModalBtn) cancelObsModalBtn.addEventListener('click', closeAndRevertObsModal);

    if (obsForm) {
        obsForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const obsText = requiredObsInput.value.trim();

            if (!obsText) {
                alert('La observación es obligatoria. Por favor detalle el resultado o motivo.');
                requiredObsInput.focus();
                return;
            }

            if (pendingStatusChange) {
                const { act, targetStatus } = pendingStatusChange;
                act.status = targetStatus;
                act.obs = obsText;

                // Sugerir hora actual si no tenía hora registrada
                if (targetStatus === 'Ejecucion' && !act.start) {
                    const now = new Date();
                    act.start = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;
                }
                if (targetStatus === 'Completado' && !act.end) {
                    const now = new Date();
                    act.end = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;
                }

                pendingStatusChange = null;
                if (obsModal) obsModal.classList.remove('active');

                renderTable();
                renderOwnersTable();
                saveData(true);
                showToast(`Estado de #${act.id} actualizado a "${targetStatus}" con observación guardada.`, 'success', 3000);
            }
        });
    }

    // ==========================================
    // ACTUALIZACIÓN DE KPIS Y GRÁFICOS
    // ==========================================
    function updateDashboard() {
        const total = activities.length;
        const completed = activities.filter(a => a.status === 'Completado').length;
        const running = activities.filter(a => a.status === 'Ejecucion').length;
        const failed = activities.filter(a => a.status === 'Fallido').length;
        const percent = total > 0 ? Math.round((completed / total) * 100) : 0;

        if (kpiTotal) kpiTotal.textContent = total;
        if (kpiOk) kpiOk.textContent = completed;
        if (kpiRun) kpiRun.textContent = running;
        if (kpiError) kpiError.textContent = failed;
        if (kpiPercent) kpiPercent.textContent = percent + '%';

        updateCharts(completed, running, failed, total - (completed + running + failed));
        updateModuleProgressGrid();
    }

    function updateCharts(ok, run, err, pend) {
        const canvasDoughnut = document.getElementById('statusChart');
        if (canvasDoughnut) {
            const ctxDoughnut = canvasDoughnut.getContext('2d');
            if (statusChartInstance) {
                statusChartInstance.data.datasets[0].data = [ok, run, err, pend];
                statusChartInstance.update();
            } else {
                statusChartInstance = new Chart(ctxDoughnut, {
                    type: 'doughnut',
                    data: {
                        labels: ['Completadas', 'En Ejecución', 'Fallidas', 'Pendientes'],
                        datasets: [{
                            data: [ok, run, err, pend],
                            backgroundColor: ['#10b981', '#f59e0b', '#ef4444', '#cbd5e1'],
                            borderWidth: 2,
                            borderColor: '#ffffff'
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: {
                            legend: {
                                position: 'bottom',
                                labels: { boxWidth: 12, font: { family: 'Inter', size: 12 } }
                            }
                        }
                    }
                });
            }
        }

        const canvasBar = document.getElementById('modulesBarChart');
        if (canvasBar) {
            const modules = getUniqueModules();
            const modulePercentages = modules.map(mod => {
                const items = activities.filter(a => a.module === mod);
                const t = items.length;
                const c = items.filter(a => a.status === 'Completado').length;
                return t > 0 ? Math.round((c / t) * 100) : 0;
            });

            const ctxBar = canvasBar.getContext('2d');
            if (modulesBarChartInstance) {
                modulesBarChartInstance.data.labels = modules;
                modulesBarChartInstance.data.datasets[0].data = modulePercentages;
                modulesBarChartInstance.update();
            } else {
                modulesBarChartInstance = new Chart(ctxBar, {
                    type: 'bar',
                    data: {
                        labels: modules,
                        datasets: [{
                            label: '% de Avance',
                            data: modulePercentages,
                            backgroundColor: '#2563eb',
                            borderRadius: 6
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        indexAxis: 'y',
                        scales: {
                            x: {
                                beginAtZero: true,
                                max: 100,
                                ticks: { callback: (val) => val + '%' }
                            }
                        },
                        plugins: {
                            legend: { display: false }
                        }
                    }
                });
            }
        }
    }

    function updateModuleProgressGrid() {
        const container = document.getElementById('modules-progress-list');
        if (!container) return;
        container.innerHTML = '';

        const modules = getUniqueModules();

        modules.forEach(mod => {
            const modItems = activities.filter(a => a.module === mod);
            const modTotal = modItems.length;
            const modCompleted = modItems.filter(a => a.status === 'Completado').length;
            const modPercent = modTotal > 0 ? Math.round((modCompleted / modTotal) * 100) : 0;

            const div = document.createElement('div');
            div.className = 'module-progress-item';
            div.innerHTML = `
                <div class="module-progress-info">
                    <span>${escapeHtml(mod)}</span>
                    <span><strong>${modPercent}%</strong> (${modCompleted}/${modTotal})</span>
                </div>
                <div class="progress-bar-bg">
                    <div class="progress-bar-fill" style="width: ${modPercent}%;"></div>
                </div>
            `;
            container.appendChild(div);
        });
    }

    // ==========================================
    // REINICIAR DATOS (RESET EN SERVIDOR)
    // ==========================================
    if (resetBtn) {
        resetBtn.addEventListener('click', async () => {
            if (confirm('¿Estás seguro de restablecer todos los avances a su estado inicial? Esta acción reiniciará los datos en el servidor IIS para TODOS los usuarios.')) {
                if (apiEndpoint === 'api.ashx' || apiEndpoint === 'api.php') {
                    setSyncStatus('saving', 'Restableciendo...');
                    try {
                        const res = await fetch(`${apiEndpoint}?action=reset&t=${Date.now()}`);
                        if (res.ok) {
                            await fetchData(false);
                            showToast('Datos reiniciados con éxito en el servidor IIS', 'success');
                            return;
                        }
                    } catch (e) {
                        console.error(e);
                    }
                }

                localStorage.removeItem('alwayson_data_v2');
                localStorage.removeItem('alwayson_activities');
                owners = [...defaultOwners];
                activities = (typeof initialPlanData !== 'undefined') ? JSON.parse(JSON.stringify(initialPlanData)) : [];
                populateModulesFilter();
                populateOwnersSelects();
                updateDashboard();
                renderTable();
                renderModulesTable();
                renderOwnersTable();
                showToast('Datos restablecidos al estado inicial', 'info');
            }
        });
    }

    // Botón manual de sincronización
    if (manualSyncBtn) {
        manualSyncBtn.addEventListener('click', () => {
            const icon = manualSyncBtn.querySelector('i');
            if (icon) icon.classList.add('fa-spin');
            fetchData(false).finally(() => {
                setTimeout(() => {
                    if (icon) icon.classList.remove('fa-spin');
                }, 600);
            });
        });
    }

    // Filtros de búsqueda
    if (filterModule) filterModule.addEventListener('change', renderTable);
    if (searchActivity) searchActivity.addEventListener('input', renderTable);

    // ==========================================
    // MODALES (NUEVA ACTIVIDAD / NUEVO MÓDULO)
    // ==========================================
    const modal = document.getElementById('activity-modal');
    const openModalBtn = document.getElementById('open-modal-btn');
    const closeModalBtn = document.getElementById('close-modal-btn');
    const cancelModalBtn = document.getElementById('cancel-modal-btn');
    const addActivityForm = document.getElementById('add-activity-form');

    if (openModalBtn) {
        openModalBtn.addEventListener('click', () => {
            populateModulesFilter();
            populateOwnersSelects();
            modal.classList.add('active');
        });
    }
    if (closeModalBtn) closeModalBtn.addEventListener('click', () => modal.classList.remove('active'));
    if (cancelModalBtn) cancelModalBtn.addEventListener('click', () => modal.classList.remove('active'));

    const moduleModal = document.getElementById('module-modal');
    const openModuleModalBtn = document.getElementById('open-module-modal-btn');
    const closeModuleModalBtn = document.getElementById('close-module-modal-btn');
    const cancelModuleModalBtn = document.getElementById('cancel-module-modal-btn');
    const addModuleForm = document.getElementById('add-module-form');

    if (openModuleModalBtn) {
        openModuleModalBtn.addEventListener('click', () => moduleModal.classList.add('active'));
    }
    if (closeModuleModalBtn) closeModuleModalBtn.addEventListener('click', () => moduleModal.classList.remove('active'));
    if (cancelModuleModalBtn) cancelModuleModalBtn.addEventListener('click', () => moduleModal.classList.remove('active'));

    window.addEventListener('click', (e) => {
        if (e.target === modal) modal.classList.remove('active');
        if (e.target === moduleModal) moduleModal.classList.remove('active');
        if (e.target === ownerModal) closeOwnerModal();
        if (e.target === obsModal) closeAndRevertObsModal();
    });

    if (addActivityForm) {
        addActivityForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const moduleName = document.getElementById('new-module').value.trim();
            const activityName = document.getElementById('new-name').value.trim();
            const ownerName = document.getElementById('new-owner').value.trim();
            const dependsVal = document.getElementById('new-depends').value;
            const startTime = document.getElementById('new-start').value;
            const endTime = document.getElementById('new-end').value;
            const obsText = document.getElementById('new-obs').value.trim();

            if (!moduleName || !activityName || !ownerName) return;

            const newId = activities.length > 0 ? Math.max(...activities.map(a => a.id)) + 1 : 1;
            
            activities.push({
                id: newId,
                module: moduleName,
                name: activityName,
                status: "Pendiente",
                owner: ownerName,
                start: startTime || "",
                end: endTime || "",
                obs: obsText || "",
                dependsOn: dependsVal ? parseInt(dependsVal) : null
            });

            populateModulesFilter();
            renderTable();
            renderModulesTable();
            renderOwnersTable();
            saveData(true);

            addActivityForm.reset();
            modal.classList.remove('active');
        });
    }

    if (addModuleForm) {
        addModuleForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const newModName = document.getElementById('new-module-name').value.trim();
            if (!newModName) return;

            const existingModules = getUniqueModules();
            if (existingModules.includes(newModName)) {
                alert('Este módulo ya existe.');
                return;
            }

            const newId = activities.length > 0 ? Math.max(...activities.map(a => a.id)) + 1 : 1;
            activities.push({
                id: newId,
                module: newModName,
                name: "Actividad Inicial de Certificación",
                status: "Pendiente",
                owner: owners.length > 0 ? owners[0] : "DBA",
                start: "",
                end: "",
                obs: "Módulo creado manualmente",
                dependsOn: null
            });

            populateModulesFilter();
            renderTable();
            renderModulesTable();
            renderOwnersTable();
            saveData(true);

            addModuleForm.reset();
            moduleModal.classList.remove('active');
        });
    }

    // ==========================================
    // INICIALIZACIÓN Y POLLING (CADA 3.5 SEGUNDOS)
    // ==========================================
    fetchData(false).then(() => {
        pollingInterval = setInterval(() => {
            fetchData(true);
        }, 3500);
    });
});
