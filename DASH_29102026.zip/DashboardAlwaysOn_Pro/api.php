<?php
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-cache, no-store, must-revalidate');
header('Pragma: no-cache');
header('Expires: 0');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

$dataPath = __DIR__ . '/data.json';
$initialPath = __DIR__ . '/initial_data.json';

$action = isset($_GET['action']) ? $_GET['action'] : '';

// 1. Reset
if ($action === 'reset') {
    if (file_exists($initialPath)) {
        copy($initialPath, $dataPath);
    } else {
        file_put_contents($dataPath, '[]');
    }
    echo json_encode(["success" => true, "message" => "Datos restablecidos con éxito."]);
    exit;
}

// 2. GET
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    if (!file_exists($dataPath)) {
        if (file_exists($initialPath)) {
            copy($initialPath, $dataPath);
        } else {
            file_put_contents($dataPath, '[]');
        }
    }
    echo file_get_contents($dataPath);
    exit;
}

// 3. POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $body = file_get_contents('php://input');
    if (empty($body)) {
        http_response_code(400);
        echo json_encode(["success" => false, "error" => "El contenido recibido está vacío."]);
        exit;
    }

    $fp = fopen($dataPath, 'w');
    if ($fp && flock($fp, LOCK_EX)) {
        fwrite($fp, $body);
        fflush($fp);
        flock($fp, LOCK_UN);
        fclose($fp);
        echo json_encode(["success" => true, "message" => "Guardado correctamente."]);
    } else {
        http_response_code(500);
        echo json_encode(["success" => false, "error" => "No se pudo escribir en data.json. Verifique permisos de escritura en IIS."]);
    }
    exit;
}

http_response_code(405);
echo json_encode(["success" => false, "error" => "Método no permitido."]);
?>
