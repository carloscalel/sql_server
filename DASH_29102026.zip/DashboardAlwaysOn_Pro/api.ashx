<%@ WebHandler Language="C#" Class="AlwaysOnApiHandler" %>

using System;
using System.Web;
using System.IO;
using System.Text;

public class AlwaysOnApiHandler : IHttpHandler {
    private static readonly object _fileLock = new object();

    public void ProcessRequest(HttpContext context) {
        // Encabezados para evitar almacenamiento en caché
        context.Response.ContentType = "application/json; charset=utf-8";
        context.Response.Headers.Add("Cache-Control", "no-cache, no-store, must-revalidate");
        context.Response.Headers.Add("Pragma", "no-cache");
        context.Response.Headers.Add("Expires", "0");
        
        // Habilitar CORS por si se accede mediante IP o subdominio
        context.Response.Headers.Add("Access-Control-Allow-Origin", "*");
        context.Response.Headers.Add("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
        context.Response.Headers.Add("Access-Control-Allow-Headers", "Content-Type");

        if (context.Request.HttpMethod == "OPTIONS") {
            context.Response.StatusCode = 200;
            return;
        }

        string dataFilePath = context.Server.MapPath("~/data.json");
        string initialFilePath = context.Server.MapPath("~/initial_data.json");

        try {
            string action = context.Request.QueryString["action"];

            // 1. Acción de Reset / Reiniciar datos
            if (action == "reset") {
                lock (_fileLock) {
                    if (File.Exists(initialFilePath)) {
                        File.Copy(initialFilePath, dataFilePath, true);
                    } else {
                        // Fallback si no existe initial_data.json
                        File.WriteAllText(dataFilePath, "[]", Encoding.UTF8);
                    }
                }
                context.Response.Write("{\"success\":true,\"message\":\"Datos restablecidos con éxito.\"}");
                return;
            }

            // 2. Obtener datos (GET)
            if (context.Request.HttpMethod == "GET") {
                lock (_fileLock) {
                    if (!File.Exists(dataFilePath)) {
                        if (File.Exists(initialFilePath)) {
                            File.Copy(initialFilePath, dataFilePath);
                        } else {
                            File.WriteAllText(dataFilePath, "[]", Encoding.UTF8);
                        }
                    }
                    string jsonContent = File.ReadAllText(dataFilePath, Encoding.UTF8);
                    context.Response.Write(jsonContent);
                }
                return;
            }

            // 3. Guardar cambios (POST)
            if (context.Request.HttpMethod == "POST") {
                string body;
                using (var reader = new StreamReader(context.Request.InputStream, Encoding.UTF8)) {
                    body = reader.ReadToEnd();
                }

                if (string.IsNullOrWhiteSpace(body)) {
                    context.Response.StatusCode = 400;
                    context.Response.Write("{\"success\":false,\"error\":\"El contenido recibido está vacío.\"}");
                    return;
                }

                // Guardar en el archivo compartido data.json
                lock (_fileLock) {
                    File.WriteAllText(dataFilePath, body, Encoding.UTF8);
                }

                context.Response.Write("{\"success\":true,\"message\":\"Guardado correctamente en IIS.\"}");
                return;
            }

            context.Response.StatusCode = 405;
            context.Response.Write("{\"success\":false,\"error\":\"Método HTTP no permitido.\"}");
        }
        catch (UnauthorizedAccessException uex) {
            context.Response.StatusCode = 500;
            context.Response.Write("{\"success\":false,\"error\":\"Permiso denegado en IIS: Conceda permisos de Modificar/Escritura a 'IIS_IUSRS' en la carpeta.\",\"detail\":\"" + HttpUtility.JavaScriptStringEncode(uex.Message) + "\"}");
        }
        catch (Exception ex) {
            context.Response.StatusCode = 500;
            context.Response.Write("{\"success\":false,\"error\":\"Error en el servidor: " + HttpUtility.JavaScriptStringEncode(ex.Message) + "\"}");
        }
    }

    public bool IsReusable {
        get { return true; }
    }
}
