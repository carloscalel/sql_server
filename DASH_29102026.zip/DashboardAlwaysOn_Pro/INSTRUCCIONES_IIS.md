# Guía Rápida de Despliegue en IIS (Internet Information Services)

Este dashboard está configurado para funcionar **sin base de datos**, compartiendo un archivo central `data.json` para que todos los usuarios vean exactamente los mismos resultados en tiempo real.

---

### Pasos para Publicar en IIS:

#### 1. Copiar la Carpeta al Servidor
Copia la carpeta completa del proyecto (por ejemplo `DashboardAlwaysOn_Pro`) dentro del directorio web de IIS:
> `C:\inetpub\wwwroot\AlwaysOn`

*(O crea una nueva aplicación / sitio web en el Administrador de IIS apuntando a esta carpeta).*

---

#### 2. Permiso de Escritura para IIS (Paso Crucial)
Dado que el dashboard guarda los avances directamente en `data.json`, el usuario del grupo de trabajo de IIS necesita permiso para escribir en la carpeta:

1. Haz clic derecho sobre la carpeta del proyecto (`AlwaysOn` o `DashboardAlwaysOn_Pro`) y selecciona **Propiedades**.
2. Ve a la pestaña **Seguridad** y haz clic en **Editar...**.
3. Haz clic en **Agregar...** y escribe:
   `IIS_IUSRS`
4. Presiona **Aceptar** y marca la casilla **Modificar** (esto activará Lectura y Escritura).
5. Haz clic en **Aplicar** y **Aceptar**.

> **Nota:** Si tu Application Pool utiliza una identidad específica (por ejemplo `AppPoolIdentity` o `NetworkService`), asegúrate de concederle permiso de Modificar a dicha identidad o a `IIS_IUSRS`.

---

#### 3. Verificar que ASP.NET esté habilitado en IIS
El archivo `api.ashx` utiliza ASP.NET nativo de Windows (no requiere compilación ni dependencias externas):
- En Windows Server: **Server Manager** > **Add Roles and Features** > **Web Server (IIS)** > **Web Server** > **Application Development** > Asegurarse de tener marcado **ASP.NET 4.8** (o 4.x).
- En Windows 10/11: **Activar o desactivar las características de Windows** > **Internet Information Services** > **Servicios World Wide Web** > **Características de desarrollo de aplicaciones** > **ASP.NET 4.8**.

*(Opcional: Si tu servidor tiene soporte para PHP en lugar de ASP.NET, el archivo `api.php` ya viene incluido y el sistema lo detectará automáticamente).*

---

### ¿Cómo funciona la sincronización en tiempo real?
- **Actualización Compartida:** Cuando un usuario cambia el estado de una actividad, añade una nota o modifica una fecha, se guarda inmediatamente en el archivo compartido `data.json` del servidor.
- **Sondeo Automático (Polling):** Cada 3.5 segundos, las pantallas de todos los usuarios consultan el servidor en segundo plano. Si detectan que otro compañero actualizó alguna actividad, el dashboard se actualiza automáticamente sin parpadeos y sin interrumpir a quien esté escribiendo.
- **Indicador de Estado:** En la esquina superior derecha se muestra el estado en vivo:
  - 🟢 **En Línea (Sincronizado)** con la hora exacta de la última comprobación.
  - 🟡 **Guardando...** al registrar un cambio.
  - 🔄 **Botón de refresco manual** para forzar la actualización al instante.
- **Reinicio Centralizado:** El botón "Reiniciar Datos" en el menú lateral restablece los 38 puntos de certificación originales tanto para el usuario como para el servidor central.
