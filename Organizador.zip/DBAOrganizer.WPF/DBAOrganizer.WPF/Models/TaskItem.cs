using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Collections.ObjectModel;
using System;
using System.Linq;

namespace DBAOrganizer.WPF.Models
{
    public class ChecklistItemModel : INotifyPropertyChanged
    {
        private string _text = "Nuevo requisito";
        private bool _isDone = false;

        public string Text
        {
            get => _text;
            set { _text = value; OnPropertyChanged(); }
        }

        public bool IsDone
        {
            get => _isDone;
            set { _isDone = value; OnPropertyChanged(); }
        }

        public event PropertyChangedEventHandler? PropertyChanged;
        protected void OnPropertyChanged([CallerMemberName] string? propertyName = null) => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
    }

    public class TaskItem : INotifyPropertyChanged
    {
        private string _id = Guid.NewGuid().ToString();
        private string _ticket = string.Empty;
        private string _title = "Migrar BD a SQL Server 2026";
        private string _creationDate = "29/08/2026";
        private DateTime? _selectedCreationDate = DateTime.Now;
        private string _dueDate = "31/08/2026";
        private DateTime? _selectedDueDate = DateTime.Now.AddDays(2);
        private string _priority = "Normal";
        private string _tag = "SQL Server";
        private string _assigned = "Admin";
        private string _status = "En QA";
        
        private string _repoUrl = "https://github.com/proyecto/db-migration";
        private string _buildCommand = "docker build -t db-migrate .";
        private string _deployCommand = "kubectl apply -f deployment.yaml";
        private string _rollbackCommand = "Restaurar backup desde /backups/backup_09032026.bak";
        
        private string _markdownNotes = "# Notas Técnicas\n\n* **Servidor**: AWS RDS SQL Server\n* **Puerto**: 1433\n* **Estado**: En proceso de pruebas.\n\n## \uD83D\uDCC4 BITÁCORA\n| Fecha | Quién | Acción |\n|-------|-------|--------|\n| 29/08 | Admin | Se usa migrate_v2.sql |\n| 28/08 | QA | Pruebas OK en Staging |";

        private string _attachmentPath = string.Empty;
        private string _activityLog = "[29/08/2026 10:30] [Admin] Se usa migrate_v2.sql por índices.\n[28/08/2026 16:00] [QA] Pruebas OK en Staging.";

        private ObservableCollection<ChecklistItemModel> _checklistItems = new()
        {
            new ChecklistItemModel { Text = "Código compilado", IsDone = true },
            new ChecklistItemModel { Text = "Pruebas unitarias OK", IsDone = true },
            new ChecklistItemModel { Text = "Code Review aprobado", IsDone = true },
            new ChecklistItemModel { Text = "Pruebas de integración OK", IsDone = true },
            new ChecklistItemModel { Text = "Seguridad OK", IsDone = true },
            new ChecklistItemModel { Text = "Rendimiento OK (pendiente)", IsDone = false }
        };

        public TaskItem()
        {
            _checklistItems.CollectionChanged += (s, e) => { OnPropertyChanged(nameof(ChecklistSummary)); };
            foreach (var item in _checklistItems)
            {
                item.PropertyChanged += (s, e) => { if (e.PropertyName == nameof(ChecklistItemModel.IsDone)) OnPropertyChanged(nameof(ChecklistSummary)); };
            }
        }

        public string Id { get => _id; set { _id = value; OnPropertyChanged(); } }
        public string Ticket { get => _ticket; set { _ticket = value; OnPropertyChanged(); } }
        public string Title { get => _title; set { _title = value; OnPropertyChanged(); } }
        public string CreationDate { get => _creationDate; set { _creationDate = value; OnPropertyChanged(); } }
        public DateTime? SelectedCreationDate { get => _selectedCreationDate; set { _selectedCreationDate = value; OnPropertyChanged(); if (value.HasValue) CreationDate = value.Value.ToString("dd/MM/yyyy"); } }
        public string DueDate { get => _dueDate; set { _dueDate = value; OnPropertyChanged(); } }
        public DateTime? SelectedDueDate { get => _selectedDueDate; set { _selectedDueDate = value; OnPropertyChanged(); if (value.HasValue) DueDate = value.Value.ToString("dd/MM/yyyy"); } }
        public string Priority { get => _priority; set { _priority = value; OnPropertyChanged(); } }
        public string Tag { get => _tag; set { _tag = value; OnPropertyChanged(); } }
        public string Assigned { get => _assigned; set { _assigned = value; OnPropertyChanged(); } }
        public string Status { get => _status; set { _status = value; OnPropertyChanged(); } }
        public string RepoUrl { get => _repoUrl; set { _repoUrl = value; OnPropertyChanged(); } }
        public string BuildCommand { get => _buildCommand; set { _buildCommand = value; OnPropertyChanged(); } }
        public string DeployCommand { get => _deployCommand; set { _deployCommand = value; OnPropertyChanged(); } }
        public string RollbackCommand { get => _rollbackCommand; set { _rollbackCommand = value; OnPropertyChanged(); } }
        public string MarkdownNotes { get => _markdownNotes; set { _markdownNotes = value; OnPropertyChanged(); } }
        public string AttachmentPath { get => _attachmentPath; set { _attachmentPath = value; OnPropertyChanged(); } }
        public string ActivityLog { get => _activityLog; set { _activityLog = value; OnPropertyChanged(); } }

        public ObservableCollection<ChecklistItemModel> ChecklistItems
        {
            get => _checklistItems;
            set
            {
                _checklistItems = value;
                OnPropertyChanged();
                OnPropertyChanged(nameof(ChecklistSummary));
            }
        }

        public string ChecklistSummary
        {
            get
            {
                if (ChecklistItems == null || ChecklistItems.Count == 0) return "0/0";
                int total = ChecklistItems.Count;
                int checkedCount = ChecklistItems.Count(c => c.IsDone);
                return $"{checkedCount}/{total}";
            }
        }

        public event PropertyChangedEventHandler? PropertyChanged;
        protected void OnPropertyChanged([CallerMemberName] string? propertyName = null) => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
    }

    public class ColumnModel : INotifyPropertyChanged
    {
        private string _name = string.Empty;
        public string Name { get => _name; set { _name = value; OnPropertyChanged(); } }
        public ObservableCollection<TaskItem> Tasks { get; set; } = new();
        public ObservableCollection<TaskItem> FilteredTasks { get; set; } = new();

        public event PropertyChangedEventHandler? PropertyChanged;
        protected void OnPropertyChanged([CallerMemberName] string? propertyName = null) => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
    }
}