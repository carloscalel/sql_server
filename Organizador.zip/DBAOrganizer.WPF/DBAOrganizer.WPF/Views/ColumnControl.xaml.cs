using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using DBAOrganizer.WPF.Models;
using DBAOrganizer.WPF.ViewModels;
using System;

namespace DBAOrganizer.WPF.Views
{
    public partial class ColumnControl : UserControl
    {
        private Point _startPoint;

        public ColumnControl()
        {
            InitializeComponent();
        }

        private void ListBox_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            _startPoint = e.GetPosition(null);
        }

        private void ListBox_MouseMove(object sender, MouseEventArgs e)
        {
            Point mousePos = e.GetPosition(null);
            Vector diff = _startPoint - mousePos;

            if (e.LeftButton == MouseButtonState.Pressed &&
                (Math.Abs(diff.X) > SystemParameters.MinimumHorizontalDragDistance ||
                 Math.Abs(diff.Y) > SystemParameters.MinimumVerticalDragDistance))
            {
                if (sender is ListBox listBox && listBox.SelectedItem is TaskItem task)
                {
                    DataObject dragData = new DataObject("TaskItemFormat", task);
                    DragDrop.DoDragDrop(listBox, dragData, DragDropEffects.Move);
                }
            }
        }

        private void Column_Drop(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent("TaskItemFormat"))
            {
                TaskItem? task = e.Data.GetData("TaskItemFormat") as TaskItem;
                if (sender is Border border && border.Tag is string targetColumnName && task != null)
                {
                    if (DataContext is ColumnModel col && Window.GetWindow(this).DataContext is MainViewModel vm)
                    {
                        vm.MoveTaskToColumn(task, targetColumnName);
                    }
                }
            }
        }
    }
}