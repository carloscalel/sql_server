﻿using DBAOrganizer.WPF.Models;
using Markdig;
using Microsoft.Web.WebView2.Core;
using Microsoft.Web.WebView2.Wpf;
using System;
using System.IO;
using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;

namespace DBAOrganizer.WPF.Views
{
    public partial class TaskDetailControl : UserControl
    {
        private System.Threading.Timer? _previewTimer; // 🔥 Hacerlo nullable

        public TaskDetailControl()
        {
            InitializeComponent();

            // Inicializar WebView2
            this.Loaded += async (s, e) =>
            {
                try
                {
                    await MarkdownBrowser.EnsureCoreWebView2Async(null);
                }
                catch (Exception ex)
                {
                    System.Diagnostics.Debug.WriteLine($"Error inicializando WebView2: {ex.Message}");
                }
            };
        }

        // 🔥 Evento cuando cambia el texto del editor
        private void MarkdownEditor_TextChanged(object sender, TextChangedEventArgs e)
        {
            // Actualizar en tiempo real SIEMPRE (no solo cuando está en vista previa)
            UpdatePreviewDelayed();
        }

        // 🔥 Evento cuando cambiamos de pestaña en el editor markdown
        private void InnerMarkdownTab_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (e.Source is TabControl tc)
            {
                // Si la pestaña seleccionada es la de Vista Previa (índice 1)
                if (tc.SelectedIndex == 1)
                {
                    RenderPreview();
                }
            }
        }

        // 🔥 Actualización con delay para no saturar
        private void UpdatePreviewDelayed()
        {
            // Cancela el timer anterior si existe
            _previewTimer?.Dispose();

            // Espera 300ms después de que el usuario deje de escribir
            _previewTimer = new System.Threading.Timer(
                _ =>
                {
                    // Dispatcher necesario para UI thread
                    Dispatcher.Invoke(() => RenderPreview());
                },
                null,
                200,
                System.Threading.Timeout.Infinite
            );
        }

        // 🔥 Renderiza la vista previa
        private void RenderPreview()
        {
            if (MarkdownBrowser == null || !(DataContext is TaskItem task))
                return;

            try
            {
                string markdown = task.MarkdownNotes ?? string.Empty;
                string html = ConvertMarkdownToHtml(markdown);

                // WebView2 usa NavigateToString directamente y funciona mucho mejor
                Dispatcher.Invoke(async () =>
                {
                    try
                    {
                        // Asegurar que CoreWebView2 está inicializado
                        if (MarkdownBrowser.CoreWebView2 == null)
                        {
                            await MarkdownBrowser.EnsureCoreWebView2Async(null);
                        }

                        MarkdownBrowser.NavigateToString(html);
                    }
                    catch (Exception ex)
                    {
                        System.Diagnostics.Debug.WriteLine($"Error en WebView2: {ex.Message}");
                    }
                });
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error renderizando Markdown: " + ex.Message);
            }
        }

        // 🔥 Convierte Markdown a HTML usando Markdig
        private string ConvertMarkdownToHtml(string markdown)
        {
            bool isDarkMode = GetIsDarkModeFromApplication();

            var pipeline = new MarkdownPipelineBuilder()
                .UseAdvancedExtensions()
                .UseEmphasisExtras()
                .UseListExtras()
                .UsePipeTables()
                .UseTaskLists()
                .UseAutoIdentifiers()
                .UseFootnotes()
                .UseDefinitionLists()
                .UseCustomContainers()
                .UseDiagrams()
                .UseMediaLinks()
                .UseSmartyPants()
                .Build();

            if (string.IsNullOrWhiteSpace(markdown))
            {
                // ... (código para markdown vacío)
            }

            // 🔥 Convertir Markdown a HTML
            string html = Markdig.Markdown.ToHtml(markdown, pipeline);

            // 🔥 Colores según el tema
            string bodyBg = isDarkMode ? "#1e1e1e" : "#FFFFFF";
            string textColor = isDarkMode ? "#d4d4d4" : "#242424";
            string borderColor = isDarkMode ? "#3d3d3d" : "#E1DFDD";
            string thBg = isDarkMode ? "#2d2d2d" : "#F3F2F1";
            string thText = isDarkMode ? "#ffffff" : "#201F1E";
            string codeBg = isDarkMode ? "#2d2d2d" : "#F3F2F1";
            string codeText = isDarkMode ? "#ce9178" : "#D13438";
            string headingColor = isDarkMode ? "#ffffff" : "#201F1E";
            string linkColor = isDarkMode ? "#4da6ff" : "#0078D4";
            string blockquoteColor = isDarkMode ? "#888888" : "#666666";
            string hrColor = isDarkMode ? "#3d3d3d" : "#E1DFDD";
            string preBg = isDarkMode ? "#2d2d2d" : "#F5F5F5";

            // 🔥 Tema para Highlight.js
            string highlightTheme = isDarkMode ? "vs2015" : "github";

            // 🔥 Construir HTML completo con estilos Y Highlight.js
            return $@"<!DOCTYPE html>
<html>
<head>
    <meta charset='utf-8'>
    <meta http-equiv='X-UA-Compatible' content='IE=edge'>
    <meta name='viewport' content='width=device-width, initial-scale=1.0'>
    
    <!-- 🔥 Highlight.js: Resaltado de sintaxis -->
    <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.9.0/styles/{highlightTheme}.min.css'>
    <script src='https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.9.0/highlight.min.js'></script>
    <script src='https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.9.0/languages/csharp.min.js'></script>
    <script src='https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.9.0/languages/sql.min.js'></script>
    <script src='https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.9.0/languages/javascript.min.js'></script>
    <script src='https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.9.0/languages/python.min.js'></script>
    <script src='https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.9.0/languages/xml.min.js'></script>
    <script src='https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.9.0/languages/json.min.js'></script>
    
    <!-- 🔥 NUEVO: Mermaid para diagramas -->
    <script src='https://cdn.jsdelivr.net/npm/mermaid@10/dist/mermaid.min.js'></script>
    <script>
        // 🔥 Inicializar Mermaid con el tema adecuado
        mermaid.initialize({{
            theme: '{(isDarkMode ? "dark" : "default")}',
            startOnLoad: true,
            flowchart: {{
                useMaxWidth: true
            }},
            sequence: {{
                useMaxWidth: true
            }},
            gantt: {{
                useMaxWidth: true
            }}
        }});
    </script>
    
    <style>
        /* 🔥 Estilos base */
        body {{
            font-family: 'Segoe UI Variable', 'Segoe UI', Arial, sans-serif;
            font-size: 14px;
            line-height: 1.6;
            padding: 20px;
            background-color: {bodyBg};
            color: {textColor};
            margin: 0;
        }}

        /* 🔥 Encabezados */
        h1, h2, h3, h4, h5, h6 {{
            color: {headingColor};
            margin-top: 24px;
            margin-bottom: 16px;
            font-weight: 600;
            line-height: 1.25;
        }}
        h1 {{ font-size: 2em; border-bottom: 1px solid {borderColor}; padding-bottom: 0.3em; }}
        h2 {{ font-size: 1.5em; border-bottom: 1px solid {borderColor}; padding-bottom: 0.3em; }}
        h3 {{ font-size: 1.25em; }}
        h4 {{ font-size: 1em; }}
        h5 {{ font-size: 0.875em; }}
        h6 {{ font-size: 0.85em; color: {blockquoteColor}; }}

        /* 🔥 Párrafos y texto */
        p {{ margin: 0 0 16px 0; }}
        strong {{ font-weight: 600; }}
        em {{ font-style: italic; }}
        del {{ text-decoration: line-through; }}
        u {{ text-decoration: underline; }}

        /* 🔥 Enlaces */
        a {{
            color: {linkColor};
            text-decoration: none;
        }}
        a:hover {{
            text-decoration: underline;
        }}

        /* 🔥 Listas */
        ul, ol {{
            padding-left: 24px;
            margin: 0 0 16px 0;
        }}
        li {{
            margin-bottom: 4px;
        }}
        li > ul, li > ol {{
            margin-bottom: 0;
        }}

        /* 🔥 Tablas */
        table {{
            border-collapse: collapse;
            width: 100%;
            margin: 16px 0;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 0 0 1px {borderColor};
        }}
        th, td {{
            padding: 8px 12px;
            text-align: left;
            border-bottom: 1px solid {borderColor};
        }}
        th {{
            background-color: {thBg};
            color: {thText};
            font-weight: 600;
        }}
        td {{
            color: {textColor};
        }}
        tr:last-child td {{
            border-bottom: none;
        }}

        /* 🔥 Código inline */
        code:not(pre code) {{
            background-color: {codeBg};
            padding: 2px 6px;
            border-radius: 4px;
            font-family: 'Consolas', 'Cascadia Code', monospace;
            font-size: 13px;
            color: {codeText};
        }}

        /* 🔥 Bloques de código (Highlight.js) */
        pre {{
            background-color: {preBg};
            padding: 0;
            border-radius: 6px;
            overflow: auto;
            margin: 16px 0;
            border: 1px solid {borderColor};
        }}
        pre code {{
            display: block;
            padding: 16px;
            font-size: 13px;
            line-height: 1.5;
            font-family: 'Consolas', 'Cascadia Code', monospace;
            background-color: transparent;
        }}

        /* 🔥 Ajustes para Highlight.js en modo oscuro */
        {(isDarkMode ? @"
        .hljs {{
            background: #1e1e1e !important;
        }}" : "")}

        /* 🔥 NUEVO: Estilos para diagramas Mermaid */
        .mermaid {{
            background-color: {(isDarkMode ? "#1e1e1e" : "#ffffff")};
            padding: 16px;
            border-radius: 8px;
            margin: 16px 0;
            border: 1px solid {borderColor};
            text-align: center;
        }}
        .mermaid svg {{
            max-width: 100%;
            height: auto;
        }}

        /* 🔥 Citas */
        blockquote {{
            border-left: 4px solid {borderColor};
            padding: 0 16px;
            margin: 16px 0;
            color: {blockquoteColor};
        }}
        blockquote p:last-child {{
            margin-bottom: 0;
        }}

        /* 🔥 Línea horizontal */
        hr {{
            border: none;
            border-top: 1px solid {hrColor};
            margin: 24px 0;
        }}

        /* 🔥 Imágenes */
        img {{
            max-width: 100%;
            height: auto;
            border-radius: 6px;
            margin: 8px 0;
        }}
        {(isDarkMode ? "img {{ filter: brightness(0.9); }}" : "")}

        /* 🔥 Listas de tareas (checklist) */
        .task-list-item {{
            list-style-type: none;
        }}
        .task-list-item input[type='checkbox'] {{
            margin-right: 8px;
        }}

        /* 🔥 Notas al pie */
        .footnotes {{
            border-top: 1px solid {borderColor};
            padding-top: 16px;
            margin-top: 32px;
            font-size: 0.9em;
            color: {blockquoteColor};
        }}
        .footnotes ol {{
            padding-left: 24px;
        }}
        .footnote-ref {{
            color: {linkColor};
            text-decoration: none;
        }}

        /* 🔥 Tablas de definición */
        dl {{
            margin: 16px 0;
        }}
        dt {{
            font-weight: 600;
            margin-top: 8px;
        }}
        dd {{
            margin-left: 24px;
            margin-bottom: 8px;
        }}

        /* 🔥 Contenedores personalizados */
        .container {{
            padding: 16px;
            border-radius: 6px;
            margin: 16px 0;
            border: 1px solid {borderColor};
        }}
        .container.warning {{
            background-color: {(isDarkMode ? "#3d2a1f" : "#fff3cd")};
            border-color: {(isDarkMode ? "#856404" : "#ffc107")};
        }}
        .container.info {{
            background-color: {(isDarkMode ? "#1f2a3d" : "#d1ecf1")};
            border-color: {(isDarkMode ? "#0c5460" : "#17a2b8")};
        }}
        .container.success {{
            background-color: {(isDarkMode ? "#1f3d2a" : "#d4edda")};
            border-color: {(isDarkMode ? "#155724" : "#28a745")};
        }}
        .container.error {{
            background-color: {(isDarkMode ? "#3d1f1f" : "#f8d7da")};
            border-color: {(isDarkMode ? "#721c24" : "#dc3545")};
        }}

        /* 🔥 Scrollbar personalizado */
        ::-webkit-scrollbar {{
            width: 8px;
            height: 8px;
        }}
        ::-webkit-scrollbar-track {{
            background: {bodyBg};
        }}
        ::-webkit-scrollbar-thumb {{
            background: {borderColor};
            border-radius: 4px;
        }}
        ::-webkit-scrollbar-thumb:hover {{
            background: {(isDarkMode ? "#555" : "#bbb")};
        }}
    </style>
</head>
<body>
    {html}
    
    <!-- 🔥 Aplicar resaltado de sintaxis -->
    <script>
        document.addEventListener('DOMContentLoaded', function() {{
            hljs.highlightAll();
        }});
    </script>
</body>
</html>";
        }

        /// <summary>
        /// Obtiene el estado del modo oscuro desde el ViewModel
        /// </summary>
        private bool GetIsDarkModeFromApplication()
        {
            try
            {
                // Obtener el DataContext de la ventana principal
                var mainWindow = Application.Current.MainWindow;
                if (mainWindow?.DataContext != null)
                {
                    var vm = mainWindow.DataContext;

                    // Buscar la propiedad IsDarkMode en el ViewModel
                    var prop = vm.GetType().GetProperty("IsDarkMode");
                    if (prop != null)
                    {
                        return (bool)prop.GetValue(vm);
                    }
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Error obteniendo IsDarkMode: {ex.Message}");
            }

            // Valor por defecto: modo claro
            return false;
        }

        // 🔥 Eventos del Checklist
        private void AddChecklistItem_Click(object sender, RoutedEventArgs e)
        {
            if (DataContext is TaskItem task)
                task.ChecklistItems.Add(new ChecklistItemModel { Text = "Nuevo requisito", IsDone = false });
        }

        private void DeleteChecklistItem_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button btn && btn.DataContext is ChecklistItemModel item && DataContext is TaskItem task)
                task.ChecklistItems.Remove(item);
        }
    }
}