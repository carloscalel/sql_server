using System.Windows.Controls;
namespace DBAOrganizer.WPF.Views { public partial class CardControl : UserControl { public CardControl() { InitializeComponent(); } } }