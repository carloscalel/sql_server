using System.Collections.ObjectModel;
using System.Windows.Input;
using DBAOrganizer.WPF.Models;
using DBAOrganizer.WPF.Services;
using System;
using System.Linq;

namespace DBAOrganizer.WPF.ViewModels
{
    public class RelayCommand : ICommand
    {
        private readonly Action<object?> _execute;
        private readonly Func<object?, bool>? _canExecute;

        public RelayCommand(Action<object?> execute, Func<object?, bool>? canExecute = null)
        {
            _execute = execute;
            _canExecute = canExecute;
        }

        public event EventHandler? CanExecuteChanged
        {
            add => CommandManager.RequerySuggested += value;
            remove => CommandManager.RequerySuggested -= value;
        }

        public bool CanExecute(object? parameter) => _canExecute == null || _canExecute(parameter);
        public void Execute(object? parameter) => _execute(parameter);
    }

    public class MainViewModel : TaskItem
    {
        private readonly JsonDataService _dataService;
        public ObservableCollection<TaskItem> Tasks { get; set; }
        public ObservableCollection<ColumnModel> Columns { get; set; } = new();

        private TaskItem? _selectedTask;
        public TaskItem? SelectedTask
        {
            get => _selectedTask;
            set { _selectedTask = value; OnPropertyChanged(); }
        }

        private string _searchQuery = string.Empty;
        public string SearchQuery
        {
            get => _searchQuery;
            set { _searchQuery = value; OnPropertyChanged(); RefreshFilters(); }
        }

        private string _selectedTagFilter = "Todos";
        public string SelectedTagFilter
        {
            get => _selectedTagFilter;
            set { _selectedTagFilter = value; OnPropertyChanged(); RefreshFilters(); }
        }

        private string _selectedPriorityFilter = "Todas";
        public string SelectedPriorityFilter
        {
            get => _selectedPriorityFilter;
            set { _selectedPriorityFilter = value; OnPropertyChanged(); RefreshFilters(); }
        }

        private bool _isDarkMode = false;
        public bool IsDarkMode
        {
            get => _isDarkMode;
            set
            {
                _isDarkMode = value;
                OnPropertyChanged();
                OnPropertyChanged(nameof(CurrentThemeBackground));
                OnPropertyChanged(nameof(HeaderBackground));
                OnPropertyChanged(nameof(CardBackground));
                OnPropertyChanged(nameof(SearchBackground));
                OnPropertyChanged(nameof(BorderColor));
                OnPropertyChanged(nameof(TextPrimary));
                OnPropertyChanged(nameof(TextSecondary));
                OnPropertyChanged(nameof(ThemeIcon));
            }
        }

        public string CurrentThemeBackground => _isDarkMode ? "#1C1C1C" : "#F3F3F3";
        public string HeaderBackground => _isDarkMode ? "#2D2D2D" : "#FFFFFF";
        public string CardBackground => _isDarkMode ? "#333333" : "#FFFFFF";
        public string SearchBackground => _isDarkMode ? "#1C1C1C" : "#F3F3F3";
        public string BorderColor => _isDarkMode ? "#484644" : "#E1DFDD";
        public string TextPrimary => _isDarkMode ? "#FFFFFF" : "#323130";
        public string TextSecondary => _isDarkMode ? "#D2D0CE" : "#605E5C";
        public string ThemeIcon => _isDarkMode ? "\uE708" : "\uE706"; // Sun / Moon icons

        private string _totalTasksSummary = "0 tarjetas activas";
        public string TotalTasksSummary
        {
            get => _totalTasksSummary;
            set { _totalTasksSummary = value; OnPropertyChanged(); }
        }

        public ICommand AddColumnCommand { get; }
        public ICommand DeleteColumnCommand { get; }
        public ICommand AddTaskCommand { get; }
        public ICommand AddTaskInColumnCommand { get; }
        public ICommand SaveCommand { get; }
        public ICommand DeleteSelectedTaskCommand { get; }
        public ICommand ExportCsvCommand { get; }
        public ICommand ToggleThemeCommand { get; }

        public MainViewModel()
        {
            _dataService = new JsonDataService();
            var (colNames, loadedTasks) = _dataService.LoadBoard();
            Tasks = loadedTasks;

            foreach (var name in colNames)
            {
                Columns.Add(new ColumnModel { Name = name });
            }

            if (Tasks.Count == 0 && Columns.Count > 0)
            {
                Tasks.Add(new TaskItem
                {
                    Ticket = "INC-725037",
                    Title = "Migrar BD a SQL Server 2026",
                    Assigned = "Admin",
                    Priority = "Normal",
                    Tag = "SQL Server",
                    Status = Columns.FirstOrDefault(c => c.Name == "En QA")?.Name ?? Columns[0].Name,
                    DueDate = "31/08/2026"
                });
            }

            RefreshColumns();

            AddColumnCommand = new RelayCommand(_ => AddColumn());
            DeleteColumnCommand = new RelayCommand(param => DeleteColumn(param as ColumnModel));
            AddTaskCommand = new RelayCommand(_ => AddTask(Columns.FirstOrDefault()?.Name ?? "New Tickets"));
            AddTaskInColumnCommand = new RelayCommand(param => AddTask(param as string));
            SaveCommand = new RelayCommand(_ => SaveData());
            DeleteSelectedTaskCommand = new RelayCommand(_ => DeleteSelectedTask());
            ExportCsvCommand = new RelayCommand(_ => _dataService.ExportToCsv(Tasks));
            ToggleThemeCommand = new RelayCommand(_ => IsDarkMode = !IsDarkMode);
        }

        private void RefreshColumns()
        {
            foreach (var col in Columns)
            {
                col.Tasks.Clear();
            }

            foreach (var task in Tasks)
            {
                var targetCol = Columns.FirstOrDefault(c => c.Name == task.Status);
                if (targetCol != null)
                {
                    targetCol.Tasks.Add(task);
                }
                else if (Columns.Count > 0)
                {
                    task.Status = Columns[0].Name;
                    Columns[0].Tasks.Add(task);
                }
            }

            RefreshFilters();
            TotalTasksSummary = $"{Tasks.Count} tarjetas activas";
        }

        private void RefreshFilters()
        {
            foreach (var col in Columns)
            {
                col.FilteredTasks.Clear();
                foreach (var task in col.Tasks)
                {
                    bool matchesSearch = string.IsNullOrWhiteSpace(SearchQuery) ||
                                         task.Title.Contains(SearchQuery, StringComparison.OrdinalIgnoreCase) ||
                                         task.Assigned.Contains(SearchQuery, StringComparison.OrdinalIgnoreCase) ||
                                         task.Ticket.Contains(SearchQuery, StringComparison.OrdinalIgnoreCase);

                    bool matchesTag = string.IsNullOrEmpty(SelectedTagFilter) || SelectedTagFilter == "Todos" || 
                                      task.Tag.Contains(SelectedTagFilter, StringComparison.OrdinalIgnoreCase);
                    
                    bool matchesPriority = string.IsNullOrEmpty(SelectedPriorityFilter) || SelectedPriorityFilter == "Todas" || 
                                           task.Priority.Equals(SelectedPriorityFilter, StringComparison.OrdinalIgnoreCase);

                    if (matchesSearch && matchesTag && matchesPriority)
                    {
                        col.FilteredTasks.Add(task);
                    }
                }
            }
        }

        private void AddColumn()
        {
            string newName = $"Lista {Columns.Count + 1}";
            Columns.Add(new ColumnModel { Name = newName });
            SaveData();
        }

        private void DeleteColumn(ColumnModel? col)
        {
            if (col != null && Columns.Count > 1)
            {
                var targetCol = Columns.First(c => c != col);
                foreach (var t in col.Tasks.ToList())
                {
                    t.Status = targetCol.Name;
                }
                Columns.Remove(col);
                RefreshColumns();
                SaveData();
            }
        }

        private void AddTask(string? columnName)
        {
            string targetCol = columnName ?? "New Tickets";
            var newTask = new TaskItem
            {
                Ticket = $"INC-{new Random().Next(100000, 999999)}",
                Title = "Nueva Tarea de Ingeniería",
                Assigned = "Admin",
                Priority = "Normal",
                Tag = "SQL Server",
                Status = targetCol,
                DueDate = "31/08/2026",
                ActivityLog = $"[{DateTime.Now:dd/MM/yyyy HH:mm}] [Admin] Tarjeta creada."
            };
            Tasks.Add(newTask);
            RefreshColumns();
            SelectedTask = newTask; // Auto-select new task
        }

        public void MoveTaskToColumn(TaskItem task, string newColumnName)
        {
            if (task != null && task.Status != newColumnName)
            {
                task.Status = newColumnName;
                task.ActivityLog += $"\n[{DateTime.Now:dd/MM/yyyy HH:mm}] [Sistema] Movida a lista '{newColumnName}'.";
                RefreshColumns();
                SaveData();
            }
        }

        private void DeleteSelectedTask()
        {
            if (SelectedTask != null)
            {
                Tasks.Remove(SelectedTask);
                SelectedTask = null;
                SaveData();
            }
        }

        private void SaveData()
        {
            RefreshColumns();
            _dataService.SaveBoard(Columns.Select(c => c.Name), Tasks);
        }
    }
}