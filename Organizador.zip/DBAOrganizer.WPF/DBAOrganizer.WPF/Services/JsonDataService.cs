using System.IO;
using System.Text;
using System.Text.Json;
using System.Collections.ObjectModel;
using DBAOrganizer.WPF.Models;
using System.Collections.Generic;
using System.Linq;
using System;

namespace DBAOrganizer.WPF.Services
{
    public class BoardData
    {
        public List<string> ColumnNames { get; set; } = new();
        public List<TaskItem> Tasks { get; set; } = new();
    }

    public class JsonDataService
    {
        private readonly string _filePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "trello_board.json");

        public (List<string> columns, ObservableCollection<TaskItem> tasks) LoadBoard()
        {
            if (!File.Exists(_filePath))
            {
                var defaultCols = new List<string> { "New Tickets", "En QA", "Done" };
                return (defaultCols, new ObservableCollection<TaskItem>());
            }

            try
            {
                var json = File.ReadAllText(_filePath);
                var data = JsonSerializer.Deserialize<BoardData>(json);
                if (data != null)
                {
                    return (data.ColumnNames.Any() ? data.ColumnNames : new List<string> { "New Tickets", "En QA", "Done" }, 
                            new ObservableCollection<TaskItem>(data.Tasks));
                }
            }
            catch { }

            return (new List<string> { "New Tickets", "En QA", "Done" }, new ObservableCollection<TaskItem>());
        }

        public void SaveBoard(IEnumerable<string> columns, IEnumerable<TaskItem> tasks)
        {
            var data = new BoardData
            {
                ColumnNames = columns.ToList(),
                Tasks = tasks.ToList()
            };
            var options = new JsonSerializerOptions { WriteIndented = true };
            var json = JsonSerializer.Serialize(data, options);
            File.WriteAllText(_filePath, json);
        }

        public void ExportToCsv(IEnumerable<TaskItem> tasks)
        {
            string csvPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Trello_Report.csv");
            var sb = new StringBuilder();
            sb.AppendLine("Ticket,Title,Assigned,Priority,Tag,Status,DueDate,Checklist");

            foreach (var t in tasks)
            {
                sb.AppendLine(string.Format("\"{0}\",\"{1}\",\"{2}\",\"{3}\",\"{4}\",\"{5}\",\"{6}\",\"{7}\"",
                    t.Ticket, t.Title, t.Assigned, t.Priority, t.Tag, t.Status, t.DueDate, t.ChecklistSummary));
            }

            File.WriteAllText(csvPath, sb.ToString(), Encoding.UTF8);
        }
    }
}