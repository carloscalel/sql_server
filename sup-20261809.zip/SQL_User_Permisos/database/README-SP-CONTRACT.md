# Ubicación de los objetos de base de datos

Los scripts ejecutables por el DBA se encuentran en [`../InsumosProduccion`](../InsumosProduccion/README.md).

Esta carpeta se conserva únicamente como referencia de compatibilidad. La aplicación no contiene inicializadores, migraciones ni rutinas para crear objetos de `adminDB`.
