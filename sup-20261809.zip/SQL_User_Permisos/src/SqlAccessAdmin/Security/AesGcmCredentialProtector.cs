using System.Security.Cryptography;
using System.Text;
using SqlAccessAdmin.Models;

namespace SqlAccessAdmin.Security;

public interface ICredentialProtector { string Protect(string plaintext); string Unprotect(string payload); }

public sealed class AesGcmCredentialProtector : ICredentialProtector
{
    private readonly byte[] _key;
    public AesGcmCredentialProtector(byte[] key)
    { if (key.Length != 32) throw new ArgumentException("AES-256 requiere una clave de 32 bytes.", nameof(key)); _key = key.ToArray(); }
    public string Protect(string plaintext)
    {
        var nonce=RandomNumberGenerator.GetBytes(12); var plain=Encoding.UTF8.GetBytes(plaintext); var cipher=new byte[plain.Length]; var tag=new byte[16];
        using var aes=new AesGcm(_key,16); aes.Encrypt(nonce,plain,cipher,tag);
        return $"v1.{Convert.ToBase64String(nonce)}.{Convert.ToBase64String(tag)}.{Convert.ToBase64String(cipher)}";
    }
    public string Unprotect(string payload)
    {
        var p=payload.Split('.'); if(p.Length!=4||p[0]!="v1") throw new CryptographicException("Formato cifrado no válido.");
        var nonce=Convert.FromBase64String(p[1]); var tag=Convert.FromBase64String(p[2]); var cipher=Convert.FromBase64String(p[3]); var plain=new byte[cipher.Length];
        using var aes=new AesGcm(_key,16); aes.Decrypt(nonce,cipher,tag,plain); return Encoding.UTF8.GetString(plain);
    }

    public CredentialEnvelope ProtectEnvelope(string plaintext,Guid keyId)
    {
        var nonce=RandomNumberGenerator.GetBytes(12);var plain=Encoding.UTF8.GetBytes(plaintext);var cipher=new byte[plain.Length];var tag=new byte[16];var aad=keyId.ToByteArray();
        using var aes=new AesGcm(_key,16);aes.Encrypt(nonce,plain,cipher,tag,aad);CryptographicOperations.ZeroMemory(plain);
        return new CredentialEnvelope(cipher,nonce,tag,keyId);
    }
    public string Unprotect(CredentialEnvelope envelope)
    {
        var plain=new byte[envelope.Ciphertext.Length];
        using var aes=new AesGcm(_key,16);aes.Decrypt(envelope.Nonce,envelope.Ciphertext,envelope.Tag,plain,envelope.KeyId.ToByteArray());
        try{return Encoding.UTF8.GetString(plain);}finally{CryptographicOperations.ZeroMemory(plain);}
    }
}
