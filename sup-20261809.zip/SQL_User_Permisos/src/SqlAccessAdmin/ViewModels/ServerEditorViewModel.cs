using SqlAccessAdmin.Data;
using SqlAccessAdmin.Infrastructure;
using SqlAccessAdmin.Models;
using SqlAccessAdmin.Security;
using System.Security.Cryptography;

namespace SqlAccessAdmin.ViewModels;

public sealed class ServerEditorViewModel : BindableBase
{
    private readonly AdminDbGateway _db;
    private readonly DirectSqlServerService _direct;
    private readonly int? _id;
    private string _name="Nuevo servidor",_host="localhost",_instance="",_sqlUser="",_password="",_status="Listo para probar la conexión.";
    private bool _windowsAuth=true,_encrypt=true,_trustCertificate,_active=true;
    private int _timeoutSeconds=30;
    public event Action<bool>? CloseRequested;
    public string WindowTitle=>_id.HasValue?"Editar servidor":"Registrar servidor";
    public string Name {get=>_name;set=>Set(ref _name,value);}
    public string Host {get=>_host;set=>Set(ref _host,value);}
    public string Instance {get=>_instance;set=>Set(ref _instance,value);}
    public string SqlUser {get=>_sqlUser;set=>Set(ref _sqlUser,value);}
    public string Password {get=>_password;set=>Set(ref _password,value);}
    public bool WindowsAuth {get=>_windowsAuth;set=>Set(ref _windowsAuth,value);}
    public bool Encrypt {get=>_encrypt;set=>Set(ref _encrypt,value);}
    public bool TrustCertificate {get=>_trustCertificate;set=>Set(ref _trustCertificate,value);}
    public bool Active {get=>_active;set=>Set(ref _active,value);}
    public int TimeoutSeconds {get=>_timeoutSeconds;set=>Set(ref _timeoutSeconds,value);}
    public string Status {get=>_status;set=>Set(ref _status,value);}
    public string PasswordHint=>_id.HasValue?"Déjala vacía para conservar la contraseña existente.":"Se cifrará con AES-256-GCM antes de guardarse.";
    public AsyncCommand SaveCommand {get;}
    public AsyncCommand TestCommand {get;}
    public RelayCommand CancelCommand {get;}

    public ServerEditorViewModel(AdminDbGateway db,DirectSqlServerService direct,ServerItem? item)
    {
        _db=db;_direct=direct;_id=item?.Id;
        if(item is not null){_name=item.Name;_host=item.Host;_instance=item.Instance;_windowsAuth=item.WindowsAuth;_sqlUser=item.SqlUser;_encrypt=item.Encrypt;_trustCertificate=item.TrustCertificate;_active=item.Active;_timeoutSeconds=item.TimeoutSeconds;}
        SaveCommand=new(SaveAsync);TestCommand=new(TestAsync);CancelCommand=new(()=>CloseRequested?.Invoke(false));
    }
    private ServerEditData BuildData()=>new(_id,Name.Trim(),Host.Trim(),Instance.Trim(),WindowsAuth,SqlUser.Trim(),Password,Encrypt,TrustCertificate,TimeoutSeconds,Active);
    private void Validate()
    {if(string.IsNullOrWhiteSpace(Name))throw new InvalidOperationException("Indique un nombre amigable.");if(string.IsNullOrWhiteSpace(Host))throw new InvalidOperationException("Indique el host o IP.");if(!Encrypt)throw new InvalidOperationException("Por seguridad, la conexión cifrada es obligatoria.");if(TimeoutSeconds is <5 or >300)throw new InvalidOperationException("El timeout debe estar entre 5 y 300 segundos.");if(!WindowsAuth&&string.IsNullOrWhiteSpace(SqlUser))throw new InvalidOperationException("Indique el usuario SQL.");if(!WindowsAuth&&!_id.HasValue&&string.IsNullOrEmpty(Password))throw new InvalidOperationException("Indique la contraseña SQL.");}
    private async Task SaveAsync()
    {try{Validate();CredentialEnvelope? envelope=null;if(!WindowsAuth&&!string.IsNullOrEmpty(Password)){var crypto=await _db.GetCryptoMaterialAsync();try{envelope=new AesGcmCredentialProtector(crypto.MasterKey).ProtectEnvelope(Password,crypto.KeyId);}finally{CryptographicOperations.ZeroMemory(crypto.MasterKey);}}await _db.SaveServerAsync(BuildData(),envelope);Password="";CloseRequested?.Invoke(true);}catch(Exception ex){Password="";Status=ex.Message;}}
    private async Task TestAsync()
    {
        try{Validate();Status="Probando conexión directa…";await _direct.TestAsync(BuildData());Status="✓ Conexión realizada correctamente.";}
        catch(Exception ex){Status=$"✕ No fue posible conectar: {ex.Message}";}
    }
}
