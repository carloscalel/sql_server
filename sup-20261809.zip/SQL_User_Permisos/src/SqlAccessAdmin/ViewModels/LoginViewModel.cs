using System.Windows;
using Microsoft.Data.SqlClient;
using SqlAccessAdmin.Data;
using SqlAccessAdmin.Infrastructure;
using SqlAccessAdmin.Models;
using SqlAccessAdmin.Views;

namespace SqlAccessAdmin.ViewModels;

public sealed class LoginViewModel : BindableBase
{
    private string _server="localhost",_instance="",_database="adminDB",_user="",_status="";
    private bool _integrated=true,_encrypt=true,_trust,_isConnecting,_cancelRequested;
    private CancellationTokenSource? _connectionCancellation;

    public string Server {get=>_server;set=>Set(ref _server,value);}
    public string Instance {get=>_instance;set=>Set(ref _instance,value);}
    public string Database {get=>_database;set=>Set(ref _database,value);}
    public string User {get=>_user;set=>Set(ref _user,value);}
    public string Password {get;set;}="";
    public bool Integrated {get=>_integrated;set=>Set(ref _integrated,value);}
    public bool Encrypt {get=>_encrypt;set=>Set(ref _encrypt,value);}
    public bool TrustCertificate {get=>_trust;set=>Set(ref _trust,value);}
    public string Status {get=>_status;set=>Set(ref _status,value);}
    public bool IsConnecting
    {
        get=>_isConnecting;
        private set
        {
            if(!Set(ref _isConnecting,value))return;
            LoginCommand.Refresh();
            CancelConnectionCommand.Refresh();
        }
    }

    public AsyncCommand LoginCommand {get;}
    public RelayCommand CancelConnectionCommand {get;}

    public LoginViewModel()
    {
        LoginCommand=new(LoginAsync,()=>!IsConnecting);
        CancelConnectionCommand=new(CancelConnection,()=>IsConnecting);
    }

    private async Task LoginAsync()
    {
        using var cancellation=new CancellationTokenSource();
        _connectionCancellation=cancellation;
        _cancelRequested=false;
        IsConnecting=true;
        try
        {
            Status="Conectando de forma segura…";
            var options=new PivotOptions(Server,Instance,Database,Integrated,User,Password,Encrypt,TrustCertificate);
            var gateway=new AdminDbGateway(options);
            var session=await gateway.LoginAsync(cancellation.Token);
            cancellation.Token.ThrowIfCancellationRequested();
            var main=new MainWindow{DataContext=new MainViewModel(gateway,session)};
            main.Show();
            Application.Current.Windows.OfType<LoginWindow>().Single().Close();
        }
        catch(OperationCanceledException){Status="Conexión cancelada. Corrige los datos y vuelve a intentarlo.";}
        catch(SqlException) when(_cancelRequested){Status="Conexión cancelada. Corrige los datos y vuelve a intentarlo.";}
        catch(SqlException ex) when(ex.Number is 208 or 2812 or 4060){Status="adminDB no está preparada o no es accesible. Solicite al DBA ejecutar y validar los scripts de InsumosProduccion.";}
        catch(SqlException ex){Status=$"No fue posible conectar: {ex.Message}";}
        catch(Exception ex){Status=ex.Message;}
        finally
        {
            if(ReferenceEquals(_connectionCancellation,cancellation))_connectionCancellation=null;
            IsConnecting=false;
        }
    }

    private void CancelConnection()
    {
        if(_connectionCancellation is null)return;
        _cancelRequested=true;
        Status="Cancelando la conexión…";
        _connectionCancellation.Cancel();
    }
}
