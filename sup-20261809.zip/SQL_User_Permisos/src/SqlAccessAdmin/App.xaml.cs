using System.Windows;

namespace SqlAccessAdmin;

public partial class App : Application { }
