using System.Windows.Controls; namespace SqlAccessAdmin.Views; public partial class AuditView:UserControl{public AuditView()=>InitializeComponent();}
