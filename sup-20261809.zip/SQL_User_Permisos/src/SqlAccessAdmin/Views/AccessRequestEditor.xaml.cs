using System.Windows;
using System.Windows.Controls;
using SqlAccessAdmin.ViewModels;

namespace SqlAccessAdmin.Views;

public partial class AccessRequestEditor : UserControl
{
    public AccessRequestEditor()=>InitializeComponent();

    private async void SelectObjects_OnClick(object sender,RoutedEventArgs e)
    {
        if(DataContext is not AccessViewModel vm)return;
        await vm.LoadDatabaseObjectsForSelectionAsync();
        if(vm.DatabaseObjects.Count==0)return;
        var selector=new DatabaseObjectSelectorWindow(vm.DatabaseObjects,vm.SelectedDatabaseObjects)
        {
            Owner=Window.GetWindow(this)
        };
        if(selector.ShowDialog()==true)vm.ApplySelectedDatabaseObjects(selector.SelectedObjects);
    }

    private void SelectAllPermissions_OnClick(object sender,RoutedEventArgs e)
    {
        if(DataContext is not AccessViewModel vm)return;
        foreach(var permission in vm.PermissionChoices)permission.IsSelected=true;
    }

    private void ClearPermissions_OnClick(object sender,RoutedEventArgs e)
    {
        if(DataContext is not AccessViewModel vm)return;
        foreach(var permission in vm.PermissionChoices)permission.IsSelected=false;
    }
}
