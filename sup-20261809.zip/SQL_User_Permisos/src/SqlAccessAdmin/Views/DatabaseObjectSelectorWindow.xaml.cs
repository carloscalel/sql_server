using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Data;
using SqlAccessAdmin.Models;

namespace SqlAccessAdmin.Views;

public partial class DatabaseObjectSelectorWindow : Window,INotifyPropertyChanged
{
    private string _searchText="";
    public ObservableCollection<DatabaseObjectSelectionItem> Items {get;}=[];
    public ICollectionView FilteredItems {get;}
    public IReadOnlyList<DatabaseObjectItem> SelectedObjects=>Items.Where(x=>x.IsSelected).Select(x=>x.Item).ToList();
    public int SelectedCount=>Items.Count(x=>x.IsSelected);
    public string SearchText {get=>_searchText;set{if(_searchText==value)return;_searchText=value;OnPropertyChanged();FilteredItems.Refresh();}}

    public DatabaseObjectSelectorWindow(IEnumerable<DatabaseObjectItem> objects,IEnumerable<DatabaseObjectItem> selected)
    {
        InitializeComponent();
        var selectedObjects=selected.ToHashSet();
        foreach(var item in objects.OrderBy(x=>x.Schema).ThenBy(x=>x.Name))
        {
            var choice=new DatabaseObjectSelectionItem(item,selectedObjects.Contains(item));
            choice.PropertyChanged+=(_,args)=>{if(args.PropertyName==nameof(DatabaseObjectSelectionItem.IsSelected))OnPropertyChanged(nameof(SelectedCount));};
            Items.Add(choice);
        }
        FilteredItems=CollectionViewSource.GetDefaultView(Items);
        FilteredItems.Filter=MatchesFilter;
        DataContext=this;
    }

    private bool MatchesFilter(object value)
    {
        if(value is not DatabaseObjectSelectionItem item)return false;
        var filter=SearchText.Trim();
        return filter.Length==0||item.Schema.Contains(filter,StringComparison.CurrentCultureIgnoreCase)||item.Name.Contains(filter,StringComparison.CurrentCultureIgnoreCase)||item.Kind.Contains(filter,StringComparison.CurrentCultureIgnoreCase);
    }
    private void Clear_OnClick(object sender,RoutedEventArgs e)=>SearchText="";
    private void Accept_OnClick(object sender,RoutedEventArgs e)
    {
        if(SelectedCount==0){MessageBox.Show(this,"Seleccione al menos un objeto.","Objetos",MessageBoxButton.OK,MessageBoxImage.Information);return;}
        DialogResult=true;
    }
    public event PropertyChangedEventHandler? PropertyChanged;
    private void OnPropertyChanged([CallerMemberName]string? name=null)=>PropertyChanged?.Invoke(this,new(name));
}
