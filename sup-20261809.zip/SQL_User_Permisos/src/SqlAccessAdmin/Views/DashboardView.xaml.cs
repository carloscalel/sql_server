using System.Windows.Controls; namespace SqlAccessAdmin.Views; public partial class DashboardView:UserControl{public DashboardView()=>InitializeComponent();}
