using System.Windows.Controls;

namespace SqlAccessAdmin.Views;

public partial class RequestHistoryView : UserControl
{
    public RequestHistoryView()=>InitializeComponent();
}
