using System.Windows.Controls; namespace SqlAccessAdmin.Views; public partial class UsersView:UserControl{public UsersView()=>InitializeComponent();}
