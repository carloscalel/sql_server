using System.Windows;
using System.Windows.Controls;
using SqlAccessAdmin.Models;
using SqlAccessAdmin.ViewModels;

namespace SqlAccessAdmin.Views;

public partial class ServersView:UserControl
{
    public ServersView()=>InitializeComponent();
    private async void ActiveCheckBox_OnClick(object sender,RoutedEventArgs e)
    {
        if(sender is CheckBox{DataContext:ServerItem server}&&DataContext is ServersViewModel vm)
            await vm.ChangeActiveAsync(server);
    }
}
