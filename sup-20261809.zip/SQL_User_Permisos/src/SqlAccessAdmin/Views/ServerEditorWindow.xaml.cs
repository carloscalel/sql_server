using System.Windows;
using System.Windows.Controls;
using SqlAccessAdmin.Data;
using SqlAccessAdmin.Models;
using SqlAccessAdmin.ViewModels;

namespace SqlAccessAdmin.Views;

public partial class ServerEditorWindow : Window
{
    public ServerEditorWindow(AdminDbGateway db,DirectSqlServerService direct,ServerItem? item)
    {
        InitializeComponent();
        var vm=new ServerEditorViewModel(db,direct,item);
        vm.CloseRequested+=result=>{DialogResult=result;Close();};
        DataContext=vm;
    }
    private void PasswordBox_OnPasswordChanged(object sender,RoutedEventArgs e)
    {if(DataContext is ServerEditorViewModel vm)vm.Password=((PasswordBox)sender).Password;}
}
