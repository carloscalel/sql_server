using System.Windows.Controls;
namespace SqlAccessAdmin.Views;
public partial class PolicyView:UserControl{public PolicyView()=>InitializeComponent();}
