using System.Windows;
using System.Windows.Controls;
using SqlAccessAdmin.ViewModels;

namespace SqlAccessAdmin.Views;
public partial class LoginWindow : Window
{
    public LoginWindow(){InitializeComponent();DataContext=new LoginViewModel();}
    private void PasswordBox_OnPasswordChanged(object sender,RoutedEventArgs e){if(DataContext is LoginViewModel vm)vm.Password=((PasswordBox)sender).Password;}
}
