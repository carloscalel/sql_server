using System.Windows; namespace SqlAccessAdmin.Views; public partial class MainWindow:Window{public MainWindow()=>InitializeComponent();}
