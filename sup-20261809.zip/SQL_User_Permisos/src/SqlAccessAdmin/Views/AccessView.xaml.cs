using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using SqlAccessAdmin.Models;
using SqlAccessAdmin.ViewModels;
namespace SqlAccessAdmin.Views;
public partial class AccessView:UserControl
{
    public AccessView()=>InitializeComponent();
    private void ExecutionPassword_OnPasswordChanged(object sender,RoutedEventArgs e){if(DataContext is AccessViewModel vm)vm.ExecutionPassword=((PasswordBox)sender).Password;}

    private async void SecurityTreeItem_OnExpanded(object sender,RoutedEventArgs e)
    {
        if(e.OriginalSource is not TreeViewItem item||item.DataContext is not SecurityTreeNode node||DataContext is not AccessViewModel vm)return;
        e.Handled=true;
        await vm.ExpandSecurityNodeAsync(node);
    }

    private async void SecurityTree_OnSelectedItemChanged(object sender,RoutedPropertyChangedEventArgs<object> e)
    {
        if(e.NewValue is SecurityTreeNode node&&DataContext is AccessViewModel vm)
            await vm.SelectSecurityNodeAsync(node);
    }

    private void SecurityTreeItem_OnRightClick(object sender,MouseButtonEventArgs e)
    {
        if(sender is not TreeViewItem item||item.DataContext is not SecurityTreeNode node||DataContext is not AccessViewModel vm)return;
        item.IsSelected=true;
        var menu=new ContextMenu();

        void Add(string title,string operationCode)
        {
            var action=new MenuItem{Header=title};
            action.Click+=async (_,_)=>await vm.BeginAccessManagementAsync(operationCode,node);
            menu.Items.Add(action);
        }

        void AddCommand(string title,System.Windows.Input.ICommand command)
        {
            menu.Items.Add(new MenuItem{Header=title,Command=command});
        }

        switch(node.Kind)
        {
            case SecurityNodeKind.LoginGroup:
                Add("Nuevo login SQL…","CREATE_SQL_LOGIN");
                Add("Nuevo login Windows…","CREATE_WINDOWS_LOGIN");
                break;
            case SecurityNodeKind.Login:
                Add("Modificar login…","MODIFY_LOGIN");
                menu.Items.Add(new Separator());
                AddCommand("Habilitar login…",vm.EnableLoginCommand);
                AddCommand("Deshabilitar login…",vm.DisableLoginCommand);
                Add("Crear usuario de base…","CREATE_DB_USER");
                break;
            case SecurityNodeKind.Database:
            case SecurityNodeKind.UserGroup:
                Add("Crear usuario de base…","CREATE_DB_USER");
                break;
            case SecurityNodeKind.User:
                AddCommand("Cambiar permisos…",vm.ChangePermissionsCommand);
                menu.Items.Add(new Separator());
                AddCommand("Asignar rol permitido…",vm.AddRoleCommand);
                AddCommand("Quitar rol asignado…",vm.RemoveRoleCommand);
                break;
        }

        if(menu.Items.Count==0)return;
        item.ContextMenu=menu;
        menu.PlacementTarget=item;
        menu.IsOpen=true;
        e.Handled=true;
    }
}
