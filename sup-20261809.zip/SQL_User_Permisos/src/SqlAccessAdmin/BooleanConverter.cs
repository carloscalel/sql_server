using System.Globalization;
using System.Windows.Data;
namespace SqlAccessAdmin;
public sealed class BooleanConverter:IValueConverter
{ public static BooleanConverter Instance {get;}=new(); public object Convert(object value,Type t,object p,CultureInfo c)=>value is bool b&&!b; public object ConvertBack(object value,Type t,object p,CultureInfo c)=>value is bool b&&!b; }
