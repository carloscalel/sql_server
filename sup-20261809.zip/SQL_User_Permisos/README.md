# SQL Access Admin

Cliente WPF moderno en C# / .NET 8 para administrar accesos en múltiples instancias SQL Server desde un servidor pivote `adminDB`.

## Ejecutar

```powershell
dotnet restore
dotnet run --project src/SqlAccessAdmin/SqlAccessAdmin.csproj
```

La aplicación requiere que un DBA prepare previamente `adminDB` con los scripts de [InsumosProduccion](InsumosProduccion/README.md). El cliente no crea bases, tablas, tipos, roles ni procedimientos y no aplica migraciones automáticas. La UI implementa autenticación con el pivote, roles Administrator/Operator/Auditor, alta y edición de servidores, prueba de conexión, selección simultánea de servidores y bases, asignación de login/rol, resultados por destino y auditoría.

## Conexiones directas

`adminDB` funciona como catálogo y registro de auditoría. El cliente recupera únicamente los servidores autorizados y abre conexiones TLS directas a cada destino; no requiere linked servers. Para migrar una instalación anterior, el DBA debe ejecutar `08_ConfigurarConexionDirectaYCifrado.sql` y después volver a ejecutar los scripts `02`, `03`, `04` y `99`.

El flujo de administración de accesos requiere además [10_PoliticaSolicitudesEIntegridad.sql](InsumosProduccion/10_PoliticaSolicitudesEIntegridad.sql). Este insumo instala la allowlist, la denylist permanente, solicitudes y aprobaciones, y la cadena hash append-only de auditoría. Ninguno de estos objetos se crea automáticamente desde el cliente.

## Seguridad

- `Encrypt=True` por defecto en la conexión.
- No se requieren linked servers. El cliente abre conexiones TLS directas y las credenciales SQL se almacenan como sobres AES-256-GCM en `adminDB`.
- La clave AES-GCM aleatoria se guarda envuelta mediante una clave AES-256 protegida por certificado y Database Master Key de SQL Server.
- La contraseña del servidor nunca aparece en el listado y, al editar, puede dejarse vacía para conservar el sobre existente.
- Comandos parametrizados y `CommandType.StoredProcedure` exclusivamente.
- Si se habilita almacenamiento de credenciales, la clave de producción debe proceder de DPAPI/HSM/gestor de secretos; nunca debe almacenarse en el repositorio.
