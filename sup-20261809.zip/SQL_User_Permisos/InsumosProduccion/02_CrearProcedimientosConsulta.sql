USE [adminDB];
GO
SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
GO

CREATE OR ALTER PROCEDURE dbo.usp_App_LoginContext
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @Principal nvarchar(256) = ORIGINAL_LOGIN();

    IF EXISTS(SELECT 1 FROM dbo.AuthorizedPrincipal WHERE Active=1 AND Principal=@Principal)
    BEGIN
        SELECT TOP (1) Principal, RoleName AS [Role], CAST(1 AS bit) AS IsAuthorized,
               N'Principal autorizado mediante la lista blanca.' AS Detail
        FROM dbo.AuthorizedPrincipal
        WHERE Active=1 AND Principal=@Principal;
        RETURN;
    END;

    /* Un sysadmin ya posee control total de la instancia; se admite como administrador de la aplicación. */
    IF IS_SRVROLEMEMBER(N'sysadmin')=1
    BEGIN
        SELECT @Principal AS Principal, CAST('Administrator' AS varchar(20)) AS [Role],
               CAST(1 AS bit) AS IsAuthorized, N'Principal autorizado por pertenecer a sysadmin.' AS Detail;
        RETURN;
    END;

    SELECT @Principal AS Principal, CAST(NULL AS varchar(20)) AS [Role], CAST(0 AS bit) AS IsAuthorized,
           N'El principal detectado por SQL Server ['+@Principal+N'] no está activo en dbo.AuthorizedPrincipal.' AS Detail;
END;
GO

CREATE OR ALTER PROCEDURE dbo.usp_Server_List
AS
BEGIN
    SET NOCOUNT ON;
    SELECT ServerId, Active, Name, Host, ISNULL(Instance,N'') AS Instance,
           WindowsAuth, ISNULL(SqlUser,N'') AS SqlUser, Encrypt,
           TrustServerCertificate AS TrustCertificate, TimeoutSeconds
    FROM dbo.ManagedServer
    ORDER BY Name;
END;
GO

CREATE OR ALTER PROCEDURE dbo.usp_Server_GetConnection
    @ServerId int
AS
BEGIN
    SET NOCOUNT ON;
    SELECT ServerId,Name,Host,ISNULL(Instance,N'') AS Instance,WindowsAuth,
           ISNULL(SqlUser,N'') AS SqlUser,CredentialCiphertext,CredentialNonce,CredentialTag,
           CredentialKeyId,Encrypt,TrustServerCertificate,TimeoutSeconds,Active
    FROM dbo.ManagedServer WHERE ServerId=@ServerId AND Active=1;
END;
GO

CREATE OR ALTER PROCEDURE dbo.usp_AuthorizedUser_List
AS
BEGIN
    SET NOCOUNT ON;
    SELECT UserId, Principal, PrincipalType, RoleName AS [Role], Active, ISNULL(Notes,N'') AS Notes
    FROM dbo.AuthorizedPrincipal
    ORDER BY Principal;
END;
GO

CREATE OR ALTER PROCEDURE dbo.usp_Audit_List
    @Filter nvarchar(200) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SELECT TOP (500) EventDate, Principal, Form, Action,
           ISNULL(ServerName,N'') AS Server, ISNULL(DatabaseName,N'') AS [Database],
           Success, ISNULL(Detail,N'') AS Detail
    FROM dbo.AuditEvent
    WHERE @Filter IS NULL OR @Filter = N''
       OR Principal LIKE N'%' + @Filter + N'%'
       OR Form LIKE N'%' + @Filter + N'%'
       OR Action LIKE N'%' + @Filter + N'%'
       OR ServerName LIKE N'%' + @Filter + N'%'
       OR DatabaseName LIKE N'%' + @Filter + N'%'
       OR Detail LIKE N'%' + @Filter + N'%'
    ORDER BY EventDate DESC, AuditId DESC;
END;
GO
