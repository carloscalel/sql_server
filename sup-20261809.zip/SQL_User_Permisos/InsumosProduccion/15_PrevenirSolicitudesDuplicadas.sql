USE [adminDB];
GO
SET NOCOUNT ON;
SET XACT_ABORT ON;
GO

/*
  Ejecutar manualmente como DBA.

  Impide registrar una solicitud equivalente mientras exista otra PENDING o
  APPROVED con la misma operación, principal, configuración y conjunto exacto
  de destinos. La justificación no forma parte de la equivalencia: cambiar el
  texto no debe permitir duplicar una operación pendiente.
*/

CREATE OR ALTER PROCEDURE dbo.usp_AccessRequest_Create
    @OperationCode varchar(40),
    @TargetPrincipal nvarchar(256),
    @SourcePrincipal nvarchar(256)=NULL,
    @AuthenticationType varchar(20)=NULL,
    @PermissionAction varchar(10)=NULL,
    @PermissionName varchar(40)=NULL,
    @ScopeType varchar(20)=NULL,
    @Securable nvarchar(776)=NULL,
    @RoleName sysname=NULL,
    @Justification nvarchar(1000),
    @Targets dbo.AccessRequestTargetType READONLY
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    IF NOT EXISTS(SELECT 1 FROM @Targets)
        THROW 51310,'Debe seleccionar destinos.',1;
    IF (SELECT COUNT(DISTINCT ServerId) FROM @Targets)<>1
        THROW 51314,'Cada solicitud debe pertenecer a un único servidor.',1;
    IF LEN(LTRIM(RTRIM(@Justification)))<10
        THROW 51311,'La justificación debe contener al menos 10 caracteres.',1;

    DECLARE @Check table
    (
        Allowed bit,
        RequiresApproval bit,
        RiskLevel varchar(10),
        Reason nvarchar(2000)
    );
    INSERT @Check
        EXEC dbo.usp_AccessRequest_Preview
            @OperationCode,@PermissionAction,@PermissionName,@ScopeType,@RoleName;
    IF NOT EXISTS(SELECT 1 FROM @Check WHERE Allowed=1)
        THROW 51312,'Solicitud rechazada por la política central.',1;

    BEGIN TRAN;

    -- AccessRequestDuplicateGuard: serializa la comprobación y la inserción.
    DECLARE @LockResult int;
    EXEC @LockResult=sys.sp_getapplock
        @Resource=N'SqlAccessAdmin.AccessRequestCreate',
        @LockMode='Exclusive',
        @LockOwner='Transaction',
        @LockTimeout=10000;
    IF @LockResult<0
        THROW 51317,'No fue posible bloquear el registro de solicitudes.',1;

    DECLARE @ExistingRequestId bigint;
    SELECT TOP(1) @ExistingRequestId=r.RequestId
    FROM dbo.AccessRequest r WITH(UPDLOCK,HOLDLOCK)
    WHERE r.Status IN('PENDING','APPROVED')
      AND r.OperationCode=@OperationCode
      AND UPPER(LTRIM(RTRIM(r.TargetPrincipal)))=UPPER(LTRIM(RTRIM(@TargetPrincipal)))
      AND ISNULL(UPPER(LTRIM(RTRIM(r.SourcePrincipal))),N'')=ISNULL(UPPER(LTRIM(RTRIM(@SourcePrincipal))),N'')
      AND ISNULL(UPPER(r.AuthenticationType),'')=ISNULL(UPPER(@AuthenticationType),'')
      AND ISNULL(UPPER(r.PermissionAction),'')=ISNULL(UPPER(@PermissionAction),'')
      AND ISNULL(UPPER(r.PermissionName),'')=ISNULL(UPPER(@PermissionName),'')
      AND ISNULL(UPPER(r.ScopeType),'')=ISNULL(UPPER(@ScopeType),'')
      AND ISNULL(UPPER(LTRIM(RTRIM(r.Securable))),N'')=ISNULL(UPPER(LTRIM(RTRIM(@Securable))),N'')
      AND ISNULL(UPPER(LTRIM(RTRIM(r.RoleName))),N'')=ISNULL(UPPER(LTRIM(RTRIM(@RoleName))),N'')
      AND NOT EXISTS
      (
          SELECT ServerId,DatabaseName FROM @Targets
          EXCEPT
          SELECT ServerId,DatabaseName FROM dbo.AccessRequestTarget WHERE RequestId=r.RequestId
      )
      AND NOT EXISTS
      (
          SELECT ServerId,DatabaseName FROM dbo.AccessRequestTarget WHERE RequestId=r.RequestId
          EXCEPT
          SELECT ServerId,DatabaseName FROM @Targets
      )
    ORDER BY r.RequestId DESC;

    IF @ExistingRequestId IS NOT NULL
    BEGIN
        ROLLBACK;
        DECLARE @DuplicateMessage nvarchar(2048)=CONCAT(
            N'Ya existe la solicitud activa #',@ExistingRequestId,
            N' con la misma operación, principal y destinos.');
        THROW 51316,@DuplicateMessage,1;
    END;

    INSERT dbo.AccessRequest
    (
        OperationCode,TargetPrincipal,SourcePrincipal,AuthenticationType,
        PermissionAction,PermissionName,ScopeType,Securable,RoleName,Justification
    )
    VALUES
    (
        @OperationCode,@TargetPrincipal,@SourcePrincipal,@AuthenticationType,
        @PermissionAction,@PermissionName,@ScopeType,@Securable,@RoleName,@Justification
    );

    DECLARE @Id bigint=SCOPE_IDENTITY();
    INSERT dbo.AccessRequestTarget(RequestId,ServerId,DatabaseName)
        SELECT @Id,ServerId,DatabaseName FROM @Targets;
    COMMIT;

    DECLARE @AuditDetail nvarchar(max)=CONCAT(
        N'Solicitud #',@Id,N' ',@OperationCode,N' · servidor único · control de duplicados');
    EXEC dbo.usp_Audit_Write N'Solicitudes',N'Crear',NULL,NULL,1,@AuditDetail;
    SELECT @Id RequestId,'PENDING' [Status];
END;
GO

CREATE OR ALTER PROCEDURE dbo.usp_AccessRequest_Approve
    @RequestId bigint,
    @Approve bit,
    @Comment nvarchar(1000)
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    IF IS_SRVROLEMEMBER(N'sysadmin')<>1
       AND NOT EXISTS
       (
           SELECT 1
           FROM dbo.AuthorizedPrincipal
           WHERE Principal=ORIGINAL_LOGIN() AND Active=1 AND RoleName='Administrator'
       )
        THROW 51301,'Se requiere Administrator.',1;

    IF EXISTS
    (
        SELECT 1 FROM dbo.AccessRequest
        WHERE RequestId=@RequestId AND RequestedBy=ORIGINAL_LOGIN()
    )
        THROW 51313,'No se permite autoaprobar una solicitud.',1;

    BEGIN TRAN;
    DECLARE @ApprovalLockResult int;
    EXEC @ApprovalLockResult=sys.sp_getapplock
        @Resource=N'SqlAccessAdmin.AccessRequestApprove',
        @LockMode='Exclusive',
        @LockOwner='Transaction',
        @LockTimeout=10000;
    IF @ApprovalLockResult<0
        THROW 51319,'No fue posible bloquear la aprobación de solicitudes.',1;

    IF @Approve=1 AND EXISTS
    (
        SELECT 1
        FROM dbo.AccessRequest currentRequest
        JOIN dbo.AccessRequest approvedRequest
          ON approvedRequest.RequestId<>currentRequest.RequestId
         AND approvedRequest.Status='APPROVED'
         AND approvedRequest.OperationCode=currentRequest.OperationCode
         AND UPPER(LTRIM(RTRIM(approvedRequest.TargetPrincipal)))=UPPER(LTRIM(RTRIM(currentRequest.TargetPrincipal)))
         AND ISNULL(UPPER(LTRIM(RTRIM(approvedRequest.SourcePrincipal))),N'')=ISNULL(UPPER(LTRIM(RTRIM(currentRequest.SourcePrincipal))),N'')
         AND ISNULL(UPPER(approvedRequest.AuthenticationType),'')=ISNULL(UPPER(currentRequest.AuthenticationType),'')
         AND ISNULL(UPPER(approvedRequest.PermissionAction),'')=ISNULL(UPPER(currentRequest.PermissionAction),'')
         AND ISNULL(UPPER(approvedRequest.PermissionName),'')=ISNULL(UPPER(currentRequest.PermissionName),'')
         AND ISNULL(UPPER(approvedRequest.ScopeType),'')=ISNULL(UPPER(currentRequest.ScopeType),'')
         AND ISNULL(UPPER(LTRIM(RTRIM(approvedRequest.Securable))),N'')=ISNULL(UPPER(LTRIM(RTRIM(currentRequest.Securable))),N'')
         AND ISNULL(UPPER(LTRIM(RTRIM(approvedRequest.RoleName))),N'')=ISNULL(UPPER(LTRIM(RTRIM(currentRequest.RoleName))),N'')
        WHERE currentRequest.RequestId=@RequestId
          AND currentRequest.Status='PENDING'
          AND NOT EXISTS
          (
              SELECT ServerId,DatabaseName
              FROM dbo.AccessRequestTarget
              WHERE RequestId=currentRequest.RequestId
              EXCEPT
              SELECT ServerId,DatabaseName
              FROM dbo.AccessRequestTarget
              WHERE RequestId=approvedRequest.RequestId
          )
          AND NOT EXISTS
          (
              SELECT ServerId,DatabaseName
              FROM dbo.AccessRequestTarget
              WHERE RequestId=approvedRequest.RequestId
              EXCEPT
              SELECT ServerId,DatabaseName
              FROM dbo.AccessRequestTarget
              WHERE RequestId=currentRequest.RequestId
          )
    )
    BEGIN
        ROLLBACK;
        THROW 51318,'Ya existe otra solicitud equivalente aprobada. Rechace este duplicado.',1;
    END;

    UPDATE dbo.AccessRequest
    SET Status=IIF(@Approve=1,'APPROVED','REJECTED'),
        ApprovedBy=ORIGINAL_LOGIN(),
        ApprovedAt=SYSUTCDATETIME(),
        ApprovalComment=@Comment
    WHERE RequestId=@RequestId AND Status='PENDING';
    IF @@ROWCOUNT=0
    BEGIN
        ROLLBACK;
        THROW 51314,'La solicitud no está pendiente.',1;
    END;
    COMMIT;

    DECLARE @Action nvarchar(50)=IIF(@Approve=1,N'Aprobar',N'Rechazar');
    DECLARE @ApprovalAuditDetail nvarchar(max)=CONCAT(N'Solicitud #',@RequestId,N'. ',@Comment);
    EXEC dbo.usp_Audit_Write N'Solicitudes',@Action,NULL,NULL,1,@ApprovalAuditDetail;
END;
GO

GRANT EXECUTE ON dbo.usp_AccessRequest_Create TO [SqlAccessAdmin_Users];
GRANT EXECUTE ON dbo.usp_AccessRequest_Approve TO [SqlAccessAdmin_Administrator];
GO

PRINT N'Control transaccional de solicitudes duplicadas instalado.';
GO
