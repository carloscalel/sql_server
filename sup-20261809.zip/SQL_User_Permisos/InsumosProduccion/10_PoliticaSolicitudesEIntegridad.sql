/* Política de mínimo privilegio, flujo de aprobación y auditoría append-only. */
USE [adminDB];
GO
SET NOCOUNT ON;
SET XACT_ABORT ON;
GO

IF OBJECT_ID(N'dbo.SecurityPolicyOperation',N'U') IS NULL
CREATE TABLE dbo.SecurityPolicyOperation
(
 OperationCode varchar(40) NOT NULL CONSTRAINT PK_SecurityPolicyOperation PRIMARY KEY,
 DisplayName nvarchar(150) NOT NULL,Enabled bit NOT NULL CONSTRAINT DF_PolicyOperation_Enabled DEFAULT(1),
 RequiresApproval bit NOT NULL CONSTRAINT DF_PolicyOperation_Approval DEFAULT(1),
 RiskLevel varchar(10) NOT NULL,Description nvarchar(500) NULL,
 CONSTRAINT CK_PolicyOperation_Risk CHECK(RiskLevel IN('LOW','MEDIUM','HIGH'))
);
GO

IF OBJECT_ID(N'dbo.SecurityPolicyPermission',N'U') IS NULL
CREATE TABLE dbo.SecurityPolicyPermission
(
 PermissionName varchar(40) NOT NULL,ScopeType varchar(20) NOT NULL,
 AllowGrant bit NOT NULL,AllowDeny bit NOT NULL,AllowRevoke bit NOT NULL,Enabled bit NOT NULL CONSTRAINT DF_PolicyPermission_Enabled DEFAULT(1),
 ApprovedBy nvarchar(256) NOT NULL CONSTRAINT DF_PolicyPermission_By DEFAULT(ORIGINAL_LOGIN()),
 ApprovedAt datetime2(3) NOT NULL CONSTRAINT DF_PolicyPermission_At DEFAULT(SYSUTCDATETIME()),
 CONSTRAINT PK_SecurityPolicyPermission PRIMARY KEY(PermissionName,ScopeType),
 CONSTRAINT CK_PolicyPermission_Scope CHECK(ScopeType IN('DATABASE','SCHEMA','OBJECT','COLUMN'))
);
GO

IF OBJECT_ID(N'dbo.SecurityPolicyRole',N'U') IS NULL
CREATE TABLE dbo.SecurityPolicyRole
(
 RoleName sysname NOT NULL CONSTRAINT PK_SecurityPolicyRole PRIMARY KEY,
 RoleKind varchar(10) NOT NULL,Enabled bit NOT NULL CONSTRAINT DF_PolicyRole_Enabled DEFAULT(1),
 ApprovedBy nvarchar(256) NOT NULL CONSTRAINT DF_PolicyRole_By DEFAULT(ORIGINAL_LOGIN()),
 ApprovedAt datetime2(3) NOT NULL CONSTRAINT DF_PolicyRole_At DEFAULT(SYSUTCDATETIME()),
 Notes nvarchar(500) NULL,CONSTRAINT CK_PolicyRole_Kind CHECK(RoleKind IN('FIXED','CUSTOM'))
);
GO

IF OBJECT_ID(N'dbo.SecurityDenyList',N'U') IS NULL
CREATE TABLE dbo.SecurityDenyList
(
 DenyId int IDENTITY(1,1) NOT NULL CONSTRAINT PK_SecurityDenyList PRIMARY KEY,
 Category varchar(30) NOT NULL,DeniedValue nvarchar(256) NOT NULL,Reason nvarchar(1000) NOT NULL,
 IsSystem bit NOT NULL CONSTRAINT DF_DenyList_System DEFAULT(0),Active bit NOT NULL CONSTRAINT DF_DenyList_Active DEFAULT(1),
 CreatedBy nvarchar(256) NOT NULL CONSTRAINT DF_DenyList_By DEFAULT(ORIGINAL_LOGIN()),CreatedAt datetime2(3) NOT NULL CONSTRAINT DF_DenyList_At DEFAULT(SYSUTCDATETIME()),
 CONSTRAINT UQ_SecurityDenyList UNIQUE(Category,DeniedValue)
);
GO

IF OBJECT_ID(N'dbo.AccessRequest',N'U') IS NULL
CREATE TABLE dbo.AccessRequest
(
 RequestId bigint IDENTITY(1,1) NOT NULL CONSTRAINT PK_AccessRequest PRIMARY KEY,
 OperationCode varchar(40) NOT NULL,TargetPrincipal nvarchar(256) NOT NULL,SourcePrincipal nvarchar(256) NULL,
 AuthenticationType varchar(20) NULL,PermissionAction varchar(10) NULL,PermissionName varchar(40) NULL,
 ScopeType varchar(20) NULL,Securable nvarchar(776) NULL,RoleName sysname NULL,Justification nvarchar(1000) NOT NULL,
 Status varchar(20) NOT NULL CONSTRAINT DF_AccessRequest_Status DEFAULT('PENDING'),
 RequestedBy nvarchar(256) NOT NULL CONSTRAINT DF_AccessRequest_By DEFAULT(ORIGINAL_LOGIN()),RequestedAt datetime2(3) NOT NULL CONSTRAINT DF_AccessRequest_At DEFAULT(SYSUTCDATETIME()),
 ApprovedBy nvarchar(256) NULL,ApprovedAt datetime2(3) NULL,ApprovalComment nvarchar(1000) NULL,
 ExecutedBy nvarchar(256) NULL,ExecutedAt datetime2(3) NULL,
 CONSTRAINT FK_AccessRequest_Operation FOREIGN KEY(OperationCode) REFERENCES dbo.SecurityPolicyOperation(OperationCode),
 CONSTRAINT CK_AccessRequest_Status CHECK(Status IN('PENDING','APPROVED','REJECTED','EXECUTED','FAILED','CANCELLED')),
 CONSTRAINT CK_AccessRequest_Action CHECK(PermissionAction IS NULL OR PermissionAction IN('GRANT','DENY','REVOKE'))
);
GO

IF OBJECT_ID(N'dbo.AccessRequestTarget',N'U') IS NULL
CREATE TABLE dbo.AccessRequestTarget
(
 RequestId bigint NOT NULL,ServerId int NOT NULL,DatabaseName sysname NOT NULL,
 CONSTRAINT PK_AccessRequestTarget PRIMARY KEY(RequestId,ServerId,DatabaseName),
 CONSTRAINT FK_RequestTarget_Request FOREIGN KEY(RequestId) REFERENCES dbo.AccessRequest(RequestId),
 CONSTRAINT FK_RequestTarget_Server FOREIGN KEY(ServerId) REFERENCES dbo.ManagedServer(ServerId)
);
GO

IF TYPE_ID(N'dbo.AccessRequestTargetType') IS NULL
EXEC(N'CREATE TYPE dbo.AccessRequestTargetType AS TABLE(ServerId int NOT NULL,DatabaseName sysname NOT NULL,PRIMARY KEY(ServerId,DatabaseName));');
GO

MERGE dbo.SecurityPolicyOperation AS t USING(VALUES
 ('QUERY_SECURITY',N'Consultar seguridad','LOW',0,N'Consulta de logins, usuarios, roles y permisos'),
 ('CREATE_SQL_LOGIN',N'Crear login SQL','HIGH',1,N'Crea un login SQL sin roles de servidor'),
 ('CREATE_WINDOWS_LOGIN',N'Crear login Windows','MEDIUM',1,N'Crea un login para una identidad Windows existente'),
 ('MODIFY_LOGIN',N'Modificar login','HIGH',1,N'Cambia la base predeterminada y, para autenticación SQL, permite restablecer la contraseña durante la ejecución'),
 ('CREATE_DB_USER',N'Crear usuario de base','MEDIUM',1,N'Crea usuario asociado a un login existente'),
 ('ADD_ROLE_MEMBER',N'Agregar membresía de rol','MEDIUM',1,N'Rol fijo permitido o personalizado aprobado'),
 ('REMOVE_ROLE_MEMBER',N'Quitar membresía de rol','MEDIUM',1,N'Retira una membresía administrada'),
 ('PERMISSION_CHANGE',N'GRANT, DENY o REVOKE','HIGH',1,N'Permiso y ámbito expresamente permitidos'),
 ('ENABLE_LOGIN',N'Habilitar login','MEDIUM',1,N'Habilita un login sin cambiar privilegios'),
 ('DISABLE_LOGIN',N'Deshabilitar login','MEDIUM',1,N'Deshabilita un login sin eliminarlo')
)s(OperationCode,DisplayName,RiskLevel,RequiresApproval,Description) ON t.OperationCode=s.OperationCode
WHEN NOT MATCHED THEN INSERT(OperationCode,DisplayName,RiskLevel,RequiresApproval,Description) VALUES(s.OperationCode,s.DisplayName,s.RiskLevel,s.RequiresApproval,s.Description);
GO

MERGE dbo.SecurityPolicyPermission AS t USING(VALUES
 ('SELECT','DATABASE',1,0,1),('SELECT','OBJECT',1,0,1),
 ('INSERT','DATABASE',1,0,1),('INSERT','OBJECT',1,0,1),
 ('UPDATE','DATABASE',1,0,1),('UPDATE','OBJECT',1,0,1),
 ('DELETE','DATABASE',1,0,1),('DELETE','OBJECT',1,0,1),
 ('EXECUTE','DATABASE',1,0,1),('EXECUTE','OBJECT',1,0,1)
)s(PermissionName,ScopeType,AllowGrant,AllowDeny,AllowRevoke) ON t.PermissionName=s.PermissionName AND t.ScopeType=s.ScopeType
WHEN NOT MATCHED THEN INSERT(PermissionName,ScopeType,AllowGrant,AllowDeny,AllowRevoke) VALUES(s.PermissionName,s.ScopeType,s.AllowGrant,s.AllowDeny,s.AllowRevoke);
GO

MERGE dbo.SecurityPolicyRole AS t USING(VALUES('db_datareader','FIXED',N'Lectura de todas las tablas y vistas'),('db_datawriter','FIXED',N'Escritura en todas las tablas'))s(RoleName,RoleKind,Notes)
ON t.RoleName=s.RoleName WHEN NOT MATCHED THEN INSERT(RoleName,RoleKind,Notes) VALUES(s.RoleName,s.RoleKind,s.Notes);
GO

MERGE dbo.SecurityDenyList AS t USING(VALUES
 ('SERVER_ROLE','sysadmin',N'Control total de instancia'),('SERVER_ROLE','securityadmin',N'Ruta de escalamiento'),('SERVER_ROLE','serveradmin',N'Configuración de instancia'),('SERVER_ROLE','setupadmin',N'Configuración sensible'),('SERVER_ROLE','processadmin',N'Control de procesos'),('SERVER_ROLE','diskadmin',N'Administración de disco'),('SERVER_ROLE','bulkadmin',N'Importación masiva no aprobada'),
 ('DATABASE_ROLE','db_owner',N'Control total de base'),('DATABASE_ROLE','db_securityadmin',N'Puede delegar permisos'),('DATABASE_ROLE','db_accessadmin',N'Administra acceso'),('DATABASE_ROLE','db_ddladmin',N'Puede modificar objetos'),('DATABASE_ROLE','db_backupoperator',N'No aprobado por política inicial'),
 ('PERMISSION','CONTROL SERVER',N'Control total de instancia'),('PERMISSION','CONTROL',N'Control de securable'),('PERMISSION','ALTER ANY SERVER ROLE',N'Escalamiento'),('PERMISSION','ALTER ANY LOGIN',N'Escalamiento'),('PERMISSION','ALTER ANY USER',N'Escalamiento'),('PERMISSION','ALTER ANY ROLE',N'Escalamiento'),('PERMISSION','ALTER ANY SCHEMA',N'Escalamiento'),('PERMISSION','IMPERSONATE',N'Suplantación'),('PERMISSION','IMPERSONATE ANY LOGIN',N'Suplantación'),('PERMISSION','TAKE OWNERSHIP',N'Cambio de propietario'),('PERMISSION','ALTER AUTHORIZATION',N'Cambio de propietario'),('PERMISSION','UNSAFE ASSEMBLY',N'Ejecución no segura'),('PERMISSION','EXTERNAL ACCESS ASSEMBLY',N'Acceso externo'),('PERMISSION','CREATE ASSEMBLY',N'Código en SQL Server'),('CLAUSE','WITH GRANT OPTION',N'No se permite redelegación'),
 ('OPERATION','FREE_TSQL',N'Nunca se ejecuta T-SQL proporcionado por operadores'),('OPERATION','KILL',N'Operación excluida'),('OPERATION','TRUSTWORTHY',N'Operación excluida'),('OPERATION','ALTER_AUTHORIZATION',N'Operación excluida')
)s(Category,DeniedValue,Reason) ON t.Category=s.Category AND t.DeniedValue=s.DeniedValue
WHEN NOT MATCHED THEN INSERT(Category,DeniedValue,Reason,IsSystem) VALUES(s.Category,s.DeniedValue,s.Reason,1);
GO

IF COL_LENGTH(N'dbo.AuditEvent',N'PreviousHash') IS NULL ALTER TABLE dbo.AuditEvent ADD PreviousHash varbinary(32) NULL,EventHash varbinary(32) NULL;
GO

CREATE OR ALTER TRIGGER dbo.tr_AuditEvent_AppendOnly ON dbo.AuditEvent INSTEAD OF UPDATE,DELETE AS
BEGIN THROW 51300,'AuditEvent es append-only; UPDATE y DELETE están prohibidos.',1; END;
GO

CREATE OR ALTER PROCEDURE dbo.usp_Audit_Write
    @Form nvarchar(100),@Action nvarchar(100),@ServerName sysname=NULL,@DatabaseName sysname=NULL,
    @Success bit,@Detail nvarchar(2000)=NULL,@CorrelationId uniqueidentifier=NULL
AS
BEGIN
 SET NOCOUNT ON;SET XACT_ABORT ON;
 DECLARE @LockResult int,@PreviousHash varbinary(32),@EventHash varbinary(32),@EventDate datetime2(3)=SYSUTCDATETIME(),@Principal nvarchar(256)=ORIGINAL_LOGIN(),@Correlation uniqueidentifier=COALESCE(@CorrelationId,NEWID()),@Payload nvarchar(max);
 BEGIN TRAN;
 EXEC @LockResult=sys.sp_getapplock @Resource=N'SqlAccessAdmin.AuditHashChain',@LockMode='Exclusive',@LockOwner='Transaction',@LockTimeout=10000;
 IF @LockResult<0 THROW 51320,'No fue posible bloquear la cadena de auditoría.',1;
 SELECT TOP(1) @PreviousHash=EventHash FROM dbo.AuditEvent WITH(UPDLOCK,HOLDLOCK) WHERE EventHash IS NOT NULL ORDER BY AuditId DESC;
 SET @PreviousHash=COALESCE(@PreviousHash,CONVERT(varbinary(32),0x));
 SET @Payload=CONCAT(CONVERT(nvarchar(33),@EventDate,126),N'|',@Principal,N'|',@Form,N'|',@Action,N'|',COALESCE(@ServerName,N''),N'|',COALESCE(@DatabaseName,N''),N'|',CONVERT(nvarchar(1),@Success),N'|',COALESCE(@Detail,N''),N'|',CONVERT(nvarchar(36),@Correlation));
 SET @EventHash=HASHBYTES('SHA2_256',@PreviousHash+CONVERT(varbinary(max),@Payload));
 INSERT dbo.AuditEvent(EventDate,Principal,Form,Action,ServerName,DatabaseName,Success,Detail,CorrelationId,PreviousHash,EventHash)
 VALUES(@EventDate,@Principal,@Form,@Action,@ServerName,@DatabaseName,@Success,@Detail,@Correlation,@PreviousHash,@EventHash);
 COMMIT;
END;
GO

CREATE OR ALTER PROCEDURE dbo.usp_Audit_ValidateIntegrity
AS
BEGIN
 SET NOCOUNT ON;
 ;WITH c AS
 (
  SELECT AuditId,PreviousHash,EventHash,LAG(EventHash,1,CONVERT(varbinary(32),0x)) OVER(ORDER BY AuditId) ExpectedPrevious,
   HASHBYTES('SHA2_256',PreviousHash+CONVERT(varbinary(max),CONCAT(CONVERT(nvarchar(33),EventDate,126),N'|',Principal,N'|',Form,N'|',Action,N'|',COALESCE(ServerName,N''),N'|',COALESCE(DatabaseName,N''),N'|',CONVERT(nvarchar(1),Success),N'|',COALESCE(Detail,N''),N'|',CONVERT(nvarchar(36),CorrelationId)))) ExpectedHash
  FROM dbo.AuditEvent WHERE EventHash IS NOT NULL
 )
 SELECT COUNT_BIG(*) HashedEvents,COALESCE(SUM(CASE WHEN PreviousHash=ExpectedPrevious THEN 0 ELSE 1 END),0) BrokenLinks,
        COALESCE(SUM(CASE WHEN EventHash=ExpectedHash THEN 0 ELSE 1 END),0) AlteredEvents,
        CAST(IIF(COALESCE(SUM(CASE WHEN PreviousHash=ExpectedPrevious AND EventHash=ExpectedHash THEN 0 ELSE 1 END),0)=0,1,0) AS bit) IsValid
 FROM c;
END;
GO

CREATE OR ALTER PROCEDURE dbo.usp_Policy_OperationList AS SELECT OperationCode,DisplayName,Enabled,RequiresApproval,RiskLevel,ISNULL(Description,N'') Description FROM dbo.SecurityPolicyOperation ORDER BY DisplayName;
GO
CREATE OR ALTER PROCEDURE dbo.usp_Policy_PermissionList AS SELECT PermissionName,ScopeType,AllowGrant,AllowDeny,AllowRevoke,Enabled,ApprovedBy,ApprovedAt FROM dbo.SecurityPolicyPermission ORDER BY PermissionName,ScopeType;
GO
CREATE OR ALTER PROCEDURE dbo.usp_Policy_RoleList AS SELECT RoleName,RoleKind,Enabled,ApprovedBy,ApprovedAt,ISNULL(Notes,N'') Notes FROM dbo.SecurityPolicyRole ORDER BY RoleKind,RoleName;
GO
CREATE OR ALTER PROCEDURE dbo.usp_Policy_DenyList AS SELECT DenyId,Category,DeniedValue,Reason,IsSystem,Active,CreatedBy,CreatedAt FROM dbo.SecurityDenyList ORDER BY Category,DeniedValue;
GO

CREATE OR ALTER PROCEDURE dbo.usp_Policy_PermissionUpsert @PermissionName varchar(40),@ScopeType varchar(20),@AllowGrant bit,@AllowDeny bit,@AllowRevoke bit,@Enabled bit
AS
BEGIN
 SET NOCOUNT ON;
 IF IS_SRVROLEMEMBER(N'sysadmin')<>1 AND NOT EXISTS(SELECT 1 FROM dbo.AuthorizedPrincipal WHERE Principal=ORIGINAL_LOGIN() AND Active=1 AND RoleName='Administrator') THROW 51301,'Se requiere Administrator.',1;
 IF UPPER(@PermissionName) NOT IN('SELECT','INSERT','UPDATE','DELETE','EXECUTE') THROW 51302,'Permiso fuera de la allowlist máxima.',1;
 IF UPPER(@ScopeType) NOT IN('DATABASE','OBJECT') THROW 51303,'Ámbito no permitido.',1;
 IF @AllowDeny=1 THROW 51306,'DENY no está habilitado por la política simplificada.',1;
 MERGE dbo.SecurityPolicyPermission t USING(SELECT UPPER(@PermissionName) PermissionName,UPPER(@ScopeType) ScopeType)s ON t.PermissionName=s.PermissionName AND t.ScopeType=s.ScopeType
 WHEN MATCHED THEN UPDATE SET AllowGrant=@AllowGrant,AllowDeny=@AllowDeny,AllowRevoke=@AllowRevoke,Enabled=@Enabled,ApprovedBy=ORIGINAL_LOGIN(),ApprovedAt=SYSUTCDATETIME()
 WHEN NOT MATCHED THEN INSERT(PermissionName,ScopeType,AllowGrant,AllowDeny,AllowRevoke,Enabled) VALUES(s.PermissionName,s.ScopeType,@AllowGrant,@AllowDeny,@AllowRevoke,@Enabled);
 -- Declarar y construir la variable antes de la llamada
 DECLARE @Detail NVARCHAR(MAX) = CONCAT(@PermissionName, N'/', @ScopeType);
 EXEC dbo.usp_Audit_Write N'Política central',N'Actualizar permiso',NULL,NULL,1,@Detail;
END;
GO

-- Los roles SQL son inmutables para la aplicación. Este catálogo solo controla
-- cuáles roles preaprobados pueden asignarse o retirarse como membresías.
DROP PROCEDURE IF EXISTS dbo.usp_Policy_RoleUpsert;
GO

CREATE OR ALTER PROCEDURE dbo.usp_Policy_DenyUpsert @Category varchar(30),@DeniedValue nvarchar(256),@Reason nvarchar(1000),@Active bit=1
AS
BEGIN
 SET NOCOUNT ON;
 IF IS_SRVROLEMEMBER(N'sysadmin')<>1 AND NOT EXISTS(SELECT 1 FROM dbo.AuthorizedPrincipal WHERE Principal=ORIGINAL_LOGIN() AND Active=1 AND RoleName='Administrator') THROW 51301,'Se requiere Administrator.',1;
 MERGE dbo.SecurityDenyList t USING(SELECT UPPER(@Category) Category,@DeniedValue DeniedValue)s ON t.Category=s.Category AND UPPER(t.DeniedValue)=UPPER(s.DeniedValue)
 WHEN MATCHED THEN UPDATE SET Reason=@Reason,Active=CASE WHEN t.IsSystem=1 THEN 1 ELSE @Active END
 WHEN NOT MATCHED THEN INSERT(Category,DeniedValue,Reason,Active) VALUES(s.Category,s.DeniedValue,@Reason,@Active);
 -- Variable previa para almacenar el resultado de CONCAT
 DECLARE @AuditDetail NVARCHAR(MAX) = CONCAT(@Category, N':', @DeniedValue);
 EXEC dbo.usp_Audit_Write N'Política central',N'Agregar bloqueo',NULL,NULL,1,@AuditDetail;
END;
GO

CREATE OR ALTER PROCEDURE dbo.usp_AccessRequest_Preview @OperationCode varchar(40),@PermissionAction varchar(10)=NULL,@PermissionName varchar(40)=NULL,@ScopeType varchar(20)=NULL,@RoleName sysname=NULL
AS
BEGIN
 SET NOCOUNT ON;
 DECLARE @Allowed bit=1,@Reason nvarchar(2000)=N'La solicitud cumple la allowlist central.',@Risk varchar(10),@Approval bit;
 SELECT @Risk=RiskLevel,@Approval=RequiresApproval FROM dbo.SecurityPolicyOperation WHERE OperationCode=@OperationCode AND Enabled=1;
 IF @Risk IS NULL SELECT @Allowed=0,@Reason=N'Operación no registrada o deshabilitada.';
 IF @RoleName IS NOT NULL AND (EXISTS(SELECT 1 FROM dbo.SecurityDenyList WHERE Active=1 AND Category IN('DATABASE_ROLE','SERVER_ROLE') AND UPPER(DeniedValue)=UPPER(@RoleName)) OR NOT EXISTS(SELECT 1 FROM dbo.SecurityPolicyRole WHERE Enabled=1 AND RoleName=@RoleName)) SELECT @Allowed=0,@Reason=N'Rol bloqueado o no aprobado.';
 IF @PermissionName IS NOT NULL AND (EXISTS(SELECT 1 FROM dbo.SecurityDenyList WHERE Active=1 AND Category='PERMISSION' AND UPPER(DeniedValue)=UPPER(@PermissionName)) OR NOT EXISTS(SELECT 1 FROM dbo.SecurityPolicyPermission WHERE Enabled=1 AND PermissionName=UPPER(@PermissionName) AND ScopeType=UPPER(@ScopeType) AND ((@PermissionAction='GRANT' AND AllowGrant=1) OR (@PermissionAction='DENY' AND AllowDeny=1) OR (@PermissionAction='REVOKE' AND AllowRevoke=1)))) SELECT @Allowed=0,@Reason=N'Permiso, acción o ámbito fuera de allowlist.';
 SELECT @Allowed Allowed,ISNULL(@Approval,1) RequiresApproval,ISNULL(@Risk,'HIGH') RiskLevel,@Reason Reason;
END;
GO

CREATE OR ALTER PROCEDURE dbo.usp_AccessRequest_Create @OperationCode varchar(40),@TargetPrincipal nvarchar(256),@SourcePrincipal nvarchar(256)=NULL,@AuthenticationType varchar(20)=NULL,@PermissionAction varchar(10)=NULL,@PermissionName varchar(40)=NULL,@ScopeType varchar(20)=NULL,@Securable nvarchar(776)=NULL,@RoleName sysname=NULL,@Justification nvarchar(1000),@Targets dbo.AccessRequestTargetType READONLY
AS
BEGIN
 SET NOCOUNT ON;SET XACT_ABORT ON;
 IF NOT EXISTS(SELECT 1 FROM @Targets) THROW 51310,'Debe seleccionar destinos.',1;
 IF (SELECT COUNT(DISTINCT ServerId) FROM @Targets)<>1 THROW 51314,'Cada solicitud debe pertenecer a un único servidor.',1;
 IF LEN(LTRIM(RTRIM(@Justification)))<10 THROW 51311,'La justificación debe contener al menos 10 caracteres.',1;
 DECLARE @Check table(Allowed bit,RequiresApproval bit,RiskLevel varchar(10),Reason nvarchar(2000));
 INSERT @Check EXEC dbo.usp_AccessRequest_Preview @OperationCode,@PermissionAction,@PermissionName,@ScopeType,@RoleName;
 IF NOT EXISTS(SELECT 1 FROM @Check WHERE Allowed=1) THROW 51312,'Solicitud rechazada por la política central.',1;
 BEGIN TRAN;
 INSERT dbo.AccessRequest(OperationCode,TargetPrincipal,SourcePrincipal,AuthenticationType,PermissionAction,PermissionName,ScopeType,Securable,RoleName,Justification)
 VALUES(@OperationCode,@TargetPrincipal,@SourcePrincipal,@AuthenticationType,@PermissionAction,@PermissionName,@ScopeType,@Securable,@RoleName,@Justification);
 DECLARE @Id bigint=SCOPE_IDENTITY();INSERT dbo.AccessRequestTarget SELECT @Id,ServerId,DatabaseName FROM @Targets;
 COMMIT;
 -- Concatenación en variable antes del EXEC
 DECLARE @AuditDetail NVARCHAR(MAX) = CONCAT(N'Solicitud #', @Id, N' ', @OperationCode);
 EXEC dbo.usp_Audit_Write N'Solicitudes',N'Crear',NULL,NULL,1,@AuditDetail;SELECT @Id RequestId,'PENDING' [Status];
END;
GO

CREATE OR ALTER PROCEDURE dbo.usp_AccessRequest_List @Status varchar(20)=NULL,@ServerId int=NULL
AS
BEGIN SET NOCOUNT ON;SELECT r.RequestId,r.OperationCode,r.TargetPrincipal,ISNULL(r.SourcePrincipal,N'') SourcePrincipal,ISNULL(r.AuthenticationType,'') AuthenticationType,ISNULL(r.PermissionAction,'') PermissionAction,ISNULL(r.PermissionName,'') PermissionName,ISNULL(r.ScopeType,'') ScopeType,ISNULL(r.Securable,N'') Securable,ISNULL(r.RoleName,N'') RoleName,r.Justification,r.Status,r.RequestedBy,r.RequestedAt,ISNULL(r.ApprovedBy,N'') ApprovedBy,r.ApprovedAt,(SELECT COUNT(*) FROM dbo.AccessRequestTarget t WHERE t.RequestId=r.RequestId) TargetCount FROM dbo.AccessRequest r WHERE (@Status IS NULL OR r.Status=@Status) AND (@ServerId IS NULL OR (EXISTS(SELECT 1 FROM dbo.AccessRequestTarget st WHERE st.RequestId=r.RequestId AND st.ServerId=@ServerId) AND NOT EXISTS(SELECT 1 FROM dbo.AccessRequestTarget other WHERE other.RequestId=r.RequestId AND other.ServerId<>@ServerId))) ORDER BY r.RequestedAt DESC;END;
GO

CREATE OR ALTER PROCEDURE dbo.usp_AccessRequest_TargetList @RequestId bigint
AS
BEGIN SET NOCOUNT ON;SELECT t.ServerId,s.Name AS Server,t.DatabaseName AS [Database] FROM dbo.AccessRequestTarget t JOIN dbo.ManagedServer s ON s.ServerId=t.ServerId WHERE t.RequestId=@RequestId ORDER BY s.Name,t.DatabaseName;END;
GO

CREATE OR ALTER PROCEDURE dbo.usp_AccessRequest_Approve @RequestId bigint,@Approve bit,@Comment nvarchar(1000)
AS
BEGIN
 SET NOCOUNT ON;
 IF IS_SRVROLEMEMBER(N'sysadmin')<>1 AND NOT EXISTS(SELECT 1 FROM dbo.AuthorizedPrincipal WHERE Principal=ORIGINAL_LOGIN() AND Active=1 AND RoleName='Administrator') THROW 51301,'Se requiere Administrator.',1;
 IF EXISTS(SELECT 1 FROM dbo.AccessRequest WHERE RequestId=@RequestId AND RequestedBy=ORIGINAL_LOGIN()) THROW 51313,'No se permite autoaprobar una solicitud.',1;
 UPDATE dbo.AccessRequest SET Status=IIF(@Approve=1,'APPROVED','REJECTED'),ApprovedBy=ORIGINAL_LOGIN(),ApprovedAt=SYSUTCDATETIME(),ApprovalComment=@Comment WHERE RequestId=@RequestId AND Status='PENDING';
 IF @@ROWCOUNT=0 THROW 51314,'La solicitud no está pendiente.',1;
 -- Evaluar expresiones antes de pasar los parámetros al EXEC
 DECLARE @Action NVARCHAR(50) = IIF(@Approve = 1, N'Aprobar', N'Rechazar');
 DECLARE @AuditDetail NVARCHAR(MAX) = CONCAT(N'Solicitud #', @RequestId, N'. ', @Comment);
 EXEC dbo.usp_Audit_Write N'Solicitudes',@Action,NULL,NULL,1,@AuditDetail;
END;
GO

CREATE OR ALTER PROCEDURE dbo.usp_AccessRequest_MarkExecuted @RequestId bigint,@Success bit,@Detail nvarchar(2000)
AS
BEGIN
 SET NOCOUNT ON;SET XACT_ABORT ON;
 IF IS_SRVROLEMEMBER(N'sysadmin')<>1 AND NOT EXISTS(SELECT 1 FROM dbo.AuthorizedPrincipal WHERE Principal=ORIGINAL_LOGIN() AND Active=1 AND RoleName='Administrator') THROW 51301,'Se requiere Administrator.',1;
 UPDATE dbo.AccessRequest SET Status=IIF(@Success=1,'EXECUTED','FAILED'),ExecutedBy=ORIGINAL_LOGIN(),ExecutedAt=SYSUTCDATETIME() WHERE RequestId=@RequestId AND Status='APPROVED';
 IF @@ROWCOUNT=0 THROW 51315,'La solicitud no está aprobada o ya fue procesada.',1;
 EXEC dbo.usp_Audit_Write N'Solicitudes',N'Ejecutar',NULL,NULL,@Success,@Detail;
END;
GO

GRANT EXECUTE ON dbo.usp_Policy_OperationList TO [SqlAccessAdmin_Users];
GRANT EXECUTE ON dbo.usp_Policy_PermissionList TO [SqlAccessAdmin_Users];
GRANT EXECUTE ON dbo.usp_Policy_RoleList TO [SqlAccessAdmin_Users];
GRANT EXECUTE ON dbo.usp_Policy_DenyList TO [SqlAccessAdmin_Users];
GRANT EXECUTE ON dbo.usp_AccessRequest_Preview TO [SqlAccessAdmin_Users];
GRANT EXECUTE ON dbo.usp_AccessRequest_Create TO [SqlAccessAdmin_Users];
GRANT EXECUTE ON dbo.usp_AccessRequest_List TO [SqlAccessAdmin_Users];
GRANT EXECUTE ON dbo.usp_AccessRequest_TargetList TO [SqlAccessAdmin_Users];
GRANT EXECUTE ON dbo.usp_Audit_ValidateIntegrity TO [SqlAccessAdmin_Users];
GRANT REFERENCES ON TYPE::dbo.AccessRequestTargetType TO [SqlAccessAdmin_Users];
GRANT EXECUTE ON dbo.usp_Policy_PermissionUpsert TO [SqlAccessAdmin_Administrator];
GRANT EXECUTE ON dbo.usp_Policy_DenyUpsert TO [SqlAccessAdmin_Administrator];
GRANT EXECUTE ON dbo.usp_AccessRequest_Approve TO [SqlAccessAdmin_Administrator];
GRANT EXECUTE ON dbo.usp_AccessRequest_MarkExecuted TO [SqlAccessAdmin_Administrator];
GO
