USE [adminDB];
GO
SET NOCOUNT ON;
GO

IF DATABASE_PRINCIPAL_ID(N'SqlAccessAdmin_Administrator') IS NULL CREATE ROLE [SqlAccessAdmin_Administrator] AUTHORIZATION [dbo];
IF DATABASE_PRINCIPAL_ID(N'SqlAccessAdmin_Operator') IS NULL CREATE ROLE [SqlAccessAdmin_Operator] AUTHORIZATION [dbo];
IF DATABASE_PRINCIPAL_ID(N'SqlAccessAdmin_Auditor') IS NULL CREATE ROLE [SqlAccessAdmin_Auditor] AUTHORIZATION [dbo];
IF DATABASE_PRINCIPAL_ID(N'SqlAccessAdmin_Users') IS NULL CREATE ROLE [SqlAccessAdmin_Users] AUTHORIZATION [dbo];
GO

GRANT EXECUTE ON dbo.usp_App_LoginContext TO [SqlAccessAdmin_Users];
GRANT EXECUTE ON dbo.usp_Server_List TO [SqlAccessAdmin_Users];
GRANT EXECUTE ON dbo.usp_AuthorizedUser_List TO [SqlAccessAdmin_Users];
GRANT EXECUTE ON dbo.usp_Audit_List TO [SqlAccessAdmin_Users];
GRANT EXECUTE ON dbo.usp_Audit_Write TO [SqlAccessAdmin_Users];

GRANT EXECUTE ON dbo.usp_AuthorizedUser_Upsert TO [SqlAccessAdmin_Administrator];
GRANT EXECUTE ON dbo.usp_Server_Upsert TO [SqlAccessAdmin_Administrator];
GRANT EXECUTE ON dbo.usp_Server_SetActive TO [SqlAccessAdmin_Administrator];
GRANT EXECUTE ON dbo.usp_Server_GetConnection TO [SqlAccessAdmin_Administrator];
GRANT EXECUTE ON dbo.usp_Server_GetConnection TO [SqlAccessAdmin_Operator];

GRANT EXECUTE ON dbo.usp_Server_List TO [SqlAccessAdmin_Auditor];
GRANT EXECUTE ON dbo.usp_AuthorizedUser_List TO [SqlAccessAdmin_Auditor];
GRANT EXECUTE ON dbo.usp_Audit_List TO [SqlAccessAdmin_Auditor];

DENY SELECT, INSERT, UPDATE, DELETE ON dbo.AuthorizedPrincipal TO [SqlAccessAdmin_Users];
DENY SELECT, INSERT, UPDATE, DELETE ON dbo.ManagedServer TO [SqlAccessAdmin_Users];
DENY INSERT, UPDATE, DELETE ON dbo.AuditEvent TO [SqlAccessAdmin_Users];
GO
