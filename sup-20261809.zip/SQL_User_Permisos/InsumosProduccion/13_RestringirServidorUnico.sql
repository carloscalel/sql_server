USE [adminDB];
GO
SET NOCOUNT ON;
SET XACT_ABORT ON;
GO

/*
  Cada solicitud nueva queda limitada a un único servidor.
  Las solicitudes históricas multiserver se conservan para auditoría, pero la
  aplicación actual las rechazará durante la ejecución.
*/

CREATE OR ALTER PROCEDURE dbo.usp_AccessRequest_List
    @Status varchar(20)=NULL,
    @ServerId int=NULL
AS
BEGIN
    SET NOCOUNT ON;
    SELECT
        r.RequestId,r.OperationCode,r.TargetPrincipal,
        ISNULL(r.SourcePrincipal,N'') SourcePrincipal,
        ISNULL(r.AuthenticationType,'') AuthenticationType,
        ISNULL(r.PermissionAction,'') PermissionAction,
        ISNULL(r.PermissionName,'') PermissionName,
        ISNULL(r.ScopeType,'') ScopeType,
        ISNULL(r.Securable,N'') Securable,
        ISNULL(r.RoleName,N'') RoleName,
        r.Justification,r.Status,r.RequestedBy,r.RequestedAt,
        ISNULL(r.ApprovedBy,N'') ApprovedBy,r.ApprovedAt,
        (SELECT COUNT(*) FROM dbo.AccessRequestTarget t WHERE t.RequestId=r.RequestId) TargetCount
    FROM dbo.AccessRequest r
    WHERE (@Status IS NULL OR r.Status=@Status)
      AND (@ServerId IS NULL OR
          (EXISTS(SELECT 1 FROM dbo.AccessRequestTarget st WHERE st.RequestId=r.RequestId AND st.ServerId=@ServerId)
           AND NOT EXISTS(SELECT 1 FROM dbo.AccessRequestTarget other WHERE other.RequestId=r.RequestId AND other.ServerId<>@ServerId)))
    ORDER BY r.RequestedAt DESC;
END;
GO

CREATE OR ALTER PROCEDURE dbo.usp_AccessRequest_Create
    @OperationCode varchar(40),@TargetPrincipal nvarchar(256),@SourcePrincipal nvarchar(256)=NULL,
    @AuthenticationType varchar(20)=NULL,@PermissionAction varchar(10)=NULL,@PermissionName varchar(40)=NULL,
    @ScopeType varchar(20)=NULL,@Securable nvarchar(776)=NULL,@RoleName sysname=NULL,
    @Justification nvarchar(1000),@Targets dbo.AccessRequestTargetType READONLY
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    IF NOT EXISTS(SELECT 1 FROM @Targets) THROW 51310,'Debe seleccionar destinos.',1;
    IF (SELECT COUNT(DISTINCT ServerId) FROM @Targets)<>1 THROW 51314,'Cada solicitud debe pertenecer a un único servidor.',1;
    IF LEN(LTRIM(RTRIM(@Justification)))<10 THROW 51311,'La justificación debe contener al menos 10 caracteres.',1;
    DECLARE @Check table(Allowed bit,RequiresApproval bit,RiskLevel varchar(10),Reason nvarchar(2000));
    INSERT @Check EXEC dbo.usp_AccessRequest_Preview @OperationCode,@PermissionAction,@PermissionName,@ScopeType,@RoleName;
    IF NOT EXISTS(SELECT 1 FROM @Check WHERE Allowed=1) THROW 51312,'Solicitud rechazada por la política central.',1;
    BEGIN TRAN;
    INSERT dbo.AccessRequest(OperationCode,TargetPrincipal,SourcePrincipal,AuthenticationType,PermissionAction,PermissionName,ScopeType,Securable,RoleName,Justification)
    VALUES(@OperationCode,@TargetPrincipal,@SourcePrincipal,@AuthenticationType,@PermissionAction,@PermissionName,@ScopeType,@Securable,@RoleName,@Justification);
    DECLARE @Id bigint=SCOPE_IDENTITY();
    INSERT dbo.AccessRequestTarget SELECT @Id,ServerId,DatabaseName FROM @Targets;
    COMMIT;
    DECLARE @AuditDetail nvarchar(max)=CONCAT(N'Solicitud #',@Id,N' ',@OperationCode,N' · servidor único');
    EXEC dbo.usp_Audit_Write N'Solicitudes',N'Crear',NULL,NULL,1,@AuditDetail;
    SELECT @Id RequestId,'PENDING' [Status];
END;
GO

GRANT EXECUTE ON dbo.usp_AccessRequest_List TO [SqlAccessAdmin_Users];
GRANT EXECUTE ON dbo.usp_AccessRequest_Create TO [SqlAccessAdmin_Users];
GO

SELECT r.RequestId,COUNT(DISTINCT t.ServerId) AS ServerCount
FROM dbo.AccessRequest r
JOIN dbo.AccessRequestTarget t ON t.RequestId=r.RequestId
GROUP BY r.RequestId
HAVING COUNT(DISTINCT t.ServerId)>1;
GO
