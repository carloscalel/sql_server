USE [adminDB];
GO
SET NOCOUNT ON;
GO

DECLARE @Expected table(ObjectType varchar(10),ObjectName sysname);
INSERT @Expected VALUES
 ('TABLE','AppRole'),('TABLE','AuthorizedPrincipal'),('TABLE','ManagedServer'),('TABLE','AuditEvent'),('TABLE','CryptoConfiguration'),
 ('TABLE','SecurityPolicyOperation'),('TABLE','SecurityPolicyPermission'),('TABLE','SecurityPolicyRole'),('TABLE','SecurityDenyList'),('TABLE','AccessRequest'),('TABLE','AccessRequestTarget'),
 ('PROC','usp_App_LoginContext'),('PROC','usp_Server_List'),
 ('PROC','usp_AuthorizedUser_List'),('PROC','usp_Audit_List'),('PROC','usp_Server_GetConnection'),
 ('PROC','usp_Audit_Write'),('PROC','usp_AuthorizedUser_Upsert'),('PROC','usp_Server_Upsert'),
 ('PROC','usp_Server_SetActive'),('PROC','usp_Crypto_GetKey'),('PROC','usp_AccessRequest_Preview'),('PROC','usp_AccessRequest_Create'),
 ('PROC','usp_AccessRequest_List'),('PROC','usp_AccessRequest_Approve'),('PROC','usp_AccessRequest_MarkExecuted'),('PROC','usp_Audit_ValidateIntegrity');

SELECT e.ObjectType,e.ObjectName,
 CASE e.ObjectType WHEN 'TYPE' THEN IIF(TYPE_ID(N'dbo.'+e.ObjectName) IS NULL,'FALTA','OK')
                   ELSE IIF(OBJECT_ID(N'dbo.'+e.ObjectName) IS NULL,'FALTA','OK') END AS [Status]
FROM @Expected e ORDER BY e.ObjectType,e.ObjectName;

SELECT RoleName,Description FROM dbo.AppRole ORDER BY RoleName;
SELECT name AS DatabaseRole,
       IIF(name IN (N'SqlAccessAdmin_Administrator',N'SqlAccessAdmin_Operator',N'SqlAccessAdmin_Auditor',N'SqlAccessAdmin_Users'),N'OK',N'REVISAR') AS [Status]
FROM sys.database_principals
WHERE type='R' AND name LIKE N'SqlAccessAdmin[_]%'
ORDER BY name;
SELECT UserId,Principal,RoleName,Active FROM dbo.AuthorizedPrincipal ORDER BY Principal;
SELECT ServerId,Name,Host,Instance,Active,Encrypt,TrustServerCertificate,TimeoutSeconds FROM dbo.ManagedServer ORDER BY Name;
SELECT RoleName,RoleKind,Enabled,Notes FROM dbo.SecurityPolicyRole ORDER BY RoleKind,RoleName;

IF OBJECT_ID(N'dbo.usp_Policy_RoleUpsert',N'P') IS NOT NULL
    THROW 51111, 'La ruta de modificación de roles sigue instalada. Ejecute 11_BloquearModificacionRoles.sql.', 1;

IF NOT EXISTS(SELECT 1 FROM dbo.SecurityPolicyOperation WHERE OperationCode='CREATE_WINDOWS_LOGIN' AND Enabled=1)
   OR NOT EXISTS(SELECT 1 FROM dbo.SecurityPolicyOperation WHERE OperationCode='MODIFY_LOGIN' AND Enabled=1)
    THROW 51112, 'Falta la política simplificada. Ejecute 12_SimplificarGestionAccesos.sql.', 1;

IF EXISTS
(
    SELECT 1
    FROM dbo.SecurityPolicyPermission
    WHERE Enabled=1
      AND (PermissionName NOT IN('SELECT','INSERT','UPDATE','DELETE','EXECUTE')
           OR ScopeType NOT IN('DATABASE','OBJECT')
           OR AllowDeny=1)
)
    THROW 51113, 'Existen permisos activos fuera del modelo simplificado.', 1;

IF NOT EXISTS
(
    SELECT 1 FROM sys.parameters
    WHERE object_id=OBJECT_ID(N'dbo.usp_AccessRequest_List',N'P')
      AND name=N'@ServerId'
)
    THROW 51114, 'Falta el control de servidor único. Ejecute 13_RestringirServidorUnico.sql.', 1;

IF NOT EXISTS
(
    SELECT 1
    FROM dbo.SecurityPolicyOperation
    WHERE OperationCode='MODIFY_LOGIN'
      AND Enabled=1
      AND DisplayName=N'Modificar acceso del login'
)
    THROW 51115, 'Falta el rediseño de mapeo de login. Ejecute 14_RedisenarMapeoLogin.sql.', 1;

IF OBJECT_DEFINITION(OBJECT_ID(N'dbo.usp_AccessRequest_Create',N'P')) NOT LIKE N'%SqlAccessAdmin.AccessRequestCreate%'
   OR OBJECT_DEFINITION(OBJECT_ID(N'dbo.usp_AccessRequest_Approve',N'P')) NOT LIKE N'%SqlAccessAdmin.AccessRequestApprove%'
    THROW 51116, 'Falta el control de solicitudes duplicadas. Ejecute 15_PrevenirSolicitudesDuplicadas.sql.', 1;

IF OBJECT_DEFINITION(OBJECT_ID(N'dbo.usp_AccessRequest_Approve',N'P')) NOT LIKE N'%SqlAccessAdmin.SelfConfirmation%'
   OR OBJECT_DEFINITION(OBJECT_ID(N'dbo.usp_AccessRequest_MarkExecuted',N'P')) NOT LIKE N'%SqlAccessAdmin.SelfConfirmationExecution%'
    THROW 51117, 'Falta la autoconfirmación. Ejecute 16_HabilitarAutoconfirmacion.sql.', 1;

IF EXISTS
(
 SELECT 1 FROM @Expected e WHERE
   (e.ObjectType='TYPE' AND TYPE_ID(N'dbo.'+e.ObjectName) IS NULL)
   OR (e.ObjectType<>'TYPE' AND OBJECT_ID(N'dbo.'+e.ObjectName) IS NULL)
)
    THROW 51110, 'La instalación está incompleta. Revise los objetos marcados como FALTA.', 1;

PRINT N'Validación de objetos completada correctamente.';
GO
