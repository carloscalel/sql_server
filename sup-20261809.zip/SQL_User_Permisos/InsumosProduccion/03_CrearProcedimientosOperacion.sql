USE [adminDB];
GO
SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
GO

CREATE OR ALTER PROCEDURE dbo.usp_Audit_Write
    @Form nvarchar(100), @Action nvarchar(100), @ServerName sysname = NULL,
    @DatabaseName sysname = NULL, @Success bit, @Detail nvarchar(2000) = NULL,
    @CorrelationId uniqueidentifier = NULL
AS
BEGIN
    SET NOCOUNT ON;
    INSERT dbo.AuditEvent(Principal,Form,Action,ServerName,DatabaseName,Success,Detail,CorrelationId)
    VALUES(ORIGINAL_LOGIN(),@Form,@Action,@ServerName,@DatabaseName,@Success,@Detail,COALESCE(@CorrelationId,NEWID()));
END;
GO

CREATE OR ALTER PROCEDURE dbo.usp_AuthorizedUser_Upsert
    @UserId int = NULL, @Principal nvarchar(256), @PrincipalType varchar(20),
    @Role varchar(20), @Active bit, @Notes nvarchar(500) = NULL
AS
BEGIN
    SET NOCOUNT ON; SET XACT_ABORT ON;
    IF IS_SRVROLEMEMBER(N'sysadmin')<>1 AND NOT EXISTS(SELECT 1 FROM dbo.AuthorizedPrincipal WHERE Principal=ORIGINAL_LOGIN() AND Active=1 AND RoleName='Administrator')
        THROW 51001, 'Se requiere el rol Administrator.', 1;
    IF NOT EXISTS(SELECT 1 FROM dbo.AppRole WHERE RoleName=@Role)
        THROW 51002, 'Rol de aplicación no permitido.', 1;
    BEGIN TRAN;
    IF @UserId IS NULL
        INSERT dbo.AuthorizedPrincipal(Principal,PrincipalType,RoleName,Active,Notes) VALUES(@Principal,@PrincipalType,@Role,@Active,@Notes);
    ELSE
        UPDATE dbo.AuthorizedPrincipal SET Principal=@Principal,PrincipalType=@PrincipalType,RoleName=@Role,Active=@Active,Notes=@Notes WHERE UserId=@UserId;
    EXEC dbo.usp_Audit_Write N'Usuarios autorizados',N'Guardar',NULL,NULL,1,N'Principal actualizado';
    COMMIT;
END;
GO

CREATE OR ALTER PROCEDURE dbo.usp_Server_Upsert
    @ServerId int = NULL, @Name sysname, @Host nvarchar(255), @Instance sysname = NULL,
    @WindowsAuth bit = 1, @SqlUser nvarchar(256) = NULL,
    @CredentialCiphertext varbinary(max) = NULL, @CredentialNonce varbinary(12) = NULL,
    @CredentialTag varbinary(16) = NULL, @CredentialKeyId nvarchar(200) = NULL,
    @Encrypt bit = 1, @TrustServerCertificate bit = 0, @TimeoutSeconds int = 30, @Active bit = 1
AS
BEGIN
    SET NOCOUNT ON; SET XACT_ABORT ON;
    IF IS_SRVROLEMEMBER(N'sysadmin')<>1 AND NOT EXISTS(SELECT 1 FROM dbo.AuthorizedPrincipal WHERE Principal=ORIGINAL_LOGIN() AND Active=1 AND RoleName='Administrator')
        THROW 51001, 'Se requiere el rol Administrator.', 1;
    IF @Encrypt=0 THROW 51004, 'Las conexiones sin cifrado no están permitidas.', 1;
    IF @TimeoutSeconds NOT BETWEEN 5 AND 300 THROW 51005, 'Timeout fuera del rango permitido (5-300).', 1;
    IF @WindowsAuth=0 AND @ServerId IS NULL AND @CredentialCiphertext IS NULL THROW 51006, 'La contraseña SQL es obligatoria.', 1;
    BEGIN TRAN;
    IF @ServerId IS NULL
        INSERT dbo.ManagedServer(Name,Host,Instance,WindowsAuth,SqlUser,CredentialCiphertext,CredentialNonce,CredentialTag,CredentialKeyId,Encrypt,TrustServerCertificate,TimeoutSeconds,Active)
        VALUES(@Name,@Host,@Instance,@WindowsAuth,@SqlUser,@CredentialCiphertext,@CredentialNonce,@CredentialTag,@CredentialKeyId,@Encrypt,@TrustServerCertificate,@TimeoutSeconds,@Active);
    ELSE
        UPDATE dbo.ManagedServer SET Name=@Name,Host=@Host,Instance=@Instance,WindowsAuth=@WindowsAuth,SqlUser=CASE WHEN @WindowsAuth=1 THEN NULL ELSE @SqlUser END,
          CredentialCiphertext=CASE WHEN @WindowsAuth=1 THEN NULL ELSE COALESCE(@CredentialCiphertext,CredentialCiphertext) END,
          CredentialNonce=CASE WHEN @WindowsAuth=1 THEN NULL ELSE COALESCE(@CredentialNonce,CredentialNonce) END,
          CredentialTag=CASE WHEN @WindowsAuth=1 THEN NULL ELSE COALESCE(@CredentialTag,CredentialTag) END,
          CredentialKeyId=CASE WHEN @WindowsAuth=1 THEN NULL ELSE COALESCE(@CredentialKeyId,CredentialKeyId) END,
          Encrypt=@Encrypt,TrustServerCertificate=@TrustServerCertificate,TimeoutSeconds=@TimeoutSeconds,Active=@Active WHERE ServerId=@ServerId;
    EXEC dbo.usp_Audit_Write N'Servidores',N'Guardar',@Name,NULL,1,N'Servidor actualizado';
    COMMIT;
END;
GO

CREATE OR ALTER PROCEDURE dbo.usp_Server_SetActive @ServerId int,@Active bit
AS
BEGIN
    SET NOCOUNT ON;
    IF IS_SRVROLEMEMBER(N'sysadmin')<>1 AND NOT EXISTS(SELECT 1 FROM dbo.AuthorizedPrincipal WHERE Principal=ORIGINAL_LOGIN() AND Active=1 AND RoleName='Administrator')
        THROW 51001,'Se requiere el rol Administrator.',1;
    --UPDATE dbo.ManagedServer SET Active=@Active WHERE ServerId=@ServerId;
    --EXEC dbo.usp_Audit_Write N'Servidores', N'Cambiar estado', NULL, NULL, 1, IIF(@Active = 1, N'Servidor habilitado', N'Servidor deshabilitado');
    -- Evaluar la expresión en una variable primero
    DECLARE @Message NVARCHAR(MAX) = IIF(@Active = 1, N'Servidor habilitado', N'Servidor deshabilitado');

    -- Pasar la variable al procedimiento almacenado
    EXEC dbo.usp_Audit_Write N'Servidores', N'Cambiar estado', NULL, NULL, 1, @Message;
END;
GO
