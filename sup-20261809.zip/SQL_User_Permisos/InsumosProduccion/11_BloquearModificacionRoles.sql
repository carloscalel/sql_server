USE [adminDB];
GO
SET NOCOUNT ON;
SET XACT_ABORT ON;
GO

/*
  Migración para instalaciones existentes.
  La aplicación conserva dbo.SecurityPolicyRole y dbo.usp_Policy_RoleList
  únicamente como catálogo de roles asignables. Se elimina toda ruta de escritura.
*/

DROP PROCEDURE IF EXISTS dbo.usp_Policy_RoleUpsert;
GO

IF OBJECT_ID(N'dbo.usp_Audit_Write',N'P') IS NOT NULL
    EXEC dbo.usp_Audit_Write
        N'Política central',
        N'Bloquear modificación de roles',
        NULL,
        NULL,
        1,
        N'Eliminado dbo.usp_Policy_RoleUpsert; los roles quedan disponibles solo para membresías.';
GO

SELECT
    RoleName,
    RoleKind,
    Enabled,
    Notes
FROM dbo.SecurityPolicyRole
ORDER BY RoleKind,RoleName;
GO
