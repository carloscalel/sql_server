/* OPCIONAL. Ejecutar únicamente si adminDB no existe. */
USE [master];
GO
SET NOCOUNT ON;
GO

IF DB_ID(N'adminDB') IS NULL
BEGIN
    PRINT N'Creando base de datos [adminDB]...';
    CREATE DATABASE [adminDB];
END
ELSE
    PRINT N'La base [adminDB] ya existe; no se realizaron cambios.';
GO

ALTER DATABASE [adminDB] SET RECOVERY FULL;
ALTER DATABASE [adminDB] SET READ_COMMITTED_SNAPSHOT ON WITH ROLLBACK IMMEDIATE;
GO
