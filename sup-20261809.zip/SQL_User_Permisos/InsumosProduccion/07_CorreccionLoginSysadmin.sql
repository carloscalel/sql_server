/*
  Corrección puntual para instalaciones existentes.
  También está incorporada en 02_CrearProcedimientosConsulta.sql.
*/
USE [adminDB];
GO
SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
GO

CREATE OR ALTER PROCEDURE dbo.usp_App_LoginContext
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @Principal nvarchar(256)=ORIGINAL_LOGIN();

    IF EXISTS(SELECT 1 FROM dbo.AuthorizedPrincipal WHERE Active=1 AND Principal=@Principal)
    BEGIN
        SELECT TOP (1) Principal,RoleName AS [Role],CAST(1 AS bit) AS IsAuthorized,
               N'Principal autorizado mediante la lista blanca.' AS Detail
        FROM dbo.AuthorizedPrincipal WHERE Active=1 AND Principal=@Principal;
        RETURN;
    END;

    IF IS_SRVROLEMEMBER(N'sysadmin')=1
    BEGIN
        SELECT @Principal AS Principal,CAST('Administrator' AS varchar(20)) AS [Role],
               CAST(1 AS bit) AS IsAuthorized,N'Principal autorizado por pertenecer a sysadmin.' AS Detail;
        RETURN;
    END;

    SELECT @Principal AS Principal,CAST(NULL AS varchar(20)) AS [Role],CAST(0 AS bit) AS IsAuthorized,
           N'El principal detectado por SQL Server ['+@Principal+N'] no está activo en dbo.AuthorizedPrincipal.' AS Detail;
END;
GO

/* Diagnóstico visible para el DBA que ejecuta el parche. */
SELECT ORIGINAL_LOGIN() AS OriginalLogin,SUSER_SNAME() AS ExecutionLogin,
       IS_SRVROLEMEMBER(N'sysadmin') AS IsSysadmin;
EXEC dbo.usp_App_LoginContext;
GO
