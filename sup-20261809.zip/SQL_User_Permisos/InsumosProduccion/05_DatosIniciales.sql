USE [adminDB];
GO
SET NOCOUNT ON;
SET XACT_ABORT ON;
GO

/* El DBA debe sustituir ambos valores antes de ejecutar. */
DECLARE @InitialPrincipal nvarchar(256)=N'DOMINIO\usuario.dba';
DECLARE @PrincipalType varchar(20)='WINDOWS';

IF @InitialPrincipal=N'DOMINIO\usuario.dba'
    THROW 51100, 'Personalice @InitialPrincipal antes de ejecutar este script.', 1;

IF NOT EXISTS(SELECT 1 FROM dbo.AuthorizedPrincipal WHERE Principal=@InitialPrincipal)
    INSERT dbo.AuthorizedPrincipal(Principal,PrincipalType,RoleName,Active,Notes)
    VALUES(@InitialPrincipal,@PrincipalType,'Administrator',1,N'Administrador inicial registrado por el DBA');

PRINT N'Administrador inicial registrado. Agregue su usuario de base a SqlAccessAdmin_Users según la política local.';
GO

/*
Ejemplo para un login Windows que ya existe en la instancia:

CREATE USER [DOMINIO\usuario.dba] FOR LOGIN [DOMINIO\usuario.dba];
ALTER ROLE [SqlAccessAdmin_Users] ADD MEMBER [DOMINIO\usuario.dba];
ALTER ROLE [SqlAccessAdmin_Administrator] ADD MEMBER [DOMINIO\usuario.dba];

Ejemplo de servidor con conexión directa:

INSERT dbo.ManagedServer(Name,Host,Instance,WindowsAuth,Encrypt,TrustServerCertificate,TimeoutSeconds)
VALUES(N'SQL-PROD-01',N'sql-prod-01.dominio.local',NULL,1,1,0,30);
*/
