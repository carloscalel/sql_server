/* Migra únicamente los nombres heredados; conserva todos los miembros de cada rol. */
USE [adminDB];
GO
SET NOCOUNT ON;
SET XACT_ABORT ON;
GO

IF DATABASE_PRINCIPAL_ID(N'OfuscadorTool_Administrator') IS NOT NULL
   AND DATABASE_PRINCIPAL_ID(N'SqlAccessAdmin_Administrator') IS NULL
    ALTER ROLE [OfuscadorTool_Administrator] WITH NAME=[SqlAccessAdmin_Administrator];

IF DATABASE_PRINCIPAL_ID(N'OfuscadorTool_Operator') IS NOT NULL
   AND DATABASE_PRINCIPAL_ID(N'SqlAccessAdmin_Operator') IS NULL
    ALTER ROLE [OfuscadorTool_Operator] WITH NAME=[SqlAccessAdmin_Operator];

IF DATABASE_PRINCIPAL_ID(N'OfuscadorTool_Auditor') IS NOT NULL
   AND DATABASE_PRINCIPAL_ID(N'SqlAccessAdmin_Auditor') IS NULL
    ALTER ROLE [OfuscadorTool_Auditor] WITH NAME=[SqlAccessAdmin_Auditor];

IF DATABASE_PRINCIPAL_ID(N'OfuscadorTool_AppRole') IS NOT NULL
   AND DATABASE_PRINCIPAL_ID(N'SqlAccessAdmin_Users') IS NULL
    ALTER ROLE [OfuscadorTool_AppRole] WITH NAME=[SqlAccessAdmin_Users];
GO

IF DATABASE_PRINCIPAL_ID(N'SqlAccessAdmin_Administrator') IS NULL CREATE ROLE [SqlAccessAdmin_Administrator] AUTHORIZATION [dbo];
IF DATABASE_PRINCIPAL_ID(N'SqlAccessAdmin_Operator') IS NULL CREATE ROLE [SqlAccessAdmin_Operator] AUTHORIZATION [dbo];
IF DATABASE_PRINCIPAL_ID(N'SqlAccessAdmin_Auditor') IS NULL CREATE ROLE [SqlAccessAdmin_Auditor] AUTHORIZATION [dbo];
IF DATABASE_PRINCIPAL_ID(N'SqlAccessAdmin_Users') IS NULL CREATE ROLE [SqlAccessAdmin_Users] AUTHORIZATION [dbo];
GO

SELECT p.name AS RoleName,m.name AS MemberName
FROM sys.database_role_members drm
JOIN sys.database_principals p ON p.principal_id=drm.role_principal_id
JOIN sys.database_principals m ON m.principal_id=drm.member_principal_id
WHERE p.name LIKE N'SqlAccessAdmin[_]%'
ORDER BY p.name,m.name;
GO
