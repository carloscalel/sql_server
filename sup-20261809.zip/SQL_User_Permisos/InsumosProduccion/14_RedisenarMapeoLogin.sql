USE [adminDB];
GO
SET NOCOUNT ON;
SET XACT_ABORT ON;
GO

/*
  Cambia el significado funcional de MODIFY_LOGIN:
    1. El operador selecciona un login existente.
    2. Selecciona exactamente una base de datos.
    3. Selecciona un rol aprobado por la política central.
    4. Tras la aprobación, la aplicación crea el usuario mapeado si no existe
       y lo agrega únicamente al rol permitido seleccionado.

  No habilita modificación de roles, roles de servidor ni roles bloqueados.
*/

MERGE dbo.SecurityPolicyOperation AS target
USING
(
    SELECT 'MODIFY_LOGIN' OperationCode,
           N'Modificar acceso del login' DisplayName,
           CAST(1 AS bit) Enabled,
           CAST(1 AS bit) RequiresApproval,
           'HIGH' RiskLevel,
           N'Mapea el login como usuario en una base y asigna un rol aprobado por la política central' Description
) AS source
ON target.OperationCode=source.OperationCode
WHEN MATCHED THEN UPDATE SET
    DisplayName=source.DisplayName,
    Enabled=source.Enabled,
    RequiresApproval=source.RequiresApproval,
    RiskLevel=source.RiskLevel,
    Description=source.Description
WHEN NOT MATCHED THEN INSERT(OperationCode,DisplayName,Enabled,RequiresApproval,RiskLevel,Description)
VALUES(source.OperationCode,source.DisplayName,source.Enabled,source.RequiresApproval,source.RiskLevel,source.Description);

DECLARE @Detail nvarchar(2000)=N'MODIFY_LOGIN actualizado: selección única de base, creación controlada del usuario mapeado y asignación de un rol allowlist.';
EXEC dbo.usp_Audit_Write N'Política central',N'Rediseñar mapeo de login',NULL,NULL,1,@Detail;
GO

SELECT OperationCode,DisplayName,Description,Enabled,RiskLevel,RequiresApproval
FROM dbo.SecurityPolicyOperation
WHERE OperationCode='MODIFY_LOGIN';
GO
