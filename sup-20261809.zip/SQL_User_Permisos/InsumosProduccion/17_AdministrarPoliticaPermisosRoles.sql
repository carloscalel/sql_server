USE [adminDB];
GO
SET NOCOUNT ON;
SET XACT_ABORT ON;
GO

/*
  Habilita la administración controlada del catálogo de roles asignables.
  No crea ni modifica roles en servidores administrados: únicamente determina
  si una membresía puede solicitarse desde la aplicación.
*/

MERGE dbo.SecurityPolicyRole AS target
USING (VALUES
    (N'db_datareader',N'Lectura de todas las tablas y vistas'),
    (N'db_datawriter',N'Escritura en todas las tablas'),
    (N'db_denydatareader',N'Denegación de lectura en toda la base'),
    (N'db_denydatawriter',N'Denegación de escritura en toda la base'),
    (N'db_backupoperator',N'Operación de respaldos'),
    (N'db_ddladmin',N'Administración DDL'),
    (N'db_accessadmin',N'Administración de acceso'),
    (N'db_securityadmin',N'Administración de seguridad'),
    (N'db_owner',N'Control total de la base')
) AS source(RoleName,Notes)
ON target.RoleName=source.RoleName
WHEN NOT MATCHED THEN
    INSERT(RoleName,RoleKind,Enabled,Notes)
    VALUES(source.RoleName,'FIXED',0,source.Notes);
GO

CREATE OR ALTER PROCEDURE dbo.usp_Policy_RoleUpsert
    @RoleName sysname,
    @RoleKind varchar(10),
    @Enabled bit,
    @Notes nvarchar(500)=NULL
AS
BEGIN
    SET NOCOUNT ON;

    IF IS_SRVROLEMEMBER(N'sysadmin')<>1
       AND NOT EXISTS
       (
           SELECT 1
           FROM dbo.AuthorizedPrincipal
           WHERE Principal=ORIGINAL_LOGIN()
             AND Active=1
             AND RoleName='Administrator'
       )
        THROW 51301,'Se requiere Administrator.',1;

    SET @RoleName=LTRIM(RTRIM(@RoleName));
    SET @RoleKind=UPPER(@RoleKind);

    IF NULLIF(@RoleName,N'') IS NULL
        THROW 51307,'El nombre del rol es obligatorio.',1;
    IF @RoleKind NOT IN('FIXED','CUSTOM')
        THROW 51303,'Tipo de rol no permitido.',1;
    IF LOWER(@RoleName)=N'public'
        THROW 51308,'La membresía public no puede administrarse.',1;
    IF @Enabled=1 AND EXISTS
    (
        SELECT 1
        FROM dbo.SecurityDenyList
        WHERE Active=1
          AND Category IN('DATABASE_ROLE','SERVER_ROLE')
          AND UPPER(DeniedValue)=UPPER(@RoleName)
    )
        THROW 51309,'El rol está protegido por la denylist y no puede habilitarse.',1;

    MERGE dbo.SecurityPolicyRole AS target
    USING(SELECT @RoleName RoleName) AS source
       ON UPPER(target.RoleName)=UPPER(source.RoleName)
    WHEN MATCHED THEN UPDATE SET
        RoleKind=@RoleKind,
        Enabled=@Enabled,
        ApprovedBy=ORIGINAL_LOGIN(),
        ApprovedAt=SYSUTCDATETIME(),
        Notes=@Notes
    WHEN NOT MATCHED THEN
        INSERT(RoleName,RoleKind,Enabled,ApprovedBy,ApprovedAt,Notes)
        VALUES(source.RoleName,@RoleKind,@Enabled,ORIGINAL_LOGIN(),SYSUTCDATETIME(),@Notes);

    DECLARE @Detail nvarchar(2000)=CONCAT(
        N'Rol=',@RoleName,
        N'; Tipo=',@RoleKind,
        N'; Estado=',IIF(@Enabled=1,N'Habilitado',N'Deshabilitado'));
    EXEC dbo.usp_Audit_Write
        N'Política de seguridad',
        N'Actualizar disponibilidad de rol',
        NULL,
        NULL,
        1,
        @Detail;
END;
GO

GRANT EXECUTE ON dbo.usp_Policy_RoleUpsert TO [SqlAccessAdmin_Administrator];
GO

