USE [adminDB];
GO
SET NOCOUNT ON;
SET XACT_ABORT ON;
GO

IF OBJECT_ID(N'dbo.AppRole', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.AppRole
    (
        RoleName varchar(20) NOT NULL CONSTRAINT PK_AppRole PRIMARY KEY,
        Description nvarchar(250) NOT NULL
    );
    INSERT dbo.AppRole(RoleName, Description) VALUES
      ('Administrator', N'Configuración y administración total'),
      ('Operator', N'Ejecución de operaciones autorizadas'),
      ('Auditor', N'Consulta de configuración y auditoría');
END;
GO

IF OBJECT_ID(N'dbo.AuthorizedPrincipal', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.AuthorizedPrincipal
    (
        UserId int IDENTITY(1,1) NOT NULL CONSTRAINT PK_AuthorizedPrincipal PRIMARY KEY,
        Principal nvarchar(256) NOT NULL,
        PrincipalType varchar(20) NOT NULL CONSTRAINT DF_AuthorizedPrincipal_Type DEFAULT ('WINDOWS'),
        RoleName varchar(20) NOT NULL,
        Active bit NOT NULL CONSTRAINT DF_AuthorizedPrincipal_Active DEFAULT (1),
        Notes nvarchar(500) NULL,
        CreatedAt datetime2(3) NOT NULL CONSTRAINT DF_AuthorizedPrincipal_CreatedAt DEFAULT (SYSUTCDATETIME()),
        CreatedBy nvarchar(256) NOT NULL CONSTRAINT DF_AuthorizedPrincipal_CreatedBy DEFAULT (ORIGINAL_LOGIN()),
        RowVersion rowversion NOT NULL,
        CONSTRAINT UQ_AuthorizedPrincipal_Principal UNIQUE (Principal),
        CONSTRAINT CK_AuthorizedPrincipal_Type CHECK (PrincipalType IN ('WINDOWS','SQL_LOGIN','BOOTSTRAP')),
        CONSTRAINT FK_AuthorizedPrincipal_Role FOREIGN KEY (RoleName) REFERENCES dbo.AppRole(RoleName)
    );
END;
GO

IF OBJECT_ID(N'dbo.ManagedServer', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.ManagedServer
    (
        ServerId int IDENTITY(1,1) NOT NULL CONSTRAINT PK_ManagedServer PRIMARY KEY,
        Name sysname NOT NULL,
        Host nvarchar(255) NOT NULL,
        Instance sysname NULL,
        WindowsAuth bit NOT NULL CONSTRAINT DF_ManagedServer_WindowsAuth DEFAULT (1),
        SqlUser nvarchar(256) NULL,
        CredentialCiphertext varbinary(max) NULL,
        CredentialNonce varbinary(12) NULL,
        CredentialTag varbinary(16) NULL,
        CredentialKeyId nvarchar(200) NULL,
        Encrypt bit NOT NULL CONSTRAINT DF_ManagedServer_Encrypt DEFAULT (1),
        TrustServerCertificate bit NOT NULL CONSTRAINT DF_ManagedServer_Trust DEFAULT (0),
        TimeoutSeconds int NOT NULL CONSTRAINT DF_ManagedServer_Timeout DEFAULT (30),
        Active bit NOT NULL CONSTRAINT DF_ManagedServer_Active DEFAULT (1),
        CreatedAt datetime2(3) NOT NULL CONSTRAINT DF_ManagedServer_CreatedAt DEFAULT (SYSUTCDATETIME()),
        CreatedBy nvarchar(256) NOT NULL CONSTRAINT DF_ManagedServer_CreatedBy DEFAULT (ORIGINAL_LOGIN()),
        RowVersion rowversion NOT NULL,
        CONSTRAINT UQ_ManagedServer_Name UNIQUE (Name),
        CONSTRAINT CK_ManagedServer_Timeout CHECK (TimeoutSeconds BETWEEN 5 AND 300),
        CONSTRAINT CK_ManagedServer_CredentialEnvelope CHECK
        (
            (CredentialCiphertext IS NULL AND CredentialNonce IS NULL AND CredentialTag IS NULL AND CredentialKeyId IS NULL)
            OR
            (CredentialCiphertext IS NOT NULL AND CredentialNonce IS NOT NULL AND CredentialTag IS NOT NULL AND CredentialKeyId IS NOT NULL)
        )
    );
END;
GO

IF OBJECT_ID(N'dbo.CryptoConfiguration',N'U') IS NULL
BEGIN
    CREATE TABLE dbo.CryptoConfiguration
    (
        KeyId uniqueidentifier NOT NULL CONSTRAINT PK_CryptoConfiguration PRIMARY KEY,
        KeyEnvelope varbinary(512) NOT NULL,
        Active bit NOT NULL CONSTRAINT DF_CryptoConfiguration_Active DEFAULT (1),
        CreatedAt datetime2(3) NOT NULL CONSTRAINT DF_CryptoConfiguration_CreatedAt DEFAULT (SYSUTCDATETIME())
    );
    CREATE UNIQUE INDEX UX_CryptoConfiguration_OneActive ON dbo.CryptoConfiguration(Active) WHERE Active=1;
END;
GO

IF OBJECT_ID(N'dbo.AuditEvent', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.AuditEvent
    (
        AuditId bigint IDENTITY(1,1) NOT NULL CONSTRAINT PK_AuditEvent PRIMARY KEY,
        EventDate datetime2(3) NOT NULL CONSTRAINT DF_AuditEvent_Date DEFAULT (SYSUTCDATETIME()),
        Principal nvarchar(256) NOT NULL,
        Form nvarchar(100) NOT NULL,
        Action nvarchar(100) NOT NULL,
        ServerName sysname NULL,
        DatabaseName sysname NULL,
        Success bit NOT NULL,
        Detail nvarchar(2000) NULL,
        CorrelationId uniqueidentifier NOT NULL CONSTRAINT DF_AuditEvent_Correlation DEFAULT (NEWID()),
        ClientHost nvarchar(128) NULL CONSTRAINT DF_AuditEvent_Host DEFAULT (HOST_NAME()),
        ApplicationName nvarchar(128) NULL CONSTRAINT DF_AuditEvent_App DEFAULT (APP_NAME())
    );
    CREATE INDEX IX_AuditEvent_EventDate ON dbo.AuditEvent(EventDate DESC);
    CREATE INDEX IX_AuditEvent_Principal ON dbo.AuditEvent(Principal, EventDate DESC);
END;
GO
