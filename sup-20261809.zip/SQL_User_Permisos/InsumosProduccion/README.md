# Insumos de preparación de `adminDB`

Estos archivos son insumos de infraestructura. **La aplicación no los ejecuta, no crea la base de datos y no realiza migraciones automáticas.** Deben ser revisados, ajustados y ejecutados manualmente por un DBA con una cuenta privilegiada.

## Orden de ejecución

1. `00_CrearBaseDatos.sql` — opcional; omitir si `adminDB` ya existe.
2. `01_CrearEsquema.sql` — tablas, restricciones, índices y tipo de tabla.
3. `02_CrearProcedimientosConsulta.sql` — login, catálogos y auditoría.
4. `03_CrearProcedimientosOperacion.sql` — operaciones auditadas y ejecución remota.
5. `04_CrearRolesYPermisos.sql` — roles de mínimo privilegio y permisos sobre SP.
6. `05_DatosIniciales.sql` — plantilla que el DBA debe personalizar antes de ejecutar.
7. `07_CorreccionLoginSysadmin.sql` — actualización puntual para instalaciones existentes.
8. `08_ConfigurarConexionDirectaYCifrado.sql` — migración y clave AES-GCM central; requiere una contraseña elegida por el DBA.
9. `09_RenombrarRolesSqlAccessAdmin.sql` — migra los nombres heredados de roles en instalaciones existentes.
10. `10_PoliticaSolicitudesEIntegridad.sql` — allowlist, denylist, solicitudes, aprobación y cadena hash de auditoría.
11. `11_BloquearModificacionRoles.sql` — elimina en instalaciones existentes la ruta para registrar o modificar roles desde la aplicación.
12. `12_SimplificarGestionAccesos.sql` — habilita cuentas Windows/modificación de login y reduce los permisos a lectura, escritura y ejecución de rutinas por base u objeto.
13. `13_RestringirServidorUnico.sql` — obliga a que cada solicitud nueva pertenezca a un solo servidor y habilita el filtro de solicitudes por servidor.
14. `14_RedisenarMapeoLogin.sql` — redefine “Modificar login” como mapeo controlado a una base y asignación de un rol aprobado.
15. `15_PrevenirSolicitudesDuplicadas.sql` — rechaza de forma transaccional solicitudes equivalentes que continúen pendientes o aprobadas e impide aprobar dos duplicados históricos.
16. `16_HabilitarAutoconfirmacion.sql` — convierte la aprobación en un doble check: Administrator y Operator pueden confirmar, rechazar y ejecutar sus propias gestiones.
17. `17_AdministrarPoliticaPermisosRoles.sql` — permite al Administrator habilitar o deshabilitar permisos y roles asignables sin modificar la definición de los roles SQL.
18. `99_ValidarInstalacion.sql` — comprobación final, solo lectura.

Todos los scripts usan `GO`, por lo que deben ejecutarse con SSMS, Azure Data Studio o `sqlcmd` en modo compatible. Los scripts `01` a `04` son repetibles. El archivo `05` contiene variables que intencionalmente provocan un error hasta ser personalizadas.

Para una instalación existente, ejecute en este orden: `09`, `08`, `02`, `03`, `04`, `10`, `11`, `12`, `13`, `14`, `15`, `16`, `17` y `99`. El script `09` conserva los miembros al renombrar roles; `08` configura el cifrado y retira la ruta heredada; `11` conserva inicialmente el catálogo de roles asignables como solo lectura; `12` activa el modelo simplificado por nivel; `13` impone el control de servidor único; `14` rediseña el mapeo de login; `15` evita solicitudes activas duplicadas; `16` habilita la autoconfirmación auditada y `17` habilita su administración posterior exclusivamente para administradores.

## Ejecución con `sqlcmd`

```powershell
sqlcmd -S SERVIDOR\INSTANCIA -E -b -i .\InsumosProduccion\00_CrearBaseDatos.sql
sqlcmd -S SERVIDOR\INSTANCIA -E -b -i .\InsumosProduccion\01_CrearEsquema.sql
sqlcmd -S SERVIDOR\INSTANCIA -E -b -i .\InsumosProduccion\02_CrearProcedimientosConsulta.sql
sqlcmd -S SERVIDOR\INSTANCIA -E -b -i .\InsumosProduccion\03_CrearProcedimientosOperacion.sql
sqlcmd -S SERVIDOR\INSTANCIA -E -b -i .\InsumosProduccion\04_CrearRolesYPermisos.sql
```

Los scripts `05` y `08` son plantillas y requieren personalización explícita. No deben incluirse sin revisión en una ejecución desatendida.

## Decisiones de seguridad

- Los servidores administrados se alcanzan mediante conexiones TLS directas desde el aplicativo; no se requieren linked servers.
- `Encrypt` es obligatorio por defecto; `TrustServerCertificate` debe permanecer desactivado cuando exista una PKI válida.
- Las columnas `CredentialCiphertext`, `CredentialNonce` y `CredentialTag` guardan el sobre AES-256-GCM. La clave de 256 bits se genera aleatoriamente en `adminDB` y queda envuelta por una clave AES-256 protegida mediante certificado y Database Master Key de SQL Server.
- La contraseña de un nuevo login SQL no se guarda: viaja como parámetro sobre la conexión TLS al pivote, se usa dentro del SP y luego desaparece.
- La cuenta configurada para cada destino debe tener únicamente los permisos necesarios para crear logins, usuarios y membresías autorizadas.
- Los roles de base de datos son inmutables para la aplicación: solo pueden consultarse y asignarse o retirarse como membresías de usuarios. No se crean, editan ni reciben permisos mediante la aplicación.
- Los permisos de datos administrables son `SELECT`, `INSERT`, `UPDATE` y `DELETE`. `EXECUTE` se limita a procedimientos y funciones porque SQL Server lo exige para ejecutar rutinas. Los permisos se conceden o retiran a nivel de base u objeto; el nivel instancia se reserva al ciclo de vida de logins.
- Antes de consultar o gestionar accesos se selecciona un único servidor de trabajo. Una solicitud no puede mezclar servidores y las solicitudes históricas multiserver quedan bloqueadas para ejecución.
- La confirmación es un segundo paso consciente del mismo operador, no una segregación de funciones. Administrator y Operator pueden confirmar o rechazar su propia solicitud antes de ejecutarla; todos los pasos quedan auditados.

Antes de producción, el DBA debe revisar políticas de contraseñas, certificados TLS, retención de auditoría, respaldos y permisos del principal técnico.
