/*
  Ejecutar como DBA en adminDB. Para instalaciones existentes elimina la dependencia
  funcional de linked servers y configura la clave maestra de los sobres AES-256-GCM.
*/
USE [adminDB];
GO
SET NOCOUNT ON;
SET XACT_ABORT ON;
GO

/* Retira los objetos de la ruta heredada basada en linked servers. */
IF OBJECT_ID(N'dbo.usp_Access_Execute',N'P') IS NOT NULL DROP PROCEDURE dbo.usp_Access_Execute;
IF OBJECT_ID(N'dbo.usp_Database_ListForServers',N'P') IS NOT NULL DROP PROCEDURE dbo.usp_Database_ListForServers;
IF TYPE_ID(N'dbo.AccessTargetType') IS NOT NULL DROP TYPE dbo.AccessTargetType;
GO

IF COL_LENGTH(N'dbo.ManagedServer',N'TimeoutSeconds') IS NULL
    ALTER TABLE dbo.ManagedServer ADD TimeoutSeconds int NOT NULL CONSTRAINT DF_ManagedServer_Timeout DEFAULT(30);
GO

IF COL_LENGTH(N'dbo.ManagedServer',N'LinkedServerName') IS NOT NULL
BEGIN
    DECLARE @DefaultConstraint sysname;
    SELECT @DefaultConstraint=dc.name FROM sys.default_constraints dc
    JOIN sys.columns c ON c.default_object_id=dc.object_id
    WHERE c.object_id=OBJECT_ID(N'dbo.ManagedServer') AND c.name=N'LinkedServerName';
    IF @DefaultConstraint IS NOT NULL 
    BEGIN
        DECLARE @SqlDefault NVARCHAR(MAX) = N'ALTER TABLE dbo.ManagedServer DROP CONSTRAINT ' + QUOTENAME(@DefaultConstraint);
        EXEC sp_executesql @SqlDefault;
    END

    DECLARE @UniqueConstraint sysname;
    SELECT TOP(1) @UniqueConstraint=kc.name FROM sys.key_constraints kc
    JOIN sys.index_columns ic ON ic.object_id=kc.parent_object_id AND ic.index_id=kc.unique_index_id
    JOIN sys.columns c ON c.object_id=ic.object_id AND c.column_id=ic.column_id
    WHERE kc.parent_object_id=OBJECT_ID(N'dbo.ManagedServer') AND c.name=N'LinkedServerName';
    IF @UniqueConstraint IS NOT NULL 
    BEGIN
        DECLARE @SqlDefault1 NVARCHAR(MAX) = N'ALTER TABLE dbo.ManagedServer DROP CONSTRAINT '+QUOTENAME(@UniqueConstraint);
        EXEC sp_executesql @SqlDefault1;
    END
    ALTER TABLE dbo.ManagedServer DROP COLUMN LinkedServerName;
END;
GO

IF OBJECT_ID(N'dbo.CryptoConfiguration',N'U') IS NULL
BEGIN
    CREATE TABLE dbo.CryptoConfiguration
    (
        KeyId uniqueidentifier NOT NULL CONSTRAINT PK_CryptoConfiguration PRIMARY KEY,
        KeyEnvelope varbinary(512) NOT NULL,
        Active bit NOT NULL CONSTRAINT DF_CryptoConfiguration_Active DEFAULT(1),
        CreatedAt datetime2(3) NOT NULL CONSTRAINT DF_CryptoConfiguration_CreatedAt DEFAULT(SYSUTCDATETIME())
    );
END;
GO

IF NOT EXISTS(SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID(N'dbo.CryptoConfiguration') AND name=N'UX_CryptoConfiguration_OneActive')
    CREATE UNIQUE INDEX UX_CryptoConfiguration_OneActive ON dbo.CryptoConfiguration(Active) WHERE Active=1;
GO

/* PERSONALIZAR: esta contraseña protege la Database Master Key; guárdela en la bóveda del DBA. */
DECLARE @DatabaseMasterKeyPassword nvarchar(256)=N'CarlosCalel21';
IF @DatabaseMasterKeyPassword=N'CAMBIAR-POR-CONTRASENA-ROBUSTA-Y-UNICA'
    THROW 51200,'Personalice @DatabaseMasterKeyPassword antes de ejecutar este script.',1;

IF NOT EXISTS(SELECT 1 FROM sys.symmetric_keys WHERE name=N'##MS_DatabaseMasterKey##')
BEGIN
    DECLARE @Sql NVARCHAR(MAX) = N'CREATE MASTER KEY ENCRYPTION BY PASSWORD=N''' + REPLACE(@DatabaseMasterKeyPassword, '''', '''''') + N''';';
    EXEC sp_executesql @Sql;
END
GO

IF NOT EXISTS(SELECT 1 FROM sys.certificates WHERE name=N'SqlAccessAdminCredentialCertificate')
    CREATE CERTIFICATE SqlAccessAdminCredentialCertificate
      WITH SUBJECT=N'Protección de la clave AES-GCM de SQL Access Admin',EXPIRY_DATE='2099-12-31T23:59:59';
GO

IF NOT EXISTS(SELECT 1 FROM sys.symmetric_keys WHERE name=N'SqlAccessAdminWrappingKey')
    CREATE SYMMETRIC KEY SqlAccessAdminWrappingKey WITH ALGORITHM=AES_256
      ENCRYPTION BY CERTIFICATE SqlAccessAdminCredentialCertificate;
GO

OPEN SYMMETRIC KEY SqlAccessAdminWrappingKey DECRYPTION BY CERTIFICATE SqlAccessAdminCredentialCertificate;
IF NOT EXISTS(SELECT 1 FROM dbo.CryptoConfiguration WHERE Active=1)
BEGIN
    DECLARE @AesGcmKey varbinary(32)=CRYPT_GEN_RANDOM(32);
    INSERT dbo.CryptoConfiguration(KeyId,KeyEnvelope,Active)
    VALUES(NEWID(),EncryptByKey(Key_GUID(N'SqlAccessAdminWrappingKey'),@AesGcmKey,1,HASHBYTES('SHA2_256',N'SqlAccessAdmin-AES-GCM')),1);
END;
CLOSE SYMMETRIC KEY SqlAccessAdminWrappingKey;
GO

CREATE OR ALTER PROCEDURE dbo.usp_Crypto_GetKey
WITH EXECUTE AS OWNER
AS
BEGIN
    SET NOCOUNT ON;
    OPEN SYMMETRIC KEY SqlAccessAdminWrappingKey DECRYPTION BY CERTIFICATE SqlAccessAdminCredentialCertificate;
    SELECT KeyId,CONVERT(varbinary(32),DecryptByKey(KeyEnvelope,1,HASHBYTES('SHA2_256',N'SqlAccessAdmin-AES-GCM'))) AS MasterKey
    FROM dbo.CryptoConfiguration WHERE Active=1;
    CLOSE SYMMETRIC KEY SqlAccessAdminWrappingKey;
END;
GO

GRANT EXECUTE ON dbo.usp_Crypto_GetKey TO [SqlAccessAdmin_Administrator];
GRANT EXECUTE ON dbo.usp_Crypto_GetKey TO [SqlAccessAdmin_Operator];
GO
