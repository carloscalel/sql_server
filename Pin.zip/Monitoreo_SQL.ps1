$ServidorSQL = "localhost"
$BaseDatos  = "adminDB"

$Conn = "Server=$ServidorSQL;Database=$BaseDatos;Integrated Security=True"

# Obtener servidores activos
$QueryServidores = @"
SELECT IdServidor, NombreServidor, PuertoSQL
FROM dbo.Config_Servidores_SQL
WHERE Activo = 1
"@

$Servidores = Invoke-Sqlcmd -ConnectionString $Conn -Query $QueryServidores

foreach ($srv in $Servidores) {

    $PingOK = Test-Connection $srv.NombreServidor -Count 1 -Quiet
    $PuertoOK = $false

    if ($PingOK) {
        $test = Test-NetConnection $srv.NombreServidor -Port $srv.PuertoSQL
        $PuertoOK = $test.TcpTestSucceeded
    }

    if (-not $PingOK) {
        $Estado  = 'Servidor caído'
        $Detalle = 'No responde a ping'
    }
    elseif (-not $PuertoOK) {
        $Estado  = 'SQL no disponible'
        $Detalle = 'Ping OK, puerto SQL cerrado'
    }
    else {
        $Estado  = 'OK'
        $Detalle = 'Servidor y SQL disponibles'
    }

    $Insert = @"
INSERT INTO dbo.Monitoreo_SQL_Server
(IdServidor, NombreServidor, PuertoSQL, PingOK, PuertoOK, EstadoGeneral, Detalle)
VALUES
($($srv.IdServidor), '$($srv.NombreServidor)', $($srv.PuertoSQL),
 $( [int]$PingOK ), $( [int]$PuertoOK ), '$Estado', '$Detalle')
"@

    Invoke-Sqlcmd -ConnectionString $Conn -Query $Insert
}
