CREATE TABLE dbo.Config_Servidores_SQL
(
    IdServidor     INT IDENTITY PRIMARY KEY,
    NombreServidor SYSNAME NOT NULL,
    PuertoSQL      INT NOT NULL DEFAULT 1433,
    Activo         BIT NOT NULL DEFAULT 1,
    Observaciones  VARCHAR(200)
);


CREATE TABLE dbo.Monitoreo_SQL_Server
(
    IdMonitoreo    INT IDENTITY PRIMARY KEY,
    IdServidor     INT,
    NombreServidor SYSNAME,
    PuertoSQL      INT,
    FechaChequeo   DATETIME2 DEFAULT SYSDATETIME(),
    PingOK         BIT,
    PuertoOK       BIT,
    EstadoGeneral  VARCHAR(30),
    Detalle        VARCHAR(300)
);


USE adminDB;
GO

INSERT INTO dbo.Config_Servidores_SQL
(NombreServidor, PuertoSQL, Observaciones)
VALUES
('localhost', 1433, 'SQL Server local');


--truncate table Monitoreo_SQL_Server

SELECT *
FROM dbo.Monitoreo_SQL_Server
ORDER BY FechaChequeo DESC;

 
 EXEC sp_help 'Monitoreo_SQL_Server';
