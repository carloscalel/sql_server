﻿using System.Data;
using Microsoft.Data.SqlClient;
using SqlAccessAdmin.Models;

namespace SqlAccessAdmin.Data;

public sealed partial class DirectSqlServerService : IReportsDataSource
{
    private async Task RequireReportsAsync(CancellationToken ct)
    {
        // Same boundary as existing direct connections; no new access to shared credentials for Auditor.
        if (!(await adminDb.LoginAsync(ct)).CanAccessRequests)
            throw new UnauthorizedAccessException("Los reportes directos requieren Administrador, Operador o AprobadorEjecutor.");
    }

    public async Task<IReadOnlyList<ServerItem>> GetReportServersAsync(CancellationToken ct)
    {
        await RequireReportsAsync(ct);
        return (await adminDb.GetServersAsync(ct)).Where(x => x.Active).ToList();
    }

    private async Task<DataSet> ReadReportAsync(int serverId, string database, string sql, CancellationToken ct, string? user = null, byte[]? sid = null)
    {
        await RequireReportsAsync(ct);
        var resolved = await ResolveAsync(serverId, database, ct);
        await using var connection = new SqlConnection(resolved.ConnectionString);
        await connection.OpenAsync(ct);
        await using var command = new SqlCommand(sql, connection) { CommandTimeout = resolved.Server.TimeoutSeconds };
        if (user is not null) command.Parameters.Add(new("@user", SqlDbType.NVarChar, 128) { Value = user });
        if (sid is not null) command.Parameters.Add(new("@sid", SqlDbType.VarBinary, 85) { Value = sid });
        await using var reader = await command.ExecuteReaderAsync(ct);
        var data = new DataSet();
        do
        {
            var table = new DataTable();
            for (var i = 0; i < reader.FieldCount; i++) table.Columns.Add(reader.GetName(i), reader.GetFieldType(i));
            while (await reader.ReadAsync(ct))
            {
                var values = new object[reader.FieldCount];
                reader.GetValues(values);
                table.Rows.Add(values);
            }
            data.Tables.Add(table);
        } while (await reader.NextResultAsync(ct));
        ct.ThrowIfCancellationRequested();
        // A revocation during a long target query must not publish its results.
        await RequireReportsAsync(ct);
        return data;
    }

    public async Task<IReadOnlyList<string>> GetReportDatabasesAsync(int serverId, CancellationToken ct) =>
        (await ReadReportAsync(serverId, "master", ReportsSql.Databases, ct)).Tables[0].Rows.Cast<DataRow>().Select(x => x.Field<string>("name")!).ToList();

    public async Task<IReadOnlyList<ReportUser>> GetReportUsersAsync(int serverId, CancellationToken ct) =>
        (await ReadReportAsync(serverId, "master", ReportsSql.Users, ct)).Tables[0].Rows.Cast<DataRow>()
            .Select(x => new ReportUser(x.Field<string>("name")!, x.Field<string>("type_desc")!)).ToList();

    public async Task<UserAccessReport> GetUserAccessReportAsync(int serverId, IReadOnlyList<string> databases, string login, CancellationToken ct)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(login);
        if (databases.Any(string.IsNullOrWhiteSpace)) throw new ArgumentException("Las bases seleccionadas no son válidas.");
        var data = await ReadReportAsync(serverId, "master", ReportsSql.ServerAccess, ct, login);
        var sid = (byte[])data.Tables[0].Rows[0]["LoginSid"];
        var roles = ReadRoles(data.Tables[1], "Instancia", "", login);
        var permissions = ReadPermissions(data.Tables[2], "Instancia", "", login);
        var sysadmin = roles.Any(x => x.Name.Equals("sysadmin", StringComparison.OrdinalIgnoreCase));
        var coverage = new List<ReportDatabaseCoverage>();
        foreach (var database in databases.Distinct(StringComparer.Ordinal))
        {
            ct.ThrowIfCancellationRequested();
            try
            {
                var databaseData = await ReadReportAsync(serverId, database, ReportsSql.UserAccess, ct, sid: sid);
                var user = databaseData.Tables[0].Rows[0].Field<string>("MappedUser")!;
                var owner = databaseData.Tables[0].Rows[0].Field<bool>("IsOwner");
                roles.AddRange(ReadRoles(databaseData.Tables[1], "Base", database, user));
                permissions.AddRange(ReadPermissions(databaseData.Tables[2], "Base", database, user));
                var detail = sysadmin ? "Control por sysadmin; no requiere usuario mapeado."
                    : owner ? "Propietario de la base."
                    : user.Length > 0 ? "Usuario mapeado; consulte sus roles y permisos directos."
                    : "Sin usuario mapeado; revise permisos de instancia o grupos Windows.";
                coverage.Add(new(database, user.Length == 0 ? "Sin usuario mapeado" : user, detail));
            }
            catch (OperationCanceledException) { throw; }
            catch (Exception ex) { throw new InvalidOperationException($"No se pudo revisar la base {database}: {ex.Message}", ex); }
        }
        await RequireReportsAsync(ct);
        return new(roles, permissions) { Databases = coverage };
    }

    public async Task<InstanceAccessReport> GetInstanceAccessReportAsync(int serverId, IReadOnlyList<string> databases, CancellationToken ct)
    {
        if (databases.Any(string.IsNullOrWhiteSpace)) throw new ArgumentException("Las bases seleccionadas no son válidas.");
        var data = await ReadReportAsync(serverId, "master", InstanceReportsSql.ServerAccess, ct);
        var logins = data.Tables[0].Rows.Cast<DataRow>().Select(x => new ReportInstanceLogin(
            x.Field<string>("name")!, x.Field<string>("type_desc")!, x.Field<bool>("is_disabled"), x.Field<bool>("IsSysadmin"))).ToList();
        var identities = data.Tables[0].Rows.Cast<DataRow>().ToDictionary(x => x.Field<string>("name")!, x => (byte[])x["sid"], StringComparer.Ordinal);
        var sysadmins = logins.Where(x => x.IsSysadmin).Select(x => x.Name).ToHashSet(StringComparer.Ordinal);
        List<ReportRoleMembership> roles = [];
        List<ReportPermission> permissions = [];
        List<ReportDatabaseCoverage> coverage = [];
        ReadContext(data, "Instancia", "");
        foreach (var database in databases.Distinct(StringComparer.Ordinal))
        {
            ct.ThrowIfCancellationRequested();
            try
            {
                var databaseData = await ReadReportAsync(serverId, database, InstanceReportsSql.DatabaseAccess, ct);
                var mappings = databaseData.Tables[0].Rows.Cast<DataRow>().ToList();
                if (mappings.Count != identities.Count || mappings.Any(x => !identities.TryGetValue(x.Field<string>("LoginName")!, out var sid)
                    || !sid.SequenceEqual((byte[])x["sid"])))
                    throw new InvalidOperationException("El catálogo de logins cambió durante la consulta. Vuelva a consultar el reporte.");
                foreach (var row in mappings)
                {
                    var login = row.Field<string>("LoginName")!;
                    var user = row.Field<string>("MappedUser")!;
                    var detail = sysadmins.Contains(login) ? "Control por sysadmin; no requiere usuario mapeado."
                        : row.Field<bool>("IsOwner") ? "Propietario de la base."
                        : user.Length > 0 ? "Usuario mapeado; consulte sus roles y permisos directos."
                        : "Sin usuario mapeado; revise permisos de instancia o grupos Windows.";
                    coverage.Add(new(database, user.Length == 0 ? "Sin usuario mapeado" : user, detail) { Login = login });
                }
                ReadContext(databaseData, "Base", database);
            }
            catch (OperationCanceledException) { throw; }
            catch (Exception ex) { throw new InvalidOperationException($"No se pudo revisar la base {database}: {ex.Message}", ex); }
        }
        await RequireReportsAsync(ct);
        return new(logins, roles, permissions) { Databases = coverage };

        void ReadContext(DataSet context, string level, string database)
        {
            foreach (DataRow row in context.Tables[1].Rows)
            {
                var login = row.Field<string>("LoginName")!;
                roles.Add(new(row.Field<string>("name")!, row.Field<bool>("is_fixed_role"), row.Field<bool>("IsDirect"))
                    { Level = level, Database = database, Login = login, Principal = level == "Instancia" ? login : row.Field<string>("MappedUser")! });
            }
            foreach (DataRow row in context.Tables[2].Rows)
            {
                var login = row.Field<string>("LoginName")!;
                permissions.Add(new(row.Field<string>("Scope")!, row.Field<string>("SchemaName")!, row.Field<string>("ObjectName")!,
                    ObjectTypeDisplay(row.Field<string>("ObjectType")!), row.Field<string>("ColumnName")!, row.Field<string>("permission_name")!, row.Field<string>("Action")!)
                    { Level = level, Database = database, Login = login, Principal = level == "Instancia" ? login : row.Field<string>("MappedUser")!, CoveredBySysadmin = sysadmins.Contains(login) });
            }
        }
    }

    private static List<ReportRoleMembership> ReadRoles(DataTable table, string level, string database, string principal) =>
        table.Rows.Cast<DataRow>().Select(x => new ReportRoleMembership(x.Field<string>("name")!, x.Field<bool>("is_fixed_role"), x.Field<bool>("IsDirect"))
            { Level = level, Database = database, Principal = principal }).ToList();
    private static List<ReportPermission> ReadPermissions(DataTable table, string level, string database, string principal) =>
        table.Rows.Cast<DataRow>().Select(x => new ReportPermission(x.Field<string>("Scope")!, x.Field<string>("SchemaName")!, x.Field<string>("ObjectName")!,
            ObjectTypeDisplay(x.Field<string>("ObjectType")!), x.Field<string>("ColumnName")!, x.Field<string>("permission_name")!, x.Field<string>("Action")!)
            { Level = level, Database = database, Principal = principal }).ToList();

    private static string ObjectTypeDisplay(string type) => type switch
    {
        "U" => "Tabla", "V" => "Vista", "P" or "PC" => "Procedimiento",
        "FN" or "IF" or "TF" or "FS" or "FT" => "Función", _ => type
    };

    public async Task<IReadOnlyList<ReportRole>> GetRoleCatalogReportAsync(int serverId, string database, CancellationToken ct)
    {
        var data = await ReadReportAsync(serverId, database, ReportsSql.Roles, ct);
        var permissions = data.Tables[1].Rows.Cast<DataRow>().GroupBy(x => x.Field<string>("RoleName")!, StringComparer.Ordinal)
            .ToDictionary(g => g.Key, g => (IReadOnlyList<ReportPermission>)g.Select(x => new ReportPermission(
                x.Field<string>("Scope")!, x.Field<string>("SchemaName")!, x.Field<string>("ObjectName")!,
                ObjectTypeDisplay(x.Field<string>("ObjectType")!), x.Field<string>("ColumnName")!,
                x.Field<string>("permission_name")!, x.Field<string>("Action")!) { Database = database, Principal = g.Key }).ToList(), StringComparer.Ordinal);
        var roles = data.Tables[0].Rows.Cast<DataRow>()
            .GroupBy(x => (Name: x.Field<string>("name")!, Fixed: x.Field<bool>("is_fixed_role")))
            .Select(g => new ReportRole(g.Key.Name, g.Key.Fixed, g.Where(x => !x.IsNull("MemberName"))
                .Select(x => new ReportRoleMember(x.Field<string>("MemberName")!, x.Field<string>("MemberType")!)).Distinct().ToList())
                { DirectPermissions = permissions.GetValueOrDefault(g.Key.Name) ?? [] }).ToList();
        var links = data.Tables[2].Rows.Cast<DataRow>().Select(x => new ReportRoleLink(x.Field<string>("MemberRole")!, x.Field<string>("ParentRole")!)).ToList();
        ct.ThrowIfCancellationRequested();
        return RoleCatalogDetails.Attach(roles, links);
    }

    public async Task<IReadOnlyList<CredentialAgeRow>> GetCredentialAgeReportAsync(int serverId, CancellationToken ct)
    {
        var data=(await ReadReportAsync(serverId,"master",ReportsSql.CredentialAge,ct)).Tables[0];
        var confirmed=await adminDb.GetConfirmedPasswordDatesAsync(serverId,ct);
        await RequireReportsAsync(ct);
        var now=SqlAccessAdmin.Infrastructure.AppTime.Now;
        return data.Rows.Cast<DataRow>().Select(x=>
        {
            var row=new CredentialAgeRow(x.Field<string>("name")!,x.Field<bool>("is_disabled"),x.Field<DateTime?>("LastSet"),
                x.Field<int?>("DaysElapsed"),x.Field<bool?>("is_policy_checked"),x.Field<bool?>("is_expiration_checked"),
                x.Field<string>("LoginType")!,x.Field<DateTime?>("LastModified"),x.Field<int?>("ModificationDays"));
            return confirmed.TryGetValue(Convert.ToHexString((byte[])x["sid"]),out var changedAt)
                ? row.WithConfirmedPasswordChange(changedAt,x.Field<DateTime>("CreatedAt"),now) : row;
        }).ToList();
    }
}
