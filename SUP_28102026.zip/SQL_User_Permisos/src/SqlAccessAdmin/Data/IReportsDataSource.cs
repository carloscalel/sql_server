using SqlAccessAdmin.Models;

namespace SqlAccessAdmin.Data;

public interface IReportsDataSource
{
    Task<IReadOnlyList<ServerItem>> GetReportServersAsync(CancellationToken ct);
    Task<IReadOnlyList<string>> GetReportDatabasesAsync(int serverId, CancellationToken ct);
    Task<IReadOnlyList<ReportUser>> GetReportUsersAsync(int serverId, CancellationToken ct);
    Task<UserAccessReport> GetUserAccessReportAsync(int serverId, IReadOnlyList<string> databases, string login, CancellationToken ct);
    Task<InstanceAccessReport> GetInstanceAccessReportAsync(int serverId, IReadOnlyList<string> databases, CancellationToken ct);
    Task<IReadOnlyList<ReportRole>> GetRoleCatalogReportAsync(int serverId, string database, CancellationToken ct);
    Task<IReadOnlyList<CredentialAgeRow>> GetCredentialAgeReportAsync(int serverId, CancellationToken ct);
}
