namespace SqlAccessAdmin.Data;

// One catalog read per context, independent of the number of logins. Temporary tables
// live only in the report connection; no security objects or permissions are modified.
internal static class InstanceReportsSql
{
    internal const string ServerVisibility = """
        IF COALESCE(HAS_PERMS_BY_NAME(NULL, NULL, 'VIEW ANY DEFINITION'),0)<>1
           AND COALESCE(HAS_PERMS_BY_NAME(NULL, NULL, 'VIEW ANY SECURITY DEFINITION'),0)<>1
            THROW 51004, N'El reporte de instancia requiere VIEW ANY DEFINITION o VIEW ANY SECURITY DEFINITION para consultar roles y permisos completos.', 1;
        """;

    internal const string EligibleLogins = """
        SET NOCOUNT ON;
        SELECT principal_id, name, sid, type_desc, is_disabled
        INTO #ReportLogins FROM sys.server_principals
        WHERE type IN ('S','U') AND name NOT LIKE N'#%'
          AND UPPER(name) NOT LIKE N'NT %';
        """;

    internal const string ServerAccess = ServerVisibility + EligibleLogins + """

        ;WITH memberships AS
        (
            SELECT l.principal_id AS login_id, rm.role_principal_id, 1 AS depth,
                CAST('/'+CAST(l.principal_id AS varchar(11))+'/'+CAST(rm.role_principal_id AS varchar(11))+'/' AS varchar(max)) AS path
            FROM #ReportLogins l JOIN sys.server_role_members rm ON rm.member_principal_id=l.principal_id
            UNION ALL
            SELECT m.login_id, rm.role_principal_id, m.depth+1,
                CAST(m.path+CAST(rm.role_principal_id AS varchar(11))+'/' AS varchar(max))
            FROM memberships m JOIN sys.server_role_members rm ON rm.member_principal_id=m.role_principal_id
            WHERE CHARINDEX('/'+CAST(rm.role_principal_id AS varchar(11))+'/',m.path)=0
        )
        SELECT login_id, role_principal_id, CAST(MAX(CASE WHEN depth=1 THEN 1 ELSE 0 END) AS bit) AS IsDirect
        INTO #ReportMemberships FROM memberships GROUP BY login_id, role_principal_id
        OPTION(MAXRECURSION 32767);

        INSERT #ReportMemberships(login_id,role_principal_id,IsDirect)
        SELECT l.principal_id, r.principal_id, CAST(0 AS bit)
        FROM #ReportLogins l CROSS JOIN sys.server_principals r
        WHERE r.type='R' AND r.name=N'sysadmin' AND IS_SRVROLEMEMBER(N'sysadmin',l.name)=1
          AND NOT EXISTS(SELECT 1 FROM #ReportMemberships m WHERE m.login_id=l.principal_id AND m.role_principal_id=r.principal_id);

        SELECT l.name,l.sid,l.type_desc,l.is_disabled,
            CAST(CASE WHEN EXISTS(SELECT 1 FROM #ReportMemberships m JOIN sys.server_principals r ON r.principal_id=m.role_principal_id
                 WHERE m.login_id=l.principal_id AND r.name=N'sysadmin') THEN 1 ELSE 0 END AS bit) AS IsSysadmin
        FROM #ReportLogins l ORDER BY l.name;

        SELECT l.name AS LoginName,r.name,r.is_fixed_role,m.IsDirect
        FROM #ReportMemberships m JOIN #ReportLogins l ON l.principal_id=m.login_id
        JOIN sys.server_principals r ON r.principal_id=m.role_principal_id
        WHERE r.name<>N'public' ORDER BY l.name,r.name;

        SELECT l.name AS LoginName,
            CASE p.class WHEN 100 THEN N'Instancia' WHEN 101 THEN N'Login/rol'
                WHEN 105 THEN N'Endpoint' WHEN 108 THEN N'Grupo de disponibilidad' ELSE p.class_desc END AS Scope,
            N'' AS SchemaName,
            CASE p.class WHEN 100 THEN N'(instancia)' WHEN 101 THEN COALESCE(target.name,N'(no visible)')
                WHEN 105 THEN COALESCE(ep.name,N'(no visible)') WHEN 108 THEN N'Id '+CONVERT(nvarchar(128),p.major_id)
                ELSE CONVERT(nvarchar(128),p.major_id) END AS ObjectName,
            N'' AS ObjectType,N'' AS ColumnName,p.permission_name,
            CASE p.state WHEN 'W' THEN N'GRANT WITH GRANT OPTION' WHEN 'D' THEN N'DENY' WHEN 'R' THEN N'REVOKE' ELSE N'GRANT' END AS Action
        FROM #ReportLogins l JOIN sys.server_permissions p ON p.grantee_principal_id=l.principal_id
        LEFT JOIN sys.server_principals target ON p.class=101 AND target.principal_id=p.major_id
        LEFT JOIN sys.endpoints ep ON p.class=105 AND ep.endpoint_id=p.major_id
        ORDER BY l.name,Scope,ObjectName,p.permission_name,Action;
        DROP TABLE #ReportMemberships,#ReportLogins;
        """;

    internal const string DatabaseAccess = ReportsSql.DatabaseVisibility + ServerVisibility + EligibleLogins + """

        SELECT l.name AS LoginName,l.sid,u.principal_id,u.name AS MappedUser,
            CAST(CASE WHEN EXISTS(SELECT 1 FROM sys.databases WHERE database_id=DB_ID() AND owner_sid=l.sid) THEN 1 ELSE 0 END AS bit) AS IsOwner
        INTO #ReportMappings FROM #ReportLogins l
        OUTER APPLY(SELECT TOP (1) dp.principal_id,dp.name FROM sys.database_principals dp
            WHERE dp.sid=l.sid AND dp.type IN ('S','U') AND dp.name NOT IN (N'dbo',N'guest',N'INFORMATION_SCHEMA',N'sys')
            ORDER BY dp.principal_id) u;
        SELECT LoginName,sid,COALESCE(MappedUser,N'') AS MappedUser,IsOwner FROM #ReportMappings ORDER BY LoginName;

        ;WITH memberships AS
        (
            SELECT u.LoginName,u.MappedUser,rm.role_principal_id,1 AS depth,
                CAST('/'+CAST(u.principal_id AS varchar(11))+'/'+CAST(rm.role_principal_id AS varchar(11))+'/' AS varchar(max)) AS path
            FROM #ReportMappings u JOIN sys.database_role_members rm ON rm.member_principal_id=u.principal_id
            UNION ALL
            SELECT m.LoginName,m.MappedUser,rm.role_principal_id,m.depth+1,
                CAST(m.path+CAST(rm.role_principal_id AS varchar(11))+'/' AS varchar(max))
            FROM memberships m JOIN sys.database_role_members rm ON rm.member_principal_id=m.role_principal_id
            WHERE CHARINDEX('/'+CAST(rm.role_principal_id AS varchar(11))+'/',m.path)=0
        )
        SELECT m.LoginName,m.MappedUser,r.name,r.is_fixed_role,
            CAST(MAX(CASE WHEN m.depth=1 THEN 1 ELSE 0 END) AS bit) AS IsDirect
        FROM memberships m JOIN sys.database_principals r ON r.principal_id=m.role_principal_id
        WHERE r.name<>N'public'
        GROUP BY m.LoginName,m.MappedUser,r.name,r.is_fixed_role
        ORDER BY m.LoginName,r.name OPTION(MAXRECURSION 32767);

        SELECT u.LoginName,u.MappedUser,
            CASE p.class WHEN 0 THEN N'Base' WHEN 3 THEN N'Esquema'
                ELSE CASE WHEN p.minor_id>0 THEN N'Columna' ELSE N'Objeto' END END AS Scope,
            COALESCE(s.name,os.name,N'') AS SchemaName,COALESCE(o.name,N'') AS ObjectName,
            COALESCE(RTRIM(o.type),N'') AS ObjectType,COALESCE(c.name,N'') AS ColumnName,p.permission_name,
            CASE p.state WHEN 'W' THEN N'GRANT WITH GRANT OPTION' WHEN 'R' THEN N'REVOKE (excepción de columna)'
                WHEN 'D' THEN N'DENY' ELSE N'GRANT' END AS Action
        FROM #ReportMappings u JOIN sys.database_permissions p ON p.grantee_principal_id=u.principal_id
        LEFT JOIN sys.objects o ON p.class=1 AND p.major_id=o.object_id
        LEFT JOIN sys.schemas os ON os.schema_id=o.schema_id
        LEFT JOIN sys.schemas s ON p.class=3 AND p.major_id=s.schema_id
        LEFT JOIN sys.columns c ON p.class=1 AND p.major_id=c.object_id AND p.minor_id=c.column_id
        WHERE p.class IN (0,3) OR (p.class=1 AND o.is_ms_shipped=0 AND o.type IN ('U','V','P','PC','FN','IF','TF','FS','FT'))
        ORDER BY u.LoginName,Scope,SchemaName,ObjectName,ColumnName,p.permission_name,Action;
        DROP TABLE #ReportMappings,#ReportLogins;
        """;
}
