using Microsoft.Win32;
using System.Windows;
using SqlAccessAdmin.Models;
using SqlAccessAdmin.Views;

namespace SqlAccessAdmin.Infrastructure;

public interface IReportSaveDialog
{
    ReportExportScope? ChooseScope(ReportExportFormat format, string activeSection);
    ReportExportScope? ChooseScope(ReportExportFormat format, string activeSection, IReadOnlyList<string> sections) => ChooseScope(format, activeSection);
    string? ChoosePath(ReportExportFormat format, string suggestedName);
}

public sealed class ReportSaveDialog : IReportSaveDialog
{
    private static Window? ActiveWindow => Application.Current?.Windows.OfType<Window>().FirstOrDefault(window => window.IsActive);
    public ReportExportScope? ChooseScope(ReportExportFormat format, string activeSection)
        => ChooseScope(format, activeSection, ["Roles asignados", "Permisos directos", "Bases revisadas"]);

    public ReportExportScope? ChooseScope(ReportExportFormat format, string activeSection, IReadOnlyList<string> sections)
    {
        var dialog = new ReportExportOptionsWindow(format, activeSection, sections);
        if (ActiveWindow is { } owner) dialog.Owner = owner;
        else dialog.WindowStartupLocation = WindowStartupLocation.CenterScreen;
        return dialog.ShowDialog() == true ? dialog.Scope : null;
    }

    public string? ChoosePath(ReportExportFormat format, string suggestedName)
    {
        var (extension, filter) = format switch
        {
            ReportExportFormat.Pdf => (".pdf", "Documento PDF (*.pdf)|*.pdf"),
            ReportExportFormat.Csv => (".csv", "CSV UTF-8 (*.csv)|*.csv"),
            _ => (".xlsx", "Libro de Excel (*.xlsx)|*.xlsx")
        };
        var dialog = new SaveFileDialog
        {
            Title = "Exportar resultados filtrados", FileName = suggestedName + extension,
            DefaultExt = extension, Filter = filter, AddExtension = true, OverwritePrompt = true,
            CheckPathExists = true
        };
        var accepted = ActiveWindow is { } owner ? dialog.ShowDialog(owner) : dialog.ShowDialog();
        return accepted == true ? dialog.FileName : null;
    }
}
