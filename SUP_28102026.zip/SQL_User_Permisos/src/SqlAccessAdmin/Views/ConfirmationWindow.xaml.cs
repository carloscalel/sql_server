using System.Windows;

namespace SqlAccessAdmin.Views;

public partial class ConfirmationWindow : Window
{
    public string Heading {get;}
    public string Message {get;}
    public string AcceptLabel {get;}
    public string ContextLabel {get;}
    public bool AcceptOnEnter {get;}
    public bool CancelOnEnter=>!AcceptOnEnter;

    public ConfirmationWindow(string heading,string message,string acceptLabel,string contextLabel="USUARIOS AUTORIZADOS",bool acceptOnEnter=true)
    {
        Heading=heading;Message=message;AcceptLabel=acceptLabel;ContextLabel=contextLabel;AcceptOnEnter=acceptOnEnter;
        InitializeComponent();DataContext=this;
    }

    public static bool Confirm(string heading,string message,string acceptLabel,string contextLabel="USUARIOS AUTORIZADOS",bool acceptOnEnter=true)
    {
        var window=new ConfirmationWindow(heading,message,acceptLabel,contextLabel,acceptOnEnter);
        var owner=Application.Current?.Windows.OfType<Window>().FirstOrDefault(x=>x.IsActive)
            ??Application.Current?.MainWindow;
        if(owner is {IsVisible:true})window.Owner=owner;
        else window.WindowStartupLocation=WindowStartupLocation.CenterScreen;
        return window.ShowDialog()==true;
    }

    protected override void OnContentRendered(EventArgs e)
    {
        base.OnContentRendered(e);
        if(!AcceptOnEnter)CancelConfirmationButton.Focus();
    }

    private void Accept_Click(object sender,RoutedEventArgs e)=>DialogResult=true;
    private void Cancel_Click(object sender,RoutedEventArgs e)=>DialogResult=false;
}
