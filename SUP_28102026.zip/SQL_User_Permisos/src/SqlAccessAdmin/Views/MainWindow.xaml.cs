using System.ComponentModel;
using System.Windows;
using System.Windows.Controls;
using Microsoft.Data.SqlClient;
using SqlAccessAdmin.ViewModels;

namespace SqlAccessAdmin.Views;

public partial class MainWindow : Window
{
    private bool _logoutRequested;

    public MainWindow() => InitializeComponent();
    private void Logout_Click(object sender, RoutedEventArgs e)
    {
        _logoutRequested = true;
        try { Close(); }
        finally { _logoutRequested = false; }
    }
    private void ReportsHeader_Click(object sender, RoutedEventArgs e)
    {
        if(ReportsNavigation.Items[0] is TreeViewItem reports)reports.IsExpanded=!reports.IsExpanded;
    }

    protected override void OnClosing(CancelEventArgs e)
    {
        if (DataContext is MainViewModel { Current: PolicyViewModel policy } && !policy.ConfirmLeave()) e.Cancel = true;
        if (DataContext is MainViewModel { Current: UsersViewModel users } && !users.ConfirmLeave()) e.Cancel = true;
        base.OnClosing(e);
    }

    protected override void OnClosed(EventArgs e)
    {
        if(DataContext is MainViewModel main)main.Dispose();
        DataContext = null;
        base.OnClosed(e);
        if (_logoutRequested)
        {
            SqlConnection.ClearAllPools();
            var login = new LoginWindow();
            Application.Current.MainWindow = login;
            login.Show();
        }
        else
        {
            Application.Current?.Shutdown();
        }
    }
}
