﻿using System.Collections.ObjectModel;
using System.ComponentModel;
using System.IO;
using System.Windows.Data;
using SqlAccessAdmin.Data;
using SqlAccessAdmin.Infrastructure;
using SqlAccessAdmin.Models;

namespace SqlAccessAdmin.ViewModels;

public sealed class ReportsViewModel : BindableBase, IDisposable
{
    private static readonly HashSet<string> InternalLoginNames = new(StringComparer.OrdinalIgnoreCase) { "dbo", "guest", "INFORMATION_SCHEMA", "sys" };
    private readonly IReportsDataSource _source;
    private readonly IReportExportService _exporter;
    private readonly IReportSaveDialog _saveDialog;
    private CancellationTokenSource? _exportOperation;
    private bool _isExporting;
    private bool _includeRoleMembersInExport;
    private DateTimeOffset _queriedAt;
    private CancellationTokenSource? _operation;
    private bool _disposed, _busy, _hasResult;
    private ServerItem? _server;
    private string? _database;
    private ReportUser? _user;
    private ReportRole? _role;
    private string _search = "", _action = "Todas", _roleKind = "Todos", _credentialState = "Todos";
    private string _status = "Seleccione los datos del reporte y pulse Consultar.";
    private IReadOnlyList<ReportRoleMembership> _allMemberships = [];
    private IReadOnlyList<ReportPermission> _allPermissions = [];
    private IReadOnlyList<ReportRole> _allRoles = [];
    private IReadOnlyList<CredentialAgeRow> _allCredentials = [];
    private IReadOnlyList<ReportDatabaseCoverage> _allCoverage = [];
    private IReadOnlyList<ReportInstanceLogin> _allInstanceLogins = [];
    private bool _changingDatabases;
    private string _databaseSearch = "";
    private string _loginSearch = "";
    public string LoginSearch
    {
        get => _loginSearch;
        set { if (Set(ref _loginSearch, value)) RefreshLoginFilter(); }
    }
    public ICollectionView FilteredUsers { get; }
    public string LoginSearchSummary => Users.Count == 0 ? "Sin logins disponibles."
        : FilteredUsers.IsEmpty ? "Sin coincidencias."
        : $"{FilteredUsers.Cast<ReportUser>().Count()} de {Users.Count} logins";
    private void RefreshLoginFilter()
    {
        FilteredUsers.Refresh();
        if (SelectedUser is not null && !FilteredUsers.Contains(SelectedUser)) SelectedUser = null;
        Raise(nameof(LoginSearchSummary));
    }
    private static bool IsSelectableLogin(ReportUser user) => (user.Type is "SQL_LOGIN" or "WINDOWS_LOGIN")
        && !user.Name.StartsWith("NT AUTHORITY\\", StringComparison.OrdinalIgnoreCase)
        && !user.Name.StartsWith("NT SERVICE\\", StringComparison.OrdinalIgnoreCase)
        && !user.Name.StartsWith("##", StringComparison.Ordinal)
        && !InternalLoginNames.Contains(user.Name);
    private int _activeSectionIndex;
    public int ActiveSectionIndex
    {
        get => _activeSectionIndex;
        set { if (value >= 0 && value <= (IsInstancePermissions ? 3 : 2) && Set(ref _activeSectionIndex, value)) { Raise(nameof(ActiveSectionName)); Raise(nameof(ShowEmpty)); } }
    }
    public string ActiveSectionName => ActiveSectionIndex switch { 1 => "Permisos directos", 2 => "Bases revisadas", 3 => "Logins de la instancia", _ => "Roles asignados" };

    public ReportKind Kind { get; }
    public bool IsUserPermissions => Kind == ReportKind.UserPermissions;
    public bool IsInstancePermissions => Kind == ReportKind.InstancePermissions;
    public bool IsPermissionsReport => IsUserPermissions || IsInstancePermissions;
    public bool IsRoleCatalog => Kind == ReportKind.RoleCatalog;
    public bool IsCredentialAge => Kind == ReportKind.CredentialAge;
    public bool NeedsDatabase => IsRoleCatalog;
    public string Heading => Kind switch
    {
        ReportKind.UserPermissions => "Permisos por usuario",
        ReportKind.InstancePermissions => "Permisos por instancia",
        ReportKind.RoleCatalog => "Catálogo de roles",
        _ => "Inactividad de credenciales"
    };
    public string Explanation => Kind switch
    {
        ReportKind.UserPermissions => "Consulte los roles y permisos asignados a una cuenta en el servidor y en las bases de datos que elija.",
        ReportKind.InstancePermissions => "Consulte las cuentas del servidor y revise sus roles y permisos.",
        ReportKind.RoleCatalog => "Seleccione un rol y despliegue sus permisos directos, permisos heredados y miembros.",
        _ => "Revise las cuentas del servidor, la antigüedad de sus contraseñas y la fecha de su última actualización."
    };
    public string ScopeNote => Kind switch
    {
        ReportKind.UserPermissions => "Seleccione una cuenta y marque las bases de datos que desea revisar. El reporte incluye los roles asignados y los permisos otorgados directamente a la cuenta. No detalla los permisos que recibe por pertenecer a un rol o grupo de Windows.",
        ReportKind.InstancePermissions => "Seleccione un servidor y pulse Consultar. Para revisar también los accesos en bases de datos, marque las bases que le interesen. Use Buscar para encontrar una cuenta o permiso.",
        ReportKind.RoleCatalog => RoleCatalogDetails.ScopeNote,
        _ => "Una contraseña antigua no significa que la cuenta haya dejado de usarse. Si no se puede confirmar su fecha de cambio, verá «No disponible». Las contraseñas de cuentas Windows se administran fuera de esta aplicación. La última actualización de una cuenta puede corresponder a otros cambios. Las fechas se muestran en hora de Guatemala."
    };
    public ObservableCollection<ServerItem> Servers { get; } = [];
    public ObservableCollection<string> Databases { get; } = [];
    public ObservableCollection<ReportDatabaseChoice> DatabaseChoices { get; } = [];
    public ObservableCollection<ReportDatabaseCoverage> DatabaseCoverage { get; } = [];
    public ObservableCollection<ReportInstanceLogin> InstanceLogins { get; } = [];
    public IEnumerable<ReportDatabaseChoice> FilteredDatabaseChoices => DatabaseChoices.Where(x => string.IsNullOrWhiteSpace(DatabaseSearch) || x.Name.Contains(DatabaseSearch.Trim(), StringComparison.OrdinalIgnoreCase));
    public string DatabaseSearch { get => _databaseSearch; set { if (Set(ref _databaseSearch, value)) Raise(nameof(FilteredDatabaseChoices)); } }
    public string DatabaseSelectionSummary => SelectedDatabaseNames.Count == 0 ? "Solo instancia" : $"{SelectedDatabaseNames.Count} base(s) seleccionada(s)";
    public string SelectedDatabaseSummary => SelectedDatabaseNames.Count == 0 ? "Solo instancia" : string.Join(", ", SelectedDatabaseNames);
    private IReadOnlyList<string> SelectedDatabaseNames => DatabaseChoices.Where(x => x.IsSelected).Select(x => x.Name).ToList();
    private void DatabaseChoiceChanged(object? sender, System.ComponentModel.PropertyChangedEventArgs e)
    {
        if (e.PropertyName == nameof(ReportDatabaseChoice.IsSelected) && !_changingDatabases) DatabaseSelectionChanged();
    }
    private void DatabaseSelectionChanged()
    {
        CancelOperation(); ClearResults();
        Raise(nameof(DatabaseSelectionSummary)); Raise(nameof(SelectedDatabaseSummary));
    }
    private void SetDatabaseSelection(bool selected)
    {
        _changingDatabases = true;
        try { foreach (var choice in selected ? FilteredDatabaseChoices : DatabaseChoices) choice.IsSelected = selected; }
        finally { _changingDatabases = false; }
        DatabaseSelectionChanged();
    }
    public ObservableCollection<ReportUser> Users { get; } = [];
    public ObservableCollection<ReportRoleMembership> Memberships { get; } = [];
    public ObservableCollection<ReportPermission> Permissions { get; } = [];
    public ObservableCollection<ReportRole> Roles { get; } = [];
    public ObservableCollection<CredentialAgeRow> Credentials { get; } = [];
    public IReadOnlyList<string> Actions { get; } = ["Todas", "GRANT", "DENY", "REVOKE"];
    public IReadOnlyList<string> RoleKinds { get; } = ["Todos", "Fijos", "Personalizados"];
    public IReadOnlyList<string> CredentialStates { get; } = ["Todos", "Habilitados", "Deshabilitados", "Más de 45 días", "Hasta 45 días", "Fecha no disponible", "SQL_LOGIN", "WINDOWS_LOGIN"];
    public ServerItem? SelectedServer
    {
        get => _server;
        set
        {
            if (!Set(ref _server, value)) return;
            ResetDatabase(); ClearResults();
            ContextLoad = LoadDatabasesAsync(value);
        }
    }
    public string? SelectedDatabase
    {
        get => _database;
        set
        {
            if (!Set(ref _database, value)) return;
            ClearResults();
            ContextLoad = Task.CompletedTask;
            Status = "Pulse Consultar para cargar el catálogo de esta base.";
        }
    }
    public ReportUser? SelectedUser
    {
        get => _user;
        set { if (Set(ref _user, value)) { CancelOperation(); ClearResults(); } }
    }
    public ReportRole? SelectedRole
    {
        get => _role;
        set { if (Set(ref _role, value)) { Raise(nameof(RoleMembers)); Raise(nameof(SelectedRoleDescription)); Raise(nameof(RoleDetailTree)); } }
    }
    public IReadOnlyList<ReportRoleTreeNode> RoleDetailTree => RoleCatalogDetails.Tree(SelectedRole);
    public IEnumerable<ReportRoleMember> RoleMembers => SelectedRole?.Members ?? [];
    public string SelectedRoleDescription => SelectedRole is null ? "Seleccione un rol del catálogo." : $"{SelectedRole.Name} · {SelectedRole.Description}";
    public bool IncludeRoleMembersInExport
    {
        get => _includeRoleMembersInExport;
        set
        {
            if (!Set(ref _includeRoleMembersInExport, value)) return;
            if (!value) foreach (var role in _allRoles) role.ExportMembers = false;
            MemberExportChanged();
        }
    }
    public string MemberExportSummary => !IncludeRoleMembersInExport ? "Se exportarán el catálogo y sus permisos directos, heredados y capacidades fijas, sin el detalle de miembros."
        : SelectedMemberExportCount == 0 ? "Marque uno o varios roles en la columna «Exportar miembros»."
        : $"Se incluirán los miembros de {SelectedMemberExportCount} rol(es) marcado(s).";
    private int SelectedMemberExportCount => Roles.Count(x => x.ExportMembers);
    private void RoleExportSelectionChanged(object? sender, System.ComponentModel.PropertyChangedEventArgs e)
    {
        if (e.PropertyName == nameof(ReportRole.ExportMembers)) MemberExportChanged();
    }
    private void MemberExportChanged()
    {
        Raise(nameof(MemberExportSummary)); Raise(nameof(CanExport)); RefreshCommands();
    }
    public string Search { get => _search; set { if (Set(ref _search, value)) ApplyFilters(); } }
    public string ActionFilter { get => _action; set { if (Set(ref _action, value)) ApplyFilters(); } }
    public string RoleKindFilter { get => _roleKind; set { if (Set(ref _roleKind, value)) ApplyFilters(); } }
    public string CredentialStateFilter { get => _credentialState; set { if (Set(ref _credentialState, value)) ApplyFilters(); } }
    public string Status { get => _status; private set => Set(ref _status, value); }
    public bool IsBusy { get => _busy; private set { if (Set(ref _busy, value)) WorkingChanged(); } }
    public bool IsExporting { get => _isExporting; private set { if (Set(ref _isExporting, value)) WorkingChanged(); } }
    public bool IsWorking => IsBusy || IsExporting;
    public bool CanSelectContext => !IsWorking;
    public bool CanExport => !_disposed && _hasResult && !IsWorking &&
        (!IsRoleCatalog || !IncludeRoleMembersInExport || SelectedMemberExportCount > 0);
    private void WorkingChanged()
    {
        Raise(nameof(CanSelectContext)); Raise(nameof(IsWorking)); Raise(nameof(CanExport)); RefreshCommands();
    }
    public string ResultSummary => !_hasResult ? "Sin consulta realizada" : Kind switch
    {
        ReportKind.UserPermissions => $"{Memberships.Count} de {_allMemberships.Count} roles · {Permissions.Count} de {_allPermissions.Count} permisos directos",
        ReportKind.InstancePermissions => $"{InstanceLogins.Count} de {_allInstanceLogins.Count} cuentas · {Memberships.Count} de {_allMemberships.Count} roles · {Permissions.Count} de {_allPermissions.Count} permisos directos",
        ReportKind.RoleCatalog => $"{Roles.Count} de {_allRoles.Count} roles",
        _ => $"{Credentials.Count} de {_allCredentials.Count} cuentas · {_allCredentials.Count(x => x.LoginType == "SQL_LOGIN" && x.Days is null)} fechas no disponibles"
    };
    public string EmptyMessage => !_hasResult ? "Seleccione el servidor y complete las opciones del reporte. Luego pulse Consultar." :
        "No hay resultados para las opciones seleccionadas. Pruebe con otros filtros.";
    public bool ShowEmpty => !IsBusy && (IsInstancePermissions ? (ActiveSectionIndex switch
    {
        0 => Memberships.Count == 0, 1 => Permissions.Count == 0, 2 => DatabaseCoverage.Count == 0, _ => InstanceLogins.Count == 0
    }) : !IsUserPermissions ? (IsRoleCatalog ? Roles.Count == 0 : Credentials.Count == 0) : Memberships.Count == 0 && Permissions.Count == 0 && DatabaseCoverage.Count == 0);
    public AsyncCommand QueryCommand { get; }
    public AsyncCommand ReloadCommand { get; }
    public RelayCommand CancelCommand { get; }
    public AsyncCommand ExportPdfCommand { get; }
    public AsyncCommand ExportCsvCommand { get; }
    public AsyncCommand ExportExcelCommand { get; }
    public RelayCommand SelectDatabasesCommand { get; }
    public RelayCommand ClearDatabasesCommand { get; }
    public Task Initialization { get; }
    public Task ContextLoad { get; private set; } = Task.CompletedTask;

    public ReportsViewModel(IReportsDataSource source, ReportKind kind, IReportExportService? exporter = null, IReportSaveDialog? saveDialog = null)
    {
        _source = source; Kind = kind; _activeSectionIndex = IsInstancePermissions ? 3 : 0;
        _exporter = exporter ?? new ReportExportService(); _saveDialog = saveDialog ?? new ReportSaveDialog();
        FilteredUsers = new ListCollectionView(Users)
        {
            Filter = item => item is ReportUser user && (string.IsNullOrWhiteSpace(LoginSearch)
                || user.Name.Contains(LoginSearch.Trim(), StringComparison.OrdinalIgnoreCase))
        };
        QueryCommand = new(QueryAsync, () => !_disposed && !IsWorking && SelectedServer is not null &&
            (IsCredentialAge || IsInstancePermissions || IsRoleCatalog && SelectedDatabase is not null || IsUserPermissions && SelectedUser is not null));
        ReloadCommand = new(InitializeAsync, () => !_disposed && !IsWorking);
        ExportPdfCommand = new(() => ExportAsync(ReportExportFormat.Pdf), () => CanExport);
        ExportCsvCommand = new(() => ExportAsync(ReportExportFormat.Csv), () => CanExport);
        ExportExcelCommand = new(() => ExportAsync(ReportExportFormat.Excel), () => CanExport);
        CancelCommand = new(() => { var exporting = IsExporting; CancelOperation(); Status = exporting ? "Exportación cancelada." : "Consulta cancelada. Puede volver a consultar."; }, () => IsWorking);
        SelectDatabasesCommand = new(() => SetDatabaseSelection(true), () => !_disposed && !IsWorking);
        ClearDatabasesCommand = new(() => SetDatabaseSelection(false), () => !_disposed && !IsWorking);
        Initialization = InitializeAsync();
    }

    private CancellationToken BeginOperation(string message)
    {
        _operation?.Cancel(); _operation?.Dispose();
        _operation = new(); IsBusy = true; Status = message;
        return _operation.Token;
    }
    private void CancelOperation()
    {
        _operation?.Cancel(); _exportOperation?.Cancel(); IsBusy = false; Raise(nameof(ShowEmpty));
    }
    private bool IsCurrent(CancellationToken token) => !_disposed && !token.IsCancellationRequested && _operation?.Token == token;
    private void EndOperation(CancellationToken token)
    {
        if (!IsCurrent(token)) return;
        IsBusy = false; Raise(nameof(ShowEmpty));
    }
    private void RefreshCommands()
    {
        QueryCommand.Refresh(); ReloadCommand.Refresh(); CancelCommand.Refresh();
        ExportPdfCommand.Refresh(); ExportCsvCommand.Refresh(); ExportExcelCommand.Refresh();
        SelectDatabasesCommand.Refresh(); ClearDatabasesCommand.Refresh();
    }
    private void ResetDatabase()
    {
        _database = null; _user = null;
        Raise(nameof(SelectedDatabase)); Raise(nameof(SelectedUser));
        Databases.Clear(); Users.Clear();
        _loginSearch = ""; Raise(nameof(LoginSearch)); RefreshLoginFilter();
        foreach (var choice in DatabaseChoices) choice.PropertyChanged -= DatabaseChoiceChanged;
        DatabaseChoices.Clear(); DatabaseSearch = "";
        Raise(nameof(FilteredDatabaseChoices)); Raise(nameof(DatabaseSelectionSummary)); Raise(nameof(SelectedDatabaseSummary));
    }
    private async Task InitializeAsync()
    {
        if (_disposed) return;
        _server = null; Raise(nameof(SelectedServer)); Servers.Clear(); ResetDatabase(); ClearResults();
        var token = BeginOperation("Cargando servidores autorizados…");
        try
        {
            var servers = await _source.GetReportServersAsync(token);
            if (!IsCurrent(token)) return;
            foreach (var server in servers) Servers.Add(server);
            Status = Servers.Count == 0 ? "No hay servidores activos disponibles." : "Seleccione un servidor para continuar.";
        }
        catch (OperationCanceledException) { }
        catch (Exception ex) { if (IsCurrent(token)) Status = $"No se pudieron cargar los servidores: {ex.Message}"; }
        finally { EndOperation(token); }
    }
    private async Task LoadDatabasesAsync(ServerItem? server)
    {
        CancelOperation();
        if (_disposed || server is null) return;
        if (IsCredentialAge) { Status = "Pulse Consultar para revisar las credenciales de esta instancia."; RefreshCommands(); return; }
        var token = BeginOperation("Cargando bases accesibles…");
        try
        {
            var databaseTask = _source.GetReportDatabasesAsync(server.Id, token);
            var usersTask = IsUserPermissions ? _source.GetReportUsersAsync(server.Id, token) : Task.FromResult<IReadOnlyList<ReportUser>>([]);
            await Task.WhenAll(databaseTask, usersTask);
            var databases = await databaseTask;
            if (!IsCurrent(token)) return;
            foreach (var database in databases)
            {
                Databases.Add(database);
                var choice = new ReportDatabaseChoice(database);
                choice.PropertyChanged += DatabaseChoiceChanged; DatabaseChoices.Add(choice);
            }
            foreach (var user in (await usersTask).Where(IsSelectableLogin)) Users.Add(user);
            RefreshLoginFilter();
            Raise(nameof(FilteredDatabaseChoices));
            Status = IsInstancePermissions ? "Pulse Consultar para ver las cuentas del servidor. Puede marcar bases de datos para revisar también sus accesos."
                : IsUserPermissions ? "Seleccione un login. Marque una o varias bases, o consulte solo la instancia."
                : Databases.Count == 0 ? "No hay bases en línea accesibles con esta conexión." : "Seleccione una base de datos.";
        }
        catch (OperationCanceledException) { }
        catch (Exception ex) { if (IsCurrent(token)) Status = $"No se pudieron cargar las bases: {ex.Message}"; }
        finally { EndOperation(token); }
    }
    public async Task QueryAsync()
    {
        if (_disposed || IsWorking || SelectedServer is null || NeedsDatabase && SelectedDatabase is null || IsUserPermissions && SelectedUser is null) return;
        var server = SelectedServer!; var database = SelectedDatabase; var user = SelectedUser;
        ClearResults();
        var token = BeginOperation("Consultando la información del servidor…");
        try
        {
            if (IsInstancePermissions)
            {
                var result = await _source.GetInstanceAccessReportAsync(server.Id, SelectedDatabaseNames, token);
                if (!IsCurrent(token)) return;
                _allInstanceLogins = result.Logins;
                _allMemberships = result.Roles.Where(x => !x.Name.Equals("public", StringComparison.OrdinalIgnoreCase)).ToList();
                var sysadmins = result.Logins.Where(x => x.IsSysadmin).Select(x => x.Name).ToHashSet(StringComparer.Ordinal);
                _allPermissions = result.Permissions.Select(x => x with { CoveredBySysadmin = sysadmins.Contains(x.Login) }).ToList();
                _allCoverage = result.Databases;
            }
            else if (IsUserPermissions)
            {
                var result = await _source.GetUserAccessReportAsync(server.Id, SelectedDatabaseNames, user!.Name, token);
                if (!IsCurrent(token)) return;
                _allMemberships = result.Roles
                    .Where(role => !string.Equals(role.Name, "public", StringComparison.OrdinalIgnoreCase))
                    .ToList();
                var sysadmin = _allMemberships.Any(role => role.Level == "Instancia"
                    && string.Equals(role.Name, "sysadmin", StringComparison.OrdinalIgnoreCase));
                _allPermissions = result.Permissions.Select(permission => permission with { CoveredBySysadmin = sysadmin }).ToList();
                _allCoverage = result.Databases;
            }
            else if (IsRoleCatalog)
            {
                var result = await _source.GetRoleCatalogReportAsync(server.Id, database!, token);
                if (!IsCurrent(token)) return;
                _allRoles = result;
                foreach (var role in _allRoles) role.PropertyChanged += RoleExportSelectionChanged;
            }
            else
            {
                var result = await _source.GetCredentialAgeReportAsync(server.Id, token);
                if (!IsCurrent(token)) return;
                _allCredentials = result;
            }
            _queriedAt = SqlAccessAdmin.Infrastructure.AppTime.OffsetNow; _hasResult = true; ApplyFilters();
            Status = $"Consulta completada · {server.Name}{(IsPermissionsReport ? $" / {SelectedDatabaseSummary}" : database is null ? "" : $" / {database}")}{(user is null ? "" : $" / {user.Name}")} · {SqlAccessAdmin.Infrastructure.AppTime.Now:yyyy-MM-dd HH:mm:ss}";
        }
        catch (OperationCanceledException) { }
        catch (Exception ex) { if (IsCurrent(token)) { ClearResults(); Status = $"No fue posible generar el reporte: {ex.Message}"; } }
        finally { EndOperation(token); }
    }
    private bool Matches(params string[] values) => string.IsNullOrWhiteSpace(Search) || values.Any(x => x.Contains(Search.Trim(), StringComparison.OrdinalIgnoreCase));
    private void ApplyFilters()
    {
        Replace(InstanceLogins, _allInstanceLogins.Where(x => Matches(x.Name, x.Type, x.Status, x.Access)));
        Replace(Memberships, _allMemberships.Where(x => Matches(x.Login, x.Level, x.Database, x.Principal, x.Name, x.Kind, x.Description, x.Assignment)));
        Replace(Permissions, _allPermissions.Where(x => Matches(x.Login, x.Level, x.Database, x.Principal, x.Scope, x.Schema, x.Object, x.ObjectType, x.Column, x.Permission, x.Action, x.OriginStatus)
            && (ActionFilter == "Todas" || x.Action.StartsWith(ActionFilter, StringComparison.Ordinal))));
        Replace(DatabaseCoverage, _allCoverage.Where(x => Matches(x.Login, x.Database, x.User, x.Detail)));
        var selectedName = SelectedRole?.Name;
        Replace(Roles, _allRoles.Where(x => Matches(x.Name, x.Kind, x.Description, x.MemberSummary, x.DetailSearch)
            && (RoleKindFilter == "Todos" || RoleKindFilter == "Fijos" && (x.IsFixed || x.Name == "public") || RoleKindFilter == "Personalizados" && !x.IsFixed && x.Name != "public")));
        SelectedRole = Roles.FirstOrDefault(x => x.Name == selectedName) ?? Roles.FirstOrDefault();
        var visibleRoleNames = Roles.Select(x => x.Name).ToHashSet(StringComparer.Ordinal);
        foreach (var role in _allRoles.Where(x => x.ExportMembers && !visibleRoleNames.Contains(x.Name))) role.ExportMembers = false;
        Raise(nameof(MemberExportSummary));
        Replace(Credentials, _allCredentials.Where(x => Matches(x.Name, x.LoginType, x.Status, x.Classification) && (CredentialStateFilter switch
        {
            "Habilitados" => !x.Disabled, "Deshabilitados" => x.Disabled,
            "Más de 45 días" => x.Days > 45, "Hasta 45 días" => x.Days is >= 0 and <= 45,
            "SQL_LOGIN" => x.LoginType == "SQL_LOGIN", "WINDOWS_LOGIN" => x.LoginType == "WINDOWS_LOGIN",
            "Fecha no disponible" => x.LoginType == "SQL_LOGIN" && x.PasswordLastSet is null, _ => true
        })));
        foreach (var property in new[] { nameof(ResultSummary), nameof(ShowEmpty), nameof(EmptyMessage), nameof(CanExport) }) Raise(property);
        RefreshCommands();
    }
    public ReportExportDocument CreateExportDocument(ReportExportScope scope = ReportExportScope.FullReport)
    {
        if (!_hasResult || _disposed || IsBusy) throw new InvalidOperationException("Primero debe consultar un reporte.");
        if (IsRoleCatalog && IncludeRoleMembersInExport && SelectedMemberExportCount == 0)
            throw new InvalidOperationException("Marque al menos un rol para exportar sus miembros o desactive la opción de incluir miembros.");
        static IEnumerable<T> Visible<T>(ObservableCollection<T> source) => CollectionViewSource.GetDefaultView(source).Cast<T>();
        List<ReportExportSection> sections = [];
        if (IsPermissionsReport)
        {
            sections.Add(new("Roles asignados", [new("Nivel"), new("Base", 1.3), new("Usuario", 1.3), new("Rol", 1.5), new("Tipo"), new("Asignación"), new("Descripción", 3)],
                Visible(Memberships).Select(x => new object?[] { x.Level, x.DatabaseDisplay, x.Principal, x.Name, x.Kind, x.Assignment, x.Description }).ToList()));
            sections.Add(new("Permisos directos", [new("Nivel"), new("Base", 1.2), new("Usuario", 1.6), new("Ámbito", 1.1), new("Esquema", 0.9), new("Objeto", 1.4), new("Tipo", 0.9), new("Columna", 0.9), new("Permiso", 1.3), new("Acción", 1.5), new("Origen / Estado", 2.4)],
                Visible(Permissions).Select(x => new object?[] { x.Level, x.DatabaseDisplay, x.Principal, x.Scope, x.SchemaDisplay, x.ObjectDisplay, x.ObjectTypeDisplay, x.ColumnDisplay, x.Permission, x.Action, x.OriginStatus }).ToList()));
            sections.Add(new("Bases revisadas", [new("Base", 1.5), new("Usuario", 1.5), new("Resultado", 4)],
                Visible(DatabaseCoverage).Select(x => new object?[] { x.Database, x.User, x.Detail }).ToList()));
            if (IsInstancePermissions)
            {
                // Keep login identity beside the mapped database user in every exported section.
                var loginsBySection = new[] { Visible(Memberships).Select(x => x.Login), Visible(Permissions).Select(x => x.Login), Visible(DatabaseCoverage).Select(x => x.Login) };
                for (var i = 0; i < sections.Count; i++)
                {
                    var section = sections[i];
                    sections[i] = new(section.Name, new[] { new ReportExportColumn("Login", 1.6) }.Concat(section.Columns).ToList(),
                        section.Rows.Zip(loginsBySection[i], (row, login) => new object?[] { login }.Concat(row).ToArray()).ToList());
                }
                sections.Add(new("Logins de la instancia", [new("Login", 2), new("Tipo", 1.5), new("Estado"), new("Acceso", 3)],
                    Visible(InstanceLogins).Select(x => new object?[] { x.Name, x.Type, x.Status, x.Access }).ToList()));
            }
            if (scope == ReportExportScope.ActiveSection) sections = [sections[ActiveSectionIndex]];
        }
        else if (IsRoleCatalog)
        {
            var roles = Visible(Roles).ToList();
            IReadOnlyList<ReportExportColumn> columns = IncludeRoleMembersInExport
                ? [new("Rol", 1.5), new("Tipo"), new("Descripción", 3), new("Cantidad de usuarios")]
                : [new("Rol", 1.5), new("Tipo"), new("Descripción", 3)];
            sections.Add(new("Catálogo de roles", columns,
                roles.Select(x => IncludeRoleMembersInExport
                    ? new object?[] { x.Name, x.Kind, x.Description, x.MemberCount }
                    : new object?[] { x.Name, x.Kind, x.Description }).ToList()));
            if (IncludeRoleMembersInExport)
                sections.Add(new("Miembros por rol", [new("Rol", 1.5), new("Miembro", 2), new("Tipo de cuenta", 1.5), new("Membresía", 1.3)],
                    roles.Where(role => role.ExportMembers).SelectMany(role => role.Members.Select(member => new object?[] { role.Name, member.Name, member.Type, role.Name == "public" ? "Implícita" : "Directa" })
                        .Concat(role.NestedMembers.Select(member => new object?[] { role.Name, member, "Rol", "Directa" }))).ToList()));
            sections.Add(new("Permisos de roles", [new("Rol", 1.6), new("Origen", 1), new("Rol de origen", 1.6), new("Ámbito", 1), new("Recurso", 2.4), new("Permiso", 1.4), new("Acción", 1.8)],
                roles.SelectMany(role => role.DirectPermissions.Select(p => PermissionRow(role.Name, "Directo", role.Name, p))
                    .Concat(role.InheritedRoles.SelectMany(parent => parent.Permissions.Select(p => PermissionRow(role.Name, "Heredado", parent.Name, p))))).ToList()));
            sections.Add(new("Roles heredados", [new("Rol", 1.8), new("Rol de origen", 1.8), new("Membresía", 1.6), new("Tipo"), new("Descripción", 3)],
                roles.SelectMany(role => role.InheritedRoles.Select(parent => new object?[] { role.Name, parent.Name, parent.Assignment, parent.IsFixed ? "Fijo" : "Personalizado", parent.Description })).ToList()));
            sections.Add(new("Capacidades de roles fijos", [new("Rol", 1.7), new("Origen"), new("Rol de origen", 1.7), new("Capacidades incorporadas", 4)],
                roles.SelectMany(role => (role.IsFixed ? new[] { new object?[] { role.Name, "Propio", role.Name, role.Description } } : [])
                    .Concat(role.InheritedRoles.Where(parent => parent.IsFixed).Select(parent => new object?[] { role.Name, "Heredado", parent.Name, parent.Description }))).ToList()));
        }
        else
            sections.Add(new("Credenciales", [new("Cuenta", 1.8), new("Tipo", 1.4), new("Estado", 1.2), new("Último cambio de contraseña", 1.8), new("Días contraseña"), new("Última actualización de la cuenta", 1.8), new("Días desde modificación"), new("Clasificación", 1.5), new("Política"), new("Expiración"), new("Fecha obtenida de", 1.8)],
                Visible(Credentials).Select(x => new object?[] { x.Name, x.LoginType, x.Status, x.PasswordLastSet, x.Days, x.LastModified, x.ModificationDays, x.Classification, x.PolicyChecked, x.ExpirationChecked, x.PasswordDateSourceDisplay }).ToList()));
        var filter = IsPermissionsReport ? $"Acción: {ActionFilter}" : IsRoleCatalog ? $"Tipo de rol: {RoleKindFilter}" : $"Estado: {CredentialStateFilter}";
        if (IsPermissionsReport) filter += scope == ReportExportScope.ActiveSection ? $" | Sección exportada: {ActiveSectionName}" : " | Secciones: Reporte completo";
        if (IsRoleCatalog) filter += IncludeRoleMembersInExport
            ? $" | Miembros de: {string.Join(", ", Visible(Roles).Where(role => role.ExportMembers).Select(role => role.Name))}"
            : " | Miembros: no incluidos";
        return new(Heading, SelectedServer!.Name, IsPermissionsReport ? SelectedDatabaseSummary : SelectedDatabase ?? "Instancia", IsInstancePermissions ? "Cuentas del servidor" : SelectedUser?.Name ?? "No aplica", _queriedAt,
            $"Búsqueda: {(string.IsNullOrWhiteSpace(Search) ? "Sin filtro" : Search)} | {filter}", IsRoleCatalog ? RoleCatalogDetails.ScopeNote : "", sections);
    }
    private static object?[] PermissionRow(string role, string origin, string source, ReportPermission permission) =>
        [role, origin, source, permission.Scope, RoleCatalogDetails.Resource(permission), permission.Permission, permission.Action];
    public async Task ExportAsync(ReportExportFormat format)
    {
        if (!CanExport) return;
        try
        {
            var scope = IsPermissionsReport ? _saveDialog.ChooseScope(format, ActiveSectionName,
                IsInstancePermissions ? ["Roles asignados", "Permisos directos", "Bases revisadas", "Logins de la instancia"]
                    : ["Roles asignados", "Permisos directos", "Bases revisadas"]) : ReportExportScope.FullReport;
            if (scope is null || _disposed || !_hasResult) return;
            var snapshot = CreateExportDocument(scope.Value);
            var name = IsPermissionsReport && scope == ReportExportScope.ActiveSection ? $"{Heading}_{ActiveSectionName}" : Heading;
            var safeName = string.Concat(name.Select(c => Path.GetInvalidFileNameChars().Contains(c) ? '_' : c));
            var path = _saveDialog.ChoosePath(format, $"{safeName}_{SqlAccessAdmin.Infrastructure.AppTime.Now:yyyyMMdd_HHmmss}");
            if (path is null || _disposed || !_hasResult) return;
            _exportOperation?.Dispose(); _exportOperation = new(); var token = _exportOperation.Token;
            IsExporting = true; Status = "Exportando resultados filtrados…";
            try
            {
                await _exporter.ExportAsync(snapshot, path, format, token);
                if (!_disposed && !token.IsCancellationRequested) Status = $"Reporte exportado: {path}";
            }
            catch (OperationCanceledException) { if (!_disposed) Status = "Exportación cancelada."; }
            finally { IsExporting = false; }
        }
        catch (Exception ex) { if (!_disposed) Status = $"No fue posible exportar el reporte: {ex.Message}"; }
    }
    private static void Replace<T>(ObservableCollection<T> target, IEnumerable<T> values)
    {
        target.Clear(); foreach (var value in values) target.Add(value);
    }
    private void ClearResults()
    {
        foreach (var role in _allRoles) { role.PropertyChanged -= RoleExportSelectionChanged; role.ExportMembers = false; }
        _includeRoleMembersInExport = false; Raise(nameof(IncludeRoleMembersInExport));
        _hasResult = false; _allMemberships = []; _allPermissions = []; _allRoles = []; _allCredentials = []; _allCoverage = []; _allInstanceLogins = [];
        DatabaseCoverage.Clear();
        SelectedRole = null; ApplyFilters(); RefreshCommands();
        Status = "Seleccione los datos del reporte y pulse Consultar.";
    }
    public void Dispose()
    {
        if (_disposed) return;
        _disposed = true; CancelOperation(); _operation?.Dispose(); _operation = null;
        _exportOperation?.Dispose(); _exportOperation = null;
        foreach (var choice in DatabaseChoices) choice.PropertyChanged -= DatabaseChoiceChanged;
        ClearResults();
    }
}
