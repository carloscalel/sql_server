/* Hora única de la aplicación: Guatemala. Ejecutar con clientes y worker detenidos,
   después de respaldo. Existente UTC: 36 -> 33 actualizado -> 99.
   Convierte fechas estructuradas una sola vez. No cambia hashes históricos. */
USE [adminDB];
GO
SET ANSI_NULLS ON;SET QUOTED_IDENTIFIER ON;
GO
BEGIN TRY
 IF SCHEMA_ID(N'access') IS NULL OR OBJECT_ID(N'access.ufn_App_HasPermission',N'FN') IS NULL
  OR OBJECT_ID(N'access.usp_App_RequirePermission',N'P') IS NULL
  OR OBJECT_ID(N'access.SecurityPolicyOperation',N'U') IS NULL
  OR DATABASE_PRINCIPAL_ID(N'SqlAccessAdmin_Users') IS NULL
  THROW 51862,'Instale primero los scripts 01 a 32 antes de ejecutar 36 -> 33.',1;
 IF NOT EXISTS(SELECT 1 FROM access.SecurityPolicyOperation WHERE OperationCode='CHANGE_LOGIN_PASSWORD')
  THROW 51862,'Falta el contrato de contraseñas del script 32. Instale 32 antes de ejecutar 36 -> 33.',1;
END TRY
BEGIN CATCH
 DECLARE @PreconditionMessage nvarchar(2048)=ERROR_MESSAGE(),@PreconditionNumber int=ERROR_NUMBER();
 RAISERROR(N'%s (error %d). No se aplicó el script 36.',16,1,@PreconditionMessage,@PreconditionNumber);
 SET NOEXEC ON;
END CATCH;
GO
IF OBJECT_ID(N'access.ufn_AppNow',N'FN') IS NULL
 EXEC(N'CREATE FUNCTION access.ufn_AppNow() RETURNS datetime2(7) AS BEGIN RETURN DATEADD(hour,-6,SYSUTCDATETIME()); END;');
GO
SET NOCOUNT ON;SET XACT_ABORT ON;
SET ANSI_NULLS ON;SET QUOTED_IDENTIFIER ON;SET ANSI_PADDING ON;SET ANSI_WARNINGS ON;
SET ARITHABORT ON;SET CONCAT_NULL_YIELDS_NULL ON;SET NUMERIC_ROUNDABORT OFF;
DECLARE @AuditValidator nvarchar(max)=N'CREATE OR ALTER PROCEDURE access.usp_Audit_ValidateIntegrity AS
  BEGIN
   SET NOCOUNT ON;
   -- SqlAccessAdmin.MultiRoleGuard.v1 AUDIT
   EXEC access.usp_App_RequirePermission ''AUDIT'';
   ;WITH c AS
   (SELECT AuditId,PreviousHash,EventHash,LAG(EventHash,1,CONVERT(varbinary(32),0x)) OVER(ORDER BY AuditId) ExpectedPrevious,
    CASE WHEN HashDateBasis IS NULL OR EventDate=DATEADD(hour,-6,CONVERT(datetime2(3),HashDateBasis)) THEN 0 ELSE 1 END InvalidLocalDate,
    HASHBYTES(''SHA2_256'',PreviousHash+CONVERT(varbinary(max),CONCAT(CONVERT(nvarchar(33),
     CASE WHEN HashDateBasis IS NULL THEN EventDate ELSE CONVERT(datetime2(3),HashDateBasis) END,126),N''|'',Principal,N''|'',Form,N''|'',Action,N''|'',
     COALESCE(ServerName,N''''),N''|'',COALESCE(DatabaseName,N''''),N''|'',CONVERT(nvarchar(1),Success),N''|'',COALESCE(Detail,N''''),N''|'',CONVERT(nvarchar(36),CorrelationId)))) ExpectedHash
    FROM access.AuditEvent WHERE EventHash IS NOT NULL)
   SELECT COUNT_BIG(*) HashedEvents,COALESCE(SUM(CASE WHEN PreviousHash=ExpectedPrevious THEN 0 ELSE 1 END),0) BrokenLinks,
    COALESCE(SUM(CASE WHEN EventHash=ExpectedHash AND InvalidLocalDate=0 THEN 0 ELSE 1 END),0) AlteredEvents,
    CAST(IIF(COALESCE(SUM(CASE WHEN PreviousHash=ExpectedPrevious AND EventHash=ExpectedHash AND InvalidLocalDate=0 THEN 0 ELSE 1 END),0)=0,1,0) AS bit) IsValid FROM c;
  END;';
BEGIN TRY
IF ABS(DATEDIFF(second,access.ufn_AppNow(),DATEADD(hour,-6,SYSUTCDATETIME())))>5
 THROW 51859,'El reloj de aplicación existente no corresponde a Guatemala.',1;
IF OBJECT_ID(N'access.AppTimeConvention',N'U') IS NOT NULL
BEGIN
 IF NOT EXISTS(SELECT 1 FROM access.AppTimeConvention WHERE Id=1 AND Version=4 AND TimeZoneName=N'Central America Standard Time')
  THROW 51850,'Convención temporal desconocida. No se realizará una conversión automática.',1;
 -- Reparar instalaciones convertidas con la versión que omitía la guarda AUDIT.
 IF COL_LENGTH(N'access.AuditEvent',N'HashDateBasis') IS NOT NULL
  AND ISNULL(OBJECT_DEFINITION(OBJECT_ID(N'access.usp_Audit_ValidateIntegrity',N'P')),N'') NOT LIKE N'%SqlAccessAdmin.MultiRoleGuard.v1 AUDIT%'
  EXEC sys.sp_executesql @AuditValidator;
 PRINT N'Hora de Guatemala ya aplicada; no se convirtieron fechas otra vez.';
 RETURN;
END;
DECLARE @Lock int,@Sql nvarchar(max),@Table sysname,@Column sysname,@NewColumn sysname,@Qualified nvarchar(776),@Rows bigint,
 @AuditEnabled bit=0,@HasAudit bit=CASE WHEN OBJECT_ID(N'access.AuditEvent',N'U') IS NOT NULL THEN 1 ELSE 0 END;
DECLARE @Integrity table(HashedEvents bigint,BrokenLinks int,AlteredEvents int,IsValid bit);
 BEGIN TRAN;
 EXEC @Lock=sys.sp_getapplock @Resource=N'SqlAccessAdmin.TimeConvention',@LockMode='Exclusive',@LockOwner='Transaction',@LockTimeout=10000;
 IF @Lock<0 THROW 51851,'No se pudo reservar la conversión de fechas.',1;
 IF EXISTS(SELECT 1 FROM sys.sql_modules m JOIN sys.objects o ON o.object_id=m.object_id WHERE o.schema_id=SCHEMA_ID(N'access') AND m.definition IS NULL)
  THROW 51861,'Hay módulos de aplicación cifrados o sin definición visible. No se puede validar su reloj; se cancela la conversión.',1;
 IF @HasAudit=1 AND COL_LENGTH(N'access.AuditEvent',N'EventHash') IS NOT NULL
 BEGIN
  IF OBJECT_ID(N'access.usp_Audit_ValidateIntegrity',N'P') IS NULL THROW 51852,'Falta el validador de integridad de auditoría.',1;
  INSERT @Integrity EXEC access.usp_Audit_ValidateIntegrity;
  IF NOT EXISTS(SELECT 1 FROM @Integrity WHERE IsValid=1) THROW 51853,'La auditoría ya tiene alteraciones; se canceló la conversión.',1;
  IF EXISTS(SELECT 1 FROM sys.triggers WHERE object_id=OBJECT_ID(N'access.tr_AuditEvent_AppendOnly') AND is_disabled=0)
  BEGIN SET @AuditEnabled=1;DISABLE TRIGGER access.tr_AuditEvent_AppendOnly ON access.AuditEvent;END;
  IF COL_LENGTH(N'access.AuditEvent',N'HashDateBasis') IS NULL EXEC(N'ALTER TABLE access.AuditEvent ADD HashDateBasis varbinary(16) NULL;');
  -- Se conserva la entrada binaria del hash. EventDate será la fecha de lectura local.
  EXEC(N'UPDATE access.AuditEvent SET HashDateBasis=CONVERT(varbinary(16),EventDate) WHERE EventHash IS NOT NULL;');
 END;
 CREATE TABLE access.AppTimeConversion(TableName sysname NOT NULL,ColumnName sysname NOT NULL,NewColumnName sysname NOT NULL,
  ConvertedRows bigint NOT NULL,AppliedAt datetime2(7) NOT NULL DEFAULT access.ufn_AppNow(),PRIMARY KEY(TableName,ColumnName));
 DECLARE @Dates table(TableName sysname,ColumnName sysname,NewColumnName sysname,PRIMARY KEY(TableName,ColumnName));
 -- Columnas UTC explícitas, incluidas tablas históricas de versiones anteriores.
 INSERT @Dates SELECT t.name,c.name,LEFT(c.name,LEN(c.name)-3) FROM sys.tables t JOIN sys.schemas s ON s.schema_id=t.schema_id
  JOIN sys.columns c ON c.object_id=t.object_id JOIN sys.types ty ON ty.user_type_id=c.user_type_id
  WHERE s.name=N'access' AND RIGHT(c.name,3) COLLATE Latin1_General_100_CI_AS=N'Utc' AND ty.name IN(N'datetime',N'datetime2',N'smalldatetime');
 -- Fechas históricas sin sufijo, originalmente escritas con SYSUTCDATETIME.
 INSERT @Dates SELECT v.TableName,v.ColumnName,v.ColumnName FROM (VALUES
 (N'AuthorizedPrincipal',N'CreatedAt'),(N'ManagedServer',N'CreatedAt'),(N'CryptoConfiguration',N'CreatedAt'),
 (N'SecurityPolicyPermission',N'ApprovedAt'),(N'SecurityPolicyRole',N'ApprovedAt'),(N'SecurityDenyList',N'CreatedAt'),
 (N'AccessRequest',N'RequestedAt'),(N'AccessRequest',N'ApprovedAt'),(N'AccessRequest',N'ExecutedAt'),
 (N'SecurityPolicyOverride',N'ApprovedAt'),(N'PolicyPermissionRule',N'ApprovedAt'),(N'PolicyRoleRule',N'ApprovedAt'),
 (N'PolicyRoleDiscovery',N'LastSeenAt'),(N'AuditEvent',N'EventDate'))v(TableName,ColumnName)
 WHERE COL_LENGTH(N'access.'+v.TableName,v.ColumnName) IS NOT NULL;
 DECLARE @Unmapped nvarchar(2048)=(SELECT TOP(1) CONCAT(N'Fecha sin convención catalogada: access.',t.name,N'.',c.name,N'. Revisar antes de convertir.')
  FROM sys.tables t JOIN sys.columns c ON c.object_id=t.object_id
  WHERE t.schema_id=SCHEMA_ID(N'access') AND TYPE_NAME(c.user_type_id) IN(N'datetime',N'datetime2',N'smalldatetime')
   AND t.name<>N'AppTimeConversion'
   AND NOT EXISTS(SELECT 1 FROM @Dates d WHERE d.TableName=t.name AND d.ColumnName=c.name)
   AND NOT(t.name IN(N'AppSecurityChange',N'PrincipalMetadataSnapshot') AND c.name IN(N'ModifiedLocal',N'PasswordSetLocal')));
 IF @Unmapped IS NOT NULL THROW 51860,@Unmapped,1;
 DECLARE dates CURSOR LOCAL FAST_FORWARD FOR SELECT TableName,ColumnName,NewColumnName FROM @Dates;
 OPEN dates;FETCH NEXT FROM dates INTO @Table,@Column,@NewColumn;
 WHILE @@FETCH_STATUS=0
 BEGIN
  SET @Sql=N'UPDATE access.'+QUOTENAME(@Table)+N' SET '+QUOTENAME(@Column)+N'=DATEADD(hour,-6,'+QUOTENAME(@Column)+N') WHERE '+QUOTENAME(@Column)+N' IS NOT NULL; SET @Count=@@ROWCOUNT;';
  EXEC sys.sp_executesql @Sql,N'@Count bigint OUTPUT',@Rows OUTPUT;
  IF @Column<>@NewColumn
  BEGIN
   IF COL_LENGTH(N'access.'+@Table,@NewColumn) IS NOT NULL THROW 51854,'Existen columnas temporales de ambas convenciones; revisar antes de convertir.',1;
   SET @Qualified=N'access.'+QUOTENAME(@Table)+N'.'+QUOTENAME(@Column);
   EXEC sys.sp_rename @objname=@Qualified,@newname=@NewColumn,@objtype=N'COLUMN';
  END;
  INSERT access.AppTimeConversion(TableName,ColumnName,NewColumnName,ConvertedRows) VALUES(@Table,@Column,@NewColumn,@Rows);
  FETCH NEXT FROM dates INTO @Table,@Column,@NewColumn;
 END;
 CLOSE dates;DEALLOCATE dates;
 -- Las fechas nativas del motor se normalizan usando el desplazamiento observado.
 DECLARE nativeDates CURSOR LOCAL FAST_FORWARD FOR SELECT name FROM sys.tables WHERE schema_id=SCHEMA_ID(N'access') AND name IN(N'AppSecurityChange',N'PrincipalMetadataSnapshot');
 OPEN nativeDates;FETCH NEXT FROM nativeDates INTO @Table;
 WHILE @@FETCH_STATUS=0
 BEGIN
  IF COL_LENGTH(N'access.'+@Table,N'EngineOffsetMinutes') IS NOT NULL
  BEGIN
   SET @Sql=N'UPDATE access.'+QUOTENAME(@Table)+N' SET ModifiedLocal=DATEADD(minute,-360-EngineOffsetMinutes,ModifiedLocal),PasswordSetLocal=DATEADD(minute,-360-EngineOffsetMinutes,PasswordSetLocal) WHERE EngineOffsetMinutes IS NOT NULL; SET @Count=@@ROWCOUNT;';
   EXEC sys.sp_executesql @Sql,N'@Count bigint OUTPUT',@Rows OUTPUT;
   INSERT access.AppTimeConversion(TableName,ColumnName,NewColumnName,ConvertedRows) VALUES(@Table,N'ModifiedLocal/PasswordSetLocal',N'ModifiedLocal/PasswordSetLocal',@Rows);
  END;
  FETCH NEXT FROM nativeDates INTO @Table;
 END;
 CLOSE nativeDates;DEALLOCATE nativeDates;
 -- Cambiar todos los defaults UTC del esquema propio; no depender del huso del servidor.
 DECLARE @Default sysname,@Definition nvarchar(max),@Rewritten nvarchar(max);
 DECLARE defaults CURSOR LOCAL FAST_FORWARD FOR SELECT t.name,c.name,d.name,d.definition FROM sys.default_constraints d
  JOIN sys.tables t ON t.object_id=d.parent_object_id JOIN sys.columns c ON c.object_id=t.object_id AND c.column_id=d.parent_column_id
  WHERE t.schema_id=SCHEMA_ID(N'access') AND (d.definition COLLATE Latin1_General_100_CI_AS LIKE N'%SYSUTCDATETIME%' OR d.definition COLLATE Latin1_General_100_CI_AS LIKE N'%GETUTCDATE%');
 OPEN defaults;FETCH NEXT FROM defaults INTO @Table,@Column,@Default,@Definition;
 WHILE @@FETCH_STATUS=0
 BEGIN
  SET @Rewritten=REPLACE(REPLACE(@Definition COLLATE Latin1_General_100_CI_AS,N'SYSUTCDATETIME()',N'[access].[ufn_AppNow]()'),N'GETUTCDATE()',N'[access].[ufn_AppNow]()');
  SET @Sql=N'ALTER TABLE access.'+QUOTENAME(@Table)+N' DROP CONSTRAINT '+QUOTENAME(@Default)+N'; ALTER TABLE access.'+QUOTENAME(@Table)+N' ADD CONSTRAINT '+QUOTENAME(@Default)+N' DEFAULT '+@Rewritten+N' FOR '+QUOTENAME(@Column)+N';';
  EXEC sys.sp_executesql @Sql;
  FETCH NEXT FROM defaults INTO @Table,@Column,@Default,@Definition;
 END;
 CLOSE defaults;DEALLOCATE defaults;
 -- Actualizar contratos instalados sin reaplicar migraciones históricas de negocio.
 DECLARE @ObjectId int,@Original nvarchar(max),@Find sysname,@Replace sysname;
 DECLARE modules CURSOR LOCAL FAST_FORWARD FOR SELECT m.object_id,m.definition FROM sys.sql_modules m JOIN sys.objects o ON o.object_id=m.object_id
  WHERE o.schema_id=SCHEMA_ID(N'access') AND o.name<>N'ufn_AppNow' AND m.definition IS NOT NULL;
 OPEN modules;FETCH NEXT FROM modules INTO @ObjectId,@Original;
 WHILE @@FETCH_STATUS=0
 BEGIN
  SET @Rewritten=REPLACE(REPLACE(@Original COLLATE Latin1_General_100_CI_AS,N'SYSUTCDATETIME()',N'[access].[ufn_AppNow]()'),N'GETUTCDATE()',N'[access].[ufn_AppNow]()');
  DECLARE names CURSOR LOCAL FAST_FORWARD FOR SELECT ColumnName,NewColumnName FROM(SELECT DISTINCT ColumnName,NewColumnName FROM @Dates WHERE ColumnName<>NewColumnName)d ORDER BY LEN(ColumnName) DESC;
  OPEN names;FETCH NEXT FROM names INTO @Find,@Replace;
  WHILE @@FETCH_STATUS=0 BEGIN SET @Rewritten=REPLACE(@Rewritten,@Find,@Replace);FETCH NEXT FROM names INTO @Find,@Replace;END;
  CLOSE names;DEALLOCATE names;
  IF @Rewritten<>@Original
  BEGIN
   DECLARE @Start int=1;
   WHILE SUBSTRING(@Rewritten,@Start,1) IN(N' ',NCHAR(9),NCHAR(10),NCHAR(13)) SET @Start+=1;
   IF SUBSTRING(@Rewritten,@Start,6)=N'CREATE' AND SUBSTRING(@Rewritten,@Start,15)<>N'CREATE OR ALTER'
    SET @Rewritten=STUFF(@Rewritten,@Start,6,N'ALTER');
   EXEC sys.sp_executesql @Rewritten;
  END;
  FETCH NEXT FROM modules INTO @ObjectId,@Original;
 END;
 CLOSE modules;DEALLOCATE modules;
 IF @HasAudit=1 AND COL_LENGTH(N'access.AuditEvent',N'EventHash') IS NOT NULL
 BEGIN
  EXEC sys.sp_executesql @AuditValidator;
  DELETE @Integrity;INSERT @Integrity EXEC access.usp_Audit_ValidateIntegrity;
  IF NOT EXISTS(SELECT 1 FROM @Integrity WHERE IsValid=1) THROW 51855,'La conversión no conserva la integridad de auditoría; se revierte.',1;
  IF @AuditEnabled=1 ENABLE TRIGGER access.tr_AuditEvent_AppendOnly ON access.AuditEvent;
 END;
 CREATE TABLE access.AppTimeConvention(Id int NOT NULL PRIMARY KEY CHECK(Id=1),Version int NOT NULL,TimeZoneName sysname NOT NULL,
  AppliedAt datetime2(7) NOT NULL DEFAULT access.ufn_AppNow());
 INSERT access.AppTimeConvention(Id,Version,TimeZoneName) VALUES(1,4,N'Central America Standard Time');
 IF OBJECT_ID(N'access.SecurityMonitoringVersion',N'U') IS NOT NULL EXEC(N'UPDATE access.SecurityMonitoringVersion SET Version=0;');
 COMMIT;
 PRINT N'Fechas convertidas a hora de Guatemala. Reaplicar 33 actualizado y validar con 99 antes de abrir clientes.';
 SELECT TableName,ColumnName,NewColumnName,ConvertedRows FROM access.AppTimeConversion ORDER BY TableName,ColumnName;
END TRY
BEGIN CATCH
 IF XACT_STATE()<>0 ROLLBACK;
 DECLARE @ConversionMessage nvarchar(2048)=ERROR_MESSAGE(),@ConversionNumber int=ERROR_NUMBER();
 RAISERROR(N'%s (error %d). No se completó la conversión del script 36.',16,1,@ConversionMessage,@ConversionNumber);
 SET NOEXEC ON;
END CATCH;
GO
CREATE OR ALTER PROCEDURE access.usp_App_TimeContext
AS
BEGIN
 SET NOCOUNT ON;EXEC access.usp_App_RequirePermission 'READ';
 SELECT Version,TimeZoneName FROM access.AppTimeConvention WHERE Id=1 AND Version=4;
END;
GO
GRANT EXECUTE ON access.usp_App_TimeContext TO SqlAccessAdmin_Users;
GO
SET NOEXEC OFF;
GO
