# Documentación de Proceso

**SQL Access Admin — El «Cómo se planificó»**

Fecha de elaboración: **17 de octubre de 2026**. Última revisión: **28 de octubre de 2026**. Perspectiva: gestión del proyecto y evolución del desarrollo con Codex.

Este documento reconstruye el proceso a partir del código, los scripts numerados, las guías y las comprobaciones disponibles en esta entrega. La copia revisada no contiene un repositorio Git consultable ni un registro formal de sprints, fechas de entrega o versiones publicadas. Por ello, los hitos se presentan según la secuencia de los insumos y las funcionalidades documentadas, sin asignar fechas ni números de versión retrospectivos.

Los scripts también han recibido correcciones posteriores: sus contenidos actuales no son fotografías inmutables de cada etapa. Los requerimientos de partida y las razones de diseño que siguen son una lectura retrospectiva del material conservado, no la transcripción de un acta inicial. La [Documentación Técnica](Documentación%20Técnica.md) describe la implementación actual; este archivo explica la necesidad que atendió cada evolución y sus consecuencias para el proyecto.

## Contenido

- [1. Resumen del proyecto y alcance](#1-resumen-del-proyecto).
- [2. Decisiones de diseño](#2-decisiones-de-diseño-clave).
- [3. Retos, soluciones y validación](#3-retos-y-soluciones).
- [4. Registro de cambios y alcance pendiente](#4-registro-de-cambios--changelog).
- [5. Criterios de entrega y mantenimiento documental](#5-criterios-de-entrega-y-mantenimiento-documental).

## 1. Resumen del Proyecto

### 1.1. Objetivo principal

SQL Access Admin centraliza la administración de accesos a distintas instancias de SQL Server mediante una aplicación de escritorio. Su propósito es convertir las altas de usuarios, modificaciones de permisos, copias de accesos y cambios de contraseña SQL en gestiones controladas, revisables y auditables. El alcance vigente incorpora reportes exportables, vigencias temporales y seguimiento de seguridad para revisar vencimientos y resultados que necesitan conciliación.

La base central `adminDB` mantiene el catálogo de servidores, las identidades autorizadas, las políticas, las solicitudes y la auditoría. Desde el cliente se selecciona una instancia de trabajo, se prepara una solicitud y se ejecutan los cambios autorizados sobre ese destino. Aunque el sistema administra varias instancias, cada solicitud vigente pertenece a un solo servidor.

El resultado esperado del proyecto es que cada gestión pueda responder qué se solicitó, para qué ticket, quién la creó, quién la confirmó, dónde se aplicó y cuál fue su resultado.

### 1.2. Requerimientos de partida reconstruidos

La estructura base y los primeros procedimientos permiten identificar las siguientes necesidades:

| Necesidad | Requerimiento identificado |
| --- | --- |
| Administración central | Mantener en `adminDB` las instancias administradas y su configuración de conexión. |
| Interfaz operativa | Ofrecer un cliente Windows para consultar servidores, bases, logins, usuarios y accesos. |
| Gestión de seguridad | Crear o mapear usuarios, asignar o retirar membresías y administrar los permisos admitidos. |
| Acceso al aplicativo | Registrar identidades autorizadas y distinguir funciones administrativas, operativas y de consulta. |
| Trazabilidad | Registrar actor, acción, destino, resultado y detalle de las operaciones. |
| Protección de conexiones | Contemplar autenticación Windows o SQL, cifrado de transporte y protección de credenciales. |
| Preparación del entorno | Entregar scripts SQL revisables por el DBA y un contrato de acceso a datos para el cliente. |

El proyecto pasó de esa base administrativa a un flujo de solicitudes con aprobación, ticket externo, planes compuestos, copia detallada, política por destino y roles acumulables. Después incorporó cambios de contraseña SQL, consultas/exportaciones, vigencias y seguimiento central de operaciones y metadatos. Estas capacidades corresponden a ampliaciones observables en los insumos y el código; no se atribuyen todas al alcance inicial.

### 1.3. Organización del alcance

La evolución puede agruparse en siete frentes de trabajo:

1. **Base operativa:** cliente WPF, conexión al pivote, catálogo de servidores, usuarios autorizados y auditoría.
2. **Control del cambio:** política de accesos, solicitudes, revisión, prevención de duplicados y ticket externo.
3. **Gestiones completas:** alta con accesos iniciales, edición compuesta, contraseña temporal y copia por base.
4. **Política y contexto:** autenticación SQL/Windows, activaciones especiales, descubrimiento y herencia por instancia y base.
5. **Consolidación:** identidad estricta, separación de funciones, selección de cuentas existentes y ajustes de experiencia de uso.
6. **Consulta y credenciales:** seis reportes PDF/CSV/Excel, inventario por instancia, detalle de herencia de roles, cambio controlado de contraseña SQL y antigüedad con fechas confirmadas.
7. **Seguimiento operativo:** vigencias, alertas persistentes, evidencia por comando, referencias de metadatos, worker opcional y hora única de Guatemala.

Esta agrupación sirve para explicar dependencias y prioridades; no representa un calendario de sprints registrado.

## 2. Decisiones de Diseño Clave

Las razones de esta sección se deducen de los problemas atendidos y de la estructura implementada. No se conserva una evaluación formal de alternativas ni evidencia suficiente para afirmar que se compararon productos concretos antes de elegirlos.

### 2.1. Cliente Windows con C#, .NET 8 y WPF

Se mantuvo un cliente de escritorio con destino `net8.0-windows`. WPF permite organizar formularios, tablas, ventanas de confirmación y asistentes mediante XAML y enlaces de datos. C# reúne en un mismo proyecto la lógica de interfaz, las conexiones SQL y las funciones criptográficas utilizadas.

La elección es coherente con una herramienta administrativa que se ejecuta en Windows y utiliza autenticación integrada. Su consecuencia es que la entrega requiere un entorno Windows compatible; el proyecto no implementa un cliente web ni multiplataforma.

Evidencia: [proyecto de aplicación](../../src/SqlAccessAdmin/SqlAccessAdmin.csproj) y [vistas](../../src/SqlAccessAdmin/Views/).

### 2.2. Organización MVVM y servicios separados

Las vistas presentan la información; los ViewModels mantienen borradores, comandos, navegación y estados de validación; los modelos representan contratos y planes. El acceso a datos se concentra en componentes como `AdminDbGateway` y `DirectSqlServerService`, con interfaces para determinadas dependencias de política y usuarios autorizados.

Esta distribución permite comprobar reglas y estados del formulario con datos simulados, y cambiar una interacción sin duplicar toda la lógica SQL. Se conserva code-behind para comportamientos propios de los controles y ventanas. El crecimiento también dio lugar a ViewModels especializados para el asistente de alta, la copia, las cuentas autorizadas y el estado del login.

Evidencia: [ViewModels](../../src/SqlAccessAdmin/ViewModels/), [servicios de datos](../../src/SqlAccessAdmin/Data/) y comprobaciones vigentes de [contraseñas](../../tests/LoginPasswordChecks/README.md), [reportes](../../tests/ReportsChecks/README.md) y [seguimiento de seguridad](../../tests/SecurityMonitoringChecks/README.md).

### 2.3. Pivote central y conexiones directas a los destinos

`adminDB` actúa como punto de gobierno y registro. El cliente obtiene de allí la configuración autorizada y abre conexiones TLS directas a las instancias administradas. El script `08` recoge la transición de instalaciones anteriores a este modelo, que elimina la necesidad de linked servers.

La decisión permite mantener las reglas y el historial en un lugar, mientras las consultas de catálogo y los cambios se ejecutan contra el servidor seleccionado. A cambio, cada equipo cliente necesita conectividad hacia el pivote y los destinos, y la cuenta técnica debe disponer de los permisos SQL necesarios.

Evidencia: [guía de infraestructura](../README.md), [script 08](../08_ConfigurarConexionDirectaYCifrado.sql) y [servicio directo](../../src/SqlAccessAdmin/Data/DirectSqlServerService.cs).

### 2.4. Contratos explícitos y preparación manual de infraestructura

El gateway del pivote utiliza procedimientos almacenados y parámetros tipados mediante `Microsoft.Data.SqlClient`. En los destinos se emplean también consultas de catálogo y sentencias T-SQL para operaciones admitidas, con valores parametrizados e identificadores validados y delimitados.

La instalación se mantiene como una actividad del DBA: el cliente no crea `adminDB` ni aplica migraciones. Los scripts numerados hacen revisables los cambios de estructura y los contratos; el esquema `access` agrupa los objetos de la aplicación y el validador `99` comprueba la instalación resultante.

Esta separación exige coordinar el despliegue del cliente con los scripts correspondientes. Evita que abrir una nueva versión de la interfaz modifique por sí mismo la infraestructura.

Evidencia: [gateway](../../src/SqlAccessAdmin/Data/AdminDbGateway.cs), [migración al esquema access](../20_MigrarObjetosAlEsquemaAccess.sql) y [validador de instalación](../99_ValidarInstalacion.sql).

### 2.5. Solicitudes y planes persistidos antes de ejecutar

La gestión evolucionó hacia tres momentos explícitos: preparar y enviar, revisar y confirmar, ejecutar. La persistencia separa cabecera, destinos y pasos mediante `AccessRequest`, `AccessRequestTarget` y `AccessRequestStep`. Los parámetros tabulares permiten enviar conjuntos de cambios y el plan JSON de copia conserva el detalle revisado por base.

La razón funcional es que una gestión completa pueda revisarse como una unidad: crear un login, mapear usuarios y asignar accesos no debe exigir reconstruir su intención a partir de operaciones aisladas. En la copia, una huella SHA-256 permite detectar que el origen o el plan ya no coinciden con lo aprobado.

La revisión es una etapa separada, pero no impone dos personas distintas: un Administrador o una identidad con Operador y AprobadorEjecutor puede procesar sus propias solicitudes.

Evidencia: [script 19](../19_SolicitudCompuestaYContrasenaTemporal.sql), [script 21](../21_SolicitudUnicaCambiosAcceso.sql), [script 23](../23_DetalleCopiaPermisosPorBase.sql) y [modelos de copia](../../src/SqlAccessAdmin/Models/PermissionCopyModels.cs).

### 2.6. Política por contexto y autorización por funciones

Una política exclusivamente global resultó insuficiente para representar diferencias entre servidores y bases. La solución vigente resuelve reglas con prioridad **Base → Instancia → General**, consulta los catálogos reales y exige revisión de roles personalizados en su destino.

En paralelo, la autorización del aplicativo pasó de un rol principal a membresías múltiples. `AuthorizedPrincipalRole` permite acumular funciones y separar creación de solicitudes de confirmación y ejecución. El rol principal anterior se conserva por compatibilidad, pero ya no representa por sí solo los permisos efectivos.

Los controles se aplican en la interfaz y en los procedimientos, y se revalidan durante el ciclo de la solicitud. La disponibilidad de una opción depende de su contexto, su política y los permisos efectivos de la cuenta técnica.

Evidencia: [política por destino](../../docs/PoliticaAccesoPorDestino.md), [script 27](../27_PoliticaAccesoPorInstanciaYBase.sql) y [roles múltiples](../30_RolesMultiplesYSeparacionSolicitudes.sql).

### 2.7. Secretos cifrados y auditoría con integridad comprobable

Las credenciales SQL y las contraseñas temporales se conservan como sobres AES-256-GCM. La clave central se guarda envuelta mediante una clave AES-256 protegida por certificado y Database Master Key de SQL Server. Esto permite conservar el secreto necesario para una ejecución posterior sin guardarlo como texto plano en las tablas.

La auditoría incorpora una cadena hash y un trigger que impide modificaciones y eliminaciones ordinarias. Su objetivo es aportar evidencia comprobable sobre las gestiones; su integridad sigue dependiendo de la administración de SQL Server y de los respaldos. El código actual no integra DPAPI, HSM ni un gestor externo de secretos.

Evidencia: [protector criptográfico](../../src/SqlAccessAdmin/Security/AesGcmCredentialProtector.cs) y [script 10](../10_PoliticaSolicitudesEIntegridad.sql).

### 2.8. Reportes con fuentes y autorizaciones diferenciadas

La consulta de configuración utiliza cuatro reportes directos: **Permisos por usuario**, **Permisos por instancia**, **Catálogo de roles** e **Inactividad de credenciales**. Los reportes centrales **Cambios de accesos** y **Cambios de contraseña** se alimentan del pivote. Los seis son exportables. Esta separación permite que Auditor consulte el seguimiento y exporte resultados sin recibir credenciales compartidas de los destinos.

El inventario por instancia permite revisar cuentas con y sin asignaciones, incluidas deshabilitadas y sysadmin, conservando login y usuario mapeado. Sus consultas por contexto se realizan en bloque; una diferencia de nombres/SID entre lotes o un fallo de base invalida el resultado. Así, ampliar la consulta a todas las cuentas no depende de repetir el reporte individual por cada login. Esta ampliación no requiere una migración nueva ni cambia el alcance operativo de las solicitudes.

El catálogo de roles incorpora permisos directos/heredados, dirección de membresías, capacidades fijas y miembros directos. Las capacidades incorporadas se explican aunque no aparezcan como permisos explícitos. La lectura evita ciclos y rutas repetidas. Conservar estos conceptos separados permite interpretar mejor un rol sin atribuirle privilegios por su nombre ni presentar su detalle como el acceso efectivo de una persona.

Las exportaciones conservan contexto, filtros y orden. PDF, CSV y Excel se generan localmente sin automatizar Office. El reporte de credenciales incluye cuentas SQL/Windows y fechas desconocidas: una ausencia de fecha no prueba inactividad. El complemento 37 toma el último cambio confirmado por servidor y SID para complementar una propiedad del motor no disponible o desactualizada.

Evidencia: [servicio de reportes](../../src/SqlAccessAdmin/Data/ReportsService.cs), [consultas por instancia](../../src/SqlAccessAdmin/Data/InstanceReportsSql.cs), [herencia y árbol de roles](../../src/SqlAccessAdmin/Models/RoleCatalogDetails.cs), [exportación](../../src/SqlAccessAdmin/Data/ReportExportService.cs) y [script 37](../37_FechasContrasenaConfirmadas.sql).

### 2.9. Vigencias con revisión humana y alertas persistentes

La vigencia identifica una cuenta, usuario o recurso nuevo y su fecha de revisión. Al vencer se conserva el acceso y se crea una alerta; el sistema exige una extensión o un cierre solicitado con ticket, confirmado y ejecutado por Administrador. No convierte accesos permanentes previos en temporales.

La decisión mantiene una revisión explícita antes de deshabilitar un login, eliminar un usuario, retirar un permiso o una membresía. También introduce una responsabilidad operativa: un vencimiento requiere atención y no acredita por sí solo la retirada del acceso. Las alertas sobreviven al reinicio y solo se resuelven cuando termina satisfactoriamente la acción correspondiente.

Evidencia: [gestión de temporales](../../src/SqlAccessAdmin/ViewModels/TemporaryAccessViewModel.cs) y [contrato central 33](../33_MonitoreoSeguridadYTemporales.sql).

### 2.10. Operaciones confirmadas y referencias externas de metadatos

El seguimiento vigente registra en el pivote un intento y cada comando tipado antes de enviarlo al destino. Solo acredita el resultado después de la respuesta satisfactoria o del COMMIT. Una confirmación repetida no duplica el conteo y un intento reservado no se ejecuta otra vez automáticamente. La falta de confirmación suficiente exige conciliación.

En paralelo, se consultan las últimas fechas de modificación y contraseña por instancia, ámbito y SID. La primera consulta establece una referencia inicial. Una diferencia sin operación confirmada coincidente se muestra como Externo, sin atribuir actor o herramienta. No permite reconstruir intervenciones intermedias ni garantiza detectar cada cambio de permiso.

Este diseño evita instalar captura en los destinos. Los ejemplos de captura antiguos permanecen archivados fuera del despliegue vigente; no describen la arquitectura actual. El costo operativo incluye consultas periódicas de catálogos y depende de la conectividad y visibilidad disponibles. Un worker opcional mantiene los ciclos cuando WPF está cerrado.

Evidencia: [instrumentación de ejecución](../../src/SqlAccessAdmin/Data/ExecutionEvidenceScope.cs), [recolección de metadatos](../../src/SqlAccessAdmin/Data/PrincipalMetadataCollector.cs) y [guía de seguimiento](../../docs/MonitoreoSeguridad.md).

### 2.11. Una sola convención horaria para operar y contar

La entrega usa hora local de Guatemala para fechas estructuradas, vencimientos, historial y días de los contadores. El script 36 convierte fechas históricas una sola vez y conserva la base binaria utilizada para verificar los hashes de auditoría anteriores. El marcador de conversión impide desplazar los registros otra vez.

La dependencia exige aplicar 36 antes de 33 v4, aunque su número sea mayor. Para completar esta entrega, el cierre de instalación es **32 → 36 → 33 v4 → 37 → 99**, con respaldo, cliente/worker detenidos y reinicio posterior. No se deben reaplicar 01–32 sobre la base ya convertida.

Evidencia: [convención horaria](../../docs/HoraLocalGuatemala.md) y [script 36](../36_HoraLocalGuatemala.sql).

## 3. Retos y Soluciones

### 3.1. Principales problemas atendidos durante las iteraciones

La tabla reúne retos que tienen una corrección o un control identificable en los archivos. No atribuye conversaciones, incidentes de producción ni resultados de pruebas que no estén registrados.

| Reto | Solución incorporada | Consecuencia para el proceso |
| --- | --- | --- |
| Delimitar el destino de una gestión en una herramienta que administra varias instancias. | El script `13` restringió cada solicitud a un único servidor y alineó su consulta y ejecución. | La instancia de trabajo pasa a ser parte obligatoria del contexto del formulario. |
| Evitar que gestionar membresías permita alterar la definición de roles SQL. | El script `11` cerró la ruta histórica de modificación; las evoluciones posteriores permiten catalogar y autorizar roles existentes, sin editar su definición SQL. | Se distingue entre política del aplicativo, membresía del usuario y definición del rol en SQL Server. |
| Solicitudes repetidas o fragmentadas que dificultaban revisar una gestión completa. | `15` incorporó detección transaccional de duplicados; `19` y `21` reunieron los pasos relacionados en un plan y ampliaron su comparación. | La unidad de revisión es la solicitud completa con sus destinos y cambios. |
| Conservar una contraseña hasta que otra etapa ejecute el alta SQL. | `19` añadió el secreto temporal cifrado y las opciones de política, expiración y cambio en el primer inicio de sesión. | Se puede separar preparación de ejecución sin persistir la contraseña en texto plano. |
| Que la copia otorgue algo diferente de lo revisado o mezcle accesos entre bases. | `22` y `23` incorporaron plan detallado por base, usuario origen específico, exclusiones y huella; el origen y la política se vuelven a comprobar. | Un cambio del origen invalida la copia. DENY o excepciones REVOKE bloquean la gestión; no se copia delegación ni roles de servidor. |
| Confundir una cuenta Windows válida con un login ya presente en SQL Server. | `24` separó SQL/Windows; el cliente comprueba nombres con `xp_logininfo`, exige retorno entero `0` y vincula el resultado al servidor y la identidad. | Una cuenta válida sin filas de accesos SQL puede aceptarse. Cambiar el contexto invalida la comprobación y descarta respuestas tardías. |
| Aplicar las mismas reglas a destinos con necesidades o versiones diferentes. | `25` y `26` reforzaron autorizaciones especiales; `27` añadió herencia, descubrimiento y reglas por instancia/base. | Las excepciones se autorizan en su contexto y se revalidan al crear, confirmar y ejecutar. |
| Errores de intercalación y comparaciones de catálogo durante la evolución de política. | La corrección documentada de `27` normalizó comparaciones con `DATABASE_DEFAULT` y mantuvo creación e importación repetibles. | La guía exige revisar todos los errores entre lotes y usar `99`; un mensaje final aislado no demuestra instalación correcta. |
| Contrato insuficiente para nombres de permisos y clasificación de CREDENTIAL. | `27` amplió los nombres a 128 caracteres y versionó el tipo tabular de pasos; `28` registró CREDENTIAL como ámbito de instancia. | Se conserva la información y se coordina el contrato del cliente con SQL, en lugar de filtrar permisos que no caben. |
| Tickets con formato plausible que no acreditaban una gestión externa válida. | El contrato actualizado de `27` consulta `dbo.sp_VerificarTicketExiste`, verifica el identificador completo y toma DESCRIPCION o ASUNTO como motivo oficial. | El cliente bloquea el formulario hasta validar y SQL comprueba nuevamente el ticket al crear la solicitud. La revalidación del ticket al confirmar y ejecutar sigue pendiente. |
| Alias MicrosoftAccount y privilegios sysadmin que no representaban la autorización explícita deseada. | `29` resolvió el nombre canónico desde el SID original y exigió registro activo; un alias activo no elude una baja canónica. | La conexión técnica a SQL Server y el derecho a entrar en la aplicación se validan por separado. |
| Separar creación y procesamiento sin perder combinaciones legítimas de funciones. | `30` incorporó cuatro roles acumulables, contrato de autorización v2 y controles funcionales en cliente y SP. | Operador no recibe aprobación automáticamente; cambiar membresías bloquea la sesión en su siguiente operación contra el pivote. |
| Altas de usuarios autorizados con nombres inexistentes o estado desactualizado. | `31` sustituyó el texto libre por selección de cuentas Windows individuales o SQL existentes y habilitadas; cliente y SP revalidan al guardar. | El tipo se obtiene del catálogo y las cuentas ya registradas se modifican o reactivan desde la tabla. |
| Transformar definiciones de SP sin corromper encabezados, literales o bloques. | Las comprobaciones SQL de `29` y `30` cubren variantes de encabezado, comentarios, bloques e idempotencia, capturando las transformaciones sin ejecutar DDL. | Se revisa la transformación sobre casos representativos antes de aplicar manualmente la migración. |
| Formularios extensos y borradores que podían perder contexto. | El asistente separó cuenta, mapeo y objetos; mantuvo opciones independientes, navegación con borrador y confirmación de descarte. También se añadieron filtros y permisos según tipo de función. | Los pasos visibles corresponden a las opciones elegidas y se evita enviar selecciones ocultas o de otra base. |
| Confusión entre baja de cuenta, cambio de permisos y cierre de sesión. | La interfaz muestra una única acción Habilitar/Deshabilitar según el estado real, genera una solicitud independiente y revalida el estado; el cierre termina ventanas y libera pools. | Deshabilitar impide nuevas conexiones del login, conserva permisos y no termina sesiones SQL existentes. El cierre del aplicativo respeta la confirmación de cambios pendientes. |
| Cambiar una contraseña existente con la misma trazabilidad de una gestión de acceso. | `32` incorpora `CHANGE_LOGIN_PASSWORD`, secreto cifrado, opciones compatibles y revisión separada. | Solo aplica a logins SQL administrables; la solicitud no mezcla permisos del borrador. |
| Considerar un vencimiento como baja automática o afectar permisos permanentes previos. | `33` sigue recursos nuevos y exige extensión/cierre administrativo ejecutado. | El vencimiento mantiene acceso y alerta hasta resolver la gestión; el cierre tiene alcance por recurso. |
| Duplicar conteos o repetir un comando cuyo resultado se perdió. | Reserva persistente del intento, comandos antes del envío y confirmaciones idempotentes después del resultado/COMMIT. | Pendientes e inciertos no suman; se revisa el destino antes de repetir una gestión. |
| Confundir una fecha externa con un historial completo o un actor conocido. | Referencia inicial por SID y última diferencia de metadatos separada de los comandos confirmados. | Externo conserva la limitación de evidencia; no se inventan detalles, usuarios ni cantidades. |
| Alertas de contraseña perdidas al reiniciar o duplicadas por reentrega. | Conteo por instancia/SID/día de Guatemala, umbral de tres cambios confirmados y revisión persistida. | Atender una alerta conserva contador e historial; un cambio nuevo puede generar otra alerta. |
| Mezclar UTC y hora local o invalidar auditoría al convertirla. | `36` convierte fechas, protege contra doble conversión y conserva `HashDateBasis`. | Las horas visibles y el día del contador son consistentes, con verificación de la cadena histórica. |
| Mostrar antigüedad incorrecta cuando falta una fecha válida del motor. | `37` complementa el reporte con cambios confirmados por SID; mantiene separada la modificación del login. | Un cambio confirmado hoy muestra 0 días; fechas desconocidas y Windows/AD se identifican explícitamente. |
| Revisar toda una instancia sin omitir cuentas que no tienen asignaciones. | Permisos por instancia conserva un inventario independiente y consulta roles, permisos y mapeos en bloque por contexto. | Las cuentas sin filas de permisos siguen visibles; un fallo de base o cambio de identidades impide publicar un conjunto incompleto. |
| Interpretar un rol solo por su nombre o por los permisos explícitos visibles. | El catálogo muestra permisos directos/heredados, capacidades fijas y miembros, con recorrido de padres y control de ciclos. | Un rol fijo sin filas explícitas puede tener capacidades; los roles miembros no se confunden con fuentes de herencia. |
| Exportar un detalle diferente de lo consultado o perder cuentas sin permisos. | Los reportes de permisos permiten elegir reporte completo/pestaña; instancia añade inventario y roles añade secciones de herencia/capacidades y miembros opcionales. | Los archivos conservan contexto, filtros y orden, con selección explícita de miembros y cuentas sin asignaciones en la exportación completa de instancia. |

### 3.2. Forma de trabajo con Codex reflejada en la entrega

La evidencia disponible muestra una evolución que conecta comportamiento de pantalla, reglas del ViewModel, contrato SQL, comprobaciones y documentación. No se conserva la conversación completa de programación; por tanto, no es posible enumerar cada instrucción dada a Codex ni asignar autoría individual a todos los cambios.

Desde la gestión del proyecto, el ciclo de trabajo que puede reconstruirse es:

1. **Concretar el comportamiento:** definir el actor, el destino, los datos necesarios y los casos que deben bloquear el envío.
2. **Revisar el contrato afectado:** determinar si basta con actualizar el cliente o si hacen falta tablas, tipos, procedimientos o migraciones.
3. **Implementar la gestión completa:** conectar captura, validación, confirmación, ejecución y consulta del resultado.
4. **Comprobar casos relevantes:** usar dobles en memoria para reglas y planes, controles WPF para enlaces y estados, y comprobaciones SQL para los contratos que lo requieren.
5. **Preparar la entrega:** actualizar las guías, indicar el orden de instalación y distinguir las comprobaciones locales de las pruebas pendientes con infraestructura real.

Los ajustes de asistente, funciones, estado del login y cierre muestran que una iteración de interfaz puede reutilizar el contrato existente. Los cambios de política, identidad y membresías, en cambio, requieren una entrega coordinada de cliente y SQL.

### 3.3. Estrategia de validación y límites de la evidencia

La entrega conserva los siguientes grupos de comprobaciones:

- **Cambio de contraseña:** ticket, roles, tipo de login, complejidad, opciones, envío y revisión sin secreto; comprobación de transformaciones SQL mediante ScriptDom y variantes de encabezados. Los escenarios de ViewModel usan datos simulados.
- **Reportes:** contexto, filtros, cancelación, respuestas tardías, controles WPF y exportaciones PDF/CSV/XLSX. Incluye el inventario por instancia, clasificación por sysadmin, alias, cuentas sin asignaciones, cuatro secciones y exportación por pestaña. El catálogo cubre herencia, dirección de membresías, ciclos, capacidades fijas y miembros opcionales. El modo SQL opcional consulta catálogos de solo lectura; no aplica migraciones.
- **Seguimiento y temporales:** vigencias, umbral de alertas, revisión, roles, filtros, exportaciones y sintaxis SQL. El laboratorio aislado crea recursos aleatorios de prueba para comprobar comandos reales, confirmación/rollback, idempotencia, referencias externas, SID y conversión horaria con integridad de auditoría.

Las pruebas con identidades Windows reales, conectividad, certificados, permisos técnicos, tickets y ejecución en varias bases corresponden a la integración del entorno. Las guías mantienen escenarios para verificarlas antes de producción.

Esta revisión documental contrasta los archivos con el código y los contratos actuales. La cobertura descrita corresponde a las comprobaciones disponibles; no acredita una ejecución nueva de esas pruebas ni una certificación del entorno. Actualizar estas guías no aplica migraciones ni cambia accesos en SQL Server.

Referencias: [contraseñas](../../tests/LoginPasswordChecks/README.md), [reportes](../../tests/ReportsChecks/README.md), [seguimiento y laboratorio SQL](../../tests/SecurityMonitoringChecks/README.md) y [guía de instalación](../README.md).

## 4. Registro de Cambios — Changelog

### 4.1. Hitos principales reconstruidos

La numeración corresponde a los **scripts de infraestructura**, no a versiones semánticas del producto ni a fechas de publicación. Las filas resumen la evolución funcional; el orden de instalación y las condiciones para actualizar un entorno existente se consultan en [InsumosProduccion/README.md](../README.md).

| Hito / referencia | Cambio principal | Resultado para el proyecto |
| --- | --- | --- |
| Base — `00` a `05` | Preparación de `adminDB`, esquema, consultas, operaciones, roles SQL y datos iniciales. Cliente WPF y catálogo central. | Base funcional para administrar destinos y registrar operaciones. |
| Ajuste de identidad — `07` | Corrección histórica del contexto de login; su contenido actual ya incorpora acceso estricto y remite a `29`. | Evidencia de evolución del inicio de sesión; no debe interpretarse como el diseño final aislado. |
| Conectividad y nombres — `08` y `09` | Preparación de conexiones directas, cifrado y migración de nombres heredados de roles SQL. | Consolidación de la comunicación cliente–destino y de la nomenclatura de infraestructura. |
| Gobierno inicial — `10` | Allowlist, denylist, solicitudes, aprobación y cadena hash de auditoría. | El cambio de acceso obtiene política, revisión y evidencia persistida. |
| Reducción del alcance operativo — `11` a `14` | Bloqueo de modificación de roles, simplificación de accesos, servidor único y mapeo controlado a base. | Menor ambigüedad sobre qué puede cambiarse y dónde. |
| Duplicados y autoconfirmación — `15` y `16` | Prevención de solicitudes equivalentes y habilitación del doble check de gestiones propias. | Menos trabajo repetido y revisión explícita; `30` introduce después la separación funcional vigente. |
| Administración de política — `17` | Habilitación o bloqueo de permisos y roles asignables. | Se configura qué accesos pueden solicitarse sin editar la definición de los roles SQL. |
| Ticket externo — `18` | Ticket obligatorio en solicitudes, revisión e historial. | Vínculo con la gestión externa; `27` actualizado sustituye la validación de formato por consulta real. |
| Alta compuesta — `19` | Login, usuario de base, roles y permisos en una solicitud, con contraseña temporal cifrada para SQL. | El alta representa una gestión completa y ejecutable después de revisarse. |
| Ordenamiento de objetos — `20` | Migración de objetos de instalaciones anteriores al esquema `access`. | Contratos agrupados con conservación de datos y permisos. |
| Edición compuesta — `21` | Solicitud única para cambios de membresías y permisos; comparación del plan completo. | Confirmación del conjunto de cambios y detección más precisa de duplicados. |
| Copia de accesos — `22` y `23` | Copia a login nuevo, huella del origen y desglose persistido por base. | Revisión e historial del plan exacto; copias antiguas sin detalle deben regenerarse para procesarse. |
| Autenticación del alta — `24` | Elección exclusiva SQL/Windows y contratos compatibles con cada tipo. | Contraseña temporal solo para SQL y validación de cuentas Windows existentes. |
| Excepciones controladas — `25` y `26` | Activación especial auditada y validación compartida para roles y permisos protegidos. | Tratamiento consistente de opciones sensibles en solicitudes, copia y ejecución. |
| Política contextual e integración — `27` y `28` | Herencia General/Instancia/Base, descubrimiento, catálogo ampliado, acciones por destino, tickets reales y corrección de CREDENTIAL. | Reglas adaptadas al destino y validación más precisa del contexto de la gestión. |
| Identidad estricta — `29` | Registro activo obligatorio incluso para sysadmin, SID original y mantenimiento de usuarios autorizados. | La autorización de aplicación deja de depender de privilegios SQL elevados o alias ambiguos. |
| Roles acumulables — `30` | Administrador, Operador, AprobadorEjecutor y Auditor; membresías múltiples y autorización v2. | Separación entre crear y procesar solicitudes, con combinaciones explícitas de funciones. |
| Altas desde catálogo — `31` | Selección de logins reales y habilitados, tipo automático y revalidación al guardar. | Menos errores de registro y rechazo de cuentas retiradas o deshabilitadas durante la edición. |
| Cambio de contraseña — `32` | Operación de instancia para login SQL existente, secreto cifrado y opciones de contraseña. | Ciclo solicitar/confirmar/ejecutar con ticket y detalle sin secreto. |
| Reportes de configuración | Permisos por usuario multibase, catálogo de roles y antigüedad de credenciales; exportación PDF/CSV/Excel. | Consulta separada de las operaciones, con filtros, contexto y alcance explícitos. |
| Inventario por instancia | Nuevo reporte directo con cuentas, roles, permisos y bases revisadas; consultas en bloque y controles por SID. | El menú alcanza seis reportes: cuatro directos y dos centrales; incluye cuentas sin asignaciones y exportación completa o por pestaña, sin migración propia. |
| Detalle del catálogo de roles | Árbol de permisos directos/heredados, capacidades fijas y miembros directos; exportación por secciones. | La consulta y los archivos conservan origen y acción SQL, con miembros opcionales y sin confundir asignaciones con acceso efectivo total. |
| Seguimiento y temporales — `33` vigente v4 | Vigencias, extensiones/cierres, alertas, comandos registrados y comparación de metadatos; dos reportes centrales y worker opcional. | Seguimiento desde el pivote sin captura instalada en destinos; incertidumbres visibles para conciliación. |
| Hora de Guatemala — `36` | Conversión protegida de fechas históricas y contratos, manteniendo hashes originales. | Fechas coherentes en interfaz, persistencia y conteos diarios; se aplica antes del 33 vigente. |
| Fechas confirmadas — `37` | Consulta del último cambio de contraseña confirmado por servidor y SID. | Complemento del reporte de credenciales sin modificar cuentas ni contraseñas. |
| Comprobación de infraestructura — `99` | Validador actualizado para autorización, contraseñas, monitoreo v4, hora local y complemento de fechas. | Comprobación final tras los scripts aplicables; su numeración no representa una versión del producto. |

### 4.2. Mejoras del cliente sin una nueva migración propia

Las siguientes capacidades están documentadas en el estado actual. No hay evidencia suficiente para fecharlas ni fijar un orden exacto entre ellas:

- **Asistente de creación:** opciones independientes de mapeo y objetos, navegación que conserva el borrador y numeración según los pasos habilitados.
- **Funciones definidas por el usuario:** filtro por tipo y selección de `EXECUTE` para escalares o `SELECT` para tabulares, sujeta a política.
- **Validación Windows:** comprobación ligada a identidad y servidor, tratamiento del retorno de `xp_logininfo` y descarte de respuestas tardías.
- **Política más legible:** búsqueda en descripciones, explicación de permisos y roles, edición de descripciones administrativas de roles personalizados y exclusión de nombres internos con `##`.
- **Estado del login:** acción única según estado, ticket validado, solicitud independiente y comprobación antes de ejecutar.
- **Cierre de sesión:** terminación de ventanas, liberación de pools SQL y tratamiento de borradores pendientes.
- **Consulta multibase:** selección y búsqueda de logins/bases, tres pestañas de permisos y alcance de exportación completo o por pestaña; no amplía el contrato operativo multibase.
- **Consulta por instancia:** inventario de logins, roles, permisos y cobertura por login/base, con filtro común y clasificación por sysadmin; incluye las cuatro pestañas y no requiere una selección de login.
- **Catálogo exportable:** permisos directos/heredados, roles de origen, capacidades fijas y selección explícita de roles para añadir miembros; generación de archivos sin Office instalado.
- **Alertas en Resumen:** contadores y ventana de detalle con búsqueda, filtros y revisión motivada; la lógica persistente requiere el contrato 33 vigente.

Estas mejoras reutilizan los contratos instalados que les corresponden; la ausencia de una migración nueva para el ajuste no elimina sus prerrequisitos de infraestructura.

### 4.3. Alcance pendiente identificado

El análisis de [viabilidad multibase](../../docs/ViabilidadPermisosMultibase.md) propone que cada paso guarde su propia base, con contratos versionados, ejecución filtrada y seguimiento por destino. Esa ampliación **no está implementada**: las solicitudes ordinarias con permisos de objeto, esquema o columna siguen limitadas a una sola base. La copia dispone de un plan específico por base y no debe confundirse con esa ampliación del alta o la edición ordinaria.

La validación real del ticket se realiza en la interfaz y al crear la solicitud. Volver a comprobar su vigencia al confirmar y ejecutar figura como decisión pendiente en el material de seguimiento; la revalidación de política en esas etapas no implica una nueva consulta del ticket.

Tampoco existe una transacción global entre pivote y destinos. La copia y determinados cambios agrupan trabajo por base, pero un login creado o una base completada pueden permanecer si otro destino falla. La conciliación de resultados inciertos y la revisión antes de reintentar forman parte de la operación; no se presenta la atomicidad global como una capacidad entregada.

El seguimiento actual conserva comandos confirmados y últimas referencias de metadatos; no entrega un historial completo de todas las intervenciones externas. Tampoco ofrece una cola local de recuperación o reejecución automática de intentos reservados. La operación debe prever conciliación y atención de alertas, además de un worker autorizado si se necesita continuar los ciclos con el cliente cerrado.

Los diseños de captura en `docs/propuestas` y `docs/archive/monitoring-v2` son material histórico. No son módulos pendientes que deban instalarse para completar esta entrega, ni reemplazan el contrato central v4.

Para mantener esta historia en futuras entregas, cada hito debe incorporar su fecha real, referencia de cambio, alcance, scripts requeridos y validación efectivamente realizada. El changelog actual conserva únicamente la secuencia que puede sostenerse con los archivos disponibles.

## 5. Criterios de entrega y mantenimiento documental

### 5.1. Criterios funcionales para revisar una entrega

La siguiente matriz organiza la aceptación en un entorno de pruebas. Describe qué debe verificarse; no constituye un resultado de pruebas ejecutadas durante esta revisión documental.

| Frente | Comportamiento que se debe verificar | Guía para la revisión |
| --- | --- | --- |
| Ingreso y roles | Cuenta activa registrada, roles acumulables y bloqueo al perder autorización; sysadmin no elude el registro. | Usuario 2 y 3.1; Técnica 3.2; guía de usuarios autorizados. |
| Servidores y conexiones | Alta/edición, prueba de conexión, TLS, estado activo y conservación de contraseña al editar. | Usuario 3.10; Técnica 3.3 y 4.1. |
| Alta y modificación | Ticket real, asistente SQL/Windows, comprobación de cuenta, cambios compuestos y política vigente. | Usuario 3.3–3.5; Técnica 3.5–3.7. |
| Copia y estado del login | Plan por base, revisión de exclusiones/huella y solicitudes independientes para habilitar/deshabilitar. | Usuario 3.6 y 3.8; Técnica 3.7. |
| Confirmación y ejecución | Roles correctos, transiciones, resultado por destino, duplicados y conciliación de incertidumbres. | Usuario 3.7 y 3.9; Técnica 3.5 y 3.10. |
| Política y usuarios autorizados | Herencia por destino, acciones independientes, activación especial, guardados y restricciones administrativas. | Usuario 3.11–3.12; Técnica 3.2 y 3.6. |
| Cuatro reportes directos | Contextos, filtros, cuentas sin asignaciones, SID/alias, herencia de roles, fechas y rechazo de resultados parciales. | Usuario 3.14; Técnica 3.8; ReportsChecks. |
| Dos reportes centrales | Período local, ranking/historial, límites y separación de operaciones confirmadas, inciertas y referencias externas. | Usuario 3.14; Técnica 3.8 y 3.10. |
| Exportación | PDF/CSV/Excel, filtros y orden, reporte completo/pestaña, miembros opcionales y preservación del archivo anterior ante fallo de generación. | Usuario 3.14; Técnica 3.8; ReportsChecks y SecurityMonitoringChecks. |
| Contraseñas | Secreto cifrado, opciones compatibles, revisión sin secreto y fecha confirmada vinculada al SID. | Usuario 3.15; Técnica 3.9; LoginPasswordChecks. |
| Vigencias y alertas | Vencer conserva acceso, extensión/cierre administrativo, umbral diario y revisión persistente. | Usuario 3.16–3.17; Técnica 3.11. |
| Infraestructura y operación | Orden de migraciones, 99, integridad de auditoría, hora local y worker con identidad/permisos adecuados. | Técnica 4; guía de insumos y SecurityMonitoringChecks. |

Las referencias y los requisitos de cada comprobación están enlazados en la [Documentación Técnica](Documentación%20Técnica.md). Los escenarios con infraestructura real se realizan con cuentas de laboratorio y permisos autorizados por el DBA.

### 5.2. Revisión documental del 28 de octubre de 2026

Se contrastaron las guías con la navegación WPF, los modelos de autorización, los servicios de reportes, el árbol de roles, las opciones de exportación y los contratos SQL disponibles. Se actualizó el inventario a seis reportes, se incorporó Permisos por instancia en las tres perspectivas y se amplió la explicación de herencia, miembros y exportaciones. El [índice de documentación](README.md) relaciona cada capacidad con su guía.

Esta fecha corresponde a la revisión de documentación. No fija la fecha de lanzamiento de las funciones ni acredita una aplicación de migraciones o una ejecución nueva de las pruebas funcionales.

Para futuras actualizaciones, revisar conjuntamente: comportamiento visible y roles en la guía de usuario; componentes, contratos y despliegue en la guía técnica; decisiones, cobertura y límites en la guía de proceso. Un cambio en el número de reportes, en una autorización o en los prerrequisitos debe reflejarse en los tres archivos y en el índice. La documentación debe distinguir capacidades implementadas, análisis pendientes y material histórico.
