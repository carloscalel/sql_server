# Documentación de SQL Access Admin

Revisión documental: **28 de octubre de 2026**, hora de Guatemala. Alcance contrastado con el código y los insumos de esta carpeta de proyecto.

## Elegir una guía

| Documento | Destinatario | Contenido |
| --- | --- | --- |
| [Documentación de Usuario](Documentación%20de%20Usuario.md) | Personas que utilizan la aplicación. | Ingreso, roles, pantallas, solicitudes, seis reportes, contraseñas, temporales, alertas y solución de problemas. |
| [Documentación Técnica](Documentación%20Técnica.md) | Desarrollo, soporte e infraestructura/DBA. | Stack, arquitectura, contratos, seguridad, instalación, despliegue, comprobaciones y worker opcional. |
| [Documentación de Proceso](Documentación%20de%20Proceso.md) | Responsables del proyecto y revisión de entregas. | Alcance, decisiones, evolución, retos, validación disponible, criterios de entrega y trabajo pendiente. |
| [Insumos de producción](../README.md) | DBA responsable del pivote y los destinos. | Preparación manual de `adminDB`, scripts y requisitos de infraestructura. |

## Cobertura funcional

Las secciones indicadas permiten localizar la explicación operativa y su implementación. Los permisos de la tabla corresponden a roles de aplicación; la cuenta técnica también necesita los permisos SQL del entorno.

| Capacidad | Rol o condición | Guía de usuario | Guía técnica |
| --- | --- | --- | --- |
| Ingreso SQL/Windows y sesión | Identidad registrada, activa y con roles. | 2, 3.1 y 3.13 | 3.2–3.3 |
| Resumen y seguimiento | Toda sesión autorizada; consulta de metadatos con Administrador/AprobadorEjecutor. | 3.2 y 3.17 | 3.10–3.11 |
| Selección del destino y validación de ticket | Creación: Administrador/Operador. | 3.3 | 3.5 y 4.3 |
| Modificar roles y permisos de base/instancia | Creación: Administrador/Operador y política del destino. | 3.4 | 3.5–3.6 |
| Crear cuenta SQL/Windows y accesos iniciales | Creación: Administrador/Operador. | 3.5 | 3.5 y 3.7 |
| Copiar permisos a una cuenta nueva | Creación: Administrador/Operador. | 3.6 | 3.7 |
| Confirmar, rechazar y ejecutar | Administrador/AprobadorEjecutor. | 3.7 | 3.5 y 3.10 |
| Habilitar/deshabilitar login | Solicitud de estado independiente y ciclo de revisión/ejecución. | 3.8 | 3.5 |
| Historial de solicitudes | Administrador/Operador/AprobadorEjecutor. | 3.9 | 3.2 y 3.5 |
| Auditoría y validación de integridad | Administrador/Auditor. | 3.9 | 3.7 y 3.12 |
| Servidores y pruebas de conexión | Administrador. | 3.10 | 3.3 y 4 |
| Usuarios autorizados y roles acumulables | Administrador. | 3.11 | 3.2 y 3.4 |
| Política General/Instancia/Base y activación especial | Administrador. | 3.12 | 3.6 |
| Reportes directos y centrales | Según reporte; véase el inventario siguiente. | 3.14 | 3.8 |
| Exportación PDF/CSV/Excel | Mismo acceso requerido para consultar cada reporte. | 3.14 | 3.8 |
| Cambiar contraseña de login SQL | Solicitar: Administrador/Operador; procesar: Administrador/AprobadorEjecutor. | 3.15 | 3.9 |
| Consultar vigencias y alertas | Toda sesión autorizada. | 3.16–3.17 | 3.11 |
| Solicitar/procesar extensión o cierre temporal | Solo Administrador. | 3.16 | 3.11 |
| Registrar revisión de alertas de contraseña | Administrador/Auditor. | 3.17 | 3.11 |
| Publicación, hora local y worker opcional | Infraestructura y permisos de la identidad ejecutora. | 2 y 3.17 | 3.12 y 4 |

## Inventario de los seis reportes

| Menú | Reporte | Fuente | Roles de consulta y exportación |
| --- | --- | --- | --- |
| Permisos y Accesos | Permisos por usuario | Destino: una cuenta, instancia y bases opcionales. | Administrador, Operador o AprobadorEjecutor. |
| Permisos y Accesos | Permisos por instancia | Destino: inventario de cuentas, roles, permisos y mapeos. | Administrador, Operador o AprobadorEjecutor. |
| Permisos y Accesos | Catálogo de roles | Destino: una base, herencia, capacidades y miembros. | Administrador, Operador o AprobadorEjecutor. |
| Seguridad y Auditoría | Inactividad de credenciales | Destino y complemento central de fechas confirmadas. | Administrador, Operador o AprobadorEjecutor. |
| Seguridad y Auditoría | Cambios de accesos | Seguimiento central del pivote. | Administrador o Auditor. |
| Seguridad y Auditoría | Cambios de contraseña | Seguimiento central: ranking e historial. | Administrador o Auditor. |

## Reglas de operación que deben conservarse

- Enviar o confirmar una solicitud no aplica el cambio; hay que ejecutarla. Los roles se suman y el aplicativo permite que una persona con las funciones necesarias complete el ciclo.
- Cada solicitud pertenece a una sola instancia. Las consultas multibase y el plan específico de copia no amplían el alta/modificación ordinaria con objetos de bases diferentes.
- La política controla lo que se puede solicitar; bloquear una opción no revoca permisos ya asignados.
- Vencer una vigencia genera una alerta y conserva el acceso hasta completar una extensión o cierre administrativo.
- Una referencia **Externo** es la última diferencia observada sin operación confirmada coincidente; no reconstruye todo el historial del motor ni identifica al actor.
- Un resultado **Por conciliar** exige revisar destino, identidad y registro central antes de repetir la gestión. No hay una transacción global entre pivote y destinos.
- Las fechas estructuradas usan Guatemala, con formato `yyyy-MM-dd HH:mm:ss`. La antigüedad de contraseña no representa el último uso del login.

## Instalación y validación

La aplicación no instala ni migra `adminDB`. Después de los prerrequisitos anteriores, la secuencia para completar la entrega es **32 → 36 → 33 v4 → 37 → 99**. El orden no es numérico: 36 precede a 33. Una instalación ya convertida a hora local no debe reaplicar 01–32. Consulte las condiciones y secuencias según estado previo en la [guía técnica, sección 4.2](Documentación%20Técnica.md#42-preparación-manual-de-admindb).

Permisos por instancia y el detalle de roles utilizan consultas de catálogo y no requieren una migración propia. El complemento de fechas de contraseñas sí requiere 37; los dos reportes centrales y temporales requieren el contrato 33 vigente.

Las guías describen las comprobaciones disponibles y sus límites. Esta revisión documental no aplica scripts ni acredita una ejecución nueva de las pruebas de la aplicación. Los diseños de `docs/propuestas` y `docs/archive/monitoring-v2` son material histórico y no forman parte del despliegue vigente.
