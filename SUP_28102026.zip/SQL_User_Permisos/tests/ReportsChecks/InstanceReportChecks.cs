using System.IO;
using ClosedXML.Excel;
using SqlAccessAdmin.Data;
using SqlAccessAdmin.Models;
using SqlAccessAdmin.ViewModels;

internal static class InstanceReportChecks
{
    internal static async Task RunAsync(Action<bool, string> check)
    {
        var source = new FakeReports();
        using var vm = new ReportsViewModel(source, ReportKind.InstancePermissions);
        await vm.Initialization;
        vm.SelectedServer = vm.Servers[0]; await vm.ContextLoad;
        check(vm.QueryCommand.CanExecute(null) && vm.SelectedUser is null, "Instancia se consulta sin elegir usuario ni base");
        await vm.QueryAsync();
        check(vm.InstanceLogins.Count == 6 && vm.InstanceLogins.Any(x => x.Disabled && x.Name == "sin_accesos"), "Inventario conserva cuentas deshabilitadas y sin asignaciones");
        check(vm.InstanceLogins.Count(x => x.IsSysadmin) == 2 && vm.Memberships.Any(x => x.Name == "sysadmin"), "Inventario y roles conservan sysadmins");
        check(vm.DatabaseCoverage.Count == 0 && source.LastDatabases.Count == 0, "Sin bases marcadas consulta únicamente la instancia");
        check(vm.ActiveSectionIndex == 3 && !vm.ShowEmpty, "Reporte abre el listado completo de logins");
        vm.ActiveSectionIndex = 2;
        check(vm.ShowEmpty, "Pestaña sin bases revisadas presenta estado vacío");
        vm.DatabaseChoices[0].IsSelected = true;
        check(!vm.CanExport && vm.InstanceLogins.Count == 0, "Cambiar alcance limpia inventario y exportación anterior");
        await vm.QueryAsync();
        check(vm.Permissions.Any(x => x.Login == "DOMINIO\\operador" && x.Principal == "usuario_windows_alias"), "Permisos distinguen login Windows de su usuario mapeado");
        check(vm.Permissions.Where(x => x.Login == "administrador_con_permisos").All(x => x.CoveredBySysadmin)
            && vm.Permissions.Where(x => x.Login == "operador_ventas").All(x => !x.CoveredBySysadmin), "Sysadmin se clasifica por cuenta sin afectar a los demás logins");
        check(vm.Memberships.All(x => x.Name != "public"), "Instancia omite public como el reporte por usuario");
        vm.Search = "DOMINIO\\operador";
        check(vm.InstanceLogins.Count == 1 && vm.Permissions.Count == 4 && vm.DatabaseCoverage.Count == 1, "Buscar login filtra también asignaciones y cobertura de su alias");
        vm.ActionFilter = "DENY";
        check(vm.Permissions.Count == 1 && vm.Permissions[0].Action == "DENY", "Instancia filtra permisos directos por acción");
        var filtered = vm.CreateExportDocument();
        check(filtered.Sections.Count == 4 && filtered.Sections.All(x => x.Columns[0].Header == "Login")
            && filtered.Sections[1].Rows.Single()[0]?.ToString() == "DOMINIO\\operador", "Exportación incluye cuatro bloques filtrados con la identidad del login");
        vm.ActiveSectionIndex = 3;
        check(vm.CreateExportDocument(ReportExportScope.ActiveSection).Sections.Single().Name == "Logins de la instancia", "Exportación de pestaña activa incluye el inventario");
        var directory = Path.Combine(Path.GetTempPath(), "instance-report-checks-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(directory);
        var exporter = new ReportExportService();
        foreach (var format in Enum.GetValues<ReportExportFormat>())
        {
            var path = Path.Combine(directory, "instance." + (format == ReportExportFormat.Excel ? "xlsx" : format.ToString().ToLowerInvariant()));
            await exporter.ExportAsync(filtered, path, format, CancellationToken.None);
            check(new FileInfo(path).Length > 100, "Instancia genera archivo " + format);
            if (format == ReportExportFormat.Excel)
            {
                using var workbook = new XLWorkbook(path);
                check(workbook.Worksheets.Count == 4, "Excel de instancia conserva cuatro hojas");
            }
        }
        vm.Search = ""; vm.ActionFilter = "Todas";
        source.Fail = true; await vm.QueryAsync();
        check(!vm.CanExport && vm.InstanceLogins.Count == 0 && vm.Status.Contains("Sin visibilidad"), "Error de instancia descarta resultados anteriores");
        source.Fail = false; await vm.QueryAsync();
        source.PendingInstance = new(); var pending = vm.QueryAsync();
        vm.SelectedServer = vm.Servers[1]; await vm.ContextLoad;
        source.PendingInstance.SetResult(new([new("respuesta_antigua", "SQL_LOGIN", false, true)], [], []));
        await pending;
        check(vm.InstanceLogins.Count == 0 && !vm.CanExport, "Respuesta tardía de instancia se descarta al cambiar servidor");
        source.PendingInstance = null;
        vm.DatabaseChoices[0].IsSelected = true; source.FailDatabase = vm.DatabaseChoices[0].Name;
        await vm.QueryAsync();
        check(!vm.CanExport && vm.InstanceLogins.Count == 0 && vm.Status.Contains(source.FailDatabase), "Fallo en una base impide publicar reporte parcial de instancia");
    }
}
