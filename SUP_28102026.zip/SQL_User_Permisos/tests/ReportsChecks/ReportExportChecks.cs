using System.ComponentModel;
using System.IO;
using System.Text;
using System.Windows.Data;
using ClosedXML.Excel;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Validation;
using Microsoft.VisualBasic.FileIO;
using PdfSharp.Pdf.IO;
using SqlAccessAdmin.Data;
using SqlAccessAdmin.Infrastructure;
using SqlAccessAdmin.Models;
using SqlAccessAdmin.ViewModels;

internal static class ReportExportChecks
{
    internal static async Task RunAsync(FakeReports source, ReportsViewModel user, ReportsViewModel roles,
        ReportsViewModel credentials, string directory, Action<bool, string> check)
    {
        Directory.CreateDirectory(directory);
        var exporter = new ReportExportService();
        user.DatabaseChoices[1].IsSelected = true; await user.QueryAsync();
        using var admin = new ReportsViewModel(source, ReportKind.UserPermissions);
        await admin.Initialization; admin.SelectedServer = admin.Servers[0]; await admin.ContextLoad;
        admin.DatabaseChoices[0].IsSelected = true;
        admin.SelectedUser = admin.Users.Single(x => x.Name == "administrador_con_permisos"); await admin.QueryAsync();
        foreach (var (vm, name) in new[] { (user, "permisos"), (admin, "permisos-sysadmin"), (roles, "roles"), (credentials, "credenciales") })
        {
            var snapshot = vm.CreateExportDocument();
            foreach (var format in Enum.GetValues<ReportExportFormat>())
            {
                var extension = format switch { ReportExportFormat.Pdf => ".pdf", ReportExportFormat.Csv => ".csv", _ => ".xlsx" };
                var path = Path.Combine(directory, name + extension);
                await exporter.ExportAsync(snapshot, path, format, CancellationToken.None);
                check(new FileInfo(path).Length > 100, $"Exportación real de {name}: {format}");
                if (format == ReportExportFormat.Excel)
                {
                    using var workbook = new XLWorkbook(path);
                    check(workbook.Worksheets.Count == snapshot.Sections.Count, $"Excel {name}: todas las secciones");
                    foreach (var section in snapshot.Sections)
                    {
                        var sheet = workbook.Worksheet(section.Name);
                        check(sheet.Cell(7, 1).GetString() == section.Columns[0].Header, $"Excel {name}: encabezados de {section.Name}");
                        check(sheet.SheetView.SplitRow == 7, $"Excel {name}: encabezados inmovilizados");
                    }
                    using var openXml = SpreadsheetDocument.Open(path, false);
                    var errors = new OpenXmlValidator().Validate(openXml).Take(4).ToList();
                    check(errors.Count == 0, $"Excel {name}: OpenXML válido {string.Join(", ", errors.Select(x => x.Description))}");
                }
                if (format == ReportExportFormat.Pdf)
                {
                    using var pdf = PdfReader.Open(path, PdfDocumentOpenMode.Import);
                    check(vm.IsRoleCatalog ? pdf.PageCount >= 1 : pdf.PageCount == 1, $"PDF {name}: secciones continuas y páginas según el detalle");
                }
                if (format == ReportExportFormat.Csv)
                {
                    var bytes = File.ReadAllBytes(path);
                    check(bytes.Take(3).SequenceEqual(Encoding.UTF8.GetPreamble()), $"CSV {name}: UTF-8 con BOM");
                    var rows = ReadCsv(path);
                    check(rows.Skip(1).All(r => r.Length == rows[0].Length), $"CSV {name}: todas las filas tienen la misma estructura");
                    check(rows.Skip(1).All(r => r[1] == snapshot.Server && r[4] == snapshot.QueriedAt.ToString("yyyy-MM-dd HH:mm:ss", System.Globalization.CultureInfo.InvariantCulture)), $"CSV {name}: contexto y fecha conservados");
                    if (vm.IsUserPermissions)
                    {
                        var stateIndex = Array.IndexOf(rows[0], "Origen / Estado");
                        check(rows.Skip(1).All(row => row[6] == "") && stateIndex >= 0
                            && rows.Skip(1).Where(row => row[7] == "Permisos directos").Select(row => row[stateIndex])
                                .SequenceEqual(snapshot.Sections[1].Rows.Select(row => row[^1]?.ToString())), $"CSV {name}: estado de permisos conservado sin nota explicativa");
                    }
                }
            }
        }

        foreach (var index in Enumerable.Range(0, 3))
        {
            user.ActiveSectionIndex = index;
            var sectionOnly = user.CreateExportDocument(ReportExportScope.ActiveSection);
            check(sectionOnly.Sections.Count == 1 && sectionOnly.Sections[0].Name == user.ActiveSectionName
                && sectionOnly.Filters.Contains("Sección exportada: " + user.ActiveSectionName), "Pestaña activa selecciona un solo bloque y documenta su alcance");
            check(user.CreateExportDocument().Sections.Count == 3, "Reporte completo conserva las tres secciones independientemente de la pestaña");
            foreach (var format in Enum.GetValues<ReportExportFormat>())
            {
                var extension = format switch { ReportExportFormat.Pdf => ".pdf", ReportExportFormat.Csv => ".csv", _ => ".xlsx" };
                var path = Path.Combine(directory, $"permisos-seccion-{index + 1}{extension}");
                await exporter.ExportAsync(sectionOnly, path, format, CancellationToken.None);
                if (format == ReportExportFormat.Excel)
                {
                    using var workbook = new XLWorkbook(path);
                    check(workbook.Worksheets.Count == 1 && workbook.Worksheet(1).Name == user.ActiveSectionName, "Excel de pestaña activa contiene únicamente su hoja");
                }
                else if (format == ReportExportFormat.Csv)
                    check(ReadCsv(path).Skip(1).All(row => row[7] == user.ActiveSectionName), "CSV de pestaña activa contiene únicamente sus registros");
                else
                {
                    using var pdf = PdfReader.Open(path, PdfDocumentOpenMode.Import);
                    check(pdf.PageCount == 1, "PDF de pestaña activa conserva una sección breve en una página");
                }
            }
        }

        user.ActionFilter = "DENY";
        var filtered = user.CreateExportDocument();
        check(filtered.Sections[1].Rows.Count == 2 && filtered.Sections[1].Rows.All(x => Equals(x[9], "DENY")) && filtered.Filters.Contains("DENY"), "Exportación respeta filtros y los documenta");
        user.ActionFilter = "Todas";
        var view = CollectionViewSource.GetDefaultView(user.Permissions);
        view.SortDescriptions.Add(new(nameof(ReportPermission.Object), ListSortDirection.Descending));
        check(Equals(user.CreateExportDocument().Sections[1].Rows[0][5], "Ventas"), "Exportación conserva el orden visible");
        view.SortDescriptions.Clear();
        check(!roles.IncludeRoleMembersInExport && roles.CreateExportDocument().Sections.Count == 4 && roles.CreateExportDocument().Sections.All(x => x.Name != "Miembros por rol"),
            "Catálogo omite el detalle de miembros por defecto");
        check(roles.CreateExportDocument().Sections[0].Columns.All(x => x.Header != "Cantidad de usuarios")
            && roles.CreateExportDocument().Sections[0].Rows.All(x => x.Length == 3), "Exportación oculta también el conteo de usuarios al excluir miembros");
        roles.IncludeRoleMembersInExport = true;
        check(!roles.CanExport && !roles.ExportPdfCommand.CanExecute(null), "Incluir miembros exige marcar al menos un rol");
        var rejectedEmptySelection = false;
        try { roles.CreateExportDocument(); } catch (InvalidOperationException) { rejectedEmptySelection = true; }
        check(rejectedEmptySelection, "No se genera detalle de todos los roles por falta de selección");
        roles.Roles.Single(x => x.Name == "db_datareader").ExportMembers = true;
        var singleRole = roles.CreateExportDocument();
        check(singleRole.Sections[0].Columns.Last().Header == "Cantidad de usuarios" && singleRole.Sections[0].Rows.All(x => x.Length == 4),
            "Exportación incluye conteo de usuarios solo al activar miembros");
        check(roles.CanExport && singleRole.Sections[1].Rows.Count == 2 && singleRole.Sections[1].Rows.All(x => Equals(x[0], "db_datareader")),
            "Un rol marcado exporta únicamente sus miembros");
        roles.Roles.Single(x => x.Name == "public").ExportMembers = true;
        var selectedRoles = roles.CreateExportDocument();
        check(selectedRoles.Sections[1].Rows.Count == 3 && selectedRoles.Filters.Contains("db_datareader, public"),
            "Varios roles marcados se incluyen y quedan identificados en el encabezado");
        foreach (var format in Enum.GetValues<ReportExportFormat>())
        {
            var extension = format switch { ReportExportFormat.Pdf => ".pdf", ReportExportFormat.Csv => ".csv", _ => ".xlsx" };
            await exporter.ExportAsync(selectedRoles, Path.Combine(directory, "roles-seleccionados" + extension), format, CancellationToken.None);
        }
        using (var workbook = new XLWorkbook(Path.Combine(directory, "roles-seleccionados.xlsx")))
            check(workbook.Worksheet("Miembros por rol").LastRowUsed()!.RowNumber() == 10, "Excel contiene solo los miembros de los roles marcados");
        var selectedCsv = ReadCsv(Path.Combine(directory, "roles-seleccionados.csv"));
        var sectionIndex = Array.IndexOf(selectedCsv[0], "Sección");
        var roleIndex = Array.IndexOf(selectedCsv[0], "Rol");
        check(selectedCsv.Skip(1).Where(x => x[sectionIndex] == "Miembros por rol").Select(x => x[roleIndex]).SequenceEqual(new[] { "db_datareader", "db_datareader", "public" }),
            "CSV incluye únicamente los roles elegidos en el detalle");
        roles.Search = "ana";
        check(roles.CreateExportDocument().Sections[1].Rows.Count == 2 && roles.Roles[0].ExportMembers,
            "Filtrar conserva las marcas de los roles visibles y excluye las ocultas");
        roles.Search = "";
        check(!roles.Roles.Single(x => x.Name == "public").ExportMembers, "Quitar el filtro no restaura marcas ocultas");
        roles.IncludeRoleMembersInExport = false;
        check(roles.CanExport && roles.CreateExportDocument().Sections.Count == 4 && roles.Roles.All(x => !x.ExportMembers),
            "Desactivar miembros conserva los permisos del catálogo y limpia las marcas");
        roles.IncludeRoleMembersInExport = true;
        roles.Roles.Single(x => x.Name == "ventas_lectura").ExportMembers = true;
        check(roles.CreateExportDocument().Sections[1].Rows.Count == 0 && roles.CreateExportDocument().Filters.Contains("ventas_lectura"),
            "Un rol sin miembros queda identificado sin añadir usuarios de otros roles");
        await roles.QueryAsync();
        check(!roles.IncludeRoleMembersInExport && roles.Roles.All(x => !x.ExportMembers), "Una nueva consulta reinicia las opciones de miembros");
        var datesPath = Path.Combine(directory, "credenciales.xlsx");
        using (var workbook = new XLWorkbook(datesPath))
        {
            var sheet = workbook.Worksheet(1);
            check(sheet.Cell(8, 4).DataType == XLDataType.DateTime && sheet.Cell(8, 5).DataType == XLDataType.Number, "Excel conserva fechas y días como datos tipados");
            check(sheet.Cell(10, 4).GetString() == "No disponible", "Excel distingue fechas desconocidas");
            check(sheet.Cell(10, 6).DataType == XLDataType.DateTime && sheet.Cell(10, 7).GetValue<int>() == 0, "Excel separa modificación reciente de contraseña desconocida");
        }

        var sample = new ReportExportDocument("Texto de prueba", "SQL,principal", "Base\"especial", "José", SqlAccessAdmin.Infrastructure.AppTime.OffsetNow, "Sin filtro", "Solo lectura",
            [new("Pruebas", [new("Texto", 2), new("Descripción", 3)],
                [new object?[] { "=1+1", "Texto, con \"comillas\" y\nsalto" }, new object?[] { " @SUM(A1)", "áéíóú ñ 中文" },
                 new object?[] { "+cmd", "Identificador_" + new string('x', 128) }])]);
        var csvPath = Path.Combine(directory, "escape.csv");
        await exporter.ExportAsync(sample, csvPath, ReportExportFormat.Csv, CancellationToken.None);
        var escaped = ReadCsv(csvPath);
        var textColumn = Array.IndexOf(escaped[0], "Texto"); var descriptionColumn = Array.IndexOf(escaped[0], "Descripción");
        check(escaped[1][textColumn] == "'=1+1" && escaped[2][textColumn].StartsWith("'"), "CSV neutraliza valores que Excel interpretaría como fórmulas");
        check(escaped[1][descriptionColumn] == "Texto, con \"comillas\" y\nsalto" && escaped[2][descriptionColumn].Contains("ñ 中文"), "CSV conserva comillas, comas, saltos y Unicode");
        var excelPath = Path.Combine(directory, "escape.xlsx");
        await exporter.ExportAsync(sample, excelPath, ReportExportFormat.Excel, CancellationToken.None);
        using (var workbook = new XLWorkbook(excelPath))
            check(workbook.Worksheet(1).Cell(8, 1).GetString() == "=1+1" && !workbook.Worksheet(1).Cell(8, 1).HasFormula, "Excel mantiene identificadores como texto sin ejecutar fórmulas");
        var multipage = sample with { Sections = [new("Pruebas", sample.Sections[0].Columns, Enumerable.Range(0, 180).Select(i => new object?[] { $"usuario_{i:D3}", "Descripción extensa para comprobar encabezados repetidos y saltos de página. " + new string('x', 80) }).ToList())] };
        var pdfPath = Path.Combine(directory, "multipagina.pdf");
        await exporter.ExportAsync(multipage, pdfPath, ReportExportFormat.Pdf, CancellationToken.None);
        using (var pdf = PdfReader.Open(pdfPath, PdfDocumentOpenMode.Import)) check(pdf.PageCount > 2, "PDF pagina resultados largos");

        var protectedPath = Path.Combine(directory, "existente.csv"); File.WriteAllText(protectedPath, "ORIGINAL");
        using (var cancellation = new CancellationTokenSource())
        {
            cancellation.Cancel();
            try { await exporter.ExportAsync(sample, protectedPath, ReportExportFormat.Csv, cancellation.Token); }
            catch (OperationCanceledException) { }
            check(File.ReadAllText(protectedPath) == "ORIGINAL", "Cancelar conserva un archivo existente");
        }
        var protectedExcel = Path.Combine(directory, "existente.xlsx"); File.WriteAllText(protectedExcel, "ORIGINAL");
        var invalid = sample with { Sections = [sample.Sections[0] with { Name = "nombre/inválido" }] };
        try { await exporter.ExportAsync(invalid, protectedExcel, ReportExportFormat.Excel, CancellationToken.None); }
        catch (ArgumentException) { }
        check(File.ReadAllText(protectedExcel) == "ORIGINAL", "Un error de generación conserva el archivo previo");
        File.Delete(protectedExcel); File.Delete(protectedPath);
        user.SelectedUser = user.Users[1]; await user.QueryAsync();
        check(user.CanExport, "Una consulta vacía puede exportarse");
        var empty = user.CreateExportDocument();
        foreach (var format in Enum.GetValues<ReportExportFormat>())
        {
            var extension = format switch { ReportExportFormat.Pdf => ".pdf", ReportExportFormat.Csv => ".csv", _ => ".xlsx" };
            await exporter.ExportAsync(empty, Path.Combine(directory, "sin-filas" + extension), format, CancellationToken.None);
        }
        check(ReadCsv(Path.Combine(directory, "sin-filas.csv")).Skip(1).All(x => x[8] == "Sin filas con los filtros actuales"), "CSV identifica secciones vacías sin inventar datos");
        user.SelectedUser = user.Users[0]; await user.QueryAsync();
        check(!Directory.EnumerateFiles(directory, ".sql-access-report-*.tmp").Any(), "No quedan archivos temporales de exportación");

        var fakeExporter = new FakeExporter(); var dialog = new FakeDialog();
        using var interactive = new ReportsViewModel(source, ReportKind.CredentialAge, fakeExporter, dialog);
        await interactive.Initialization;
        check(!interactive.ExportPdfCommand.CanExecute(null), "Exportar se deshabilita antes de consultar");
        interactive.SelectedServer = interactive.Servers[0]; await interactive.ContextLoad; await interactive.QueryAsync();
        await interactive.ExportAsync(ReportExportFormat.Pdf);
        check(fakeExporter.Calls == 0 && interactive.CanExport, "Cancelar Guardar como no exporta ni elimina resultados");
        dialog.Path = "prueba.pdf"; fakeExporter.Pending = new();
        var exporting = interactive.ExportAsync(ReportExportFormat.Pdf);
        check(interactive.IsExporting && !interactive.QueryCommand.CanExecute(null) && !interactive.ExportCsvCommand.CanExecute(null), "Exportación bloquea consultas y exportaciones simultáneas");
        interactive.CancelCommand.Execute(null); fakeExporter.Pending.SetCanceled(); await exporting;
        check(interactive.CanExport && interactive.Status.Contains("cancelada"), "Cancelar exportación habilita reintentar");
        fakeExporter.Pending = null; fakeExporter.Fail = true;
        await interactive.ExportAsync(ReportExportFormat.Pdf);
        check(interactive.Status.Contains("archivo bloqueado") && interactive.CanExport, "Error al guardar mantiene el reporte disponible");

        var scopeDialog = new FakeDialog { Path = "reporte.pdf", Scope = null };
        var scopeExporter = new FakeExporter();
        using var scoped = new ReportsViewModel(source, ReportKind.UserPermissions, scopeExporter, scopeDialog);
        await scoped.Initialization;
        scoped.SelectedServer = scoped.Servers[0]; await scoped.ContextLoad;
        scoped.DatabaseChoices[0].IsSelected = true;
        scoped.SelectedUser = scoped.Users.Single(x => x.Name == "administrador_con_permisos"); await scoped.QueryAsync();
        await scoped.ExportAsync(ReportExportFormat.Pdf);
        check(scopeDialog.ScopeCalls == 1 && scopeDialog.PathCalls == 0 && scopeExporter.Calls == 0 && scoped.CanExport,
            "Cancelar el selector de alcance no abre Guardar como ni exporta");
        foreach (var format in Enum.GetValues<ReportExportFormat>())
        {
            foreach (var index in Enumerable.Range(0, 3))
            {
                scoped.ActiveSectionIndex = index; scopeDialog.Scope = ReportExportScope.ActiveSection;
                await scoped.ExportAsync(format);
                check(scopeDialog.LastFormat == format && scopeDialog.LastActiveSection == scoped.ActiveSectionName
                    && scopeExporter.LastDocument!.Sections.Single().Name == scoped.ActiveSectionName
                    && scopeDialog.SuggestedName!.Contains(scoped.ActiveSectionName), "Botón de exportación respeta el alcance elegido y la pestaña actual");
            }
            scopeDialog.Scope = ReportExportScope.FullReport;
            await scoped.ExportAsync(format);
            check(scopeExporter.LastDocument!.Sections.Count == 3, "Cada formato permite elegir el reporte completo desde cualquier pestaña");
        }
        scoped.ActiveSectionIndex = 1; scoped.ActionFilter = "DENY"; scopeDialog.Scope = ReportExportScope.ActiveSection;
        await scoped.ExportAsync(ReportExportFormat.Pdf);
        check(scopeExporter.LastDocument!.Sections.Single().Rows.All(row => Equals(row[9], "DENY") && Equals(row[10], "Sin efecto (Sysadmin)")),
            "Exportar la pestaña de permisos conserva filtros, acción y contexto de sysadmin");
        scoped.ClearDatabasesCommand.Execute(null); scoped.ActionFilter = "Todas"; await scoped.QueryAsync();
        scoped.ActiveSectionIndex = 2;
        check(scoped.CreateExportDocument().Sections.Count == 3 && scoped.CreateExportDocument(ReportExportScope.ActiveSection).Sections.Single().Rows.Count == 0,
            "Bases revisadas permanece exportable como sección vacía cuando se consulta solo la instancia");
    }
    private static List<string[]> ReadCsv(string path)
    {
        using var parser = new TextFieldParser(path, Encoding.UTF8) { TextFieldType = FieldType.Delimited, HasFieldsEnclosedInQuotes = true, TrimWhiteSpace = false };
        parser.SetDelimiters(","); List<string[]> rows = [];
        while (!parser.EndOfData) rows.Add(parser.ReadFields()!);
        return rows;
    }
    private sealed class FakeDialog : IReportSaveDialog
    {
        public string? Path;
        public ReportExportScope? Scope = ReportExportScope.FullReport;
        public int ScopeCalls, PathCalls;
        public ReportExportFormat LastFormat;
        public string? LastActiveSection, SuggestedName;
        public ReportExportScope? ChooseScope(ReportExportFormat format, string activeSection)
        {
            ScopeCalls++; LastFormat = format; LastActiveSection = activeSection; return Scope;
        }
        public string? ChoosePath(ReportExportFormat format, string suggestedName) { PathCalls++; SuggestedName = suggestedName; return Path; }
    }
    private sealed class FakeExporter : IReportExportService
    {
        public int Calls; public bool Fail; public TaskCompletionSource? Pending;
        public ReportExportDocument? LastDocument;
        public Task ExportAsync(ReportExportDocument report, string path, ReportExportFormat format, CancellationToken ct)
        {
            Calls++; LastDocument = report; if (Fail) throw new IOException("archivo bloqueado");
            return Pending?.Task ?? Task.CompletedTask;
        }
    }
}
