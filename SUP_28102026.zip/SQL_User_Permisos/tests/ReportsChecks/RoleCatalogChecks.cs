using SqlAccessAdmin.Data;
using SqlAccessAdmin.Models;
using SqlAccessAdmin.ViewModels;

internal static class RoleCatalogChecks
{
    internal static async Task RunAsync(ReportsViewModel vm, Action<bool, string> check)
    {
        ReportPermission grant = new("Objeto", "dbo", "Pagos", "Tabla", "", "SELECT", "GRANT");
        ReportPermission deny = grant with { Permission = "DELETE", Action = "DENY" };
        var roles = RoleCatalogDetails.Attach([
            new("operador", false, []) { DirectPermissions = [deny] },
            new("rama_a", false, []) { DirectPermissions = [grant] },
            new("rama_b", false, []), new("db_datareader", true, []), new("public", false, []), new("aislado", false, [])],
            [new("operador", "rama_a"), new("operador", "rama_b"), new("rama_a", "db_datareader"),
             new("rama_b", "db_datareader"), new("db_datareader", "operador")]);
        var role = roles.Single(x => x.Name == "operador");
        check(role.InheritedRoles.Count == 3 && role.InheritedRoles.All(x => x.Name != "operador"), "Herencia termina ciclos y deduplica rutas múltiples");
        check(role.InheritedRoles.Single(x => x.Name == "rama_a").IsDirect && !role.InheritedRoles.Single(x => x.Name == "db_datareader").IsDirect,
            "Herencia distingue membresía directa de anidada");
        check(roles.Single(x => x.Name == "aislado").InheritedRoles.Count == 0 && roles.Single(x => x.Name == "public").InheritedRoles.Count == 0,
            "No se atribuye herencia a roles sin membresías");
        check(roles.Single(x => x.Name == "rama_a").NestedMembers.SequenceEqual(new[] { "operador" }), "Roles miembros y roles de origen conservan dirección");
        var texts = Flatten(RoleCatalogDetails.Tree(role)).ToList();
        check(texts.Any(x => x.Contains("DELETE — Denegado")) && texts.Any(x => x.Contains("Capacidades incorporadas:")),
            "Árbol conserva denegaciones y capacidades fijas heredadas");
        using var inheritedVm = new ReportsViewModel(new FakeReports { RoleCatalog = roles }, ReportKind.RoleCatalog);
        await inheritedVm.Initialization;
        inheritedVm.SelectedServer = inheritedVm.Servers[0]; await inheritedVm.ContextLoad;
        inheritedVm.SelectedDatabase = inheritedVm.Databases[0]; await inheritedVm.ContextLoad;
        await inheritedVm.QueryAsync();
        var inheritedRows = inheritedVm.CreateExportDocument().Sections.Single(x => x.Name == "Permisos de roles").Rows
            .Where(x => Equals(x[0], "operador")).ToList();
        check(inheritedRows.Count == 2 && inheritedRows.Any(x => Equals(x[1], "Heredado") && Equals(x[2], "rama_a") && Equals(x[6], "GRANT"))
            && inheritedRows.Any(x => Equals(x[1], "Directo") && Equals(x[6], "DENY")),
            "Exportación conserva concesión heredada y denegación directa sin calcular una concesión efectiva");
        inheritedVm.SelectedDatabase = inheritedVm.Databases[1];
        check(inheritedVm.RoleDetailTree.Count == 0 && !inheritedVm.CanExport, "Cambiar base limpia el árbol y la exportación de roles anterior");
        check(RoleCatalogDetails.Resource(grant with { Object = "a.b]c", Column = "importe.neto" }) == "[dbo].[a.b]]c].[importe.neto]",
            "Identificadores delimitados distinguen puntos y corchetes en recursos");
        vm.SelectedRole = vm.Roles.Single(x => x.Name == "ventas_lectura");
        check(Flatten(vm.RoleDetailTree).Any(x => x.Contains("REVOKE — Excepción de columna"))
            && Flatten(vm.RoleDetailTree).Any(x => x.Contains("Permitido con opción de conceder")), "Árbol distingue REVOKE y delegación de una concesión ordinaria");
        vm.Search = "Solicitudes";
        check(vm.Roles.Count == 1 && vm.Roles[0].Name == "ventas_lectura", "Búsqueda local incluye recursos de permisos");
        var snapshot = vm.CreateExportDocument();
        check(snapshot.Sections.Single(x => x.Name == "Permisos de roles").Rows.Count == 4
            && snapshot.Sections.Single(x => x.Name == "Roles heredados").Rows.Count == 1
            && snapshot.Sections.Single(x => x.Name == "Capacidades de roles fijos").Rows.Single()[1]?.ToString() == "Heredado",
            "Exportación filtrada conserva el origen heredado aunque ese rol no esté visible en el catálogo");
        check(snapshot.ScopeNote.Contains("no calcula los permisos efectivos"), "Exportación explica el alcance sin presentar permisos efectivos");
        vm.Search = ""; vm.SelectedRole = vm.Roles.First();
    }

    private static IEnumerable<string> Flatten(IEnumerable<ReportRoleTreeNode> nodes) =>
        nodes.SelectMany(x => new[] { x.Text }.Concat(Flatten(x.Children)));
}
