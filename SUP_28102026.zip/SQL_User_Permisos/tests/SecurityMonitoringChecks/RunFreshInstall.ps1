param([string]$Server='localhost',[switch]$TrustCertificate)
$ErrorActionPreference='Stop'
$repoRoot=(Resolve-Path (Join-Path $PSScriptRoot '../..')).Path
$labName='SqlAccessAdmin_FreshChecks_'+[guid]::NewGuid().ToString('N')
$outputDir=Join-Path $repoRoot 'artifacts/security-monitoring-fresh-sql'
New-Item -ItemType Directory -Path $outputDir -Force | Out-Null
function Invoke-FreshSql([string]$Db,[string[]]$Arguments) {
 $sqlArgs=@('-S',$Server,'-d',$Db,'-E','-I','-b','-r','1','-l','15','-f','65001')
 if($TrustCertificate){$sqlArgs+='-C'}
 $result=& sqlcmd @sqlArgs @Arguments 2>&1
 $result | Set-Content -LiteralPath (Join-Path $outputDir 'last-output.txt') -Encoding utf8
 if($LASTEXITCODE -ne 0){$result | Select-Object -Last 20 | Write-Output;throw 'Falló la instalación nueva SQL.'}
 $result | Where-Object {$_ -match 'FRESH_SQL_RESULT'} | Write-Output
}
function Get-Migration([string]$Name) {
 $sql=Get-Content (Join-Path $repoRoot ('InsumosProduccion/'+$Name)) -Raw
 if($Name -like '08_*') {
  # La copia de pruebas usa una clave efímera; no reutiliza la configurada por el DBA.
  $sql=[regex]::Replace($sql,"DECLARE @DatabaseMasterKeyPassword nvarchar\(256\)=N'[^']*';","DECLARE @DatabaseMasterKeyPassword nvarchar(256)=N'Fresh!"+[guid]::NewGuid().ToString('N')+"';")
 }
 return $sql.Replace('USE [adminDB];',"USE [$labName];")
}
function Test-RejectedMigration([string]$Name,[string]$ExpectedMessage,[string]$Checks) {
 # Sin -b: reproduce SSMS, que continúa con el siguiente GO tras un error.
 $probe="SELECT object_id,modify_date INTO #BeforeObjects FROM sys.objects;`nGO`n"+(Get-Migration $Name)+"`n"+$Checks+@'

IF EXISTS(SELECT object_id,modify_date FROM #BeforeObjects EXCEPT SELECT object_id,modify_date FROM sys.objects)
 OR EXISTS(SELECT object_id,modify_date FROM sys.objects WHERE name<>N'ufn_AppNow' EXCEPT SELECT object_id,modify_date FROM #BeforeObjects)
 THROW 51940,'La migración rechazada modificó objetos.',1;
PRINT N'FRESH_SQL_RESULT Rechazo controlado; sesión restaurada y contratos conservados.';
'@
 $probePath=Join-Path $outputDir 'rejected.sql'
 Set-Content -LiteralPath $probePath -Value $probe -Encoding utf8
 $probeArgs=@('-S',$Server,'-d',$labName,'-E','-I','-r','1','-l','15','-f','65001','-i',$probePath)
 if($TrustCertificate){$probeArgs+='-C'}
 $result=& sqlcmd @probeArgs 2>&1
 $result | Set-Content -LiteralPath (Join-Path $outputDir 'rejected-output.txt') -Encoding utf8
 $message=$result -join "`n"
 if($LASTEXITCODE -ne 0 -or $message -notmatch [regex]::Escape($ExpectedMessage) -or
  ([regex]::Matches($message,'Msg \d+, Level')).Count -ne 1 -or
  $message -notmatch 'FRESH_SQL_RESULT Rechazo controlado') {
  $result | Select-Object -Last 20 | Write-Output
  throw ('Falló el rechazo seguro de '+$Name)
 }
 Write-Output ('FRESH_SQL_RESULT '+$ExpectedMessage+' Sin errores en cascada ni cambios parciales.')
}
$created=$false
try {
 Invoke-FreshSql 'master' @('-Q',"CREATE DATABASE [$labName];")
 $created=$true
 Test-RejectedMigration '36_HoraLocalGuatemala.sql' 'Instale primero los scripts 01 a 32' ''
 $bootstrap=@'
INSERT access.AuthorizedPrincipal(Principal,PrincipalType,RoleName,Active,Notes)
VALUES(ORIGINAL_LOGIN(),'BOOTSTRAP','Administrator',1,N'Administrador exclusivo del laboratorio.');
GO
CREATE PROCEDURE dbo.sp_VerificarTicketExiste @Ticket varchar(50) AS
BEGIN SET NOCOUNT ON; SELECT N'Equipo' RESPONSABLE,N'Lab' CLIENTE,@Ticket ID_COMPUESTO,N'Prueba' ASUNTO,N'Prueba' DESCRIPCION,N'ACTIVO' ESTADO; END;
GO
'@
 $scriptPath=Join-Path $outputDir 'migration.sql'
 $scripts=Get-ChildItem (Join-Path $repoRoot 'InsumosProduccion') -Filter '*.sql' |
  Where-Object {$_.Name -match '^(0[1-4]|0[7-9]|[12][0-9]|3[0-2])_'} | Sort-Object Name
 foreach($script in $scripts) {
  Set-Content -LiteralPath $scriptPath -Value (Get-Migration $script.Name) -Encoding utf8
  Invoke-FreshSql $labName @('-i',$scriptPath)
  if($script.Name -like '04_*'){Invoke-FreshSql $labName @('-Q',$bootstrap)}
  Write-Output ('Instalado: '+$script.Name)
 }
 Test-RejectedMigration '33_MonitoreoSeguridadYTemporales.sql' 'Aplique primero 36_HoraLocalGuatemala.sql.' ''
 Invoke-FreshSql $labName @('-Q','CREATE TABLE access.LabUnmappedDate(UnknownDate datetime2);')
 Test-RejectedMigration '36_HoraLocalGuatemala.sql' 'Fecha sin convención catalogada: access.LabUnmappedDate.UnknownDate.' @'
IF OBJECT_ID(N'access.AppTimeConvention') IS NOT NULL OR OBJECT_ID(N'access.AppTimeConversion') IS NOT NULL
 OR COL_LENGTH(N'access.AuditEvent',N'HashDateBasis') IS NOT NULL
 THROW 51941,'No se revirtió la conversión fallida.',1;
'@
 Invoke-FreshSql $labName @('-Q','DROP TABLE access.LabUnmappedDate;')
 foreach($name in '36_HoraLocalGuatemala.sql','33_MonitoreoSeguridadYTemporales.sql','37_FechasContrasenaConfirmadas.sql','99_ValidarInstalacion.sql') {
  Set-Content -LiteralPath $scriptPath -Value (Get-Migration $name) -Encoding utf8
  Invoke-FreshSql $labName @('-i',$scriptPath)
  Write-Output ('Instalado: '+$name)
 }
 # Reproducir el validador que dejaba la versión anterior de 36 en bases ya convertidas.
 Invoke-FreshSql $labName @('-Q',@'
DECLARE @Definition nvarchar(max)=OBJECT_DEFINITION(OBJECT_ID(N'access.usp_Audit_ValidateIntegrity'));
DECLARE @Guard nvarchar(200)=N'-- SqlAccessAdmin.MultiRoleGuard.v1 AUDIT
   EXEC access.usp_App_RequirePermission ''AUDIT'';';
IF CHARINDEX(@Guard,@Definition)=0 THROW 51942,'No se encontró la guarda de auditoría.',1;
SET @Definition=REPLACE(@Definition,@Guard,N'');
SET @Definition=N'ALTER '+SUBSTRING(@Definition,CHARINDEX(N'PROCEDURE',@Definition),LEN(@Definition));
EXEC sys.sp_executesql @Definition;
'@)
 foreach($name in '36_HoraLocalGuatemala.sql','33_MonitoreoSeguridadYTemporales.sql','99_ValidarInstalacion.sql') {
  Set-Content -LiteralPath $scriptPath -Value (Get-Migration $name) -Encoding utf8
  Invoke-FreshSql $labName @('-i',$scriptPath)
 }
 Invoke-FreshSql $labName @('-Q',"PRINT N'FRESH_SQL_RESULT Reaplicación de 36 y 33: autorización AUDIT reparada y validación 99 correcta.';")
 Invoke-FreshSql $labName @('-Q',"PRINT N'FRESH_SQL_RESULT Instalación nueva completa: 01–32, 36, 33, 37 y 99.';")
} finally {
 if($created) {
  if($labName -notmatch '^SqlAccessAdmin_FreshChecks_[a-f0-9]{32}$'){throw 'Limpieza rechazada.'}
  Invoke-FreshSql 'master' @('-Q',"ALTER DATABASE [$labName] SET SINGLE_USER WITH ROLLBACK IMMEDIATE; DROP DATABASE [$labName];")
 }
}
