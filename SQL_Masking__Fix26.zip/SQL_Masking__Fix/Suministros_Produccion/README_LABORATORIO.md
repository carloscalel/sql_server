# Base de prueba

Ejecute `10_base_ejemplo_ofuscamiento.sql` como DBA en el servidor que registrará en la aplicación. Crea `OfuscadorDemo`, tres tablas (`Clientes`, `Empleados`, `Pedidos`), datos ficticios y patrones para tarjeta, cuenta, correo, NIT, dirección, teléfono, token y nombre.

Después de registrar el servidor en OfuscadorTool:

1. Seleccione `OfuscadorDemo` en **Servidores y bases**.
2. Cargue los usuarios en **Usuarios excluidos** y marque los que deban conservar acceso sin cambios.
3. Ejecute primero una simulación.
4. Revise `dbo.Masked_Audit`, las vistas `masked` y los sinónimos `app`.
5. Ejecute el despliegue real solo después de validar el resultado.

Los patrones se almacenan en `dbo.Masked_Patterns`, que es la tabla que consumen los scripts de destino.
