/*
  OfuscadorTool - instalación administrativa controlada por DBA
  Ejecutar manualmente en la base pivote ya creada (por defecto: adminDB).
  Este script crea únicamente el esquema y objetos administrativos del aplicativo.
  La aplicación NO crea ni modifica estos objetos.
*/
USE [adminDB];
GO
SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
SET NOCOUNT ON;

IF SCHEMA_ID(N'ofuscador') IS NULL EXEC(N'CREATE SCHEMA [ofuscador] AUTHORIZATION [dbo]');
GO
IF OBJECT_ID(N'ofuscador.Servers',N'U') IS NULL
CREATE TABLE ofuscador.Servers(
 ServerId int IDENTITY(1,1) CONSTRAINT PK_Ofuscador_Servers PRIMARY KEY,
 IsActive bit NOT NULL CONSTRAINT DF_Ofuscador_Servers_IsActive DEFAULT(1),
 Name nvarchar(100) NOT NULL CONSTRAINT UQ_Ofuscador_Servers_Name UNIQUE,
 Host nvarchar(256) NOT NULL, Instance nvarchar(128) NULL,
 UseWindowsAuth bit NOT NULL, SqlUser nvarchar(256) NULL, EncryptedPassword nvarchar(max) NULL,
 Encrypt bit NOT NULL CONSTRAINT DF_Ofuscador_Servers_Encrypt DEFAULT(1),
 TrustServerCertificate bit NOT NULL CONSTRAINT DF_Ofuscador_Servers_Trust DEFAULT(0),
 TimeoutSeconds int NOT NULL CONSTRAINT DF_Ofuscador_Servers_Timeout DEFAULT(30),
 CreatedAt datetime2(0) NOT NULL CONSTRAINT DF_Ofuscador_Servers_Created DEFAULT SYSUTCDATETIME());
GO
IF OBJECT_ID(N'ofuscador.AuthorizedUsers',N'U') IS NULL
CREATE TABLE ofuscador.AuthorizedUsers(
 Principal nvarchar(256) NOT NULL CONSTRAINT PK_Ofuscador_AuthorizedUsers PRIMARY KEY,
 PrincipalType nvarchar(30) NOT NULL, AppRole nvarchar(20) NOT NULL,
 IsActive bit NOT NULL CONSTRAINT DF_Ofuscador_AuthorizedUsers_Active DEFAULT(1),
 Notes nvarchar(500) NULL, UpdatedAt datetime2(0) NOT NULL CONSTRAINT DF_Ofuscador_AuthorizedUsers_Updated DEFAULT SYSUTCDATETIME());
GO
IF OBJECT_ID(N'ofuscador.MaskPatterns',N'U') IS NULL
CREATE TABLE ofuscador.MaskPatterns(
 Pattern nvarchar(128) NOT NULL CONSTRAINT PK_Ofuscador_MaskPatterns PRIMARY KEY,
 DdmFunction nvarchar(200) NOT NULL, ViewMaskExpr nvarchar(1000) NULL,
 Priority int NOT NULL CONSTRAINT DF_Ofuscador_MaskPatterns_Priority DEFAULT(100),
 IsActive bit NOT NULL CONSTRAINT DF_Ofuscador_MaskPatterns_Active DEFAULT(1));
GO
IF OBJECT_ID(N'ofuscador.Executions',N'U') IS NULL
CREATE TABLE ofuscador.Executions(
 ExecutionId uniqueidentifier NOT NULL CONSTRAINT PK_Ofuscador_Executions PRIMARY KEY,
 Mode nvarchar(20) NOT NULL, Status nvarchar(30) NOT NULL, RequestedBy nvarchar(256) NOT NULL,
 StartedAt datetime2(0) NOT NULL, FinishedAt datetime2(0) NULL, Summary nvarchar(max) NULL);
GO
IF OBJECT_ID(N'ofuscador.ExecutionTargets',N'U') IS NULL
CREATE TABLE ofuscador.ExecutionTargets(
 ExecutionId uniqueidentifier NOT NULL, ServerName nvarchar(100) NOT NULL, DatabaseName sysname NOT NULL,
 Status nvarchar(30) NOT NULL, Detail nvarchar(max) NULL,
 CONSTRAINT PK_Ofuscador_ExecutionTargets PRIMARY KEY(ExecutionId,ServerName,DatabaseName),
 CONSTRAINT FK_Ofuscador_ExecutionTargets_Execution FOREIGN KEY(ExecutionId) REFERENCES ofuscador.Executions(ExecutionId));
GO
IF OBJECT_ID(N'ofuscador.PermissionBackup',N'U') IS NULL
CREATE TABLE ofuscador.PermissionBackup(
 ExecutionId uniqueidentifier NOT NULL, ServerName nvarchar(100) NOT NULL, DatabaseName sysname NOT NULL,
 PrincipalName sysname NOT NULL, SnapshotJson nvarchar(max) NOT NULL,
 CONSTRAINT PK_Ofuscador_PermissionBackup PRIMARY KEY(ExecutionId,ServerName,DatabaseName,PrincipalName));
GO
IF OBJECT_ID(N'ofuscador.Audit',N'U') IS NULL
CREATE TABLE ofuscador.Audit(
 AuditId bigint IDENTITY(1,1) CONSTRAINT PK_Ofuscador_Audit PRIMARY KEY,
 EventAt datetime2(0) NOT NULL CONSTRAINT DF_Ofuscador_Audit_Event DEFAULT SYSUTCDATETIME(),
 Principal nvarchar(256) NOT NULL, FormName nvarchar(100) NOT NULL, ActionName nvarchar(100) NOT NULL,
 ServerName nvarchar(100) NULL, DatabaseName sysname NULL, Success bit NOT NULL, Detail nvarchar(max) NULL);
GO
/* Perfiles de ofuscamiento: objetos creados manualmente por el DBA. */
IF OBJECT_ID(N'ofuscador.MaskProfiles',N'U') IS NULL
CREATE TABLE ofuscador.MaskProfiles(
 ProfileId int IDENTITY(1,1) NOT NULL CONSTRAINT PK_Ofuscador_MaskProfiles PRIMARY KEY,
 ProfileName nvarchar(128) NOT NULL CONSTRAINT UQ_Ofuscador_MaskProfiles_Name UNIQUE,
 ServerName nvarchar(128) NOT NULL, DatabaseName sysname NOT NULL, TargetSchema sysname NOT NULL,
 IsActive bit NOT NULL CONSTRAINT DF_Ofuscador_MaskProfiles_Active DEFAULT(1),
 CreatedAt datetime2(0) NOT NULL CONSTRAINT DF_Ofuscador_MaskProfiles_Created DEFAULT SYSUTCDATETIME(),
 ModifiedAt datetime2(0) NOT NULL CONSTRAINT DF_Ofuscador_MaskProfiles_Modified DEFAULT SYSUTCDATETIME());
IF OBJECT_ID(N'ofuscador.MaskProfileColumns',N'U') IS NULL
CREATE TABLE ofuscador.MaskProfileColumns(
 ProfileId int NOT NULL, SchemaName sysname NOT NULL, TableName sysname NOT NULL, ColumnName sysname NOT NULL,
 RulePattern nvarchar(128) NOT NULL,
 CONSTRAINT PK_Ofuscador_MaskProfileColumns PRIMARY KEY(ProfileId,SchemaName,TableName,ColumnName),
 CONSTRAINT FK_Ofuscador_MaskProfileColumns_Profile FOREIGN KEY(ProfileId) REFERENCES ofuscador.MaskProfiles(ProfileId) ON DELETE CASCADE);
IF OBJECT_ID(N'ofuscador.MaskProfileUsers',N'U') IS NULL
CREATE TABLE ofuscador.MaskProfileUsers(
 ProfileId int NOT NULL, PrincipalName sysname NOT NULL,
 CONSTRAINT PK_Ofuscador_MaskProfileUsers PRIMARY KEY(ProfileId,PrincipalName),
 CONSTRAINT FK_Ofuscador_MaskProfileUsers_Profile FOREIGN KEY(ProfileId) REFERENCES ofuscador.MaskProfiles(ProfileId) ON DELETE CASCADE);
GO
IF NOT EXISTS(SELECT 1 FROM sys.indexes WHERE name=N'IX_Ofuscador_Audit_EventAt' AND object_id=OBJECT_ID(N'ofuscador.Audit'))
  CREATE INDEX IX_Ofuscador_Audit_EventAt ON ofuscador.Audit(EventAt DESC);
IF NOT EXISTS(SELECT 1 FROM sys.indexes WHERE name=N'IX_Ofuscador_ExecutionTargets_Status' AND object_id=OBJECT_ID(N'ofuscador.ExecutionTargets'))
  CREATE INDEX IX_Ofuscador_ExecutionTargets_Status ON ofuscador.ExecutionTargets(Status);
GO

/* Patrones iniciales: solo se insertan si todavía no existen. */
MERGE ofuscador.MaskPatterns AS T
USING (VALUES
 (N'%TARJETA%',N'partial(0,"XXXXXXXXXXXXXXX",4)',CONVERT(nvarchar(1000),NULL),100,CONVERT(bit,1)),
 (N'%CUENTA%',N'partial(0,"XXXXXXXXXXXX",4)',CONVERT(nvarchar(1000),NULL),100,CONVERT(bit,1)),
 (N'%EMAIL%',N'email()',CONVERT(nvarchar(1000),NULL),200,CONVERT(bit,1)),
 (N'%NIT%',N'default()',CONVERT(nvarchar(1000),NULL),200,CONVERT(bit,1)),
 (N'%DIRECCION%',N'default()',CONVERT(nvarchar(1000),NULL),200,CONVERT(bit,1)),
 (N'%TEL%',N'default()',CONVERT(nvarchar(1000),NULL),200,CONVERT(bit,1)),
 (N'%TELEFONO%',N'default()',CONVERT(nvarchar(1000),NULL),200,CONVERT(bit,1)),
 (N'%TOKEN%',N'partial(0,"****************",4)',CONVERT(nvarchar(1000),NULL),100,CONVERT(bit,1)),
 (N'%NOMBRE%',N'partial(1,"XXXXXXXXXX",0)',CONVERT(nvarchar(1000),NULL),300,CONVERT(bit,1))
) AS S(Pattern,DdmFunction,ViewMaskExpr,Priority,IsActive) ON S.Pattern=T.Pattern
WHEN NOT MATCHED THEN INSERT(Pattern,DdmFunction,ViewMaskExpr,Priority,IsActive)
VALUES(S.Pattern,S.DdmFunction,S.ViewMaskExpr,S.Priority,S.IsActive);
GO

/* Reemplace el valor y ejecute este bloque para registrar al primer administrador. */
DECLARE @PrimerAdministrador nvarchar(256)=N'DOMINIO\usuario1';
MERGE ofuscador.AuthorizedUsers AS T
USING (SELECT @PrimerAdministrador Principal) AS S ON S.Principal=T.Principal
WHEN MATCHED THEN UPDATE SET IsActive=1,AppRole=N'Administrator',PrincipalType=N'WINDOWS_LOGIN',UpdatedAt=SYSUTCDATETIME()
WHEN NOT MATCHED THEN INSERT(Principal,PrincipalType,AppRole,IsActive,Notes)
 VALUES(S.Principal,N'WINDOWS_LOGIN',N'Administrator',1,N'Administrador inicial');
GO

/* Permisos sugeridos: cree un rol corporativo y conceda solo acceso al esquema. */
IF NOT EXISTS(SELECT 1 FROM sys.database_principals WHERE name=N'OfuscadorTool_AppRole') CREATE ROLE [OfuscadorTool_AppRole];
GRANT SELECT,INSERT,UPDATE,DELETE ON SCHEMA::ofuscador TO [OfuscadorTool_AppRole];
GO
