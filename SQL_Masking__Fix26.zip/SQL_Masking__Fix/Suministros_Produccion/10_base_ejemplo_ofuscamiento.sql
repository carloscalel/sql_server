/*
  Laboratorio OfuscadorTool
  Crea una base de prueba con datos ficticios y reglas de ofuscamiento.
  Ejecutar manualmente como DBA. No usar en producción.
*/
USE [master];
GO
IF DB_ID(N'OfuscadorDemo') IS NULL CREATE DATABASE [OfuscadorDemo];
GO
USE [OfuscadorDemo];
GO
SET NOCOUNT ON;

IF OBJECT_ID(N'dbo.Pedidos',N'U') IS NOT NULL DROP TABLE dbo.Pedidos;
IF OBJECT_ID(N'dbo.Clientes',N'U') IS NOT NULL DROP TABLE dbo.Clientes;
IF OBJECT_ID(N'dbo.Empleados',N'U') IS NOT NULL DROP TABLE dbo.Empleados;
GO
CREATE TABLE dbo.Clientes(
 ClienteId int IDENTITY(1,1) CONSTRAINT PK_Demo_Clientes PRIMARY KEY,
 NombreCompleto nvarchar(120) NOT NULL,
 NumeroTarjeta varchar(19) NULL,
 CuentaBancaria varchar(24) NULL,
 CorreoEmail varchar(150) NULL,
 NIT varchar(20) NULL,
 Direccion nvarchar(250) NULL,
 Telefono varchar(25) NULL,
 FechaNacimiento date NULL,
 ComentarioSensible nvarchar(500) NULL
);
CREATE TABLE dbo.Empleados(
 EmpleadoId int IDENTITY(1,1) CONSTRAINT PK_Demo_Empleados PRIMARY KEY,
 NombreEmpleado nvarchar(120) NOT NULL,
 SalarioMensual decimal(12,2) NOT NULL,
 TokenAcceso varchar(80) NULL,
 TelefonoEmpleado varchar(25) NULL,
 DireccionEmpleado nvarchar(250) NULL
);
CREATE TABLE dbo.Pedidos(
 PedidoId int IDENTITY(1,1) CONSTRAINT PK_Demo_Pedidos PRIMARY KEY,
 ClienteId int NOT NULL,
 Importe decimal(12,2) NOT NULL,
 Impuesto decimal(12,2) NOT NULL,
 ImporteTotal AS (Importe + Impuesto) PERSISTED,
 CONSTRAINT FK_Demo_Pedidos_Clientes FOREIGN KEY(ClienteId) REFERENCES dbo.Clientes(ClienteId)
);
GO
INSERT dbo.Clientes(NombreCompleto,NumeroTarjeta,CuentaBancaria,CorreoEmail,NIT,Direccion,Telefono,FechaNacimiento,ComentarioSensible)
VALUES
(N'Ana Martínez López','4111111111111111','001234567890123456789012','ana.martinez@example.test','1234567-8',N'Zona 10, Ciudad de Guatemala','5555-0101','1988-04-12',N'Cliente preferente'),
(N'Carlos Ramírez Soto','5500000000000004','009876543210987654321098','carlos.ramirez@example.test','9876543-2',N'Zona 14, Ciudad de Guatemala','5555-0102','1979-11-28',N'No llamar por la tarde'),
(N'Lucía Gómez Pérez','340000000000009','004444333322221111000099','lucia.gomez@example.test','4567890-1',N'Quetzaltenango','5555-0103','1992-07-05',N'Información ficticia');
INSERT dbo.Empleados(NombreEmpleado,SalarioMensual,TokenAcceso,TelefonoEmpleado,DireccionEmpleado)
VALUES
(N'Roberto Castillo',18500.00,'tok-demo-001','5555-1001',N'Zona 1, Guatemala'),
(N'María López',12750.50,'tok-demo-002','5555-1002',N'Zona 4, Guatemala');
INSERT dbo.Pedidos(ClienteId,Importe,Impuesto) VALUES (1,1200,144),(2,850,102),(3,2400,288);
GO

/* Tabla compatible con 02_deploy_all.sql para patrones editables del laboratorio. */
IF OBJECT_ID(N'dbo.Masked_Patterns',N'U') IS NULL
CREATE TABLE dbo.Masked_Patterns(
 Pattern nvarchar(128) NOT NULL PRIMARY KEY,
 DdmFunction nvarchar(200) NOT NULL,
 ViewMaskExpr nvarchar(1000) NULL
);
DELETE dbo.Masked_Patterns;
INSERT dbo.Masked_Patterns(Pattern,DdmFunction,ViewMaskExpr) VALUES
(N'%TARJETA%',N'partial(0,"XXXXXXXXXXXXXXX",4)',NULL),
(N'%CUENTA%',N'partial(0,"XXXXXXXXXXXX",4)',NULL),
(N'%EMAIL%',N'email()',NULL),
(N'%NIT%',N'default()',NULL),
(N'%DIRECCION%',N'default()',NULL),
(N'%TEL%',N'default()',NULL),
(N'%TELEFONO%',N'default()',NULL),
(N'%TOKEN%',N'partial(0,"****************",4)',NULL),
(N'%NOMBRE%',N'partial(1,"XXXXXXXXXX",0)',NULL);
GO
/* Consulta de verificación antes de ejecutar desde la aplicación. */
SELECT * FROM dbo.Clientes;
SELECT * FROM dbo.Empleados;
SELECT * FROM dbo.Pedidos;
SELECT Pattern,DdmFunction FROM dbo.Masked_Patterns ORDER BY Pattern;
GO
