# Suministros de producción

Ejecute `00_instalacion_adminDB.sql` manualmente como DBA en `adminDB`. Reemplace `DOMINIO\usuario1` por el primer administrador autorizado y asigne ese login al rol `OfuscadorTool_AppRole`.

El catálogo central de patrones es `adminDB.ofuscador.MaskPatterns`. El aplicativo lee, agrega, edita y elimina patrones exclusivamente en esa tabla del servidor pivote. Las reglas activas de ese catálogo se sincronizan durante cada despliegue hacia `dbo.Masked_Patterns` en las bases seleccionadas.

El aplicativo no crea bases, esquemas, tablas, índices, roles ni usuarios administrativos.
Las tablas `ofuscador.MaskProfiles`, `ofuscador.MaskProfileColumns` y `ofuscador.MaskProfileUsers` son el catálogo DBA de perfiles: guardan el esquema destino, columnas con reglas especiales y usuarios asignados.
