/* ===========================================================
   04_policy_by_table.sql  (v4 - Respeta sysadmin, db_owner y excluidos)
   - rol_app_lectura: vistas masked + tablas con DDM + tablas sin cambios
   - rol_app_bloqueo_dbo: SOLO tablas que tienen vista masked
   - EXCLUYE: sysadmin, db_owner, lista de excluidos
   - Los usuarios excluidos NO son agregados a ningún rol
   ===========================================================*/
SET NOCOUNT ON; SET XACT_ABORT ON;

DECLARE @IncludeDml BIT = 0;
DECLARE @Excluidos TABLE(UserName SYSNAME COLLATE DATABASE_DEFAULT PRIMARY KEY);
-- agrega especiales a excluir (estos usuarios NO serán tocados)
INSERT INTO @Excluidos VALUES 
    (N'svc_replicacion'),
    (N'svc_backup'),
    (N'svc_monitoreo');

-- Crear roles si no existen
IF NOT EXISTS (SELECT 1 FROM sys.database_principals WHERE name=N'rol_app_lectura')     CREATE ROLE rol_app_lectura;
IF NOT EXISTS (SELECT 1 FROM sys.database_principals WHERE name=N'rol_app_dml')         CREATE ROLE rol_app_dml;
IF NOT EXISTS (SELECT 1 FROM sys.database_principals WHERE name=N'rol_app_bloqueo_dbo') CREATE ROLE rol_app_bloqueo_dbo;

-- Permisos base sobre schemas (estos aplican a TODOS los miembros del rol)
BEGIN TRY GRANT SELECT ON SCHEMA::app    TO rol_app_lectura; END TRY BEGIN CATCH END CATCH;
BEGIN TRY GRANT SELECT ON SCHEMA::masked TO rol_app_lectura; END TRY BEGIN CATCH END CATCH;
IF @IncludeDml=1 BEGIN TRY GRANT INSERT,UPDATE,DELETE ON SCHEMA::masked TO rol_app_dml; END TRY BEGIN CATCH END CATCH;

/* ===================================================================
   PASO 1: Identificar tablas y su estado de ofuscación
   =================================================================== */
IF OBJECT_ID('tempdb..#TablasEstado') IS NOT NULL DROP TABLE #TablasEstado;
CREATE TABLE #TablasEstado(
    SchemaName SYSNAME COLLATE DATABASE_DEFAULT,
    TableName SYSNAME COLLATE DATABASE_DEFAULT,
    TieneDDM BIT DEFAULT 0,
    TieneVista BIT DEFAULT 0,
    Estado NVARCHAR(20) COLLATE DATABASE_DEFAULT, -- 'DDM', 'VISTA', 'NINGUNO'
    PRIMARY KEY (SchemaName, TableName)
);

-- Insertar todas las tablas de dbo (excepto las de sistema)
INSERT INTO #TablasEstado (SchemaName, TableName)
SELECT 
    s.name,
    o.name
FROM sys.tables o
JOIN sys.schemas s ON s.schema_id = o.schema_id
WHERE s.name = N'dbo'
    AND o.is_ms_shipped = 0
    AND o.name NOT IN (N'Masked_Audit', N'Masked_Patterns');

-- Marcar tablas con DDM
UPDATE t SET TieneDDM = 1
FROM #TablasEstado t
WHERE EXISTS (
    SELECT 1 
    FROM sys.masked_columns mc
    WHERE mc.object_id = OBJECT_ID(QUOTENAME(t.SchemaName) + '.' + QUOTENAME(t.TableName))
);

-- Marcar tablas con vista en masked
UPDATE t SET TieneVista = 1
FROM #TablasEstado t
WHERE EXISTS (
    SELECT 1 
    FROM sys.views v 
    JOIN sys.schemas s ON s.schema_id = v.schema_id
    WHERE s.name = N'masked' 
        AND v.name COLLATE DATABASE_DEFAULT = t.TableName
);

-- Determinar estado final
UPDATE #TablasEstado SET 
    Estado = CASE 
        WHEN TieneDDM = 1 AND TieneVista = 1 THEN 'AMBOS'
        WHEN TieneDDM = 1 THEN 'DDM'
        WHEN TieneVista = 1 THEN 'VISTA'
        ELSE 'NINGUNO'
    END;

/* ===================================================================
   PASO 2: Limpiar permisos existentes (revocar grants anteriores)
   SOLO para usuarios NO excluidos
   =================================================================== */
DECLARE @sql NVARCHAR(MAX);

-- Revoquar todos los grants SELECT existentes en dbo para rol_app_lectura
SELECT @sql = STUFF((
    SELECT CHAR(13) + N'REVOKE SELECT ON dbo.' + QUOTENAME(o.name) + N' TO rol_app_lectura;'
    FROM sys.objects o
    JOIN sys.schemas s ON s.schema_id = o.schema_id
    WHERE s.name = N'dbo' 
        AND o.type = 'U'
        AND o.name NOT IN (N'Masked_Audit', N'Masked_Patterns')
    FOR XML PATH(''), TYPE
).value('.', 'nvarchar(max)'), 1, 1, '');

IF @sql IS NOT NULL AND LEN(@sql) > 0 
    EXEC sp_executesql @sql;

/* ===================================================================
   PASO 3: Conceder permisos según estado
   =================================================================== */

-- 3.1 GRANT SELECT en tablas dbo para TODAS las tablas (DDM + NINGUNO)
-- Las tablas con VISTA serán bloqueadas por rol_app_bloqueo_dbo
DECLARE @GrantList NVARCHAR(MAX) = '';
SELECT @GrantList = @GrantList + 
    CHAR(13) + N'GRANT SELECT ON dbo.' + QUOTENAME(TableName) + N' TO rol_app_lectura;'
FROM #TablasEstado
WHERE Estado IN ('DDM', 'NINGUNO');  -- Tablas con DDM o sin cambios

IF @GrantList IS NOT NULL AND LEN(@GrantList) > 0
    EXEC sp_executesql @GrantList;

-- 3.2 DENY para tablas con vista (bloquear acceso directo)
DECLARE @DenyList NVARCHAR(MAX) = '';
SELECT @DenyList = @DenyList + 
    CHAR(13) + N'DENY SELECT, INSERT, UPDATE, DELETE ON dbo.' + QUOTENAME(TableName) + N' TO rol_app_bloqueo_dbo;'
FROM #TablasEstado
WHERE TieneVista = 1;  -- Todas las tablas que tienen vista

IF @DenyList IS NOT NULL AND LEN(@DenyList) > 0
    EXEC sp_executesql @DenyList;

-- 3.3 Asegurar que las vistas masked tengan permisos SELECT
-- (ya tienen por el GRANT en SCHEMA::masked, pero lo reforzamos)
DECLARE @VistaGrant NVARCHAR(MAX) = '';
SELECT @VistaGrant = @VistaGrant + 
    CHAR(13) + N'GRANT SELECT ON masked.' + QUOTENAME(v.name) + N' TO rol_app_lectura;'
FROM sys.views v
JOIN sys.schemas s ON s.schema_id = v.schema_id
WHERE s.name = N'masked'
    AND EXISTS (
        SELECT 1 FROM #TablasEstado t 
        WHERE t.TableName = v.name COLLATE DATABASE_DEFAULT
    );

IF @VistaGrant IS NOT NULL AND LEN(@VistaGrant) > 0
    EXEC sp_executesql @VistaGrant;

/* ===================================================================
   PASO 4: Identificar usuarios objetivo (EXCLUYENDO sysadmin, db_owner, excluidos)
   =================================================================== */
IF OBJECT_ID('tempdb..#UsuariosObjetivo') IS NOT NULL DROP TABLE #UsuariosObjetivo;
CREATE TABLE #UsuariosObjetivo(
    UserName SYSNAME COLLATE DATABASE_DEFAULT PRIMARY KEY,
    EsSysAdmin BIT DEFAULT 0,
    EsDBOwner BIT DEFAULT 0,
    EstaExcluido BIT DEFAULT 0,
    MotivoExclusion NVARCHAR(100) COLLATE DATABASE_DEFAULT NULL
);

-- Obtener todos los usuarios de BD
WITH db_users AS (
    SELECT dp.name, dp.sid, dp.principal_id
    FROM sys.database_principals dp
    WHERE dp.type IN ('S','U','E')  -- SQL User, Windows User, External User
        AND dp.principal_id > 4
        AND dp.name NOT IN (N'dbo', N'guest', N'sys', N'INFORMATION_SCHEMA')
),
-- Identificar miembros de db_owner
db_owners AS (
    SELECT DISTINCT m.member_principal_id
    FROM sys.database_role_members m
    JOIN sys.database_principals r ON r.principal_id = m.role_principal_id
    WHERE r.name = N'db_owner'
),
-- Identificar sysadmins (desde el servidor)
sysadmins AS (
    SELECT DISTINCT sp.sid
    FROM sys.server_role_members srm
    JOIN sys.server_principals sr ON sr.principal_id = srm.role_principal_id AND sr.name = N'sysadmin'
    JOIN sys.server_principals sp ON sp.principal_id = srm.member_principal_id
)
INSERT INTO #UsuariosObjetivo (UserName, EsSysAdmin, EsDBOwner, EstaExcluido, MotivoExclusion)
SELECT 
    u.name,
    CASE WHEN sa.sid IS NOT NULL THEN 1 ELSE 0 END AS EsSysAdmin,
    CASE WHEN do.member_principal_id IS NOT NULL THEN 1 ELSE 0 END AS EsDBOwner,
    CASE WHEN ex.UserName IS NOT NULL THEN 1 ELSE 0 END AS EstaExcluido,
    CASE 
        WHEN ex.UserName IS NOT NULL THEN N'Usuario en lista de excluidos'
        WHEN sa.sid IS NOT NULL THEN N'Usuario es sysadmin'
        WHEN do.member_principal_id IS NOT NULL THEN N'Usuario es miembro de db_owner'
        ELSE NULL
    END AS MotivoExclusion
FROM db_users u
LEFT JOIN db_owners do ON do.member_principal_id = u.principal_id
LEFT JOIN sysadmins sa ON sa.sid = u.sid
LEFT JOIN @Excluidos ex ON ex.UserName = u.name COLLATE DATABASE_DEFAULT;

/* ===================================================================
   PASO 5: Onboarding SOLO para usuarios NO excluidos
   =================================================================== */
DECLARE @u SYSNAME;
DECLARE @motivo NVARCHAR(100);
DECLARE curUser CURSOR LOCAL FAST_FORWARD FOR 
    SELECT UserName, MotivoExclusion 
    FROM #UsuariosObjetivo
    WHERE EsSysAdmin = 0 
        AND EsDBOwner = 0 
        AND EstaExcluido = 0;

OPEN curUser; 
FETCH NEXT FROM curUser INTO @u, @motivo;

PRINT '========================================';
PRINT 'PROCESANDO USUARIOS NO EXCLUIDOS';
PRINT '========================================';

WHILE @@FETCH_STATUS = 0
BEGIN
    BEGIN TRY
        PRINT 'Procesando usuario: ' + @u;
        
        -- Crear usuario si no existe (por si acaso)
        IF NOT EXISTS (SELECT 1 FROM sys.database_principals WHERE name = @u)
        BEGIN
            EXEC('CREATE USER [' + @u + '] FOR LOGIN [' + @u + '];');
            PRINT '  - Usuario creado en BD';
        END
        
        -- Asignar esquema default
        EXEC('ALTER USER [' + @u + '] WITH DEFAULT_SCHEMA = app;');
        PRINT '  - Default schema: app';
        
        -- Remover roles genéricos (si existen)
        BEGIN TRY 
            EXEC sp_droprolemember 'db_datareader', @u; 
            PRINT '  - Removido de db_datareader';
        END TRY BEGIN CATCH END CATCH;
        
        BEGIN TRY 
            EXEC sp_droprolemember 'db_datawriter', @u; 
            PRINT '  - Removido de db_datawriter';
        END TRY BEGIN CATCH END CATCH;
        
        -- Agregar al rol de lectura (siempre)
        EXEC sp_addrolemember 'rol_app_lectura', @u;
        PRINT '  - Agregado a rol_app_lectura';
        
        -- Agregar al rol de bloqueo SOLO si hay tablas con vistas
        IF EXISTS (SELECT 1 FROM #TablasEstado WHERE TieneVista = 1)
        BEGIN
            EXEC sp_addrolemember 'rol_app_bloqueo_dbo', @u;
            PRINT '  - Agregado a rol_app_bloqueo_dbo (hay vistas)';
        END
        
        -- Permisos DML si aplica
        IF @IncludeDml = 1 
        BEGIN
            EXEC sp_addrolemember 'rol_app_dml', @u;
            PRINT '  - Agregado a rol_app_dml';
        END
        
        -- Registrar en auditoría
        INSERT INTO dbo.Masked_Audit (EventType, ObjectName, Action, Detail)
        VALUES (N'INFO', @u, N'USER_ONBOARDING', N'Usuario agregado a roles correctamente');
        
        PRINT '  - ✓ Procesado exitosamente';
        PRINT '';
        
    END TRY
    BEGIN CATCH
        PRINT '  - ✗ ERROR con ' + @u + ': ' + ERROR_MESSAGE();
        INSERT INTO dbo.Masked_Audit (EventType, ObjectName, Action, Detail)
        VALUES (N'ERROR', @u, N'USER_ONBOARDING', ERROR_MESSAGE());
    END CATCH;
    
    FETCH NEXT FROM curUser INTO @u, @motivo;
END
CLOSE curUser; DEALLOCATE curUser;

/* ===================================================================
   PASO 6: Reporte de usuarios EXCLUIDOS (solo informativo)
   =================================================================== */
PRINT '========================================';
PRINT 'USUARIOS EXCLUIDOS (NO PROCESADOS)';
PRINT '========================================';

SELECT 
    UserName,
    MotivoExclusion,
    CASE 
        WHEN EsSysAdmin = 1 THEN 'SYSADMIN'
        WHEN EsDBOwner = 1 THEN 'DB_OWNER'
        WHEN EstaExcluido = 1 THEN 'EXCLUIDO MANUAL'
    END AS TipoExclusion
FROM #UsuariosObjetivo
WHERE EsSysAdmin = 1 
    OR EsDBOwner = 1 
    OR EstaExcluido = 1
ORDER BY TipoExclusion, UserName;

/* ===================================================================
   PASO 7: Reporte final de tablas y permisos
   =================================================================== */
PRINT '========================================';
PRINT 'REPORTE DE OFUSCACIÓN POR TABLA';
PRINT '========================================';

SELECT 
    TableName,
    CASE 
        WHEN Estado = 'DDM' THEN 'DDM Directo (ALTER MASKED)'
        WHEN Estado = 'VISTA' THEN 'Vista Enmascarada (Tabla bloqueada)'
        WHEN Estado = 'AMBOS' THEN 'DDM + Vista (Recomendado revisar)'
        WHEN Estado = 'NINGUNO' THEN 'Sin ofuscación'
    END AS EstadoOfuscacion,
    CASE 
        WHEN TieneVista = 1 THEN 'BLOQUEADA (rol_app_bloqueo_dbo)'
        ELSE 'ACCESIBLE (rol_app_lectura)'
    END AS AccesoDirecto
FROM #TablasEstado
ORDER BY 
    CASE Estado 
        WHEN 'NINGUNO' THEN 4
        WHEN 'DDM' THEN 1
        WHEN 'VISTA' THEN 2
        WHEN 'AMBOS' THEN 3
    END,
    TableName;

PRINT '========================================';
PRINT 'RESUMEN EJECUCIÓN';
PRINT '========================================';

SELECT 
    'Usuarios procesados' AS Concepto,
    COUNT(*) AS Cantidad
FROM #UsuariosObjetivo
WHERE EsSysAdmin = 0 
    AND EsDBOwner = 0 
    AND EstaExcluido = 0
UNION ALL
SELECT 
    'Usuarios excluidos (sysadmin/db_owner/lista)' AS Concepto,
    COUNT(*) AS Cantidad
FROM #UsuariosObjetivo
WHERE EsSysAdmin = 1 
    OR EsDBOwner = 1 
    OR EstaExcluido = 1
UNION ALL
SELECT 
    'Tablas con DDM' AS Concepto,
    COUNT(*) AS Cantidad
FROM #TablasEstado
WHERE Estado = 'DDM'
UNION ALL
SELECT 
    'Tablas con Vista' AS Concepto,
    COUNT(*) AS Cantidad
FROM #TablasEstado
WHERE Estado = 'VISTA'
UNION ALL
SELECT 
    'Tablas sin cambios' AS Concepto,
    COUNT(*) AS Cantidad
FROM #TablasEstado
WHERE Estado = 'NINGUNO';
