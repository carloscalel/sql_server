using Microsoft.Data.SqlClient;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Data;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;

namespace OfuscadorTool;

public partial class MainWindow : Window
{
    private readonly DatabaseService _db;
    private readonly DeploymentService _deployment;
    private readonly bool _isAdministrator;
    private ICollectionView? _serversView;
    private ICollectionView? _patternsView;
    private ICollectionView? _authorizedUsersView;
    public ObservableCollection<ServerProfile> Servers { get; set; } = [];
    public ObservableCollection<DatabaseTarget> Targets { get; } = [];
    public ObservableCollection<DeploymentTreeNode> ServerNodes { get; } = [];
    public ObservableCollection<DeploymentTreeNode> ExcludedNodes { get; } = [];
    public ObservableCollection<DeploymentTreeNode> FilteredServerNodes { get; } = [];
    public ObservableCollection<DeploymentTreeNode> FilteredExcludedNodes { get; } = [];
    public ObservableCollection<MaskPattern> Patterns { get; set; } = [];
    public ObservableCollection<AuthorizedUser> Users { get; set; } = [];
    public ObservableCollection<ExecutionRow> ExecutionRows { get; } = [];

    public MainWindow(LoginContext context)
    {
        InitializeComponent();
        _db = new(context); _deployment = new(_db);
        _isAdministrator = string.Equals(context.Role, "Administrator", StringComparison.OrdinalIgnoreCase);
        AuthorizedUsersButton.Visibility = _isAdministrator ? Visibility.Visible : Visibility.Collapsed;
        _deployment.Log += text => Dispatcher.Invoke(() =>
        {
            LogBox.AppendText(text + Environment.NewLine); LogBox.ScrollToEnd();
        });
        PrincipalText.Text = context.Principal;
        DashboardPrincipalText.Text = context.Principal;
        DashboardRoleText.Text = context.Role;
        RoleColumn.ItemsSource = new[] { "Administrator", "Operator", "Auditor" };
        PatternPriorityColumn.ItemsSource = new[] { "Bajo", "Medio", "Alto" };
        DataContext = this;
        Loaded += async (_, _) => await LoadInitialAsync();
    }

    private async Task LoadInitialAsync()
    {
        Servers = await _db.LoadServersAsync(); Patterns = await _db.LoadPatternsAsync(); Users = await _db.LoadUsersAsync();
        ConfigureServersView(); ConfigurePatternsView(); ConfigureAuthorizedUsersView();
        await _db.AuditAsync("Resumen", "Abrir", true);
    }

    private async void Navigate(object sender, RoutedEventArgs e)
    {
        var index = int.Parse((string)((Button)sender).Tag);
        if (index == 5 && !_isAdministrator) return;
        Pages.SelectedIndex = index;
        var names = new[] { "Resumen", "Ofuscamiento", "Rollback", "Servidores", "Reglas", "Usuarios autorizados", "Auditoría" };
        try
        {
            await _db.AuditAsync(names[index], "Abrir", true);
            if (index == 2) await LoadRollbackAsync();
            if (index == 6) AuditGrid.ItemsSource = (await _db.LoadAuditAsync()).DefaultView;
        }
        catch (Exception ex) { MessageBox.Show(ex.Message, "Error", MessageBoxButton.OK, MessageBoxImage.Error); }
    }

    private void OpenProfilesClick(object sender, RoutedEventArgs e)
    {
        if (string.Equals(_db.Context.Role, "Auditor", StringComparison.OrdinalIgnoreCase)) return;
        new ProfileWindow(_db, _deployment, Servers, Patterns) { Owner = this }.ShowDialog();
    }

    private async void LoadTargetsClick(object sender, RoutedEventArgs e)
    {
        if (!await TryLoadTargetsAsync()) return;
    }

    private async Task<bool> TryLoadTargetsAsync()
    {
        var progress = new ProgressDialog("Cargar servidores y bases") { Owner = this };
        IsEnabled = false; progress.Show();
        Targets.Clear(); ServerNodes.Clear(); ExcludedNodes.Clear();
        FilteredServerNodes.Clear(); FilteredExcludedNodes.Clear();
        try
        {
            var activeServers = Servers.Where(s => s.IsActive).ToList();
            var serverIndex = 0;
            foreach (var server in activeServers)
            {
                serverIndex++;
                progress.UpdateProgress(serverIndex - 1, activeServers.Count, $"Cargando bases de {server.Name}...");
                var serverNode = new DeploymentTreeNode { DisplayName = $"{server.Name}  ({server.DataSource})", Kind = "server", Server = server };
                foreach (var database in await _db.LoadDatabasesAsync(server))
                {
                    var target = new DatabaseTarget { Server = server, Database = database };
                    Targets.Add(target);
                    serverNode.Children.Add(new DeploymentTreeNode { DisplayName = database, Kind = "database", Server = server, Target = target });
                }
                ServerNodes.Add(serverNode);
            }
            ApplyTargetFilter();
            await _db.AuditAsync("Ofuscamiento", "Cargar bases", true, $"{Targets.Count} bases");
            progress.UpdateProgress(activeServers.Count, activeServers.Count, $"Completado: {Targets.Count} bases disponibles");
            await Task.Delay(250);
            return true;
        }
        catch (Exception ex) { await _db.AuditAsync("Ofuscamiento", "Cargar bases", false, ex.Message); ShowError(ex); return false; }
        finally { progress.Close(); IsEnabled = true; }
    }

    private async void LoadPrincipalsClick(object sender, RoutedEventArgs e)
    {
        var progress = new ProgressDialog("Cargar usuarios de las bases seleccionadas") { Owner = this };
        IsEnabled = false; progress.Show();
        try
        {
            var targets = Targets.Where(t => t.IsSelected).ToList();
            if (targets.Count == 0) { MessageBox.Show("Selecciona una o varias bases antes de cargar sus usuarios."); return; }
            ExcludedNodes.Clear();
            foreach (var server in Servers.Where(s => s.IsActive))
                ExcludedNodes.Add(new DeploymentTreeNode { DisplayName = $"{server.Name}  ({server.DataSource})", Kind = "excluded-server", Server = server });
            if (targets.Count == 0) { MessageBox.Show("Selecciona una o varias bases en la sección 1 antes de cargar sus usuarios."); return; }
            var targetIndex = 0;
            foreach (var target in targets)
            {
                targetIndex++;
                progress.UpdateProgress(targetIndex - 1, targets.Count, $"Consultando usuarios: {target.Server.Name}/{target.Database}");
                var serverNode = ExcludedNodes.FirstOrDefault(n => ReferenceEquals(n.Server, target.Server));
                if (serverNode is null) continue;
                var node = new DeploymentTreeNode { DisplayName = target.Database, Kind = "excluded-database", Server = target.Server, Target = target };
                serverNode.Children.Add(node);
                var users = await _db.LoadPrincipalsAsync(target.Server, target.Database);
                target.Principals.Clear();
                node.Children.Clear();
                foreach (var user in users)
                {
                    target.Principals.Add(user);
                    node.Children.Add(new DeploymentTreeNode { DisplayName = $"{user.Name}  [{user.Type}]" + (user.IsProtected ? "  · protegido" : ""), Kind = "user", Server = target.Server, Target = target, Principal = user, IsChecked = user.IsExcluded });
                }
            }
            ApplyTargetFilter();
            ApplyExcludedUserFilter();
            await _db.AuditAsync("Ofuscamiento", "Cargar usuarios", true, null);
            progress.UpdateProgress(targets.Count, targets.Count, $"Completado: {targets.Count} base(s)");
            await Task.Delay(250);
        }
        catch (Exception ex) { ShowError(ex); }
        finally { progress.Close(); IsEnabled = true; }
    }

    private void TreeCheckChanged(object sender, RoutedEventArgs e)
    {
        if (sender is not CheckBox check || check.DataContext is not DeploymentTreeNode node) return;
        var value = check.IsChecked == true;
        if (node.Kind == "server")
        {
            foreach (var target in Targets.Where(x => ReferenceEquals(x.Server, node.Server)))
                target.IsSelected = value;
            foreach (var database in node.Children) database.IsChecked = value;
        }
        else if (node.Kind == "database" && node.Target is not null) node.Target.IsSelected = value;
        else if (node.Kind == "excluded-server")
        {
            foreach (var target in Targets.Where(x => ReferenceEquals(x.Server, node.Server)))
                foreach (var principal in target.Principals)
                    principal.IsExcluded = principal.IsProtected || value;
            foreach (var database in node.Children)
                foreach (var user in database.Children)
                    user.IsChecked = user.Principal?.IsProtected == true || value;
        }
        else if (node.Kind == "excluded-database" && node.Target is not null)
        {
            foreach (var principal in node.Target.Principals)
                principal.IsExcluded = principal.IsProtected || value;
            foreach (var user in node.Children)
                user.IsChecked = user.Principal?.IsProtected == true || value;
        }
        else if (node.Kind == "user" && node.Principal is not null)
        {
            node.Principal.IsExcluded = node.Principal.IsProtected || value;
            node.IsChecked = node.Principal.IsExcluded;
        }
    }

    private void TargetFilterChanged(object sender, TextChangedEventArgs e) => ApplyTargetFilter();

    private void ExcludedUserFilterChanged(object sender, TextChangedEventArgs e) => ApplyExcludedUserFilter();

    private void ApplyTargetFilter()
    {
        if (FilteredServerNodes is null) return;
        var filter = TargetFilterBox?.Text?.Trim() ?? "";
        FilteredServerNodes.Clear();
        foreach (var sourceServer in ServerNodes)
        {
            var serverMatches = Matches(sourceServer.DisplayName, filter);
            var databases = sourceServer.Children
                .Where(x => serverMatches || Matches(x.DisplayName, filter))
                .ToList();
            if (!serverMatches && databases.Count == 0) continue;

            var serverNode = new DeploymentTreeNode
            {
                DisplayName = sourceServer.DisplayName,
                Kind = sourceServer.Kind,
                Server = sourceServer.Server,
                IsChecked = Targets.Where(x => ReferenceEquals(x.Server, sourceServer.Server)).Any()
                    && Targets.Where(x => ReferenceEquals(x.Server, sourceServer.Server)).All(x => x.IsSelected)
            };
            foreach (var database in databases)
                serverNode.Children.Add(new DeploymentTreeNode
                {
                    DisplayName = database.DisplayName,
                    Kind = database.Kind,
                    Server = database.Server,
                    Target = database.Target,
                    IsChecked = database.Target?.IsSelected == true
                });
            FilteredServerNodes.Add(serverNode);
        }
    }

    private void ApplyExcludedUserFilter()
    {
        if (FilteredExcludedNodes is null) return;
        var filter = ExcludedUserFilterBox?.Text?.Trim() ?? "";
        FilteredExcludedNodes.Clear();
        foreach (var sourceServer in ExcludedNodes)
        {
            var serverNode = new DeploymentTreeNode
            {
                DisplayName = sourceServer.DisplayName,
                Kind = sourceServer.Kind,
                Server = sourceServer.Server
            };
            foreach (var sourceDatabase in sourceServer.Children)
            {
                var users = sourceDatabase.Children
                    .Where(x => Matches(x.DisplayName, filter))
                    .ToList();
                if (users.Count == 0 && !string.IsNullOrWhiteSpace(filter)) continue;
                var databaseNode = new DeploymentTreeNode
                {
                    DisplayName = sourceDatabase.DisplayName,
                    Kind = sourceDatabase.Kind,
                    Server = sourceDatabase.Server,
                    Target = sourceDatabase.Target,
                    IsChecked = sourceDatabase.Target?.Principals.Count > 0
                        && sourceDatabase.Target.Principals.All(x => x.IsExcluded)
                };
                foreach (var user in users)
                    databaseNode.Children.Add(new DeploymentTreeNode
                    {
                        DisplayName = user.DisplayName,
                        Kind = user.Kind,
                        Server = user.Server,
                        Target = user.Target,
                        Principal = user.Principal,
                        IsChecked = user.Principal?.IsExcluded == true
                    });
                serverNode.Children.Add(databaseNode);
            }
            if (serverNode.Children.Count > 0)
            {
                serverNode.IsChecked = serverNode.Children.All(x => x.IsChecked);
                FilteredExcludedNodes.Add(serverNode);
            }
        }
    }

    private static bool Matches(string value, string filter) =>
        string.IsNullOrWhiteSpace(filter) || value.Contains(filter, StringComparison.OrdinalIgnoreCase);

    private void ReviewClick(object sender, RoutedEventArgs e)
    {
        var selected = Targets.Where(t => t.IsSelected).ToList();
        var text = $"MODO: {(DryRunBox.IsChecked == true ? "SIMULACIÓN (sin cambios)" : "DESPLIEGUE REAL")}\n\n" +
                   $"DESTINOS ({selected.Count}):\n" + string.Join("\n", selected.Select(t => $" • {t.Server.Name} / {t.Database} — excluidos: {t.Principals.Count(p => p.IsExcluded)}")) +
                   $"\n\nPATRONES ACTIVOS: {Patterns.Count(p => p.IsActive)}\n" +
                   "PROTECCIÓN AUTOMÁTICA: sysadmin, db_owner y owner siempre quedan excluidos.";
        MessageBox.Show(text, "Revisión previa", MessageBoxButton.OK, MessageBoxImage.Information);
    }

    private async void ExecuteClick(object sender, RoutedEventArgs e)
    {
        var selected = Targets.Where(t => t.IsSelected).ToList();
        if (selected.Count == 0) { MessageBox.Show("Selecciona al menos una base."); return; }
        var dry = DryRunBox.IsChecked == true;
        if (MessageBox.Show($"Se ejecutará {(dry ? "una simulación" : "el despliegue REAL")} en {selected.Count} base(s). ¿Continuar?",
            "Confirmar ejecución", MessageBoxButton.YesNo, dry ? MessageBoxImage.Question : MessageBoxImage.Warning) != MessageBoxResult.Yes) return;
        ExecuteButton.IsEnabled = false; ExecutionRows.Clear(); LogBox.Clear();
        foreach (var t in selected) ExecutionRows.Add(new() { Server = t.Server.Name, Database = t.Database });
        var executionId = await _db.BeginExecutionAsync(dry ? "Simulation" : "Deploy", selected);
        var failures = 0;
        await Parallel.ForEachAsync(selected, new ParallelOptions { MaxDegreeOfParallelism = 4 }, async (target, _) =>
        {
            var row = ExecutionRows.First(r => r.Server == target.Server.Name && r.Database == target.Database);
            try
            {
                var detail = dry ? await _deployment.SimulateAsync(target, Patterns.Where(p => p.IsActive).ToList())
                                 : await DeployAndReturnAsync(executionId, target);
                await Dispatcher.InvokeAsync(() => { row.Status = "OK"; row.Detail = detail; ExecutionGrid.Items.Refresh(); });
                await _db.UpdateTargetAsync(executionId, target, "OK", detail);
            }
            catch (Exception ex)
            {
                Interlocked.Increment(ref failures);
                await Dispatcher.InvokeAsync(() => { row.Status = "Error"; row.Detail = ex.Message; ExecutionGrid.Items.Refresh(); LogBox.AppendText(ex.Message + "\n"); });
                await _db.UpdateTargetAsync(executionId, target, "Error", ex.ToString());
            }
        });
        var status = failures == 0 ? "Completed" : failures == selected.Count ? "Failed" : "Partial";
        await _db.FinishExecutionAsync(executionId, status, $"{selected.Count - failures} OK; {failures} error(es)");
        await _db.AuditAsync("Ofuscamiento", dry ? "Simular" : "Desplegar", failures == 0, $"ExecutionId={executionId}; {failures} errores");
        ExecuteButton.IsEnabled = true;
        MessageBox.Show($"Ejecución finalizada. {selected.Count - failures} correctas, {failures} con error.", "Finalizado");
    }

    private async Task<string> DeployAndReturnAsync(Guid id, DatabaseTarget target)
    {
        await _deployment.DeployAsync(id, target, Patterns.Where(p => p.IsActive).ToList());
        return "Despliegue completado";
    }

    private async void AddServerClick(object sender, RoutedEventArgs e)
    {
        var dialog = new ServerDialog(new ServerProfile { Name = "Nuevo servidor", Host = "localhost", Encrypt = true }) { Owner = this };
        if (dialog.ShowDialog() != true) return;
        try
        {
            var item = dialog.Server;
            if (!item.UseWindowsAuth && !string.IsNullOrEmpty(item.PlainPassword)) item.EncryptedPassword = SecurityService.Protect(item.PlainPassword);
            await _db.SaveServerAsync(item);
            Servers = await _db.LoadServersAsync(); ConfigureServersView();
            await _db.AuditAsync("Servidores", "Agregar", true, item.Name);
        }
        catch (Exception ex) { ShowError(ex); }
    }

    private async void EditServerClick(object sender, RoutedEventArgs e)
    {
        if (ServersGrid.SelectedItem is not ServerProfile server) { MessageBox.Show("Selecciona un servidor."); return; }
        var dialog = new ServerDialog(server) { Owner = this };
        if (dialog.ShowDialog() != true) return;
        try { await SaveServerProfileAsync(dialog.Server, "Editar"); }
        catch (Exception ex) { ShowError(ex); }
    }

    private async void SaveServerClick(object sender, RoutedEventArgs e)
    {
        if (ServersGrid.SelectedItem is not ServerProfile server) return;
        try
        {
            if (!server.UseWindowsAuth)
            {
                var dialog = new PasswordDialog { Owner = this };
                if (dialog.ShowDialog() == true && !string.IsNullOrEmpty(dialog.Password)) server.EncryptedPassword = SecurityService.Protect(dialog.Password);
            }
            await SaveServerProfileAsync(server, "Guardar");
        }
        catch (Exception ex) { ShowError(ex); }
    }

    private async Task SaveServerProfileAsync(ServerProfile server, string action)
    {
        if (!server.UseWindowsAuth && !string.IsNullOrEmpty(server.PlainPassword)) server.EncryptedPassword = SecurityService.Protect(server.PlainPassword);
        await _db.SaveServerAsync(server); Servers = await _db.LoadServersAsync(); ConfigureServersView();
        await _db.AuditAsync("Servidores", action, true, server.Name);
    }

    private async void TestServerClick(object sender, RoutedEventArgs e)
    {
        if (ServersGrid.SelectedItem is not ServerProfile server) return;
        try { await using var cn = new SqlConnection(_db.TargetConnection(server)); await cn.OpenAsync(); MessageBox.Show("Conexión exitosa."); }
        catch (Exception ex) { ShowError(ex); }
    }

    private async void DeleteServerClick(object sender, RoutedEventArgs e)
    {
        if (ServersGrid.SelectedItem is not ServerProfile server) return;
        if (server.Id > 0) await _db.DeleteServerAsync(server.Id);
        Servers.Remove(server);
        _serversView?.Refresh();
        UpdateServersCount();
    }

    private void ConfigureServersView()
    {
        _serversView = CollectionViewSource.GetDefaultView(Servers);
        _serversView.Filter = FilterServer;
        ServersGrid.ItemsSource = _serversView;
        UpdateServersCount();
    }

    private bool FilterServer(object item)
    {
        if (item is not ServerProfile server) return false;
        var filter = ServerFilterBox?.Text?.Trim();
        return string.IsNullOrWhiteSpace(filter)
            || server.Name.Contains(filter, StringComparison.OrdinalIgnoreCase)
            || server.Host.Contains(filter, StringComparison.OrdinalIgnoreCase)
            || server.Instance.Contains(filter, StringComparison.OrdinalIgnoreCase)
            || server.SqlUser.Contains(filter, StringComparison.OrdinalIgnoreCase);
    }

    private void ServerFilterChanged(object sender, TextChangedEventArgs e)
    {
        _serversView?.Refresh();
        UpdateServersCount();
    }

    private void UpdateServersCount()
    {
        if (ServersCountText is null) return;
        var visible = _serversView?.Cast<object>().Count() ?? Servers.Count;
        ServersCountText.Text = $"{visible} de {Servers.Count} servidores";
        UpdateDashboardSummary();
    }

    private void AddPatternClick(object sender, RoutedEventArgs e)
    {
        PatternFilterBox.Text = "";
        Patterns.Add(new() { Pattern = "%NUEVO%", Priority = "Medio" });
        _patternsView?.Refresh();
        UpdatePatternsCount();
        PatternsGrid.SelectedItem = Patterns.Last();
        PatternsGrid.ScrollIntoView(Patterns.Last());
    }
    private void DeletePatternClick(object sender, RoutedEventArgs e)
    {
        if (PatternsGrid.SelectedItem is MaskPattern pattern)
        {
            Patterns.Remove(pattern);
            _patternsView?.Refresh();
            UpdatePatternsCount();
        }
        else MessageBox.Show("Selecciona una regla para eliminar.");
    }
    private async void SavePatternsClick(object sender, RoutedEventArgs e)
    {
        await _db.SavePatternsAsync(Patterns); await _db.AuditAsync("Reglas", "Guardar", true, $"{Patterns.Count} reglas"); UpdatePatternsCount(); MessageBox.Show("Reglas guardadas.");
    }

    private void ConfigurePatternsView()
    {
        _patternsView = CollectionViewSource.GetDefaultView(Patterns);
        _patternsView.Filter = FilterPattern;
        PatternsGrid.ItemsSource = _patternsView;
        UpdatePatternsCount();
    }

    private bool FilterPattern(object item)
    {
        if (item is not MaskPattern pattern) return false;
        var filter = PatternFilterBox?.Text?.Trim();
        return string.IsNullOrWhiteSpace(filter)
            || pattern.Pattern.Contains(filter, StringComparison.OrdinalIgnoreCase)
            || pattern.DdmFunction.Contains(filter, StringComparison.OrdinalIgnoreCase)
            || (pattern.ViewMaskExpr?.Contains(filter, StringComparison.OrdinalIgnoreCase) ?? false)
            || pattern.Priority.Contains(filter, StringComparison.OrdinalIgnoreCase);
    }

    private void PatternFilterChanged(object sender, TextChangedEventArgs e)
    {
        _patternsView?.Refresh();
        UpdatePatternsCount();
    }

    private void UpdatePatternsCount()
    {
        if (PatternsCountText is null) return;
        var visible = _patternsView?.Cast<object>().Count() ?? Patterns.Count;
        var active = Patterns.Count(x => x.IsActive);
        PatternsCountText.Text = $"{visible} de {Patterns.Count} · {active} activas";
        UpdateDashboardSummary();
    }
    private async void LoadUsersClick(object sender, RoutedEventArgs e)
    {
        try { Users = await _db.LoadUsersAsync(); ConfigureAuthorizedUsersView(); }
        catch (Exception ex) { ShowError(ex); }
    }

    private async void AddUserClick(object sender, RoutedEventArgs e)
    {
        if (!_isAdministrator) return;
        try
        {
            var existing = Users.Select(u => u.Principal).ToHashSet(StringComparer.OrdinalIgnoreCase);
            var dialog = new AddAuthorizedUsersDialog(_db, existing) { Owner = this };
            if (dialog.ShowDialog() != true) return;
            foreach (var option in dialog.SelectedUsers)
                Users.Add(new() { Principal = option.Login, PrincipalType = option.LoginType, Role = option.Role, IsActive = !option.IsDisabled, Notes = option.Notes });
            _authorizedUsersView?.Refresh();
            UpdateAuthorizedUsersCount();
            await _db.AuditAsync("Usuarios autorizados", "Agregar", true, $"{dialog.SelectedUsers.Count} usuarios");
        }
        catch (Exception ex) { ShowError(ex); }
    }
    private async void SaveUsersClick(object sender, RoutedEventArgs e)
    {
        if (!_isAdministrator) return;
        if (!Users.Any(u => u.Principal.Equals(_db.Context.Principal, StringComparison.OrdinalIgnoreCase) && u.IsActive))
        { MessageBox.Show("No puedes desactivar o eliminar tu propia identidad."); return; }
        await _db.SaveUsersAsync(Users); await _db.AuditAsync("Usuarios autorizados", "Guardar", true, $"{Users.Count} usuarios"); UpdateAuthorizedUsersCount(); MessageBox.Show("Usuarios guardados.");
    }

    private void ConfigureAuthorizedUsersView()
    {
        _authorizedUsersView = CollectionViewSource.GetDefaultView(Users);
        _authorizedUsersView.Filter = FilterAuthorizedUser;
        UsersGrid.ItemsSource = _authorizedUsersView;
        UpdateAuthorizedUsersCount();
    }

    private bool FilterAuthorizedUser(object item)
    {
        if (item is not AuthorizedUser user) return false;
        var filter = AuthorizedUserFilterBox?.Text?.Trim();
        return string.IsNullOrWhiteSpace(filter)
            || user.Principal.Contains(filter, StringComparison.OrdinalIgnoreCase)
            || user.PrincipalType.Contains(filter, StringComparison.OrdinalIgnoreCase)
            || user.Role.Contains(filter, StringComparison.OrdinalIgnoreCase);
    }

    private void AuthorizedUserFilterChanged(object sender, TextChangedEventArgs e)
    {
        _authorizedUsersView?.Refresh();
        UpdateAuthorizedUsersCount();
    }

    private void UpdateAuthorizedUsersCount()
    {
        if (AuthorizedUsersCountText is null) return;
        var visible = _authorizedUsersView?.Cast<object>().Count() ?? Users.Count;
        AuthorizedUsersCountText.Text = $"{visible} de {Users.Count} usuarios";
        UpdateDashboardSummary();
    }

    private void UpdateDashboardSummary()
    {
        if (DashboardServersCount is null) return;
        DashboardServersCount.Text = Servers.Count.ToString();
        DashboardPatternsCount.Text = Patterns.Count(x => x.IsActive).ToString();
        DashboardUsersCount.Text = Users.Count(x => x.IsActive).ToString();
    }

    private async Task LoadRollbackAsync() => RollbackGrid.ItemsSource = (await _db.LoadDeploymentsAsync()).DefaultView;
    private async void LoadRollbackClick(object sender, RoutedEventArgs e) => await LoadRollbackAsync();
    private async void RollbackSelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (RollbackGrid.SelectedItem is not DataRowView row) { RollbackTargetsGrid.ItemsSource = null; return; }
        var id = (Guid)row["ExecutionId"];
        var rows = await _db.LoadExecutionTargetsAsync(id);
        RollbackTargetsGrid.ItemsSource = rows.Select(x => new RollbackTargetRow { Server = x.Server, Database = x.Database }).ToList();
    }
    private async void RollbackClick(object sender, RoutedEventArgs e)
    {
        if (RollbackGrid.SelectedItem is not DataRowView row) { MessageBox.Show("Selecciona un despliegue."); return; }
        var id = (Guid)row["ExecutionId"];
        if (MessageBox.Show("El rollback modificará todas las bases del despliegue seleccionado. ¿Continuar?", "Confirmar rollback", MessageBoxButton.YesNo, MessageBoxImage.Warning) != MessageBoxResult.Yes) return;
        var serverList = await _db.LoadServersAsync();
        var targets = (RollbackTargetsGrid.ItemsSource as IEnumerable<RollbackTargetRow>)?.Where(x => x.IsSelected).ToList() ?? [];
        if (targets.Count == 0) { MessageBox.Show("Selecciona al menos una base para revertir."); return; }
        foreach (var target in targets)
        {
            var server = serverList.FirstOrDefault(s => s.Name == target.Server);
            if (server is null) continue;
            try { await _deployment.RollbackAsync(id, new() { Server = server, Database = target.Database }); }
            catch (Exception ex) { ShowError(ex); }
        }
        await _db.AuditAsync("Rollback", "Ejecutar", true, $"SourceExecutionId={id}");
        MessageBox.Show("Rollback finalizado. Revisa auditoría y logs.");
    }

    private async void LoadAuditClick(object sender, RoutedEventArgs e) => AuditGrid.ItemsSource = (await _db.LoadAuditAsync()).DefaultView;
    private static void ShowError(Exception ex) => MessageBox.Show(ex.Message, "Error", MessageBoxButton.OK, MessageBoxImage.Error);
}
