using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace OfuscadorTool;

public sealed class ServerProfile
{
    public int Id { get; set; }
    public bool IsActive { get; set; } = true;
    public string Name { get; set; } = "";
    public string Host { get; set; } = "";
    public string Instance { get; set; } = "";
    public bool UseWindowsAuth { get; set; } = true;
    public string SqlUser { get; set; } = "";
    public string EncryptedPassword { get; set; } = "";
    public bool Encrypt { get; set; } = true;
    public bool TrustServerCertificate { get; set; }
    public int TimeoutSeconds { get; set; } = 30;
    public string PlainPassword { get; set; } = "";
    public string DataSource => string.IsNullOrWhiteSpace(Instance) ? Host : $@"{Host}\{Instance}";
}

public sealed class DatabaseTarget
{
    public ServerProfile Server { get; init; } = new();
    public string Database { get; init; } = "";
    public bool IsSelected { get; set; }
    public ObservableCollection<PrincipalChoice> Principals { get; } = [];
}

public sealed class DeploymentTreeNode : INotifyPropertyChanged
{
    private bool _isChecked;

    public string DisplayName { get; init; } = "";
    public string Kind { get; init; } = "";
    public bool IsChecked
    {
        get => _isChecked;
        set
        {
            if (_isChecked == value) return;
            _isChecked = value;
            OnPropertyChanged();
        }
    }
    public ServerProfile? Server { get; init; }
    public DatabaseTarget? Target { get; init; }
    public PrincipalChoice? Principal { get; init; }
    public ObservableCollection<DeploymentTreeNode> Children { get; } = [];

    public event PropertyChangedEventHandler? PropertyChanged;
    private void OnPropertyChanged([CallerMemberName] string? propertyName = null) =>
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
}

public sealed class PrincipalChoice
{
    public string Name { get; init; } = "";
    public string Type { get; init; } = "";
    public bool IsProtected { get; init; }
    public bool IsExcluded { get; set; }
    public string ProtectionReason { get; init; } = "";
}

public sealed class MaskPattern
{
    public string Pattern { get; set; } = "";
    public string DdmFunction { get; set; } = "default()";
    public string? ViewMaskExpr { get; set; }
    public string Priority { get; set; } = "Medio";
    public bool IsActive { get; set; } = true;
}

public sealed class AuthorizedUser
{
    public string Principal { get; set; } = "";
    public string PrincipalType { get; set; } = "SQL_LOGIN";
    public string Role { get; set; } = "Operator";
    public bool IsActive { get; set; } = true;
    public string Notes { get; set; } = "";
}

public sealed class PivotLoginOption
{
    public bool IsSelected { get; set; }
    public string Login { get; init; } = "";
    public string LoginType { get; init; } = "";
    public bool IsDisabled { get; init; }
    public string Role { get; set; } = "Operator";
    public string Notes { get; set; } = "";
}

public sealed class ExecutionRow
{
    public string Server { get; init; } = "";
    public string Database { get; init; } = "";
    public string Status { get; set; } = "Pendiente";
    public string Detail { get; set; } = "";
}

public sealed class RollbackTargetRow
{
    public bool IsSelected { get; set; } = true;
    public string Server { get; init; } = "";
    public string Database { get; init; } = "";
    public string Status { get; init; } = "";
}

public sealed class ProfileColumnRule
{
    public string Schema { get; init; } = "dbo";
    public string Table { get; init; } = "";
    public string Column { get; init; } = "";
    public string DataType { get; init; } = "";
    public string RulePattern { get; set; } = "(predeterminado)";
}

public sealed class MaskProfile
{
    public int ProfileId { get; set; }
    public string ProfileName { get; set; } = "";
    public string ServerName { get; set; } = "";
    public string DatabaseName { get; set; } = "";
    public string TargetSchema { get; set; } = "";
    public bool IsActive { get; set; } = true;
    public ObservableCollection<ProfileColumnRule> Rules { get; } = [];
    public ObservableCollection<string> Users { get; } = [];
}

public sealed record LoginContext(string PivotConnectionString, string Principal, string AdminDatabase, string Role);
