using Microsoft.Data.SqlClient;
using System.Collections.ObjectModel;
using System.Data;
using System.Text;

namespace OfuscadorTool;

public sealed class DatabaseService(LoginContext context)
{
    public LoginContext Context { get; } = context;

    private static SqlConnection Connection(string cs) => new(cs);

    public static string BuildConnection(string source, string database, bool windows, string user, string password,
        bool encrypt, bool trust, int timeout = 30) =>
        new SqlConnectionStringBuilder
        {
            DataSource = source,
            InitialCatalog = database,
            IntegratedSecurity = windows,
            UserID = windows ? "" : user,
            Password = windows ? "" : password,
            Encrypt = encrypt,
            TrustServerCertificate = trust,
            ConnectTimeout = Math.Clamp(timeout, 5, 300),
            ApplicationName = "OfuscadorTool"
        }.ConnectionString;

    public string TargetConnection(ServerProfile server, string database = "master") =>
        BuildConnection(server.DataSource, database, server.UseWindowsAuth, server.SqlUser,
            SecurityService.Unprotect(server.EncryptedPassword), server.Encrypt, server.TrustServerCertificate, server.TimeoutSeconds);

    public async Task ValidateInstallationAsync()
    {
        const string sql = """
        SELECT CASE WHEN SCHEMA_ID(N'ofuscador') IS NULL THEN 0 ELSE 1 END;
        SELECT COUNT(*) FROM (VALUES
          (OBJECT_ID(N'ofuscador.Servers',N'U')),(OBJECT_ID(N'ofuscador.AuthorizedUsers',N'U')),
          (OBJECT_ID(N'ofuscador.MaskPatterns',N'U')),(OBJECT_ID(N'ofuscador.Executions',N'U')),
          (OBJECT_ID(N'ofuscador.ExecutionTargets',N'U')),(OBJECT_ID(N'ofuscador.PermissionBackup',N'U')),
          (OBJECT_ID(N'ofuscador.Audit',N'U')),(OBJECT_ID(N'ofuscador.MaskProfiles',N'U')),
          (OBJECT_ID(N'ofuscador.MaskProfileColumns',N'U')),(OBJECT_ID(N'ofuscador.MaskProfileUsers',N'U'))
        ) RequiredObjects(ObjectId) WHERE ObjectId IS NOT NULL;
        """;
        await using var cn = Connection(Context.PivotConnectionString);
        await cn.OpenAsync();
        await using var cmd = new SqlCommand(sql, cn);
        await using var reader = await cmd.ExecuteReaderAsync();
        if (!await reader.ReadAsync() || reader.GetInt32(0) != 1)
            throw new InvalidOperationException("No existe el esquema [ofuscador]. Un DBA debe ejecutar Suministros_Produccion/00_instalacion_adminDB.sql.");
        await reader.NextResultAsync();
        if (!await reader.ReadAsync() || reader.GetInt32(0) != 10)
            throw new InvalidOperationException("Faltan tablas administrativas. Un DBA debe ejecutar Suministros_Produccion/00_instalacion_adminDB.sql.");
    }

    public async Task<bool> IsAuthorizedAsync()
    {
        var result = await ScalarAsync(Context.PivotConnectionString,
            "SELECT COUNT(*) FROM ofuscador.AuthorizedUsers WHERE Principal=@p AND IsActive=1",
            new SqlParameter("@p", Context.Principal));
        return Convert.ToInt32(result) > 0;
    }

    public async Task<string?> GetUserRoleAsync()
    {
        var result = await ScalarAsync(Context.PivotConnectionString,
            "SELECT TOP(1) AppRole FROM ofuscador.AuthorizedUsers WHERE Principal=@p AND IsActive=1",
            new SqlParameter("@p", Context.Principal));
        return result == null || result == DBNull.Value ? null : Convert.ToString(result);
    }

    public async Task AuditAsync(string form, string action, bool success, string? detail = null,
        string? server = null, string? database = null)
    {
        await ExecuteAsync(Context.PivotConnectionString, """
            INSERT ofuscador.Audit(Principal,FormName,ActionName,ServerName,DatabaseName,Success,Detail)
            VALUES(@p,@f,@a,@s,@d,@ok,@x)
            """, new("@p", Context.Principal), new("@f", form), new("@a", action),
            new("@s", (object?)server ?? DBNull.Value), new("@d", (object?)database ?? DBNull.Value),
            new("@ok", success), new("@x", (object?)detail ?? DBNull.Value));
    }

    public async Task<ObservableCollection<ServerProfile>> LoadServersAsync()
    {
        var result = new ObservableCollection<ServerProfile>();
        await using var cn = Connection(Context.PivotConnectionString);
        await cn.OpenAsync();
        await using var cmd = new SqlCommand("""
            SELECT ServerId,IsActive,Name,Host,ISNULL(Instance,''),UseWindowsAuth,ISNULL(SqlUser,''),
                   ISNULL(EncryptedPassword,''),Encrypt,TrustServerCertificate,TimeoutSeconds FROM ofuscador.Servers ORDER BY Name
            """, cn);
        await using var rd = await cmd.ExecuteReaderAsync();
        while (await rd.ReadAsync())
            result.Add(new()
            {
                Id = rd.GetInt32(0), IsActive = rd.GetBoolean(1), Name = rd.GetString(2), Host = rd.GetString(3),
                Instance = rd.GetString(4), UseWindowsAuth = rd.GetBoolean(5), SqlUser = rd.GetString(6),
                EncryptedPassword = rd.GetString(7), Encrypt = rd.GetBoolean(8), TrustServerCertificate = rd.GetBoolean(9), TimeoutSeconds = rd.GetInt32(10)
            });
        return result;
    }

    public Task SaveServerAsync(ServerProfile s) => ExecuteAsync(Context.PivotConnectionString, """
        MERGE ofuscador.Servers AS t
        USING (SELECT @id ServerId) s ON t.ServerId=s.ServerId
        WHEN MATCHED THEN UPDATE SET IsActive=@active,Name=@name,Host=@host,Instance=@instance,
          UseWindowsAuth=@windows,SqlUser=@user,EncryptedPassword=@password,Encrypt=@encrypt,TrustServerCertificate=@trust,TimeoutSeconds=@timeout
        WHEN NOT MATCHED THEN INSERT(IsActive,Name,Host,Instance,UseWindowsAuth,SqlUser,EncryptedPassword,Encrypt,TrustServerCertificate,TimeoutSeconds)
          VALUES(@active,@name,@host,@instance,@windows,@user,@password,@encrypt,@trust,@timeout);
        """, new("@id", s.Id), new("@active", s.IsActive), new("@name", s.Name), new("@host", s.Host),
        new("@instance", (object?)s.Instance ?? DBNull.Value), new("@windows", s.UseWindowsAuth),
        new("@user", (object?)s.SqlUser ?? DBNull.Value), new("@password", (object?)s.EncryptedPassword ?? DBNull.Value),
        new("@encrypt", s.Encrypt), new("@trust", s.TrustServerCertificate), new("@timeout", s.TimeoutSeconds));

    public Task DeleteServerAsync(int id) => ExecuteAsync(Context.PivotConnectionString,
        "DELETE ofuscador.Servers WHERE ServerId=@id", new SqlParameter("@id", id));

    public async Task<List<string>> LoadDatabasesAsync(ServerProfile server)
    {
        var result = new List<string>();
        await using var cn = Connection(TargetConnection(server));
        await cn.OpenAsync();
        await using var cmd = new SqlCommand("""
            SELECT name FROM sys.databases WHERE state=0 AND database_id>4 AND source_database_id IS NULL ORDER BY name
            """, cn);
        await using var rd = await cmd.ExecuteReaderAsync();
        while (await rd.ReadAsync()) result.Add(rd.GetString(0));
        return result;
    }

    public async Task<ObservableCollection<PrincipalChoice>> LoadPrincipalsAsync(ServerProfile server, string database)
    {
        var result = new ObservableCollection<PrincipalChoice>();
        await using var cn = Connection(TargetConnection(server, database));
        await cn.OpenAsync();
        await using var cmd = new SqlCommand("""
            SELECT dp.name,dp.type_desc,
              CONVERT(bit,CASE WHEN IS_SRVROLEMEMBER(N'sysadmin',SUSER_SNAME(dp.sid))=1
                OR IS_ROLEMEMBER(N'db_owner',dp.name)=1 OR dp.name=N'dbo' THEN 1 ELSE 0 END),
              CASE WHEN IS_SRVROLEMEMBER(N'sysadmin',SUSER_SNAME(dp.sid))=1 THEN N'sysadmin'
                   WHEN IS_ROLEMEMBER(N'db_owner',dp.name)=1 OR dp.name=N'dbo' THEN N'db_owner/owner' ELSE N'' END
            FROM sys.database_principals dp
            WHERE dp.type IN('S','U','G','E','X') AND dp.principal_id>4
              AND dp.name NOT IN(N'guest',N'INFORMATION_SCHEMA',N'sys') ORDER BY dp.name
            """, cn);
        await using var rd = await cmd.ExecuteReaderAsync();
        while (await rd.ReadAsync())
        {
            var protectedUser = rd.GetBoolean(2);
            result.Add(new()
            {
                Name = rd.GetString(0), Type = rd.GetString(1), IsProtected = protectedUser,
                IsExcluded = protectedUser, ProtectionReason = rd.GetString(3)
            });
        }
        return result;
    }

    public async Task<ObservableCollection<MaskPattern>> LoadPatternsAsync()
    {
        var result = new ObservableCollection<MaskPattern>();
        await using var cn = Connection(Context.PivotConnectionString); await cn.OpenAsync();
        await using var cmd = new SqlCommand("SELECT Pattern,DdmFunction,ViewMaskExpr,CASE Priority WHEN 100 THEN N'Alto' WHEN 300 THEN N'Bajo' ELSE N'Medio' END,IsActive FROM ofuscador.MaskPatterns ORDER BY Priority,Pattern", cn);
        await using var rd = await cmd.ExecuteReaderAsync();
        while (await rd.ReadAsync()) result.Add(new()
        {
            Pattern = rd.GetString(0), DdmFunction = rd.GetString(1), ViewMaskExpr = rd.IsDBNull(2) ? null : rd.GetString(2),
            Priority = rd.GetString(3), IsActive = rd.GetBoolean(4)
        });
        return result;
    }

    public async Task<ObservableCollection<ProfileColumnRule>> LoadProfileColumnsAsync(ServerProfile server, string database)
    {
        var result = new ObservableCollection<ProfileColumnRule>();
        await using var cn = Connection(TargetConnection(server, database)); await cn.OpenAsync();
        await using var cmd = new SqlCommand("""
            SELECT s.name,t.name,c.name,TYPE_NAME(c.user_type_id)
            FROM sys.tables t JOIN sys.schemas s ON s.schema_id=t.schema_id
            JOIN sys.columns c ON c.object_id=t.object_id
            WHERE t.is_ms_shipped=0 AND s.name=N'dbo' ORDER BY t.name,c.column_id
            """, cn);
        await using var rd = await cmd.ExecuteReaderAsync();
        while (await rd.ReadAsync()) result.Add(new() { Schema=rd.GetString(0), Table=rd.GetString(1), Column=rd.GetString(2), DataType=rd.GetString(3) });
        return result;
    }

    public async Task SaveMaskProfileAsync(MaskProfile profile)
    {
        if (string.IsNullOrWhiteSpace(profile.ProfileName) || string.IsNullOrWhiteSpace(profile.TargetSchema))
            throw new InvalidOperationException("El perfil y el esquema son obligatorios.");
        await using var cn = Connection(Context.PivotConnectionString); await cn.OpenAsync();
        await using var tx = await cn.BeginTransactionAsync();
        await using var cmd = new SqlCommand("""
            DECLARE @id int = (SELECT ProfileId FROM ofuscador.MaskProfiles WHERE ProfileName=@n);
            IF @id IS NULL
            BEGIN
                INSERT ofuscador.MaskProfiles(ProfileName,ServerName,DatabaseName,TargetSchema,IsActive)
                VALUES(@n,@s,@d,@schema,@a);
                SET @id = CONVERT(int,SCOPE_IDENTITY());
            END
            ELSE
                UPDATE ofuscador.MaskProfiles SET ServerName=@s,DatabaseName=@d,TargetSchema=@schema,IsActive=@a,ModifiedAt=SYSUTCDATETIME() WHERE ProfileId=@id;
            SELECT @id;
            """, cn, (SqlTransaction)tx);
        cmd.Parameters.AddRange([new("@n",profile.ProfileName),new("@s",profile.ServerName),new("@d",profile.DatabaseName),new("@schema",profile.TargetSchema),new("@a",profile.IsActive)]);
        profile.ProfileId = Convert.ToInt32(await cmd.ExecuteScalarAsync());
        await ExecuteAsync(cn, (SqlTransaction)tx, "DELETE ofuscador.MaskProfileColumns WHERE ProfileId=@id; DELETE ofuscador.MaskProfileUsers WHERE ProfileId=@id", new SqlParameter("@id", profile.ProfileId));
        foreach (var r in profile.Rules.Where(x => !string.IsNullOrWhiteSpace(x.RulePattern) && x.RulePattern != "(predeterminado)"))
            await ExecuteAsync(cn, (SqlTransaction)tx, "INSERT ofuscador.MaskProfileColumns VALUES(@id,@s,@t,@c,@r)", new("@id",profile.ProfileId),new("@s",r.Schema),new("@t",r.Table),new("@c",r.Column),new("@r",r.RulePattern));
        foreach (var u in profile.Users.Where(x => !string.IsNullOrWhiteSpace(x)))
            await ExecuteAsync(cn, (SqlTransaction)tx, "INSERT ofuscador.MaskProfileUsers VALUES(@id,@u)", new("@id",profile.ProfileId),new("@u",u));
        await tx.CommitAsync();
    }

    private static async Task ExecuteAsync(SqlConnection cn, SqlTransaction tx, string sql, params SqlParameter[] parameters)
    {
        await using var cmd = new SqlCommand(sql, cn, tx); cmd.Parameters.AddRange(parameters); await cmd.ExecuteNonQueryAsync();
    }

    public async Task SavePatternsAsync(IEnumerable<MaskPattern> patterns)
    {
        await using var cn = Connection(Context.PivotConnectionString); await cn.OpenAsync();
        await using var tx = await cn.BeginTransactionAsync();
        await new SqlCommand("DELETE ofuscador.MaskPatterns", cn, (SqlTransaction)tx).ExecuteNonQueryAsync();
        foreach (var p in patterns.Where(x => !string.IsNullOrWhiteSpace(x.Pattern)))
        {
            await using var cmd = new SqlCommand("""
                INSERT ofuscador.MaskPatterns(Pattern,DdmFunction,ViewMaskExpr,Priority,IsActive) VALUES(@p,@d,@v,@o,@a)
                """, cn, (SqlTransaction)tx);
            cmd.Parameters.AddRange([new("@p",p.Pattern),new("@d",p.DdmFunction),new("@v",(object?)p.ViewMaskExpr??DBNull.Value),
                new("@o",PriorityRank(p.Priority)),new("@a",p.IsActive)]);
            await cmd.ExecuteNonQueryAsync();
        }
        await tx.CommitAsync();
    }

    public static int PriorityRank(string? priority) => priority switch
    {
        "Alto" => 100,
        "Bajo" => 300,
        _ => 200
    };

    public async Task<ObservableCollection<AuthorizedUser>> LoadUsersAsync()
    {
        var result = new ObservableCollection<AuthorizedUser>();
        await using var cn = Connection(Context.PivotConnectionString); await cn.OpenAsync();
        await using var cmd = new SqlCommand("SELECT Principal,PrincipalType,AppRole,IsActive,ISNULL(Notes,'') FROM ofuscador.AuthorizedUsers ORDER BY Principal",cn);
        await using var rd=await cmd.ExecuteReaderAsync();
        while(await rd.ReadAsync()) result.Add(new(){Principal=rd.GetString(0),PrincipalType=rd.GetString(1),Role=rd.GetString(2),IsActive=rd.GetBoolean(3),Notes=rd.GetString(4)});
        return result;
    }

    public async Task<List<PivotLoginOption>> LoadPivotLoginsAsync()
    {
        var result = new List<PivotLoginOption>();
        await using var cn = Connection(Context.PivotConnectionString);
        await cn.OpenAsync();
        await using var cmd = new SqlCommand("""
            SELECT sp.name,
              CASE sp.type WHEN 'S' THEN N'SQL_LOGIN' WHEN 'U' THEN N'WINDOWS_LOGIN'
                           WHEN 'G' THEN N'WINDOWS_GROUP' WHEN 'E' THEN N'EXTERNAL_LOGIN'
                           WHEN 'X' THEN N'EXTERNAL_GROUP' ELSE sp.type_desc END,
              CONVERT(bit,ISNULL(sp.is_disabled,0))
            FROM sys.server_principals sp
            WHERE sp.type IN('S','U','G','E','X') AND sp.name NOT LIKE N'##%'
            ORDER BY sp.name
            """, cn);
        await using var rd = await cmd.ExecuteReaderAsync();
        while (await rd.ReadAsync()) result.Add(new() { Login = rd.GetString(0), LoginType = rd.GetString(1), IsDisabled = rd.GetBoolean(2) });
        return result;
    }

    public async Task SaveUsersAsync(IEnumerable<AuthorizedUser> users)
    {
        await using var cn=Connection(Context.PivotConnectionString); await cn.OpenAsync();
        await using var tx=await cn.BeginTransactionAsync();
        await new SqlCommand("DELETE ofuscador.AuthorizedUsers",cn,(SqlTransaction)tx).ExecuteNonQueryAsync();
        foreach(var u in users.Where(x=>!string.IsNullOrWhiteSpace(x.Principal)))
        {
            await using var cmd=new SqlCommand("INSERT ofuscador.AuthorizedUsers(Principal,PrincipalType,AppRole,IsActive,Notes) VALUES(@p,@t,@r,@a,@n)",cn,(SqlTransaction)tx);
            cmd.Parameters.AddRange([new("@p",u.Principal),new("@t",u.PrincipalType),new("@r",u.Role),new("@a",u.IsActive),new("@n",u.Notes)]);
            await cmd.ExecuteNonQueryAsync();
        }
        await tx.CommitAsync();
    }

    public async Task<Guid> BeginExecutionAsync(string mode, IEnumerable<DatabaseTarget> targets)
    {
        var id=Guid.NewGuid();
        await ExecuteAsync(Context.PivotConnectionString,"INSERT ofuscador.Executions VALUES(@id,@m,N'Running',@p,SYSUTCDATETIME(),NULL,NULL)",
            new("@id",id),new("@m",mode),new("@p",Context.Principal));
        foreach(var t in targets) await ExecuteAsync(Context.PivotConnectionString,
            "INSERT ofuscador.ExecutionTargets VALUES(@id,@s,@d,N'Pending',NULL)",new("@id",id),new("@s",t.Server.Name),new("@d",t.Database));
        return id;
    }

    public Task UpdateTargetAsync(Guid id,DatabaseTarget target,string status,string detail)=>ExecuteAsync(Context.PivotConnectionString,
        "UPDATE ofuscador.ExecutionTargets SET Status=@x,Detail=@z WHERE ExecutionId=@id AND ServerName=@s AND DatabaseName=@d",
        new("@x",status),new("@z",detail),new("@id",id),new("@s",target.Server.Name),new("@d",target.Database));

    public Task FinishExecutionAsync(Guid id,string status,string summary)=>ExecuteAsync(Context.PivotConnectionString,
        "UPDATE ofuscador.Executions SET Status=@s,FinishedAt=SYSUTCDATETIME(),Summary=@x WHERE ExecutionId=@id",
        new("@s",status),new("@x",summary),new("@id",id));

    public async Task<DataTable> LoadAuditAsync()
    {
        var table=new DataTable();
        await using var cn=Connection(Context.PivotConnectionString); await cn.OpenAsync();
        await using var cmd=new SqlCommand("SELECT TOP(500) EventAt,Principal,FormName,ActionName,ServerName,DatabaseName,Success,Detail FROM ofuscador.Audit ORDER BY AuditId DESC",cn);
        await using var rd=await cmd.ExecuteReaderAsync(); table.Load(rd);
        LocalizeUtcColumns(table, "EventAt");
        return table;
    }

    public async Task<DataTable> LoadDeploymentsAsync()
    {
        var table=new DataTable();
        await using var cn=Connection(Context.PivotConnectionString); await cn.OpenAsync();
        await using var cmd=new SqlCommand("SELECT TOP(100) ExecutionId,Mode,Status,RequestedBy,StartedAt,FinishedAt FROM ofuscador.Executions WHERE Mode=N'Deploy' AND Status IN(N'Completed',N'Partial') ORDER BY StartedAt DESC",cn);
        await using var rd=await cmd.ExecuteReaderAsync(); table.Load(rd);
        LocalizeUtcColumns(table, "StartedAt", "FinishedAt");
        return table;
    }

    private static void LocalizeUtcColumns(DataTable table, params string[] columnNames)
    {
        foreach (DataRow row in table.Rows)
        foreach (var columnName in columnNames)
        {
            if (!table.Columns.Contains(columnName) || row[columnName] is not DateTime value) continue;
            row[columnName] = DateTime.SpecifyKind(value, DateTimeKind.Utc).ToLocalTime();
        }
    }

    public async Task<List<(string Server,string Database)>> LoadExecutionTargetsAsync(Guid id)
    {
        var result=new List<(string,string)>();
        await using var cn=Connection(Context.PivotConnectionString); await cn.OpenAsync();
        await using var cmd=new SqlCommand("SELECT ServerName,DatabaseName FROM ofuscador.ExecutionTargets WHERE ExecutionId=@id",cn);
        cmd.Parameters.AddWithValue("@id",id);
        await using var rd=await cmd.ExecuteReaderAsync();
        while(await rd.ReadAsync()) result.Add((rd.GetString(0),rd.GetString(1)));
        return result;
    }

    public static async Task ExecuteAsync(string cs, string sql, params SqlParameter[] parameters)
    {
        await using var cn = Connection(cs);
        await cn.OpenAsync();
        await using var cmd = new SqlCommand(sql, cn) { CommandTimeout = 180 };
        if (parameters.Length > 0) cmd.Parameters.AddRange(parameters);
        await cmd.ExecuteNonQueryAsync();
    }

    public static async Task<object?> ScalarAsync(string cs, string sql, params SqlParameter[] parameters)
    {
        await using var cn = Connection(cs);
        await cn.OpenAsync();
        await using var cmd = new SqlCommand(sql, cn);
        if (parameters.Length > 0) cmd.Parameters.AddRange(parameters);
        return await cmd.ExecuteScalarAsync();
    }
}
