using Microsoft.Data.SqlClient;
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;

namespace OfuscadorTool;

public sealed class DeploymentService(DatabaseService db)
{
    public event Action<string>? Log;

    private void Write(string text) => Log?.Invoke($"[{DateTime.Now:HH:mm:ss}] {text}");

    public async Task<string> SimulateAsync(DatabaseTarget target, IReadOnlyCollection<MaskPattern> patterns)
    {
        var cs = db.TargetConnection(target.Server, target.Database);
        await using var cn = new SqlConnection(cs);
        await cn.OpenAsync();
        var warnings = new List<string>();
        async Task<int> Count(string sql)
        {
            await using var cmd = new SqlCommand(sql, cn);
            return Convert.ToInt32(await cmd.ExecuteScalarAsync());
        }
        var tables = await Count("SELECT COUNT(*) FROM sys.tables WHERE is_ms_shipped=0 AND SCHEMA_NAME(schema_id)=N'dbo'");
        var computed = await Count("SELECT COUNT(DISTINCT object_id) FROM sys.computed_columns");
        var withoutPk = await Count("""
            SELECT COUNT(*) FROM sys.tables t WHERE t.is_ms_shipped=0 AND SCHEMA_NAME(t.schema_id)=N'dbo'
            AND NOT EXISTS(SELECT 1 FROM sys.key_constraints k WHERE k.parent_object_id=t.object_id AND k.type='PK')
            """);
        if (patterns.Count == 0) warnings.Add("No hay patrones activos.");
        if (withoutPk > 0) warnings.Add($"{withoutPk} tabla(s) sin PK no tendrán UPDATE/DELETE mediante vista.");
        var summary = $"{target.Server.Name}/{target.Database}: conexión OK; {tables} tablas; {computed} con columnas calculadas; " +
                      $"{patterns.Count} patrones; {target.Principals.Count(p => p.IsExcluded)} usuarios excluidos.";
        if (warnings.Count > 0) summary += " Advertencias: " + string.Join(" ", warnings);
        Write(summary);
        return summary;
    }

    public async Task DeployAsync(Guid executionId, DatabaseTarget target, IReadOnlyCollection<MaskPattern> patterns)
    {
        var cs = db.TargetConnection(target.Server, target.Database);
        Write($"Iniciando {target.Server.Name}/{target.Database}");
        await BackupPermissionsAsync(executionId, target, cs);

        var setup = SqlText.Resource("00_setup_min.sql");
        setup = setup.Replace(
            "IF OBJECT_ID('dbo.Masked_Patterns','U') IS NOT NULL DROP TABLE dbo.Masked_Patterns;\nCREATE TABLE dbo.Masked_Patterns",
            "IF OBJECT_ID('dbo.Masked_Patterns','U') IS NULL CREATE TABLE dbo.Masked_Patterns");
        var insertAt = setup.IndexOf("/* Carga de patrones solicitados */", StringComparison.Ordinal);
        var auditAt = setup.IndexOf("IF OBJECT_ID('dbo.Masked_Audit'", StringComparison.Ordinal);
        if (insertAt >= 0 && auditAt > insertAt) setup = setup[..insertAt] + setup[auditAt..];
        await RunBatchesAsync(cs, setup);
        await SyncPatternsAsync(cs, patterns);
        await RunBatchesAsync(cs, SqlText.Resource("01_sp_CreateViewWithDml.sql"));
        await RunBatchesAsync(cs, SqlText.Resource("02_deploy_all.sql"));

        var excluded = target.Principals.Where(p => p.IsExcluded).Select(p => p.Name).Distinct(StringComparer.OrdinalIgnoreCase);
        var policy = SqlText.Resource("04_policy.sql");
        var markerStart = policy.IndexOf("INSERT INTO @Excluidos VALUES", StringComparison.OrdinalIgnoreCase);
        var markerEnd = policy.IndexOf(";", markerStart) + 1;
        var values = excluded.Any()
            ? "INSERT INTO @Excluidos(UserName) VALUES " + string.Join(",", excluded.Select(x => $"({SqlText.Quote(x)})")) + ";"
            : "-- Sin exclusiones manuales; sysadmin y db_owner siguen protegidos.";
        if (markerStart >= 0 && markerEnd > markerStart) policy = policy[..markerStart] + values + policy[markerEnd..];
        await RunBatchesAsync(cs, policy);
        Write($"Finalizado {target.Server.Name}/{target.Database}");
    }

    public async Task ApplyProfileAsync(MaskProfile profile, ServerProfile server, IReadOnlyCollection<MaskPattern> patterns)
    {
        if (!Regex.IsMatch(profile.TargetSchema, "^[A-Za-z_][A-Za-z0-9_]*$"))
            throw new InvalidOperationException("El esquema del perfil solo puede contener letras, números y guion bajo.");

        await using var cn = new SqlConnection(db.TargetConnection(server, profile.DatabaseName));
        await cn.OpenAsync();

        var qSchema = Q(profile.TargetSchema);
        await ExecuteSqlAsync(cn, $"IF SCHEMA_ID(N'{profile.TargetSchema.Replace("'", "''")}') IS NULL EXEC(N'CREATE SCHEMA {qSchema} AUTHORIZATION dbo');");

        await ExecuteSqlAsync(cn, "SET QUOTED_IDENTIFIER ON;");

        var activePatterns = patterns.Where(x => x.IsActive).ToList();
        var overrides = profile.Rules
            .Where(x => !string.Equals(x.RulePattern, "(predeterminado)", StringComparison.OrdinalIgnoreCase))
            .ToDictionary(x => $"{x.Schema}.{x.Table}.{x.Column}", StringComparer.OrdinalIgnoreCase);
        var tablesWithOverrides = overrides.Values
            .Select(x => $"{x.Schema}.{x.Table}")
            .ToHashSet(StringComparer.OrdinalIgnoreCase);

        const string metadataSql = """
            SELECT s.name,t.name,c.name
            FROM sys.tables t
            JOIN sys.schemas s ON s.schema_id=t.schema_id
            JOIN sys.columns c ON c.object_id=t.object_id
            WHERE t.is_ms_shipped=0 AND s.name=N'dbo'
            ORDER BY t.name,c.column_id;
            """;
        var columns = new List<(string Schema, string Table, string Column)>();
        await using (var cmd = new SqlCommand(metadataSql, cn))
        await using (var reader = await cmd.ExecuteReaderAsync())
            while (await reader.ReadAsync())
                columns.Add((reader.GetString(0), reader.GetString(1), reader.GetString(2)));

        foreach (var table in columns.GroupBy(x => (x.Schema, x.Table)))
        {
            var projections = new List<string>();
            var isCustomTable = tablesWithOverrides.Contains($"{table.Key.Schema}.{table.Key.Table}");
            foreach (var column in table)
            {
                var key = $"{column.Schema}.{column.Table}.{column.Column}";
                var hasOverride = overrides.TryGetValue(key, out var overrideRule);
                MaskPattern? rule;
                if (hasOverride)
                    rule = activePatterns.FirstOrDefault(x =>
                        string.Equals(x.Pattern, overrideRule!.RulePattern, StringComparison.OrdinalIgnoreCase));
                else if (isCustomTable)
                    rule = null;
                else
                    rule = activePatterns
                        .OrderBy(x => DatabaseService.PriorityRank(x.Priority))
                        .FirstOrDefault(x => ColumnMatchesPattern(column.Column, x.Pattern));

                if (hasOverride && (rule is null || string.IsNullOrWhiteSpace(rule.ViewMaskExpr)))
                    throw new InvalidOperationException(
                        $"La regla '{overrideRule!.RulePattern}' no tiene Expresión vista para {key}.");

                if (string.IsNullOrWhiteSpace(rule?.ViewMaskExpr))
                {
                    projections.Add(Q(column.Column));
                    continue;
                }

                var expression = PrepareViewExpression(rule.ViewMaskExpr, column.Column);
                projections.Add($"{expression} AS {Q(column.Column)}");
            }

            var viewName = $"{qSchema}.{Q(table.Key.Table)}";
            await ExecuteSqlAsync(cn,
                $"IF OBJECT_ID(N'{profile.TargetSchema.Replace("'", "''")}.{table.Key.Table.Replace("'", "''")}',N'V') IS NOT NULL DROP VIEW {viewName};");

            var createSql =
                $"CREATE VIEW {viewName} AS SELECT {string.Join(",", projections)} FROM {Q(table.Key.Schema)}.{Q(table.Key.Table)};";
            try
            {
                await ExecuteSqlAsync(cn, createSql);
            }
            catch (SqlException ex)
            {
                throw new InvalidOperationException(
                    $"No se pudo crear la vista {viewName}. Revisa Expresión vista de las columnas de {table.Key.Table}.{Environment.NewLine}{ex.Message}{Environment.NewLine}{createSql}",
                    ex);
            }
        }

        var roleName = $"ofuscador_profile_{profile.TargetSchema}";
        if (roleName.Length > 128)
            throw new InvalidOperationException("El nombre del esquema es demasiado largo para crear el rol del perfil.");

        var qRole = Q(roleName);
        var roleLiteral = roleName.Replace("'", "''", StringComparison.Ordinal);
        await ExecuteSqlAsync(cn, $"""
            IF DATABASE_PRINCIPAL_ID(N'{roleLiteral}') IS NULL
                CREATE ROLE {qRole} AUTHORIZATION dbo;
            GRANT UNMASK TO {qRole};
            DENY SELECT ON SCHEMA::[dbo] TO {qRole};
            GRANT SELECT ON SCHEMA::{qSchema} TO {qRole};
            """);

        foreach (var user in profile.Users.Where(x => !string.IsNullOrWhiteSpace(x)))
        {
            var qUser = Q(user);
            var userLiteral = user.Replace("'", "''", StringComparison.Ordinal);
            await ExecuteSqlAsync(cn,
                $"""
                IF NOT EXISTS
                (
                    SELECT 1
                    FROM sys.database_role_members drm
                    JOIN sys.database_principals r ON r.principal_id=drm.role_principal_id
                    JOIN sys.database_principals u ON u.principal_id=drm.member_principal_id
                    WHERE r.name=N'{roleLiteral}' AND u.name=N'{userLiteral}'
                )
                    ALTER ROLE {qRole} ADD MEMBER {qUser};
                ALTER USER {qUser} WITH DEFAULT_SCHEMA={qSchema};
                """);
        }

        Write($"Perfil {profile.ProfileName} aplicado en {server.Name}/{profile.DatabaseName}: {columns.Select(x => x.Table).Distinct().Count()} vistas; rol {roleName}; UNMASK habilitado y acceso directo a dbo denegado.");
    }

    private static bool ColumnMatchesPattern(string column, string pattern)
    {
        var token = pattern.Trim().Trim('%');
        return token.Length > 0 && column.Contains(token, StringComparison.OrdinalIgnoreCase);
    }

    private static string PrepareViewExpression(string expression, string column)
    {
        // Las expresiones se capturan en la UI con "X", pero T-SQL requiere 'X'.
        // Esta es la única normalización aplicada; la fórmula de ViewMaskExpr se conserva.
        var prepared = expression
            .Replace("&quot;", "'", StringComparison.OrdinalIgnoreCase)
            .Replace("\"", "'", StringComparison.Ordinal)
            .Replace("“", "'", StringComparison.Ordinal)
            .Replace("”", "'", StringComparison.Ordinal)
            .Replace("{col}", Q(column), StringComparison.OrdinalIgnoreCase);

        // ViewMaskExpr puede venir escapada para SQL dinámico: ''X''.
        // Al insertarla directamente en CREATE VIEW debe convertirse en 'X'.
        return Regex.Replace(prepared, @"(?<!')''([^']+)''(?!')", "'$1'");
    }

    private async Task ApplyProfileLegacyAsync(MaskProfile profile, ServerProfile server, IReadOnlyCollection<MaskPattern> patterns)
    {
        if (!System.Text.RegularExpressions.Regex.IsMatch(profile.TargetSchema, "^[A-Za-z_][A-Za-z0-9_]*$"))
            throw new InvalidOperationException("El esquema del perfil solo puede contener letras, números y guion bajo.");
        var cs = db.TargetConnection(server, profile.DatabaseName);
        await using var cn = new SqlConnection(cs); await cn.OpenAsync();
        var qSchema = Q(profile.TargetSchema);
        await ExecuteSqlAsync(cn, $"IF SCHEMA_ID(N'{profile.TargetSchema.Replace("'", "''")}') IS NULL EXEC(N'CREATE SCHEMA {qSchema} AUTHORIZATION dbo');");
        var custom = profile.Rules.Where(r => r.RulePattern != "(predeterminado)")
            .ToDictionary(r => $"{r.Schema}.{r.Table}.{r.Column}", StringComparer.OrdinalIgnoreCase);
        var active = patterns.Where(p => p.IsActive).ToList();
        await using var meta = new SqlCommand("""
            SELECT s.name,t.name,c.name FROM sys.tables t JOIN sys.schemas s ON s.schema_id=t.schema_id
            JOIN sys.columns c ON c.object_id=t.object_id WHERE t.is_ms_shipped=0 AND s.name=N'dbo'
            ORDER BY t.name,c.column_id
            """, cn);
        var columns = new List<(string Schema,string Table,string Column)>();
        await using (var rd = await meta.ExecuteReaderAsync()) while (await rd.ReadAsync()) columns.Add((rd.GetString(0),rd.GetString(1),rd.GetString(2)));
        foreach (var table in columns.GroupBy(x => (x.Schema,x.Table)))
        {
            var expressions = new List<string>();
            foreach (var c in table)
            {
                MaskPattern? p = null;
                if (custom.TryGetValue($"{c.Schema}.{c.Table}.{c.Column}", out var overrideRule)) p = active.FirstOrDefault(x => x.Pattern.Equals(overrideRule.RulePattern,StringComparison.OrdinalIgnoreCase));
                if (p is null) p = active.FirstOrDefault(x => c.Column.Contains(x.Pattern.Replace("%", ""), StringComparison.OrdinalIgnoreCase));
                var expr = p?.ViewMaskExpr;
                // Los patrones nuevos pueden tener únicamente DdmFunction. En perfiles usamos
                // una expresión SQL segura para no intentar ejecutar el texto DDM (partial(...)).
                if (p is not null && string.IsNullOrWhiteSpace(expr) && !string.IsNullOrWhiteSpace(p.DdmFunction))
                    expr = "REPLICATE(N'X', NULLIF(LEN(CONVERT(nvarchar(max), {col})), 0))";
                if (string.IsNullOrWhiteSpace(expr)) expressions.Add(Q(c.Column));
                else
                {
                    // Las reglas se capturan normalmente con "X"; en T-SQL esos caracteres
                    // son identificadores cuando QUOTED_IDENTIFIER está activo. Convertirlos
                    // a literales permite reutilizar directamente la expresión de la regla.
                    var sqlExpr = expr.Replace('"', '\'').Replace('“', '\'').Replace('”', '\'');
                    // Algunas reglas antiguas almacenan el relleno como X sin comillas.
                    sqlExpr = Regex.Replace(sqlExpr, @"(?i)(REPLICATE\s*\(\s*)X(\s*,)", "$1N'X'$2");
                    sqlExpr = sqlExpr.Replace("{col}", Q(c.Column), StringComparison.OrdinalIgnoreCase);
                    expressions.Add($"{sqlExpr} AS {Q(c.Column)}");
                }
            }
            var view = $"{qSchema}.{Q(table.Key.Table)}";
            // CREATE VIEW debe ser la primera instrucción del lote; separar DROP y CREATE evita el error 111.
            await ExecuteSqlAsync(cn, $"IF OBJECT_ID(N'{profile.TargetSchema}.{table.Key.Table}',N'V') IS NOT NULL DROP VIEW {view};");
            await ExecuteSqlAsync(cn, $"CREATE VIEW {view} AS SELECT {string.Join(",",expressions)} FROM dbo.{Q(table.Key.Table)};");
        }
        foreach (var user in profile.Users.Where(x => !string.IsNullOrWhiteSpace(x)))
        {
            var qUser = Q(user); await ExecuteSqlAsync(cn, $"GRANT SELECT ON SCHEMA::{qSchema} TO {qUser}; ALTER USER {qUser} WITH DEFAULT_SCHEMA={qSchema};");
        }
        Write($"Perfil {profile.ProfileName} aplicado en {server.Name}/{profile.DatabaseName}: {columns.Select(x=>x.Table).Distinct().Count()} vistas.");
    }

    private static string Q(string value) => "[" + value.Replace("]", "]]", StringComparison.Ordinal) + "]";
    private static async Task ExecuteSqlAsync(SqlConnection cn, string sql)
    { await using var cmd = new SqlCommand(sql, cn) { CommandTimeout = 0 }; await cmd.ExecuteNonQueryAsync(); }

    private static async Task RunBatchesAsync(string cs, string sql)
    {
        await using var cn = new SqlConnection(cs);
        await cn.OpenAsync();
        foreach (var batch in SqlText.Batches(sql))
        {
            await using var cmd = new SqlCommand(batch, cn) { CommandTimeout = 0 };
            await cmd.ExecuteNonQueryAsync();
        }
    }

    private static async Task SyncPatternsAsync(string cs, IReadOnlyCollection<MaskPattern> patterns)
    {
        await using var cn = new SqlConnection(cs);
        await cn.OpenAsync();
        await using var tx = await cn.BeginTransactionAsync();
        await using (var clear = new SqlCommand("DELETE dbo.Masked_Patterns", cn, (SqlTransaction)tx))
            await clear.ExecuteNonQueryAsync();
        foreach (var p in patterns.Where(x => x.IsActive).OrderBy(x => DatabaseService.PriorityRank(x.Priority)))
        {
            await using var cmd = new SqlCommand("""
                INSERT dbo.Masked_Patterns(Pattern,DdmFunction,ViewMaskExpr) VALUES(@p,@d,@v)
                """, cn, (SqlTransaction)tx);
            cmd.Parameters.AddWithValue("@p", p.Pattern);
            cmd.Parameters.AddWithValue("@d", p.DdmFunction);
            cmd.Parameters.AddWithValue("@v", (object?)p.ViewMaskExpr ?? DBNull.Value);
            await cmd.ExecuteNonQueryAsync();
        }
        await tx.CommitAsync();
    }

    private async Task BackupPermissionsAsync(Guid id, DatabaseTarget target, string cs)
    {
        await using var cn = new SqlConnection(cs);
        await cn.OpenAsync();
        const string sql = """
            SELECT dp.name,
              (SELECT r.name FROM sys.database_role_members drm JOIN sys.database_principals r
               ON r.principal_id=drm.role_principal_id WHERE drm.member_principal_id=dp.principal_id FOR JSON PATH) Roles,
              (SELECT pe.state_desc,pe.permission_name,SCHEMA_NAME(o.schema_id) SchemaName,o.name ObjectName
               FROM sys.database_permissions pe LEFT JOIN sys.objects o ON o.object_id=pe.major_id
               WHERE pe.grantee_principal_id=dp.principal_id FOR JSON PATH) Permissions,
              dp.default_schema_name
            FROM sys.database_principals dp WHERE dp.type IN('S','U','G','E','X') AND dp.principal_id>4
            FOR JSON PATH
            """;
        await using var cmd = new SqlCommand(sql, cn);
        var snapshot = (string?)await cmd.ExecuteScalarAsync() ?? "[]";
        await DatabaseService.ExecuteAsync(db.Context.PivotConnectionString, """
            INSERT ofuscador.PermissionBackup(ExecutionId,ServerName,DatabaseName,PrincipalName,SnapshotJson)
            VALUES(@id,@s,@d,N'*',@j)
            """, new("@id", id), new("@s", target.Server.Name), new("@d", target.Database), new("@j", snapshot));
    }

    public async Task RollbackAsync(Guid sourceExecutionId, DatabaseTarget target)
    {
        var cs = db.TargetConnection(target.Server, target.Database);
        Write($"Rollback {target.Server.Name}/{target.Database}");
        const string cleanup = """
        DECLARE @sql nvarchar(max)=N'';
        SELECT @sql += N'ALTER TABLE ['+REPLACE(s.name,N']',N']]')+N'].['+REPLACE(o.name,N']',N']]')+
          N'] ALTER COLUMN ['+REPLACE(mc.name,N']',N']]')+N'] DROP MASKED;'+CHAR(10)
          FROM sys.masked_columns mc
          JOIN sys.objects o ON o.object_id=mc.object_id
          JOIN sys.schemas s ON s.schema_id=o.schema_id;
        IF LEN(@sql)>0 EXEC sp_executesql @sql;
        SET @sql=N'';
        SELECT @sql += N'DROP SYNONYM ['+REPLACE(s.name,N']',N']]')+N'].['+REPLACE(syn.name,N']',N']]')+N'];'
          FROM sys.synonyms syn JOIN sys.schemas s ON s.schema_id=syn.schema_id WHERE s.name=N'app';
        IF LEN(@sql)>0 EXEC sp_executesql @sql;
        SET @sql=N'';
        SELECT @sql += N'DROP VIEW ['+REPLACE(s.name,N']',N']]')+N'].['+REPLACE(v.name,N']',N']]')+N'];'
          FROM sys.views v JOIN sys.schemas s ON s.schema_id=v.schema_id WHERE s.name=N'masked';
        IF LEN(@sql)>0 EXEC sp_executesql @sql;
        DECLARE @u sysname,@r sysname;
        DECLARE c CURSOR LOCAL FAST_FORWARD FOR
          SELECT u.name,r.name FROM sys.database_role_members m JOIN sys.database_principals u ON u.principal_id=m.member_principal_id
          JOIN sys.database_principals r ON r.principal_id=m.role_principal_id
          WHERE r.name IN(N'rol_app_lectura',N'rol_app_dml',N'rol_app_bloqueo_dbo');
        OPEN c; FETCH NEXT FROM c INTO @u,@r;
        DECLARE @cmd nvarchar(max);
        WHILE @@FETCH_STATUS=0 BEGIN
          SET @cmd=N'ALTER ROLE ['+REPLACE(@r,N']',N']]')+N'] DROP MEMBER ['+REPLACE(@u,N']',N']]')+N']';
          EXEC sp_executesql @cmd;
          FETCH NEXT FROM c INTO @u,@r;
        END
        CLOSE c; DEALLOCATE c;
        """;
        await RunBatchesAsync(cs, cleanup);

        var json = (string?)await DatabaseService.ScalarAsync(db.Context.PivotConnectionString, """
            SELECT SnapshotJson FROM ofuscador.PermissionBackup
            WHERE ExecutionId=@id AND ServerName=@s AND DatabaseName=@d AND PrincipalName=N'*'
            """, new("@id", sourceExecutionId), new("@s", target.Server.Name), new("@d", target.Database));
        if (!string.IsNullOrWhiteSpace(json)) await RestoreSnapshotAsync(cs, json);
        Write($"Rollback finalizado {target.Server.Name}/{target.Database}");
    }

    private static async Task RestoreSnapshotAsync(string cs, string json)
    {
        using var doc = JsonDocument.Parse(json);
        await using var cn = new SqlConnection(cs);
        await cn.OpenAsync();
        foreach (var principal in doc.RootElement.EnumerateArray())
        {
            var name = principal.GetProperty("name").GetString()!;
            if (principal.TryGetProperty("default_schema_name", out var ds) && ds.ValueKind == JsonValueKind.String)
                await ExecuteSafeAsync(cn, $"ALTER USER [{name.Replace("]", "]]")}] WITH DEFAULT_SCHEMA=[{ds.GetString()!.Replace("]", "]]")}]");
            if (principal.TryGetProperty("Roles", out var roles))
                foreach (var role in JsonArray(roles))
                    await ExecuteSafeAsync(cn, $"ALTER ROLE [{role.GetProperty("name").GetString()!.Replace("]", "]]")}] ADD MEMBER [{name.Replace("]", "]]")}]");
            if (principal.TryGetProperty("Permissions", out var permissions))
            {
                foreach (var permission in JsonArray(permissions))
                {
                    var state = permission.GetProperty("state_desc").GetString();
                    var permissionName = permission.GetProperty("permission_name").GetString();
                    if (string.IsNullOrWhiteSpace(state) || string.IsNullOrWhiteSpace(permissionName)) continue;
                    var verb = state == "DENY" ? "DENY" : "GRANT";
                    var scope = "";
                    if (permission.TryGetProperty("ObjectName", out var obj) && obj.ValueKind == JsonValueKind.String)
                    {
                        var schema = permission.TryGetProperty("SchemaName", out var sch) && sch.ValueKind == JsonValueKind.String
                            ? sch.GetString()! : "dbo";
                        scope = $" ON OBJECT::[{schema.Replace("]", "]]")}].[{obj.GetString()!.Replace("]", "]]")}]";
                    }
                    var grantOption = state == "GRANT_WITH_GRANT_OPTION" ? " WITH GRANT OPTION" : "";
                    await ExecuteSafeAsync(cn, $"{verb} {permissionName} {scope} TO [{name.Replace("]", "]]")}]{grantOption}");
                }
            }
        }
    }

    private static IEnumerable<JsonElement> JsonArray(JsonElement value)
    {
        if (value.ValueKind == JsonValueKind.Array) return value.EnumerateArray();
        if (value.ValueKind == JsonValueKind.String && !string.IsNullOrWhiteSpace(value.GetString()))
            return JsonDocument.Parse(value.GetString()!).RootElement.EnumerateArray();
        return [];
    }

    private static async Task ExecuteSafeAsync(SqlConnection cn, string sql)
    {
        try { await using var cmd = new SqlCommand(sql, cn); await cmd.ExecuteNonQueryAsync(); } catch (SqlException) { }
    }
}
