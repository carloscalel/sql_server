document.addEventListener('DOMContentLoaded', () => {
    let activities = JSON.parse(localStorage.getItem('alwayson_activities')) || initialPlanData;

    let statusChartInstance = null;
    let modulesBarChartInstance = null;

    const navItems = document.querySelectorAll('.nav-item');
    const sections = document.querySelectorAll('.content-section');
    const tbody = document.getElementById('activities-tbody');
    const modulesTbody = document.getElementById('modules-tbody');
    const filterModule = document.getElementById('filter-module');
    const searchActivity = document.getElementById('search-activity');
    const resetBtn = document.getElementById('reset-storage');

    const kpiTotal = document.getElementById('kpi-total');
    const kpiOk = document.getElementById('kpi-ok');
    const kpiRun = document.getElementById('kpi-run');
    const kpiError = document.getElementById('kpi-error');
    const kpiPercent = document.getElementById('kpi-percent');

    navItems.forEach(item => {
        item.addEventListener('click', (e) => {
            e.preventDefault();
            navItems.forEach(nav => nav.classList.remove('active'));
            sections.forEach(sec => sec.classList.remove('active'));

            item.classList.add('active');
            const targetId = item.getAttribute('data-section');
            document.getElementById(targetId).classList.add('active');
        });
    });

    function getUniqueModules() {
        return [...new Set(activities.map(item => item.module))];
    }

    function populateModulesFilter() {
        const currentSelected = filterModule.value;
        const modules = getUniqueModules();
        filterModule.innerHTML = '<option value="all">Todos los Módulos</option>';
        modules.forEach(mod => {
            const opt = document.createElement('option');
            opt.value = mod;
            opt.textContent = mod;
            if (mod === currentSelected) opt.selected = true;
            filterModule.appendChild(opt);
        });

        // Llenar select del modal de nueva actividad
        const modalModuleSelect = document.getElementById('new-module');
        if (modalModuleSelect) {
            modalModuleSelect.innerHTML = '';
            modules.forEach(mod => {
                const opt = document.createElement('option');
                opt.value = mod;
                opt.textContent = mod;
                modalModuleSelect.appendChild(opt);
            });
        }
    }

    function saveData() {
        localStorage.setItem('alwayson_activities', JSON.stringify(activities));
        updateDashboard();
        renderTable();
        renderModulesTable();
    }

    function renderTable() {
        const selectedModule = filterModule.value;
        const searchTerm = searchActivity.value.toLowerCase();

        tbody.innerHTML = '';

        const filtered = activities.filter(item => {
            const matchMod = selectedModule === 'all' || item.module === selectedModule;
            const matchSearch = item.name.toLowerCase().includes(searchTerm) || item.owner.toLowerCase().includes(searchTerm);
            return matchMod && matchSearch;
        });

        if (filtered.length === 0) {
            tbody.innerHTML = `<tr><td colspan="8" style="text-align: center; padding: 20px; color: var(--text-muted);">No se encontraron actividades</td></tr>`;
            return;
        }

        filtered.forEach(item => {
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td><strong>${item.module}</strong></td>
                <td>${item.name}</td>
                <td>
                    <select class="status-select ${item.status}" data-id="${item.id}">
                        <option value="Pendiente" ${item.status === 'Pendiente' ? 'selected' : ''}>Pendiente</option>
                        <option value="Ejecucion" ${item.status === 'Ejecucion' ? 'selected' : ''}>En Ejecución</option>
                        <option value="Completado" ${item.status === 'Completado' ? 'selected' : ''}>Completado</option>
                        <option value="Fallido" ${item.status === 'Fallido' ? 'selected' : ''}>Fallido</option>
                    </select>
                </td>
                <td><span style="font-size: 11px; background: #e2e8f0; padding: 3px 8px; border-radius: 4px; font-weight: 600;">${item.owner}</span></td>
                <td><input type="date" class="table-input date-start" data-id="${item.id}" value="${item.start}"></td>
                <td><input type="date" class="table-input date-end" data-id="${item.id}" value="${item.end}"></td>
                <td><input type="text" class="table-input obs-text" data-id="${item.id}" value="${item.obs}" placeholder="Notas..."></td>
                <td>
                    <button class="btn-icon-danger delete-act-btn" data-id="${item.id}" title="Eliminar actividad">
                        <i class="fa-solid fa-trash"></i>
                    </button>
                </td>
            `;
            tbody.appendChild(tr);
        });

        attachTableListeners();
    }

    function renderModulesTable() {
        if (!modulesTbody) return;
        modulesTbody.innerHTML = '';
        const modules = getUniqueModules();

        modules.forEach(mod => {
            const modItems = activities.filter(a => a.module === mod);
            const total = modItems.length;
            const completed = modItems.filter(a => a.status === 'Completado').length;

            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td><strong><i class="fa-solid fa-folder"></i> ${mod}</strong></td>
                <td>${total} actividades</td>
                <td>${completed} / ${total} (${total > 0 ? Math.round((completed/total)*100) : 0}%)</td>
                <td>
                    <button class="btn-icon-danger delete-mod-btn" data-module="${mod}" title="Eliminar Módulo y sus actividades">
                        <i class="fa-solid fa-trash"></i> Eliminar
                    </button>
                </td>
            `;
            modulesTbody.appendChild(tr);
        });

        attachModuleListeners();
    }

    function attachTableListeners() {
        document.querySelectorAll('.status-select').forEach(select => {
            select.addEventListener('change', (e) => {
                const id = parseInt(e.target.getAttribute('data-id'));
                const val = e.target.value;
                const act = activities.find(a => a.id === id);
                if (act) {
                    act.status = val;
                    saveData();
                }
            });
        });

        document.querySelectorAll('.date-start').forEach(input => {
            input.addEventListener('change', (e) => {
                const id = parseInt(e.target.getAttribute('data-id'));
                const act = activities.find(a => a.id === id);
                if (act) { act.start = e.target.value; saveData(); }
            });
        });

        document.querySelectorAll('.date-end').forEach(input => {
            input.addEventListener('change', (e) => {
                const id = parseInt(e.target.getAttribute('data-id'));
                const act = activities.find(a => a.id === id);
                if (act) { act.end = e.target.value; saveData(); }
            });
        });

        document.querySelectorAll('.obs-text').forEach(input => {
            input.addEventListener('input', (e) => {
                const id = parseInt(e.target.getAttribute('data-id'));
                const act = activities.find(a => a.id === id);
                if (act) { act.obs = e.target.value; localStorage.setItem('alwayson_activities', JSON.stringify(activities)); }
            });
        });

        document.querySelectorAll('.delete-act-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const id = parseInt(e.currentTarget.getAttribute('data-id'));
                if (confirm('¿Estás seguro de eliminar esta actividad?')) {
                    activities = activities.filter(a => a.id !== id);
                    saveData();
                }
            });
        });
    }

    function attachModuleListeners() {
        document.querySelectorAll('.delete-mod-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const modName = e.currentTarget.getAttribute('data-module');
                if (confirm(`¿Estás seguro de eliminar el módulo "${modName}" y todas sus actividades asociadas?`)) {
                    activities = activities.filter(a => a.module !== modName);
                    saveData();
                    populateModulesFilter();
                }
            });
        });
    }

    function updateDashboard() {
        const total = activities.length;
        const completed = activities.filter(a => a.status === 'Completado').length;
        const running = activities.filter(a => a.status === 'Ejecucion').length;
        const failed = activities.filter(a => a.status === 'Fallido').length;
        const percent = total > 0 ? Math.round((completed / total) * 100) : 0;

        kpiTotal.textContent = total;
        kpiOk.textContent = completed;
        kpiRun.textContent = running;
        kpiError.textContent = failed;
        kpiPercent.textContent = percent + '%';

        updateCharts(completed, running, failed, total - (completed + running + failed));
        updateModuleProgressGrid();
    }

    function updateCharts(ok, run, err, pend) {
        // 1. Gráfico de Dona (Estado General)
        const ctxDoughnut = document.getElementById('statusChart').getContext('2d');
        if (statusChartInstance) {
            statusChartInstance.data.datasets[0].data = [ok, run, err, pend];
            statusChartInstance.update();
        } else {
            statusChartInstance = new Chart(ctxDoughnut, {
                type: 'doughnut',
                data: {
                    labels: ['Completadas', 'En Ejecución', 'Fallidas', 'Pendientes'],
                    datasets: [{
                        data: [ok, run, err, pend],
                        backgroundColor: ['#10b981', '#f59e0b', '#ef4444', '#cbd5e1'],
                        borderWidth: 2,
                        borderColor: '#ffffff'
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            position: 'bottom',
                            labels: { boxWidth: 12, font: { family: 'Inter', size: 12 } }
                        }
                    }
                }
            });
        }

        // 2. Gráfico de Barras Horizontal (Avance Porcentual por Módulo)
        const modules = getUniqueModules();
        const modulePercentages = modules.map(mod => {
            const items = activities.filter(a => a.module === mod);
            const t = items.length;
            const c = items.filter(a => a.status === 'Completado').length;
            return t > 0 ? Math.round((c / t) * 100) : 0;
        });

        const ctxBar = document.getElementById('modulesBarChart').getContext('2d');
        if (modulesBarChartInstance) {
            modulesBarChartInstance.data.labels = modules;
            modulesBarChartInstance.data.datasets[0].data = modulePercentages;
            modulesBarChartInstance.update();
        } else {
            modulesBarChartInstance = new Chart(ctxBar, {
                type: 'bar',
                data: {
                    labels: modules,
                    datasets: [{
                        label: '% de Avance',
                        data: modulePercentages,
                        backgroundColor: '#2563eb',
                        borderRadius: 6
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    indexAxis: 'y',
                    scales: {
                        x: {
                            beginAtZero: true,
                            max: 100,
                            ticks: { callback: (val) => val + '%' }
                        }
                    },
                    plugins: {
                        legend: { display: false }
                    }
                }
            });
        }
    }

    function updateModuleProgressGrid() {
        const container = document.getElementById('modules-progress-list');
        if (!container) return;
        container.innerHTML = '';

        const modules = getUniqueModules();

        modules.forEach(mod => {
            const modItems = activities.filter(a => a.module === mod);
            const modTotal = modItems.length;
            const modCompleted = modItems.filter(a => a.status === 'Completado').length;
            const modPercent = modTotal > 0 ? Math.round((modCompleted / modTotal) * 100) : 0;

            const div = document.createElement('div');
            div.className = 'module-progress-item';
            div.innerHTML = `
                <div class="module-progress-info">
                    <span>${mod}</span>
                    <span><strong>${modPercent}%</strong> (${modCompleted}/${modTotal})</span>
                </div>
                <div class="progress-bar-bg">
                    <div class="progress-bar-fill" style="width: ${modPercent}%;"></div>
                </div>
            `;
            container.appendChild(div);
        });
    }

    resetBtn.addEventListener('click', () => {
        if (confirm('¿Estás seguro de restablecer todos los avances a su estado inicial?')) {
            localStorage.removeItem('alwayson_activities');
            activities = JSON.parse(JSON.stringify(initialPlanData));
            populateModulesFilter();
            updateDashboard();
            renderTable();
            renderModulesTable();
        }
    });

    filterModule.addEventListener('change', renderTable);
    searchActivity.addEventListener('input', renderTable);

    // Modal de Nueva Actividad
    const modal = document.getElementById('activity-modal');
    const openModalBtn = document.getElementById('open-modal-btn');
    const closeModalBtn = document.getElementById('close-modal-btn');
    const cancelModalBtn = document.getElementById('cancel-modal-btn');
    const addActivityForm = document.getElementById('add-activity-form');

    if (openModalBtn) {
        openModalBtn.addEventListener('click', () => {
            populateModulesFilter();
            modal.classList.add('active');
        });
    }
    if (closeModalBtn) closeModalBtn.addEventListener('click', () => modal.classList.remove('active'));
    if (cancelModalBtn) cancelModalBtn.addEventListener('click', () => modal.classList.remove('active'));

    // Modal de Nuevo Módulo
    const moduleModal = document.getElementById('module-modal');
    const openModuleModalBtn = document.getElementById('open-module-modal-btn');
    const closeModuleModalBtn = document.getElementById('close-module-modal-btn');
    const cancelModuleModalBtn = document.getElementById('cancel-module-modal-btn');
    const addModuleForm = document.getElementById('add-module-form');

    if (openModuleModalBtn) {
        openModuleModalBtn.addEventListener('click', () => moduleModal.classList.add('active'));
    }
    if (closeModuleModalBtn) closeModuleModalBtn.addEventListener('click', () => moduleModal.classList.remove('active'));
    if (cancelModuleModalBtn) cancelModuleModalBtn.addEventListener('click', () => moduleModal.classList.remove('active'));

    window.addEventListener('click', (e) => {
        if (e.target === modal) modal.classList.remove('active');
        if (e.target === moduleModal) moduleModal.classList.remove('active');
    });

    if (addActivityForm) {
        addActivityForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const moduleName = document.getElementById('new-module').value.trim();
            const activityName = document.getElementById('new-name').value.trim();
            const ownerName = document.getElementById('new-owner').value.trim();

            if (!moduleName || !activityName || !ownerName) return;

            const newId = activities.length > 0 ? Math.max(...activities.map(a => a.id)) + 1 : 1;
            
            activities.push({
                id: newId,
                module: moduleName,
                name: activityName,
                status: "Pendiente",
                owner: ownerName,
                start: "",
                end: "",
                obs: ""
            });

            saveData();
            populateModulesFilter();
            renderModulesTable();

            addActivityForm.reset();
            modal.classList.remove('active');
        });
    }

    if (addModuleForm) {
        addModuleForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const newModName = document.getElementById('new-module-name').value.trim();
            if (!newModName) return;

            const existingModules = getUniqueModules();
            if (existingModules.includes(newModName)) {
                alert('Este módulo ya existe.');
                return;
            }

            // Crear una actividad por defecto para el módulo para que aparezca
            const newId = activities.length > 0 ? Math.max(...activities.map(a => a.id)) + 1 : 1;
            activities.push({
                id: newId,
                module: newModName,
                name: "Actividad Inicial de Certificación",
                status: "Pendiente",
                owner: "DBA",
                start: "",
                end: "",
                obs: "Módulo creado manualmente"
            });

            saveData();
            populateModulesFilter();
            renderModulesTable();

            addModuleForm.reset();
            moduleModal.classList.remove('active');
        });
    }

    populateModulesFilter();
    updateDashboard();
    renderTable();
    renderModulesTable();
});
