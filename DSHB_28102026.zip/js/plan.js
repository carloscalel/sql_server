// Datos iniciales completos basados en el Plan Integral de Certificación SQL Server AlwaysOn
const initialPlanData = [
    // Pruebas Técnicas AlwaysOn
    { id: 1, module: "Pruebas Técnicas AlwaysOn", name: "Failover Manual", status: "Pendiente", owner: "DBA", start: "", end: "", obs: "" },
    { id: 2, module: "Pruebas Técnicas AlwaysOn", name: "Failover Automático", status: "Pendiente", owner: "DBA", start: "", end: "", obs: "" },
    { id: 3, module: "Pruebas Técnicas AlwaysOn", name: "Failback", status: "Pendiente", owner: "DBA", start: "", end: "", obs: "" },
    { id: 4, module: "Pruebas Técnicas AlwaysOn", name: "Caída Nodo Primario", status: "Pendiente", owner: "DBA", start: "", end: "", obs: "" },
    { id: 5, module: "Pruebas Técnicas AlwaysOn", name: "Caída Nodo Secundario", status: "Pendiente", owner: "DBA", start: "", end: "", obs: "" },
    { id: 6, module: "Pruebas Técnicas AlwaysOn", name: "Reconexión mediante Listener", status: "Pendiente", owner: "DBA", start: "", end: "", obs: "" },
    { id: 7, module: "Pruebas Técnicas AlwaysOn", name: "Sincronización de réplicas", status: "Pendiente", owner: "DBA", start: "", end: "", obs: "" },
    { id: 8, module: "Pruebas Técnicas AlwaysOn", name: "Backups y Restores", status: "Pendiente", owner: "DBA", start: "", end: "", obs: "" },
    { id: 9, module: "Pruebas Técnicas AlwaysOn", name: "Integridad DBCC", status: "Pendiente", owner: "DBA", start: "", end: "", obs: "" },

    // Infraestructura
    { id: 10, module: "Infraestructura", name: "Validación CPU y RAM", status: "Pendiente", owner: "Infraestructura", start: "", end: "", obs: "" },
    { id: 11, module: "Infraestructura", name: "Storage e IOPS", status: "Pendiente", owner: "Infraestructura", start: "", end: "", obs: "" },
    { id: 12, module: "Infraestructura", name: "Latencia Data & Log", status: "Pendiente", owner: "Infraestructura", start: "", end: "", obs: "" },
    { id: 13, module: "Infraestructura", name: "Cluster Windows & VMware", status: "Pendiente", owner: "Infraestructura", start: "", end: "", obs: "" },
    { id: 14, module: "Infraestructura", name: "Eventos Windows & Capacidad", status: "Pendiente", owner: "Infraestructura", start: "", end: "", obs: "" },

    // Telecomunicaciones
    { id: 15, module: "Telecomunicaciones", name: "Resolución DNS & Firewall", status: "Pendiente", owner: "Telecom", start: "", end: "", obs: "" },
    { id: 16, module: "Telecomunicaciones", name: "Ruteo, ACL y Conectividad", status: "Pendiente", owner: "Telecom", start: "", end: "", obs: "" },
    { id: 17, module: "Telecomunicaciones", name: "Listener Latency & Balanceadores", status: "Pendiente", owner: "Telecom", start: "", end: "", obs: "" },
    { id: 18, module: "Telecomunicaciones", name: "Monitoreo de tráfico", status: "Pendiente", owner: "Telecom", start: "", end: "", obs: "" },

    // Ciberseguridad
    { id: 19, module: "Ciberseguridad", name: "Hardening Windows & SQL Server", status: "Pendiente", owner: "Ciberseguridad", start: "", end: "", obs: "" },
    { id: 20, module: "Ciberseguridad", name: "Escaneo de Vulnerabilidades", status: "Pendiente", owner: "Ciberseguridad", start: "", end: "", obs: "" },
    { id: 21, module: "Ciberseguridad", name: "TLS, EDR y SIEM", status: "Pendiente", owner: "Ciberseguridad", start: "", end: "", obs: "" },
    { id: 22, module: "Ciberseguridad", name: "Cuentas Privilegiadas y Certificados", status: "Pendiente", owner: "Ciberseguridad", start: "", end: "", obs: "" },

    // Core Bancario
    { id: 23, module: "Core Bancario", name: "Consulta Cliente, Cuenta y Saldo", status: "Pendiente", owner: "Operaciones", start: "", end: "", obs: "" },
    { id: 24, module: "Core Bancario", name: "Débito, Crédito y Transferencias", status: "Pendiente", owner: "Operaciones", start: "", end: "", obs: "" },
    { id: 25, module: "Core Bancario", name: "Pago de Servicios y Bloqueos", status: "Pendiente", owner: "Operaciones", start: "", end: "", obs: "" },
    { id: 26, module: "Core Bancario", name: "Cierre Operativo", status: "Pendiente", owner: "Operaciones", start: "", end: "", obs: "" },

    // Certificación ACH
    { id: 27, module: "Certificación ACH", name: "Creación y Aprobación de Lotes", status: "Pendiente", owner: "Tesorería", start: "", end: "", obs: "" },
    { id: 28, module: "Certificación ACH", name: "Generación Archivo ACH & SFTP", status: "Pendiente", owner: "Tesorería", start: "", end: "", obs: "" },
    { id: 29, module: "Certificación ACH", name: "Recepción, Créditos y Débitos ACH", status: "Pendiente", owner: "Tesorería", start: "", end: "", obs: "" },
    { id: 30, module: "Certificación ACH", name: "Conciliación y Reproceso", status: "Pendiente", owner: "Tesorería", start: "", end: "", obs: "" },

    // Pruebas UAT
    { id: 31, module: "Pruebas UAT", name: "Consultas y Transacciones (Operaciones)", status: "Pendiente", owner: "Usuarios Clave", start: "", end: "", obs: "" },
    { id: 32, module: "Pruebas UAT", name: "ACH y Conciliaciones (Tesorería)", status: "Pendiente", owner: "Usuarios Clave", start: "", end: "", obs: "" },
    { id: 33, module: "Pruebas UAT", name: "Cuadres y Reportes (Contabilidad)", status: "Pendiente", owner: "Usuarios Clave", start: "", end: "", obs: "" },
    { id: 34, module: "Pruebas UAT", name: "Banca Web y App Móvil (Canales)", status: "Pendiente", owner: "Usuarios Clave", start: "", end: "", obs: "" },

    // Continuidad Operativa
    { id: 35, module: "Continuidad Operativa", name: "Validación RTO y RPO", status: "Pendiente", owner: "Continuidad", start: "", end: "", obs: "" },
    { id: 36, module: "Continuidad Operativa", name: "Recuperación de servicios críticos", status: "Pendiente", owner: "Continuidad", start: "", end: "", obs: "" },
    { id: 37, module: "Continuidad Operativa", name: "Validación posterior a failover", status: "Pendiente", owner: "Continuidad", start: "", end: "", obs: "" },
    { id: 38, module: "Continuidad Operativa", name: "Integridad de información y monitoreo", status: "Pendiente", owner: "Continuidad", start: "", end: "", obs: "" }
];
