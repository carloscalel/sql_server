using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using SqlAccessAdmin.ViewModels;

namespace SqlAccessAdmin.Views;

public partial class AccessRequestEditor : UserControl
{
    private AccessViewModel? _subscribedViewModel;

    public AccessRequestEditor()
    {
        InitializeComponent();
        DataContextChanged+=OnDataContextChanged;
        Loaded+=(_,_)=>SubscribeTo(DataContext as AccessViewModel);
        Unloaded+=(_,_)=>SubscribeTo(null);
    }

    private void OnDataContextChanged(object sender,DependencyPropertyChangedEventArgs e)=>SubscribeTo(e.NewValue as AccessViewModel);

    private void SubscribeTo(AccessViewModel? viewModel)
    {
        if(_subscribedViewModel is not null)_subscribedViewModel.TemporaryPasswordCleared-=ClearPasswordBoxes;
        _subscribedViewModel=viewModel;
        if(_subscribedViewModel is not null)_subscribedViewModel.TemporaryPasswordCleared+=ClearPasswordBoxes;
    }

    private void ClearPasswordBoxes()
    {
        TemporaryPasswordBox.Clear();
        TemporaryPasswordConfirmationBox.Clear();
    }

    private void TicketNumber_OnPreviewTextInput(object sender,TextCompositionEventArgs e)
    {
        e.Handled=e.Text.Any(character=>!char.IsDigit(character));
    }

    private async void SelectObjects_OnClick(object sender,RoutedEventArgs e)
    {
        if(DataContext is not AccessViewModel vm)return;
        await vm.LoadDatabaseObjectsForSelectionAsync();
        if(vm.DatabaseObjects.Count==0)return;
        var selector=new DatabaseObjectSelectorWindow(vm.DatabaseObjects,vm.SelectedDatabaseObjects)
        {
            Owner=Window.GetWindow(this)
        };
        if(selector.ShowDialog()==true)vm.ApplySelectedDatabaseObjects(selector.SelectedObjects);
    }

    private void SelectAllPermissions_OnClick(object sender,RoutedEventArgs e)
    {
        if(DataContext is not AccessViewModel vm)return;
        foreach(var permission in vm.PermissionChoices)permission.IsSelected=true;
    }

    private void ClearPermissions_OnClick(object sender,RoutedEventArgs e)
    {
        if(DataContext is not AccessViewModel vm)return;
        foreach(var permission in vm.PermissionChoices)permission.IsSelected=false;
    }

    private void TemporaryPassword_OnPasswordChanged(object sender,RoutedEventArgs e)
    {if(DataContext is AccessViewModel vm)vm.TemporaryPassword=((PasswordBox)sender).Password;}

    private void TemporaryPasswordConfirmation_OnPasswordChanged(object sender,RoutedEventArgs e)
    {if(DataContext is AccessViewModel vm)vm.TemporaryPasswordConfirmation=((PasswordBox)sender).Password;}

    private void GeneratePassword_OnClick(object sender,RoutedEventArgs e)
    {
        if(DataContext is not AccessViewModel vm)return;
        var password=vm.GenerateTemporaryPassword();
        TemporaryPasswordBox.Password=password;
        TemporaryPasswordConfirmationBox.Password=password;
        vm.Status="Contraseña temporal segura sugerida. Cópiela y entréguela al usuario mediante un canal seguro.";
    }

    private void CopyPassword_OnClick(object sender,RoutedEventArgs e)
    {
        if(DataContext is not AccessViewModel vm||!vm.IsTemporaryPasswordValid){if(DataContext is AccessViewModel invalid)invalid.Status=invalid.TemporaryPasswordValidationMessage;return;}
        Clipboard.SetText(vm.TemporaryPassword);
        vm.Status="Contraseña temporal copiada. El portapapeles puede contener información sensible; entréguela por un canal seguro.";
    }
}
