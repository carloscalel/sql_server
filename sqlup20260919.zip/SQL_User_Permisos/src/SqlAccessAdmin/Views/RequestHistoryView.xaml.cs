using System.Windows;
using System.Windows.Controls;
using SqlAccessAdmin.Models;

namespace SqlAccessAdmin.Views;

public partial class RequestHistoryView : UserControl
{
    public RequestHistoryView()=>InitializeComponent();

    private void CopyTicket_OnClick(object sender,RoutedEventArgs e)
    {
        if(sender is Button{DataContext:AccessRequestItem request}&&!string.IsNullOrWhiteSpace(request.ExternalTicketNumber))
            Clipboard.SetText(request.ExternalTicketNumber);
    }
}
