using System.Data;
using System.Security.Cryptography;
using Microsoft.Data.SqlClient;
using SqlAccessAdmin.Models;
using SqlAccessAdmin.Security;

namespace SqlAccessAdmin.Data;

public sealed class DirectSqlServerService(AdminDbGateway adminDb)
{
    private static readonly HashSet<string> AllowedPermissions=new(StringComparer.OrdinalIgnoreCase){"SELECT","INSERT","UPDATE","DELETE","EXECUTE"};
    private static readonly HashSet<string> ForbiddenRoles=new(StringComparer.OrdinalIgnoreCase){"db_owner","db_securityadmin","db_accessadmin","db_ddladmin","db_backupoperator","sysadmin","securityadmin","serveradmin","setupadmin","processadmin","diskadmin","bulkadmin"};
    private async Task<(ServerConnectionInfo Server,string ConnectionString)> ResolveAsync(int serverId,string database="master",CancellationToken ct=default)
    {
        var server=await adminDb.GetServerConnectionAsync(serverId,ct);
        string? password=null;
        if(!server.WindowsAuth)
        {
            if(server.Credential is null)throw new InvalidOperationException("El servidor no tiene una credencial SQL cifrada.");
            var crypto=await adminDb.GetCryptoMaterialAsync(ct);
            if(crypto.KeyId!=server.Credential.KeyId)throw new InvalidOperationException("La credencial utiliza una versión de clave no disponible.");
            try{password=new AesGcmCredentialProtector(crypto.MasterKey).Unprotect(server.Credential);}
            finally{CryptographicOperations.ZeroMemory(crypto.MasterKey);}
        }
        var source=string.IsNullOrWhiteSpace(server.Instance)?server.Host:$"{server.Host}\\{server.Instance}";
        var builder=new SqlConnectionStringBuilder{DataSource=source,InitialCatalog=database,IntegratedSecurity=server.WindowsAuth,UserID=server.WindowsAuth?"":server.SqlUser,Password=password??"",Encrypt=server.Encrypt,TrustServerCertificate=server.TrustCertificate,ConnectTimeout=server.TimeoutSeconds,ApplicationName="SqlAccessAdmin-Direct"};
        return(server,builder.ConnectionString);
    }

    public async Task TestAsync(int serverId,CancellationToken ct=default)
    { var x=await ResolveAsync(serverId,ct:ct);await using var cn=new SqlConnection(x.ConnectionString);await cn.OpenAsync(ct); }

    public async Task TestAsync(ServerEditData data,CancellationToken ct=default)
    {
        string? password=data.Password;
        if(!data.WindowsAuth&&string.IsNullOrEmpty(password)&&data.Id.HasValue){var existing=await ResolveAsync(data.Id.Value,ct:ct);password=new SqlConnectionStringBuilder(existing.ConnectionString).Password;}
        var source=string.IsNullOrWhiteSpace(data.Instance)?data.Host:$"{data.Host}\\{data.Instance}";
        var builder=new SqlConnectionStringBuilder{DataSource=source,InitialCatalog="master",IntegratedSecurity=data.WindowsAuth,UserID=data.WindowsAuth?"":data.SqlUser,Password=password??"",Encrypt=data.Encrypt,TrustServerCertificate=data.TrustCertificate,ConnectTimeout=data.TimeoutSeconds,ApplicationName="SqlAccessAdmin-Direct-Test"};
        await using var cn=new SqlConnection(builder.ConnectionString);await cn.OpenAsync(ct);
    }

    public async Task<IReadOnlyList<DatabaseItem>> GetDatabasesAsync(IEnumerable<ServerItem> servers,CancellationToken ct=default)
    {
        var tasks=servers.Where(x=>x.IsSelected).Select(async item=>{var x=await ResolveAsync(item.Id,ct:ct);await using var cn=new SqlConnection(x.ConnectionString);await cn.OpenAsync(ct);var schema=cn.GetSchema("Databases");return schema.Rows.Cast<DataRow>().Select(r=>new DatabaseItem{ServerId=item.Id,Server=item.Name,Name=Convert.ToString(r["database_name"])??""}).Where(d=>!string.IsNullOrWhiteSpace(d.Name)).ToList();});
        return (await Task.WhenAll(tasks)).SelectMany(x=>x).OrderBy(x=>x.Server).ThenBy(x=>x.Name).ToList();
    }

    public async Task<IReadOnlyList<DatabaseObjectItem>> GetDatabaseObjectsAsync(DatabaseItem database,CancellationToken ct=default)
    {
        var resolved=await ResolveAsync(database.ServerId,database.Name,ct);
        await using var cn=new SqlConnection(resolved.ConnectionString);
        await cn.OpenAsync(ct);
        await using var cmd=new SqlCommand("sys.sp_help",cn)
        {
            CommandType=CommandType.StoredProcedure,
            CommandTimeout=resolved.Server.TimeoutSeconds
        };
        await using var reader=await cmd.ExecuteReaderAsync(ct);
        var result=new List<DatabaseObjectItem>();
        while(await reader.ReadAsync(ct))
        {
            var name=Convert.ToString(reader["Name"])?.Trim()??"";
            var schema=Convert.ToString(reader["Owner"])?.Trim()??"dbo";
            var rawType=Convert.ToString(reader["Object_type"])?.Trim()??"";
            var normalized=rawType.ToUpperInvariant();
            var kind=normalized switch
            {
                var x when x.Contains("USER_TABLE")||x.Contains("USER TABLE")=>"TABLE",
                var x when x.Contains("VIEW")=>"VIEW",
                var x when x.Contains("STORED_PROCEDURE")||x.Contains("STORED PROCEDURE")=>"PROCEDURE",
                var x when x.Contains("FUNCTION")=>"FUNCTION",
                _=>""
            };
            if(!string.IsNullOrWhiteSpace(name)&&!string.IsNullOrWhiteSpace(kind))
                result.Add(new(database.ServerId,database.Server,database.Name,schema,name,kind));
        }
        return result.OrderBy(x=>x.Kind).ThenBy(x=>x.Schema).ThenBy(x=>x.Name).ToList();
    }

    public async Task<DataTable> GetSecurityInventoryAsync(int serverId,string database,string inventoryType,CancellationToken ct=default)
    {
        var resolved=await ResolveAsync(serverId,string.IsNullOrWhiteSpace(database)?"master":database,ct);
        await using var cn=new SqlConnection(resolved.ConnectionString);await cn.OpenAsync(ct);
        await using var cmd=inventoryType=="LOGINS"
            ? new SqlCommand("SELECT name AS LoginName,is_disabled AS IsDisabled,type_desc AS LoginType FROM sys.server_principals WHERE type IN ('S','U','G','C','K') ORDER BY name",cn)
            : new SqlCommand(inventoryType switch
            {
                "USERS"=>"sys.sp_helpuser",
                "ROLES"=>"sys.sp_helprole",
                "PERMISSIONS"=>"sys.sp_helprotect",
                _=>throw new InvalidOperationException("Tipo de inventario no permitido.")
            },cn){CommandType=CommandType.StoredProcedure};
        cmd.CommandTimeout=resolved.Server.TimeoutSeconds;
        await using var reader=await cmd.ExecuteReaderAsync(ct);var table=new DataTable();table.Load(reader);return table;
    }

    public async Task<bool> IsLoginEnabledAsync(int serverId,string login,CancellationToken ct=default)
    {
        if(string.IsNullOrWhiteSpace(login))throw new InvalidOperationException("El login seleccionado no es válido.");
        var resolved=await ResolveAsync(serverId,"master",ct);
        await using var cn=new SqlConnection(resolved.ConnectionString);
        await cn.OpenAsync(ct);
        await using var cmd=new SqlCommand("SELECT is_disabled FROM sys.server_principals WHERE name=@login AND type IN ('S','U','G','C','K')",cn)
        {
            CommandTimeout=resolved.Server.TimeoutSeconds
        };
        cmd.Parameters.Add(new("@login",SqlDbType.NVarChar,128){Value=login});
        var value=await cmd.ExecuteScalarAsync(ct);
        if(value is null||value is DBNull)throw new InvalidOperationException($"El login {login} ya no existe en el servidor.");
        return !Convert.ToBoolean(value);
    }

    public async Task<MappedLoginState?> GetMappedLoginStateAsync(int serverId,string database,string user,CancellationToken ct=default)
    {
        if(string.IsNullOrWhiteSpace(database)||string.IsNullOrWhiteSpace(user))
            throw new InvalidOperationException("El usuario de base seleccionado no es válido.");
        var resolved=await ResolveAsync(serverId,database,ct);
        await using var cn=new SqlConnection(resolved.ConnectionString);
        await cn.OpenAsync(ct);
        await using var cmd=new SqlCommand(
            "SELECT TOP (1) sp.name AS LoginName,sp.is_disabled AS IsDisabled FROM sys.database_principals dp INNER JOIN sys.server_principals sp ON dp.sid=sp.sid WHERE dp.name=@user",
            cn){CommandTimeout=resolved.Server.TimeoutSeconds};
        cmd.Parameters.Add(new("@user",SqlDbType.NVarChar,128){Value=user});
        await using var reader=await cmd.ExecuteReaderAsync(ct);
        if(!await reader.ReadAsync(ct))return null;
        return new(reader.GetString(0),!reader.GetBoolean(1));
    }

    public async Task<SecurityPrincipalDetails> GetSecurityPrincipalDetailsAsync(
        int serverId,
        string database,
        string principal,
        SecurityNodeKind kind,
        CancellationToken ct=default)
    {
        if (string.IsNullOrWhiteSpace(principal))
            throw new InvalidOperationException("El principal seleccionado no es válido.");

        var details = new SecurityPrincipalDetails();
        if (kind == SecurityNodeKind.Login)
        {
            var loginData = await RunSystemProcedureAsync(
                serverId,
                "master",
                "sys.sp_helplogins",
                [new SqlParameter("@LoginNamePattern", SqlDbType.NVarChar, 128) { Value = principal }],
                ct);

            if (loginData.Tables.Count > 1)
            {
                foreach (DataRow row in loginData.Tables[1].Rows)
                {
                    var dbName = Cell(row, "DBName", "DatabaseName");
                    var userName = Cell(row, "UserName", "Name");
                    if (!string.IsNullOrWhiteSpace(userName))
                        details.Memberships.Add(new SecurityMembershipItem("Usuario de base", userName, dbName));
                }
            }

            var serverRoles = await RunSystemProcedureAsync(serverId, "master", "sys.sp_helpsrvrolemember", [], ct);
            foreach (DataTable table in serverRoles.Tables)
            foreach (DataRow row in table.Rows)
            {
                var member = Cell(row, "MemberName", "LoginName");
                if (!member.Equals(principal, StringComparison.OrdinalIgnoreCase)) continue;
                var role = Cell(row, "ServerRole", "RoleName");
                if (!string.IsNullOrWhiteSpace(role))
                    details.Memberships.Add(new SecurityMembershipItem("Rol de servidor", role, "Servidor"));
            }

            return details;
        }

        var helpUser = await RunSystemProcedureAsync(
            serverId,
            database,
            "sys.sp_helpuser",
            [new SqlParameter("@name_in_db", SqlDbType.NVarChar, 128) { Value = principal }],
            ct);
        foreach (DataTable table in helpUser.Tables)
        foreach (DataRow row in table.Rows)
        {
            var role = Cell(row, "RoleName");
            if (!string.IsNullOrWhiteSpace(role))
                details.Memberships.Add(new SecurityMembershipItem("Rol de base asignado", role, database));
        }

        var permissions = await RunOptionalReportProcedureAsync(
            serverId,
            database,
            "sys.sp_helprotect",
            [new SqlParameter("@username", SqlDbType.NVarChar, 128) { Value = principal }],
            ct);

        foreach (DataTable table in permissions.Tables)
        foreach (DataRow row in table.Rows)
        {
            var state = Cell(row, "ProtectType", "State");
            var permission = Cell(row, "Action", "Permission");
            var owner = Cell(row, "Owner", "Schema");
            var target = Cell(row, "Object", "ObjectName");
            var column = Cell(row, "Column", "ColumnName");
            var securableParts = new[] { owner, target, column }
                .Where(x => !string.IsNullOrWhiteSpace(x) && x != ".");
            var securable = string.Join('.', securableParts);
            var scope = !string.IsNullOrWhiteSpace(column) && column != "."
                ? "COLUMN"
                : !string.IsNullOrWhiteSpace(target) && target != "." ? "OBJECT" : "DATABASE";
            if (!string.IsNullOrWhiteSpace(permission))
                details.Permissions.Add(new SecurityPermissionItem(state, permission, scope, securable, Cell(row, "Grantor")));
        }

        return details;
    }

    private async Task<DataSet> RunOptionalReportProcedureAsync(
        int serverId,
        string database,
        string procedure,
        IReadOnlyCollection<SqlParameter> parameters,
        CancellationToken ct)
    {
        try
        {
            return await RunSystemProcedureAsync(serverId,database,procedure,parameters,ct);
        }
        catch(SqlException ex) when(IsEmptyReport(ex.Message))
        {
            return new DataSet();
        }
    }

    private static bool IsEmptyReport(string message)=>
        message.Contains("no matching rows",StringComparison.OrdinalIgnoreCase)||
        message.Contains("no hay filas que coincidan",StringComparison.OrdinalIgnoreCase)||
        message.Contains("aucune ligne correspondante",StringComparison.OrdinalIgnoreCase)||
        message.Contains("keine übereinstimmenden Zeilen",StringComparison.OrdinalIgnoreCase);

    private async Task<DataSet> RunSystemProcedureAsync(
        int serverId,
        string database,
        string procedure,
        IReadOnlyCollection<SqlParameter> parameters,
        CancellationToken ct)
    {
        var resolved = await ResolveAsync(serverId, database, ct);
        await using var cn = new SqlConnection(resolved.ConnectionString);
        await cn.OpenAsync(ct);
        await using var cmd = new SqlCommand(procedure, cn)
        {
            CommandType = CommandType.StoredProcedure,
            CommandTimeout = resolved.Server.TimeoutSeconds
        };
        foreach (var parameter in parameters) cmd.Parameters.Add(parameter);

        await using var reader = await cmd.ExecuteReaderAsync(ct);
        var result = new DataSet();
        var resultNumber = 1;
        do
        {
            if (reader.FieldCount <= 0) continue;
            var table = new DataTable($"Result{resultNumber++}");
            for (var index = 0; index < reader.FieldCount; index++)
            {
                var columnName = reader.GetName(index);
                if (string.IsNullOrWhiteSpace(columnName)) columnName = $"Column{index + 1}";
                var uniqueName = columnName;
                var suffix = 2;
                while (table.Columns.Contains(uniqueName)) uniqueName = $"{columnName}_{suffix++}";
                table.Columns.Add(uniqueName, typeof(object));
            }

            while (await reader.ReadAsync(ct))
            {
                var values = new object[reader.FieldCount];
                reader.GetValues(values);
                table.Rows.Add(values);
            }
            result.Tables.Add(table);
        }
        while (await reader.NextResultAsync(ct));

        return result;
    }

    private static string Cell(DataRow row, params string[] names)
    {
        var column = names.Select(name => row.Table.Columns.Cast<DataColumn>()
                .FirstOrDefault(x => x.ColumnName.Equals(name, StringComparison.OrdinalIgnoreCase)))
            .FirstOrDefault(x => x is not null);
        return column is null || row.IsNull(column) ? "" : Convert.ToString(row[column])?.Trim() ?? "";
    }

    public async Task<IReadOnlyList<OperationResult>> ExecuteApprovedRequestAsync(AccessRequestItem request,IEnumerable<DatabaseItem> targets,string? newLoginPassword,IReadOnlyList<AccessRequestStepItem>? steps=null,bool passwordPolicy=true,bool passwordExpiration=true,bool mustChangePassword=true,CancellationToken ct=default)
    {
        if(request.Status!="APPROVED")throw new InvalidOperationException("La solicitud debe estar aprobada.");
        if(!string.IsNullOrWhiteSpace(request.Permission)&&!AllowedPermissions.Contains(request.Permission))throw new InvalidOperationException("Permiso bloqueado por la política máxima.");
        if(!string.IsNullOrWhiteSpace(request.Role)&&ForbiddenRoles.Contains(request.Role))throw new InvalidOperationException("Rol bloqueado permanentemente.");
        var targetList=targets.ToList();
        if(targetList.Select(x=>x.ServerId).Distinct().Count()!=1)throw new InvalidOperationException("La solicitud debe pertenecer a un único servidor. Divida cualquier solicitud histórica con varios servidores antes de ejecutarla.");
        var results=new List<OperationResult>();
        foreach(var group in targetList.GroupBy(x=>x.ServerId))
        {
            var master=await ResolveAsync(group.Key,ct:ct);
            if(request.Operation is "CREATE_SQL_LOGIN" or "CREATE_WINDOWS_LOGIN" or "CLONE_SQL_LOGIN" or "ENABLE_LOGIN" or "DISABLE_LOGIN")
            {
                try
                {
                    if(request.Operation=="CREATE_SQL_LOGIN")await EnsureLoginAsync(master.ConnectionString,request.TargetPrincipal,true,newLoginPassword,passwordPolicy,passwordExpiration,mustChangePassword,ct);
                    else if(request.Operation=="CREATE_WINDOWS_LOGIN")await EnsureLoginAsync(master.ConnectionString,request.TargetPrincipal,false,null,false,false,false,ct);
                    else if(request.Operation=="CLONE_SQL_LOGIN")await CloneLoginAsync(master.ConnectionString,request.SourcePrincipal,request.TargetPrincipal,newLoginPassword,ct);
                    else await SetLoginEnabledAsync(master.ConnectionString,request.TargetPrincipal,request.Operation=="ENABLE_LOGIN",ct);
                    if(steps is {Count:>0})
                    {
                        foreach(var target in group)
                        {
                            try
                            {
                                var db=await ResolveAsync(group.Key,target.Name,ct);
                                foreach(var step in steps.OrderBy(x=>x.Order))await ExecuteStepAsync(db.ConnectionString,request.TargetPrincipal,step,ct);
                                results.Add(new(master.Server.Name,target.Name,true,$"Login y {steps.Count} paso(s) de acceso ejecutados en orden."));
                            }
                            catch(Exception ex){results.Add(new(master.Server.Name,target.Name,false,$"El login fue creado, pero falló el acceso inicial: {ex.Message}"));}
                        }
                    }
                    else foreach(var db in group)results.Add(new(master.Server.Name,db.Name,true,"Operación de login completada."));
                }
                catch(Exception ex){foreach(var db in group)results.Add(new(master.Server.Name,db.Name,false,ex.Message));}
                continue;
            }
            foreach(var target in group)
            {
                try
                {
                    var db=await ResolveAsync(group.Key,target.Name,ct);
                    switch(request.Operation)
                    {
                        case "CREATE_DB_USER":await EnsureUserAsync(db.ConnectionString,request.TargetPrincipal,ct);break;
                        case "MODIFY_LOGIN":await ChangeRoleAsync(db.ConnectionString,request.TargetPrincipal,request.Role,true,ct);break;
                        case "ADD_ROLE_MEMBER":await ChangeRoleAsync(db.ConnectionString,request.TargetPrincipal,request.Role,true,ct);break;
                        case "REMOVE_ROLE_MEMBER":await ChangeRoleAsync(db.ConnectionString,request.TargetPrincipal,request.Role,false,ct);break;
                        case "PERMISSION_CHANGE":await ChangePermissionAsync(db.ConnectionString,request.TargetPrincipal,request.PermissionAction,request.Permission,request.Scope,request.Securable,ct);break;
                        case "CLONE_PERMISSIONS":await ClonePermissionsAsync(db.ConnectionString,request.SourcePrincipal,request.TargetPrincipal,ct);break;
                        default:throw new InvalidOperationException("La operación aprobada no tiene un ejecutor registrado.");
                    }
                    results.Add(new(master.Server.Name,target.Name,true,"Operación aprobada ejecutada."));
                }
                catch(Exception ex){results.Add(new(master.Server.Name,target.Name,false,ex.Message));}
            }
        }
        return results;
    }

    private static async Task ExecuteStepAsync(string connectionString,string principal,AccessRequestStepItem step,CancellationToken ct)
    {
        if(!string.IsNullOrWhiteSpace(step.Permission)&&!AllowedPermissions.Contains(step.Permission))throw new InvalidOperationException("Permiso de paso bloqueado por la política máxima.");
        if(!string.IsNullOrWhiteSpace(step.Role)&&ForbiddenRoles.Contains(step.Role))throw new InvalidOperationException("Rol de paso bloqueado permanentemente.");
        switch(step.Operation)
        {
            case "CREATE_DB_USER":await EnsureUserAsync(connectionString,principal,ct);break;
            case "ADD_ROLE_MEMBER":await ChangeRoleAsync(connectionString,principal,step.Role,true,ct);break;
            case "REMOVE_ROLE_MEMBER":await ChangeRoleAsync(connectionString,principal,step.Role,false,ct);break;
            case "PERMISSION_CHANGE":await ChangePermissionAsync(connectionString,principal,step.PermissionAction,step.Permission,step.Scope,step.Securable,ct);break;
            default:throw new InvalidOperationException($"El paso {step.Order} no tiene un ejecutor registrado.");
        }
    }

    private static async Task EnsureUserAsync(string connectionString,string login,CancellationToken ct)
    {
        await using var cn=new SqlConnection(connectionString);await cn.OpenAsync(ct);await using var cmd=new SqlCommand("sys.sp_grantdbaccess",cn){CommandType=CommandType.StoredProcedure};cmd.Parameters.Add(new("@loginame",SqlDbType.NVarChar,128){Value=login});try{await cmd.ExecuteNonQueryAsync(ct);}catch(SqlException ex)when(ex.Number==15023){}
    }
    private static async Task ChangeRoleAsync(string connectionString,string principal,string role,bool add,CancellationToken ct)
    {
        if(string.IsNullOrWhiteSpace(role)||ForbiddenRoles.Contains(role))throw new InvalidOperationException("Rol no permitido.");
        await EnsureUserAsync(connectionString,principal,ct);await using var cn=new SqlConnection(connectionString);await cn.OpenAsync(ct);await using var cmd=new SqlCommand(add?"sys.sp_addrolemember":"sys.sp_droprolemember",cn){CommandType=CommandType.StoredProcedure};cmd.Parameters.Add(new("@rolename",SqlDbType.NVarChar,128){Value=role});cmd.Parameters.Add(new("@membername",SqlDbType.NVarChar,128){Value=principal});await cmd.ExecuteNonQueryAsync(ct);
    }
    private static async Task SetLoginEnabledAsync(string connectionString,string login,bool enabled,CancellationToken ct)
    {var b=new SqlCommandBuilder();var sql=$"ALTER LOGIN {b.QuoteIdentifier(login)} {(enabled?"ENABLE":"DISABLE")}";await ExecuteControlledTextAsync(connectionString,sql,ct);}

    private static async Task ChangePermissionAsync(string connectionString,string principal,string action,string permission,string scope,string securable,CancellationToken ct)
    {
        if(!AllowedPermissions.Contains(permission))throw new InvalidOperationException("Permiso fuera de la allowlist máxima.");
        if(action is not ("GRANT" or "REVOKE"))throw new InvalidOperationException("Solo se permite conceder o retirar accesos.");
        await EnsurePrincipalIsNotRoleAsync(connectionString,principal,ct);
        var b=new SqlCommandBuilder();var target=b.QuoteIdentifier(principal);string onClause="";
        var parts=(securable??"").Split('.',StringSplitOptions.RemoveEmptyEntries|StringSplitOptions.TrimEntries);
        if(scope=="OBJECT"&&parts.Length==2)onClause=$" ON OBJECT::{b.QuoteIdentifier(parts[0])}.{b.QuoteIdentifier(parts[1])}";
        else if(scope!="DATABASE")throw new InvalidOperationException("El securable no coincide con el ámbito seleccionado.");
        var preposition=action=="REVOKE"?"FROM":"TO";var sql=$"{action} {permission}{onClause} {preposition} {target}";await ExecuteControlledTextAsync(connectionString,sql,ct);
    }
    private static async Task CloneLoginAsync(string connectionString,string source,string target,string? password,CancellationToken ct)
    {
        if(string.IsNullOrWhiteSpace(source)||string.IsNullOrWhiteSpace(password))throw new InvalidOperationException("Clonar un login requiere origen y una contraseña nueva.");
        await using var cn=new SqlConnection(connectionString);await cn.OpenAsync(ct);await using var query=new SqlCommand("SELECT default_database_name,default_language_name,is_disabled FROM sys.sql_logins WHERE name=@source",cn);query.Parameters.Add(new("@source",SqlDbType.NVarChar,128){Value=source});await using var reader=await query.ExecuteReaderAsync(ct);if(!await reader.ReadAsync(ct))throw new InvalidOperationException("El login origen no existe o no es un login SQL compatible.");var db=reader.GetString(0);var lang=reader.GetString(1);var disabled=reader.GetBoolean(2);await reader.CloseAsync();await using var create=new SqlCommand("sys.sp_addlogin",cn){CommandType=CommandType.StoredProcedure};create.Parameters.Add(new("@loginame",SqlDbType.NVarChar,128){Value=target});create.Parameters.Add(new("@passwd",SqlDbType.NVarChar,128){Value=password});create.Parameters.Add(new("@defdb",SqlDbType.NVarChar,128){Value=db});create.Parameters.Add(new("@deflanguage",SqlDbType.NVarChar,128){Value=lang});await create.ExecuteNonQueryAsync(ct);if(disabled)await SetLoginEnabledAsync(connectionString,target,false,ct);
    }
    private static async Task ClonePermissionsAsync(string connectionString,string source,string target,CancellationToken ct)
    {
        if(string.IsNullOrWhiteSpace(source))throw new InvalidOperationException("Indique el principal origen.");
        await EnsurePrincipalIsNotRoleAsync(connectionString,source,ct);
        await EnsurePrincipalIsNotRoleAsync(connectionString,target,ct);
        await EnsureUserAsync(connectionString,target,ct);
        const string sql="SELECT p.state_desc,p.permission_name,CASE WHEN p.class=0 THEN 'DATABASE' WHEN p.class=3 THEN 'SCHEMA' WHEN p.class=1 AND p.minor_id=0 THEN 'OBJECT' WHEN p.class=1 THEN 'COLUMN' END ScopeType,CASE WHEN p.class=3 THEN SCHEMA_NAME(p.major_id) ELSE OBJECT_SCHEMA_NAME(p.major_id) END SchemaName,CASE WHEN p.class=1 THEN OBJECT_NAME(p.major_id) END ObjectName,CASE WHEN p.class=1 AND p.minor_id>0 THEN COL_NAME(p.major_id,p.minor_id) END ColumnName FROM sys.database_permissions p JOIN sys.database_principals u ON u.principal_id=p.grantee_principal_id WHERE u.name=@source AND p.state IN('G','D')";
        await using var cn=new SqlConnection(connectionString);await cn.OpenAsync(ct);await using var cmd=new SqlCommand(sql,cn);cmd.Parameters.Add(new("@source",SqlDbType.NVarChar,128){Value=source});await using var reader=await cmd.ExecuteReaderAsync(ct);var grants=new List<(string Action,string Permission,string Scope,string Securable)>();while(await reader.ReadAsync(ct)){var permission=reader.GetString(1);if(!AllowedPermissions.Contains(permission))continue;var scope=reader.IsDBNull(2)?"":reader.GetString(2);var parts=new[]{reader.IsDBNull(3)?null:reader.GetString(3),reader.IsDBNull(4)?null:reader.GetString(4),reader.IsDBNull(5)?null:reader.GetString(5)}.Where(x=>x is not null);grants.Add((reader.GetString(0)=="DENY"?"DENY":"GRANT",permission,scope,string.Join('.',parts!)));}await reader.CloseAsync();foreach(var g in grants)await ChangePermissionAsync(connectionString,target,g.Action,g.Permission,g.Scope,g.Securable,ct);
    }

    private static async Task EnsurePrincipalIsNotRoleAsync(string connectionString,string principal,CancellationToken ct)
    {
        await using var cn=new SqlConnection(connectionString);
        await cn.OpenAsync(ct);
        await using var cmd=new SqlCommand("sys.sp_helprole",cn){CommandType=CommandType.StoredProcedure};
        cmd.Parameters.Add(new("@rolename",SqlDbType.NVarChar,128){Value=principal});
        try
        {
            await using var reader=await cmd.ExecuteReaderAsync(ct);
            if(await reader.ReadAsync(ct))
                throw new InvalidOperationException($"'{principal}' es un rol. Los permisos solo pueden administrarse para usuarios; los roles son inmutables.");
        }
        catch(SqlException ex) when(IsEmptyReport(ex.Message))
        {
            // El principal no es un rol registrado en la base de datos.
        }
    }
    private static async Task ExecuteControlledTextAsync(string connectionString,string text,CancellationToken ct)
    {await using var cn=new SqlConnection(connectionString);await cn.OpenAsync(ct);await using var cmd=new SqlCommand(text,cn){CommandTimeout=60};await cmd.ExecuteNonQueryAsync(ct);}

    private static async Task EnsureLoginAsync(string connectionString,string login,bool sqlLogin,string? password,bool passwordPolicy,bool passwordExpiration,bool mustChangePassword,CancellationToken ct)
    {
        await using var cn=new SqlConnection(connectionString);await cn.OpenAsync(ct);
        SqlCommand cmd;
        if(sqlLogin)
        {
            if(string.IsNullOrWhiteSpace(password)||password.Length<16)throw new InvalidOperationException("La contraseña temporal debe contener al menos 16 caracteres.");
            var b=new SqlCommandBuilder();
            var mustChange=mustChangePassword?" MUST_CHANGE":"";
            var passwordLiteral=$"N'{password.Replace("'","''",StringComparison.Ordinal)}'";
            var sql=$"CREATE LOGIN {b.QuoteIdentifier(login)} WITH PASSWORD={passwordLiteral}{mustChange}, CHECK_POLICY={(passwordPolicy?"ON":"OFF")}, CHECK_EXPIRATION={(passwordExpiration?"ON":"OFF")}";
            cmd=new SqlCommand(sql,cn){CommandType=CommandType.Text};
        }
        else
        {
            cmd=new SqlCommand("sys.sp_grantlogin",cn){CommandType=CommandType.StoredProcedure};
            cmd.Parameters.Add(new SqlParameter("@loginame",SqlDbType.NVarChar,128){Value=login});
        }
        await using(cmd)try{await cmd.ExecuteNonQueryAsync(ct);}catch(SqlException ex)when(ex.Number==15025){ }
    }

}
