USE [adminDB];
GO
SET NOCOUNT ON;
SET XACT_ABORT ON;
GO

/* Una solicitud visible puede contener pasos internos ordenados. La contraseña
   temporal se persiste únicamente como sobre AES-GCM y se elimina al ejecutar. */
IF COL_LENGTH(N'dbo.AccessRequest',N'SecretCiphertext') IS NULL ALTER TABLE dbo.AccessRequest ADD SecretCiphertext varbinary(max) NULL;
IF COL_LENGTH(N'dbo.AccessRequest',N'SecretNonce') IS NULL ALTER TABLE dbo.AccessRequest ADD SecretNonce varbinary(12) NULL;
IF COL_LENGTH(N'dbo.AccessRequest',N'SecretTag') IS NULL ALTER TABLE dbo.AccessRequest ADD SecretTag varbinary(16) NULL;
IF COL_LENGTH(N'dbo.AccessRequest',N'SecretKeyId') IS NULL ALTER TABLE dbo.AccessRequest ADD SecretKeyId uniqueidentifier NULL;
IF COL_LENGTH(N'dbo.AccessRequest',N'PasswordPolicy') IS NULL ALTER TABLE dbo.AccessRequest ADD PasswordPolicy bit NOT NULL CONSTRAINT DF_AccessRequest_PasswordPolicy DEFAULT(0);
IF COL_LENGTH(N'dbo.AccessRequest',N'PasswordExpiration') IS NULL ALTER TABLE dbo.AccessRequest ADD PasswordExpiration bit NOT NULL CONSTRAINT DF_AccessRequest_PasswordExpiration DEFAULT(0);
IF COL_LENGTH(N'dbo.AccessRequest',N'MustChangePassword') IS NULL ALTER TABLE dbo.AccessRequest ADD MustChangePassword bit NOT NULL CONSTRAINT DF_AccessRequest_MustChange DEFAULT(0);
GO

IF OBJECT_ID(N'dbo.AccessRequestStep',N'U') IS NULL
CREATE TABLE dbo.AccessRequestStep
(
 StepId bigint IDENTITY(1,1) NOT NULL CONSTRAINT PK_AccessRequestStep PRIMARY KEY,
 RequestId bigint NOT NULL,StepOrder int NOT NULL,OperationCode varchar(40) NOT NULL,
 PermissionAction varchar(10) NULL,PermissionName varchar(40) NULL,ScopeType varchar(20) NULL,
 Securable nvarchar(776) NULL,RoleName sysname NULL,
 CONSTRAINT FK_AccessRequestStep_Request FOREIGN KEY(RequestId) REFERENCES dbo.AccessRequest(RequestId),
 CONSTRAINT FK_AccessRequestStep_Operation FOREIGN KEY(OperationCode) REFERENCES dbo.SecurityPolicyOperation(OperationCode),
 CONSTRAINT UQ_AccessRequestStep_Order UNIQUE(RequestId,StepOrder),
 CONSTRAINT CK_AccessRequestStep_Order CHECK(StepOrder>0),
 CONSTRAINT CK_AccessRequestStep_Action CHECK(PermissionAction IS NULL OR PermissionAction IN('GRANT','DENY','REVOKE'))
);
GO

IF TYPE_ID(N'dbo.AccessRequestStepType') IS NULL
EXEC(N'CREATE TYPE dbo.AccessRequestStepType AS TABLE(StepOrder int NOT NULL,OperationCode varchar(40) NOT NULL,PermissionAction varchar(10) NULL,PermissionName varchar(40) NULL,ScopeType varchar(20) NULL,Securable nvarchar(776) NULL,RoleName sysname NULL,PRIMARY KEY(StepOrder));');
GO

CREATE OR ALTER PROCEDURE dbo.usp_AccessRequest_List
 @Status varchar(20)=NULL,@ServerId int=NULL
AS
BEGIN
 SET NOCOUNT ON;
 SELECT r.RequestId,r.OperationCode,r.TargetPrincipal,ISNULL(r.SourcePrincipal,N'') SourcePrincipal,
  ISNULL(r.AuthenticationType,'') AuthenticationType,ISNULL(r.PermissionAction,'') PermissionAction,
  ISNULL(r.PermissionName,'') PermissionName,ISNULL(r.ScopeType,'') ScopeType,ISNULL(r.Securable,N'') Securable,
  ISNULL(r.RoleName,N'') RoleName,ISNULL(r.ExternalTicketNumber,'') ExternalTicketNumber,r.Justification,r.Status,
  r.RequestedBy,r.RequestedAt,ISNULL(r.ApprovedBy,N'') ApprovedBy,r.ApprovedAt,
  (SELECT COUNT(*) FROM dbo.AccessRequestTarget t WHERE t.RequestId=r.RequestId) TargetCount,
  (SELECT COUNT(*) FROM dbo.AccessRequestStep s WHERE s.RequestId=r.RequestId) StepCount
 FROM dbo.AccessRequest r
 WHERE (@Status IS NULL OR r.Status=@Status)
   AND (@ServerId IS NULL OR
       (EXISTS(SELECT 1 FROM dbo.AccessRequestTarget st WHERE st.RequestId=r.RequestId AND st.ServerId=@ServerId)
        AND NOT EXISTS(SELECT 1 FROM dbo.AccessRequestTarget ot WHERE ot.RequestId=r.RequestId AND ot.ServerId<>@ServerId)))
 ORDER BY r.RequestedAt DESC;
END;
GO

CREATE OR ALTER PROCEDURE dbo.usp_AccessRequest_Create
 @OperationCode varchar(40),@TargetPrincipal nvarchar(256),@SourcePrincipal nvarchar(256)=NULL,
 @AuthenticationType varchar(20)=NULL,@PermissionAction varchar(10)=NULL,@PermissionName varchar(40)=NULL,
 @ScopeType varchar(20)=NULL,@Securable nvarchar(776)=NULL,@RoleName sysname=NULL,
 @ExternalTicketNumber varchar(40),@Justification nvarchar(1000),
 @Targets dbo.AccessRequestTargetType READONLY,@Steps dbo.AccessRequestStepType READONLY,
 @SecretCiphertext varbinary(max)=NULL,@SecretNonce varbinary(12)=NULL,@SecretTag varbinary(16)=NULL,
 @SecretKeyId uniqueidentifier=NULL,@PasswordPolicy bit=0,@PasswordExpiration bit=0,@MustChangePassword bit=0
AS
BEGIN
 SET NOCOUNT ON;SET XACT_ABORT ON;
 -- SqlAccessAdmin.AccessRequestCreate · SqlAccessAdmin.CompositeRequestCreate
 SET @ExternalTicketNumber=UPPER(LTRIM(RTRIM(@ExternalTicketNumber)));
 IF @ExternalTicketNumber NOT LIKE 'TIC-RF-%' OR LEN(@ExternalTicketNumber)<=7 OR SUBSTRING(@ExternalTicketNumber,8,40) LIKE '%[^0-9]%'
  THROW 51320,'El ticket externo debe usar TIC-RF- seguido únicamente por dígitos.',1;
 IF NOT EXISTS(SELECT 1 FROM @Targets) THROW 51310,'Debe seleccionar destinos.',1;
 IF (SELECT COUNT(DISTINCT ServerId) FROM @Targets)<>1 THROW 51314,'Cada solicitud debe pertenecer a un único servidor.',1;
 IF LEN(LTRIM(RTRIM(@Justification)))<10 THROW 51311,'La justificación debe contener al menos 10 caracteres.',1;
 IF @OperationCode='CREATE_SQL_LOGIN' AND (@SecretCiphertext IS NULL OR @SecretNonce IS NULL OR @SecretTag IS NULL OR @SecretKeyId IS NULL)
  THROW 51330,'La creación de un login SQL requiere una contraseña temporal cifrada.',1;
 IF @OperationCode='CREATE_SQL_LOGIN' AND @PasswordExpiration=1 AND @PasswordPolicy=0
  THROW 51331,'CHECK_EXPIRATION requiere CHECK_POLICY activo.',1;
 IF @OperationCode='CREATE_SQL_LOGIN' AND @MustChangePassword=1 AND (@PasswordPolicy=0 OR @PasswordExpiration=0)
  THROW 51335,'MUST_CHANGE requiere CHECK_POLICY y CHECK_EXPIRATION activos.',1;
 IF EXISTS(SELECT 1 FROM @Steps) AND @OperationCode NOT IN('CREATE_SQL_LOGIN','CREATE_WINDOWS_LOGIN')
  THROW 51332,'Solo la creación de login admite un plan interno.',1;
 IF EXISTS(SELECT 1 FROM @Steps) AND (SELECT TOP(1) OperationCode FROM @Steps ORDER BY StepOrder)<>'CREATE_DB_USER'
  THROW 51333,'El primer paso interno debe crear el usuario de base.',1;

 DECLARE @Check table(Allowed bit,RequiresApproval bit,RiskLevel varchar(10),Reason nvarchar(2000));
 INSERT @Check EXEC dbo.usp_AccessRequest_Preview @OperationCode,@PermissionAction,@PermissionName,@ScopeType,@RoleName;
 IF NOT EXISTS(SELECT 1 FROM @Check WHERE Allowed=1) THROW 51312,'Solicitud rechazada por la política central.',1;
 DECLARE @SO varchar(40),@SA varchar(10),@SP varchar(40),@SS varchar(20),@SR sysname;
 DECLARE StepPolicy CURSOR LOCAL FAST_FORWARD FOR SELECT OperationCode,PermissionAction,PermissionName,ScopeType,RoleName FROM @Steps ORDER BY StepOrder;
 OPEN StepPolicy;FETCH NEXT FROM StepPolicy INTO @SO,@SA,@SP,@SS,@SR;
 WHILE @@FETCH_STATUS=0
 BEGIN
  DELETE FROM @Check;INSERT @Check EXEC dbo.usp_AccessRequest_Preview @SO,@SA,@SP,@SS,@SR;
  IF NOT EXISTS(SELECT 1 FROM @Check WHERE Allowed=1) BEGIN CLOSE StepPolicy;DEALLOCATE StepPolicy;THROW 51334,'Un paso interno fue rechazado por la política central.',1;END;
  FETCH NEXT FROM StepPolicy INTO @SO,@SA,@SP,@SS,@SR;
 END;
 CLOSE StepPolicy;DEALLOCATE StepPolicy;

 BEGIN TRAN;
 DECLARE @LockResult int;EXEC @LockResult=sys.sp_getapplock @Resource=N'SqlAccessAdmin.AccessRequestCreate',@LockMode='Exclusive',@LockOwner='Transaction',@LockTimeout=10000;
 IF @LockResult<0 THROW 51317,'No fue posible bloquear el registro de solicitudes.',1;
 DECLARE @ExistingRequestId bigint;
 SELECT TOP(1) @ExistingRequestId=r.RequestId FROM dbo.AccessRequest r WITH(UPDLOCK,HOLDLOCK)
 WHERE r.Status IN('PENDING','APPROVED') AND r.OperationCode=@OperationCode
  AND UPPER(LTRIM(RTRIM(r.TargetPrincipal)))=UPPER(LTRIM(RTRIM(@TargetPrincipal)))
  AND NOT EXISTS(SELECT ServerId,DatabaseName FROM @Targets EXCEPT SELECT ServerId,DatabaseName FROM dbo.AccessRequestTarget WHERE RequestId=r.RequestId)
  AND NOT EXISTS(SELECT ServerId,DatabaseName FROM dbo.AccessRequestTarget WHERE RequestId=r.RequestId EXCEPT SELECT ServerId,DatabaseName FROM @Targets)
 ORDER BY r.RequestId DESC;
 IF @ExistingRequestId IS NOT NULL BEGIN ROLLBACK;DECLARE @DuplicateMessage nvarchar(2048)=CONCAT(N'Ya existe la solicitud activa #',@ExistingRequestId,N' con la misma operación, principal y destinos.');THROW 51316,@DuplicateMessage,1;END;

 INSERT dbo.AccessRequest(OperationCode,TargetPrincipal,SourcePrincipal,AuthenticationType,PermissionAction,PermissionName,ScopeType,Securable,RoleName,ExternalTicketNumber,Justification,
  SecretCiphertext,SecretNonce,SecretTag,SecretKeyId,PasswordPolicy,PasswordExpiration,MustChangePassword)
 VALUES(@OperationCode,@TargetPrincipal,@SourcePrincipal,@AuthenticationType,@PermissionAction,@PermissionName,@ScopeType,@Securable,@RoleName,@ExternalTicketNumber,@Justification,
  @SecretCiphertext,@SecretNonce,@SecretTag,@SecretKeyId,@PasswordPolicy,@PasswordExpiration,@MustChangePassword);
 DECLARE @Id bigint=SCOPE_IDENTITY();
 INSERT dbo.AccessRequestTarget(RequestId,ServerId,DatabaseName) SELECT @Id,ServerId,DatabaseName FROM @Targets;
 INSERT dbo.AccessRequestStep(RequestId,StepOrder,OperationCode,PermissionAction,PermissionName,ScopeType,Securable,RoleName)
  SELECT @Id,StepOrder,OperationCode,PermissionAction,PermissionName,ScopeType,Securable,RoleName FROM @Steps;
 COMMIT;
 DECLARE @StepCount int=(SELECT COUNT(*) FROM @Steps);
 DECLARE @AuditDetail nvarchar(2000)=CONCAT(
  N'Solicitud compuesta #',@Id,N' · ',@ExternalTicketNumber,N' · ',@StepCount,N' pasos internos · ',
  N'CHECK_POLICY=',IIF(@PasswordPolicy=1,N'ON',N'OFF'),N' · CHECK_EXPIRATION=',IIF(@PasswordExpiration=1,N'ON',N'OFF'),
  N' · MUST_CHANGE=',IIF(@MustChangePassword=1,N'ON',N'OFF'));
 EXEC dbo.usp_Audit_Write N'Solicitudes',N'Crear',NULL,NULL,1,@AuditDetail;
 SELECT @Id RequestId,'PENDING' [Status];
END;
GO

CREATE OR ALTER PROCEDURE dbo.usp_AccessRequest_StepList @RequestId bigint
AS
BEGIN
 SET NOCOUNT ON;
 SELECT StepId,StepOrder,OperationCode,ISNULL(PermissionAction,'') PermissionAction,ISNULL(PermissionName,'') PermissionName,
  ISNULL(ScopeType,'') ScopeType,ISNULL(Securable,N'') Securable,ISNULL(RoleName,N'') RoleName
 FROM dbo.AccessRequestStep WHERE RequestId=@RequestId ORDER BY StepOrder;
END;
GO

CREATE OR ALTER PROCEDURE dbo.usp_AccessRequest_SecretGet @RequestId bigint
AS
BEGIN
 SET NOCOUNT ON;
 IF IS_SRVROLEMEMBER(N'sysadmin')<>1 AND NOT EXISTS(SELECT 1 FROM dbo.AuthorizedPrincipal WHERE Principal=ORIGINAL_LOGIN() AND Active=1 AND RoleName IN('Administrator','Operator'))
  THROW 51301,'Se requiere un usuario Administrator u Operator activo.',1;
 SELECT SecretCiphertext,SecretNonce,SecretTag,SecretKeyId,PasswordPolicy,PasswordExpiration,MustChangePassword
 FROM dbo.AccessRequest WHERE RequestId=@RequestId AND Status='APPROVED';
END;
GO

CREATE OR ALTER PROCEDURE dbo.usp_AccessRequest_SecretDiscard @RequestId bigint
AS
BEGIN
 SET NOCOUNT ON;
 UPDATE dbo.AccessRequest SET SecretCiphertext=NULL,SecretNonce=NULL,SecretTag=NULL,SecretKeyId=NULL
 WHERE RequestId=@RequestId AND Status IN('REJECTED','CANCELLED');
END;
GO

CREATE OR ALTER PROCEDURE dbo.usp_AccessRequest_MarkExecuted @RequestId bigint,@Success bit,@Detail nvarchar(2000)
AS
BEGIN
 SET NOCOUNT ON;SET XACT_ABORT ON;
 -- SqlAccessAdmin.SelfConfirmationExecution
 IF IS_SRVROLEMEMBER(N'sysadmin')<>1 AND NOT EXISTS(SELECT 1 FROM dbo.AuthorizedPrincipal WHERE Principal=ORIGINAL_LOGIN() AND Active=1 AND RoleName IN('Administrator','Operator'))
  THROW 51301,'Se requiere un usuario Administrator u Operator activo.',1;
 UPDATE dbo.AccessRequest SET Status=IIF(@Success=1,'EXECUTED','FAILED'),ExecutedBy=ORIGINAL_LOGIN(),ExecutedAt=SYSUTCDATETIME(),
  SecretCiphertext=NULL,SecretNonce=NULL,SecretTag=NULL,SecretKeyId=NULL
 WHERE RequestId=@RequestId AND Status='APPROVED';
 IF @@ROWCOUNT=0 THROW 51315,'La solicitud no está confirmada o ya fue procesada.',1;
 EXEC dbo.usp_Audit_Write N'Solicitudes',N'Ejecutar',NULL,NULL,@Success,@Detail;
END;
GO

GRANT REFERENCES ON TYPE::dbo.AccessRequestStepType TO [SqlAccessAdmin_Users];
GRANT EXECUTE ON dbo.usp_AccessRequest_Create TO [SqlAccessAdmin_Users];
GRANT EXECUTE ON dbo.usp_AccessRequest_List TO [SqlAccessAdmin_Users];
GRANT EXECUTE ON dbo.usp_AccessRequest_StepList TO [SqlAccessAdmin_Users];
GRANT EXECUTE ON dbo.usp_AccessRequest_SecretGet TO [SqlAccessAdmin_Users];
GRANT EXECUTE ON dbo.usp_AccessRequest_SecretDiscard TO [SqlAccessAdmin_Users];
GRANT EXECUTE ON dbo.usp_AccessRequest_MarkExecuted TO [SqlAccessAdmin_Users];
GO
PRINT N'Solicitudes compuestas y contraseña temporal cifrada instaladas.';
GO
